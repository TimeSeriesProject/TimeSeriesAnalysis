/*  1:   */ package ec.ui.html;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbComponents;
/*  4:   */ import ec.ui.AHtmlView;
/*  5:   */ import java.awt.BorderLayout;
/*  6:   */ import javax.swing.BorderFactory;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public final class JHtmlView
/* 27:   */   extends AHtmlView
/* 28:   */ {
/* 29:   */   private final JHtmlPane html;
/* 30:   */   
/* 31:   */   public JHtmlView()
/* 32:   */   {
/* 33:33 */     html = new JHtmlPane();
/* 34:34 */     html.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/* 35:35 */     setLayout(new BorderLayout());
/* 36:36 */     add(NbComponents.newJScrollPane(html), "Center");
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void loadContent(String content)
/* 40:   */   {
/* 41:41 */     html.setText(content);
/* 42:42 */     html.setCaretPosition(0);
/* 43:   */   }
/* 44:   */ }
