/*   1:    */ package ec.ui.html;
/*   2:    */ 
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Graphics;
/*   5:    */ import java.awt.Rectangle;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.util.logging.Level;
/*   8:    */ import java.util.logging.Logger;
/*   9:    */ import javax.swing.AbstractAction;
/*  10:    */ import javax.swing.ActionMap;
/*  11:    */ import javax.swing.JEditorPane;
/*  12:    */ import javax.swing.text.EditorKit;
/*  13:    */ import javax.swing.text.MutableAttributeSet;
/*  14:    */ import javax.swing.text.html.CSS.Attribute;
/*  15:    */ import javax.swing.text.html.HTMLEditorKit;
/*  16:    */ import javax.swing.text.html.StyleSheet;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ public class JHtmlPane
/*  40:    */   extends JEditorPane
/*  41:    */ {
/*  42: 42 */   private boolean lastPaintException = false;
/*  43:    */   
/*  44:    */   public JHtmlPane() {
/*  45: 45 */     setEditable(false);
/*  46:    */     
/*  47:    */ 
/*  48: 48 */     ActionMap actionMap = getActionMap();
/*  49: 49 */     actionMap.put("caret-up", new ScrollAction(-1));
/*  50: 50 */     actionMap.put("caret-down", new ScrollAction(1));
/*  51:    */     
/*  52: 52 */     setEditorKit(new HTMLEditorKit() {});
/*  53: 68 */     initStyleSheet();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Dimension getPreferredSize()
/*  57:    */   {
/*  58:    */     try {
/*  59: 74 */       return super.getPreferredSize();
/*  60:    */     }
/*  61:    */     catch (RuntimeException e) {}
/*  62: 77 */     return new Dimension(400, 600);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void paint(Graphics g)
/*  66:    */   {
/*  67:    */     try
/*  68:    */     {
/*  69: 84 */       super.paint(g);
/*  70: 85 */       lastPaintException = false;
/*  71:    */     }
/*  72:    */     catch (RuntimeException e)
/*  73:    */     {
/*  74: 89 */       if (!lastPaintException) {
/*  75: 90 */         repaint();
/*  76:    */       }
/*  77:    */       
/*  78: 93 */       lastPaintException = true;
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void scrollToReference(String reference)
/*  83:    */   {
/*  84: 99 */     if ((!isShowing()) || (getParent() == null) || (getWidth() < 1) || (getHeight() < 1)) {
/*  85:100 */       return;
/*  86:    */     }
/*  87:102 */     super.scrollToReference(reference);
/*  88:    */   }
/*  89:    */   
/*  90:    */   @Deprecated
/*  91:    */   public void layout()
/*  92:    */   {
/*  93:    */     try {
/*  94:109 */       super.layout();
/*  95:    */     }
/*  96:    */     catch (ArrayIndexOutOfBoundsException aioobE) {
/*  97:112 */       StackTraceElement[] stack = aioobE.getStackTrace();
/*  98:113 */       if ((stack.length > 0) && (stack[0].getClassName().endsWith("BoxView"))) {
/*  99:114 */         Logger.getLogger(JHtmlPane.class.getName()).log(Level.INFO, null, aioobE);
/* 100:    */       } else {
/* 101:116 */         throw aioobE;
/* 102:    */       }
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */ 
/* 107:    */   private class ScrollAction
/* 108:    */     extends AbstractAction
/* 109:    */   {
/* 110:    */     int direction;
/* 111:    */     
/* 112:    */     public ScrollAction(int direction)
/* 113:    */     {
/* 114:129 */       this.direction = direction;
/* 115:    */     }
/* 116:    */     
/* 117:    */     public void actionPerformed(ActionEvent e)
/* 118:    */     {
/* 119:134 */       Rectangle r = getVisibleRect();
/* 120:135 */       int increment = getScrollableUnitIncrement(r, 1, direction);
/* 121:136 */       y += increment * direction;
/* 122:137 */       scrollRectToVisible(r);
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static class FilteredStyleSheet extends StyleSheet
/* 127:    */   {
/* 128:    */     public void addCSSAttribute(MutableAttributeSet attr, CSS.Attribute key, String value)
/* 129:    */     {
/* 130:145 */       value = fixFontSize(key, value);
/* 131:146 */       super.addCSSAttribute(attr, key, value);
/* 132:    */     }
/* 133:    */     
/* 134:    */     public boolean addCSSAttributeFromHTML(MutableAttributeSet attr, CSS.Attribute key, String value)
/* 135:    */     {
/* 136:151 */       value = fixFontSize(key, value);
/* 137:152 */       return super.addCSSAttributeFromHTML(attr, key, value);
/* 138:    */     }
/* 139:    */     
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */     private static String fixFontSize(CSS.Attribute key, String value)
/* 148:    */     {
/* 149:164 */       if (("font-size".equals(key.toString())) && (value != null) && (value.endsWith("%"))) {
/* 150:165 */         String strPercentage = value.replace("%", "");
/* 151:166 */         int percentage = Integer.parseInt(strPercentage);
/* 152:167 */         if (percentage < 100) {
/* 153:168 */           value = "100%";
/* 154:    */         }
/* 155:    */       }
/* 156:171 */       return value;
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   private void initStyleSheet() {
/* 161:176 */     StyleSheet ss = new StyleSheet();
/* 162:177 */     ss.addRule("body {font-family: arial, verdana;}");
/* 163:178 */     ss.addRule("body {font-size: 11;}");
/* 164:179 */     ss.addRule("h4 {color: blue;}");
/* 165:180 */     ss.addRule("td, th{text-align: right; margin-left: 5px; margin-right: 5 px;}");
/* 166:181 */     ss.addRule("table {border: solid;}");
/* 167:182 */     setStyleSheet(ss);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void setStyleSheet(StyleSheet s) {
/* 171:186 */     ((HTMLEditorKit)getEditorKit()).setStyleSheet(s);
/* 172:    */     
/* 173:188 */     String text = getText();
/* 174:189 */     setDocument(getEditorKit().createDefaultDocument());
/* 175:190 */     setText(text);
/* 176:    */   }
/* 177:    */ }
