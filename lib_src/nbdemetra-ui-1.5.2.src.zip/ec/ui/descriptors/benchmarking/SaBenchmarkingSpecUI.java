/*   1:    */ package ec.ui.descriptors.benchmarking;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.descriptors.EnhancedPropertyDescriptor;
/*   4:    */ 
/*   5:    */ public class SaBenchmarkingSpecUI implements ec.tstoolkit.descriptors.IPropertyDescriptors {
/*   6:    */   private final ec.satoolkit.benchmarking.SaBenchmarkingSpec core;
/*   7:    */   private final boolean ro_;
/*   8:    */   private static final int ENABLED_ID = 0;
/*   9:    */   private static final int TARGET_ID = 10;
/*  10:    */   private static final int FORECAST_ID = 20;
/*  11:    */   private static final int RHO_ID = 30;
/*  12:    */   private static final int LAMBDA_ID = 40;
/*  13:    */   private static final String ENABLED_NAME = "Is enabled";
/*  14:    */   private static final String TARGET_NAME = "Target";
/*  15:    */   private static final String FORECAST_NAME = "Use forecasts";
/*  16:    */   private static final String RHO_NAME = "Rho";
/*  17:    */   private static final String LAMBDA_NAME = "Lambda";
/*  18:    */   private static final String ENABLED_DESC = "Is enabled";
/*  19:    */   private static final String TARGET_DESC = "Target";
/*  20:    */   private static final String FORECAST_DESC = "Integrate the forecasts in the benchmarking";
/*  21:    */   private static final String RHO_DESC = "Rho";
/*  22:    */   private static final String LAMBDA_DESC = "Lambda";
/*  23:    */   
/*  24:    */   public SaBenchmarkingSpecUI(ec.satoolkit.benchmarking.SaBenchmarkingSpec spec, boolean ro) {
/*  25: 25 */     core = spec;
/*  26: 26 */     ro_ = ro;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public boolean isEnabled()
/*  30:    */   {
/*  31: 31 */     return core.isEnabled();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setEnabled(boolean value) {
/*  35: 35 */     core.setEnabled(value);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public ec.satoolkit.benchmarking.SaBenchmarkingSpec.Target getTarget() {
/*  39: 39 */     return core.getTarget();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setTarget(ec.satoolkit.benchmarking.SaBenchmarkingSpec.Target target) {
/*  43: 43 */     core.setTarget(target);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public double getRho() {
/*  47: 47 */     return core.getRho();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void setRho(double value) {
/*  51: 51 */     core.setRho(value);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public double getLambda() {
/*  55: 55 */     return core.getLambda();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setLambda(double value) {
/*  59: 59 */     core.setLambda(value);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean isUseForecast() {
/*  63: 63 */     return core.isUsingForecast();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setUseForecast(boolean bf) {
/*  67: 67 */     core.useForecast(bf);
/*  68:    */   }
/*  69:    */   
/*  70:    */   private EnhancedPropertyDescriptor eDesc() {
/*  71:    */     try {
/*  72: 72 */       java.beans.PropertyDescriptor desc = new java.beans.PropertyDescriptor("enabled", getClass());
/*  73: 73 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 0);
/*  74: 74 */       desc.setDisplayName("Is enabled");
/*  75: 75 */       desc.setShortDescription("Is enabled");
/*  76: 76 */       edesc.setReadOnly(ro_);
/*  77: 77 */       return edesc;
/*  78:    */     } catch (java.beans.IntrospectionException ex) {}
/*  79: 79 */     return null;
/*  80:    */   }
/*  81:    */   
/*  82:    */   private EnhancedPropertyDescriptor tDesc()
/*  83:    */   {
/*  84:    */     try {
/*  85: 85 */       java.beans.PropertyDescriptor desc = new java.beans.PropertyDescriptor("target", getClass());
/*  86: 86 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 10);
/*  87: 87 */       desc.setDisplayName("Target");
/*  88: 88 */       desc.setShortDescription("Target");
/*  89: 89 */       edesc.setReadOnly((ro_) || (!core.isEnabled()));
/*  90: 90 */       return edesc;
/*  91:    */     } catch (java.beans.IntrospectionException ex) {}
/*  92: 92 */     return null;
/*  93:    */   }
/*  94:    */   
/*  95:    */   private EnhancedPropertyDescriptor rDesc()
/*  96:    */   {
/*  97:    */     try {
/*  98: 98 */       java.beans.PropertyDescriptor desc = new java.beans.PropertyDescriptor("rho", getClass());
/*  99: 99 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 30);
/* 100:100 */       desc.setDisplayName("Rho");
/* 101:101 */       desc.setShortDescription("Rho");
/* 102:102 */       edesc.setReadOnly((ro_) || (!core.isEnabled()));
/* 103:103 */       return edesc;
/* 104:    */     } catch (java.beans.IntrospectionException ex) {}
/* 105:105 */     return null;
/* 106:    */   }
/* 107:    */   
/* 108:    */   private EnhancedPropertyDescriptor lDesc()
/* 109:    */   {
/* 110:    */     try {
/* 111:111 */       java.beans.PropertyDescriptor desc = new java.beans.PropertyDescriptor("lambda", getClass());
/* 112:112 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 40);
/* 113:113 */       desc.setDisplayName("Lambda");
/* 114:114 */       desc.setShortDescription("Lambda");
/* 115:115 */       edesc.setReadOnly((ro_) || (!core.isEnabled()));
/* 116:116 */       return edesc;
/* 117:    */     } catch (java.beans.IntrospectionException ex) {}
/* 118:118 */     return null;
/* 119:    */   }
/* 120:    */   
/* 121:    */   private EnhancedPropertyDescriptor forecastDesc()
/* 122:    */   {
/* 123:    */     try {
/* 124:124 */       java.beans.PropertyDescriptor desc = new java.beans.PropertyDescriptor("UseForecast", getClass());
/* 125:125 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 20);
/* 126:126 */       desc.setDisplayName("Use forecasts");
/* 127:127 */       desc.setShortDescription("Integrate the forecasts in the benchmarking");
/* 128:128 */       edesc.setReadOnly((ro_) || (!core.isEnabled()));
/* 129:129 */       return edesc;
/* 130:    */     } catch (java.beans.IntrospectionException ex) {}
/* 131:131 */     return null;
/* 132:    */   }
/* 133:    */   
/* 134:    */ 
/* 135:    */   public java.util.List<EnhancedPropertyDescriptor> getProperties()
/* 136:    */   {
/* 137:137 */     java.util.ArrayList<EnhancedPropertyDescriptor> descs = new java.util.ArrayList();
/* 138:138 */     EnhancedPropertyDescriptor desc = eDesc();
/* 139:139 */     if (desc != null) {
/* 140:140 */       descs.add(desc);
/* 141:    */     }
/* 142:142 */     desc = tDesc();
/* 143:143 */     if (desc != null) {
/* 144:144 */       descs.add(desc);
/* 145:    */     }
/* 146:146 */     desc = forecastDesc();
/* 147:147 */     if (desc != null) {
/* 148:148 */       descs.add(desc);
/* 149:    */     }
/* 150:150 */     desc = rDesc();
/* 151:151 */     if (desc != null) {
/* 152:152 */       descs.add(desc);
/* 153:    */     }
/* 154:154 */     desc = lDesc();
/* 155:155 */     if (desc != null) {
/* 156:156 */       descs.add(desc);
/* 157:    */     }
/* 158:158 */     return descs;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public String getDisplayName()
/* 162:    */   {
/* 163:163 */     return "Benchmarking";
/* 164:    */   }
/* 165:    */ }
