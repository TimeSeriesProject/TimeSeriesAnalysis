/*   1:    */ package ec.ui.descriptors;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.descriptors.EnhancedPropertyDescriptor;
/*   4:    */ import ec.tstoolkit.descriptors.EnhancedPropertyDescriptor.Refresh;
/*   5:    */ import ec.tstoolkit.timeseries.Day;
/*   6:    */ import ec.tstoolkit.timeseries.PeriodSelectorType;
/*   7:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*   9:    */ import java.beans.IntrospectionException;
/*  10:    */ import java.beans.PropertyDescriptor;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ 
/*  13:    */ public class TsPeriodSelectorUI implements ec.tstoolkit.descriptors.IPropertyDescriptors
/*  14:    */ {
/*  15:    */   private final TsPeriodSelector core_;
/*  16:    */   private final TsDomain domain_;
/*  17:    */   private final boolean ro_;
/*  18:    */   private static final int TYPE_ID = 1;
/*  19:    */   private static final int D0_ID = 2;
/*  20:    */   private static final int D1_ID = 3;
/*  21:    */   private static final int N0_ID = 4;
/*  22:    */   private static final int N1_ID = 5;
/*  23:    */   
/*  24:    */   static
/*  25:    */   {
/*  26: 26 */     ec.nbdemetra.ui.properties.l2fprod.CustomPropertyEditorRegistry.INSTANCE.registerEnumEditor(Type.class);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static enum Type
/*  30:    */   {
/*  31: 31 */     All, 
/*  32: 32 */     From, 
/*  33: 33 */     To, 
/*  34: 34 */     Between, 
/*  35: 35 */     Last, 
/*  36: 36 */     First, 
/*  37: 37 */     Excluding;
/*  38:    */     
/*  39:    */     public static Type of(PeriodSelectorType type) {
/*  40: 40 */       switch (type) {
/*  41:    */       case Between: 
/*  42: 42 */         return All;
/*  43:    */       case Excluding: 
/*  44: 44 */         return From;
/*  45:    */       case First: 
/*  46: 46 */         return To;
/*  47:    */       case From: 
/*  48: 48 */         return Between;
/*  49:    */       case Last: 
/*  50: 50 */         return Last;
/*  51:    */       case None: 
/*  52: 52 */         return First;
/*  53:    */       case To: 
/*  54: 54 */         return Excluding;
/*  55:    */       }
/*  56: 56 */       throw new IllegalArgumentException();
/*  57:    */     }
/*  58:    */     
/*  59:    */     public static PeriodSelectorType to(Type type)
/*  60:    */     {
/*  61: 61 */       switch (type) {
/*  62:    */       case All: 
/*  63: 63 */         return PeriodSelectorType.All;
/*  64:    */       case Between: 
/*  65: 65 */         return PeriodSelectorType.From;
/*  66:    */       case Excluding: 
/*  67: 67 */         return PeriodSelectorType.To;
/*  68:    */       case First: 
/*  69: 69 */         return PeriodSelectorType.Between;
/*  70:    */       case From: 
/*  71: 71 */         return PeriodSelectorType.Last;
/*  72:    */       case Last: 
/*  73: 73 */         return PeriodSelectorType.First;
/*  74:    */       case To: 
/*  75: 75 */         return PeriodSelectorType.Excluding;
/*  76:    */       }
/*  77: 77 */       return PeriodSelectorType.None;
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */ 
/*  82:    */   public String toString()
/*  83:    */   {
/*  84: 84 */     return core_.toString();
/*  85:    */   }
/*  86:    */   
/*  87:    */ 
/*  88:    */ 
/*  89:    */   public TsPeriodSelectorUI(TsPeriodSelector sel, boolean ro)
/*  90:    */   {
/*  91: 91 */     core_ = sel;
/*  92: 92 */     ro_ = ro;
/*  93: 93 */     domain_ = null;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public TsPeriodSelectorUI(TsPeriodSelector sel, TsDomain domain, boolean ro) {
/*  97: 97 */     core_ = sel;
/*  98: 98 */     ro_ = ro;
/*  99: 99 */     domain_ = domain;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public TsPeriodSelector getCore() {
/* 103:103 */     return core_;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public Type getType() {
/* 107:107 */     return Type.of(core_.getType());
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void setType(Type value) {
/* 111:111 */     core_.setType(Type.to(value));
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Day getStart() {
/* 115:115 */     if ((core_.getD0().equals(TsPeriodSelector.DEF_BEG)) && (domain_ != null)) {
/* 116:116 */       return domain_.getStart().firstday();
/* 117:    */     }
/* 118:118 */     return core_.getD0();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setStart(Day day) {
/* 122:122 */     core_.setD0(day);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Day getEnd() {
/* 126:126 */     if ((core_.getD1().equals(TsPeriodSelector.DEF_END)) && (domain_ != null)) {
/* 127:127 */       return domain_.getLast().lastday();
/* 128:    */     }
/* 129:129 */     return core_.getD1();
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setEnd(Day day) {
/* 133:133 */     core_.setD1(day);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public int getFirst() {
/* 137:137 */     return core_.getN0();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void setFirst(int n) {
/* 141:141 */     core_.setN0(n);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public int getLast() {
/* 145:145 */     return core_.getN1();
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void setLast(int n) {
/* 149:149 */     core_.setN1(n);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public java.util.List<EnhancedPropertyDescriptor> getProperties()
/* 153:    */   {
/* 154:154 */     ArrayList<EnhancedPropertyDescriptor> descs = new ArrayList();
/* 155:155 */     EnhancedPropertyDescriptor desc = typeDesc();
/* 156:156 */     if (desc != null) {
/* 157:157 */       descs.add(desc);
/* 158:    */     }
/* 159:159 */     desc = startDesc();
/* 160:160 */     if (desc != null) {
/* 161:161 */       descs.add(desc);
/* 162:    */     }
/* 163:163 */     desc = endDesc();
/* 164:164 */     if (desc != null) {
/* 165:165 */       descs.add(desc);
/* 166:    */     }
/* 167:167 */     desc = firstDesc();
/* 168:168 */     if (desc != null) {
/* 169:169 */       descs.add(desc);
/* 170:    */     }
/* 171:171 */     desc = lastDesc();
/* 172:172 */     if (desc != null) {
/* 173:173 */       descs.add(desc);
/* 174:    */     }
/* 175:175 */     return descs;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public String getDisplayName()
/* 179:    */   {
/* 180:180 */     return "Span";
/* 181:    */   }
/* 182:    */   
/* 183:    */   private EnhancedPropertyDescriptor typeDesc()
/* 184:    */   {
/* 185:    */     try
/* 186:    */     {
/* 187:187 */       PropertyDescriptor desc = new PropertyDescriptor("type", getClass());
/* 188:188 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/* 189:189 */       edesc.setRefreshMode(EnhancedPropertyDescriptor.Refresh.All);
/* 190:190 */       edesc.setReadOnly(ro_);
/* 191:191 */       return edesc;
/* 192:    */     } catch (IntrospectionException ex) {}
/* 193:193 */     return null;
/* 194:    */   }
/* 195:    */   
/* 196:    */   private EnhancedPropertyDescriptor startDesc()
/* 197:    */   {
/* 198:198 */     PeriodSelectorType type = core_.getType();
/* 199:199 */     if ((type != PeriodSelectorType.Between) && (type != PeriodSelectorType.From)) {
/* 200:200 */       return null;
/* 201:    */     }
/* 202:    */     try {
/* 203:203 */       PropertyDescriptor desc = new PropertyDescriptor("start", getClass());
/* 204:204 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/* 205:205 */       edesc.setRefreshMode(EnhancedPropertyDescriptor.Refresh.All);
/* 206:206 */       edesc.setReadOnly(ro_);
/* 207:207 */       return edesc;
/* 208:    */     } catch (IntrospectionException ex) {}
/* 209:209 */     return null;
/* 210:    */   }
/* 211:    */   
/* 212:    */   private EnhancedPropertyDescriptor endDesc()
/* 213:    */   {
/* 214:214 */     PeriodSelectorType type = core_.getType();
/* 215:215 */     if ((type != PeriodSelectorType.Between) && (type != PeriodSelectorType.To)) {
/* 216:216 */       return null;
/* 217:    */     }
/* 218:    */     try {
/* 219:219 */       PropertyDescriptor desc = new PropertyDescriptor("end", getClass());
/* 220:220 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/* 221:221 */       edesc.setRefreshMode(EnhancedPropertyDescriptor.Refresh.All);
/* 222:222 */       edesc.setReadOnly(ro_);
/* 223:223 */       return edesc;
/* 224:    */     } catch (IntrospectionException ex) {}
/* 225:225 */     return null;
/* 226:    */   }
/* 227:    */   
/* 228:    */   private EnhancedPropertyDescriptor firstDesc()
/* 229:    */   {
/* 230:230 */     PeriodSelectorType type = core_.getType();
/* 231:231 */     if ((type != PeriodSelectorType.Excluding) && (type != PeriodSelectorType.First)) {
/* 232:232 */       return null;
/* 233:    */     }
/* 234:    */     try {
/* 235:235 */       PropertyDescriptor desc = new PropertyDescriptor("first", getClass());
/* 236:236 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/* 237:237 */       edesc.setRefreshMode(EnhancedPropertyDescriptor.Refresh.All);
/* 238:238 */       edesc.setReadOnly(ro_);
/* 239:239 */       return edesc;
/* 240:    */     } catch (IntrospectionException ex) {}
/* 241:241 */     return null;
/* 242:    */   }
/* 243:    */   
/* 244:    */   private EnhancedPropertyDescriptor lastDesc()
/* 245:    */   {
/* 246:246 */     PeriodSelectorType type = core_.getType();
/* 247:247 */     if ((type != PeriodSelectorType.Excluding) && (type != PeriodSelectorType.Last)) {
/* 248:248 */       return null;
/* 249:    */     }
/* 250:    */     try {
/* 251:251 */       PropertyDescriptor desc = new PropertyDescriptor("last", getClass());
/* 252:252 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/* 253:253 */       edesc.setRefreshMode(EnhancedPropertyDescriptor.Refresh.All);
/* 254:254 */       edesc.setReadOnly(ro_);
/* 255:255 */       return edesc;
/* 256:    */     } catch (IntrospectionException ex) {}
/* 257:257 */     return null;
/* 258:    */   }
/* 259:    */ }
