package ec.ui;

import ec.ui.interfaces.IDisposable;
import javax.swing.JComponent;

public abstract class AHtmlView
  extends JComponent
  implements IDisposable
{
  public abstract void loadContent(String paramString);
  
  public void dispose() {}
}
