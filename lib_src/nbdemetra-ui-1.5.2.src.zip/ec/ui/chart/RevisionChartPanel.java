/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ImmutableList;
/*   4:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   5:    */ import ec.nbdemetra.ui.awt.KeyStrokes;
/*   6:    */ import ec.tss.Ts;
/*   7:    */ import ec.tss.TsCollection;
/*   8:    */ import ec.tss.TsFactory;
/*   9:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  10:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  11:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  13:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  14:    */ import ec.ui.ATsControl;
/*  15:    */ import ec.ui.ExtAction;
/*  16:    */ import ec.ui.view.JChartPanel;
/*  17:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  18:    */ import ec.util.chart.swing.Charts;
/*  19:    */ import java.awt.BasicStroke;
/*  20:    */ import java.awt.BorderLayout;
/*  21:    */ import java.awt.Paint;
/*  22:    */ import java.awt.datatransfer.ClipboardOwner;
/*  23:    */ import java.awt.datatransfer.Transferable;
/*  24:    */ import java.awt.event.ActionEvent;
/*  25:    */ import java.text.SimpleDateFormat;
/*  26:    */ import java.util.List;
/*  27:    */ import javax.swing.AbstractAction;
/*  28:    */ import javax.swing.ActionMap;
/*  29:    */ import javax.swing.InputMap;
/*  30:    */ import javax.swing.JMenu;
/*  31:    */ import javax.swing.JMenuItem;
/*  32:    */ import javax.swing.KeyStroke;
/*  33:    */ import org.jfree.chart.JFreeChart;
/*  34:    */ import org.jfree.chart.axis.DateAxis;
/*  35:    */ import org.jfree.chart.axis.DateTickMarkPosition;
/*  36:    */ import org.jfree.chart.axis.NumberAxis;
/*  37:    */ import org.jfree.chart.axis.ValueAxis;
/*  38:    */ import org.jfree.chart.plot.XYPlot;
/*  39:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  40:    */ import org.jfree.data.Range;
/*  41:    */ import org.jfree.data.time.Day;
/*  42:    */ import org.jfree.data.time.TimeSeries;
/*  43:    */ import org.jfree.data.time.TimeSeriesCollection;
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ public class RevisionChartPanel
/*  61:    */   extends ATsControl
/*  62:    */   implements ClipboardOwner
/*  63:    */ {
/*  64:    */   private JChartPanel panel;
/*  65:    */   private XYLineAndShapeRenderer refRenderer;
/*  66:    */   private XYLineAndShapeRenderer seriesRenderer;
/*  67:    */   private static final int REF_INDEX = 0;
/*  68:    */   private static final int SERIES_INDEX = 1;
/*  69:    */   private TsData reference;
/*  70:    */   private List<TsData> revs;
/*  71:    */   private ActionMap am;
/*  72:    */   private InputMap im;
/*  73:    */   
/*  74:    */   public RevisionChartPanel(JFreeChart chart)
/*  75:    */   {
/*  76: 76 */     setLayout(new BorderLayout());
/*  77: 77 */     panel = new JChartPanel(chart);
/*  78:    */     
/*  79: 79 */     refRenderer = new XYLineAndShapeRenderer();
/*  80: 80 */     refRenderer.setBaseShapesVisible(false);
/*  81: 81 */     refRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/*  82: 82 */     refRenderer.setBaseStroke(new BasicStroke(2.0F));
/*  83:    */     
/*  84: 84 */     seriesRenderer = new XYLineAndShapeRenderer();
/*  85: 85 */     seriesRenderer.setBaseShapesVisible(false);
/*  86: 86 */     seriesRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/*  87: 87 */     seriesRenderer.setBaseStroke(new BasicStroke(0.75F));
/*  88:    */     
/*  89: 89 */     panel.setPopupMenu(buildMenu().getPopupMenu());
/*  90:    */     
/*  91: 91 */     fillActionMap(getActionMap());
/*  92: 92 */     fillInputMap(getInputMap());
/*  93:    */     
/*  94: 94 */     add(panel, "Center");
/*  95: 95 */     onColorSchemeChange();
/*  96:    */   }
/*  97:    */   
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */   public void setChartTitle(String title)
/* 102:    */   {
/* 103:103 */     panel.getChart().setTitle(title);
/* 104:    */   }
/* 105:    */   
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */   public void setTsData(TsData reference, List<TsData> revisions)
/* 111:    */   {
/* 112:112 */     this.reference = reference;
/* 113:113 */     revs = revisions;
/* 114:    */     
/* 115:115 */     TimeSeriesCollection ref = new TimeSeriesCollection();
/* 116:116 */     addSerie(ref, reference);
/* 117:    */     
/* 118:118 */     XYPlot plot = panel.getChart().getXYPlot();
/* 119:119 */     plot.setDataset(0, ref);
/* 120:120 */     plot.setRenderer(0, refRenderer);
/* 121:121 */     refRenderer.setSeriesPaint(0, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 122:122 */     refRenderer.setSeriesStroke(0, new BasicStroke(2.0F));
/* 123:    */     
/* 124:124 */     TimeSeriesCollection revCol = null;
/* 125:125 */     if ((revisions != null) && (!revisions.isEmpty())) {
/* 126:126 */       revCol = new TimeSeriesCollection();
/* 127:127 */       for (TsData t : revisions) {
/* 128:128 */         addSerie(revCol, t);
/* 129:    */       }
/* 130:    */       
/* 131:131 */       plot.setDataset(1, revCol);
/* 132:132 */       plot.setRenderer(1, seriesRenderer);
/* 133:133 */       for (int i = 0; i < revCol.getSeriesCount(); i++) {
/* 134:134 */         seriesRenderer.setSeriesPaint(i, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 135:135 */         seriesRenderer.setSeriesStroke(i, new BasicStroke(0.75F));
/* 136:    */       }
/* 137:    */     } else {
/* 138:138 */       plot.setDataset(1, Charts.emptyXYDataset());
/* 139:139 */       refRenderer.setSeriesPaint(0, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.ORANGE));
/* 140:    */     }
/* 141:    */     
/* 142:142 */     configureAxis(plot);
/* 143:    */     
/* 144:144 */     setRange(ref, revCol);
/* 145:    */   }
/* 146:    */   
/* 147:    */   private JMenu buildMenu() {
/* 148:148 */     am = new ActionMap();
/* 149:149 */     am.put("copy", new CopyAction());
/* 150:    */     
/* 151:151 */     im = new InputMap();
/* 152:152 */     KeyStrokes.putAll(im, KeyStrokes.COPY, "copy");
/* 153:    */     
/* 154:154 */     JMenu result = new JMenu();
/* 155:    */     
/* 156:    */ 
/* 157:    */ 
/* 158:158 */     JMenuItem item = new JMenuItem(am.get("copy"));
/* 159:159 */     item.setText("Copy All");
/* 160:160 */     item.setAccelerator((KeyStroke)KeyStrokes.COPY.get(0));
/* 161:161 */     ExtAction.hideWhenDisabled(item);
/* 162:162 */     result.add(item);
/* 163:    */     
/* 164:164 */     return result;
/* 165:    */   }
/* 166:    */   
/* 167:    */   private void configureAxis(XYPlot plot) {
/* 168:168 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-yyyy");
/* 169:169 */     DateAxis dateAxis = new DateAxis();
/* 170:170 */     dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 171:171 */     dateAxis.setDateFormatOverride(sdf);
/* 172:172 */     plot.setDomainAxis(dateAxis);
/* 173:173 */     NumberAxis yaxis = new NumberAxis();
/* 174:174 */     plot.setRangeAxis(yaxis);
/* 175:    */   }
/* 176:    */   
/* 177:    */   private void setRange(TimeSeriesCollection ref, TimeSeriesCollection series)
/* 178:    */   {
/* 179:179 */     Range c = ref.getRangeBounds(true);
/* 180:    */     
/* 181:181 */     double min = c.getLowerBound();
/* 182:182 */     double max = c.getUpperBound();
/* 183:    */     
/* 184:184 */     if ((series != null) && (series.getSeriesCount() != 0)) {
/* 185:185 */       Range s = series.getRangeBounds(true);
/* 186:186 */       if (min > s.getLowerBound()) {
/* 187:187 */         min = s.getLowerBound();
/* 188:    */       }
/* 189:    */       
/* 190:190 */       if (max < s.getUpperBound()) {
/* 191:191 */         max = s.getUpperBound();
/* 192:    */       }
/* 193:    */     }
/* 194:    */     
/* 195:195 */     min -= Math.abs(min) * 0.03D;
/* 196:196 */     max += Math.abs(max) * 0.03D;
/* 197:    */     
/* 198:198 */     panel.getChart().getXYPlot().getRangeAxis().setRange(new Range(min, max));
/* 199:    */   }
/* 200:    */   
/* 201:    */   private void addSerie(TimeSeriesCollection chartSeries, TsData data) {
/* 202:202 */     TimeSeries chartTs = new TimeSeries("");
/* 203:203 */     for (int i = 0; i < data.getDomain().getLength(); i++) {
/* 204:204 */       if (DescriptiveStatistics.isFinite(data.get(i))) {
/* 205:205 */         Day day = new Day(data.getDomain().get(i).middle());
/* 206:206 */         chartTs.addOrUpdate(day, data.get(i));
/* 207:    */       }
/* 208:    */     }
/* 209:209 */     chartSeries.addSeries(chartTs);
/* 210:    */   }
/* 211:    */   
/* 212:    */   protected Transferable transferableOnSelection() {
/* 213:213 */     TsCollection col = TsFactory.instance.createTsCollection();
/* 214:214 */     Ts ts = TsFactory.instance.createTs("Reference serie", null, reference);
/* 215:215 */     col.add(ts);
/* 216:216 */     if (revs != null) {
/* 217:217 */       for (int i = 0; i < revs.size(); i++) {
/* 218:218 */         ts = TsFactory.instance.createTs(
/* 219:219 */           "Rev->" + ts.getTsData().getLastPeriod().toString(), 
/* 220:220 */           null, 
/* 221:221 */           (TsData)revs.get(i));
/* 222:222 */         col.add(ts);
/* 223:    */       }
/* 224:    */     }
/* 225:225 */     return TssTransferSupport.getDefault().fromTsCollection(col);
/* 226:    */   }
/* 227:    */   
/* 228:    */ 
/* 229:    */ 
/* 230:    */   protected void onDataFormatChange() {}
/* 231:    */   
/* 232:    */ 
/* 233:    */   protected void onColorSchemeChange()
/* 234:    */   {
/* 235:235 */     refRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 236:236 */     seriesRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 237:    */     
/* 238:238 */     XYPlot mainPlot = panel.getChart().getXYPlot();
/* 239:239 */     for (int i = 0; i < mainPlot.getSeriesCount(); i++) {
/* 240:240 */       seriesRenderer.setSeriesPaint(i, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 241:    */     }
/* 242:    */     
/* 243:243 */     mainPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 244:244 */     mainPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 245:245 */     mainPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 246:246 */     panel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 247:    */   }
/* 248:    */   
/* 249:    */   private class CopyAction extends AbstractAction
/* 250:    */   {
/* 251:    */     public CopyAction() {
/* 252:252 */       super();
/* 253:    */     }
/* 254:    */     
/* 255:    */     public void actionPerformed(ActionEvent e)
/* 256:    */     {
/* 257:257 */       setClipboardContents(transferableOnSelection());
/* 258:    */     }
/* 259:    */   }
/* 260:    */ }
