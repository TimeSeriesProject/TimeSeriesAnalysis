/*  1:   */ package ec.ui.chart;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tstoolkit.utilities.IntList;
/*  5:   */ import ec.util.chart.SeriesFunction;
/*  6:   */ import ec.util.chart.swing.JTimeSeriesChart;
/*  7:   */ import javax.swing.JMenu;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class JTsDualChart
/* 14:   */   extends JTsChart
/* 15:   */ {
/* 16:   */   protected final IntList subTss_;
/* 17:   */   
/* 18:   */   public JTsDualChart()
/* 19:   */   {
/* 20:20 */     subTss_ = new IntList();
/* 21:21 */     chartPanel.setPopupMenu(buildChartMenu().getPopupMenu());
/* 22:   */     
/* 23:23 */     chartPanel.setPlotWeights(new int[] { 2, 1 });
/* 24:24 */     chartPanel.setPlotDispatcher(new SeriesFunction()
/* 25:   */     {
/* 26:   */       public Integer apply(int series) {
/* 27:27 */         return Integer.valueOf(isSubTs(series) ? 1 : 0);
/* 28:   */       }
/* 29:   */     });
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean isSubTs(int idx) {
/* 33:33 */     return subTss_.contains(idx);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean hasSubTs() {
/* 37:37 */     return subTss_.size() > 0;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setTsLevel(int idx, boolean isSubTs) {
/* 41:41 */     setTsLevel(idx, isSubTs, true);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void setTsLevel(int idx, boolean isSubTs, boolean redraw) {
/* 45:45 */     if (idx < 0) {
/* 46:46 */       return;
/* 47:   */     }
/* 48:48 */     if ((isSubTs) && (!subTss_.contains(idx))) {
/* 49:49 */       subTss_.add(idx);
/* 50:50 */     } else if ((!isSubTs) && (subTss_.contains(idx))) {
/* 51:51 */       subTss_.remove(idx);
/* 52:   */     }
/* 53:53 */     if (redraw) {
/* 54:54 */       onCollectionChange();
/* 55:   */     }
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void clearSubChart() {
/* 59:59 */     subTss_.clear();
/* 60:60 */     onCollectionChange();
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void reset() {
/* 64:64 */     subTss_.clear();
/* 65:65 */     collection.clear();
/* 66:   */   }
/* 67:   */ }
