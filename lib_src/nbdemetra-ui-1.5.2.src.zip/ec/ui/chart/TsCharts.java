/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import ec.tss.Ts;
/*   4:    */ import ec.tss.TsCollection;
/*   5:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   6:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*   7:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*   8:    */ import ec.util.chart.swing.HighlightedXYItemRenderer;
/*   9:    */ import ec.util.chart.swing.SwingColorSchemeSupport;
/*  10:    */ import java.awt.BasicStroke;
/*  11:    */ import java.awt.Color;
/*  12:    */ import java.awt.Font;
/*  13:    */ import java.awt.Paint;
/*  14:    */ import java.awt.Stroke;
/*  15:    */ import java.text.DateFormat;
/*  16:    */ import java.text.NumberFormat;
/*  17:    */ import org.jfree.chart.JFreeChart;
/*  18:    */ import org.jfree.chart.axis.DateAxis;
/*  19:    */ import org.jfree.chart.labels.StandardXYItemLabelGenerator;
/*  20:    */ import org.jfree.chart.labels.XYSeriesLabelGenerator;
/*  21:    */ import org.jfree.chart.plot.CombinedDomainXYPlot;
/*  22:    */ import org.jfree.chart.plot.XYPlot;
/*  23:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  24:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  25:    */ import org.jfree.chart.title.LegendTitle;
/*  26:    */ import org.jfree.data.xy.AbstractXYDataset;
/*  27:    */ import org.jfree.data.xy.XYDataset;
/*  28:    */ import org.jfree.ui.RectangleInsets;
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public final class TsCharts
/*  37:    */ {
/*  38: 38 */   public static final RectangleInsets CHART_PADDING = new RectangleInsets(5.0D, 5.0D, 5.0D, 5.0D);
/*  39: 39 */   public static final Color CHART_TICK_LABEL_COLOR = Color.GRAY;
/*  40: 40 */   public static final Font CHART_TITLE_FONT = new Font("SansSerif", 2, 13);
/*  41: 41 */   public static final Font NO_DATA_FONT = new Font("SansSerif", 3, 12);
/*  42: 42 */   public static final Paint NO_DATA_PAINT = Color.LIGHT_GRAY;
/*  43:    */   public static final int ALPHA = 50;
/*  44: 44 */   public static final Font ITEM_LABEL_FONT = LegendTitle.DEFAULT_ITEM_FONT;
/*  45: 45 */   private static final BasicStroke STROKE1 = new BasicStroke(1.0F);
/*  46: 46 */   private static final BasicStroke STROKE2 = new BasicStroke(2.0F);
/*  47: 47 */   private static final BasicStroke STROKE3 = new BasicStroke(3.0F);
/*  48:    */   
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */   public static Stroke getNormalStroke(ITsChart.LinesThickness thickness)
/*  53:    */   {
/*  54: 54 */     return thickness == ITsChart.LinesThickness.Thin ? STROKE1 : STROKE2;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static Stroke getStrongStroke(ITsChart.LinesThickness thickness) {
/*  58: 58 */     return thickness == ITsChart.LinesThickness.Thin ? STROKE2 : STROKE3;
/*  59:    */   }
/*  60:    */   
/*  61:    */   @Deprecated
/*  62:    */   public static StandardXYItemLabelGenerator getXYItemLabelGenerator(DataFormat dataFormat) {
/*  63: 63 */     DateFormat dateFormat = dataFormat.newDateFormat();
/*  64: 64 */     NumberFormat numberFormat = dataFormat.newNumberFormat();
/*  65: 65 */     return new StandardXYItemLabelGenerator("{1}: {2}", dateFormat, numberFormat);
/*  66:    */   }
/*  67:    */   
/*  68:    */   @Deprecated
/*  69:    */   public static XYSeriesLabelGenerator getXYSeriesLabelGenerator(TsCollection col) {
/*  70: 70 */     new XYSeriesLabelGenerator()
/*  71:    */     {
/*  72:    */       public String generateLabel(XYDataset dataset, int series) {
/*  73: 73 */         return get(series).getName();
/*  74:    */       }
/*  75:    */     };
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static XYDataset newSparklineDataset(TsData data) {
/*  79: 79 */     return new TsDataAsXYDataset(data);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static class TsDataAsXYDataset extends AbstractXYDataset
/*  83:    */   {
/*  84:    */     final TsData data;
/*  85:    */     
/*  86:    */     public TsDataAsXYDataset(TsData data) {
/*  87: 87 */       this.data = data;
/*  88:    */     }
/*  89:    */     
/*  90:    */     public int getSeriesCount()
/*  91:    */     {
/*  92: 92 */       return 1;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public Comparable getSeriesKey(int i)
/*  96:    */     {
/*  97: 97 */       return "";
/*  98:    */     }
/*  99:    */     
/* 100:    */     public int getItemCount(int i)
/* 101:    */     {
/* 102:102 */       return data.getLength();
/* 103:    */     }
/* 104:    */     
/* 105:    */     public Number getX(int i, int i1)
/* 106:    */     {
/* 107:107 */       return Integer.valueOf(i1);
/* 108:    */     }
/* 109:    */     
/* 110:    */     public Number getY(int i, int i1)
/* 111:    */     {
/* 112:112 */       return Double.valueOf(data.get(i1));
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   @Deprecated
/* 117:    */   public static void setDataFormat(XYPlot plot, DataFormat dataFormat) {
/* 118:118 */     StandardXYItemLabelGenerator itemLabelGenerator = getXYItemLabelGenerator(dataFormat);
/* 119:119 */     plot.getRenderer().setBaseItemLabelGenerator(itemLabelGenerator);
/* 120:120 */     ((DateAxis)plot.getDomainAxis()).setDateFormatOverride(itemLabelGenerator.getXDateFormat());
/* 121:    */   }
/* 122:    */   
/* 123:    */   @Deprecated
/* 124:    */   public static void render(JFreeChart chart, SwingColorSchemeSupport support, ITsChart.LinesThickness linesThickness, RenderingStrategy strategy) {
/* 125:125 */     chart.setBackgroundPaint((Paint)support.getBackColor());
/* 126:126 */     if ((chart.getPlot() instanceof CombinedDomainXYPlot)) {
/* 127:127 */       for (XYPlot o : ((CombinedDomainXYPlot)chart.getPlot()).getSubplots()) {
/* 128:128 */         render(o, support, linesThickness, strategy);
/* 129:    */       }
/* 130:130 */     } else if ((chart.getPlot() instanceof XYPlot)) {
/* 131:131 */       render((XYPlot)chart.getPlot(), support, linesThickness, strategy);
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   @Deprecated
/* 136:    */   public static void render(XYPlot plot, SwingColorSchemeSupport support, ITsChart.LinesThickness linesThickness, RenderingStrategy strategy) {
/* 137:137 */     plot.setBackgroundPaint((Paint)support.getPlotColor());
/* 138:138 */     plot.setDomainGridlinePaint((Paint)support.getGridColor());
/* 139:139 */     plot.setRangeGridlinePaint((Paint)support.getGridColor());
/* 140:    */     
/* 141:141 */     int mainSize = plot.getDataset().getSeriesCount();
/* 142:    */     
/* 143:143 */     XYItemRenderer renderer = plot.getRenderer();
/* 144:144 */     for (int i = 0; i < mainSize; i++) {
/* 145:145 */       Paint paint = strategy.getColor(i, support);
/* 146:146 */       Stroke stroke = strategy.getStroke(i, linesThickness);
/* 147:147 */       boolean visibleInLegend = strategy.isVisibleInLegend(i);
/* 148:148 */       renderer.setSeriesPaint(i, paint);
/* 149:149 */       renderer.setSeriesStroke(i, stroke);
/* 150:150 */       renderer.setSeriesOutlineStroke(i, stroke);
/* 151:151 */       renderer.setSeriesVisibleInLegend(i, Boolean.valueOf(visibleInLegend));
/* 152:152 */       if ((renderer instanceof HighlightedXYItemRenderer)) {
/* 153:153 */         renderer.setSeriesItemLabelPaint(i, (Paint)support.getPlotColor());
/* 154:154 */         HighlightedXYItemRenderer hr = (HighlightedXYItemRenderer)renderer;
/* 155:155 */         hr.setSeriesItemLabelBackgroundPaint(i, paint);
/* 156:    */       }
/* 157:    */       else
/* 158:    */       {
/* 159:159 */         renderer.setSeriesItemLabelPaint(i, paint);
/* 160:    */       }
/* 161:    */     }
/* 162:162 */     if ((renderer instanceof XYLineAndShapeRenderer)) {
/* 163:163 */       ((XYLineAndShapeRenderer)renderer).setBaseFillPaint((Paint)support.getPlotColor());
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */   @Deprecated
/* 177:    */   public static class DefaultRenderingStrategy
/* 178:    */     implements TsCharts.RenderingStrategy
/* 179:    */   {
/* 180:    */     public Color getColor(int index, SwingColorSchemeSupport support)
/* 181:    */     {
/* 182:182 */       return (Color)support.getLineColor(index);
/* 183:    */     }
/* 184:    */     
/* 185:    */     public Stroke getStroke(int index, ITsChart.LinesThickness linesThickness)
/* 186:    */     {
/* 187:187 */       return TsCharts.getNormalStroke(linesThickness);
/* 188:    */     }
/* 189:    */     
/* 190:    */     public boolean isVisibleInLegend(int index)
/* 191:    */     {
/* 192:192 */       return true;
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   @Deprecated
/* 197:    */   public static abstract class SelectionRenderingStrategy implements TsCharts.RenderingStrategy
/* 198:    */   {
/* 199:    */     abstract boolean isSelected(int paramInt);
/* 200:    */     
/* 201:    */     public Color getColor(int index, SwingColorSchemeSupport support)
/* 202:    */     {
/* 203:203 */       Color color = (Color)support.getLineColor(index);
/* 204:204 */       return isSelected(index) ? color : SwingColorSchemeSupport.withAlpha(color, 50);
/* 205:    */     }
/* 206:    */     
/* 207:    */     public Stroke getStroke(int index, ITsChart.LinesThickness linesThickness)
/* 208:    */     {
/* 209:209 */       return isSelected(index) ? TsCharts.getStrongStroke(linesThickness) : TsCharts.getNormalStroke(linesThickness);
/* 210:    */     }
/* 211:    */     
/* 212:    */     public boolean isVisibleInLegend(int index)
/* 213:    */     {
/* 214:214 */       return true;
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   @Deprecated
/* 219:    */   public static abstract class DndRenderingStrategy implements TsCharts.RenderingStrategy
/* 220:    */   {
/* 221:    */     abstract boolean isDnd(int paramInt);
/* 222:    */     
/* 223:    */     public Color getColor(int index, SwingColorSchemeSupport support)
/* 224:    */     {
/* 225:225 */       Color color = (Color)support.getLineColor(index);
/* 226:226 */       return isDnd(index) ? color : SwingColorSchemeSupport.withAlpha(color, 50);
/* 227:    */     }
/* 228:    */     
/* 229:    */     public Stroke getStroke(int index, ITsChart.LinesThickness linesThickness)
/* 230:    */     {
/* 231:231 */       return isDnd(index) ? TsCharts.getStrongStroke(linesThickness) : TsCharts.getNormalStroke(linesThickness);
/* 232:    */     }
/* 233:    */     
/* 234:    */     public boolean isVisibleInLegend(int index)
/* 235:    */     {
/* 236:236 */       return !isDnd(index);
/* 237:    */     }
/* 238:    */   }
/* 239:    */   
/* 240:    */   @Deprecated
/* 241:    */   public static abstract interface RenderingStrategy
/* 242:    */   {
/* 243:    */     public abstract Color getColor(int paramInt, SwingColorSchemeSupport paramSwingColorSchemeSupport);
/* 244:    */     
/* 245:    */     public abstract Stroke getStroke(int paramInt, ITsChart.LinesThickness paramLinesThickness);
/* 246:    */     
/* 247:    */     public abstract boolean isVisibleInLegend(int paramInt);
/* 248:    */   }
/* 249:    */ }
