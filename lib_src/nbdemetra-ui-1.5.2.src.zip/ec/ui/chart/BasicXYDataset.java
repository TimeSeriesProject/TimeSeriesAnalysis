/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jfree.data.general.Series;
/*   6:    */ import org.jfree.data.xy.AbstractXYDataset;
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ public class BasicXYDataset
/*  14:    */   extends AbstractXYDataset
/*  15:    */ {
/*  16:    */   final List<Series> data;
/*  17:    */   
/*  18:    */   public BasicXYDataset()
/*  19:    */   {
/*  20: 20 */     this(new ArrayList());
/*  21:    */   }
/*  22:    */   
/*  23:    */   public BasicXYDataset(List<Series> data) {
/*  24: 24 */     this.data = data;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public boolean addSeries(Series series) {
/*  28: 28 */     if (data.add(series)) {
/*  29: 29 */       fireDatasetChanged();
/*  30: 30 */       return true;
/*  31:    */     }
/*  32: 32 */     return false;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void clear() {
/*  36: 36 */     data.clear();
/*  37: 37 */     fireDatasetChanged();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public int getSeriesCount()
/*  41:    */   {
/*  42: 42 */     return data.size();
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Comparable getSeriesKey(int series)
/*  46:    */   {
/*  47: 47 */     return ((Series)data.get(series)).getKey();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public int getItemCount(int series)
/*  51:    */   {
/*  52: 52 */     return ((Series)data.get(series)).getItemCount();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public double getXValue(int series, int item)
/*  56:    */   {
/*  57: 57 */     return ((Series)data.get(series)).getXValue(item);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Number getX(int series, int item)
/*  61:    */   {
/*  62: 62 */     return Double.valueOf(getXValue(series, item));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public double getYValue(int series, int item)
/*  66:    */   {
/*  67: 67 */     return ((Series)data.get(series)).getYValue(item);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Number getY(int series, int item)
/*  71:    */   {
/*  72: 72 */     return Double.valueOf(getYValue(series, item));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static abstract class Series extends Series
/*  76:    */   {
/*  77:    */     public static Series empty(Comparable key) {
/*  78: 78 */       new Series(key)
/*  79:    */       {
/*  80:    */         public double getXValue(int item) {
/*  81: 81 */           throw new UnsupportedOperationException("Not supported yet.");
/*  82:    */         }
/*  83:    */         
/*  84:    */         public double getYValue(int item)
/*  85:    */         {
/*  86: 86 */           throw new UnsupportedOperationException("Not supported yet.");
/*  87:    */         }
/*  88:    */         
/*  89:    */         public int getItemCount()
/*  90:    */         {
/*  91: 91 */           return 0;
/*  92:    */         }
/*  93:    */       };
/*  94:    */     }
/*  95:    */     
/*  96:    */     public static Series of(Comparable key, final double[] xValues, final double[] yValues) {
/*  97: 97 */       new Series(key)
/*  98:    */       {
/*  99:    */         public double getXValue(int item) {
/* 100:100 */           return xValues[item];
/* 101:    */         }
/* 102:    */         
/* 103:    */         public double getYValue(int item)
/* 104:    */         {
/* 105:105 */           return yValues[item];
/* 106:    */         }
/* 107:    */         
/* 108:    */         public int getItemCount()
/* 109:    */         {
/* 110:110 */           return xValues.length;
/* 111:    */         }
/* 112:    */       };
/* 113:    */     }
/* 114:    */     
/* 115:    */     public Series(Comparable key) {
/* 116:116 */       super();
/* 117:    */     }
/* 118:    */     
/* 119:    */     public abstract double getXValue(int paramInt);
/* 120:    */     
/* 121:    */     public abstract double getYValue(int paramInt);
/* 122:    */   }
/* 123:    */ }
