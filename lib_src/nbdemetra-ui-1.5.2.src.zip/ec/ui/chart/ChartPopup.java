/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*   4:    */ import java.awt.BorderLayout;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Frame;
/*   7:    */ import java.awt.Point;
/*   8:    */ import java.awt.Toolkit;
/*   9:    */ import java.awt.Window.Type;
/*  10:    */ import java.awt.event.WindowEvent;
/*  11:    */ import java.awt.event.WindowFocusListener;
/*  12:    */ import java.util.List;
/*  13:    */ import javax.swing.JDialog;
/*  14:    */ import org.jfree.chart.JFreeChart;
/*  15:    */ import org.jfree.chart.plot.XYPlot;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ public class ChartPopup
/*  35:    */   extends JDialog
/*  36:    */ {
/*  37:    */   private RevisionChartPanel panel;
/*  38:    */   
/*  39:    */   public ChartPopup(Frame owner, boolean modal)
/*  40:    */   {
/*  41: 41 */     super(owner, modal);
/*  42: 42 */     setLayout(new BorderLayout());
/*  43:    */     
/*  44: 44 */     setType(Window.Type.UTILITY);
/*  45: 45 */     setDefaultCloseOperation(2);
/*  46:    */     
/*  47: 47 */     addWindowFocusListener(new WindowFocusListener()
/*  48:    */     {
/*  49:    */       public void windowLostFocus(WindowEvent evt) {
/*  50: 50 */         dispose();
/*  51:    */       }
/*  52:    */       
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */       public void windowGainedFocus(WindowEvent e) {}
/*  57: 57 */     });
/*  58: 58 */     panel = new RevisionChartPanel(createChart());
/*  59:    */     
/*  60: 60 */     add(panel, "Center");
/*  61: 61 */     setPreferredSize(new Dimension(350, 200));
/*  62: 62 */     setSize(new Dimension(350, 200));
/*  63:    */   }
/*  64:    */   
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */   public void setLocation(Point p)
/*  73:    */   {
/*  74: 74 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/*  75: 75 */     int x = x;
/*  76: 76 */     int y = y;
/*  77:    */     
/*  78: 78 */     if (x + getWidth() > width) {
/*  79: 79 */       x = width - getWidth();
/*  80:    */     }
/*  81:    */     
/*  82: 82 */     if (y + getHeight() > height) {
/*  83: 83 */       y = height - getHeight();
/*  84:    */     }
/*  85:    */     
/*  86: 86 */     super.setLocation(x, y);
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   public void setChartTitle(String title)
/*  93:    */   {
/*  94: 94 */     panel.setChartTitle(title);
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */   public void setTsData(TsData reference, List<TsData> series)
/* 102:    */   {
/* 103:103 */     panel.setTsData(reference, series);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private JFreeChart createChart() {
/* 107:107 */     XYPlot plot = new XYPlot();
/* 108:108 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, false);
/* 109:109 */     return result;
/* 110:    */   }
/* 111:    */ }
