/*  1:   */ package ec.ui.chart;
/*  2:   */ 
/*  3:   */ import ec.ui.interfaces.ITsPrinter;
/*  4:   */ import org.jfree.chart.ChartPanel;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ @Deprecated
/* 13:   */ public class ChartTsPrinter
/* 14:   */   implements ITsPrinter
/* 15:   */ {
/* 16:   */   final ChartPanel chartPanel;
/* 17:   */   
/* 18:   */   public ChartTsPrinter(ChartPanel chartPanel)
/* 19:   */   {
/* 20:20 */     this.chartPanel = chartPanel;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean printPreview()
/* 24:   */   {
/* 25:25 */     chartPanel.createChartPrintJob();
/* 26:26 */     return true;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean print()
/* 30:   */   {
/* 31:31 */     return printPreview();
/* 32:   */   }
/* 33:   */ }
