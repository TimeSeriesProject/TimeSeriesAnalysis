/*  1:   */ package ec.ui.chart;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Lists;
/*  4:   */ import ec.tss.Ts;
/*  5:   */ import ec.tss.Ts.DataFeature;
/*  6:   */ import ec.tstoolkit.design.Status;
/*  7:   */ import ec.tstoolkit.design.Status.Level;
/*  8:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  9:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/* 10:   */ import java.util.Arrays;
/* 11:   */ import java.util.EnumSet;
/* 12:   */ import java.util.List;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ @Status(level=Status.Level.Initial)
/* 22:   */ public class DataFeatureModel
/* 23:   */ {
/* 24:24 */   private final Ts.DataFeature[] features = Ts.DataFeature.values();
/* 25:25 */   private boolean[][][] internalData = new boolean[0][][];
/* 26:   */   
/* 27:   */   public void setData(Ts[] tss) {
/* 28:28 */     internalData = new boolean[features.length][tss.length][];
/* 29:29 */     for (int f = 0; f < features.length; f++) {
/* 30:30 */       Ts.DataFeature feature = features[f];
/* 31:31 */       for (int series = 0; series < tss.length; series++) {
/* 32:32 */         Ts ts = tss[series];
/* 33:33 */         TsData data = ts.getTsData();
/* 34:34 */         if ((data != null) && (ts.isFeature(feature))) {
/* 35:35 */           internalData[f][series] = new boolean[data.getLength()];
/* 36:36 */           TsDomain mainDomain = data.getDomain();
/* 37:37 */           TsDomain subDomain = data.select(ts.getSelector(feature)).getDomain();
/* 38:38 */           if (!subDomain.isEmpty()) {
/* 39:39 */             int first = mainDomain.search(subDomain.getStart());
/* 40:40 */             int end = first + subDomain.getLength();
/* 41:   */             
/* 42:42 */             Arrays.fill(internalData[f][series], first, end, true);
/* 43:   */           }
/* 44:   */         }
/* 45:   */       }
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */   public boolean hasFeature(Ts.DataFeature feature, int series, int obs) {
/* 50:50 */     if (internalData.length <= feature.ordinal()) {
/* 51:51 */       return false;
/* 52:   */     }
/* 53:53 */     boolean[][] tmp = internalData[feature.ordinal()];
/* 54:54 */     if ((tmp == null) || (tmp.length <= series)) {
/* 55:55 */       return false;
/* 56:   */     }
/* 57:57 */     boolean[] cbool = tmp[series];
/* 58:58 */     if ((cbool == null) || (cbool.length <= obs)) {
/* 59:59 */       return false;
/* 60:   */     }
/* 61:61 */     return cbool[obs];
/* 62:   */   }
/* 63:   */   
/* 64:   */   public EnumSet<Ts.DataFeature> getFeatures(int series, int obs) {
/* 65:65 */     List<Ts.DataFeature> result = Lists.newArrayListWithCapacity(features.length);
/* 66:66 */     for (int f = 0; f < features.length; f++) {
/* 67:67 */       if ((internalData[f][series] != null) && (internalData[f][series][obs] != 0)) {
/* 68:68 */         result.add(features[f]);
/* 69:   */       }
/* 70:   */     }
/* 71:71 */     return EnumSet.copyOf(result);
/* 72:   */   }
/* 73:   */ }
