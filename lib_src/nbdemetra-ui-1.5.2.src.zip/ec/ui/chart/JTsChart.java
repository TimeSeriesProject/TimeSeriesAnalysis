/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Converter;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Predicate;
/*   6:    */ import com.google.common.base.Predicates;
/*   7:    */ import com.google.common.base.Strings;
/*   8:    */ import com.google.common.collect.Iterables;
/*   9:    */ import ec.nbdemetra.ui.BeanHandler;
/*  10:    */ import ec.nbdemetra.ui.Config;
/*  11:    */ import ec.nbdemetra.ui.Config.Builder;
/*  12:    */ import ec.nbdemetra.ui.Configurator;
/*  13:    */ import ec.nbdemetra.ui.DemetraUI;
/*  14:    */ import ec.nbdemetra.ui.IConfigurable;
/*  15:    */ import ec.nbdemetra.ui.ThemeSupport;
/*  16:    */ import ec.nbdemetra.ui.properties.IBeanEditor;
/*  17:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  18:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.AutoCompletedStep;
/*  19:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.BooleanStep;
/*  20:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  21:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.EnumStep;
/*  22:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  23:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  24:    */ import ec.nbdemetra.ui.properties.OpenIdePropertySheetBeanEditor;
/*  25:    */ import ec.tss.Ts;
/*  26:    */ import ec.tss.Ts.DataFeature;
/*  27:    */ import ec.tss.TsCollection;
/*  28:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  29:    */ import ec.tss.tsproviders.utils.DataFormat;
/*  30:    */ import ec.tss.tsproviders.utils.IParam;
/*  31:    */ import ec.tss.tsproviders.utils.Params;
/*  32:    */ import ec.tstoolkit.utilities.Arrays2;
/*  33:    */ import ec.tstoolkit.utilities.IntList;
/*  34:    */ import ec.ui.ATsChart;
/*  35:    */ import ec.ui.ATsCollectionView.TsCollectionSelectionListener;
/*  36:    */ import ec.ui.ATsCollectionView.TsCollectionTransferHandler;
/*  37:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*  38:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  39:    */ import ec.ui.interfaces.ITsPrinter;
/*  40:    */ import ec.util.chart.ColorScheme;
/*  41:    */ import ec.util.chart.ObsFunction;
/*  42:    */ import ec.util.chart.ObsPredicate;
/*  43:    */ import ec.util.chart.SeriesFunction;
/*  44:    */ import ec.util.chart.SeriesPredicate;
/*  45:    */ import ec.util.chart.TimeSeriesChart.Element;
/*  46:    */ import ec.util.chart.swing.Charts;
/*  47:    */ import ec.util.chart.swing.JTimeSeriesChart;
/*  48:    */ import ec.util.chart.swing.JTimeSeriesChartCommand;
/*  49:    */ import ec.util.various.swing.FontAwesome;
/*  50:    */ import java.awt.BorderLayout;
/*  51:    */ import java.awt.Dimension;
/*  52:    */ import java.awt.dnd.DropTargetAdapter;
/*  53:    */ import java.awt.dnd.DropTargetDragEvent;
/*  54:    */ import java.awt.dnd.DropTargetDropEvent;
/*  55:    */ import java.awt.dnd.DropTargetEvent;
/*  56:    */ import java.awt.event.MouseAdapter;
/*  57:    */ import java.awt.event.MouseEvent;
/*  58:    */ import java.beans.Beans;
/*  59:    */ import java.text.DateFormat;
/*  60:    */ import java.util.Date;
/*  61:    */ import java.util.TooManyListenersException;
/*  62:    */ import javax.swing.Action;
/*  63:    */ import javax.swing.ActionMap;
/*  64:    */ import javax.swing.JMenu;
/*  65:    */ import javax.swing.JMenuItem;
/*  66:    */ import javax.swing.ListSelectionModel;
/*  67:    */ import org.jfree.data.xy.IntervalXYDataset;
/*  68:    */ import org.openide.nodes.Sheet;
/*  69:    */ 
/*  70:    */ public class JTsChart extends ATsChart implements IConfigurable
/*  71:    */ {
/*  72:    */   private static final long serialVersionUID = -4816158139844033936L;
/*  73: 73 */   private static final Configurator<JTsChart> CONFIGURATOR = ;
/*  74:    */   protected final JTimeSeriesChart chartPanel;
/*  75:    */   protected final ITsPrinter printer;
/*  76:    */   protected final DataFeatureModel dataFeatureModel;
/*  77:    */   private final ATsCollectionView.TsCollectionSelectionListener selectionListener;
/*  78:    */   private final IntList savedSelection;
/*  79:    */   
/*  80:    */   public JTsChart()
/*  81:    */   {
/*  82: 82 */     setLayout(new BorderLayout());
/*  83:    */     
/*  84: 84 */     chartPanel = new JTimeSeriesChart();
/*  85:    */     
/*  86: 86 */     chartPanel.setTransferHandler(new ATsCollectionView.TsCollectionTransferHandler(this));
/*  87:    */     try {
/*  88: 88 */       chartPanel.getDropTarget().addDropTargetListener(new DropTargetAdapter()
/*  89:    */       {
/*  90:    */         public void dragEnter(DropTargetDragEvent dtde) {
/*  91: 91 */           if ((!getTsUpdateMode().isReadOnly()) && (TssTransferSupport.getDefault().canImport(dtde.getCurrentDataFlavors()))) {
/*  92: 92 */             TsCollection col = TssTransferSupport.getDefault().toTsCollection(dtde.getTransferable());
/*  93: 93 */             setDropContent(col != null ? col.toArray() : null);
/*  94:    */           }
/*  95:    */         }
/*  96:    */         
/*  97:    */         public void dragExit(DropTargetEvent dte)
/*  98:    */         {
/*  99: 99 */           setDropContent(null);
/* 100:    */         }
/* 101:    */         
/* 102:    */         public void drop(DropTargetDropEvent dtde)
/* 103:    */         {
/* 104:104 */           dragExit(dtde);
/* 105:    */         }
/* 106:    */       });
/* 107:    */     } catch (TooManyListenersException ex) {
/* 108:108 */       org.openide.util.Exceptions.printStackTrace(ex);
/* 109:    */     }
/* 110:    */     
/* 111:111 */     printer = new ITsPrinter()
/* 112:    */     {
/* 113:    */       public boolean printPreview() {
/* 114:114 */         chartPanel.printImage();
/* 115:115 */         return true;
/* 116:    */       }
/* 117:    */       
/* 118:    */       public boolean print()
/* 119:    */       {
/* 120:120 */         return printPreview();
/* 121:    */       }
/* 122:122 */     };
/* 123:123 */     dataFeatureModel = new DataFeatureModel();
/* 124:124 */     selectionListener = new ATsCollectionView.TsCollectionSelectionListener(this);
/* 125:125 */     savedSelection = new IntList();
/* 126:    */     
/* 127:127 */     chartPanel.getSeriesSelectionModel().addListSelectionListener(selectionListener);
/* 128:    */     
/* 129:129 */     add(chartPanel, "Center");
/* 130:    */     
/* 131:131 */     chartPanel.addMouseListener(new MouseAdapter()
/* 132:    */     {
/* 133:    */       public void mousePressed(MouseEvent e) {
/* 134:134 */         if ((Charts.isPopup(e)) || (!Charts.isDoubleClick(e))) {
/* 135:135 */           return;
/* 136:    */         }
/* 137:137 */         Action a = getActionMap().get("open");
/* 138:138 */         if (a.isEnabled()) {
/* 139:139 */           a.actionPerformed(null);
/* 140:    */         }
/* 141:    */         
/* 142:    */       }
/* 143:143 */     });
/* 144:144 */     onAxisVisibleChange();
/* 145:145 */     onColorSchemeChange();
/* 146:146 */     onLegendVisibleChange();
/* 147:147 */     onTitleChange();
/* 148:148 */     onUpdateModeChange();
/* 149:149 */     onDataFormatChange();
/* 150:    */     
/* 151:151 */     chartPanel.setPopupMenu(buildChartMenu().getPopupMenu());
/* 152:    */     
/* 153:153 */     fillActionMap(chartPanel.getActionMap());
/* 154:154 */     fillInputMap(chartPanel.getInputMap());
/* 155:    */     
/* 156:156 */     chartPanel.setSeriesFormatter(new SeriesFunction()
/* 157:    */     {
/* 158:    */       public String apply(int series) {
/* 159:159 */         return collection.getCount() > series ? collection.get(series).getName() : chartPanel.getDataset().getSeriesKey(series).toString();
/* 160:    */       }
/* 161:161 */     });
/* 162:162 */     chartPanel.setObsFormatter(new ObsFunction()
/* 163:    */     {
/* 164:    */       public String apply(int series, int obs) {
/* 165:165 */         IntervalXYDataset dataset = chartPanel.getDataset();
/* 166:166 */         CharSequence period = chartPanel.getPeriodFormat().format(new Date(dataset.getX(series, obs).longValue()));
/* 167:167 */         CharSequence value = chartPanel.getValueFormat().format(dataset.getY(series, obs));
/* 168:168 */         StringBuilder result = new StringBuilder();
/* 169:169 */         result.append(period).append(": ").append(value);
/* 170:170 */         if (dataFeatureModel.hasFeature(Ts.DataFeature.Forecasts, series, obs)) {
/* 171:171 */           result.append("\nForecast");
/* 172:    */         }
/* 173:173 */         return result.toString();
/* 174:    */       }
/* 175:175 */     });
/* 176:176 */     chartPanel.setDashPredicate(new ObsPredicate()
/* 177:    */     {
/* 178:    */       public boolean apply(int series, int obs) {
/* 179:179 */         return dataFeatureModel.hasFeature(Ts.DataFeature.Forecasts, series, obs);
/* 180:    */       }
/* 181:181 */     });
/* 182:182 */     chartPanel.setLegendVisibilityPredicate(new SeriesPredicate()
/* 183:    */     {
/* 184:    */       public boolean apply(int series) {
/* 185:185 */         return series < collection.getCount();
/* 186:    */       }
/* 187:    */     });
/* 188:    */     
/* 189:189 */     if (Beans.isDesignTime()) {
/* 190:190 */       setTsCollection(ec.ui.DemoUtils.randomTsCollection(3));
/* 191:191 */       setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 192:192 */       setPreferredSize(new Dimension(200, 150));
/* 193:193 */       setTitle("Chart preview");
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */ 
/* 198:    */   protected void onDataFormatChange()
/* 199:    */   {
/* 200:200 */     DataFormat df = themeSupport.getDataFormat();
/* 201:    */     try {
/* 202:202 */       chartPanel.setPeriodFormat(df.newDateFormat());
/* 203:    */     }
/* 204:    */     catch (IllegalArgumentException localIllegalArgumentException) {}
/* 205:    */     try
/* 206:    */     {
/* 207:207 */       chartPanel.setValueFormat(df.newNumberFormat());
/* 208:    */     }
/* 209:    */     catch (IllegalArgumentException localIllegalArgumentException1) {}
/* 210:    */   }
/* 211:    */   
/* 212:    */ 
/* 213:    */   protected void onColorSchemeChange()
/* 214:    */   {
/* 215:215 */     chartPanel.setColorSchemeSupport(null);
/* 216:216 */     chartPanel.setColorSchemeSupport(themeSupport);
/* 217:    */   }
/* 218:    */   
/* 219:    */   protected void onCollectionChange()
/* 220:    */   {
/* 221:221 */     selectionListener.setEnabled(false);
/* 222:222 */     Ts[] tss = collection.toArray();
/* 223:223 */     dataFeatureModel.setData(tss);
/* 224:224 */     chartPanel.setDataset(TsXYDatasets.from(tss));
/* 225:225 */     updateNoDataMessage();
/* 226:226 */     selectionListener.setEnabled(true);
/* 227:    */   }
/* 228:    */   
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */   protected void onSelectionChange()
/* 234:    */   {
/* 235:235 */     selectionListener.setEnabled(false);
/* 236:236 */     selectionListener.changeSelection(chartPanel.getSeriesSelectionModel());
/* 237:237 */     selectionListener.setEnabled(true);
/* 238:    */   }
/* 239:    */   
/* 240:    */   protected void onUpdateModeChange()
/* 241:    */   {
/* 242:242 */     updateNoDataMessage();
/* 243:    */   }
/* 244:    */   
/* 245:    */ 
/* 246:    */ 
/* 247:    */   protected void onTsActionChange() {}
/* 248:    */   
/* 249:    */ 
/* 250:    */   protected void onDropContentChange()
/* 251:    */   {
/* 252:252 */     Ts[] tss = (Ts[])Arrays2.concat(collection.toArray(), dropContent);
/* 253:253 */     dataFeatureModel.setData(tss);
/* 254:254 */     chartPanel.setDataset(TsXYDatasets.from(tss));
/* 255:    */     
/* 256:256 */     selectionListener.setEnabled(false);
/* 257:257 */     ListSelectionModel m = chartPanel.getSeriesSelectionModel();
/* 258:258 */     if (dropContent.length > 0) {
/* 259:259 */       savedSelection.clear();
/* 260:260 */       for (int series = m.getMinSelectionIndex(); series <= m.getMaxSelectionIndex(); series++) {
/* 261:261 */         if (m.isSelectedIndex(series)) {
/* 262:262 */           savedSelection.add(series);
/* 263:    */         }
/* 264:    */       }
/* 265:265 */       int offset = collection.getCount();
/* 266:266 */       m.setSelectionInterval(offset, offset + dropContent.length);
/* 267:    */     } else {
/* 268:268 */       m.clearSelection();
/* 269:269 */       for (int series : savedSelection.toArray()) {
/* 270:270 */         m.addSelectionInterval(series, series);
/* 271:    */       }
/* 272:    */     }
/* 273:273 */     selectionListener.setEnabled(true);
/* 274:    */   }
/* 275:    */   
/* 276:    */   protected void onLegendVisibleChange()
/* 277:    */   {
/* 278:278 */     chartPanel.setElementVisible(TimeSeriesChart.Element.LEGEND, legendVisible);
/* 279:    */   }
/* 280:    */   
/* 281:    */   protected void onTitleVisibleChange()
/* 282:    */   {
/* 283:283 */     chartPanel.setElementVisible(TimeSeriesChart.Element.TITLE, titleVisible);
/* 284:    */   }
/* 285:    */   
/* 286:    */   protected void onAxisVisibleChange()
/* 287:    */   {
/* 288:288 */     chartPanel.setElementVisible(TimeSeriesChart.Element.AXIS, axisVisible);
/* 289:    */   }
/* 290:    */   
/* 291:    */   protected void onTitleChange()
/* 292:    */   {
/* 293:293 */     chartPanel.setTitle(title);
/* 294:    */   }
/* 295:    */   
/* 296:    */   protected void onLinesThicknessChange()
/* 297:    */   {
/* 298:298 */     chartPanel.setLineThickness(linesThickness == ITsChart.LinesThickness.Thin ? 1.0F : 2.0F);
/* 299:    */   }
/* 300:    */   
/* 301:    */   private void updateNoDataMessage()
/* 302:    */   {
/* 303:303 */     if (getTsUpdateMode().isReadOnly())
/* 304:304 */       switch (collection.getCount()) {
/* 305:    */       case 0: 
/* 306:306 */         chartPanel.setNoDataMessage("No data");
/* 307:307 */         break;
/* 308:    */       case 1: 
/* 309:309 */         String cause = collection.get(0).getInvalidDataCause();
/* 310:310 */         chartPanel.setNoDataMessage("Invalid data: " + Strings.nullToEmpty(cause));
/* 311:311 */         break;
/* 312:    */       default: 
/* 313:313 */         chartPanel.setNoDataMessage("Invalid data");
/* 314:    */         
/* 315:    */ 
/* 316:316 */         break; } else {
/* 317:317 */       chartPanel.setNoDataMessage("Drop data here");
/* 318:    */     }
/* 319:    */   }
/* 320:    */   
/* 321:    */   protected JMenu buildExportImageMenu()
/* 322:    */   {
/* 323:323 */     JMenu result = super.buildExportImageMenu();
/* 324:324 */     JMenuItem clipboard = result.add(JTimeSeriesChartCommand.copyImage().toAction(chartPanel));
/* 325:325 */     clipboard.setText("Clipboard");
/* 326:326 */     clipboard.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_CLIPBOARD));
/* 327:327 */     JMenuItem file = result.add(JTimeSeriesChartCommand.saveImage().toAction(chartPanel));
/* 328:328 */     file.setText("File...");
/* 329:329 */     file.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_PICTURE_O));
/* 330:330 */     return result;
/* 331:    */   }
/* 332:    */   
/* 333:    */   public void showAll()
/* 334:    */   {
/* 335:335 */     chartPanel.resetZoom();
/* 336:    */   }
/* 337:    */   
/* 338:    */   public ITsPrinter getPrinter()
/* 339:    */   {
/* 340:340 */     return printer;
/* 341:    */   }
/* 342:    */   
/* 343:    */   public Config getConfig()
/* 344:    */   {
/* 345:345 */     return CONFIGURATOR.getConfig(this);
/* 346:    */   }
/* 347:    */   
/* 348:    */   public void setConfig(Config config)
/* 349:    */   {
/* 350:350 */     CONFIGURATOR.setConfig(this, config);
/* 351:    */   }
/* 352:    */   
/* 353:    */   public Config editConfig(Config config)
/* 354:    */   {
/* 355:355 */     return CONFIGURATOR.editConfig(config);
/* 356:    */   }
/* 357:    */   
/* 358:    */   public static final class InternalConfig
/* 359:    */   {
/* 360:360 */     public boolean legendVisible = true;
/* 361:361 */     public boolean titleVisible = true;
/* 362:362 */     public boolean axisVisible = true;
/* 363:363 */     public String title = "";
/* 364:364 */     public ITsChart.LinesThickness linesThickness = JTsChart.DEFAULT_LINES_THICKNESS;
/* 365:365 */     public String colorSchemeName = "";
/* 366:366 */     public double[] zoom = new double[0];
/* 367:    */     
/* 368:    */     ColorScheme getColorScheme() {
/* 369:369 */       if (colorSchemeName.isEmpty()) {
/* 370:370 */         return null;
/* 371:    */       }
/* 372:372 */       Predicate<ColorScheme> predicate = Predicates.compose(Predicates.equalTo(colorSchemeName), ec.nbdemetra.ui.Jdk6Functions.colorSchemeName());
/* 373:373 */       return (ColorScheme)Iterables.tryFind(DemetraUI.getDefault().getColorSchemes(), predicate).orNull();
/* 374:    */     }
/* 375:    */   }
/* 376:    */   
/* 377:    */   private static Configurator<JTsChart> createConfigurator()
/* 378:    */   {
/* 379:379 */     return new InternalConfigHandler(null).toConfigurator(new InternalConfigConverter(null), new InternalConfigEditor(null));
/* 380:    */   }
/* 381:    */   
/* 382:    */   private static final class InternalConfigHandler extends BeanHandler<JTsChart.InternalConfig, JTsChart>
/* 383:    */   {
/* 384:    */     public JTsChart.InternalConfig loadBean(JTsChart r)
/* 385:    */     {
/* 386:386 */       ColorScheme colorScheme = themeSupport.getLocalColorScheme();
/* 387:387 */       JTsChart.InternalConfig result = new JTsChart.InternalConfig();
/* 388:388 */       legendVisible = legendVisible;
/* 389:389 */       titleVisible = titleVisible;
/* 390:390 */       axisVisible = axisVisible;
/* 391:391 */       title = title;
/* 392:392 */       linesThickness = linesThickness;
/* 393:393 */       colorSchemeName = (colorScheme != null ? colorScheme.getName() : "");
/* 394:394 */       zoom = chartPanel.getZoom();
/* 395:395 */       return result;
/* 396:    */     }
/* 397:    */     
/* 398:    */     public void storeBean(JTsChart resource, JTsChart.InternalConfig bean)
/* 399:    */     {
/* 400:400 */       resource.setLegendVisible(legendVisible);
/* 401:401 */       resource.setTitleVisible(titleVisible);
/* 402:402 */       resource.setAxisVisible(axisVisible);
/* 403:403 */       resource.setTitle(title);
/* 404:404 */       resource.setLinesThickness(linesThickness);
/* 405:405 */       resource.setColorScheme(bean.getColorScheme());
/* 406:406 */       chartPanel.setZoom(zoom);
/* 407:    */     }
/* 408:    */   }
/* 409:    */   
/* 410:    */   private static final class InternalConfigEditor implements IBeanEditor
/* 411:    */   {
/* 412:    */     public boolean editBean(Object bean) throws java.beans.IntrospectionException
/* 413:    */     {
/* 414:414 */       Sheet sheet = new Sheet();
/* 415:415 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 416:    */       
/* 417:417 */       b.reset("Chart display");
/* 418:418 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "legendVisible")).display("Show legend")).description("Whether the legend should be shown or not")).add();
/* 419:419 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "titleVisible")).display("Show title")).description("Whether the title should be shown or not")).add();
/* 420:420 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "axisVisible")).display("Show axis")).description("Whether the axis should be shown or not")).add();
/* 421:421 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).selectField(bean, "title")).display("Title").description("Title of the chart").add();
/* 422:422 */       sheet.put(b.build());
/* 423:423 */       b.reset("Series display");
/* 424:424 */       ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(ITsChart.LinesThickness.class).selectField(bean, "linesThickness")).display("Line thickness")).description("Thickness of the line representing the series")).add();
/* 425:425 */       ((NodePropertySetBuilder.AutoCompletedStep)((NodePropertySetBuilder.AutoCompletedStep)b.withAutoCompletion().selectField(bean, "colorSchemeName")).servicePath("JAutoCompletionService/ColorScheme").promptText(DemetraUI.getDefault().getColorSchemeName()).display("Color scheme")).add();
/* 426:    */       
/* 427:427 */       sheet.put(b.build());
/* 428:428 */       return OpenIdePropertySheetBeanEditor.editSheet(sheet, "Configure chart", null);
/* 429:    */     }
/* 430:    */   }
/* 431:    */   
/* 432:    */   private static final class InternalConfigConverter extends Converter<JTsChart.InternalConfig, Config>
/* 433:    */   {
/* 434:434 */     private static final String DOMAIN = JTsChart.class.getName();
/* 435:435 */     private static final String NAME = ""; private static final String VERSION = ""; private static final IParam<Config, Boolean> LEGEND_VISIBLE = Params.onBoolean(Boolean.valueOf(true), "legendVisible");
/* 436:436 */     private static final IParam<Config, Boolean> TITLE_VISIBLE = Params.onBoolean(Boolean.valueOf(true), "titleVisible");
/* 437:437 */     private static final IParam<Config, Boolean> AXIS_VISIBLE = Params.onBoolean(Boolean.valueOf(true), "axisVisible");
/* 438:438 */     private static final IParam<Config, String> TITLE = Params.onString("", "title");
/* 439:439 */     private static final IParam<Config, ITsChart.LinesThickness> LINES_THICKNESS = Params.onEnum(JTsChart.DEFAULT_LINES_THICKNESS, "linesThickness");
/* 440:440 */     private static final IParam<Config, String> COLOR_SCHEME_NAME = Params.onString("", "colorSchemeName");
/* 441:441 */     private static final IParam<Config, double[]> ZOOM = Params.onDoubleArray("zoom", new double[0]);
/* 442:    */     
/* 443:    */     protected Config doForward(JTsChart.InternalConfig a)
/* 444:    */     {
/* 445:445 */       Config.Builder b = Config.builder(DOMAIN, "", "");
/* 446:446 */       LEGEND_VISIBLE.set(b, Boolean.valueOf(legendVisible));
/* 447:447 */       TITLE_VISIBLE.set(b, Boolean.valueOf(titleVisible));
/* 448:448 */       AXIS_VISIBLE.set(b, Boolean.valueOf(axisVisible));
/* 449:449 */       TITLE.set(b, title);
/* 450:450 */       LINES_THICKNESS.set(b, linesThickness);
/* 451:451 */       COLOR_SCHEME_NAME.set(b, colorSchemeName);
/* 452:452 */       ZOOM.set(b, zoom);
/* 453:453 */       return b.build();
/* 454:    */     }
/* 455:    */     
/* 456:    */     protected JTsChart.InternalConfig doBackward(Config config)
/* 457:    */     {
/* 458:458 */       com.google.common.base.Preconditions.checkArgument(DOMAIN.equals(config.getDomain()), "Not produced here");
/* 459:459 */       JTsChart.InternalConfig result = new JTsChart.InternalConfig();
/* 460:460 */       legendVisible = ((Boolean)LEGEND_VISIBLE.get(config)).booleanValue();
/* 461:461 */       titleVisible = ((Boolean)TITLE_VISIBLE.get(config)).booleanValue();
/* 462:462 */       axisVisible = ((Boolean)AXIS_VISIBLE.get(config)).booleanValue();
/* 463:463 */       title = ((String)TITLE.get(config));
/* 464:464 */       linesThickness = ((ITsChart.LinesThickness)LINES_THICKNESS.get(config));
/* 465:465 */       colorSchemeName = ((String)COLOR_SCHEME_NAME.get(config));
/* 466:466 */       zoom = ((double[])ZOOM.get(config));
/* 467:467 */       return result;
/* 468:    */     }
/* 469:    */   }
/* 470:    */ }
