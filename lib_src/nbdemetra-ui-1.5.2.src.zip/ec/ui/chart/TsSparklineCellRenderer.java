/*  1:   */ package ec.ui.chart;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.TsStatus;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  6:   */ import ec.util.chart.swing.SparklineCellRenderer;
/*  7:   */ import org.jfree.data.time.TimeSeries;
/*  8:   */ import org.jfree.data.time.TimeSeriesCollection;
/*  9:   */ import org.jfree.data.xy.XYDataset;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class TsSparklineCellRenderer
/* 20:   */   extends SparklineCellRenderer
/* 21:   */ {
/* 22:   */   protected XYDataset getDataset(Object value)
/* 23:   */   {
/* 24:24 */     if ((value instanceof TimeSeries)) {
/* 25:25 */       return new TimeSeriesCollection((TimeSeries)value);
/* 26:   */     }
/* 27:27 */     if ((value instanceof TsData)) {
/* 28:28 */       return TsCharts.newSparklineDataset((TsData)value);
/* 29:   */     }
/* 30:30 */     if ((value instanceof Ts)) {
/* 31:31 */       Ts ts = (Ts)value;
/* 32:32 */       return ts.hasData().equals(TsStatus.Valid) ? TsCharts.newSparklineDataset(ts.getTsData()) : null;
/* 33:   */     }
/* 34:34 */     return super.getDataset(value);
/* 35:   */   }
/* 36:   */ }
