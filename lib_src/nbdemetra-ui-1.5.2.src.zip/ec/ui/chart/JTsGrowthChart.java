/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   7:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   8:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*   9:    */ import ec.ui.ATsCollectionView.TsCollectionSelectionListener;
/*  10:    */ import ec.ui.ATsCollectionView.TsCollectionTransferHandler;
/*  11:    */ import ec.ui.ATsGrowthChart;
/*  12:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*  13:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  14:    */ import ec.ui.interfaces.ITsPrinter;
/*  15:    */ import ec.util.chart.ObsFunction;
/*  16:    */ import ec.util.chart.SeriesFunction;
/*  17:    */ import ec.util.chart.TimeSeriesChart.Element;
/*  18:    */ import ec.util.chart.TimeSeriesChart.RendererType;
/*  19:    */ import ec.util.chart.swing.Charts;
/*  20:    */ import ec.util.chart.swing.JTimeSeriesChart;
/*  21:    */ import ec.util.chart.swing.JTimeSeriesChartCommand;
/*  22:    */ import java.awt.BorderLayout;
/*  23:    */ import java.awt.Dimension;
/*  24:    */ import java.awt.dnd.DropTarget;
/*  25:    */ import java.awt.dnd.DropTargetAdapter;
/*  26:    */ import java.awt.dnd.DropTargetDragEvent;
/*  27:    */ import java.awt.dnd.DropTargetDropEvent;
/*  28:    */ import java.awt.dnd.DropTargetEvent;
/*  29:    */ import java.awt.event.MouseEvent;
/*  30:    */ import java.beans.Beans;
/*  31:    */ import java.text.NumberFormat;
/*  32:    */ import java.util.Arrays;
/*  33:    */ import java.util.Date;
/*  34:    */ import java.util.TooManyListenersException;
/*  35:    */ import javax.swing.Action;
/*  36:    */ import javax.swing.ActionMap;
/*  37:    */ import javax.swing.JMenu;
/*  38:    */ import javax.swing.JMenuItem;
/*  39:    */ import javax.swing.ListSelectionModel;
/*  40:    */ import org.jfree.data.xy.IntervalXYDataset;
/*  41:    */ 
/*  42:    */ public class JTsGrowthChart extends ATsGrowthChart
/*  43:    */ {
/*  44:    */   protected final JTimeSeriesChart chartPanel;
/*  45:    */   protected final ITsPrinter printer;
/*  46:    */   protected final ListSelectionModel selectionModel;
/*  47:    */   private final ATsCollectionView.TsCollectionSelectionListener selectionListener;
/*  48:    */   
/*  49:    */   public JTsGrowthChart()
/*  50:    */   {
/*  51: 51 */     setLayout(new BorderLayout());
/*  52:    */     
/*  53: 53 */     chartPanel = new JTimeSeriesChart();
/*  54:    */     
/*  55: 55 */     chartPanel.setTransferHandler(new ATsCollectionView.TsCollectionTransferHandler(this));
/*  56:    */     try {
/*  57: 57 */       chartPanel.getDropTarget().addDropTargetListener(new DropTargetAdapter()
/*  58:    */       {
/*  59:    */         public void dragEnter(DropTargetDragEvent dtde) {
/*  60: 60 */           if ((!getTsUpdateMode().isReadOnly()) && (TssTransferSupport.getDefault().canImport(dtde.getCurrentDataFlavors()))) {
/*  61: 61 */             TsCollection col = TssTransferSupport.getDefault().toTsCollection(dtde.getTransferable());
/*  62: 62 */             setDropContent(col != null ? col.toArray() : null);
/*  63:    */           }
/*  64:    */         }
/*  65:    */         
/*  66:    */         public void dragExit(DropTargetEvent dte)
/*  67:    */         {
/*  68: 68 */           setDropContent(null);
/*  69:    */         }
/*  70:    */         
/*  71:    */ 
/*  72:    */         public void drop(DropTargetDropEvent dtde)
/*  73:    */         {
/*  74: 74 */           dragExit(dtde);
/*  75:    */         }
/*  76:    */       });
/*  77:    */     } catch (TooManyListenersException ex) {
/*  78: 78 */       org.openide.util.Exceptions.printStackTrace(ex);
/*  79:    */     }
/*  80:    */     
/*  81: 81 */     printer = new ITsPrinter()
/*  82:    */     {
/*  83:    */       public boolean printPreview() {
/*  84: 84 */         chartPanel.printImage();
/*  85: 85 */         return true;
/*  86:    */       }
/*  87:    */       
/*  88:    */       public boolean print()
/*  89:    */       {
/*  90: 90 */         return printPreview();
/*  91:    */       }
/*  92: 92 */     };
/*  93: 93 */     selectionModel = new javax.swing.DefaultListSelectionModel();
/*  94: 94 */     selectionListener = new ATsCollectionView.TsCollectionSelectionListener(this);
/*  95:    */     
/*  96: 96 */     selectionModel.addListSelectionListener(selectionListener);
/*  97:    */     
/*  98: 98 */     add(chartPanel, "Center");
/*  99:    */     
/* 100:100 */     chartPanel.addMouseListener(new ec.util.chart.swing.SelectionMouseListener(selectionModel, true));
/* 101:    */     
/* 102:102 */     chartPanel.addMouseListener(new java.awt.event.MouseAdapter()
/* 103:    */     {
/* 104:    */       public void mousePressed(MouseEvent e) {
/* 105:105 */         if ((Charts.isPopup(e)) || (!Charts.isDoubleClick(e))) {
/* 106:106 */           return;
/* 107:    */         }
/* 108:108 */         Action a = getActionMap().get("open");
/* 109:109 */         if (a.isEnabled()) {
/* 110:110 */           a.actionPerformed(null);
/* 111:    */         }
/* 112:    */         
/* 113:    */       }
/* 114:114 */     });
/* 115:115 */     onAxisVisibleChange();
/* 116:116 */     onColorSchemeChange();
/* 117:117 */     onLegendVisibleChange();
/* 118:118 */     onTitleChange();
/* 119:119 */     onUpdateModeChange();
/* 120:120 */     onDataFormatChange();
/* 121:    */     
/* 122:122 */     chartPanel.setPopupMenu(buildChartMenu().getPopupMenu());
/* 123:    */     
/* 124:124 */     fillActionMap(chartPanel.getActionMap());
/* 125:125 */     fillInputMap(chartPanel.getInputMap());
/* 126:126 */     NumberFormat percent = NumberFormat.getPercentInstance();
/* 127:127 */     percent.setMaximumFractionDigits(1);
/* 128:128 */     chartPanel.setValueFormat(percent);
/* 129:129 */     chartPanel.setSeriesFormatter(new SeriesFunction()
/* 130:    */     {
/* 131:    */       public String apply(int series) {
/* 132:132 */         return collection.getCount() > series ? collection.get(series).getName() : chartPanel.getDataset().getSeriesKey(series).toString();
/* 133:    */       }
/* 134:134 */     });
/* 135:135 */     chartPanel.setObsFormatter(new ObsFunction()
/* 136:    */     {
/* 137:    */       public String apply(int series, int obs) {
/* 138:138 */         IntervalXYDataset dataset = chartPanel.getDataset();
/* 139:139 */         CharSequence period = chartPanel.getPeriodFormat().format(new Date(dataset.getX(series, obs).longValue()));
/* 140:140 */         CharSequence value = chartPanel.getValueFormat().format(dataset.getY(series, obs));
/* 141:141 */         StringBuilder result = new StringBuilder();
/* 142:142 */         result.append(period).append(": ").append(value);
/* 143:143 */         return result.toString();
/* 144:    */       }
/* 145:145 */     });
/* 146:146 */     chartPanel.setLegendVisibilityPredicate(new ec.util.chart.SeriesPredicate()
/* 147:    */     {
/* 148:    */       public boolean apply(int series) {
/* 149:149 */         return series < collection.getCount();
/* 150:    */       }
/* 151:151 */     });
/* 152:152 */     chartPanel.setSeriesRenderer(SeriesFunction.always(TimeSeriesChart.RendererType.COLUMN));
/* 153:    */     
/* 154:154 */     if (Beans.isDesignTime()) {
/* 155:155 */       setTsCollection(ec.ui.DemoUtils.randomTsCollection(3));
/* 156:156 */       setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 157:157 */       setPreferredSize(new Dimension(200, 150));
/* 158:158 */       setTitle("Chart preview");
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   protected void onDataFormatChange()
/* 163:    */   {
/* 164:    */     try
/* 165:    */     {
/* 166:166 */       chartPanel.setPeriodFormat(themeSupport.getDataFormat().newDateFormat());
/* 167:    */     }
/* 168:    */     catch (IllegalArgumentException localIllegalArgumentException) {}
/* 169:    */   }
/* 170:    */   
/* 171:    */ 
/* 172:    */   protected void onColorSchemeChange()
/* 173:    */   {
/* 174:174 */     chartPanel.setColorSchemeSupport(null);
/* 175:175 */     chartPanel.setColorSchemeSupport(themeSupport);
/* 176:    */   }
/* 177:    */   
/* 178:    */   protected void onCollectionChange()
/* 179:    */   {
/* 180:180 */     TsPeriodSelector selector = computeSelector(collection, lastYears);
/* 181:181 */     growthCollection.replace(Arrays.asList(computeGrowthData(collection.toArray(), growthKind, selector)));
/* 182:182 */     chartPanel.setDataset(TsXYDatasets.from(growthCollection));
/* 183:183 */     chartPanel.resetZoom();
/* 184:    */   }
/* 185:    */   
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */   protected void onSelectionChange()
/* 192:    */   {
/* 193:193 */     selectionListener.setEnabled(false);
/* 194:194 */     selectionModel.clearSelection();
/* 195:195 */     for (Ts o : selection) {
/* 196:196 */       int index = collection.indexOf(o);
/* 197:197 */       selectionModel.addSelectionInterval(index, index);
/* 198:    */     }
/* 199:199 */     selectionListener.setEnabled(true);
/* 200:    */   }
/* 201:    */   
/* 202:    */   protected void onUpdateModeChange()
/* 203:    */   {
/* 204:204 */     chartPanel.setNoDataMessage(getTsUpdateMode().isReadOnly() ? "No data" : "Drop data here");
/* 205:    */   }
/* 206:    */   
/* 207:    */ 
/* 208:    */ 
/* 209:    */   protected void onTsActionChange() {}
/* 210:    */   
/* 211:    */ 
/* 212:    */ 
/* 213:    */   protected void onDropContentChange() {}
/* 214:    */   
/* 215:    */ 
/* 216:    */ 
/* 217:    */   protected void onLegendVisibleChange()
/* 218:    */   {
/* 219:219 */     chartPanel.setElementVisible(TimeSeriesChart.Element.LEGEND, legendVisible);
/* 220:    */   }
/* 221:    */   
/* 222:    */   protected void onTitleVisibleChange()
/* 223:    */   {
/* 224:224 */     chartPanel.setElementVisible(TimeSeriesChart.Element.TITLE, titleVisible);
/* 225:    */   }
/* 226:    */   
/* 227:    */   protected void onAxisVisibleChange()
/* 228:    */   {
/* 229:229 */     chartPanel.setElementVisible(TimeSeriesChart.Element.AXIS, axisVisible);
/* 230:    */   }
/* 231:    */   
/* 232:    */   protected void onTitleChange()
/* 233:    */   {
/* 234:234 */     chartPanel.setTitle(title);
/* 235:    */   }
/* 236:    */   
/* 237:    */   protected void onLinesThicknessChange()
/* 238:    */   {
/* 239:239 */     chartPanel.setLineThickness(linesThickness == ITsChart.LinesThickness.Thin ? 1.0F : 2.0F);
/* 240:    */   }
/* 241:    */   
/* 242:    */   protected void onGrowthKindChange()
/* 243:    */   {
/* 244:244 */     onCollectionChange();
/* 245:    */   }
/* 246:    */   
/* 247:    */   protected void onLastYearsChange()
/* 248:    */   {
/* 249:249 */     onCollectionChange();
/* 250:    */   }
/* 251:    */   
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */   protected void onUseToolLayoutChange() {}
/* 272:    */   
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */   protected JMenu buildExportImageMenu()
/* 293:    */   {
/* 294:294 */     JMenu result = super.buildExportImageMenu();
/* 295:295 */     result.add(JTimeSeriesChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 296:296 */     result.add(JTimeSeriesChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 297:297 */     return result;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void showAll()
/* 301:    */   {
/* 302:302 */     chartPanel.resetZoom();
/* 303:    */   }
/* 304:    */   
/* 305:    */   public ITsPrinter getPrinter()
/* 306:    */   {
/* 307:307 */     return printer;
/* 308:    */   }
/* 309:    */ }
