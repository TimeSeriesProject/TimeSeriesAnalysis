/*   1:    */ package ec.ui.chart;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.collect.ImmutableList;
/*   5:    */ import ec.tss.Ts;
/*   6:    */ import ec.tss.TsStatus;
/*   7:    */ import ec.tstoolkit.data.Values;
/*   8:    */ import ec.tstoolkit.design.IBuilder;
/*   9:    */ import ec.tstoolkit.design.UtilityClass;
/*  10:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  11:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  13:    */ import ec.util.chart.swing.Charts;
/*  14:    */ import java.util.ArrayList;
/*  15:    */ import java.util.Calendar;
/*  16:    */ import java.util.HashSet;
/*  17:    */ import java.util.List;
/*  18:    */ import java.util.Set;
/*  19:    */ import javax.annotation.Nonnull;
/*  20:    */ import org.jfree.data.DomainOrder;
/*  21:    */ import org.jfree.data.general.AbstractSeriesDataset;
/*  22:    */ import org.jfree.data.xy.IntervalXYDataset;
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ @UtilityClass({IntervalXYDataset.class})
/*  51:    */ public final class TsXYDatasets
/*  52:    */ {
/*  53: 53 */   private static final Builder EDT_BUILDER = new Builder();
/*  54:    */   
/*  55:    */   @Nonnull
/*  56:    */   public static IntervalXYDataset from(@Nonnull Comparable<?> key, @Nonnull TsPeriod start, @Nonnull double[] data) {
/*  57: 57 */     return EDT_BUILDER.clear().add(key, start, data).build();
/*  58:    */   }
/*  59:    */   
/*  60:    */   @Nonnull
/*  61:    */   public static IntervalXYDataset from(@Nonnull Comparable<?> key, @Nonnull TsData data) {
/*  62: 62 */     return EDT_BUILDER.clear().add(key, data).build();
/*  63:    */   }
/*  64:    */   
/*  65:    */   @Nonnull
/*  66:    */   public static IntervalXYDataset from(@Nonnull Iterable<? extends Ts> tss) {
/*  67: 67 */     return EDT_BUILDER.clear().add(tss).build();
/*  68:    */   }
/*  69:    */   
/*  70:    */   @Nonnull
/*  71:    */   public static IntervalXYDataset from(@Nonnull Ts... tss) {
/*  72: 72 */     return EDT_BUILDER.clear().add(tss).build();
/*  73:    */   }
/*  74:    */   
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */   @Nonnull
/*  80:    */   @Deprecated
/*  81:    */   public static IntervalXYDataset empty()
/*  82:    */   {
/*  83: 83 */     return Charts.emptyXYDataset();
/*  84:    */   }
/*  85:    */   
/*  86:    */   @Nonnull
/*  87:    */   public static Builder builder()
/*  88:    */   {
/*  89: 89 */     return new Builder();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static final class Builder
/*  93:    */     implements IBuilder<IntervalXYDataset>
/*  94:    */   {
/*  95: 95 */     private final Set<Comparable<?>> keys = new HashSet();
/*  96: 96 */     private final List<TsXYDatasets.TsFacade> list = new ArrayList();
/*  97:    */     
/*  98:    */     private void checkKey(Comparable<?> key) {
/*  99: 99 */       Preconditions.checkNotNull(key, "Cannot add null key");
/* 100:100 */       Preconditions.checkArgument(!keys.contains(key), "Duplicated key");
/* 101:    */     }
/* 102:    */     
/* 103:    */     private void add(TsXYDatasets.TsFacade item) {
/* 104:104 */       keys.add(item.getKey());
/* 105:105 */       list.add(item);
/* 106:    */     }
/* 107:    */     
/* 108:    */     private void addTs(Ts ts) {
/* 109:109 */       Preconditions.checkNotNull(ts, "Ts cannot be null");
/* 110:110 */       checkKey(ts.getMoniker());
/* 111:111 */       if (ts.hasData().equals(TsStatus.Valid)) {
/* 112:112 */         add(TsXYDatasets.FastTs.create(ts));
/* 113:    */       }
/* 114:    */     }
/* 115:    */     
/* 116:    */     @Nonnull
/* 117:    */     public Builder add(@Nonnull Comparable<?> key, @Nonnull TsPeriod start, @Nonnull double[] data) {
/* 118:118 */       checkKey(key);
/* 119:119 */       Preconditions.checkNotNull(start, "Start cannot be null");
/* 120:120 */       Preconditions.checkNotNull(data, "Data cannot be null");
/* 121:121 */       if (data.length > 0) {
/* 122:122 */         add(TsXYDatasets.FastTs.create(key, start, data));
/* 123:    */       }
/* 124:124 */       return this;
/* 125:    */     }
/* 126:    */     
/* 127:    */     @Nonnull
/* 128:    */     public Builder add(@Nonnull Comparable<?> key, @Nonnull TsData data) {
/* 129:129 */       checkKey(key);
/* 130:130 */       Preconditions.checkNotNull(data, "Data cannot be null");
/* 131:131 */       if (!data.isEmpty()) {
/* 132:132 */         add(TsXYDatasets.FastTs.create(key, data));
/* 133:    */       }
/* 134:134 */       return this;
/* 135:    */     }
/* 136:    */     
/* 137:    */     @Nonnull
/* 138:    */     public Builder add(@Nonnull Iterable<? extends Ts> tss) {
/* 139:139 */       for (Ts o : tss) {
/* 140:140 */         addTs(o);
/* 141:    */       }
/* 142:142 */       return this;
/* 143:    */     }
/* 144:    */     
/* 145:    */     @Nonnull
/* 146:    */     public Builder add(@Nonnull Ts... tss) {
/* 147:147 */       for (Ts o : tss) {
/* 148:148 */         addTs(o);
/* 149:    */       }
/* 150:150 */       return this;
/* 151:    */     }
/* 152:    */     
/* 153:    */     @Nonnull
/* 154:    */     public Builder clear() {
/* 155:155 */       keys.clear();
/* 156:156 */       list.clear();
/* 157:157 */       return this;
/* 158:    */     }
/* 159:    */     
/* 160:    */     public IntervalXYDataset build()
/* 161:    */     {
/* 162:162 */       switch (list.size()) {
/* 163:    */       case 0: 
/* 164:164 */         return Charts.emptyXYDataset();
/* 165:    */       case 1: 
/* 166:166 */         return new TsXYDatasets.SingleTsXYDataset((TsXYDatasets.TsFacade)list.get(0), null);
/* 167:    */       }
/* 168:168 */       return new TsXYDatasets.MultiTsXYDataset(ImmutableList.copyOf(list), null);
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   private static abstract class AbstractTsXYDataset
/* 173:    */     extends AbstractSeriesDataset
/* 174:    */     implements IntervalXYDataset
/* 175:    */   {
/* 176:    */     public Number getStartX(int series, int item)
/* 177:    */     {
/* 178:178 */       return Double.valueOf(getStartXValue(series, item));
/* 179:    */     }
/* 180:    */     
/* 181:    */     public Number getEndX(int series, int item)
/* 182:    */     {
/* 183:183 */       return Double.valueOf(getEndXValue(series, item));
/* 184:    */     }
/* 185:    */     
/* 186:    */     public Number getStartY(int series, int item)
/* 187:    */     {
/* 188:188 */       return Double.valueOf(getEndYValue(series, item));
/* 189:    */     }
/* 190:    */     
/* 191:    */     public double getStartYValue(int series, int item)
/* 192:    */     {
/* 193:193 */       return getYValue(series, item);
/* 194:    */     }
/* 195:    */     
/* 196:    */     public Number getEndY(int series, int item)
/* 197:    */     {
/* 198:198 */       return Double.valueOf(getEndYValue(series, item));
/* 199:    */     }
/* 200:    */     
/* 201:    */     public double getEndYValue(int series, int item)
/* 202:    */     {
/* 203:203 */       return getYValue(series, item);
/* 204:    */     }
/* 205:    */     
/* 206:    */     public DomainOrder getDomainOrder()
/* 207:    */     {
/* 208:208 */       return DomainOrder.NONE;
/* 209:    */     }
/* 210:    */     
/* 211:    */     public Number getX(int series, int item)
/* 212:    */     {
/* 213:213 */       return Double.valueOf(getXValue(series, item));
/* 214:    */     }
/* 215:    */     
/* 216:    */     public Number getY(int series, int item)
/* 217:    */     {
/* 218:218 */       return Double.valueOf(getYValue(series, item));
/* 219:    */     }
/* 220:    */   }
/* 221:    */   
/* 222:    */   private static final class MultiTsXYDataset extends TsXYDatasets.AbstractTsXYDataset {
/* 223:    */     private final List<TsXYDatasets.TsFacade> list;
/* 224:    */     
/* 225:    */     private MultiTsXYDataset(@Nonnull List<TsXYDatasets.TsFacade> list) {
/* 226:226 */       super();
/* 227:227 */       this.list = list;
/* 228:    */     }
/* 229:    */     
/* 230:    */     public int getSeriesCount()
/* 231:    */     {
/* 232:232 */       return list.size();
/* 233:    */     }
/* 234:    */     
/* 235:    */     public Comparable<?> getSeriesKey(int series)
/* 236:    */     {
/* 237:237 */       return ((TsXYDatasets.TsFacade)list.get(series)).getKey();
/* 238:    */     }
/* 239:    */     
/* 240:    */     public double getStartXValue(int series, int item)
/* 241:    */     {
/* 242:242 */       return ((TsXYDatasets.TsFacade)list.get(series)).getStartTimeInMillis(item);
/* 243:    */     }
/* 244:    */     
/* 245:    */     public double getEndXValue(int series, int item)
/* 246:    */     {
/* 247:247 */       return ((TsXYDatasets.TsFacade)list.get(series)).getEndTimeInMillis(item);
/* 248:    */     }
/* 249:    */     
/* 250:    */     public int getItemCount(int series)
/* 251:    */     {
/* 252:252 */       return ((TsXYDatasets.TsFacade)list.get(series)).getItemCount();
/* 253:    */     }
/* 254:    */     
/* 255:    */     public double getXValue(int series, int item)
/* 256:    */     {
/* 257:257 */       return ((TsXYDatasets.TsFacade)list.get(series)).getMiddleTimeInMillis(item);
/* 258:    */     }
/* 259:    */     
/* 260:    */     public double getYValue(int series, int item)
/* 261:    */     {
/* 262:262 */       return ((TsXYDatasets.TsFacade)list.get(series)).getValue(item);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   private static final class SingleTsXYDataset extends TsXYDatasets.AbstractTsXYDataset {
/* 267:    */     private final TsXYDatasets.TsFacade singleton;
/* 268:    */     
/* 269:    */     private SingleTsXYDataset(@Nonnull TsXYDatasets.TsFacade singleton) {
/* 270:270 */       super();
/* 271:271 */       this.singleton = singleton;
/* 272:    */     }
/* 273:    */     
/* 274:    */     public int getSeriesCount()
/* 275:    */     {
/* 276:276 */       return 1;
/* 277:    */     }
/* 278:    */     
/* 279:    */     public Comparable<?> getSeriesKey(int series)
/* 280:    */     {
/* 281:281 */       return singleton.getKey();
/* 282:    */     }
/* 283:    */     
/* 284:    */     public double getStartXValue(int series, int item)
/* 285:    */     {
/* 286:286 */       return singleton.getStartTimeInMillis(item);
/* 287:    */     }
/* 288:    */     
/* 289:    */     public double getEndXValue(int series, int item)
/* 290:    */     {
/* 291:291 */       return singleton.getEndTimeInMillis(item);
/* 292:    */     }
/* 293:    */     
/* 294:    */     public int getItemCount(int series)
/* 295:    */     {
/* 296:296 */       return singleton.getItemCount();
/* 297:    */     }
/* 298:    */     
/* 299:    */     public double getXValue(int series, int item)
/* 300:    */     {
/* 301:301 */       return singleton.getMiddleTimeInMillis(item);
/* 302:    */     }
/* 303:    */     
/* 304:    */     public double getYValue(int series, int item)
/* 305:    */     {
/* 306:306 */       return singleton.getValue(item);
/* 307:    */     }
/* 308:    */   }
/* 309:    */   
/* 310:    */ 
/* 311:    */ 
/* 312:    */ 
/* 313:    */ 
/* 314:    */ 
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */ 
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:    */ 
/* 327:    */ 
/* 328:    */ 
/* 329:    */ 
/* 330:    */   private static final class FastTs
/* 331:    */     implements TsXYDatasets.TsFacade
/* 332:    */   {
/* 333:333 */     private static final Calendar EDT_CALENDAR = ;
/* 334:    */     private final Calendar cal;
/* 335:    */     
/* 336:    */     @Nonnull
/* 337:    */     static FastTs create(@Nonnull Ts ts) {
/* 338:338 */       return create(ts.getMoniker(), ts.getTsData());
/* 339:    */     }
/* 340:    */     
/* 341:    */     @Nonnull
/* 342:    */     static FastTs create(@Nonnull Comparable<?> key, @Nonnull TsData data) {
/* 343:343 */       return create(key, data.getStart(), data.getValues().internalStorage());
/* 344:    */     }
/* 345:    */     
/* 346:    */     @Nonnull
/* 347:    */     static FastTs create(@Nonnull Comparable<?> key, @Nonnull TsPeriod start, @Nonnull double[] data) {
/* 348:348 */       int freq = start.getFrequency().intValue();
/* 349:349 */       int id = start.hashCode();
/* 350:350 */       return id >= 0 ? 
/* 351:351 */         new FastTs(EDT_CALENDAR, key, freq, 1970 + id / freq, id % freq, data) : 
/* 352:352 */         new FastTs(EDT_CALENDAR, key, freq, 1969 + (1 + id) / freq, freq - 1 + (1 + id) % freq, data);
/* 353:    */     }
/* 354:    */     
/* 355:    */ 
/* 356:    */     private final Comparable<?> key;
/* 357:    */     private final int freq;
/* 358:    */     private final int startYear;
/* 359:    */     private final int startPos;
/* 360:    */     private final double[] data;
/* 361:    */     private FastTs(@Nonnull Calendar cal, @Nonnull Comparable<?> key, int freq, int startYear, int startPos, @Nonnull double[] data)
/* 362:    */     {
/* 363:363 */       this.cal = cal;
/* 364:364 */       this.key = key;
/* 365:365 */       this.freq = freq;
/* 366:366 */       this.startYear = startYear;
/* 367:367 */       this.startPos = startPos;
/* 368:368 */       this.data = data;
/* 369:    */     }
/* 370:    */     
/* 371:    */     public Comparable<?> getKey()
/* 372:    */     {
/* 373:373 */       return key;
/* 374:    */     }
/* 375:    */     
/* 376:    */     public int getItemCount()
/* 377:    */     {
/* 378:378 */       return data.length;
/* 379:    */     }
/* 380:    */     
/* 381:    */     public double getValue(int item)
/* 382:    */     {
/* 383:383 */       return data[item];
/* 384:    */     }
/* 385:    */     
/* 386:    */     public long getStartTimeInMillis(int item)
/* 387:    */     {
/* 388:388 */       int tmp = startPos + item;
/* 389:389 */       cal.set(1, startYear + tmp / freq);
/* 390:390 */       cal.set(2, tmp % freq * (12 / freq));
/* 391:391 */       cal.set(5, 1);
/* 392:392 */       cal.set(11, 0);
/* 393:393 */       cal.set(12, 0);
/* 394:394 */       cal.set(13, 0);
/* 395:395 */       cal.set(14, 0);
/* 396:396 */       return cal.getTimeInMillis();
/* 397:    */     }
/* 398:    */     
/* 399:    */     public long getEndTimeInMillis(int item)
/* 400:    */     {
/* 401:401 */       return getStartTimeInMillis(item + 1);
/* 402:    */     }
/* 403:    */     
/* 404:    */     public long getMiddleTimeInMillis(int item)
/* 405:    */     {
/* 406:406 */       long start = getStartTimeInMillis(item);
/* 407:407 */       cal.add(2, 12 / freq);
/* 408:408 */       long end = cal.getTimeInMillis();
/* 409:409 */       return start + (end - start) / 2L;
/* 410:    */     }
/* 411:    */   }
/* 412:    */   
/* 413:    */   private static abstract interface TsFacade
/* 414:    */   {
/* 415:    */     public abstract Comparable<?> getKey();
/* 416:    */     
/* 417:    */     public abstract int getItemCount();
/* 418:    */     
/* 419:    */     public abstract double getValue(int paramInt);
/* 420:    */     
/* 421:    */     public abstract long getStartTimeInMillis(int paramInt);
/* 422:    */     
/* 423:    */     public abstract long getEndTimeInMillis(int paramInt);
/* 424:    */     
/* 425:    */     public abstract long getMiddleTimeInMillis(int paramInt);
/* 426:    */   }
/* 427:    */ }
