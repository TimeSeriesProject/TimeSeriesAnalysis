/*  1:   */ package ec.ui;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.design.UtilityClass;
/*  4:   */ import ec.ui.interfaces.IDisposable;
/*  5:   */ import java.awt.Component;
/*  6:   */ import java.awt.Container;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ @UtilityClass({IDisposable.class})
/* 20:   */ public final class Disposables
/* 21:   */ {
/* 22:   */   public static <C extends Container> C disposeAndRemoveAll(C c)
/* 23:   */   {
/* 24:24 */     disposeAll(c.getComponents());
/* 25:25 */     c.removeAll();
/* 26:26 */     return c;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static void disposeAll(Component... list) {
/* 30:30 */     Component[] arrayOfComponent = list;int j = list.length; for (int i = 0; i < j; i++) { Component o = arrayOfComponent[i];
/* 31:31 */       dispose(o);
/* 32:   */     }
/* 33:   */   }
/* 34:   */   
/* 35:   */   public static void dispose(Component c) {
/* 36:36 */     if ((c instanceof IDisposable)) {
/* 37:37 */       ((IDisposable)c).dispose();
/* 38:   */     }
/* 39:   */   }
/* 40:   */ }
