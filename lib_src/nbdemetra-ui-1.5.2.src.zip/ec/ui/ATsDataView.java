/*  1:   */ package ec.ui;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  5:   */ import ec.ui.interfaces.ITsDataView;
/*  6:   */ import java.beans.PropertyChangeEvent;
/*  7:   */ import java.beans.PropertyChangeListener;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public abstract class ATsDataView
/* 17:   */   extends ATsControl
/* 18:   */   implements ITsDataView
/* 19:   */ {
/* 20:20 */   protected static final TsData DEFAULT_TS_DATA = new TsData(TsFrequency.Monthly, 2000, 0, 0);
/* 21:   */   protected TsData tsData;
/* 22:   */   
/* 23:   */   public ATsDataView()
/* 24:   */   {
/* 25:25 */     tsData = DEFAULT_TS_DATA;
/* 26:26 */     addPropertyChangeListener(new PropertyChangeListener()
/* 27:   */     {
/* 28:   */       public void propertyChange(PropertyChangeEvent evt)
/* 29:   */       {
/* 30:30 */         String p = evt.getPropertyName();
/* 31:31 */         if (p.equals("tsData")) {
/* 32:32 */           onTsDataChange();
/* 33:   */         }
/* 34:   */       }
/* 35:   */     });
/* 36:   */   }
/* 37:   */   
/* 38:   */ 
/* 39:   */ 
/* 40:   */   protected abstract void onTsDataChange();
/* 41:   */   
/* 42:   */ 
/* 43:   */   public void setTsData(TsData tsData)
/* 44:   */   {
/* 45:45 */     TsData old = this.tsData;
/* 46:46 */     this.tsData = (tsData != null ? tsData : DEFAULT_TS_DATA);
/* 47:47 */     firePropertyChange("tsData", old, this.tsData);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public TsData getTsData()
/* 51:   */   {
/* 52:52 */     return tsData;
/* 53:   */   }
/* 54:   */ }
