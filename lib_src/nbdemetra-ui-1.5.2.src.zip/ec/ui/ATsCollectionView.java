/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ImmutableList;
/*   4:    */ import com.google.common.collect.Iterables;
/*   5:    */ import com.google.common.collect.Lists;
/*   6:    */ import ec.nbdemetra.ui.DemetraUI;
/*   7:    */ import ec.nbdemetra.ui.IConfigurable;
/*   8:    */ import ec.nbdemetra.ui.awt.KeyStrokes;
/*   9:    */ import ec.nbdemetra.ui.tsaction.ITsAction;
/*  10:    */ import ec.tss.Ts;
/*  11:    */ import ec.tss.TsCollection;
/*  12:    */ import ec.tss.TsEvent;
/*  13:    */ import ec.tss.TsFactory;
/*  14:    */ import ec.tss.TsInformationType;
/*  15:    */ import ec.tss.datatransfer.TsDragRenderer;
/*  16:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  17:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  18:    */ import ec.ui.commands.ColorSchemeCommand;
/*  19:    */ import ec.ui.commands.TsCollectionViewCommand;
/*  20:    */ import ec.ui.interfaces.IColorSchemeAble;
/*  21:    */ import ec.ui.interfaces.ITsCollectionView;
/*  22:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  23:    */ import ec.util.chart.ColorScheme;
/*  24:    */ import ec.util.chart.swing.ColorSchemeIcon;
/*  25:    */ import ec.util.various.swing.FontAwesome;
/*  26:    */ import ec.util.various.swing.JCommand;
/*  27:    */ import ec.util.various.swing.JCommand.ActionAdapter;
/*  28:    */ import java.awt.Font;
/*  29:    */ import java.awt.Image;
/*  30:    */ import java.awt.datatransfer.Transferable;
/*  31:    */ import java.awt.event.MouseAdapter;
/*  32:    */ import java.awt.event.MouseEvent;
/*  33:    */ import java.beans.PropertyChangeEvent;
/*  34:    */ import java.beans.PropertyChangeListener;
/*  35:    */ import java.util.Arrays;
/*  36:    */ import java.util.EnumSet;
/*  37:    */ import java.util.List;
/*  38:    */ import java.util.Observable;
/*  39:    */ import java.util.Observer;
/*  40:    */ import java.util.concurrent.atomic.AtomicBoolean;
/*  41:    */ import javax.swing.ActionMap;
/*  42:    */ import javax.swing.InputMap;
/*  43:    */ import javax.swing.JCheckBoxMenuItem;
/*  44:    */ import javax.swing.JComponent;
/*  45:    */ import javax.swing.JMenu;
/*  46:    */ import javax.swing.JMenuItem;
/*  47:    */ import javax.swing.KeyStroke;
/*  48:    */ import javax.swing.ListSelectionModel;
/*  49:    */ import javax.swing.SwingUtilities;
/*  50:    */ import javax.swing.TransferHandler;
/*  51:    */ import javax.swing.TransferHandler.TransferSupport;
/*  52:    */ import javax.swing.event.ListSelectionEvent;
/*  53:    */ import javax.swing.event.ListSelectionListener;
/*  54:    */ import org.openide.util.ImageUtilities;
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ public abstract class ATsCollectionView
/*  70:    */   extends ATsControl
/*  71:    */   implements ITsCollectionView
/*  72:    */ {
/*  73:    */   public static final String DROP_CONTENT_PROPERTY = "dropContent";
/*  74:    */   public static final String FREEZE_ACTION = "freeze";
/*  75:    */   public static final String COPY_ACTION = "copy";
/*  76:    */   public static final String COPY_ALL_ACTION = "copyAll";
/*  77:    */   public static final String DELETE_ACTION = "delete";
/*  78:    */   public static final String CLEAR_ACTION = "clear";
/*  79:    */   public static final String PASTE_ACTION = "paste";
/*  80:    */   public static final String OPEN_ACTION = "open";
/*  81:    */   public static final String SELECT_ALL_ACTION = "selectAll";
/*  82:    */   public static final String RENAME_ACTION = "rename";
/*  83:    */   public static final String DEFAULT_COLOR_SCHEME_ACTION = "defaultColorScheme";
/*  84: 84 */   protected static final ITsCollectionView.TsUpdateMode DEFAULT_UPDATEMODE = ITsCollectionView.TsUpdateMode.Append;
/*  85: 85 */   protected static final Ts[] DEFAULT_SELECTION = new Ts[0];
/*  86: 86 */   protected static final Ts[] DEFAULT_DROP_CONTENT = new Ts[0];
/*  87:    */   
/*  88:    */   protected TsCollection collection;
/*  89:    */   
/*  90:    */   protected ITsCollectionView.TsUpdateMode updateMode;
/*  91:    */   
/*  92:    */   protected ITsAction tsAction;
/*  93:    */   protected Ts[] selection;
/*  94:    */   protected Ts[] dropContent;
/*  95:    */   protected final TsFactoryObserver tsFactoryObserver;
/*  96: 96 */   protected DemetraUI demetraUI = DemetraUI.getDefault();
/*  97:    */   
/*  98:    */   public ATsCollectionView() {
/*  99: 99 */     collection = TsFactory.instance.createTsCollection();
/* 100:100 */     updateMode = DEFAULT_UPDATEMODE;
/* 101:101 */     tsAction = null;
/* 102:102 */     selection = DEFAULT_SELECTION;
/* 103:103 */     dropContent = DEFAULT_DROP_CONTENT;
/* 104:104 */     tsFactoryObserver = new TsFactoryObserver();
/* 105:    */     
/* 106:106 */     addPropertyChangeListener(new PropertyChangeListener() {
/* 107:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 108:    */         String str;
/* 109:109 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1715965556:  if (str.equals("selection")) break; break; case -999919125:  if (str.equals("tsUpdateMode")) {} break; case 1242127765:  if (str.equals("tsAction")) {} break; case 1244250762:  if (str.equals("dropContent")) {} case 1849869949:  if ((goto 167) && (str.equals("tsCollection")))
/* 110:    */           {
/* 111:111 */             onCollectionChange();
/* 112:112 */             return;
/* 113:    */             
/* 114:114 */             onSelectionChange();
/* 115:115 */             return;
/* 116:    */             
/* 117:117 */             onUpdateModeChange();
/* 118:118 */             return;
/* 119:    */             
/* 120:120 */             onTsActionChange();
/* 121:121 */             return;
/* 122:    */             
/* 123:123 */             onDropContentChange();
/* 124:    */           }
/* 125:    */           break;
/* 126:    */         }
/* 127:    */       }
/* 128:128 */     });
/* 129:129 */     ActionMap am = getActionMap();
/* 130:130 */     am.put("freeze", TsCollectionViewCommand.freeze().toAction(this));
/* 131:131 */     am.put("copy", TsCollectionViewCommand.copy().toAction(this));
/* 132:132 */     am.put("copyAll", TsCollectionViewCommand.copyAll().toAction(this));
/* 133:133 */     am.put("delete", TsCollectionViewCommand.delete().toAction(this));
/* 134:134 */     am.put("clear", TsCollectionViewCommand.clear().toAction(this));
/* 135:135 */     am.put("paste", TsCollectionViewCommand.paste().toAction(this));
/* 136:136 */     am.put("open", TsCollectionViewCommand.open().toAction(this));
/* 137:137 */     am.put("selectAll", TsCollectionViewCommand.selectAll().toAction(this));
/* 138:138 */     am.put("rename", TsCollectionViewCommand.rename().toAction(this));
/* 139:139 */     if ((this instanceof IColorSchemeAble)) {
/* 140:140 */       am.put("defaultColorScheme", ColorSchemeCommand.applyColorScheme(null).toAction((IColorSchemeAble)this));
/* 141:    */     }
/* 142:    */     
/* 143:143 */     InputMap im = getInputMap();
/* 144:144 */     KeyStrokes.putAll(im, KeyStrokes.COPY, "copy");
/* 145:145 */     KeyStrokes.putAll(im, KeyStrokes.PASTE, "paste");
/* 146:146 */     KeyStrokes.putAll(im, KeyStrokes.DELETE, "copy");
/* 147:147 */     KeyStrokes.putAll(im, KeyStrokes.SELECT_ALL, "selectAll");
/* 148:148 */     KeyStrokes.putAll(im, KeyStrokes.OPEN, "open");
/* 149:149 */     KeyStrokes.putAll(im, KeyStrokes.CLEAR, "clear");
/* 150:    */     
/* 151:151 */     TsFactory.instance.addObserver(tsFactoryObserver);
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */   protected abstract void onCollectionChange();
/* 156:    */   
/* 157:    */ 
/* 158:    */   protected abstract void onSelectionChange();
/* 159:    */   
/* 160:    */ 
/* 161:    */   protected abstract void onUpdateModeChange();
/* 162:    */   
/* 163:    */   protected abstract void onTsActionChange();
/* 164:    */   
/* 165:    */   protected abstract void onDropContentChange();
/* 166:    */   
/* 167:    */   public TsCollection getTsCollection()
/* 168:    */   {
/* 169:169 */     return collection;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setTsCollection(TsCollection collection)
/* 173:    */   {
/* 174:174 */     TsCollection old = this.collection;
/* 175:175 */     this.collection = (collection != null ? collection : TsFactory.instance.createTsCollection());
/* 176:    */     
/* 177:177 */     Ts[] oldSelection = selection;
/* 178:178 */     selection = retainTsCollection(selection);
/* 179:179 */     firePropertyChange("tsCollection", old, this.collection);
/* 180:180 */     firePropertyChange("selection", oldSelection, selection);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public Ts[] getSelection()
/* 184:    */   {
/* 185:185 */     return (Ts[])selection.clone();
/* 186:    */   }
/* 187:    */   
/* 188:    */   public void setSelection(Ts[] tss)
/* 189:    */   {
/* 190:190 */     Ts[] old = selection;
/* 191:191 */     selection = (tss != null ? retainTsCollection(tss) : DEFAULT_SELECTION);
/* 192:192 */     firePropertyChange("selection", old, selection);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public int getSelectionSize()
/* 196:    */   {
/* 197:197 */     return selection.length;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public ITsCollectionView.TsUpdateMode getTsUpdateMode()
/* 201:    */   {
/* 202:202 */     return updateMode;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void setTsUpdateMode(ITsCollectionView.TsUpdateMode updateMode)
/* 206:    */   {
/* 207:207 */     ITsCollectionView.TsUpdateMode old = this.updateMode;
/* 208:208 */     this.updateMode = (updateMode != null ? updateMode : DEFAULT_UPDATEMODE);
/* 209:209 */     firePropertyChange("tsUpdateMode", old, this.updateMode);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public ITsAction getTsAction()
/* 213:    */   {
/* 214:214 */     return tsAction;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void setTsAction(ITsAction tsAction)
/* 218:    */   {
/* 219:219 */     ITsAction old = this.tsAction;
/* 220:220 */     this.tsAction = tsAction;
/* 221:221 */     firePropertyChange("tsAction", old, this.tsAction);
/* 222:    */   }
/* 223:    */   
/* 224:    */   protected void setDropContent(Ts[] dropContent)
/* 225:    */   {
/* 226:226 */     Ts[] old = this.dropContent;
/* 227:227 */     this.dropContent = (dropContent != null ? removeTsCollection(dropContent) : DEFAULT_DROP_CONTENT);
/* 228:228 */     firePropertyChange("dropContent", old, this.dropContent);
/* 229:    */   }
/* 230:    */   
/* 231:    */ 
/* 232:    */ 
/* 233:    */   public void dispose()
/* 234:    */   {
/* 235:235 */     TsFactory.instance.deleteObserver(tsFactoryObserver);
/* 236:236 */     super.dispose();
/* 237:    */   }
/* 238:    */   
/* 239:    */   public void connect() {
/* 240:240 */     TsFactory.instance.addObserver(tsFactoryObserver);
/* 241:    */   }
/* 242:    */   
/* 243:    */   protected Transferable transferableOnSelection() {
/* 244:244 */     TsCollection col = TsFactory.instance.createTsCollection();
/* 245:245 */     col.quietAppend(Arrays.asList(selection));
/* 246:246 */     return TssTransferSupport.getDefault().fromTsCollection(col);
/* 247:    */   }
/* 248:    */   
/* 249:    */   protected Ts[] retainTsCollection(Ts[] tss) {
/* 250:250 */     List<Ts> tmp = Lists.newArrayList(tss);
/* 251:251 */     tmp.retainAll(Arrays.asList(collection.toArray()));
/* 252:252 */     return (Ts[])Iterables.toArray(tmp, Ts.class);
/* 253:    */   }
/* 254:    */   
/* 255:    */   protected Ts[] removeTsCollection(Ts[] tss) {
/* 256:256 */     List<Ts> tmp = Lists.newArrayList(tss);
/* 257:257 */     tmp.removeAll(Arrays.asList(collection.toArray()));
/* 258:258 */     return (Ts[])Iterables.toArray(tmp, Ts.class);
/* 259:    */   }
/* 260:    */   
/* 261:    */   public JMenu buildColorSchemeMenu() {
/* 262:262 */     ActionMap am = getActionMap();
/* 263:263 */     JMenu result = new JMenu("Color scheme");
/* 264:264 */     if ((this instanceof IColorSchemeAble))
/* 265:    */     {
/* 266:    */ 
/* 267:267 */       JMenuItem item = new JCheckBoxMenuItem(am.get("defaultColorScheme"));
/* 268:268 */       item.setText("Default");
/* 269:269 */       result.add(item);
/* 270:    */       
/* 271:271 */       result.addSeparator();
/* 272:272 */       for (ColorScheme o : DemetraUI.getDefault().getColorSchemes()) {
/* 273:273 */         item = new JCheckBoxMenuItem(ColorSchemeCommand.applyColorScheme(o).toAction((IColorSchemeAble)this));
/* 274:274 */         item.setText(o.getDisplayName());
/* 275:275 */         item.setIcon(new ColorSchemeIcon(o));
/* 276:276 */         result.add(item);
/* 277:    */       }
/* 278:    */     }
/* 279:279 */     return result;
/* 280:    */   }
/* 281:    */   
/* 282:    */   protected JMenu buildMenu() {
/* 283:283 */     InputMap im = getInputMap();
/* 284:284 */     ActionMap am = getActionMap();
/* 285:285 */     JMenu result = new JMenu();
/* 286:    */     
/* 287:    */ 
/* 288:    */ 
/* 289:289 */     JMenuItem item = new JMenuItem(am.get("open"));
/* 290:290 */     item.setText("Open");
/* 291:291 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_FOLDER_OPEN_O));
/* 292:292 */     ExtAction.hideWhenDisabled(item);
/* 293:293 */     item.setAccelerator((KeyStroke)KeyStrokes.OPEN.get(0));
/* 294:294 */     item.setFont(item.getFont().deriveFont(1));
/* 295:295 */     result.add(item);
/* 296:    */     
/* 297:297 */     result.add(buildOpenWithMenu());
/* 298:    */     
/* 299:299 */     item = new JMenuItem(am.get("rename"));
/* 300:300 */     item.setText("Rename");
/* 301:301 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_PENCIL_SQUARE_O));
/* 302:302 */     ExtAction.hideWhenDisabled(item);
/* 303:303 */     result.add(item);
/* 304:    */     
/* 305:305 */     item = new JMenuItem(am.get("freeze"));
/* 306:306 */     item.setText("Freeze");
/* 307:307 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_LOCK));
/* 308:308 */     ExtAction.hideWhenDisabled(item);
/* 309:309 */     result.add(item);
/* 310:    */     
/* 311:311 */     item = new JMenuItem(am.get("copy"));
/* 312:312 */     item.setText("Copy");
/* 313:313 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_FILES_O));
/* 314:314 */     item.setAccelerator((KeyStroke)KeyStrokes.COPY.get(0));
/* 315:315 */     ExtAction.hideWhenDisabled(item);
/* 316:316 */     result.add(item);
/* 317:    */     
/* 318:318 */     item = new JMenuItem(am.get("paste"));
/* 319:319 */     item.setText("Paste");
/* 320:320 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_CLIPBOARD));
/* 321:321 */     item.setAccelerator((KeyStroke)KeyStrokes.PASTE.get(0));
/* 322:    */     
/* 323:323 */     result.add(item);
/* 324:    */     
/* 325:325 */     item = new JMenuItem(am.get("delete"));
/* 326:326 */     item.setText("Remove");
/* 327:327 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_TRASH_O));
/* 328:328 */     item.setAccelerator((KeyStroke)KeyStrokes.DELETE.get(0));
/* 329:329 */     ExtAction.hideWhenDisabled(item);
/* 330:330 */     result.add(item);
/* 331:    */     
/* 332:332 */     result.addSeparator();
/* 333:    */     
/* 334:334 */     item = new JMenuItem(am.get("selectAll"));
/* 335:335 */     item.setText("Select all");
/* 336:336 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_ASTERISK));
/* 337:337 */     item.setAccelerator((KeyStroke)KeyStrokes.SELECT_ALL.get(0));
/* 338:338 */     result.add(item);
/* 339:    */     
/* 340:340 */     item = new JMenuItem(am.get("clear"));
/* 341:341 */     item.setText("Clear");
/* 342:342 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_ERASER));
/* 343:343 */     item.setAccelerator((KeyStroke)KeyStrokes.CLEAR.get(0));
/* 344:344 */     result.add(item);
/* 345:    */     
/* 346:346 */     if ((this instanceof IConfigurable)) {
/* 347:347 */       result.addSeparator();
/* 348:348 */       item = new JMenuItem(am.get("configure"));
/* 349:349 */       item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_COGS));
/* 350:350 */       item.setText("Configure...");
/* 351:351 */       result.add(item);
/* 352:    */     }
/* 353:    */     
/* 354:354 */     return result;
/* 355:    */   }
/* 356:    */   
/* 357:    */   protected JMenu buildSelectByFreqMenu() {
/* 358:358 */     JMenu result = new JMenu("Select by frequency");
/* 359:359 */     result.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_CALENDAR_O));
/* 360:360 */     for (TsFrequency freq : EnumSet.of(TsFrequency.Monthly, TsFrequency.Quarterly, TsFrequency.HalfYearly, TsFrequency.Yearly)) {
/* 361:361 */       JMenuItem item = new JMenuItem(TsCollectionViewCommand.selectByFreq(freq).toAction(this));
/* 362:362 */       item.setText(freq.name());
/* 363:363 */       result.add(item);
/* 364:    */     }
/* 365:365 */     return result;
/* 366:    */   }
/* 367:    */   
/* 368:    */   protected JMenu buildOpenWithMenu() {
/* 369:369 */     JMenu result = new JMenu(new OpenWithCommand(null).toAction(this));
/* 370:370 */     result.setText("Open with");
/* 371:371 */     result.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_BAR_CHART_O));
/* 372:372 */     ExtAction.hideWhenDisabled(result);
/* 373:    */     
/* 374:374 */     for (ITsAction o : DemetraUI.getDefault().getTsActions()) {
/* 375:375 */       JMenuItem item = new JMenuItem(TsCollectionViewCommand.openWith(o).toAction(this));
/* 376:376 */       item.setName(o.getName());
/* 377:377 */       item.setText(o.getDisplayName());
/* 378:378 */       item.setIcon(demetraUI.getPopupMenuIcon(ImageUtilities.image2Icon(o.getIcon(1, false))));
/* 379:379 */       result.add(item);
/* 380:    */     }
/* 381:    */     
/* 382:382 */     return result;
/* 383:    */   }
/* 384:    */   
/* 385:    */ 
/* 386:    */   private static final class OpenWithCommand
/* 387:    */     extends JCommand<ATsCollectionView>
/* 388:    */   {
/* 389:    */     public void execute(ATsCollectionView component)
/* 390:    */       throws Exception
/* 391:    */     {}
/* 392:    */     
/* 393:    */     public boolean isEnabled(ATsCollectionView component)
/* 394:    */     {
/* 395:395 */       return component.getSelectionSize() == 1;
/* 396:    */     }
/* 397:    */     
/* 398:    */     public JCommand.ActionAdapter toAction(ATsCollectionView component)
/* 399:    */     {
/* 400:400 */       return super.toAction(component).withWeakPropertyChangeListener(component, new String[] { "selection" });
/* 401:    */     }
/* 402:    */   }
/* 403:    */   
/* 404:    */   public class TsActionMouseAdapter extends MouseAdapter {
/* 405:    */     public TsActionMouseAdapter() {}
/* 406:    */     
/* 407:    */     public void mouseClicked(MouseEvent e) {
/* 408:408 */       if ((e.getClickCount() > 1) && (selection.length > 0)) {
/* 409:409 */         (tsAction != null ? tsAction : DemetraUI.getDefault().getTsAction()).open(selection[0]);
/* 410:    */       }
/* 411:    */     }
/* 412:    */   }
/* 413:    */   
/* 414:    */   protected class TsFactoryObserver implements Observer
/* 415:    */   {
/* 416:416 */     final AtomicBoolean dirty = new AtomicBoolean(false);
/* 417:    */     
/* 418:    */     protected TsFactoryObserver() {}
/* 419:    */     
/* 420:420 */     public void update(Observable o, Object arg) { if ((arg instanceof TsEvent)) {
/* 421:421 */         TsEvent event = (TsEvent)arg;
/* 422:422 */         if (((event.isCollection()) && (collection.equals(tscollection))) || (
/* 423:423 */           (event.isSeries()) && (collection.contains(ts)) && 
/* 424:424 */           (!dirty.getAndSet(true)))) {
/* 425:425 */           SwingUtilities.invokeLater(new Runnable()
/* 426:    */           {
/* 427:    */ 
/* 428:    */             public void run()
/* 429:    */             {
/* 430:430 */               dirty.set(false);
/* 431:431 */               Ts[] oldSelection = selection;
/* 432:432 */               selection = retainTsCollection(selection);
/* 433:433 */               firePropertyChange("tsCollection", null, collection);
/* 434:434 */               firePropertyChange("selection", oldSelection, selection);
/* 435:    */             }
/* 436:    */           });
/* 437:    */         }
/* 438:    */       }
/* 439:    */     }
/* 440:    */   }
/* 441:    */   
/* 442:    */   public class TsCollectionSelectionListener implements ListSelectionListener
/* 443:    */   {
/* 444:    */     public TsCollectionSelectionListener() {}
/* 445:    */     
/* 446:446 */     protected boolean enabled = true;
/* 447:    */     
/* 448:    */     public void setEnabled(boolean enabled) {
/* 449:449 */       this.enabled = enabled;
/* 450:    */     }
/* 451:    */     
/* 452:    */     protected int indexToModel(int index) {
/* 453:453 */       return index;
/* 454:    */     }
/* 455:    */     
/* 456:    */     protected int indexToView(int index) {
/* 457:457 */       return index;
/* 458:    */     }
/* 459:    */     
/* 460:    */     protected void selectionChanged(ListSelectionModel model) {
/* 461:461 */       int iMin = model.getMinSelectionIndex();
/* 462:462 */       int iMax = model.getMaxSelectionIndex();
/* 463:    */       
/* 464:464 */       if ((iMin == -1) || (iMax == -1)) {
/* 465:465 */         setSelection(null);
/* 466:    */       }
/* 467:    */       
/* 468:468 */       List<Ts> selected = Lists.newArrayListWithCapacity(1 + (iMax - iMin));
/* 469:469 */       for (int i = iMin; i <= iMax; i++) {
/* 470:470 */         if (model.isSelectedIndex(i)) {
/* 471:471 */           selected.add(collection.get(indexToModel(i)));
/* 472:    */         }
/* 473:    */       }
/* 474:474 */       setSelection((Ts[])Iterables.toArray(selected, Ts.class));
/* 475:    */     }
/* 476:    */     
/* 477:    */     public void changeSelection(ListSelectionModel model) {
/* 478:478 */       model.clearSelection();
/* 479:479 */       for (Ts o : selection) {
/* 480:480 */         int index = indexToView(collection.indexOf(o));
/* 481:481 */         model.addSelectionInterval(index, index);
/* 482:    */       }
/* 483:    */     }
/* 484:    */     
/* 485:    */     public void valueChanged(ListSelectionEvent e)
/* 486:    */     {
/* 487:487 */       if ((enabled) && (!e.getValueIsAdjusting())) {
/* 488:488 */         enabled = false;
/* 489:489 */         selectionChanged((ListSelectionModel)e.getSource());
/* 490:490 */         enabled = true;
/* 491:    */       }
/* 492:    */     }
/* 493:    */   }
/* 494:    */   
/* 495:    */   public class TsCollectionTransferHandler extends TransferHandler {
/* 496:    */     public TsCollectionTransferHandler() {}
/* 497:    */     
/* 498:    */     public int getSourceActions(JComponent c) {
/* 499:499 */       TsDragRenderer r = selection.length < 10 ? TsDragRenderer.asChart() : TsDragRenderer.asCount();
/* 500:500 */       Image image = r.getTsDragRendererImage(Arrays.asList(selection));
/* 501:501 */       setDragImage(image);
/* 502:502 */       return 1;
/* 503:    */     }
/* 504:    */     
/* 505:    */     protected Transferable createTransferable(JComponent c)
/* 506:    */     {
/* 507:507 */       return transferableOnSelection();
/* 508:    */     }
/* 509:    */     
/* 510:    */     public boolean canImport(TransferHandler.TransferSupport support)
/* 511:    */     {
/* 512:512 */       boolean result = (!getTsUpdateMode().isReadOnly()) && 
/* 513:513 */         (TssTransferSupport.getDefault().canImport(support.getDataFlavors()));
/* 514:514 */       if ((result) && (support.isDrop())) {
/* 515:515 */         support.setDropAction(1);
/* 516:    */       }
/* 517:517 */       return result;
/* 518:    */     }
/* 519:    */     
/* 520:    */     public boolean importData(TransferHandler.TransferSupport support)
/* 521:    */     {
/* 522:522 */       TsCollection col = TssTransferSupport.getDefault().toTsCollection(support.getTransferable());
/* 523:523 */       if (col != null) {
/* 524:524 */         col.query(TsInformationType.All);
/* 525:525 */         if (!col.isEmpty()) {
/* 526:526 */           getTsUpdateMode().update(getTsCollection(), col);
/* 527:    */         }
/* 528:528 */         return true;
/* 529:    */       }
/* 530:530 */       return false;
/* 531:    */     }
/* 532:    */   }
/* 533:    */ }
