/*  1:   */ package ec.ui.commands;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.design.UtilityClass;
/*  4:   */ import ec.ui.interfaces.IColorSchemeAble;
/*  5:   */ import ec.util.chart.ColorScheme;
/*  6:   */ import ec.util.various.swing.JCommand;
/*  7:   */ import java.util.Objects;
/*  8:   */ import javax.annotation.Nonnull;
/*  9:   */ import javax.annotation.Nullable;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ @UtilityClass({IColorSchemeAble.class})
/* 36:   */ public final class ColorSchemeCommand
/* 37:   */ {
/* 38:   */   @Nonnull
/* 39:   */   public static JCommand<IColorSchemeAble> applyColorScheme(@Nullable ColorScheme colorScheme)
/* 40:   */   {
/* 41:41 */     return new ApplyColorSchemeCommand(colorScheme);
/* 42:   */   }
/* 43:   */   
/* 44:   */   private static final class ApplyColorSchemeCommand extends ComponentCommand<IColorSchemeAble>
/* 45:   */   {
/* 46:   */     private final ColorScheme colorScheme;
/* 47:   */     
/* 48:   */     public ApplyColorSchemeCommand(@Nullable ColorScheme colorScheme)
/* 49:   */     {
/* 50:50 */       super();
/* 51:51 */       this.colorScheme = colorScheme;
/* 52:   */     }
/* 53:   */     
/* 54:   */     public boolean isSelected(IColorSchemeAble component)
/* 55:   */     {
/* 56:56 */       return Objects.equals(colorScheme, component.getColorScheme());
/* 57:   */     }
/* 58:   */     
/* 59:   */     public void execute(IColorSchemeAble component)
/* 60:   */     {
/* 61:61 */       component.setColorScheme(colorScheme);
/* 62:   */     }
/* 63:   */   }
/* 64:   */ }
