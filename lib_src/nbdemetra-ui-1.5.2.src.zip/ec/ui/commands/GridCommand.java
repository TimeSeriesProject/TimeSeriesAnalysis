/*  1:   */ package ec.ui.commands;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.design.UtilityClass;
/*  4:   */ import ec.ui.interfaces.IZoomableGrid;
/*  5:   */ import ec.util.various.swing.JCommand;
/*  6:   */ import javax.annotation.Nonnull;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ @UtilityClass({IZoomableGrid.class})
/* 29:   */ public class GridCommand
/* 30:   */ {
/* 31:   */   @Nonnull
/* 32:   */   public static JCommand<IZoomableGrid> applyZoomRatio(int zoomRatio)
/* 33:   */   {
/* 34:34 */     return new ZoomRatioCommand(zoomRatio);
/* 35:   */   }
/* 36:   */   
/* 37:   */   @Nonnull
/* 38:   */   public static JCommand<IZoomableGrid> applyColorScale(double scale) {
/* 39:39 */     return new ColorScaleCommand(scale);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static final class ZoomRatioCommand extends ComponentCommand<IZoomableGrid>
/* 43:   */   {
/* 44:   */     private final int zoomRatio;
/* 45:   */     
/* 46:   */     public ZoomRatioCommand(int zoomRatio)
/* 47:   */     {
/* 48:48 */       super();
/* 49:49 */       this.zoomRatio = zoomRatio;
/* 50:   */     }
/* 51:   */     
/* 52:   */     public boolean isSelected(IZoomableGrid component)
/* 53:   */     {
/* 54:54 */       return zoomRatio == component.getZoomRatio();
/* 55:   */     }
/* 56:   */     
/* 57:   */     public void execute(IZoomableGrid component) throws Exception
/* 58:   */     {
/* 59:59 */       component.setZoomRatio(zoomRatio);
/* 60:   */     }
/* 61:   */   }
/* 62:   */   
/* 63:   */   public static final class ColorScaleCommand extends ComponentCommand<IZoomableGrid>
/* 64:   */   {
/* 65:   */     private final double colorScale;
/* 66:   */     
/* 67:   */     public ColorScaleCommand(double colorScale) {
/* 68:68 */       super();
/* 69:69 */       this.colorScale = colorScale;
/* 70:   */     }
/* 71:   */     
/* 72:   */     public boolean isSelected(IZoomableGrid component)
/* 73:   */     {
/* 74:74 */       return colorScale == component.getColorScale();
/* 75:   */     }
/* 76:   */     
/* 77:   */     public void execute(IZoomableGrid component) throws Exception
/* 78:   */     {
/* 79:79 */       component.setColorScale(colorScale);
/* 80:   */     }
/* 81:   */   }
/* 82:   */ }
