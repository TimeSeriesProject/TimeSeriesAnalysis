/*   1:    */ package ec.ui.commands;
/*   2:    */ 
/*   3:    */ import com.toedter.components.JSpinField;
/*   4:    */ import ec.tss.TsCollection;
/*   5:    */ import ec.tss.TsFactory;
/*   6:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   7:    */ import ec.tstoolkit.design.UtilityClass;
/*   8:    */ import ec.ui.interfaces.ITsGrowthChart;
/*   9:    */ import ec.ui.interfaces.ITsGrowthChart.GrowthKind;
/*  10:    */ import ec.util.various.swing.JCommand;
/*  11:    */ import java.awt.Dimension;
/*  12:    */ import java.awt.FlowLayout;
/*  13:    */ import java.awt.Toolkit;
/*  14:    */ import java.awt.datatransfer.Clipboard;
/*  15:    */ import java.awt.datatransfer.Transferable;
/*  16:    */ import java.util.Arrays;
/*  17:    */ import java.util.EnumMap;
/*  18:    */ import javax.annotation.Nonnull;
/*  19:    */ import javax.swing.BorderFactory;
/*  20:    */ import javax.swing.JPanel;
/*  21:    */ import org.openide.DialogDisplayer;
/*  22:    */ import org.openide.NotifyDescriptor;
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ @UtilityClass({ITsGrowthChart.class})
/*  48:    */ public final class TsGrowthChartCommand
/*  49:    */ {
/*  50:    */   @Nonnull
/*  51:    */   public static JCommand<ITsGrowthChart> copyGrowthData()
/*  52:    */   {
/*  53: 53 */     return CopyGrowthData.INSTANCE;
/*  54:    */   }
/*  55:    */   
/*  56:    */   @Nonnull
/*  57:    */   public static JCommand<ITsGrowthChart> applyGrowthKind(@Nonnull ITsGrowthChart.GrowthKind growthKind) {
/*  58: 58 */     return (JCommand)ApplyGrowthKind.VALUES.get(growthKind);
/*  59:    */   }
/*  60:    */   
/*  61:    */   @Nonnull
/*  62:    */   public static JCommand<ITsGrowthChart> editLastYears() {
/*  63: 63 */     return EditLastYearsCommand.INSTANCE;
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static final class CopyGrowthData
/*  67:    */     extends ComponentCommand<ITsGrowthChart>
/*  68:    */   {
/*  69: 69 */     public static final CopyGrowthData INSTANCE = new CopyGrowthData();
/*  70:    */     
/*  71:    */     public CopyGrowthData() {
/*  72: 72 */       super();
/*  73:    */     }
/*  74:    */     
/*  75:    */     public boolean isEnabled(ITsGrowthChart component)
/*  76:    */     {
/*  77: 77 */       return component.getSelectionSize() > 0;
/*  78:    */     }
/*  79:    */     
/*  80:    */     public void execute(ITsGrowthChart component) throws Exception
/*  81:    */     {
/*  82: 82 */       TsCollection tmp = TsFactory.instance.createTsCollection();
/*  83: 83 */       tmp.quietAppend(Arrays.asList(component.getGrowthData()));
/*  84: 84 */       Transferable transferable = TssTransferSupport.getDefault().fromTsCollection(tmp);
/*  85: 85 */       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(transferable, null);
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */   private static final class ApplyGrowthKind
/*  92:    */     extends ComponentCommand<ITsGrowthChart>
/*  93:    */   {
/*  94: 94 */     public static final EnumMap<ITsGrowthChart.GrowthKind, ApplyGrowthKind> VALUES = new EnumMap(ITsGrowthChart.GrowthKind.class);
/*  95: 95 */     static { for (ITsGrowthChart.GrowthKind o : ITsGrowthChart.GrowthKind.values()) {
/*  96: 96 */         VALUES.put(o, new ApplyGrowthKind(o));
/*  97:    */       }
/*  98:    */     }
/*  99:    */     
/* 100:    */     private final ITsGrowthChart.GrowthKind value;
/* 101:    */     public ApplyGrowthKind(ITsGrowthChart.GrowthKind value)
/* 102:    */     {
/* 103:103 */       super();
/* 104:104 */       this.value = value;
/* 105:    */     }
/* 106:    */     
/* 107:    */     public boolean isSelected(ITsGrowthChart component)
/* 108:    */     {
/* 109:109 */       return component.getGrowthKind() == value;
/* 110:    */     }
/* 111:    */     
/* 112:    */     public void execute(ITsGrowthChart component) throws Exception
/* 113:    */     {
/* 114:114 */       component.setGrowthKind(value);
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static final class EditLastYearsCommand extends JCommand<ITsGrowthChart>
/* 119:    */   {
/* 120:120 */     public static final EditLastYearsCommand INSTANCE = new EditLastYearsCommand();
/* 121:    */     
/* 122:    */     public void execute(ITsGrowthChart component) throws Exception
/* 123:    */     {
/* 124:124 */       JSpinField editor = new JSpinField();
/* 125:125 */       editor.setMinimum(0);
/* 126:126 */       editor.setValue(component.getLastYears());
/* 127:127 */       editor.setPreferredSize(new Dimension(100, getPreferredSize()height));
/* 128:128 */       JPanel p = new JPanel(new FlowLayout());
/* 129:129 */       p.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));
/* 130:130 */       p.add(editor);
/* 131:131 */       NotifyDescriptor descriptor = new NotifyDescriptor(p, "Edit last years", 2, 1, null, null);
/* 132:132 */       if (DialogDisplayer.getDefault().notify(descriptor) == NotifyDescriptor.OK_OPTION) {
/* 133:133 */         component.setLastYears(editor.getValue());
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */ }
