/*   1:    */ package ec.ui.commands;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.properties.DataFormatComponent2;
/*   4:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   5:    */ import ec.tstoolkit.design.UtilityClass;
/*   6:    */ import ec.ui.interfaces.ITsControl;
/*   7:    */ import ec.ui.interfaces.ITsPrinter;
/*   8:    */ import ec.util.various.swing.JCommand;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.FlowLayout;
/*  11:    */ import java.beans.PropertyChangeEvent;
/*  12:    */ import java.beans.PropertyChangeListener;
/*  13:    */ import javax.annotation.Nonnull;
/*  14:    */ import javax.swing.BorderFactory;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import org.openide.DialogDisplayer;
/*  18:    */ import org.openide.NotifyDescriptor;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ @UtilityClass({ITsControl.class})
/*  43:    */ public final class TsControlCommand
/*  44:    */ {
/*  45:    */   @Nonnull
/*  46:    */   public static JCommand<ITsControl> printPreview()
/*  47:    */   {
/*  48: 48 */     return PrintPreviewCommand.INSTANCE;
/*  49:    */   }
/*  50:    */   
/*  51:    */   @Nonnull
/*  52:    */   public static JCommand<ITsControl> editDataFormat() {
/*  53: 53 */     return EditDataFormatCommand.INSTANCE;
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static final class PrintPreviewCommand
/*  57:    */     extends JCommand<ITsControl>
/*  58:    */   {
/*  59: 59 */     public static final PrintPreviewCommand INSTANCE = new PrintPreviewCommand();
/*  60:    */     
/*  61:    */     public void execute(ITsControl component) throws Exception
/*  62:    */     {
/*  63: 63 */       ITsPrinter printer = component.getPrinter();
/*  64: 64 */       if (printer != null) {
/*  65: 65 */         printer.printPreview();
/*  66:    */       }
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static final class DefaultDataFormatCommand extends JCommand<ITsControl>
/*  71:    */   {
/*  72: 72 */     public static final DefaultDataFormatCommand INSTANCE = new DefaultDataFormatCommand();
/*  73:    */     
/*  74:    */     public void execute(ITsControl component)
/*  75:    */     {
/*  76: 76 */       component.setDataFormat(null);
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   private static final class EditDataFormatCommand extends JCommand<ITsControl>
/*  81:    */   {
/*  82: 82 */     public static final EditDataFormatCommand INSTANCE = new EditDataFormatCommand();
/*  83:    */     
/*  84:    */     public void execute(ITsControl component)
/*  85:    */     {
/*  86: 86 */       final DataFormatComponent2 editor = new DataFormatComponent2();
/*  87: 87 */       Dimension preferedSize = editor.getPreferredSize();
/*  88: 88 */       editor.setPreferredSize(new Dimension(400, height));
/*  89: 89 */       JPanel p = new JPanel(new FlowLayout());
/*  90: 90 */       p.setBorder(BorderFactory.createEmptyBorder(25, 10, 10, 10));
/*  91: 91 */       p.add(editor);
/*  92: 92 */       NotifyDescriptor descriptor = new NotifyDescriptor(p, "Edit data format", 2, 1, null, null);
/*  93: 93 */       descriptor.addPropertyChangeListener(new PropertyChangeListener()
/*  94:    */       {
/*  95:    */         public void propertyChange(PropertyChangeEvent evt) {
/*  96: 96 */           String p = evt.getPropertyName();
/*  97: 97 */           if (p.equals("value")) {
/*  98: 98 */             editor.setPreviewVisible(false);
/*  99:    */           }
/* 100:    */         }
/* 101:101 */       });
/* 102:102 */       editor.setDataFormat(component.getDataFormat());
/* 103:103 */       if (component.getDataFormat() != null) {
/* 104:104 */         JButton b = new JButton(TsControlCommand.DefaultDataFormatCommand.INSTANCE.toAction(component));
/* 105:105 */         b.setText("Restore");
/* 106:106 */         descriptor.setAdditionalOptions(new Object[] { b });
/* 107:    */       }
/* 108:108 */       if ((DialogDisplayer.getDefault().notify(descriptor) == NotifyDescriptor.OK_OPTION) && (!editor.getDataFormat().equals(component.getDataFormat()))) {
/* 109:109 */         component.setDataFormat(editor.getDataFormat());
/* 110:    */       }
/* 111:    */     }
/* 112:    */   }
/* 113:    */ }
