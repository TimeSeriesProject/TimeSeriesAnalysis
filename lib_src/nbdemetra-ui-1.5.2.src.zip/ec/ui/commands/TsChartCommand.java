/*   1:    */ package ec.ui.commands;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.MonikerUI;
/*   4:    */ import ec.nbdemetra.ui.tools.ChartTopComponent;
/*   5:    */ import ec.tss.Ts;
/*   6:    */ import ec.tss.TsCollection;
/*   7:    */ import ec.tss.TsFactory;
/*   8:    */ import ec.tss.TsStatus;
/*   9:    */ import ec.tss.tsproviders.utils.DataFormat;
/*  10:    */ import ec.tstoolkit.design.UtilityClass;
/*  11:    */ import ec.tstoolkit.timeseries.TsAggregationType;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  13:    */ import ec.tstoolkit.timeseries.simplets.TsDataBlock;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsDataCollector;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  16:    */ import ec.tstoolkit.timeseries.simplets.TsObservation;
/*  17:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  18:    */ import ec.tstoolkit.timeseries.simplets.YearIterator;
/*  19:    */ import ec.tstoolkit.utilities.Arrays2;
/*  20:    */ import ec.ui.ATsChart;
/*  21:    */ import ec.ui.interfaces.ITsChart;
/*  22:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*  23:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  24:    */ import ec.util.various.swing.JCommand;
/*  25:    */ import java.util.Calendar;
/*  26:    */ import javax.annotation.Nonnull;
/*  27:    */ import org.openide.util.NbCollections;
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ @UtilityClass({ITsChart.class})
/*  53:    */ public final class TsChartCommand
/*  54:    */ {
/*  55:    */   @Nonnull
/*  56:    */   public static JCommand<ITsChart> toggleTitleVisibility()
/*  57:    */   {
/*  58: 58 */     return ToggleTitleVisibilityCommand.INSTANCE;
/*  59:    */   }
/*  60:    */   
/*  61:    */   @Nonnull
/*  62:    */   public static JCommand<ITsChart> toggleLegendVisibility() {
/*  63: 63 */     return ToggleLegendVisibilityCommand.INSTANCE;
/*  64:    */   }
/*  65:    */   
/*  66:    */   @Nonnull
/*  67:    */   public static JCommand<ITsChart> applyLineThickNess(@Nonnull ITsChart.LinesThickness thickness) {
/*  68: 68 */     return ITsChart.LinesThickness.Thick.equals(thickness) ? ApplyLineThickNessCommand.THICK : ApplyLineThickNessCommand.THIN;
/*  69:    */   }
/*  70:    */   
/*  71:    */   @Nonnull
/*  72:    */   public static JCommand<ITsChart> showAll() {
/*  73: 73 */     return ShowAllCommand.INSTANCE;
/*  74:    */   }
/*  75:    */   
/*  76:    */   @Nonnull
/*  77:    */   public static JCommand<ITsChart> splitIntoYearlyComponents() {
/*  78: 78 */     return SplitIntoYearlyComponentsCommand.INSTANCE;
/*  79:    */   }
/*  80:    */   
/*  81:    */   private static final class ToggleTitleVisibilityCommand
/*  82:    */     extends ComponentCommand<ITsChart>
/*  83:    */   {
/*  84: 84 */     public static final ToggleTitleVisibilityCommand INSTANCE = new ToggleTitleVisibilityCommand();
/*  85:    */     
/*  86:    */     public ToggleTitleVisibilityCommand() {
/*  87: 87 */       super();
/*  88:    */     }
/*  89:    */     
/*  90:    */     public boolean isSelected(ITsChart component)
/*  91:    */     {
/*  92: 92 */       return component.isTitleVisible();
/*  93:    */     }
/*  94:    */     
/*  95:    */     public void execute(ITsChart component) throws Exception
/*  96:    */     {
/*  97: 97 */       component.setTitleVisible(!component.isTitleVisible());
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static final class ToggleLegendVisibilityCommand extends ComponentCommand<ITsChart>
/* 102:    */   {
/* 103:103 */     public static final ToggleLegendVisibilityCommand INSTANCE = new ToggleLegendVisibilityCommand();
/* 104:    */     
/* 105:    */     public ToggleLegendVisibilityCommand() {
/* 106:106 */       super();
/* 107:    */     }
/* 108:    */     
/* 109:    */     public boolean isSelected(ITsChart component)
/* 110:    */     {
/* 111:111 */       return component.isLegendVisible();
/* 112:    */     }
/* 113:    */     
/* 114:    */     public void execute(ITsChart component) throws Exception
/* 115:    */     {
/* 116:116 */       component.setLegendVisible(!component.isLegendVisible());
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static final class ApplyLineThickNessCommand extends ComponentCommand<ITsChart>
/* 121:    */   {
/* 122:122 */     public static final ApplyLineThickNessCommand THICK = new ApplyLineThickNessCommand(ITsChart.LinesThickness.Thick);
/* 123:123 */     public static final ApplyLineThickNessCommand THIN = new ApplyLineThickNessCommand(ITsChart.LinesThickness.Thin);
/* 124:    */     private final ITsChart.LinesThickness value;
/* 125:    */     
/* 126:    */     public ApplyLineThickNessCommand(ITsChart.LinesThickness value)
/* 127:    */     {
/* 128:128 */       super();
/* 129:129 */       this.value = value;
/* 130:    */     }
/* 131:    */     
/* 132:    */     public boolean isSelected(ITsChart component)
/* 133:    */     {
/* 134:134 */       return component.getLinesThickness() == value;
/* 135:    */     }
/* 136:    */     
/* 137:    */     public void execute(ITsChart component) throws Exception
/* 138:    */     {
/* 139:139 */       component.setLinesThickness(value);
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:    */   private static final class ShowAllCommand extends JCommand<ITsChart>
/* 144:    */   {
/* 145:145 */     public static final ShowAllCommand INSTANCE = new ShowAllCommand();
/* 146:    */     
/* 147:    */     public void execute(ITsChart component) throws Exception
/* 148:    */     {
/* 149:149 */       component.showAll();
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   private static final class SplitIntoYearlyComponentsCommand extends ComponentCommand<ITsChart>
/* 154:    */   {
/* 155:155 */     public static final SplitIntoYearlyComponentsCommand INSTANCE = new SplitIntoYearlyComponentsCommand();
/* 156:    */     
/* 157:    */     public SplitIntoYearlyComponentsCommand() {
/* 158:158 */       super();
/* 159:    */     }
/* 160:    */     
/* 161:    */     public boolean isEnabled(ITsChart component)
/* 162:    */     {
/* 163:163 */       Ts[] selection = component.getSelection();
/* 164:164 */       return (selection.length == 1) && 
/* 165:165 */         (selection[0].hasData() == TsStatus.Valid) && (
/* 166:166 */         selection[0].getTsData().getDomain().getYearsCount() > 1);
/* 167:    */     }
/* 168:    */     
/* 169:    */     public void execute(ITsChart component) throws Exception
/* 170:    */     {
/* 171:171 */       Ts[] selection = component.getSelection();
/* 172:172 */       if (Arrays2.isNullOrEmpty(selection)) {
/* 173:173 */         return;
/* 174:    */       }
/* 175:175 */       Ts ts = selection[0];
/* 176:176 */       ChartTopComponent c = new ChartTopComponent();
/* 177:177 */       c.getChart().setTitle(ts.getName());
/* 178:178 */       c.getChart().setDataFormat(new DataFormat(null, "MMM", null));
/* 179:179 */       c.getChart().setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 180:180 */       c.getChart().setTsCollection(split(ts));
/* 181:181 */       c.setIcon(MonikerUI.getDefault().getImage(ts));
/* 182:182 */       c.open();
/* 183:183 */       c.requestActive();
/* 184:    */     }
/* 185:    */     
/* 186:    */     private TsCollection split(Ts ts) {
/* 187:187 */       TsCollection result = TsFactory.instance.createTsCollection();
/* 188:188 */       Calendar cal = Calendar.getInstance();
/* 189:189 */       YearIterator yearIterator = new YearIterator(ts.getTsData());
/* 190:190 */       for (TsDataBlock o : NbCollections.iterable(yearIterator)) {
/* 191:191 */         TsDataCollector dc = new TsDataCollector();
/* 192:192 */         for (TsObservation obs : NbCollections.iterable(o.observations())) {
/* 193:193 */           cal.setTime(obs.getPeriod().middle());
/* 194:194 */           cal.set(1, 2000);
/* 195:195 */           dc.addObservation(cal.getTime(), obs.getValue());
/* 196:    */         }
/* 197:197 */         String name = String.valueOf(start.getYear());
/* 198:198 */         TsData tmp = dc.make(start.getFrequency(), TsAggregationType.None);
/* 199:199 */         result.quietAdd(TsFactory.instance.createTs(name, null, tmp));
/* 200:    */       }
/* 201:201 */       return result;
/* 202:    */     }
/* 203:    */   }
/* 204:    */ }
