/*   1:    */ package ec.ui.commands;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import com.google.common.collect.Iterables;
/*   5:    */ import com.google.common.collect.Lists;
/*   6:    */ import ec.nbdemetra.ui.DemetraUI;
/*   7:    */ import ec.nbdemetra.ui.tsaction.ITsAction;
/*   8:    */ import ec.tss.Ts;
/*   9:    */ import ec.tss.TsCollection;
/*  10:    */ import ec.tss.TsFactory;
/*  11:    */ import ec.tss.TsInformationType;
/*  12:    */ import ec.tss.TsMoniker;
/*  13:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  14:    */ import ec.tss.tsproviders.DataSet;
/*  15:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  16:    */ import ec.tss.tsproviders.TsProviders;
/*  17:    */ import ec.tstoolkit.design.UtilityClass;
/*  18:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  19:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  20:    */ import ec.tstoolkit.utilities.Arrays2;
/*  21:    */ import ec.ui.interfaces.ITsCollectionView;
/*  22:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  23:    */ import ec.util.various.swing.JCommand;
/*  24:    */ import ec.util.various.swing.JCommand.ActionAdapter;
/*  25:    */ import java.awt.Component;
/*  26:    */ import java.awt.Toolkit;
/*  27:    */ import java.awt.datatransfer.Clipboard;
/*  28:    */ import java.awt.datatransfer.Transferable;
/*  29:    */ import java.awt.event.ActionEvent;
/*  30:    */ import java.beans.PropertyChangeEvent;
/*  31:    */ import java.beans.PropertyChangeListener;
/*  32:    */ import java.util.Arrays;
/*  33:    */ import java.util.EnumMap;
/*  34:    */ import java.util.List;
/*  35:    */ import javax.annotation.Nonnull;
/*  36:    */ import javax.swing.AbstractAction;
/*  37:    */ import javax.swing.JButton;
/*  38:    */ import org.openide.DialogDisplayer;
/*  39:    */ import org.openide.NotifyDescriptor;
/*  40:    */ import org.openide.NotifyDescriptor.InputLine;
/*  41:    */ import org.openide.util.WeakListeners;
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ @UtilityClass({ITsCollectionView.class})
/*  64:    */ public final class TsCollectionViewCommand
/*  65:    */ {
/*  66:    */   @Nonnull
/*  67:    */   public static JCommand<ITsCollectionView> rename()
/*  68:    */   {
/*  69: 69 */     return RenameCommand.INSTANCE;
/*  70:    */   }
/*  71:    */   
/*  72:    */   @Nonnull
/*  73:    */   public static JCommand<ITsCollectionView> open() {
/*  74: 74 */     return OpenCommand.INSTANCE;
/*  75:    */   }
/*  76:    */   
/*  77:    */   @Nonnull
/*  78:    */   public static JCommand<ITsCollectionView> openWith(@Nonnull ITsAction tsAction) {
/*  79: 79 */     return new OpenWithCommand(tsAction);
/*  80:    */   }
/*  81:    */   
/*  82:    */   @Nonnull
/*  83:    */   public static JCommand<ITsCollectionView> copy() {
/*  84: 84 */     return CopyCommand.INSTANCE;
/*  85:    */   }
/*  86:    */   
/*  87:    */   @Nonnull
/*  88:    */   public static JCommand<ITsCollectionView> copyAll() {
/*  89: 89 */     return CopyAllCommand.INSTANCE;
/*  90:    */   }
/*  91:    */   
/*  92:    */   @Nonnull
/*  93:    */   public static JCommand<ITsCollectionView> paste() {
/*  94: 94 */     return PasteCommand.INSTANCE;
/*  95:    */   }
/*  96:    */   
/*  97:    */   @Nonnull
/*  98:    */   public static JCommand<ITsCollectionView> delete() {
/*  99: 99 */     return DeleteCommand.INSTANCE;
/* 100:    */   }
/* 101:    */   
/* 102:    */   @Nonnull
/* 103:    */   public static JCommand<ITsCollectionView> clear() {
/* 104:104 */     return ClearCommand.INSTANCE;
/* 105:    */   }
/* 106:    */   
/* 107:    */   @Nonnull
/* 108:    */   public static JCommand<ITsCollectionView> selectAll() {
/* 109:109 */     return SelectAllCommand.INSTANCE;
/* 110:    */   }
/* 111:    */   
/* 112:    */   @Nonnull
/* 113:    */   public static JCommand<ITsCollectionView> selectByFreq(@Nonnull TsFrequency freq) {
/* 114:114 */     return (JCommand)SelectByFreqCommand.VALUES.get(freq);
/* 115:    */   }
/* 116:    */   
/* 117:    */   @Nonnull
/* 118:    */   public static JCommand<ITsCollectionView> freeze() {
/* 119:119 */     return FreezeCommand.INSTANCE;
/* 120:    */   }
/* 121:    */   
/* 122:    */   private static abstract class SingleSelectionCommand extends ComponentCommand<ITsCollectionView>
/* 123:    */   {
/* 124:    */     public SingleSelectionCommand()
/* 125:    */     {
/* 126:126 */       super();
/* 127:    */     }
/* 128:    */     
/* 129:    */     public boolean isEnabled(ITsCollectionView component)
/* 130:    */     {
/* 131:131 */       return component.getSelectionSize() == 1;
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static abstract class AnySelectionCommand extends ComponentCommand<ITsCollectionView>
/* 136:    */   {
/* 137:    */     public AnySelectionCommand() {
/* 138:138 */       super();
/* 139:    */     }
/* 140:    */     
/* 141:    */     public boolean isEnabled(ITsCollectionView component)
/* 142:    */     {
/* 143:143 */       return component.getSelectionSize() > 0;
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static abstract class AnyDataCommand extends ComponentCommand<ITsCollectionView>
/* 148:    */   {
/* 149:    */     public AnyDataCommand() {
/* 150:150 */       super();
/* 151:    */     }
/* 152:    */     
/* 153:    */     public boolean isEnabled(ITsCollectionView component)
/* 154:    */     {
/* 155:155 */       return !component.getTsCollection().isEmpty();
/* 156:    */     }
/* 157:    */   }
/* 158:    */   
/* 159:    */   private static final class RenameCommand extends TsCollectionViewCommand.SingleSelectionCommand
/* 160:    */   {
/* 161:161 */     public static final RenameCommand INSTANCE = new RenameCommand();
/* 162:    */     
/* 163:    */     public void execute(final ITsCollectionView component) throws Exception
/* 164:    */     {
/* 165:165 */       Ts[] selection = component.getSelection();
/* 166:166 */       if (Arrays2.isNullOrEmpty(selection)) {
/* 167:167 */         return;
/* 168:    */       }
/* 169:169 */       final Ts ts = selection[0];
/* 170:170 */       NotifyDescriptor.InputLine descriptor = new NotifyDescriptor.InputLine("New name:", "Rename time series");
/* 171:171 */       descriptor.setInputText(ts.getName());
/* 172:172 */       if (!ts.getMoniker().isAnonymous()) {
/* 173:173 */         descriptor.setAdditionalOptions(new Object[] { new JButton(new AbstractAction("Restore")
/* 174:    */         {
/* 175:    */           public void actionPerformed(ActionEvent e) {
/* 176:176 */             Optional<IDataSourceProvider> provider = TsProviders.lookup(IDataSourceProvider.class, ts.getMoniker());
/* 177:177 */             if (provider.isPresent()) {
/* 178:178 */               DataSet dataSet = ((IDataSourceProvider)provider.get()).toDataSet(ts.getMoniker());
/* 179:179 */               if (dataSet != null) {
/* 180:180 */                 component.getTsCollection().rename(ts, ((IDataSourceProvider)provider.get()).getDisplayName(dataSet));
/* 181:181 */                 TsCollectionViewCommand.RenameCommand.this.fireCollectionChange(component, ts);
/* 182:    */               }
/* 183:    */             }
/* 184:    */           }
/* 185:    */         }) });
/* 186:    */       }
/* 187:187 */       if (DialogDisplayer.getDefault().notify(descriptor) == NotifyDescriptor.OK_OPTION) {
/* 188:188 */         component.getTsCollection().rename(ts, descriptor.getInputText());
/* 189:189 */         fireCollectionChange(component, ts);
/* 190:    */       }
/* 191:    */     }
/* 192:    */     
/* 193:193 */     private final TsCollection fake = TsFactory.instance.createTsCollection();
/* 194:    */     
/* 195:    */     private void fireCollectionChange(ITsCollectionView component, Ts ts) {
/* 196:196 */       TsCollection real = component.getTsCollection();
/* 197:197 */       component.setTsCollection(fake);
/* 198:198 */       component.setTsCollection(real);
/* 199:199 */       component.setSelection(new Ts[] { ts });
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */ 
/* 204:    */ 
/* 205:    */   private static final class OpenCommand
/* 206:    */     extends TsCollectionViewCommand.SingleSelectionCommand
/* 207:    */   {
/* 208:208 */     public static final OpenCommand INSTANCE = new OpenCommand();
/* 209:    */     
/* 210:    */     public void execute(ITsCollectionView component) throws Exception
/* 211:    */     {
/* 212:212 */       Ts[] selection = component.getSelection();
/* 213:213 */       if (Arrays2.isNullOrEmpty(selection)) {
/* 214:214 */         return;
/* 215:    */       }
/* 216:216 */       ITsAction tsAction = component.getTsAction();
/* 217:217 */       (tsAction != null ? tsAction : DemetraUI.getDefault().getTsAction()).open(selection[0]);
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */   private static final class OpenWithCommand extends TsCollectionViewCommand.SingleSelectionCommand
/* 222:    */   {
/* 223:    */     private final ITsAction tsAction;
/* 224:    */     
/* 225:    */     public OpenWithCommand(@Nonnull ITsAction tsAction) {
/* 226:226 */       this.tsAction = tsAction;
/* 227:    */     }
/* 228:    */     
/* 229:    */     public void execute(ITsCollectionView component) throws Exception
/* 230:    */     {
/* 231:231 */       Ts[] selection = component.getSelection();
/* 232:232 */       if (Arrays2.isNullOrEmpty(selection)) {
/* 233:233 */         return;
/* 234:    */       }
/* 235:235 */       tsAction.open(selection[0]);
/* 236:    */     }
/* 237:    */   }
/* 238:    */   
/* 239:    */   private static final class CopyCommand extends TsCollectionViewCommand.AnySelectionCommand
/* 240:    */   {
/* 241:241 */     public static final CopyCommand INSTANCE = new CopyCommand();
/* 242:    */     
/* 243:    */     public void execute(ITsCollectionView component) throws Exception
/* 244:    */     {
/* 245:245 */       TsCollection col = TsFactory.instance.createTsCollection();
/* 246:246 */       col.quietAppend(Arrays.asList(component.getSelection()));
/* 247:247 */       Transferable transferable = TssTransferSupport.getDefault().fromTsCollection(col);
/* 248:248 */       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(transferable, null);
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   private static final class CopyAllCommand extends TsCollectionViewCommand.AnyDataCommand
/* 253:    */   {
/* 254:254 */     public static final CopyAllCommand INSTANCE = new CopyAllCommand();
/* 255:    */     
/* 256:    */     public void execute(ITsCollectionView component) throws Exception
/* 257:    */     {
/* 258:258 */       Transferable transferable = TssTransferSupport.getDefault().fromTsCollection(component.getTsCollection());
/* 259:259 */       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(transferable, null);
/* 260:    */     }
/* 261:    */   }
/* 262:    */   
/* 263:    */   private static final class PasteCommand extends JCommand<ITsCollectionView>
/* 264:    */   {
/* 265:265 */     public static final PasteCommand INSTANCE = new PasteCommand();
/* 266:    */     
/* 267:    */     public boolean isEnabled(ITsCollectionView component)
/* 268:    */     {
/* 269:269 */       return (!component.getTsUpdateMode().isReadOnly()) && 
/* 270:270 */         (TssTransferSupport.getDefault().isValidClipboard());
/* 271:    */     }
/* 272:    */     
/* 273:    */     public void execute(ITsCollectionView component) throws Exception
/* 274:    */     {
/* 275:275 */       Transferable transferable = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(component);
/* 276:276 */       TsCollection col = TssTransferSupport.getDefault().toTsCollection(transferable);
/* 277:277 */       if (col != null) {
/* 278:278 */         col.query(TsInformationType.All);
/* 279:279 */         if (!col.isEmpty()) {
/* 280:280 */           component.getTsUpdateMode().update(component.getTsCollection(), col);
/* 281:    */         }
/* 282:    */       }
/* 283:    */     }
/* 284:    */     
/* 285:    */     public JCommand<ITsCollectionView>.ActionAdapter toAction(ITsCollectionView c)
/* 286:    */     {
/* 287:287 */       final JCommand<ITsCollectionView>.ActionAdapter result = super.toAction(c);
/* 288:288 */       if ((c instanceof Component)) {
/* 289:289 */         result.withWeakPropertyChangeListener((Component)c, new String[] { "tsUpdateMode" });
/* 290:    */       }
/* 291:291 */       TssTransferSupport source = TssTransferSupport.getDefault();
/* 292:292 */       PropertyChangeListener realListener = new PropertyChangeListener()
/* 293:    */       {
/* 294:    */         public void propertyChange(PropertyChangeEvent evt) {
/* 295:295 */           result.refreshActionState();
/* 296:    */         }
/* 297:297 */       };
/* 298:298 */       result.putValue("TssTransferSupport", realListener);
/* 299:299 */       source.addPropertyChangeListener("validClipboard", WeakListeners.propertyChange(realListener, source));
/* 300:300 */       return result;
/* 301:    */     }
/* 302:    */   }
/* 303:    */   
/* 304:    */   private static final class DeleteCommand extends ComponentCommand<ITsCollectionView>
/* 305:    */   {
/* 306:306 */     public static final DeleteCommand INSTANCE = new DeleteCommand();
/* 307:    */     
/* 308:    */     public DeleteCommand() {
/* 309:309 */       super();
/* 310:    */     }
/* 311:    */     
/* 312:    */     public boolean isEnabled(ITsCollectionView component)
/* 313:    */     {
/* 314:314 */       return (!component.getTsUpdateMode().isReadOnly()) && (component.getSelectionSize() > 0);
/* 315:    */     }
/* 316:    */     
/* 317:    */     public void execute(ITsCollectionView component) throws Exception
/* 318:    */     {
/* 319:319 */       component.getTsCollection().remove(Arrays.asList(component.getSelection()));
/* 320:    */     }
/* 321:    */   }
/* 322:    */   
/* 323:    */   private static final class ClearCommand extends ComponentCommand<ITsCollectionView>
/* 324:    */   {
/* 325:325 */     public static final ClearCommand INSTANCE = new ClearCommand();
/* 326:    */     
/* 327:    */     public ClearCommand() {
/* 328:328 */       super();
/* 329:    */     }
/* 330:    */     
/* 331:    */     public boolean isEnabled(ITsCollectionView component)
/* 332:    */     {
/* 333:333 */       return (!component.getTsUpdateMode().isReadOnly()) && (!component.getTsCollection().isEmpty());
/* 334:    */     }
/* 335:    */     
/* 336:    */     public void execute(ITsCollectionView component) throws Exception
/* 337:    */     {
/* 338:338 */       component.getTsCollection().clear();
/* 339:    */     }
/* 340:    */   }
/* 341:    */   
/* 342:    */   private static final class SelectAllCommand extends ComponentCommand<ITsCollectionView>
/* 343:    */   {
/* 344:344 */     public static final SelectAllCommand INSTANCE = new SelectAllCommand();
/* 345:    */     
/* 346:    */     public SelectAllCommand() {
/* 347:347 */       super();
/* 348:    */     }
/* 349:    */     
/* 350:    */     public boolean isEnabled(ITsCollectionView component)
/* 351:    */     {
/* 352:352 */       return component.getSelectionSize() != component.getTsCollection().getCount();
/* 353:    */     }
/* 354:    */     
/* 355:    */     public void execute(ITsCollectionView component) throws Exception
/* 356:    */     {
/* 357:357 */       component.setSelection(component.getTsCollection().toArray());
/* 358:    */     }
/* 359:    */   }
/* 360:    */   
/* 361:    */ 
/* 362:    */ 
/* 363:    */   private static final class SelectByFreqCommand
/* 364:    */     extends JCommand<ITsCollectionView>
/* 365:    */   {
/* 366:366 */     public static final EnumMap<TsFrequency, SelectByFreqCommand> VALUES = new EnumMap(TsFrequency.class);
/* 367:367 */     static { for (TsFrequency o : TsFrequency.values()) {
/* 368:368 */         VALUES.put(o, new SelectByFreqCommand(o));
/* 369:    */       }
/* 370:    */     }
/* 371:    */     
/* 372:    */     private final TsFrequency freq;
/* 373:    */     private SelectByFreqCommand(TsFrequency freq)
/* 374:    */     {
/* 375:375 */       this.freq = freq;
/* 376:    */     }
/* 377:    */     
/* 378:    */     public void execute(ITsCollectionView component) throws Exception
/* 379:    */     {
/* 380:380 */       TsCollection col = component.getTsCollection();
/* 381:381 */       List<Ts> tmp = Lists.newArrayListWithCapacity(col.getCount());
/* 382:382 */       for (Ts o : col) {
/* 383:383 */         if ((o.getTsData() != null) && (o.getTsData().getFrequency() == freq)) {
/* 384:384 */           tmp.add(o);
/* 385:    */         }
/* 386:    */       }
/* 387:387 */       component.setSelection((Ts[])Iterables.toArray(tmp, Ts.class));
/* 388:    */     }
/* 389:    */   }
/* 390:    */   
/* 391:    */   private static final class FreezeCommand extends ComponentCommand<ITsCollectionView>
/* 392:    */   {
/* 393:393 */     private static final FreezeCommand INSTANCE = new FreezeCommand();
/* 394:    */     
/* 395:    */     public FreezeCommand() {
/* 396:396 */       super();
/* 397:    */     }
/* 398:    */     
/* 399:    */     public boolean isEnabled(ITsCollectionView component)
/* 400:    */     {
/* 401:401 */       return (component.getSelectionSize() == 1) && (!component.getTsUpdateMode().isReadOnly());
/* 402:    */     }
/* 403:    */     
/* 404:    */     public void execute(ITsCollectionView component) throws Exception
/* 405:    */     {
/* 406:406 */       Ts[] selection = component.getSelection();
/* 407:407 */       if (Arrays2.isNullOrEmpty(selection)) {
/* 408:408 */         return;
/* 409:    */       }
/* 410:410 */       component.getTsCollection().add(selection[0].freeze());
/* 411:    */     }
/* 412:    */   }
/* 413:    */ }
