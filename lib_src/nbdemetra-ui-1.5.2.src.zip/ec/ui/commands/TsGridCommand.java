/*   1:    */ package ec.ui.commands;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.design.UtilityClass;
/*   4:    */ import ec.ui.interfaces.ITsGrid;
/*   5:    */ import ec.ui.interfaces.ITsGrid.Chronology;
/*   6:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*   7:    */ import ec.ui.interfaces.ITsGrid.Orientation;
/*   8:    */ import ec.util.various.swing.JCommand;
/*   9:    */ import java.util.EnumMap;
/*  10:    */ import javax.annotation.Nonnull;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ @UtilityClass({ITsGrid.class})
/*  37:    */ public final class TsGridCommand
/*  38:    */ {
/*  39:    */   @Nonnull
/*  40:    */   public static JCommand<ITsGrid> transpose()
/*  41:    */   {
/*  42: 42 */     return TransposeCommand.INSTANCE;
/*  43:    */   }
/*  44:    */   
/*  45:    */   @Nonnull
/*  46:    */   public static JCommand<ITsGrid> reverseChronology() {
/*  47: 47 */     return ReverseChronologyCommand.INSTANCE;
/*  48:    */   }
/*  49:    */   
/*  50:    */   @Nonnull
/*  51:    */   public static JCommand<ITsGrid> toggleMode() {
/*  52: 52 */     return ToggleModeCommand.INSTANCE;
/*  53:    */   }
/*  54:    */   
/*  55:    */   @Nonnull
/*  56:    */   public static JCommand<ITsGrid> applyMode(ITsGrid.Mode mode) {
/*  57: 57 */     return (JCommand)ApplyModeCommand.VALUES.get(mode);
/*  58:    */   }
/*  59:    */   
/*  60:    */   @Nonnull
/*  61:    */   public static JCommand<ITsGrid> applyZoomRatio(int zoomRatio) {
/*  62: 62 */     return new ZoomRatioCommand(zoomRatio);
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static final class TransposeCommand
/*  66:    */     extends ComponentCommand<ITsGrid>
/*  67:    */   {
/*  68: 68 */     public static final TransposeCommand INSTANCE = new TransposeCommand();
/*  69:    */     
/*  70:    */     public TransposeCommand() {
/*  71: 71 */       super();
/*  72:    */     }
/*  73:    */     
/*  74:    */     public boolean isSelected(ITsGrid component)
/*  75:    */     {
/*  76: 76 */       return component.getOrientation() == ITsGrid.Orientation.REVERSED;
/*  77:    */     }
/*  78:    */     
/*  79:    */     public void execute(ITsGrid component) throws Exception
/*  80:    */     {
/*  81: 81 */       component.setOrientation(component.getOrientation().transpose());
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static final class ReverseChronologyCommand extends ComponentCommand<ITsGrid>
/*  86:    */   {
/*  87: 87 */     public static final ReverseChronologyCommand INSTANCE = new ReverseChronologyCommand();
/*  88:    */     
/*  89:    */     public ReverseChronologyCommand() {
/*  90: 90 */       super();
/*  91:    */     }
/*  92:    */     
/*  93:    */     public boolean isSelected(ITsGrid component)
/*  94:    */     {
/*  95: 95 */       return component.getChronology() == ITsGrid.Chronology.DESCENDING;
/*  96:    */     }
/*  97:    */     
/*  98:    */     public void execute(ITsGrid component) throws Exception
/*  99:    */     {
/* 100:100 */       component.setChronology(component.getChronology().reverse());
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static final class ToggleModeCommand extends ComponentCommand<ITsGrid>
/* 105:    */   {
/* 106:106 */     public static final ToggleModeCommand INSTANCE = new ToggleModeCommand();
/* 107:    */     
/* 108:    */     public ToggleModeCommand() {
/* 109:109 */       super();
/* 110:    */     }
/* 111:    */     
/* 112:    */     public boolean isSelected(ITsGrid component)
/* 113:    */     {
/* 114:114 */       return component.getMode() == ITsGrid.Mode.SINGLETS;
/* 115:    */     }
/* 116:    */     
/* 117:    */     public void execute(ITsGrid component) throws Exception
/* 118:    */     {
/* 119:119 */       component.setMode(component.getMode().toggle());
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */ 
/* 124:    */ 
/* 125:    */   private static final class ApplyModeCommand
/* 126:    */     extends ComponentCommand<ITsGrid>
/* 127:    */   {
/* 128:128 */     public static final EnumMap<ITsGrid.Mode, ApplyModeCommand> VALUES = new EnumMap(ITsGrid.Mode.class);
/* 129:129 */     static { for (ITsGrid.Mode o : ITsGrid.Mode.values()) {
/* 130:130 */         VALUES.put(o, new ApplyModeCommand(o));
/* 131:    */       }
/* 132:    */     }
/* 133:    */     
/* 134:    */     private final ITsGrid.Mode value;
/* 135:    */     public ApplyModeCommand(ITsGrid.Mode value)
/* 136:    */     {
/* 137:137 */       super();
/* 138:138 */       this.value = value;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public boolean isSelected(ITsGrid component)
/* 142:    */     {
/* 143:143 */       return component.getMode() == value;
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void execute(ITsGrid component) throws Exception
/* 147:    */     {
/* 148:148 */       component.setMode(value);
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   private static final class ZoomRatioCommand extends ComponentCommand<ITsGrid>
/* 153:    */   {
/* 154:    */     private final int zoomRatio;
/* 155:    */     
/* 156:    */     public ZoomRatioCommand(int zoomRatio) {
/* 157:157 */       super();
/* 158:158 */       this.zoomRatio = zoomRatio;
/* 159:    */     }
/* 160:    */     
/* 161:    */     public boolean isSelected(ITsGrid component)
/* 162:    */     {
/* 163:163 */       return zoomRatio == component.getZoomRatio();
/* 164:    */     }
/* 165:    */     
/* 166:    */     public void execute(ITsGrid component) throws Exception
/* 167:    */     {
/* 168:168 */       component.setZoomRatio(zoomRatio);
/* 169:    */     }
/* 170:    */   }
/* 171:    */ }
