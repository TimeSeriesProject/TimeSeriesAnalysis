/*  1:   */ package ec.ui.commands;
/*  2:   */ 
/*  3:   */ import ec.util.various.swing.JCommand;
/*  4:   */ import ec.util.various.swing.JCommand.ActionAdapter;
/*  5:   */ import java.awt.Component;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public abstract class ComponentCommand<C>
/* 25:   */   extends JCommand<C>
/* 26:   */ {
/* 27:   */   private final String[] properties;
/* 28:   */   
/* 29:   */   public ComponentCommand(String... properties)
/* 30:   */   {
/* 31:31 */     this.properties = properties;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public JCommand.ActionAdapter toAction(C c)
/* 35:   */   {
/* 36:36 */     JCommand.ActionAdapter result = super.toAction(c);
/* 37:37 */     return (c instanceof Component) ? result.withWeakPropertyChangeListener((Component)c, properties) : result;
/* 38:   */   }
/* 39:   */ }
