/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.TsFactory;
/*   7:    */ import ec.tss.TsMoniker;
/*   8:    */ import ec.tss.TsStatus;
/*   9:    */ import ec.tstoolkit.data.Values;
/*  10:    */ import ec.tstoolkit.timeseries.Day;
/*  11:    */ import ec.tstoolkit.timeseries.Month;
/*  12:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*  13:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsDataTable;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  16:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  17:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  18:    */ import ec.ui.commands.TsGrowthChartCommand;
/*  19:    */ import ec.ui.interfaces.ITsGrowthChart;
/*  20:    */ import ec.ui.interfaces.ITsGrowthChart.GrowthKind;
/*  21:    */ import ec.util.various.swing.JCommand;
/*  22:    */ import java.beans.PropertyChangeEvent;
/*  23:    */ import java.beans.PropertyChangeListener;
/*  24:    */ import javax.swing.ActionMap;
/*  25:    */ import javax.swing.JCheckBoxMenuItem;
/*  26:    */ import javax.swing.JMenu;
/*  27:    */ import javax.swing.JMenuItem;
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ public abstract class ATsGrowthChart
/*  44:    */   extends ATsChart
/*  45:    */   implements ITsGrowthChart
/*  46:    */ {
/*  47:    */   public static final String PREVIOUS_PERIOD_ACTION = "previousPeriod";
/*  48:    */   public static final String PREVIOUS_YEAR_ACTION = "previousYear";
/*  49: 49 */   protected static final ITsGrowthChart.GrowthKind DEFAULT_GROWTH_KIND = ITsGrowthChart.GrowthKind.PreviousPeriod;
/*  50:    */   
/*  51:    */   public static final int DEFAULT_LAST_YEARS = 4;
/*  52:    */   
/*  53:    */   protected static final boolean DEFAULT_USE_TOOL_LAYOUT = false;
/*  54:    */   protected ITsGrowthChart.GrowthKind growthKind;
/*  55:    */   protected int lastYears;
/*  56:    */   protected boolean useToolLayout;
/*  57: 57 */   protected final TsCollection growthCollection = TsFactory.instance.createTsCollection();
/*  58:    */   
/*  59:    */   public ATsGrowthChart() {
/*  60: 60 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  61:    */     
/*  62: 62 */     growthKind = DEFAULT_GROWTH_KIND;
/*  63: 63 */     lastYears = demetraUI.getGrowthLastYears().intValue();
/*  64: 64 */     useToolLayout = false;
/*  65:    */     
/*  66: 66 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  67:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  68:    */         String str;
/*  69: 69 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1984797751:  if (str.equals("useToolLayout")) {} break; case -1115859461:  if (str.equals("growthKind")) break; break; case 2007313120:  if (!str.equals("lastYears"))
/*  70:    */           {
/*  71: 71 */             return;onGrowthKindChange();
/*  72:    */           }
/*  73:    */           else {
/*  74: 74 */             onLastYearsChange();
/*  75: 75 */             return;
/*  76:    */             
/*  77: 77 */             onUseToolLayoutChange();
/*  78:    */           }
/*  79:    */           break;
/*  80:    */         }
/*  81:    */       }
/*  82: 82 */     });
/*  83: 83 */     ActionMap am = getActionMap();
/*  84: 84 */     am.put("previousPeriod", TsGrowthChartCommand.applyGrowthKind(ITsGrowthChart.GrowthKind.PreviousPeriod).toAction(this));
/*  85: 85 */     am.put("previousYear", TsGrowthChartCommand.applyGrowthKind(ITsGrowthChart.GrowthKind.PreviousYear).toAction(this));
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */   protected abstract void onGrowthKindChange();
/*  90:    */   
/*  91:    */ 
/*  92:    */   protected abstract void onLastYearsChange();
/*  93:    */   
/*  94:    */ 
/*  95:    */   protected abstract void onUseToolLayoutChange();
/*  96:    */   
/*  97:    */   public ITsGrowthChart.GrowthKind getGrowthKind()
/*  98:    */   {
/*  99: 99 */     return growthKind;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setGrowthKind(ITsGrowthChart.GrowthKind growthKind)
/* 103:    */   {
/* 104:104 */     ITsGrowthChart.GrowthKind old = this.growthKind;
/* 105:105 */     this.growthKind = (growthKind != null ? growthKind : DEFAULT_GROWTH_KIND);
/* 106:106 */     firePropertyChange("growthKind", old, this.growthKind);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int getLastYears()
/* 110:    */   {
/* 111:111 */     return lastYears;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setLastYears(int lastYears)
/* 115:    */   {
/* 116:116 */     int old = this.lastYears;
/* 117:117 */     this.lastYears = lastYears;
/* 118:118 */     firePropertyChange("lastYears", old, this.lastYears);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean isUseToolLayout()
/* 122:    */   {
/* 123:123 */     return useToolLayout;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setUseToolLayout(boolean useToolLayout)
/* 127:    */   {
/* 128:128 */     boolean old = this.useToolLayout;
/* 129:129 */     this.useToolLayout = useToolLayout;
/* 130:130 */     firePropertyChange("useToolLayout", old, this.useToolLayout);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public Ts[] getGrowthData()
/* 134:    */   {
/* 135:135 */     return growthCollection.toArray();
/* 136:    */   }
/* 137:    */   
/* 138:    */ 
/* 139:    */   protected static TsPeriodSelector computeSelector(TsCollection col, int lastyears)
/* 140:    */   {
/* 141:141 */     TsPeriodSelector result = new TsPeriodSelector();
/* 142:142 */     boolean isvalid = false;
/* 143:143 */     Ts[] tss = col.toArray();
/* 144:144 */     for (Ts o : tss) {
/* 145:145 */       if (o.hasData() == TsStatus.Valid) {
/* 146:146 */         isvalid = true;
/* 147:147 */         break;
/* 148:    */       }
/* 149:    */     }
/* 150:150 */     if (isvalid) {
/* 151:151 */       TsDataTable tmp = new TsDataTable();
/* 152:152 */       for (Ts o : tss) {
/* 153:153 */         if (o.hasData() == TsStatus.Valid) {
/* 154:154 */           tmp.insert(-1, o.getTsData().cleanExtremities());
/* 155:    */         }
/* 156:    */       }
/* 157:157 */       int year = tmp.getDomain().getLast().getYear() - lastyears;
/* 158:158 */       result.from(new Day(year, Month.valueOf(0), 0));
/* 159:    */     }
/* 160:160 */     return result;
/* 161:    */   }
/* 162:    */   
/* 163:    */   protected static TsData computeGrowthData(TsData input, ITsGrowthChart.GrowthKind kind, TsPeriodSelector selector) {
/* 164:164 */     if (input == null) {
/* 165:165 */       return null;
/* 166:    */     }
/* 167:167 */     TsData result = input.cleanExtremities();
/* 168:168 */     result = result.pctVariation(kind == ITsGrowthChart.GrowthKind.PreviousPeriod ? 1 : result.getFrequency().intValue());
/* 169:169 */     result = result.select(selector);
/* 170:170 */     result.getValues().mul(0.01D);
/* 171:171 */     return result;
/* 172:    */   }
/* 173:    */   
/* 174:    */   protected static Ts[] computeGrowthData(Ts[] input, ITsGrowthChart.GrowthKind kind, TsPeriodSelector selector) {
/* 175:175 */     Ts[] result = new Ts[input.length];
/* 176:176 */     for (int i = 0; i < result.length; i++) {
/* 177:177 */       result[i] = TsFactory.instance.createTs(input[i].getName(), new TsMoniker(), null, computeGrowthData(input[i].getTsData(), kind, selector));
/* 178:    */     }
/* 179:179 */     return result;
/* 180:    */   }
/* 181:    */   
/* 182:    */   protected JMenu buildKindMenu()
/* 183:    */   {
/* 184:184 */     ActionMap am = getActionMap();
/* 185:185 */     JMenu result = new JMenu("Kind");
/* 186:    */     
/* 187:    */ 
/* 188:    */ 
/* 189:189 */     JMenuItem item = new JCheckBoxMenuItem(am.get("previousPeriod"));
/* 190:190 */     item.setText("Previous Period");
/* 191:191 */     result.add(item);
/* 192:    */     
/* 193:193 */     item = new JCheckBoxMenuItem(am.get("previousYear"));
/* 194:194 */     item.setText("Previous Year");
/* 195:195 */     result.add(item);
/* 196:    */     
/* 197:197 */     return result;
/* 198:    */   }
/* 199:    */   
/* 200:    */   protected JMenu buildChartMenu()
/* 201:    */   {
/* 202:202 */     JMenu result = super.buildChartMenu();
/* 203:    */     
/* 204:204 */     int index = 0;
/* 205:    */     
/* 206:    */ 
/* 207:207 */     index += 5;
/* 208:208 */     JMenuItem item = new JMenuItem(TsGrowthChartCommand.copyGrowthData().toAction(this));
/* 209:209 */     item.setText("Copy growth data");
/* 210:210 */     ExtAction.hideWhenDisabled(item);
/* 211:211 */     result.add(item, index++);
/* 212:    */     
/* 213:213 */     index += 6;
/* 214:214 */     result.insert(buildKindMenu(), index++);
/* 215:    */     
/* 216:216 */     item = new JMenuItem(TsGrowthChartCommand.editLastYears().toAction(this));
/* 217:217 */     item.setText("Edit last years...");
/* 218:218 */     result.insert(item, index++);
/* 219:    */     
/* 220:220 */     index += 5;
/* 221:221 */     result.remove(index);
/* 222:    */     
/* 223:223 */     return result;
/* 224:    */   }
/* 225:    */ }
