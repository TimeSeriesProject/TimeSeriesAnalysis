/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Iterables;
/*   4:    */ import ec.tstoolkit.utilities.Arrays2;
/*   5:    */ import ec.ui.interfaces.ITsList;
/*   6:    */ import ec.ui.interfaces.ITsList.InfoType;
/*   7:    */ import java.beans.PropertyChangeEvent;
/*   8:    */ import java.beans.PropertyChangeListener;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.swing.JMenu;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ public abstract class ATsList
/*  20:    */   extends ATsCollectionView
/*  21:    */   implements ITsList
/*  22:    */ {
/*  23:    */   protected static final boolean DEFAULT_MULTI_SELECTION = true;
/*  24:    */   protected static final boolean DEFAULT_SHOW_HEADER = true;
/*  25:    */   protected static final boolean DEFAULT_SORTABLE = false;
/*  26: 26 */   protected static final List<ITsList.InfoType> DEFAULT_INFORMATION = Arrays2.unmodifiableList(new ITsList.InfoType[] { ITsList.InfoType.TsIdentifier, ITsList.InfoType.Start, ITsList.InfoType.End, ITsList.InfoType.Length, ITsList.InfoType.Data });
/*  27: 27 */   protected static final ITsList.InfoType DEFAULT_SORT_INFO = ITsList.InfoType.TsIdentifier;
/*  28:    */   protected boolean multiSelection;
/*  29:    */   protected boolean showHeader;
/*  30:    */   protected boolean sortable;
/*  31:    */   protected List<ITsList.InfoType> information;
/*  32:    */   protected ITsList.InfoType sortInfo;
/*  33:    */   
/*  34:    */   public ATsList()
/*  35:    */   {
/*  36: 36 */     multiSelection = true;
/*  37: 37 */     showHeader = true;
/*  38: 38 */     sortable = false;
/*  39: 39 */     information = DEFAULT_INFORMATION;
/*  40: 40 */     sortInfo = DEFAULT_SORT_INFO;
/*  41:    */     
/*  42: 42 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  43:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  44:    */         String str;
/*  45: 45 */         switch ((str = evt.getPropertyName()).hashCode()) {case 453818346:  if (str.equals("showHeader")) {} break; case 657296467:  if (str.equals("multiSelection")) break; break; case 1661521772:  if (str.equals("sortInfo")) {} break; case 1662225400:  if (str.equals("sortable")) {} break; case 1968600364:  if (!str.equals("information"))
/*  46:    */           {
/*  47: 47 */             return;onMultiSelectionChange();
/*  48: 48 */             return;
/*  49:    */             
/*  50: 50 */             onShowHeaderChange();
/*  51: 51 */             return;
/*  52:    */             
/*  53: 53 */             onSortableChange();
/*  54:    */           }
/*  55:    */           else {
/*  56: 56 */             onInformationChange();
/*  57: 57 */             return;
/*  58:    */             
/*  59: 59 */             onSortInfoChange();
/*  60:    */           }
/*  61:    */           
/*  62:    */           break;
/*  63:    */         }
/*  64:    */         
/*  65:    */       }
/*  66:    */     });
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected abstract void onMultiSelectionChange();
/*  70:    */   
/*  71:    */   protected abstract void onShowHeaderChange();
/*  72:    */   
/*  73:    */   protected abstract void onSortableChange();
/*  74:    */   
/*  75:    */   protected abstract void onInformationChange();
/*  76:    */   
/*  77:    */   protected abstract void onSortInfoChange();
/*  78:    */   
/*  79:    */   public ITsList.InfoType[] getInformation()
/*  80:    */   {
/*  81: 81 */     return (ITsList.InfoType[])Iterables.toArray(information, ITsList.InfoType.class);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setInformation(ITsList.InfoType[] information)
/*  85:    */   {
/*  86: 86 */     List<ITsList.InfoType> old = this.information;
/*  87: 87 */     this.information = (information != null ? Arrays.asList(information) : DEFAULT_INFORMATION);
/*  88: 88 */     firePropertyChange("information", old, this.information);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean isMultiSelection()
/*  92:    */   {
/*  93: 93 */     return multiSelection;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void setMultiSelection(boolean multiSelection)
/*  97:    */   {
/*  98: 98 */     boolean old = this.multiSelection;
/*  99: 99 */     this.multiSelection = multiSelection;
/* 100:100 */     firePropertyChange("multiSelection", old, this.multiSelection);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean isShowHeader()
/* 104:    */   {
/* 105:105 */     return showHeader;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setShowHeader(boolean showHeader)
/* 109:    */   {
/* 110:110 */     boolean old = this.showHeader;
/* 111:111 */     this.showHeader = showHeader;
/* 112:112 */     firePropertyChange("showHeader", old, this.showHeader);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public ITsList.InfoType getSortInfo()
/* 116:    */   {
/* 117:117 */     return sortInfo;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void setSortInfo(ITsList.InfoType sortInfo)
/* 121:    */   {
/* 122:122 */     ITsList.InfoType old = this.sortInfo;
/* 123:123 */     this.sortInfo = (sortInfo != null ? sortInfo : DEFAULT_SORT_INFO);
/* 124:124 */     firePropertyChange("sortInfo", old, this.sortInfo);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean isSortable()
/* 128:    */   {
/* 129:129 */     return sortable;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setSortable(boolean sortable)
/* 133:    */   {
/* 134:134 */     boolean old = this.sortable;
/* 135:135 */     this.sortable = sortable;
/* 136:136 */     firePropertyChange("sortable", old, this.sortable);
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected JMenu buildListMenu()
/* 140:    */   {
/* 141:141 */     JMenu result = buildMenu();
/* 142:    */     
/* 143:143 */     int index = 8;
/* 144:144 */     result.add(buildSelectByFreqMenu(), index++);
/* 145:    */     
/* 146:146 */     return result;
/* 147:    */   }
/* 148:    */ }
