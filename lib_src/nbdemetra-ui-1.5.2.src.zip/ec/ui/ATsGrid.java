/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   5:    */ import ec.ui.commands.TsGridCommand;
/*   6:    */ import ec.ui.interfaces.ITsGrid;
/*   7:    */ import ec.ui.interfaces.ITsGrid.Chronology;
/*   8:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*   9:    */ import ec.ui.interfaces.ITsGrid.Orientation;
/*  10:    */ import ec.util.chart.ColorScheme;
/*  11:    */ import ec.util.various.swing.FontAwesome;
/*  12:    */ import ec.util.various.swing.JCommand;
/*  13:    */ import java.beans.PropertyChangeEvent;
/*  14:    */ import java.beans.PropertyChangeListener;
/*  15:    */ import javax.swing.ActionMap;
/*  16:    */ import javax.swing.JCheckBoxMenuItem;
/*  17:    */ import javax.swing.JMenu;
/*  18:    */ import javax.swing.JMenuItem;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ public abstract class ATsGrid
/*  38:    */   extends ATsCollectionView
/*  39:    */   implements ITsGrid
/*  40:    */ {
/*  41:    */   public static final String TRANSPOSE_ACTION = "transpose";
/*  42:    */   public static final String REVERSE_ACTION = "reverse";
/*  43:    */   public static final String SINGLE_TS_ACTION = "singleTs";
/*  44:    */   public static final String MULTI_TS_ACTION = "multiTs";
/*  45:    */   public static final String TOGGLE_MODE_ACTION = "toggleMode";
/*  46: 46 */   protected static final ITsGrid.Orientation DEFAULT_ORIENTATION = ITsGrid.Orientation.NORMAL;
/*  47: 47 */   protected static final ITsGrid.Chronology DEFAULT_CHRONOLOGY = ITsGrid.Chronology.ASCENDING;
/*  48: 48 */   protected static final ITsGrid.Mode DEFAULT_MODE = ITsGrid.Mode.MULTIPLETS;
/*  49:    */   
/*  50:    */   protected static final int DEFAULT_SINGLE_SERIES_INDEX = 0;
/*  51:    */   
/*  52:    */   protected static final int DEFAULT_ZOOM_RATIO = 100;
/*  53:    */   protected ITsGrid.Orientation orientation;
/*  54:    */   protected ITsGrid.Chronology chronology;
/*  55:    */   protected ITsGrid.Mode mode;
/*  56:    */   protected int singleTsIndex;
/*  57:    */   protected int zoomRatio;
/*  58: 58 */   private DemetraUI demetraUI = DemetraUI.getDefault();
/*  59:    */   
/*  60:    */   public ATsGrid() {
/*  61: 61 */     orientation = DEFAULT_ORIENTATION;
/*  62: 62 */     chronology = DEFAULT_CHRONOLOGY;
/*  63: 63 */     mode = DEFAULT_MODE;
/*  64: 64 */     singleTsIndex = 0;
/*  65: 65 */     zoomRatio = 100;
/*  66:    */     
/*  67: 67 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  68:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  69:    */         String str;
/*  70: 70 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1471050024:  if (str.equals("chronology")) {} break; case -1439500848:  if (str.equals("orientation")) break; break; case 3357091:  if (str.equals("mode")) {} break; case 3744723:  if (str.equals("zoom")) {} break; case 1027642411:  if (!str.equals("singleTsIndex"))
/*  71:    */           {
/*  72: 72 */             return;onOrientationChange();
/*  73: 73 */             return;
/*  74:    */             
/*  75: 75 */             onChronologyChange();
/*  76: 76 */             return;
/*  77:    */             
/*  78: 78 */             onModeChange();
/*  79:    */           }
/*  80:    */           else {
/*  81: 81 */             onSingleTsIndexChange();
/*  82: 82 */             return;
/*  83:    */             
/*  84: 84 */             onZoomChange();
/*  85:    */           }
/*  86:    */           break;
/*  87:    */         }
/*  88:    */       }
/*  89: 89 */     });
/*  90: 90 */     ActionMap am = getActionMap();
/*  91: 91 */     am.put("transpose", TsGridCommand.transpose().toAction(this));
/*  92: 92 */     am.put("reverse", TsGridCommand.reverseChronology().toAction(this));
/*  93: 93 */     am.put("singleTs", TsGridCommand.applyMode(ITsGrid.Mode.SINGLETS).toAction(this));
/*  94: 94 */     am.put("multiTs", TsGridCommand.applyMode(ITsGrid.Mode.MULTIPLETS).toAction(this));
/*  95: 95 */     am.put("toggleMode", TsGridCommand.toggleMode().toAction(this));
/*  96:    */   }
/*  97:    */   
/*  98:    */ 
/*  99:    */   protected abstract void onOrientationChange();
/* 100:    */   
/* 101:    */ 
/* 102:    */   protected abstract void onChronologyChange();
/* 103:    */   
/* 104:    */ 
/* 105:    */   protected abstract void onModeChange();
/* 106:    */   
/* 107:    */   protected abstract void onSingleTsIndexChange();
/* 108:    */   
/* 109:    */   protected abstract void onZoomChange();
/* 110:    */   
/* 111:    */   public ITsGrid.Orientation getOrientation()
/* 112:    */   {
/* 113:113 */     return orientation;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void setOrientation(ITsGrid.Orientation orientation)
/* 117:    */   {
/* 118:118 */     ITsGrid.Orientation old = this.orientation;
/* 119:119 */     this.orientation = (orientation != null ? orientation : DEFAULT_ORIENTATION);
/* 120:120 */     firePropertyChange("orientation", old, this.orientation);
/* 121:    */   }
/* 122:    */   
/* 123:    */   public ITsGrid.Chronology getChronology()
/* 124:    */   {
/* 125:125 */     return chronology;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setChronology(ITsGrid.Chronology chronology)
/* 129:    */   {
/* 130:130 */     ITsGrid.Chronology old = this.chronology;
/* 131:131 */     this.chronology = (chronology != null ? chronology : DEFAULT_CHRONOLOGY);
/* 132:132 */     firePropertyChange("chronology", old, this.chronology);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public ITsGrid.Mode getMode()
/* 136:    */   {
/* 137:137 */     return mode;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void setMode(ITsGrid.Mode mode)
/* 141:    */   {
/* 142:142 */     ITsGrid.Mode old = this.mode;
/* 143:143 */     this.mode = (mode != null ? mode : DEFAULT_MODE);
/* 144:144 */     firePropertyChange("mode", old, this.mode);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void setSingleTsIndex(int singleTsIndex)
/* 148:    */   {
/* 149:149 */     int old = this.singleTsIndex;
/* 150:150 */     this.singleTsIndex = (singleTsIndex >= 0 ? singleTsIndex : 0);
/* 151:151 */     firePropertyChange("singleTsIndex", old, this.singleTsIndex);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public int getSingleTsIndex()
/* 155:    */   {
/* 156:156 */     return singleTsIndex;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public ColorScheme getColorScheme()
/* 160:    */   {
/* 161:161 */     return themeSupport.getLocalColorScheme();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setColorScheme(ColorScheme colorScheme)
/* 165:    */   {
/* 166:166 */     themeSupport.setLocalColorScheme(colorScheme);
/* 167:    */   }
/* 168:    */   
/* 169:    */   @Deprecated
/* 170:    */   public void zoom(int percentage)
/* 171:    */   {
/* 172:172 */     setZoomRatio(percentage);
/* 173:    */   }
/* 174:    */   
/* 175:    */   public int getZoomRatio()
/* 176:    */   {
/* 177:177 */     return zoomRatio;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setZoomRatio(int zoomRatio)
/* 181:    */   {
/* 182:182 */     int old = this.zoomRatio;
/* 183:183 */     this.zoomRatio = ((zoomRatio >= 10) && (zoomRatio <= 200) ? zoomRatio : 100);
/* 184:184 */     firePropertyChange("zoom", old, this.zoomRatio);
/* 185:    */   }
/* 186:    */   
/* 187:    */   protected JMenu buildModeMenu()
/* 188:    */   {
/* 189:189 */     ActionMap am = getActionMap();
/* 190:190 */     JMenu result = new JMenu("Mode");
/* 191:    */     
/* 192:    */ 
/* 193:    */ 
/* 194:194 */     JMenuItem item = new JCheckBoxMenuItem(am.get("singleTs"));
/* 195:195 */     item.setText("Display only one timeseries");
/* 196:196 */     result.add(item);
/* 197:    */     
/* 198:198 */     item = new JCheckBoxMenuItem(am.get("multiTs"));
/* 199:199 */     item.setText("Display multiple timeseries");
/* 200:200 */     result.add(item);
/* 201:    */     
/* 202:202 */     return result;
/* 203:    */   }
/* 204:    */   
/* 205:    */   protected JMenu buildGridMenu() {
/* 206:206 */     ActionMap am = getActionMap();
/* 207:207 */     JMenu result = buildMenu();
/* 208:    */     
/* 209:209 */     int index = 0;
/* 210:    */     
/* 211:    */ 
/* 212:212 */     index += 10;
/* 213:213 */     result.insertSeparator(index++);
/* 214:    */     
/* 215:215 */     JMenuItem item = new JCheckBoxMenuItem(am.get("transpose"));
/* 216:216 */     item.setText("Transpose");
/* 217:217 */     result.add(item, index++);
/* 218:    */     
/* 219:219 */     item = new JCheckBoxMenuItem(am.get("reverse"));
/* 220:220 */     item.setText("Reverse chronology");
/* 221:221 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_SORT_NUMERIC_DESC));
/* 222:222 */     result.add(item, index++);
/* 223:    */     
/* 224:224 */     item = new JCheckBoxMenuItem(am.get("toggleMode"));
/* 225:225 */     item.setText("Single time series");
/* 226:226 */     result.add(item, index++);
/* 227:    */     
/* 228:228 */     return result;
/* 229:    */   }
/* 230:    */ }
