/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.beans.PropertyChangeEvent;
/*   5:    */ import java.beans.PropertyChangeListener;
/*   6:    */ import javax.swing.AbstractAction;
/*   7:    */ import javax.swing.AbstractButton;
/*   8:    */ import javax.swing.Action;
/*   9:    */ import javax.swing.Icon;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ public abstract class ExtAction
/*  20:    */   extends AbstractAction
/*  21:    */ {
/*  22:    */   @Deprecated
/*  23:    */   public ExtAction() {}
/*  24:    */   
/*  25:    */   @Deprecated
/*  26:    */   public ExtAction(String name)
/*  27:    */   {
/*  28: 28 */     super(name);
/*  29:    */   }
/*  30:    */   
/*  31:    */   @Deprecated
/*  32:    */   public ExtAction(String name, Icon icon) {
/*  33: 33 */     super(name, icon);
/*  34:    */   }
/*  35:    */   
/*  36:    */   protected void bind(Component c, final IActionBinder binder) {
/*  37: 37 */     binder.set(this);
/*  38: 38 */     c.addPropertyChangeListener(new PropertyChangeListener()
/*  39:    */     {
/*  40:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  41: 41 */         for (String o : binder.propertyNames()) {
/*  42: 42 */           if (o.equals(evt.getPropertyName())) {
/*  43: 43 */             binder.set(ExtAction.this);
/*  44: 44 */             break;
/*  45:    */           }
/*  46:    */         }
/*  47:    */       }
/*  48:    */     });
/*  49:    */   }
/*  50:    */   
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */   @Deprecated
/*  55:    */   protected static abstract class Enable
/*  56:    */     implements ExtAction.IActionBinder
/*  57:    */   {
/*  58:    */     final String[] propertyNames;
/*  59:    */     
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */     public Enable(String... propertyNames)
/*  64:    */     {
/*  65: 65 */       this.propertyNames = propertyNames;
/*  66:    */     }
/*  67:    */     
/*  68:    */     public String[] propertyNames()
/*  69:    */     {
/*  70: 70 */       return propertyNames;
/*  71:    */     }
/*  72:    */     
/*  73:    */ 
/*  74:    */ 
/*  75: 75 */     public void set(Action action) { action.setEnabled(canEnable()); }
/*  76:    */     
/*  77:    */     protected abstract boolean canEnable(); }
/*  78:    */   
/*  79:    */   @Deprecated
/*  80:    */   protected static abstract interface IActionBinder { public abstract String[] propertyNames();
/*  81:    */     
/*  82:    */     public abstract void set(Action paramAction); }
/*  83:    */   
/*  84:    */   @Deprecated
/*  85:    */   protected static abstract class Select implements ExtAction.IActionBinder { final String[] propertyNames;
/*  86:    */     
/*  87: 87 */     public Select(String... propertyNames) { this.propertyNames = propertyNames; }
/*  88:    */     
/*  89:    */ 
/*  90:    */     public String[] propertyNames()
/*  91:    */     {
/*  92: 92 */       return propertyNames;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public void set(Action action)
/*  96:    */     {
/*  97: 97 */       action.putValue("SwingSelectedKey", Boolean.valueOf(canSelect()));
/*  98:    */     }
/*  99:    */     
/* 100:    */     protected abstract boolean canSelect();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static <C extends AbstractButton> C hideWhenDisabled(C c) {
/* 104:104 */     c.setVisible(c.isEnabled());
/* 105:105 */     c.addPropertyChangeListener(HIDE);
/* 106:106 */     return c;
/* 107:    */   }
/* 108:    */   
/* 109:109 */   private static final PropertyChangeListener HIDE = new PropertyChangeListener()
/* 110:    */   {
/* 111:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 112:112 */       if (("enabled".equals(evt.getPropertyName())) && ((evt.getSource() instanceof JComponent))) {
/* 113:113 */         ((JComponent)evt.getSource()).setVisible(((Boolean)evt.getNewValue()).booleanValue());
/* 114:    */       }
/* 115:    */     }
/* 116:    */   };
/* 117:    */ }
