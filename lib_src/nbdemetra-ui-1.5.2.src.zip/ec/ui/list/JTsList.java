/*   1:    */ package ec.ui.list;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.MonikerUI;
/*   4:    */ import ec.nbdemetra.ui.awt.TableColumnModelAdapter;
/*   5:    */ import ec.tss.Ts;
/*   6:    */ import ec.tss.TsCollection;
/*   7:    */ import ec.tss.TsFactory;
/*   8:    */ import ec.tss.TsIdentifier;
/*   9:    */ import ec.tss.TsMoniker;
/*  10:    */ import ec.tss.TsStatus;
/*  11:    */ import ec.tstoolkit.timeseries.Day;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  13:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  16:    */ import ec.ui.ATsCollectionView;
/*  17:    */ import ec.ui.ATsCollectionView.TsActionMouseAdapter;
/*  18:    */ import ec.ui.ATsCollectionView.TsCollectionSelectionListener;
/*  19:    */ import ec.ui.ATsCollectionView.TsCollectionTransferHandler;
/*  20:    */ import ec.ui.ATsList;
/*  21:    */ import ec.ui.chart.TsSparklineCellRenderer;
/*  22:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  23:    */ import ec.ui.interfaces.ITsList.InfoType;
/*  24:    */ import ec.util.grid.swing.XTable;
/*  25:    */ import ec.util.various.swing.FontAwesome;
/*  26:    */ import java.awt.BorderLayout;
/*  27:    */ import java.awt.Color;
/*  28:    */ import java.awt.Component;
/*  29:    */ import java.awt.Font;
/*  30:    */ import java.awt.FontMetrics;
/*  31:    */ import java.awt.Graphics;
/*  32:    */ import java.awt.Graphics2D;
/*  33:    */ import java.awt.Image;
/*  34:    */ import java.awt.RenderingHints;
/*  35:    */ import java.awt.event.ActionEvent;
/*  36:    */ import java.beans.PropertyChangeEvent;
/*  37:    */ import java.beans.PropertyChangeListener;
/*  38:    */ import java.util.Comparator;
/*  39:    */ import java.util.List;
/*  40:    */ import javax.swing.AbstractAction;
/*  41:    */ import javax.swing.ActionMap;
/*  42:    */ import javax.swing.JComponent;
/*  43:    */ import javax.swing.JLabel;
/*  44:    */ import javax.swing.JLayer;
/*  45:    */ import javax.swing.JMenuItem;
/*  46:    */ import javax.swing.JPopupMenu;
/*  47:    */ import javax.swing.JScrollPane;
/*  48:    */ import javax.swing.JTable;
/*  49:    */ import javax.swing.JViewport;
/*  50:    */ import javax.swing.UIManager;
/*  51:    */ import javax.swing.event.PopupMenuEvent;
/*  52:    */ import javax.swing.event.PopupMenuListener;
/*  53:    */ import javax.swing.event.TableColumnModelEvent;
/*  54:    */ import javax.swing.plaf.LayerUI;
/*  55:    */ import javax.swing.table.AbstractTableModel;
/*  56:    */ import javax.swing.table.DefaultTableCellRenderer;
/*  57:    */ import javax.swing.table.JTableHeader;
/*  58:    */ import javax.swing.table.TableColumnModel;
/*  59:    */ import org.netbeans.swing.etable.ETable;
/*  60:    */ import org.netbeans.swing.etable.ETableColumn;
/*  61:    */ import org.netbeans.swing.etable.ETableColumnModel;
/*  62:    */ 
/*  63:    */ public class JTsList extends ATsList
/*  64:    */ {
/*  65: 65 */   private final boolean interactive_ = true;
/*  66:    */   private final ETable table;
/*  67:    */   private final ListTableSelectionListener selectionListener;
/*  68:    */   private final JTableHeader tableHeader;
/*  69:    */   
/*  70:    */   public JTsList() {
/*  71: 71 */     table = buildTable();
/*  72: 72 */     selectionListener = new ListTableSelectionListener(null);
/*  73: 73 */     table.getSelectionModel().addListSelectionListener(selectionListener);
/*  74: 74 */     table.addMouseListener(new ec.nbdemetra.ui.awt.PopupListener.PopupAdapter(buildPopupMenu()));
/*  75: 75 */     tableHeader = table.getTableHeader();
/*  76:    */     
/*  77: 77 */     setLayout(new BorderLayout());
/*  78: 78 */     add(new JLayer(ec.nbdemetra.ui.NbComponents.newJScrollPane(table), new DropUI()), "Center");
/*  79:    */     
/*  80: 80 */     onUpdateModeChange();
/*  81:    */     
/*  82: 82 */     if (java.beans.Beans.isDesignTime()) {
/*  83: 83 */       setTsCollection(ec.ui.DemoUtils.randomTsCollection(3));
/*  84: 84 */       setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  85: 85 */       setPreferredSize(new java.awt.Dimension(200, 150));
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   protected void onDataFormatChange() {}
/*  93:    */   
/*  94:    */ 
/*  95:    */ 
/*  96:    */   protected void onColorSchemeChange() {}
/*  97:    */   
/*  98:    */ 
/*  99:    */ 
/* 100:    */   protected void onCollectionChange()
/* 101:    */   {
/* 102:102 */     selectionListener.setEnabled(false);
/* 103:103 */     ((CustomTableModel)table.getModel()).fireTableDataChanged();
/* 104:104 */     selectionListener.setEnabled(true);
/* 105:105 */     onSelectionChange();
/* 106:    */   }
/* 107:    */   
/* 108:    */   protected void onSelectionChange()
/* 109:    */   {
/* 110:110 */     selectionListener.setEnabled(false);
/* 111:111 */     selectionListener.changeSelection(table.getSelectionModel());
/* 112:112 */     selectionListener.setEnabled(true);
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected void onUpdateModeChange()
/* 116:    */   {
/* 117:117 */     String message = getTsUpdateMode().isReadOnly() ? "No data" : "Drop data here";
/* 118:118 */     ((DropUI)((JLayer)getComponent(0)).getUI()).setMessage(message);
/* 119:119 */     ((DropUI)((JLayer)getComponent(0)).getUI()).setOnDropMessage(message);
/* 120:    */   }
/* 121:    */   
/* 122:    */ 
/* 123:    */ 
/* 124:    */   protected void onTsActionChange() {}
/* 125:    */   
/* 126:    */ 
/* 127:    */ 
/* 128:    */   protected void onDropContentChange() {}
/* 129:    */   
/* 130:    */ 
/* 131:    */ 
/* 132:    */   protected void onMultiSelectionChange()
/* 133:    */   {
/* 134:134 */     table.setSelectionMode(multiSelection ? 2 : 0);
/* 135:    */   }
/* 136:    */   
/* 137:    */   protected void onShowHeaderChange()
/* 138:    */   {
/* 139:139 */     table.setTableHeader(showHeader ? tableHeader : null);
/* 140:    */   }
/* 141:    */   
/* 142:    */ 
/* 143:    */ 
/* 144:    */   protected void onSortableChange() {}
/* 145:    */   
/* 146:    */ 
/* 147:    */   protected void onInformationChange()
/* 148:    */   {
/* 149:149 */     ((CustomTableModel)table.getModel()).fireTableStructureChanged();
/* 150:    */   }
/* 151:    */   
/* 152:    */ 
/* 153:    */ 
/* 154:    */   protected void onSortInfoChange() {}
/* 155:    */   
/* 156:    */ 
/* 157:    */   private ETable buildTable()
/* 158:    */   {
/* 159:159 */     ETable result = new ETable();
/* 160:    */     
/* 161:161 */     int cellPaddingHeight = 2;
/* 162:162 */     result.setRowHeight(result.getFontMetrics(result.getFont()).getHeight() + cellPaddingHeight * 2 + 1);
/* 163:    */     
/* 164:    */ 
/* 165:165 */     result.setFullyNonEditable(true);
/* 166:166 */     result.setShowHorizontalLines(true);
/* 167:167 */     result.setBorder(null);
/* 168:168 */     Color newGridColor = UIManager.getColor("control");
/* 169:169 */     if (newGridColor != null) {
/* 170:170 */       result.setGridColor(newGridColor);
/* 171:    */     }
/* 172:    */     
/* 173:173 */     result.setDefaultRenderer(TsData.class, new TsSparklineCellRenderer());
/* 174:174 */     result.setDefaultRenderer(TsPeriod.class, new TsPeriodTableCellRenderer());
/* 175:175 */     result.setDefaultRenderer(TsFrequency.class, new TsFrequencyTableCellRenderer());
/* 176:176 */     result.setDefaultRenderer(TsIdentifier.class, new TsIdentifierTableCellRenderer(null));
/* 177:    */     
/* 178:178 */     result.getColumnModel().addColumnModelListener(new TableColumnModelAdapter()
/* 179:    */     {
/* 180:    */       public void columnAdded(TableColumnModelEvent e) {
/* 181:181 */         ETableColumnModel columnModel = (ETableColumnModel)e.getSource();
/* 182:182 */         for (int i = e.getFromIndex(); i < e.getToIndex(); i++) {
/* 183:183 */           ETableColumn column = (ETableColumn)columnModel.getColumn(i);
/* 184:184 */           column.setNestedComparator(new JTsList.InformationComparator(JTsList.this, i));
/* 185:    */         }
/* 186:    */         
/* 187:    */       }
/* 188:188 */     });
/* 189:189 */     result.setModel(new CustomTableModel(null));
/* 190:190 */     XTable.setWidthAsPercentages(result, new double[] { 0.4D, 0.1D, 0.1D, 0.1D, 0.3D });
/* 191:    */     
/* 192:192 */     fillActionMap(result.getActionMap());
/* 193:193 */     fillInputMap(result.getInputMap());
/* 194:194 */     result.addMouseListener(new ATsCollectionView.TsActionMouseAdapter(this));
/* 195:195 */     result.setDragEnabled(true);
/* 196:196 */     result.setTransferHandler(new ATsCollectionView.TsCollectionTransferHandler(this));
/* 197:197 */     result.setFillsViewportHeight(true);
/* 198:198 */     result.setSelectionMode(multiSelection ? 2 : 0);
/* 199:    */     
/* 200:200 */     return result;
/* 201:    */   }
/* 202:    */   
/* 203:    */   protected JPopupMenu buildPopupMenu() {
/* 204:204 */     ActionMap am = getActionMap();
/* 205:205 */     JPopupMenu result = buildListMenu().getPopupMenu();
/* 206:    */     
/* 207:207 */     int index = 11;
/* 208:    */     
/* 209:    */ 
/* 210:210 */     result.insert(new javax.swing.JSeparator(), index++);
/* 211:    */     
/* 212:212 */     JMenuItem item = new JMenuItem("Original order");
/* 213:213 */     item.setEnabled(false);
/* 214:214 */     result.add(item, index++);
/* 215:    */     
/* 216:216 */     final JMenuItem unlock = new JMenuItem(new AbstractAction("Unlock")
/* 217:    */     {
/* 218:    */       public void actionPerformed(ActionEvent arg0) {
/* 219:219 */         if (collection.isLocked()) {
/* 220:220 */           TsCollection ncol = TsFactory.instance.createTsCollection();
/* 221:221 */           ncol.append(collection);
/* 222:222 */           collection = ncol;
/* 223:    */         }
/* 224:    */       }
/* 225:225 */     });
/* 226:226 */     result.add(unlock, index++);
/* 227:    */     
/* 228:228 */     result.addPopupMenuListener(new PopupMenuListener()
/* 229:    */     {
/* 230:    */       public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
/* 231:231 */         boolean locked = (collection.isLocked()) || (updateMode == ITsCollectionView.TsUpdateMode.None);
/* 232:232 */         unlock.setEnabled(locked);
/* 233:    */       }
/* 234:    */       
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */       public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}
/* 239:    */       
/* 240:    */ 
/* 241:    */ 
/* 242:    */       public void popupMenuCanceled(PopupMenuEvent e) {}
/* 243:243 */     });
/* 244:244 */     return result;
/* 245:    */   }
/* 246:    */   
/* 247:    */   private final class InformationComparator implements Comparator
/* 248:    */   {
/* 249:    */     private final int index;
/* 250:    */     
/* 251:    */     public InformationComparator(int index) {
/* 252:252 */       this.index = index;
/* 253:    */     }
/* 254:    */     
/* 255:    */     public int compare(Object o1, Object o2)
/* 256:    */     {
/* 257:257 */       switch ((ITsList.InfoType)information.get(index)) {
/* 258:    */       case Data: 
/* 259:    */       case End: 
/* 260:    */       case Frequency: 
/* 261:261 */         return ((String)o1).compareTo((String)o2);
/* 262:    */       case Id: 
/* 263:263 */         return ((TsFrequency)o1).compareTo((TsFrequency)o2);
/* 264:    */       case Length: 
/* 265:265 */         return ((TsPeriod)o1).firstday().compareTo(((TsPeriod)o2).firstday());
/* 266:    */       case Name: 
/* 267:267 */         return ((TsPeriod)o1).lastday().compareTo(((TsPeriod)o2).lastday());
/* 268:    */       case Source: 
/* 269:269 */         return ((Integer)o1).compareTo((Integer)o2);
/* 270:    */       case Start: 
/* 271:271 */         return -1;
/* 272:    */       case TsIdentifier: 
/* 273:273 */         return ((TsIdentifier)o1).getName().compareTo(((TsIdentifier)o2).getName());
/* 274:    */       }
/* 275:275 */       return -1;
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   private final class CustomTableModel extends AbstractTableModel {
/* 280:    */     private CustomTableModel() {}
/* 281:    */     
/* 282:    */     public int getRowCount() {
/* 283:283 */       return collection.getCount();
/* 284:    */     }
/* 285:    */     
/* 286:    */     public int getColumnCount()
/* 287:    */     {
/* 288:288 */       return information.size();
/* 289:    */     }
/* 290:    */     
/* 291:    */     public Object getValueAt(int rowIndex, int columnIndex)
/* 292:    */     {
/* 293:293 */       if (rowIndex == -1) {
/* 294:294 */         return null;
/* 295:    */       }
/* 296:296 */       Ts ts = collection.get(rowIndex);
/* 297:297 */       switch ((ITsList.InfoType)information.get(columnIndex)) {
/* 298:    */       case Data: 
/* 299:299 */         return ts.getName();
/* 300:    */       case Frequency: 
/* 301:301 */         return ts.getMoniker().getId();
/* 302:    */       case End: 
/* 303:303 */         return ts.getMoniker().getSource();
/* 304:    */       case Id: 
/* 305:305 */         return ts.hasData().equals(TsStatus.Valid) ? ts.getTsData().getFrequency() : null;
/* 306:    */       case Length: 
/* 307:307 */         return ts.hasData().equals(TsStatus.Valid) ? ts.getTsData().getDomain().getStart() : null;
/* 308:    */       case Name: 
/* 309:309 */         return ts.hasData().equals(TsStatus.Valid) ? ts.getTsData().getDomain().getLast() : null;
/* 310:    */       case Source: 
/* 311:311 */         return ts.hasData().equals(TsStatus.Valid) ? Integer.valueOf(ts.getTsData().getLength()) : null;
/* 312:    */       case Start: 
/* 313:313 */         return ts.hasData().equals(TsStatus.Valid) ? ts.getTsData() : null;
/* 314:    */       case TsIdentifier: 
/* 315:315 */         return new TsIdentifier(ts.getName(), ts.getMoniker());
/* 316:    */       }
/* 317:317 */       throw new UnsupportedOperationException("Not supported yet.");
/* 318:    */     }
/* 319:    */     
/* 320:    */     public String getColumnName(int column)
/* 321:    */     {
/* 322:322 */       return ((ITsList.InfoType)information.get(column)).name();
/* 323:    */     }
/* 324:    */     
/* 325:    */     public Class<?> getColumnClass(int columnIndex)
/* 326:    */     {
/* 327:327 */       switch ((ITsList.InfoType)information.get(columnIndex)) {
/* 328:    */       case Id: 
/* 329:329 */         return TsFrequency.class;
/* 330:    */       case Length: 
/* 331:    */       case Name: 
/* 332:332 */         return TsPeriod.class;
/* 333:    */       case Source: 
/* 334:334 */         return Integer.class;
/* 335:    */       case Start: 
/* 336:336 */         return TsData.class;
/* 337:    */       case TsIdentifier: 
/* 338:338 */         return TsIdentifier.class;
/* 339:    */       }
/* 340:340 */       return super.getColumnClass(columnIndex);
/* 341:    */     }
/* 342:    */   }
/* 343:    */   
/* 344:344 */   private final class ListTableSelectionListener extends ATsCollectionView.TsCollectionSelectionListener { private ListTableSelectionListener() { super(); }
/* 345:    */     
/* 346:    */     protected int indexToModel(int index)
/* 347:    */     {
/* 348:348 */       return table.convertRowIndexToModel(index);
/* 349:    */     }
/* 350:    */     
/* 351:    */     protected int indexToView(int index)
/* 352:    */     {
/* 353:353 */       return table.convertRowIndexToView(index);
/* 354:    */     }
/* 355:    */   }
/* 356:    */   
/* 357:    */   private static final class TsIdentifierTableCellRenderer extends DefaultTableCellRenderer
/* 358:    */   {
/* 359:359 */     private final MonikerUI monikerUI = MonikerUI.getDefault();
/* 360:    */     
/* 361:    */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 362:    */     {
/* 363:363 */       JLabel result = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 364:364 */       if (value != null) {
/* 365:365 */         TsIdentifier id = (TsIdentifier)value;
/* 366:366 */         result.setText(id.getName());
/* 367:367 */         result.setIcon(monikerUI.getIcon(id.getMoniker()));
/* 368:    */       }
/* 369:369 */       return result;
/* 370:    */     }
/* 371:    */   }
/* 372:    */   
/* 373:    */   private static final class DropUI
/* 374:    */     extends LayerUI<JScrollPane>
/* 375:    */   {
/* 376:    */     public static final String MESSAGE_PROPERTY = "message";
/* 377:    */     public static final String ON_DROP_MESSAGE_PROPERTY = "onDropMessage";
/* 378:    */     private final PropertyChangeListener dropLocationListener;
/* 379:379 */     private String message = "No data";
/* 380:380 */     private String onDropMessage = "Drop data";
/* 381:381 */     private boolean hasDropLocation = false;
/* 382:    */     
/* 383:    */     public DropUI() {
/* 384:384 */       dropLocationListener = new PropertyChangeListener() {
/* 385:    */         public void propertyChange(PropertyChangeEvent evt) {
/* 386:    */           String str;
/* 387:387 */           switch ((str = evt.getPropertyName()).hashCode()) {case -1909533756:  if (str.equals("dropLocation"))
/* 388:    */             {
/* 389:389 */               boolean old = hasDropLocation;
/* 390:390 */               hasDropLocation = (evt.getNewValue() != null);
/* 391:391 */               if (old != hasDropLocation) {
/* 392:392 */                 ((Component)evt.getSource()).repaint();
/* 393:    */               }
/* 394:    */             }
/* 395:    */             break;
/* 396:    */           }
/* 397:    */         }
/* 398:    */       };
/* 399:    */     }
/* 400:    */     
/* 401:    */     public String getMessage() {
/* 402:402 */       return message;
/* 403:    */     }
/* 404:    */     
/* 405:    */     public void setMessage(String message) {
/* 406:406 */       String old = this.message;
/* 407:407 */       this.message = message;
/* 408:408 */       firePropertyChange("message", old, this.message);
/* 409:    */     }
/* 410:    */     
/* 411:    */     public String getOnDropMessage() {
/* 412:412 */       return onDropMessage;
/* 413:    */     }
/* 414:    */     
/* 415:    */     public void setOnDropMessage(String onDropMessage) {
/* 416:416 */       String old = this.onDropMessage;
/* 417:417 */       this.onDropMessage = onDropMessage;
/* 418:418 */       firePropertyChange("onDropMessage", old, this.onDropMessage);
/* 419:    */     }
/* 420:    */     
/* 421:    */ 
/* 422:    */     public void applyPropertyChange(PropertyChangeEvent evt, JLayer<? extends JScrollPane> l)
/* 423:    */     {
/* 424:424 */       l.repaint();
/* 425:    */     }
/* 426:    */     
/* 427:    */     private JTable getTable(JComponent c) {
/* 428:428 */       return (JTable)((JScrollPane)((JLayer)c).getView()).getViewport().getView();
/* 429:    */     }
/* 430:    */     
/* 431:    */     public void installUI(JComponent c)
/* 432:    */     {
/* 433:433 */       super.installUI(c);
/* 434:434 */       getTable(c).addPropertyChangeListener(dropLocationListener);
/* 435:    */     }
/* 436:    */     
/* 437:    */     public void uninstallUI(JComponent c)
/* 438:    */     {
/* 439:439 */       getTable(c).removePropertyChangeListener(dropLocationListener);
/* 440:440 */       super.uninstallUI(c);
/* 441:    */     }
/* 442:    */     
/* 443:    */     public void paint(Graphics g, JComponent c)
/* 444:    */     {
/* 445:445 */       super.paint(g, c);
/* 446:446 */       JTable table = getTable(c);
/* 447:447 */       if ((table.getRowCount() == 0) || (hasDropLocation)) {
/* 448:448 */         String text = hasDropLocation ? onDropMessage : message;
/* 449:449 */         Color background = hasDropLocation ? table.getSelectionBackground() : table.getBackground();
/* 450:450 */         Color foreground = hasDropLocation ? table.getSelectionForeground() : table.getForeground();
/* 451:451 */         Font font = table.getFont();
/* 452:    */         
/* 453:453 */         Graphics2D g2d = (Graphics2D)g.create();
/* 454:    */         
/* 455:455 */         JViewport xxx = ((JScrollPane)((JLayer)c).getView()).getColumnHeader();
/* 456:456 */         int headerHeight = xxx.getHeight();
/* 457:    */         
/* 458:458 */         g2d.setColor(ec.util.chart.swing.SwingColorSchemeSupport.withAlpha(background, 200));
/* 459:459 */         g2d.fillRect(0, headerHeight, c.getWidth(), c.getHeight());
/* 460:460 */         g2d.setColor(foreground);
/* 461:461 */         g2d.setFont(font);
/* 462:    */         
/* 463:463 */         g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 464:464 */         FontMetrics fm = g2d.getFontMetrics();
/* 465:465 */         float x = (c.getWidth() - fm.stringWidth(text)) / 2.0F;
/* 466:466 */         float y = fm.getAscent() + (headerHeight + c.getHeight() - (fm.getAscent() + fm.getDescent())) / 2.0F;
/* 467:    */         
/* 468:468 */         g2d.drawString(text, x, y);
/* 469:    */         
/* 470:470 */         if (hasDropLocation) {
/* 471:471 */           Image image = FontAwesome.FA_DOWNLOAD.getImage(foreground, font.getSize2D() * 2.0F);
/* 472:472 */           g2d.drawImage(image, (c.getWidth() - image.getWidth(table)) / 2, (headerHeight + c.getHeight() - image.getHeight(table)) / 2 - 15, table);
/* 473:    */         }
/* 474:    */         
/* 475:475 */         g2d.dispose();
/* 476:    */       }
/* 477:    */     }
/* 478:    */   }
/* 479:    */ }
