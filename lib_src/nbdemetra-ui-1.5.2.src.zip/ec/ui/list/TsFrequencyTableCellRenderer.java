/*  1:   */ package ec.ui.list;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  4:   */ import javax.swing.table.DefaultTableCellRenderer;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class TsFrequencyTableCellRenderer
/* 14:   */   extends DefaultTableCellRenderer
/* 15:   */ {
/* 16:   */   protected void setValue(Object value)
/* 17:   */   {
/* 18:18 */     if ((value instanceof TsFrequency)) {
/* 19:19 */       TsFrequency freq = (TsFrequency)value;
/* 20:20 */       setText(freq.name() + " (" + freq.intValue() + ")");
/* 21:   */     } else {
/* 22:22 */       super.setValue(value);
/* 23:   */     }
/* 24:   */   }
/* 25:   */ }
