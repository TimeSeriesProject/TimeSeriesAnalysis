/*   1:    */ package ec.ui.list;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.MonikerUI;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.tss.DynamicTsVariable;
/*   6:    */ import ec.tss.Ts;
/*   7:    */ import ec.tss.TsCollection;
/*   8:    */ import ec.tss.TsIdentifier;
/*   9:    */ import ec.tss.TsInformationType;
/*  10:    */ import ec.tss.TsMoniker;
/*  11:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  12:    */ import ec.tstoolkit.data.DataBlock;
/*  13:    */ import ec.tstoolkit.data.IReadDataBlock;
/*  14:    */ import ec.tstoolkit.timeseries.regression.ITsVariable;
/*  15:    */ import ec.tstoolkit.timeseries.regression.TsVariable;
/*  16:    */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  17:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  18:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  19:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  20:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  21:    */ import ec.tstoolkit.utilities.INameValidator;
/*  22:    */ import ec.ui.chart.TsSparklineCellRenderer;
/*  23:    */ import ec.util.grid.swing.XTable;
/*  24:    */ import ec.util.grid.swing.XTable.DefaultNoDataRenderer;
/*  25:    */ import java.awt.BorderLayout;
/*  26:    */ import java.awt.Component;
/*  27:    */ import java.awt.datatransfer.Transferable;
/*  28:    */ import java.awt.event.ActionEvent;
/*  29:    */ import java.awt.event.KeyEvent;
/*  30:    */ import java.awt.event.KeyListener;
/*  31:    */ import java.util.Collections;
/*  32:    */ import java.util.List;
/*  33:    */ import javax.swing.AbstractAction;
/*  34:    */ import javax.swing.InputVerifier;
/*  35:    */ import javax.swing.JComponent;
/*  36:    */ import javax.swing.JLabel;
/*  37:    */ import javax.swing.JMenu;
/*  38:    */ import javax.swing.JMenuItem;
/*  39:    */ import javax.swing.JPopupMenu;
/*  40:    */ import javax.swing.JTable;
/*  41:    */ import javax.swing.JTextField;
/*  42:    */ import javax.swing.ListSelectionModel;
/*  43:    */ import javax.swing.TransferHandler;
/*  44:    */ import javax.swing.TransferHandler.TransferSupport;
/*  45:    */ import javax.swing.event.ListSelectionEvent;
/*  46:    */ import javax.swing.event.ListSelectionListener;
/*  47:    */ import javax.swing.table.AbstractTableModel;
/*  48:    */ import javax.swing.table.DefaultTableCellRenderer;
/*  49:    */ import javax.swing.table.TableModel;
/*  50:    */ import javax.swing.table.TableRowSorter;
/*  51:    */ import org.openide.DialogDisplayer;
/*  52:    */ import org.openide.NotifyDescriptor;
/*  53:    */ import org.openide.NotifyDescriptor.Confirmation;
/*  54:    */ import org.openide.NotifyDescriptor.InputLine;
/*  55:    */ import org.openide.NotifyDescriptor.Message;
/*  56:    */ 
/*  57:    */ public class JTsVariableList extends JComponent
/*  58:    */ {
/*  59:    */   public static final String DELETE_ACTION = "delete";
/*  60:    */   public static final String CLEAR_ACTION = "clear";
/*  61:    */   public static final String SELECT_ALL_ACTION = "selectAll";
/*  62:    */   public static final String RENAME_ACTION = "rename";
/*  63:    */   private final ListTableSelectionListener listTableListener;
/*  64:    */   private final XTable table;
/*  65:    */   private final TsVariables variables;
/*  66:    */   private final RenameAction rename;
/*  67:    */   private final ClearAction clear;
/*  68:    */   private final DeleteAction remove;
/*  69:    */   
/*  70:    */   public JTsVariableList(TsVariables vars)
/*  71:    */   {
/*  72: 72 */     variables = vars;
/*  73: 73 */     table = buildTable();
/*  74: 74 */     rename = new RenameAction();
/*  75: 75 */     remove = new DeleteAction();
/*  76: 76 */     clear = new ClearAction();
/*  77: 77 */     listTableListener = new ListTableSelectionListener(null);
/*  78: 78 */     table.getSelectionModel().addListSelectionListener(listTableListener);
/*  79: 79 */     table.addMouseListener(new ec.nbdemetra.ui.awt.PopupListener.PopupAdapter(buildPopupMenu()));
/*  80:    */     
/*  81: 81 */     setLayout(new BorderLayout());
/*  82: 82 */     add(NbComponents.newJScrollPane(table), "Center");
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected JPopupMenu buildPopupMenu() {
/*  86: 86 */     JMenu result = new JMenu();
/*  87:    */     
/*  88:    */ 
/*  89:    */ 
/*  90: 90 */     JMenuItem item = new JMenuItem(rename);
/*  91: 91 */     item.setText("Rename");
/*  92: 92 */     result.add(item);
/*  93:    */     
/*  94: 94 */     result.addSeparator();
/*  95:    */     
/*  96: 96 */     item = new JMenuItem(remove);
/*  97: 97 */     item.setText("Remove");
/*  98: 98 */     result.add(item);
/*  99:    */     
/* 100:100 */     item = new JMenuItem(clear);
/* 101:101 */     item.setText("Clear");
/* 102:102 */     result.add(item);
/* 103:    */     
/* 104:104 */     return result.getPopupMenu();
/* 105:    */   }
/* 106:    */   
/* 107:    */   private String[] names(int[] pos) {
/* 108:108 */     String[] n = new String[pos.length];
/* 109:109 */     CustomTableModel model = (CustomTableModel)table.getModel();
/* 110:110 */     for (int i = 0; i < pos.length; i++) {
/* 111:111 */       n[i] = names[pos[i]];
/* 112:    */     }
/* 113:113 */     return n;
/* 114:    */   }
/* 115:    */   
/* 116:    */   private class RenameAction extends AbstractAction
/* 117:    */   {
/* 118:    */     public static final String RENAME_TITLE = "Please enter the new name";
/* 119:    */     public static final String NAME_MESSAGE = "New name:";
/* 120:    */     
/* 121:    */     public RenameAction() {
/* 122:122 */       super();
/* 123:123 */       enabled = false;
/* 124:    */     }
/* 125:    */     
/* 126:    */ 
/* 127:    */     public void actionPerformed(ActionEvent e)
/* 128:    */     {
/* 129:129 */       int[] sel = table.getSelectedRows();
/* 130:130 */       if (sel.length != 1) {
/* 131:131 */         return;
/* 132:    */       }
/* 133:    */       
/* 134:134 */       String oldName = JTsVariableList.this.names(sel)[0];
/* 135:135 */       JTsVariableList.VarName nd = new JTsVariableList.VarName(JTsVariableList.this, variables, "New name:", "Please enter the new name", oldName);
/* 136:136 */       if (DialogDisplayer.getDefault().notify(nd) != NotifyDescriptor.OK_OPTION) {
/* 137:137 */         return;
/* 138:    */       }
/* 139:139 */       String newName = nd.getInputText();
/* 140:140 */       if (newName.equals(oldName)) {
/* 141:141 */         return;
/* 142:    */       }
/* 143:143 */       variables.rename(oldName, newName);
/* 144:144 */       ((JTsVariableList.CustomTableModel)table.getModel()).fireTableStructureChanged();
/* 145:145 */       firePropertyChange("rename", oldName, newName);
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   private class DeleteAction extends AbstractAction
/* 150:    */   {
/* 151:    */     public static final String DELETE_MESSAGE = "Are you sure you want to delete the selected items?";
/* 152:    */     
/* 153:    */     public DeleteAction() {
/* 154:154 */       super();
/* 155:155 */       enabled = false;
/* 156:    */     }
/* 157:    */     
/* 158:    */     public void actionPerformed(ActionEvent e)
/* 159:    */     {
/* 160:160 */       int[] sel = table.getSelectedRows();
/* 161:161 */       if (sel.length == 0) {
/* 162:162 */         return;
/* 163:    */       }
/* 164:164 */       NotifyDescriptor nd = new NotifyDescriptor.Confirmation("Are you sure you want to delete the selected items?", 2);
/* 165:165 */       if (DialogDisplayer.getDefault().notify(nd) != NotifyDescriptor.OK_OPTION) {
/* 166:166 */         return;
/* 167:    */       }
/* 168:    */       
/* 169:169 */       String[] n = JTsVariableList.this.names(sel);
/* 170:170 */       for (int i = 0; i < n.length; i++) {
/* 171:171 */         variables.remove(n[i]);
/* 172:    */       }
/* 173:173 */       ((JTsVariableList.CustomTableModel)table.getModel()).fireTableStructureChanged();
/* 174:174 */       firePropertyChange("delete", null, null);
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   private class ClearAction extends AbstractAction
/* 179:    */   {
/* 180:    */     public ClearAction() {
/* 181:181 */       super();
/* 182:182 */       enabled = false;
/* 183:    */     }
/* 184:    */     
/* 185:    */     public void actionPerformed(ActionEvent e)
/* 186:    */     {
/* 187:187 */       variables.clear();
/* 188:188 */       ((JTsVariableList.CustomTableModel)table.getModel()).fireTableStructureChanged();
/* 189:189 */       firePropertyChange("clear", null, null);
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   private XTable buildTable() {
/* 194:194 */     XTable result = new XTable();
/* 195:195 */     result.setNoDataRenderer(new XTable.DefaultNoDataRenderer("Drop data here", "Drop data here"));
/* 196:    */     
/* 197:197 */     result.setDefaultRenderer(TsData.class, new TsSparklineCellRenderer());
/* 198:198 */     result.setDefaultRenderer(TsPeriod.class, new TsPeriodTableCellRenderer());
/* 199:199 */     result.setDefaultRenderer(TsFrequency.class, new TsFrequencyTableCellRenderer());
/* 200:200 */     result.setDefaultRenderer(TsIdentifier.class, new TsIdentifierTableCellRenderer(null));
/* 201:    */     
/* 202:202 */     result.setModel(new CustomTableModel());
/* 203:203 */     XTable.setWidthAsPercentages(result, new double[] { 0.1D, 0.2D, 0.1D, 0.1D, 0.1D, 0.1D, 0.3D });
/* 204:    */     
/* 205:205 */     result.setAutoCreateRowSorter(true);
/* 206:206 */     TableRowSorter<TableModel> sorter = new TableRowSorter(result.getModel());
/* 207:207 */     result.setRowSorter(sorter);
/* 208:208 */     result.setDragEnabled(true);
/* 209:209 */     result.setTransferHandler(new TsVariableTransferHandler());
/* 210:210 */     result.setFillsViewportHeight(true);
/* 211:    */     
/* 212:    */ 
/* 213:    */ 
/* 214:214 */     return result;
/* 215:    */   }
/* 216:    */   
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */   public class TsVariableTransferHandler
/* 223:    */     extends TransferHandler
/* 224:    */   {
/* 225:    */     public TsVariableTransferHandler() {}
/* 226:    */     
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */     public int getSourceActions(JComponent c)
/* 232:    */     {
/* 233:233 */       return 1;
/* 234:    */     }
/* 235:    */     
/* 236:    */     protected Transferable createTransferable(JComponent c)
/* 237:    */     {
/* 238:238 */       return null;
/* 239:    */     }
/* 240:    */     
/* 241:    */     public boolean canImport(TransferHandler.TransferSupport support)
/* 242:    */     {
/* 243:243 */       boolean result = TssTransferSupport.getDefault().canImport(support.getDataFlavors());
/* 244:244 */       if ((result) && (support.isDrop())) {
/* 245:245 */         support.setDropAction(1);
/* 246:    */       }
/* 247:247 */       return result;
/* 248:    */     }
/* 249:    */     
/* 250:    */     public boolean importData(TransferHandler.TransferSupport support)
/* 251:    */     {
/* 252:252 */       TsCollection col = TssTransferSupport.getDefault().toTsCollection(support.getTransferable());
/* 253:253 */       if (col != null) {
/* 254:254 */         col.query(TsInformationType.All);
/* 255:255 */         if (!col.isEmpty()) {
/* 256:256 */           appendTsVariables(col);
/* 257:    */         }
/* 258:258 */         return true;
/* 259:    */       }
/* 260:260 */       return false;
/* 261:    */     }
/* 262:    */   }
/* 263:    */   
/* 264:    */   public void appendTsVariables(TsCollection coll) {
/* 265:265 */     for (Ts s : coll) {
/* 266:266 */       if (s.getMoniker().isAnonymous()) {
/* 267:267 */         variables.set(variables.nextName(), new TsVariable(s.getName(), s.getTsData()));
/* 268:    */       } else {
/* 269:269 */         variables.set(variables.nextName(), new DynamicTsVariable(s.getName(), s.getMoniker(), s.getTsData()));
/* 270:    */       }
/* 271:    */     }
/* 272:272 */     ((CustomTableModel)table.getModel()).fireTableStructureChanged();
/* 273:    */   }
/* 274:    */   
/* 275:    */   private static class TsIdentifierTableCellRenderer extends DefaultTableCellRenderer
/* 276:    */   {
/* 277:277 */     final MonikerUI monikerUI = MonikerUI.getDefault();
/* 278:    */     
/* 279:    */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 280:    */     {
/* 281:281 */       JLabel result = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 282:282 */       TsIdentifier identifier = (TsIdentifier)value;
/* 283:283 */       result.setText(identifier.getName());
/* 284:284 */       result.setIcon(monikerUI.getIcon(identifier.getMoniker()));
/* 285:285 */       return result;
/* 286:    */     } }
/* 287:    */   
/* 288:288 */   private static final String[] information = { "Name", "Description", "Type", "Frequency", "Start", "End", "Data" };
/* 289:    */   
/* 290:    */   private class CustomTableModel extends AbstractTableModel
/* 291:    */   {
/* 292:    */     private String[] names;
/* 293:    */     
/* 294:    */     public void fireTableStructureChanged()
/* 295:    */     {
/* 296:296 */       names = variables.getNames();
/* 297:297 */       super.fireTableStructureChanged();
/* 298:298 */       JTsVariableList.this.updateMenus();
/* 299:    */     }
/* 300:    */     
/* 301:    */     public CustomTableModel() {
/* 302:302 */       names = variables.getNames();
/* 303:    */     }
/* 304:    */     
/* 305:    */     public int getRowCount()
/* 306:    */     {
/* 307:307 */       return names.length;
/* 308:    */     }
/* 309:    */     
/* 310:    */     public int getColumnCount()
/* 311:    */     {
/* 312:312 */       return 7;
/* 313:    */     }
/* 314:    */     
/* 315:    */     public Object getValueAt(int rowIndex, int columnIndex)
/* 316:    */     {
/* 317:317 */       if (columnIndex == 0) {
/* 318:318 */         return names[rowIndex];
/* 319:    */       }
/* 320:    */       
/* 321:321 */       ITsVariable var = (ITsVariable)variables.get(names[rowIndex]);
/* 322:322 */       switch (columnIndex) {
/* 323:    */       case 0: 
/* 324:324 */         return names[rowIndex];
/* 325:    */       case 1: 
/* 326:326 */         return var.getDescription();
/* 327:    */       case 2: 
/* 328:328 */         return var.getClass().getSimpleName();
/* 329:    */       case 3: 
/* 330:330 */         return var.getDefinitionFrequency();
/* 331:    */       case 4: 
/* 332:332 */         TsDomain d = var.getDefinitionDomain();
/* 333:333 */         if (d != null) {
/* 334:334 */           return d.getStart();
/* 335:    */         }
/* 336:    */       
/* 337:    */       case 5: 
/* 338:338 */         TsDomain d = var.getDefinitionDomain();
/* 339:339 */         if (d != null) {
/* 340:340 */           return d.getLast();
/* 341:    */         }
/* 342:    */       
/* 343:    */       case 6: 
/* 344:344 */         TsDomain d = var.getDefinitionDomain();
/* 345:345 */         if (d != null) {
/* 346:346 */           List<DataBlock> data = Collections.singletonList(new DataBlock(d.getLength()));
/* 347:347 */           var.data(d, data);
/* 348:348 */           return new TsData(d.getStart(), (IReadDataBlock)data.get(0));
/* 349:    */         }
/* 350:    */         break;
/* 351:    */       }
/* 352:352 */       return null;
/* 353:    */     }
/* 354:    */     
/* 355:    */ 
/* 356:    */ 
/* 357:    */     public String getColumnName(int column)
/* 358:    */     {
/* 359:359 */       return JTsVariableList.information[column];
/* 360:    */     }
/* 361:    */     
/* 362:    */     public Class<?> getColumnClass(int columnIndex)
/* 363:    */     {
/* 364:364 */       switch (columnIndex) {
/* 365:    */       case 4: 
/* 366:366 */         return TsPeriod.class;
/* 367:    */       case 5: 
/* 368:368 */         return TsPeriod.class;
/* 369:    */       case 6: 
/* 370:370 */         return TsData.class;
/* 371:    */       }
/* 372:    */       
/* 373:373 */       return super.getColumnClass(columnIndex);
/* 374:    */     }
/* 375:    */   }
/* 376:    */   
/* 377:    */   private void updateMenus() {
/* 378:378 */     clear.setEnabled(!variables.isEmpty());
/* 379:379 */     int selectedRows = table.getSelectedRowCount();
/* 380:380 */     rename.setEnabled(selectedRows == 1);
/* 381:381 */     remove.setEnabled(selectedRows > 0);
/* 382:    */   }
/* 383:    */   
/* 384:    */   private class ListTableSelectionListener implements ListSelectionListener {
/* 385:    */     private ListTableSelectionListener() {}
/* 386:    */     
/* 387:    */     public void valueChanged(ListSelectionEvent e) {
/* 388:388 */       if (!e.getValueIsAdjusting()) {
/* 389:389 */         ListSelectionModel model = (ListSelectionModel)e.getSource();
/* 390:390 */         JTsVariableList.this.updateMenus();
/* 391:    */       }
/* 392:    */     }
/* 393:    */   }
/* 394:    */   
/* 395:    */   private class VarName extends NotifyDescriptor.InputLine
/* 396:    */   {
/* 397:    */     VarName(final TsVariables vars, String title, String text, final String oldname) {
/* 398:398 */       super(text, 3, 2);
/* 399:    */       
/* 400:400 */       setInputText(oldname);
/* 401:401 */       textField.addKeyListener(new KeyListener()
/* 402:    */       {
/* 403:    */         public void keyTyped(KeyEvent e) {}
/* 404:    */         
/* 405:    */ 
/* 406:    */ 
/* 407:    */         public void keyPressed(KeyEvent e)
/* 408:    */         {
/* 409:409 */           if ((e.getKeyCode() == 10) && (!textField.getInputVerifier().verify(textField))) {
/* 410:410 */             e.consume();
/* 411:    */           }
/* 412:    */         }
/* 413:    */         
/* 414:    */ 
/* 415:    */ 
/* 416:    */         public void keyReleased(KeyEvent e) {}
/* 417:417 */       });
/* 418:418 */       textField.setInputVerifier(new InputVerifier()
/* 419:    */       {
/* 420:    */         public boolean verify(JComponent input) {
/* 421:421 */           JTextField txt = (JTextField)input;
/* 422:422 */           String name = txt.getText();
/* 423:423 */           if (name.equals(oldname)) {
/* 424:424 */             return true;
/* 425:    */           }
/* 426:426 */           if (vars.contains(name)) {
/* 427:427 */             NotifyDescriptor nd = new NotifyDescriptor.Message(name + " is in use. You should choose another name!");
/* 428:428 */             DialogDisplayer.getDefault().notify(nd);
/* 429:429 */             return false;
/* 430:    */           }
/* 431:431 */           if (!vars.getNameValidator().accept(name)) {
/* 432:432 */             NotifyDescriptor nd = new NotifyDescriptor.Message(vars.getNameValidator().getLastError());
/* 433:433 */             DialogDisplayer.getDefault().notify(nd);
/* 434:434 */             return false;
/* 435:    */           }
/* 436:436 */           return true;
/* 437:    */         }
/* 438:    */       });
/* 439:    */     }
/* 440:    */   }
/* 441:    */ }
