/*  1:   */ package ec.ui.list;
/*  2:   */ 
/*  3:   */ import javax.swing.table.DefaultTableCellRenderer;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public class TsPeriodTableCellRenderer
/* 13:   */   extends DefaultTableCellRenderer
/* 14:   */ {
/* 15:   */   public TsPeriodTableCellRenderer()
/* 16:   */   {
/* 17:17 */     setHorizontalAlignment(11);
/* 18:   */   }
/* 19:   */ }
