package ec.ui.interfaces;

import ec.tstoolkit.timeseries.simplets.TsData;

public abstract interface ITsDataView
  extends ITsControl
{
  public static final String TS_DATA_PROPERTY = "tsData";
  
  public abstract void setTsData(TsData paramTsData);
  
  public abstract TsData getTsData();
}
