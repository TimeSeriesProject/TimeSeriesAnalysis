package ec.ui.interfaces;

public abstract interface IDisposable
{
  public abstract void dispose();
}
