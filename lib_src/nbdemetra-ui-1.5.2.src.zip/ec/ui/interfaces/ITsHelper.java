package ec.ui.interfaces;

public abstract interface ITsHelper {}
