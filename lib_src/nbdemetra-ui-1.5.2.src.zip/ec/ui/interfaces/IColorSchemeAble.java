package ec.ui.interfaces;

import ec.util.chart.ColorScheme;

public abstract interface IColorSchemeAble
{
  public static final String COLOR_SCHEME_PROPERTY = "colorScheme";
  
  public abstract void setColorScheme(ColorScheme paramColorScheme);
  
  public abstract ColorScheme getColorScheme();
}
