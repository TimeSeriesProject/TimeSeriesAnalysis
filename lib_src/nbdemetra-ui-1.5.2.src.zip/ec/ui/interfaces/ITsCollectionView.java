/*  1:   */ package ec.ui.interfaces;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.tsaction.ITsAction;
/*  4:   */ import ec.tss.Ts;
/*  5:   */ import ec.tss.TsCollection;
/*  6:   */ 
/*  7:   */ public abstract interface ITsCollectionView extends ITsControl
/*  8:   */ {
/*  9:   */   public static final String COLLECTION_PROPERTY = "tsCollection";
/* 10:   */   public static final String SELECTION_PROPERTY = "selection";
/* 11:   */   public static final String UDPATE_MODE_PROPERTY = "tsUpdateMode";
/* 12:   */   public static final String TS_ACTION_PROPERTY = "tsAction";
/* 13:   */   
/* 14:   */   public abstract TsCollection getTsCollection();
/* 15:   */   
/* 16:   */   public abstract void setTsCollection(TsCollection paramTsCollection);
/* 17:   */   
/* 18:   */   public abstract Ts[] getSelection();
/* 19:   */   
/* 20:   */   public abstract void setSelection(Ts[] paramArrayOfTs);
/* 21:   */   
/* 22:   */   public abstract int getSelectionSize();
/* 23:   */   
/* 24:   */   public abstract TsUpdateMode getTsUpdateMode();
/* 25:   */   
/* 26:   */   public abstract void setTsUpdateMode(TsUpdateMode paramTsUpdateMode);
/* 27:   */   
/* 28:   */   public abstract void setTsAction(ITsAction paramITsAction);
/* 29:   */   
/* 30:   */   public abstract ITsAction getTsAction();
/* 31:   */   
/* 32:   */   public static abstract enum TsUpdateMode
/* 33:   */   {
/* 34:34 */     None, 
/* 35:   */     
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:39 */     Single, 
/* 40:   */     
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:44 */     Replace, 
/* 45:   */     
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:49 */     Append;
/* 50:   */     
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */     public boolean isReadOnly()
/* 56:   */     {
/* 57:57 */       return this == None;
/* 58:   */     }
/* 59:   */     
/* 60:   */     public abstract void update(TsCollection paramTsCollection1, TsCollection paramTsCollection2);
/* 61:   */   }
/* 62:   */ }
