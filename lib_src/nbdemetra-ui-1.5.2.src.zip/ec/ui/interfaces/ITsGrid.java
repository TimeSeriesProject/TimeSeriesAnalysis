/*   1:    */ package ec.ui.interfaces;
/*   2:    */ 
/*   3:    */ 
/*   4:    */ public abstract interface ITsGrid
/*   5:    */   extends ITsCollectionView, IColorSchemeAble
/*   6:    */ {
/*   7:    */   public static final String ORIENTATION_PROPERTY = "orientation";
/*   8:    */   
/*   9:    */   public static final String CHRONOLOGY_PROPERTY = "chronology";
/*  10:    */   
/*  11:    */   public static final String MODE_PROPERTY = "mode";
/*  12:    */   
/*  13:    */   public static final String SINGLE_TS_INDEX_PROPERTY = "singleTsIndex";
/*  14:    */   
/*  15:    */   public static final String ZOOM_PROPERTY = "zoom";
/*  16:    */   
/*  17:    */ 
/*  18:    */   public abstract Orientation getOrientation();
/*  19:    */   
/*  20:    */ 
/*  21:    */   public abstract void setOrientation(Orientation paramOrientation);
/*  22:    */   
/*  23:    */ 
/*  24:    */   public abstract Chronology getChronology();
/*  25:    */   
/*  26:    */ 
/*  27:    */   public abstract void setChronology(Chronology paramChronology);
/*  28:    */   
/*  29:    */ 
/*  30:    */   public abstract Mode getMode();
/*  31:    */   
/*  32:    */   public abstract void setMode(Mode paramMode);
/*  33:    */   
/*  34:    */   public abstract void setSingleTsIndex(int paramInt);
/*  35:    */   
/*  36:    */   public abstract int getSingleTsIndex();
/*  37:    */   
/*  38:    */   @Deprecated
/*  39:    */   public abstract void zoom(int paramInt);
/*  40:    */   
/*  41:    */   public abstract int getZoomRatio();
/*  42:    */   
/*  43:    */   public abstract void setZoomRatio(int paramInt);
/*  44:    */   
/*  45:    */   public static enum Chronology
/*  46:    */   {
/*  47: 47 */     ASCENDING, 
/*  48:    */     
/*  49:    */ 
/*  50:    */ 
/*  51: 51 */     DESCENDING;
/*  52:    */     
/*  53:    */ 
/*  54:    */ 
/*  55:    */     public Chronology reverse()
/*  56:    */     {
/*  57: 57 */       return this == ASCENDING ? DESCENDING : ASCENDING;
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */   public static enum Mode
/*  66:    */   {
/*  67: 67 */     SINGLETS, 
/*  68:    */     
/*  69:    */ 
/*  70:    */ 
/*  71: 71 */     MULTIPLETS;
/*  72:    */     
/*  73:    */ 
/*  74:    */ 
/*  75:    */     public Mode toggle()
/*  76:    */     {
/*  77: 77 */       return this == SINGLETS ? MULTIPLETS : SINGLETS;
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */   public static enum Orientation
/*  88:    */   {
/*  89: 89 */     NORMAL, 
/*  90:    */     
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94: 94 */     REVERSED;
/*  95:    */     
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */     public Orientation transpose()
/* 100:    */     {
/* 101:101 */       return this == NORMAL ? REVERSED : NORMAL;
/* 102:    */     }
/* 103:    */   }
/* 104:    */ }
