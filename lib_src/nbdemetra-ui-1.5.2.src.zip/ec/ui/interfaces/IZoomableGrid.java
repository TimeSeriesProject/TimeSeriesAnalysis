package ec.ui.interfaces;

public abstract interface IZoomableGrid
{
  public static final String ZOOM_PROPERTY = "zoom";
  public static final String COLOR_SCALE_PROPERTY = "scale";
  
  public abstract int getZoomRatio();
  
  public abstract void setZoomRatio(int paramInt);
  
  public abstract double getColorScale();
  
  public abstract void setColorScale(double paramDouble);
}
