package ec.ui.interfaces;

public abstract interface ITsPrinter
{
  public abstract boolean printPreview();
  
  public abstract boolean print();
}
