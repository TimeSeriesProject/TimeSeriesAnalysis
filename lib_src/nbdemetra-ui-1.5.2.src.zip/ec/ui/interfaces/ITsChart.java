/*  1:   */ package ec.ui.interfaces;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.awt.IPropertyChangeSource;
/*  4:   */ 
/*  5:   */ public abstract interface ITsChart extends ITsCollectionView, IColorSchemeAble, IPropertyChangeSource
/*  6:   */ {
/*  7:   */   public static final String LEGEND_VISIBLE_PROPERTY = "legendVisible";
/*  8:   */   public static final String TITLE_VISIBLE_PROPERTY = "titleVisible";
/*  9:   */   public static final String AXIS_VISIBLE_PROPERTY = "axisVisible";
/* 10:   */   public static final String TITLE_PROPERTY = "title";
/* 11:   */   public static final String LINES_THICKNESS_PROPERTY = "linesThickness";
/* 12:   */   
/* 13:   */   public abstract void setLegendVisible(boolean paramBoolean);
/* 14:   */   
/* 15:   */   public abstract boolean isLegendVisible();
/* 16:   */   
/* 17:   */   public abstract void setTitleVisible(boolean paramBoolean);
/* 18:   */   
/* 19:   */   public abstract boolean isTitleVisible();
/* 20:   */   
/* 21:   */   public abstract void setAxisVisible(boolean paramBoolean);
/* 22:   */   
/* 23:   */   public abstract boolean isAxisVisible();
/* 24:   */   
/* 25:   */   public abstract void setTitle(String paramString);
/* 26:   */   
/* 27:   */   public abstract String getTitle();
/* 28:   */   
/* 29:   */   public abstract void showAll();
/* 30:   */   
/* 31:   */   public abstract LinesThickness getLinesThickness();
/* 32:   */   
/* 33:   */   public abstract void setLinesThickness(LinesThickness paramLinesThickness);
/* 34:   */   
/* 35:   */   public static enum LinesThickness
/* 36:   */   {
/* 37:37 */     Thin,  Thick;
/* 38:   */   }
/* 39:   */ }
