/*  1:   */ package ec.ui.interfaces;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ 
/*  5:   */ public abstract interface ITsGrowthChart extends ITsChart {
/*  6:   */   public static final String GROWTH_KIND_PROPERTY = "growthKind";
/*  7:   */   public static final String LAST_YEARS_PROPERTY = "lastYears";
/*  8:   */   public static final String USE_TOOL_LAYOUT_PROPERTY = "useToolLayout";
/*  9:   */   
/* 10:   */   public abstract GrowthKind getGrowthKind();
/* 11:   */   
/* 12:   */   public abstract void setGrowthKind(GrowthKind paramGrowthKind);
/* 13:   */   
/* 14:   */   public abstract int getLastYears();
/* 15:   */   
/* 16:   */   public static enum GrowthKind {
/* 17:17 */     PreviousPeriod, 
/* 18:18 */     PreviousYear;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public abstract void setLastYears(int paramInt);
/* 22:   */   
/* 23:   */   public abstract boolean isUseToolLayout();
/* 24:   */   
/* 25:   */   public abstract void setUseToolLayout(boolean paramBoolean);
/* 26:   */   
/* 27:   */   public abstract Ts[] getGrowthData();
/* 28:   */ }
