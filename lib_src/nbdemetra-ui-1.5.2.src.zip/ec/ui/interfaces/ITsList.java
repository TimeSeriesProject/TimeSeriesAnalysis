/*  1:   */ package ec.ui.interfaces;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ public abstract interface ITsList
/*  5:   */   extends ITsCollectionView
/*  6:   */ {
/*  7:   */   public static final String MULTI_SELECTION_PROPERTY = "multiSelection";
/*  8:   */   
/*  9:   */   public static final String SHOW_HEADER_PROPERTY = "showHeader";
/* 10:   */   
/* 11:   */   public static final String SORTABLE_PROPERTY = "sortable";
/* 12:   */   
/* 13:   */   public static final String INFORMATION_PROPERTY = "information";
/* 14:   */   
/* 15:   */   public static final String SORT_INFO_PROPERTY = "sortInfo";
/* 16:   */   
/* 17:   */ 
/* 18:   */   public abstract boolean isMultiSelection();
/* 19:   */   
/* 20:   */ 
/* 21:   */   public abstract void setMultiSelection(boolean paramBoolean);
/* 22:   */   
/* 23:   */   public abstract boolean isShowHeader();
/* 24:   */   
/* 25:   */   public abstract void setShowHeader(boolean paramBoolean);
/* 26:   */   
/* 27:   */   public abstract boolean isSortable();
/* 28:   */   
/* 29:   */   public abstract void setSortable(boolean paramBoolean);
/* 30:   */   
/* 31:   */   public abstract InfoType[] getInformation();
/* 32:   */   
/* 33:   */   public abstract void setInformation(InfoType[] paramArrayOfInfoType);
/* 34:   */   
/* 35:   */   public abstract InfoType getSortInfo();
/* 36:   */   
/* 37:   */   public abstract void setSortInfo(InfoType paramInfoType);
/* 38:   */   
/* 39:   */   public static enum InfoType
/* 40:   */   {
/* 41:41 */     Name, 
/* 42:42 */     Source, 
/* 43:43 */     Id, 
/* 44:44 */     Frequency, 
/* 45:45 */     Start, 
/* 46:46 */     End, 
/* 47:47 */     Length, 
/* 48:48 */     Data, 
/* 49:49 */     TsIdentifier;
/* 50:   */   }
/* 51:   */ }
