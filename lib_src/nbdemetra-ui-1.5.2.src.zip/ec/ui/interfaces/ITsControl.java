/*  1:   */ package ec.ui.interfaces;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.awt.IPropertyChangeSource;
/*  4:   */ import ec.tss.tsproviders.utils.DataFormat;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public abstract interface ITsControl
/* 13:   */   extends IDisposable, IPropertyChangeSource
/* 14:   */ {
/* 15:   */   public static final String DATA_FORMAT_PROPERTY = "dataFormat";
/* 16:   */   
/* 17:   */   public abstract boolean isToolWindowLayout();
/* 18:   */   
/* 19:   */   public abstract void setToolWindowLayout(boolean paramBoolean);
/* 20:   */   
/* 21:   */   @Nullable
/* 22:   */   public abstract TooltipType getTsTooltip();
/* 23:   */   
/* 24:   */   public abstract void setTsTooltip(@Nullable TooltipType paramTooltipType);
/* 25:   */   
/* 26:   */   @Nullable
/* 27:   */   public abstract ITsPrinter getPrinter();
/* 28:   */   
/* 29:   */   @Nullable
/* 30:   */   public abstract ITsHelper getHelper();
/* 31:   */   
/* 32:   */   @Nullable
/* 33:   */   public abstract DataFormat getDataFormat();
/* 34:   */   
/* 35:   */   public abstract void setDataFormat(@Nullable DataFormat paramDataFormat);
/* 36:   */   
/* 37:   */   public static enum TooltipType
/* 38:   */   {
/* 39:39 */     None,  SmallChart,  LastObs,  Name,  Identifier;
/* 40:   */   }
/* 41:   */ }
