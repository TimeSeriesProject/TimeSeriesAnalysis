package ec.ui.interfaces;

import ec.tstoolkit.data.IReadDataBlock;

public abstract interface IReadDataBlockView
{
  public abstract void setDataBlock(IReadDataBlock paramIReadDataBlock);
  
  public abstract void reset();
}
