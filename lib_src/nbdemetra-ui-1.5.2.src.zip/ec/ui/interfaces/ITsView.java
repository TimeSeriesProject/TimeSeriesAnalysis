package ec.ui.interfaces;

import ec.tss.Ts;

public abstract interface ITsView
  extends ITsControl
{
  public static final String TS_PROPERTY = "ts";
  
  public abstract Ts getTs();
  
  public abstract void setTs(Ts paramTs);
}
