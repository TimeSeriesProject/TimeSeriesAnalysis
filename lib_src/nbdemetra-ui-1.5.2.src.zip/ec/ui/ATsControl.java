/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.IConfigurable;
/*   4:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   5:    */ import ec.nbdemetra.ui.awt.ActionMaps;
/*   6:    */ import ec.nbdemetra.ui.awt.InputMaps;
/*   7:    */ import ec.nbdemetra.ui.awt.JComponent2;
/*   8:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   9:    */ import ec.ui.commands.TsControlCommand;
/*  10:    */ import ec.ui.interfaces.ITsControl;
/*  11:    */ import ec.ui.interfaces.ITsControl.TooltipType;
/*  12:    */ import ec.ui.interfaces.ITsHelper;
/*  13:    */ import ec.ui.interfaces.ITsPrinter;
/*  14:    */ import ec.util.various.swing.JCommand;
/*  15:    */ import java.awt.Toolkit;
/*  16:    */ import java.awt.datatransfer.Clipboard;
/*  17:    */ import java.awt.datatransfer.ClipboardOwner;
/*  18:    */ import java.awt.datatransfer.Transferable;
/*  19:    */ import java.awt.event.ActionEvent;
/*  20:    */ import java.beans.PropertyChangeEvent;
/*  21:    */ import java.beans.PropertyChangeListener;
/*  22:    */ import java.util.Map;
/*  23:    */ import java.util.Map.Entry;
/*  24:    */ import javax.swing.AbstractAction;
/*  25:    */ import javax.swing.Action;
/*  26:    */ import javax.swing.ActionMap;
/*  27:    */ import javax.swing.InputMap;
/*  28:    */ import javax.swing.KeyStroke;
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ public abstract class ATsControl
/*  45:    */   extends JComponent2
/*  46:    */   implements ITsControl, ClipboardOwner
/*  47:    */ {
/*  48:    */   private static final long serialVersionUID = 3804565526142589316L;
/*  49:    */   public static final String PRINT_ACTION = "print";
/*  50:    */   public static final String CONFIGURE_ACTION = "configure";
/*  51:    */   public static final String FORMAT_ACTION = "format";
/*  52: 52 */   protected ITsControl.TooltipType m_tooltip = ITsControl.TooltipType.None;
/*  53: 53 */   protected boolean m_toolwindow = false;
/*  54:    */   protected final ThemeSupport themeSupport;
/*  55:    */   
/*  56:    */   public ATsControl() {
/*  57: 57 */     themeSupport = new ThemeSupport()
/*  58:    */     {
/*  59:    */       protected void dataFormatChanged() {
/*  60: 60 */         firePropertyChange("dataFormat", null, getDataFormat());
/*  61:    */       }
/*  62:    */       
/*  63:    */       protected void colorSchemeChanged()
/*  64:    */       {
/*  65: 65 */         firePropertyChange("colorScheme", null, getColorScheme());
/*  66:    */       }
/*  67: 67 */     };
/*  68: 68 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  69:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  70:    */         String str;
/*  71: 71 */         switch ((str = evt.getPropertyName()).hashCode()) {case 900197441:  if (str.equals("dataFormat")) break; break; case 966195944:  if (!str.equals("colorScheme"))
/*  72:    */           {
/*  73: 73 */             return;onDataFormatChange();
/*  74:    */           }
/*  75:    */           else {
/*  76: 76 */             onColorSchemeChange();
/*  77:    */           }
/*  78:    */           
/*  79:    */           break;
/*  80:    */         }
/*  81:    */         
/*  82:    */       }
/*  83: 83 */     });
/*  84: 84 */     themeSupport.register();
/*  85:    */     
/*  86: 86 */     ActionMap am = getActionMap();
/*  87: 87 */     am.put("print", TsControlCommand.printPreview().toAction(this));
/*  88: 88 */     am.put("configure", new ConfigureAction());
/*  89: 89 */     am.put("format", TsControlCommand.editDataFormat().toAction(this));
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */   protected abstract void onDataFormatChange();
/*  94:    */   
/*  95:    */ 
/*  96:    */   protected abstract void onColorSchemeChange();
/*  97:    */   
/*  98:    */ 
/*  99:    */   public DataFormat getDataFormat()
/* 100:    */   {
/* 101:101 */     return themeSupport.getLocalDataFormat();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setDataFormat(DataFormat dataFormat)
/* 105:    */   {
/* 106:106 */     themeSupport.setLocalDataFormat(dataFormat);
/* 107:    */   }
/* 108:    */   
/* 109:    */ 
/* 110:    */   public void dispose()
/* 111:    */   {
/* 112:112 */     themeSupport.dispose();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public ITsControl.TooltipType getTsTooltip()
/* 116:    */   {
/* 117:117 */     return m_tooltip;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void setTsTooltip(ITsControl.TooltipType tooltipType)
/* 121:    */   {
/* 122:122 */     m_tooltip = tooltipType;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public boolean isToolWindowLayout()
/* 126:    */   {
/* 127:127 */     return m_toolwindow;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void setToolWindowLayout(boolean behavior)
/* 131:    */   {
/* 132:132 */     m_toolwindow = behavior;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public ITsHelper getHelper()
/* 136:    */   {
/* 137:137 */     return null;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public ITsPrinter getPrinter()
/* 141:    */   {
/* 142:142 */     return null;
/* 143:    */   }
/* 144:    */   
/* 145:    */ 
/* 146:    */   public void lostOwnership(Clipboard clipboard, Transferable contents) {}
/* 147:    */   
/* 148:    */ 
/* 149:    */   protected Transferable getClipboardContents()
/* 150:    */   {
/* 151:151 */     Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 152:152 */     return cb.getContents(this);
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected void setClipboardContents(Transferable transferable) {
/* 156:156 */     Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 157:157 */     cb.setContents(transferable, this);
/* 158:    */   }
/* 159:    */   
/* 160:    */   protected void fillActionMap(ActionMap am) {
/* 161:161 */     for (Map.Entry<Object, Action> o : ActionMaps.asMap(getActionMap(), false).entrySet()) {
/* 162:162 */       am.put(o.getKey(), (Action)o.getValue());
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   protected void fillInputMap(InputMap im) {
/* 167:167 */     for (Map.Entry<KeyStroke, Object> o : InputMaps.asMap(getInputMap(), false).entrySet()) {
/* 168:168 */       im.put((KeyStroke)o.getKey(), o.getValue());
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   private class ConfigureAction extends AbstractAction
/* 173:    */   {
/* 174:    */     public ConfigureAction()
/* 175:    */     {
/* 176:176 */       super();
/* 177:    */     }
/* 178:    */     
/* 179:    */     public void actionPerformed(ActionEvent e)
/* 180:    */     {
/* 181:181 */       if ((ATsControl.this instanceof IConfigurable)) {
/* 182:182 */         IConfigurable configurable = (IConfigurable)ATsControl.this;
/* 183:183 */         configurable.setConfig(configurable.editConfig(configurable.getConfig()));
/* 184:    */       }
/* 185:    */     }
/* 186:    */   }
/* 187:    */ }
