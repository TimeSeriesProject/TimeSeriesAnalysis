/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsEvent;
/*   6:    */ import ec.tss.TsFactory;
/*   7:    */ import ec.tss.TsInformationType;
/*   8:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   9:    */ import ec.ui.interfaces.IColorSchemeAble;
/*  10:    */ import ec.ui.interfaces.ITsView;
/*  11:    */ import ec.util.chart.ColorScheme;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.beans.PropertyChangeListener;
/*  14:    */ import java.util.Observable;
/*  15:    */ import java.util.Observer;
/*  16:    */ import java.util.concurrent.atomic.AtomicBoolean;
/*  17:    */ import javax.swing.SwingUtilities;
/*  18:    */ import javax.swing.TransferHandler;
/*  19:    */ import javax.swing.TransferHandler.TransferSupport;
/*  20:    */ 
/*  21:    */ 
/*  22:    */ public abstract class ATsView
/*  23:    */   extends ATsControl
/*  24:    */   implements ITsView, IColorSchemeAble
/*  25:    */ {
/*  26:    */   protected Ts m_ts;
/*  27:    */   protected final TsFactoryObserver tsFactoryObserver;
/*  28:    */   
/*  29:    */   public ATsView()
/*  30:    */   {
/*  31: 31 */     m_ts = null;
/*  32: 32 */     tsFactoryObserver = new TsFactoryObserver();
/*  33:    */     
/*  34: 34 */     addPropertyChangeListener(new PropertyChangeListener()
/*  35:    */     {
/*  36:    */       public void propertyChange(PropertyChangeEvent evt)
/*  37:    */       {
/*  38: 38 */         String p = evt.getPropertyName();
/*  39: 39 */         if (p.equals("ts")) {
/*  40: 40 */           onTsChange();
/*  41:    */         }
/*  42:    */         
/*  43:    */       }
/*  44: 44 */     });
/*  45: 45 */     TsFactory.instance.addObserver(tsFactoryObserver);
/*  46:    */   }
/*  47:    */   
/*  48:    */ 
/*  49:    */ 
/*  50:    */   protected abstract void onTsChange();
/*  51:    */   
/*  52:    */ 
/*  53:    */   public Ts getTs()
/*  54:    */   {
/*  55: 55 */     return m_ts;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setTs(Ts ts)
/*  59:    */   {
/*  60: 60 */     Ts old = m_ts;
/*  61: 61 */     m_ts = ts;
/*  62: 62 */     firePropertyChange("ts", old, m_ts);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public ColorScheme getColorScheme()
/*  66:    */   {
/*  67: 67 */     return themeSupport.getLocalColorScheme();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void setColorScheme(ColorScheme theme)
/*  71:    */   {
/*  72: 72 */     themeSupport.setLocalColorScheme(theme);
/*  73:    */   }
/*  74:    */   
/*  75:    */ 
/*  76:    */   public void dispose()
/*  77:    */   {
/*  78: 78 */     TsFactory.instance.deleteObserver(tsFactoryObserver);
/*  79: 79 */     super.dispose();
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected class TsFactoryObserver implements Observer
/*  83:    */   {
/*  84: 84 */     final AtomicBoolean dirty = new AtomicBoolean(false);
/*  85:    */     
/*  86:    */     protected TsFactoryObserver() {}
/*  87:    */     
/*  88: 88 */     public void update(Observable o, Object arg) { if ((arg instanceof TsEvent)) {
/*  89: 89 */         TsEvent event = (TsEvent)arg;
/*  90: 90 */         if ((event.isSeries()) && (ts.equals(m_ts))) {
/*  91: 91 */           dirty.set(true);
/*  92: 92 */           SwingUtilities.invokeLater(new Runnable()
/*  93:    */           {
/*  94:    */             public void run()
/*  95:    */             {
/*  96: 96 */               if (dirty.getAndSet(false)) {
/*  97: 97 */                 firePropertyChange("ts", null, m_ts);
/*  98:    */               }
/*  99:    */             }
/* 100:    */           });
/* 101:    */         }
/* 102:    */       }
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */   public class TsTransferHandler
/* 110:    */     extends TransferHandler
/* 111:    */   {
/* 112:    */     public TsTransferHandler() {}
/* 113:    */     
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */     public boolean canImport(TransferHandler.TransferSupport support)
/* 118:    */     {
/* 119:119 */       return TssTransferSupport.getDefault().canImport(support.getDataFlavors());
/* 120:    */     }
/* 121:    */     
/* 122:    */     public boolean importData(TransferHandler.TransferSupport support)
/* 123:    */     {
/* 124:124 */       Ts ts = TssTransferSupport.getDefault().toTs(support.getTransferable());
/* 125:125 */       if (ts != null) {
/* 126:126 */         ts.query(TsInformationType.All);
/* 127:127 */         setTs(ts);
/* 128:128 */         return true;
/* 129:    */       }
/* 130:130 */       return false;
/* 131:    */     }
/* 132:    */   }
/* 133:    */ }
