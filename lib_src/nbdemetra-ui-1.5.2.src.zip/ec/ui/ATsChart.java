/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.nbdemetra.ui.IConfigurable;
/*   5:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   6:    */ import ec.ui.commands.TsChartCommand;
/*   7:    */ import ec.ui.interfaces.ITsChart;
/*   8:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*   9:    */ import ec.util.chart.ColorScheme;
/*  10:    */ import ec.util.various.swing.FontAwesome;
/*  11:    */ import ec.util.various.swing.JCommand;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.beans.PropertyChangeListener;
/*  14:    */ import javax.swing.ActionMap;
/*  15:    */ import javax.swing.JCheckBoxMenuItem;
/*  16:    */ import javax.swing.JMenu;
/*  17:    */ import javax.swing.JMenuItem;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public abstract class ATsChart
/*  33:    */   extends ATsCollectionView
/*  34:    */   implements ITsChart
/*  35:    */ {
/*  36:    */   public static final String TITLE_VISIBLE_ACTION = "titleVisible";
/*  37:    */   public static final String LEGEND_VISIBLE_ACTION = "legendVisible";
/*  38:    */   public static final String THIN_LINE_ACTION = "thinLine";
/*  39:    */   public static final String THICK_LINE_ACTION = "thickLine";
/*  40:    */   public static final String SHOW_ALL_ACTION = "showAll";
/*  41:    */   public static final String SPLIT_ACTION = "splitIntoYearlyComponents";
/*  42:    */   protected static final boolean DEFAULT_LEGENDVISIBLE = true;
/*  43:    */   protected static final boolean DEFAULT_TITLEVISIBLE = true;
/*  44:    */   protected static final boolean DEFAULT_AXISVISIBLE = true;
/*  45:    */   protected static final String DEFAULT_TITLE = "";
/*  46: 46 */   protected static final ITsChart.LinesThickness DEFAULT_LINES_THICKNESS = ITsChart.LinesThickness.Thin;
/*  47:    */   protected boolean legendVisible;
/*  48:    */   protected boolean titleVisible;
/*  49:    */   protected boolean axisVisible;
/*  50:    */   protected String title;
/*  51:    */   protected ITsChart.LinesThickness linesThickness;
/*  52:    */   
/*  53:    */   public ATsChart()
/*  54:    */   {
/*  55: 55 */     legendVisible = true;
/*  56: 56 */     titleVisible = true;
/*  57: 57 */     axisVisible = true;
/*  58: 58 */     title = "";
/*  59: 59 */     linesThickness = DEFAULT_LINES_THICKNESS;
/*  60:    */     
/*  61: 61 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  62:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  63:    */         String str;
/*  64: 64 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1178448987:  if (str.equals("legendVisible")) break; break; case -430442095:  if (str.equals("axisVisible")) {} break; case 110371416:  if (str.equals("title")) {} break; case 574633781:  if (str.equals("linesThickness")) {} break; case 1196659450:  if (!str.equals("titleVisible"))
/*  65:    */           {
/*  66: 66 */             return;onLegendVisibleChange();
/*  67:    */           }
/*  68:    */           else {
/*  69: 69 */             onTitleVisibleChange();
/*  70: 70 */             return;
/*  71:    */             
/*  72: 72 */             onAxisVisibleChange();
/*  73: 73 */             return;
/*  74:    */             
/*  75: 75 */             onTitleChange();
/*  76: 76 */             return;
/*  77:    */             
/*  78: 78 */             onLinesThicknessChange();
/*  79:    */           }
/*  80:    */           break;
/*  81:    */         }
/*  82:    */       }
/*  83: 83 */     });
/*  84: 84 */     ActionMap am = getActionMap();
/*  85: 85 */     am.put("titleVisible", TsChartCommand.toggleTitleVisibility().toAction(this));
/*  86: 86 */     am.put("legendVisible", TsChartCommand.toggleLegendVisibility().toAction(this));
/*  87: 87 */     am.put("thinLine", TsChartCommand.applyLineThickNess(ITsChart.LinesThickness.Thin).toAction(this));
/*  88: 88 */     am.put("thickLine", TsChartCommand.applyLineThickNess(ITsChart.LinesThickness.Thick).toAction(this));
/*  89: 89 */     am.put("showAll", TsChartCommand.showAll().toAction(this));
/*  90: 90 */     am.put("splitIntoYearlyComponents", TsChartCommand.splitIntoYearlyComponents().toAction(this));
/*  91:    */   }
/*  92:    */   
/*  93:    */ 
/*  94:    */   protected abstract void onLegendVisibleChange();
/*  95:    */   
/*  96:    */ 
/*  97:    */   protected abstract void onTitleVisibleChange();
/*  98:    */   
/*  99:    */ 
/* 100:    */   protected abstract void onAxisVisibleChange();
/* 101:    */   
/* 102:    */   protected abstract void onTitleChange();
/* 103:    */   
/* 104:    */   protected abstract void onLinesThicknessChange();
/* 105:    */   
/* 106:    */   public boolean isLegendVisible()
/* 107:    */   {
/* 108:108 */     return legendVisible;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setLegendVisible(boolean show)
/* 112:    */   {
/* 113:113 */     boolean old = legendVisible;
/* 114:114 */     legendVisible = show;
/* 115:115 */     firePropertyChange("legendVisible", old, legendVisible);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean isTitleVisible()
/* 119:    */   {
/* 120:120 */     return titleVisible;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void setTitleVisible(boolean show)
/* 124:    */   {
/* 125:125 */     boolean old = titleVisible;
/* 126:126 */     titleVisible = show;
/* 127:127 */     firePropertyChange("titleVisible", old, titleVisible);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public String getTitle()
/* 131:    */   {
/* 132:132 */     return title;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setTitle(String title)
/* 136:    */   {
/* 137:137 */     String old = this.title;
/* 138:138 */     this.title = title;
/* 139:139 */     firePropertyChange("title", old, this.title);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean isAxisVisible()
/* 143:    */   {
/* 144:144 */     return axisVisible;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void setAxisVisible(boolean showingAxis)
/* 148:    */   {
/* 149:149 */     boolean old = axisVisible;
/* 150:150 */     axisVisible = showingAxis;
/* 151:151 */     firePropertyChange("axisVisible", old, axisVisible);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public ColorScheme getColorScheme()
/* 155:    */   {
/* 156:156 */     return themeSupport.getLocalColorScheme();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setColorScheme(ColorScheme colorScheme)
/* 160:    */   {
/* 161:161 */     themeSupport.setLocalColorScheme(colorScheme);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public ITsChart.LinesThickness getLinesThickness()
/* 165:    */   {
/* 166:166 */     return linesThickness;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void setLinesThickness(ITsChart.LinesThickness linesThickness)
/* 170:    */   {
/* 171:171 */     ITsChart.LinesThickness old = this.linesThickness;
/* 172:172 */     this.linesThickness = (linesThickness != null ? linesThickness : DEFAULT_LINES_THICKNESS);
/* 173:173 */     firePropertyChange("linesThickness", old, this.linesThickness);
/* 174:    */   }
/* 175:    */   
/* 176:    */   protected JMenu buildLinesThicknessMenu()
/* 177:    */   {
/* 178:178 */     ActionMap am = getActionMap();
/* 179:179 */     JMenu result = new JMenu("Lines thickness");
/* 180:    */     
/* 181:    */ 
/* 182:    */ 
/* 183:183 */     JMenuItem item = new JCheckBoxMenuItem(am.get("thinLine"));
/* 184:184 */     item.setText("Thin");
/* 185:185 */     result.add(item);
/* 186:    */     
/* 187:187 */     item = new JCheckBoxMenuItem(am.get("thickLine"));
/* 188:188 */     item.setText("Thick");
/* 189:189 */     result.add(item);
/* 190:    */     
/* 191:191 */     return result;
/* 192:    */   }
/* 193:    */   
/* 194:    */   protected JMenu buildExportImageMenu() {
/* 195:195 */     ActionMap am = getActionMap();
/* 196:196 */     JMenu result = new JMenu("Export image to");
/* 197:    */     
/* 198:    */ 
/* 199:    */ 
/* 200:200 */     JMenuItem item = new JMenuItem(am.get("print"));
/* 201:201 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_PRINT));
/* 202:202 */     item.setText("Printer...");
/* 203:203 */     result.add(item);
/* 204:    */     
/* 205:205 */     return result;
/* 206:    */   }
/* 207:    */   
/* 208:    */   protected JMenu buildChartMenu() {
/* 209:209 */     ActionMap am = getActionMap();
/* 210:210 */     JMenu result = buildMenu();
/* 211:    */     
/* 212:212 */     int index = 0;
/* 213:    */     
/* 214:    */ 
/* 215:215 */     index += 7;
/* 216:216 */     JMenuItem item = new JMenuItem(am.get("splitIntoYearlyComponents"));
/* 217:217 */     item.setText("Split into yearly components");
/* 218:218 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_CHAIN_BROKEN));
/* 219:219 */     ExtAction.hideWhenDisabled(item);
/* 220:220 */     result.add(item, index++);
/* 221:    */     
/* 222:222 */     index += 3;
/* 223:223 */     result.insertSeparator(index++);
/* 224:    */     
/* 225:225 */     item = new JCheckBoxMenuItem(am.get("titleVisible"));
/* 226:226 */     item.setText("Show title");
/* 227:227 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_FONT));
/* 228:228 */     result.add(item, index++);
/* 229:    */     
/* 230:230 */     item = new JCheckBoxMenuItem(am.get("legendVisible"));
/* 231:231 */     item.setText("Show legend");
/* 232:232 */     result.add(item, index++);
/* 233:    */     
/* 234:234 */     item = new JMenuItem(getActionMap().get("format"));
/* 235:235 */     item.setText("Edit format...");
/* 236:236 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_GLOBE));
/* 237:237 */     result.add(item, index++);
/* 238:    */     
/* 239:239 */     result.add(buildColorSchemeMenu(), index++);
/* 240:240 */     result.add(buildLinesThicknessMenu(), index++);
/* 241:    */     
/* 242:242 */     if (!(this instanceof IConfigurable)) {
/* 243:243 */       result.insertSeparator(index);
/* 244:    */     }
/* 245:245 */     index++;
/* 246:    */     
/* 247:247 */     item = new JMenuItem(am.get("showAll"));
/* 248:248 */     item.setText("Show all");
/* 249:249 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_EYE));
/* 250:250 */     result.add(item, index++);
/* 251:    */     
/* 252:252 */     result.add(buildExportImageMenu(), index++);
/* 253:    */     
/* 254:254 */     return result;
/* 255:    */   }
/* 256:    */ }
