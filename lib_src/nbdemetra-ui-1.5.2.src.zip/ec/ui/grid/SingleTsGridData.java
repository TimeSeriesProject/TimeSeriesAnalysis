/*  1:   */ package ec.ui.grid;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.TsCollection;
/*  5:   */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  6:   */ import ec.tstoolkit.data.Values;
/*  7:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  8:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  9:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/* 10:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ class SingleTsGridData
/* 16:   */   extends TsGridData
/* 17:   */ {
/* 18:   */   final TsGridObs obs;
/* 19:   */   final int seriesIndex;
/* 20:   */   final Values data;
/* 21:   */   final TsDomain domain;
/* 22:   */   final int startYear;
/* 23:   */   final int startPosition;
/* 24:   */   
/* 25:   */   public SingleTsGridData(TsCollection col, int seriesIndex)
/* 26:   */   {
/* 27:27 */     this.seriesIndex = seriesIndex;
/* 28:28 */     data = col.get(seriesIndex).getTsData().getValues();
/* 29:29 */     domain = col.get(seriesIndex).getTsData().getDomain();
/* 30:30 */     startYear = domain.getStart().getYear();
/* 31:31 */     startPosition = domain.getStart().getPosition();
/* 32:32 */     obs = new TsGridObs(new DescriptiveStatistics(data));
/* 33:   */   }
/* 34:   */   
/* 35:   */   int getPeriodId(int i, int j) {
/* 36:36 */     int periodId = j + getColumnCount() * i - startPosition;
/* 37:37 */     return (periodId < 0) || (periodId >= domain.getLength()) ? -1 : periodId;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getRowName(int i)
/* 41:   */   {
/* 42:42 */     return Integer.toString(startYear + i);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String getColumnName(int j)
/* 46:   */   {
/* 47:47 */     return TsPeriod.formatShortPeriod(domain.getFrequency(), j);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public TsGridObs getObs(int i, int j)
/* 51:   */   {
/* 52:52 */     int periodId = getPeriodId(i, j);
/* 53:53 */     return periodId == -1 ? obs.empty(seriesIndex) : obs.valid(seriesIndex, periodId, domain.get(periodId), data.get(periodId));
/* 54:   */   }
/* 55:   */   
/* 56:   */   public int getRowCount()
/* 57:   */   {
/* 58:58 */     return domain.getYearsCount();
/* 59:   */   }
/* 60:   */   
/* 61:   */   public int getColumnCount()
/* 62:   */   {
/* 63:63 */     return domain.getFrequency().intValue();
/* 64:   */   }
/* 65:   */ }
