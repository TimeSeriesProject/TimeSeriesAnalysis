/*   1:    */ package ec.ui.grid;
/*   2:    */ 
/*   3:    */ import ec.tss.Ts;
/*   4:    */ import ec.tss.TsCollection;
/*   5:    */ import ec.tss.TsStatus;
/*   6:    */ import ec.ui.interfaces.ITsGrid.Chronology;
/*   7:    */ import ec.ui.interfaces.ITsGrid.Orientation;
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ abstract class TsGridData
/*  16:    */ {
/*  17:    */   public static TsGridData empty()
/*  18:    */   {
/*  19: 19 */     return EmptyTsGridData.INSTANCE;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static TsGridData create(TsCollection col, int singleSeriesIndex, ITsGrid.Orientation orientation, ITsGrid.Chronology chronology) {
/*  23: 23 */     if ((col.isEmpty()) || ((singleSeriesIndex != -1) && (col.get(singleSeriesIndex).hasData() != TsStatus.Valid))) {
/*  24: 24 */       return empty();
/*  25:    */     }
/*  26: 26 */     TsGridData result = singleSeriesIndex == -1 ? new MultiTsGridData(col) : new SingleTsGridData(col, singleSeriesIndex);
/*  27: 27 */     result = chronology == ITsGrid.Chronology.ASCENDING ? result : result.flipVerticaly();
/*  28: 28 */     result = orientation == ITsGrid.Orientation.NORMAL ? result : result.transpose();
/*  29: 29 */     return result;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public abstract int getColumnCount();
/*  33:    */   
/*  34:    */   public abstract String getColumnName(int paramInt);
/*  35:    */   
/*  36:    */   public abstract int getRowCount();
/*  37:    */   
/*  38:    */   public abstract String getRowName(int paramInt);
/*  39:    */   
/*  40:    */   public abstract TsGridObs getObs(int paramInt1, int paramInt2);
/*  41:    */   
/*  42:    */   public TsGridData transpose() {
/*  43: 43 */     final TsGridData data = this;
/*  44: 44 */     new TsGridData()
/*  45:    */     {
/*  46:    */       public int getColumnCount() {
/*  47: 47 */         return data.getRowCount();
/*  48:    */       }
/*  49:    */       
/*  50:    */       public String getColumnName(int j)
/*  51:    */       {
/*  52: 52 */         return data.getRowName(j);
/*  53:    */       }
/*  54:    */       
/*  55:    */       public int getRowCount()
/*  56:    */       {
/*  57: 57 */         return data.getColumnCount();
/*  58:    */       }
/*  59:    */       
/*  60:    */       public String getRowName(int i)
/*  61:    */       {
/*  62: 62 */         return data.getColumnName(i);
/*  63:    */       }
/*  64:    */       
/*  65:    */       public TsGridObs getObs(int i, int j)
/*  66:    */       {
/*  67: 67 */         return data.getObs(j, i);
/*  68:    */       }
/*  69:    */     };
/*  70:    */   }
/*  71:    */   
/*  72:    */   public TsGridData flipHorizontaly() {
/*  73: 73 */     final TsGridData data = this;
/*  74: 74 */     new TsGridData() {
/*  75:    */       int flipColumn(int j) {
/*  76: 76 */         return data.getColumnCount() - j - 1;
/*  77:    */       }
/*  78:    */       
/*  79:    */       public int getColumnCount()
/*  80:    */       {
/*  81: 81 */         return data.getColumnCount();
/*  82:    */       }
/*  83:    */       
/*  84:    */       public String getColumnName(int j)
/*  85:    */       {
/*  86: 86 */         return data.getColumnName(flipColumn(j));
/*  87:    */       }
/*  88:    */       
/*  89:    */       public int getRowCount()
/*  90:    */       {
/*  91: 91 */         return data.getRowCount();
/*  92:    */       }
/*  93:    */       
/*  94:    */       public String getRowName(int i)
/*  95:    */       {
/*  96: 96 */         return data.getRowName(i);
/*  97:    */       }
/*  98:    */       
/*  99:    */       public TsGridObs getObs(int i, int j)
/* 100:    */       {
/* 101:101 */         return data.getObs(i, flipColumn(j));
/* 102:    */       }
/* 103:    */     };
/* 104:    */   }
/* 105:    */   
/* 106:    */   public TsGridData flipVerticaly() {
/* 107:107 */     final TsGridData data = this;
/* 108:108 */     new TsGridData() {
/* 109:    */       int flipRow(int i) {
/* 110:110 */         return data.getRowCount() - i - 1;
/* 111:    */       }
/* 112:    */       
/* 113:    */       public int getColumnCount()
/* 114:    */       {
/* 115:115 */         return data.getColumnCount();
/* 116:    */       }
/* 117:    */       
/* 118:    */       public String getColumnName(int j)
/* 119:    */       {
/* 120:120 */         return data.getColumnName(j);
/* 121:    */       }
/* 122:    */       
/* 123:    */       public int getRowCount()
/* 124:    */       {
/* 125:125 */         return data.getRowCount();
/* 126:    */       }
/* 127:    */       
/* 128:    */       public String getRowName(int i)
/* 129:    */       {
/* 130:130 */         return data.getRowName(flipRow(i));
/* 131:    */       }
/* 132:    */       
/* 133:    */       public TsGridObs getObs(int i, int j)
/* 134:    */       {
/* 135:135 */         return data.getObs(flipRow(i), j);
/* 136:    */       }
/* 137:    */     };
/* 138:    */   }
/* 139:    */   
/* 140:    */   private static class EmptyTsGridData extends TsGridData
/* 141:    */   {
/* 142:142 */     static final EmptyTsGridData INSTANCE = new EmptyTsGridData();
/* 143:    */     
/* 144:    */     public int getColumnCount()
/* 145:    */     {
/* 146:146 */       return 0;
/* 147:    */     }
/* 148:    */     
/* 149:    */     public String getColumnName(int j)
/* 150:    */     {
/* 151:151 */       throw new UnsupportedOperationException("Not supported yet.");
/* 152:    */     }
/* 153:    */     
/* 154:    */     public int getRowCount()
/* 155:    */     {
/* 156:156 */       return 0;
/* 157:    */     }
/* 158:    */     
/* 159:    */     public String getRowName(int i)
/* 160:    */     {
/* 161:161 */       throw new UnsupportedOperationException("Not supported yet.");
/* 162:    */     }
/* 163:    */     
/* 164:    */     public TsGridObs getObs(int i, int j)
/* 165:    */     {
/* 166:166 */       throw new UnsupportedOperationException("Not supported yet.");
/* 167:    */     }
/* 168:    */   }
/* 169:    */ }
