/*  1:   */ package ec.ui.grid;
/*  2:   */ 
/*  3:   */ import ec.util.grid.swing.GridModel;
/*  4:   */ import javax.swing.table.AbstractTableModel;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ final class GridModelAdapter
/* 12:   */   extends AbstractTableModel
/* 13:   */   implements GridModel
/* 14:   */ {
/* 15:   */   private final TsGridData data;
/* 16:   */   
/* 17:   */   public GridModelAdapter(TsGridData data)
/* 18:   */   {
/* 19:19 */     this.data = data;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int getRowCount()
/* 23:   */   {
/* 24:24 */     return data.getRowCount();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public int getColumnCount()
/* 28:   */   {
/* 29:29 */     return data.getColumnCount();
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Object getValueAt(int rowIndex, int columnIndex)
/* 33:   */   {
/* 34:34 */     return data.getObs(rowIndex, columnIndex);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getRowName(int rowIndex)
/* 38:   */   {
/* 39:39 */     return data.getRowName(rowIndex);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getColumnName(int column)
/* 43:   */   {
/* 44:44 */     return data.getColumnName(column);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public Class<?> getColumnClass(int columnIndex)
/* 48:   */   {
/* 49:49 */     return TsGridObs.class;
/* 50:   */   }
/* 51:   */ }
