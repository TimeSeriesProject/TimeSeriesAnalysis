package ec.ui.grid.model;

@Deprecated
abstract interface IGridData
{
  public abstract int getColumnCount();
  
  public abstract String getColumnName(int paramInt);
  
  public abstract int getRowCount();
  
  public abstract String getRowName(int paramInt);
  
  public abstract Number getValue(int paramInt1, int paramInt2);
}
