/*  1:   */ package ec.ui.grid.model;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.TsCollection;
/*  5:   */ import ec.tss.TsStatus;
/*  6:   */ import ec.ui.interfaces.ITsGrid.Chronology;
/*  7:   */ import ec.ui.interfaces.ITsGrid.Mode;
/*  8:   */ import ec.ui.interfaces.ITsGrid.Orientation;
/*  9:   */ import ec.util.grid.swing.GridModel;
/* 10:   */ import ec.util.grid.swing.GridModels;
/* 11:   */ import javax.swing.table.AbstractTableModel;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ @Deprecated
/* 24:   */ public final class TsTableModels
/* 25:   */ {
/* 26:   */   public static GridModel chooseGridModel(TsCollection col, ITsGrid.Mode mode, ITsGrid.Orientation orientation, ITsGrid.Chronology chronology)
/* 27:   */   {
/* 28:28 */     if ((col.isEmpty()) || ((mode == ITsGrid.Mode.SINGLETS) && (col.get(0).hasData() != TsStatus.Valid))) {
/* 29:29 */       return GridModels.empty();
/* 30:   */     }
/* 31:31 */     IGridData data = mode == ITsGrid.Mode.MULTIPLETS ? new MultiTsGridData(col) : new SingleTsGridData(col.get(0).getTsData());
/* 32:32 */     data = chronology == ITsGrid.Chronology.ASCENDING ? data : GridDatas.flipVerticaly(data);
/* 33:33 */     data = orientation == ITsGrid.Orientation.NORMAL ? data : GridDatas.transpose(data);
/* 34:34 */     return new GridDataAdapter(data);
/* 35:   */   }
/* 36:   */   
/* 37:   */   static class GridDataAdapter extends AbstractTableModel implements GridModel
/* 38:   */   {
/* 39:   */     IGridData data;
/* 40:   */     
/* 41:   */     public GridDataAdapter(IGridData data) {
/* 42:42 */       this.data = data;
/* 43:   */     }
/* 44:   */     
/* 45:   */     public int getRowCount()
/* 46:   */     {
/* 47:47 */       return data.getRowCount();
/* 48:   */     }
/* 49:   */     
/* 50:   */     public int getColumnCount()
/* 51:   */     {
/* 52:52 */       return data.getColumnCount();
/* 53:   */     }
/* 54:   */     
/* 55:   */     public Object getValueAt(int rowIndex, int columnIndex)
/* 56:   */     {
/* 57:57 */       return data.getValue(rowIndex, columnIndex);
/* 58:   */     }
/* 59:   */     
/* 60:   */     public String getRowName(int rowIndex)
/* 61:   */     {
/* 62:62 */       return data.getRowName(rowIndex);
/* 63:   */     }
/* 64:   */     
/* 65:   */     public String getColumnName(int column)
/* 66:   */     {
/* 67:67 */       return data.getColumnName(column);
/* 68:   */     }
/* 69:   */     
/* 70:   */     public Class<?> getColumnClass(int columnIndex)
/* 71:   */     {
/* 72:72 */       return Number.class;
/* 73:   */     }
/* 74:   */   }
/* 75:   */ }
