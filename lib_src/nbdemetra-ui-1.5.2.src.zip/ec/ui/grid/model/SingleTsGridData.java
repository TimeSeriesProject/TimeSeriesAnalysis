/*  1:   */ package ec.ui.grid.model;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  6:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ @Deprecated
/* 13:   */ class SingleTsGridData
/* 14:   */   implements IGridData
/* 15:   */ {
/* 16:   */   final TsData data;
/* 17:   */   
/* 18:   */   public SingleTsGridData(TsData data)
/* 19:   */   {
/* 20:20 */     this.data = data;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getRowName(int i)
/* 24:   */   {
/* 25:25 */     return Integer.toString(data.getDomain().getStart().getYear() + i);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getColumnName(int j)
/* 29:   */   {
/* 30:30 */     return TsPeriod.formatShortPeriod(data.getDomain().getFrequency(), j);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public Number getValue(int i, int j)
/* 34:   */   {
/* 35:35 */     int periodId = j + getColumnCount() * i - data.getDomain().getStart().getPosition();
/* 36:36 */     return (periodId < 0) || (periodId >= data.getDomain().getLength()) ? null : Double.valueOf(data.get(periodId));
/* 37:   */   }
/* 38:   */   
/* 39:   */   public int getRowCount()
/* 40:   */   {
/* 41:41 */     return data.getDomain().getYearsCount();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public int getColumnCount()
/* 45:   */   {
/* 46:46 */     return data.getDomain().getFrequency().intValue();
/* 47:   */   }
/* 48:   */ }
