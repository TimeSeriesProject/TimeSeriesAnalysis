/*   1:    */ package ec.ui.grid.model;
/*   2:    */ 
/*   3:    */ 
/*   4:    */ 
/*   5:    */ 
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ @Deprecated
/*  15:    */ final class GridDatas
/*  16:    */ {
/*  17:    */   public static IGridData empty()
/*  18:    */   {
/*  19: 19 */     return EmptyGridData.INSTANCE;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static IGridData transpose(IGridData data) {
/*  23: 23 */     new IGridData()
/*  24:    */     {
/*  25:    */       public int getColumnCount()
/*  26:    */       {
/*  27: 27 */         return GridDatas.this.getRowCount();
/*  28:    */       }
/*  29:    */       
/*  30:    */       public String getColumnName(int j)
/*  31:    */       {
/*  32: 32 */         return GridDatas.this.getRowName(j);
/*  33:    */       }
/*  34:    */       
/*  35:    */       public int getRowCount()
/*  36:    */       {
/*  37: 37 */         return GridDatas.this.getColumnCount();
/*  38:    */       }
/*  39:    */       
/*  40:    */       public String getRowName(int i)
/*  41:    */       {
/*  42: 42 */         return GridDatas.this.getColumnName(i);
/*  43:    */       }
/*  44:    */       
/*  45:    */       public Number getValue(int i, int j)
/*  46:    */       {
/*  47: 47 */         return GridDatas.this.getValue(j, i);
/*  48:    */       }
/*  49:    */     };
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static IGridData flipHorizontaly(IGridData data) {
/*  53: 53 */     new IGridData()
/*  54:    */     {
/*  55:    */       public int getColumnCount()
/*  56:    */       {
/*  57: 57 */         return GridDatas.this.getColumnCount();
/*  58:    */       }
/*  59:    */       
/*  60:    */       public String getColumnName(int j)
/*  61:    */       {
/*  62: 62 */         return GridDatas.this.getColumnName(GridDatas.this.getColumnCount() - j - 1);
/*  63:    */       }
/*  64:    */       
/*  65:    */       public int getRowCount()
/*  66:    */       {
/*  67: 67 */         return GridDatas.this.getRowCount();
/*  68:    */       }
/*  69:    */       
/*  70:    */       public String getRowName(int i)
/*  71:    */       {
/*  72: 72 */         return GridDatas.this.getRowName(i);
/*  73:    */       }
/*  74:    */       
/*  75:    */       public Number getValue(int i, int j)
/*  76:    */       {
/*  77: 77 */         return GridDatas.this.getValue(i, GridDatas.this.getColumnCount() - j - 1);
/*  78:    */       }
/*  79:    */     };
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static IGridData flipVerticaly(IGridData data) {
/*  83: 83 */     new IGridData()
/*  84:    */     {
/*  85:    */       public int getColumnCount()
/*  86:    */       {
/*  87: 87 */         return GridDatas.this.getColumnCount();
/*  88:    */       }
/*  89:    */       
/*  90:    */       public String getColumnName(int j)
/*  91:    */       {
/*  92: 92 */         return GridDatas.this.getColumnName(j);
/*  93:    */       }
/*  94:    */       
/*  95:    */       public int getRowCount()
/*  96:    */       {
/*  97: 97 */         return GridDatas.this.getRowCount();
/*  98:    */       }
/*  99:    */       
/* 100:    */       public String getRowName(int i)
/* 101:    */       {
/* 102:102 */         return GridDatas.this.getRowName(GridDatas.this.getRowCount() - i - 1);
/* 103:    */       }
/* 104:    */       
/* 105:    */       public Number getValue(int i, int j)
/* 106:    */       {
/* 107:107 */         return GridDatas.this.getValue(GridDatas.this.getRowCount() - i - 1, j);
/* 108:    */       }
/* 109:    */     };
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static enum EmptyGridData implements IGridData
/* 113:    */   {
/* 114:114 */     INSTANCE;
/* 115:    */     
/* 116:    */     public int getColumnCount()
/* 117:    */     {
/* 118:118 */       return 0;
/* 119:    */     }
/* 120:    */     
/* 121:    */     public String getColumnName(int j)
/* 122:    */     {
/* 123:123 */       throw new UnsupportedOperationException("Not supported yet.");
/* 124:    */     }
/* 125:    */     
/* 126:    */     public int getRowCount()
/* 127:    */     {
/* 128:128 */       return 0;
/* 129:    */     }
/* 130:    */     
/* 131:    */     public String getRowName(int i)
/* 132:    */     {
/* 133:133 */       throw new UnsupportedOperationException("Not supported yet.");
/* 134:    */     }
/* 135:    */     
/* 136:    */     public Number getValue(int i, int j)
/* 137:    */     {
/* 138:138 */       throw new UnsupportedOperationException("Not supported yet.");
/* 139:    */     }
/* 140:    */   }
/* 141:    */ }
