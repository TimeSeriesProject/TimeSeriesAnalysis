/*  1:   */ package ec.ui.grid.model;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsDataTable;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  6:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  7:   */ import java.util.ArrayList;
/*  8:   */ import java.util.List;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ @Deprecated
/* 15:   */ class MultiTsGridData
/* 16:   */   implements IGridData
/* 17:   */ {
/* 18:   */   final List<String> names;
/* 19:   */   final TsDataTable dataTable;
/* 20:   */   
/* 21:   */   public MultiTsGridData(Iterable<Ts> list)
/* 22:   */   {
/* 23:23 */     names = new ArrayList();
/* 24:24 */     dataTable = new TsDataTable();
/* 25:25 */     for (Ts o : list) {
/* 26:26 */       names.add(o.getName());
/* 27:27 */       dataTable.insert(-1, o.getTsData());
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String getRowName(int i)
/* 32:   */   {
/* 33:33 */     return dataTable.getDomain().get(i).toString();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String getColumnName(int j)
/* 37:   */   {
/* 38:38 */     return (String)names.get(j);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Number getValue(int i, int j)
/* 42:   */   {
/* 43:43 */     switch (dataTable.getDataInfo(i, j)) {
/* 44:   */     case Empty: 
/* 45:45 */       return null;
/* 46:   */     case Missing: 
/* 47:47 */       return Double.valueOf((0.0D / 0.0D));
/* 48:   */     case Valid: 
/* 49:49 */       return Double.valueOf(dataTable.getData(i, j));
/* 50:   */     }
/* 51:51 */     throw new UnsupportedOperationException();
/* 52:   */   }
/* 53:   */   
/* 54:   */   public int getRowCount()
/* 55:   */   {
/* 56:56 */     return dataTable.isEmpty() ? 0 : dataTable.getDomain().getLength();
/* 57:   */   }
/* 58:   */   
/* 59:   */   public int getColumnCount()
/* 60:   */   {
/* 61:61 */     return dataTable.getSeriesCount();
/* 62:   */   }
/* 63:   */ }
