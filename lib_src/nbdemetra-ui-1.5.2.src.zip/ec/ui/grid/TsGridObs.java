/*  1:   */ package ec.ui.grid;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsDataTableInfo;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class TsGridObs
/* 17:   */ {
/* 18:   */   private final DescriptiveStatistics stats;
/* 19:   */   private int seriesIndex;
/* 20:   */   private int index;
/* 21:   */   private TsPeriod period;
/* 22:   */   private double value;
/* 23:   */   
/* 24:   */   TsGridObs(DescriptiveStatistics stats)
/* 25:   */   {
/* 26:26 */     this.stats = stats;
/* 27:27 */     empty(-1);
/* 28:   */   }
/* 29:   */   
/* 30:   */   final TsGridObs empty(int seriesIndex) {
/* 31:31 */     return missing(seriesIndex, -1, null);
/* 32:   */   }
/* 33:   */   
/* 34:   */   final TsGridObs missing(int seriesIndex, int obsIndex, TsPeriod period) {
/* 35:35 */     return valid(seriesIndex, obsIndex, period, (0.0D / 0.0D));
/* 36:   */   }
/* 37:   */   
/* 38:   */   final TsGridObs valid(int seriesIndex, int obsIndex, TsPeriod period, double value) {
/* 39:39 */     this.seriesIndex = seriesIndex;
/* 40:40 */     index = obsIndex;
/* 41:41 */     this.period = period;
/* 42:42 */     this.value = value;
/* 43:43 */     return this;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public DescriptiveStatistics getStats() {
/* 47:47 */     return stats;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public TsDataTableInfo getInfo() {
/* 51:51 */     return Double.isNaN(value) ? TsDataTableInfo.Missing : period == null ? TsDataTableInfo.Empty : TsDataTableInfo.Valid;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public int getSeriesIndex() {
/* 55:55 */     return seriesIndex;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public int getIndex() {
/* 59:59 */     return index;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public TsPeriod getPeriod() {
/* 63:63 */     return period;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public double getValue() {
/* 67:67 */     return value;
/* 68:   */   }
/* 69:   */ }
