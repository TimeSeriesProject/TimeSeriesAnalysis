/*  1:   */ package ec.ui.grid;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Iterables;
/*  4:   */ import com.google.common.primitives.Doubles;
/*  5:   */ import ec.tss.Ts;
/*  6:   */ import ec.tss.TsCollection;
/*  7:   */ import ec.tss.TsStatus;
/*  8:   */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  9:   */ import ec.tstoolkit.data.Values;
/* 10:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/* 11:   */ import ec.tstoolkit.timeseries.simplets.TsDataTable;
/* 12:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/* 13:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/* 14:   */ import ec.tstoolkit.utilities.IntList;
/* 15:   */ import java.util.ArrayList;
/* 16:   */ import java.util.List;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ class MultiTsGridData
/* 22:   */   extends TsGridData
/* 23:   */ {
/* 24:   */   final TsGridObs obs;
/* 25:   */   final List<String> names;
/* 26:   */   final TsDataTable dataTable;
/* 27:   */   final TsDomain domain;
/* 28:   */   final IntList firstObsIndexes;
/* 29:   */   
/* 30:   */   public MultiTsGridData(TsCollection col)
/* 31:   */   {
/* 32:32 */     obs = new TsGridObs(createStats(col));
/* 33:33 */     names = new ArrayList();
/* 34:34 */     dataTable = new TsDataTable();
/* 35:35 */     for (Ts o : col) {
/* 36:36 */       if (o.hasData() == TsStatus.Valid) {
/* 37:37 */         names.add(o.getName());
/* 38:38 */         dataTable.insert(-1, o.getTsData());
/* 39:   */       }
/* 40:   */     }
/* 41:41 */     domain = dataTable.getDomain();
/* 42:42 */     firstObsIndexes = new IntList();
/* 43:43 */     if (domain != null) {
/* 44:44 */       for (int i = 0; i < dataTable.getSeriesCount(); i++) {
/* 45:45 */         firstObsIndexes.add(domain.search(dataTable.series(i).getStart()));
/* 46:   */       }
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   static DescriptiveStatistics createStats(TsCollection col) {
/* 51:51 */     List<double[]> allValues = new ArrayList();
/* 52:52 */     for (Ts o : col) {
/* 53:53 */       if (o.hasData() == TsStatus.Valid) {
/* 54:54 */         allValues.add(o.getTsData().getValues().internalStorage());
/* 55:   */       }
/* 56:   */     }
/* 57:57 */     return new DescriptiveStatistics(Doubles.concat((double[][])Iterables.toArray(allValues, [D.class)));
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String getRowName(int i)
/* 61:   */   {
/* 62:62 */     return domain.get(i).toString();
/* 63:   */   }
/* 64:   */   
/* 65:   */   public String getColumnName(int j)
/* 66:   */   {
/* 67:67 */     return (String)names.get(j);
/* 68:   */   }
/* 69:   */   
/* 70:   */   public TsGridObs getObs(int i, int series)
/* 71:   */   {
/* 72:72 */     switch (dataTable.getDataInfo(i, series)) {
/* 73:   */     case Empty: 
/* 74:74 */       return obs.empty(series);
/* 75:   */     case Missing: 
/* 76:76 */       return obs.missing(series, i - firstObsIndexes.get(series), domain.get(i));
/* 77:   */     case Valid: 
/* 78:78 */       return obs.valid(series, i - firstObsIndexes.get(series), domain.get(i), dataTable.getData(i, series));
/* 79:   */     }
/* 80:80 */     throw new UnsupportedOperationException();
/* 81:   */   }
/* 82:   */   
/* 83:   */   public int getRowCount()
/* 84:   */   {
/* 85:85 */     return domain != null ? domain.getLength() : 0;
/* 86:   */   }
/* 87:   */   
/* 88:   */   public int getColumnCount()
/* 89:   */   {
/* 90:90 */     return dataTable.getSeriesCount();
/* 91:   */   }
/* 92:   */ }
