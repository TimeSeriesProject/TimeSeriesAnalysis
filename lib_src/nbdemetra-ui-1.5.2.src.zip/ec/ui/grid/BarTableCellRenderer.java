/*  1:   */ package ec.ui.grid;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Graphics2D;
/*  7:   */ import java.awt.Rectangle;
/*  8:   */ import javax.swing.JLabel;
/*  9:   */ import javax.swing.JTable;
/* 10:   */ import javax.swing.table.DefaultTableCellRenderer;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ class BarTableCellRenderer
/* 19:   */   extends DefaultTableCellRenderer
/* 20:   */ {
/* 21:   */   private boolean horizontalBar;
/* 22:   */   private double a;
/* 23:23 */   private double b = 0.0D;
/* 24:   */   
/* 25:   */   public BarTableCellRenderer(boolean horizontalBar) {
/* 26:26 */     this.horizontalBar = true;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 30:   */   {
/* 31:31 */     JLabel result = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 32:32 */     return result;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setBarValues(double min, double max, double val) {
/* 36:36 */     double diff = max - min;
/* 37:37 */     if (diff == 0.0D) {
/* 38:38 */       a = (this.b = 0.0D);
/* 39:   */     } else {
/* 40:40 */       double zero = max < 0.0D ? max : min > 0.0D ? min : 0.0D;
/* 41:41 */       if (val >= zero) {
/* 42:42 */         a = ((zero - min) / diff);
/* 43:43 */         b = ((val - min) / diff);
/* 44:   */       } else {
/* 45:45 */         a = ((val - min) / diff);
/* 46:46 */         b = ((zero - min) / diff);
/* 47:   */       }
/* 48:   */     }
/* 49:   */   }
/* 50:   */   
/* 51:   */   protected void paintComponent(Graphics g)
/* 52:   */   {
/* 53:53 */     super.paintComponent(g);
/* 54:   */     
/* 55:55 */     if (b - a > 0.0D) {
/* 56:56 */       Graphics2D g2 = (Graphics2D)g;
/* 57:   */       
/* 58:58 */       Rectangle oldClip = g2.getClipBounds();
/* 59:59 */       Color oldForeground = getForeground();
/* 60:60 */       Color oldBackground = getBackground();
/* 61:   */       
/* 62:62 */       double d = b - a;
/* 63:63 */       if (horizontalBar) {
/* 64:64 */         g2.clipRect((int)(a * getWidth()), 0, (int)(d * getWidth()), getHeight());
/* 65:   */       } else {
/* 66:66 */         g2.clipRect(0, (int)((1.0D - b) * getHeight()), getWidth(), (int)(d * getHeight()));
/* 67:   */       }
/* 68:68 */       setForeground(oldBackground);
/* 69:69 */       setBackground(oldForeground);
/* 70:   */       
/* 71:71 */       super.paintComponent(g);
/* 72:   */       
/* 73:73 */       setBackground(oldBackground);
/* 74:74 */       setForeground(oldForeground);
/* 75:75 */       g2.setClip(oldClip);
/* 76:   */     }
/* 77:   */   }
/* 78:   */ }
