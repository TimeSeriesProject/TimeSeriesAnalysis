/*   1:    */ package ec.ui.grid;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Strings;
/*   5:    */ import ec.nbdemetra.ui.DemetraUI;
/*   6:    */ import ec.nbdemetra.ui.MonikerUI;
/*   7:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   8:    */ import ec.nbdemetra.ui.awt.PopupListener.PopupAdapter;
/*   9:    */ import ec.tss.Ts;
/*  10:    */ import ec.tss.Ts.DataFeature;
/*  11:    */ import ec.tss.TsCollection;
/*  12:    */ import ec.tss.tsproviders.utils.DataFormat;
/*  13:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  14:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  16:    */ import ec.ui.ATsCollectionView;
/*  17:    */ import ec.ui.ATsCollectionView.TsActionMouseAdapter;
/*  18:    */ import ec.ui.ATsCollectionView.TsCollectionSelectionListener;
/*  19:    */ import ec.ui.ATsCollectionView.TsCollectionTransferHandler;
/*  20:    */ import ec.ui.ATsGrid;
/*  21:    */ import ec.ui.DemoUtils;
/*  22:    */ import ec.ui.chart.DataFeatureModel;
/*  23:    */ import ec.ui.commands.TsGridCommand;
/*  24:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  25:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*  26:    */ import ec.ui.interfaces.ITsGrid.Orientation;
/*  27:    */ import ec.util.chart.swing.SwingColorSchemeSupport;
/*  28:    */ import ec.util.grid.swing.GridRowHeaderRenderer;
/*  29:    */ import ec.util.grid.swing.JGrid;
/*  30:    */ import ec.util.grid.swing.XTable.DefaultNoDataRenderer;
/*  31:    */ import ec.util.various.swing.FontAwesome;
/*  32:    */ import ec.util.various.swing.JCommand;
/*  33:    */ import java.awt.BorderLayout;
/*  34:    */ import java.awt.Color;
/*  35:    */ import java.awt.Component;
/*  36:    */ import java.awt.Dimension;
/*  37:    */ import java.awt.Font;
/*  38:    */ import java.awt.event.ItemEvent;
/*  39:    */ import java.awt.event.ItemListener;
/*  40:    */ import java.beans.Beans;
/*  41:    */ import java.beans.PropertyChangeEvent;
/*  42:    */ import java.beans.PropertyChangeListener;
/*  43:    */ import java.util.Date;
/*  44:    */ import javax.annotation.Nonnull;
/*  45:    */ import javax.annotation.Nullable;
/*  46:    */ import javax.swing.ActionMap;
/*  47:    */ import javax.swing.DefaultComboBoxModel;
/*  48:    */ import javax.swing.DefaultListCellRenderer;
/*  49:    */ import javax.swing.JCheckBoxMenuItem;
/*  50:    */ import javax.swing.JComboBox;
/*  51:    */ import javax.swing.JLabel;
/*  52:    */ import javax.swing.JList;
/*  53:    */ import javax.swing.JMenu;
/*  54:    */ import javax.swing.JMenuItem;
/*  55:    */ import javax.swing.JSlider;
/*  56:    */ import javax.swing.JTable;
/*  57:    */ import javax.swing.JToolTip;
/*  58:    */ import javax.swing.ListSelectionModel;
/*  59:    */ import javax.swing.event.ChangeEvent;
/*  60:    */ import javax.swing.event.ChangeListener;
/*  61:    */ import javax.swing.table.AbstractTableModel;
/*  62:    */ import javax.swing.table.JTableHeader;
/*  63:    */ import javax.swing.table.TableCellRenderer;
/*  64:    */ import javax.swing.table.TableColumnModel;
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ public class JTsGrid
/*  80:    */   extends ATsGrid
/*  81:    */ {
/*  82:    */   public static final String USE_COLOR_SCHEME_PROPERTY = "useColorScheme";
/*  83:    */   public static final String SHOW_BARS_PROPERTY = "showBars";
/*  84:    */   public static final String CELL_RENDERER_PROPERTY = "cellRenderer";
/*  85:    */   private static final boolean DEFAULT_USE_COLOR_SCHEME = false;
/*  86:    */   private static final boolean DEFAULT_SHOW_BARS = false;
/*  87:    */   private boolean useColorScheme;
/*  88:    */   private boolean showBars;
/*  89:    */   private TableCellRenderer cellRenderer;
/*  90:    */   private Font originalFont;
/*  91:    */   protected final JGrid grid;
/*  92:    */   private final JComboBox combo;
/*  93:    */   private final GridSelectionListener selectionListener;
/*  94:    */   protected final DataFeatureModel dataFeatureModel;
/*  95: 95 */   private DemetraUI demetraUI = DemetraUI.getDefault();
/*  96:    */   
/*  97:    */   public JTsGrid() {
/*  98: 98 */     useColorScheme = false;
/*  99: 99 */     showBars = false;
/* 100:    */     
/* 101:101 */     selectionListener = new GridSelectionListener(null);
/* 102:    */     
/* 103:103 */     grid = buildGrid();
/* 104:    */     
/* 105:105 */     combo = new JComboBox();
/* 106:106 */     combo.addItemListener(new ItemListener()
/* 107:    */     {
/* 108:    */       public void itemStateChanged(ItemEvent e) {
/* 109:109 */         setSingleTsIndex(combo.getSelectedIndex());
/* 110:    */       }
/* 111:    */       
/* 112:112 */     });
/* 113:113 */     dataFeatureModel = new DataFeatureModel();
/* 114:    */     
/* 115:115 */     onColorSchemeChange();
/* 116:116 */     onDataFormatChange();
/* 117:117 */     onUpdateModeChange();
/* 118:118 */     updateGridModel();
/* 119:119 */     updateComboModel();
/* 120:120 */     updateSelectionBehavior();
/* 121:121 */     updateComboCellRenderer();
/* 122:    */     
/* 123:123 */     setLayout(new BorderLayout());
/* 124:124 */     add(grid, "Center");
/* 125:125 */     add(combo, "North");
/* 126:    */     
/* 127:127 */     addPropertyChangeListener(new PropertyChangeListener() {
/* 128:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 129:    */         String str;
/* 130:130 */         switch ((str = evt.getPropertyName()).hashCode()) {case -339374243:  if (str.equals("showBars")) {} break; case 89125601:  if (str.equals("useColorScheme")) break; break; case 975416389:  if (!str.equals("cellRenderer"))
/* 131:    */           {
/* 132:132 */             return;JTsGrid.this.onUseColorSchemeChange();
/* 133:133 */             return;
/* 134:    */             
/* 135:135 */             JTsGrid.this.onShowBarsChange();
/* 136:    */           }
/* 137:    */           else {
/* 138:138 */             JTsGrid.this.onCellRendererChange();
/* 139:    */           }
/* 140:    */           break;
/* 141:    */         }
/* 142:    */       }
/* 143:    */     });
/* 144:144 */     if (Beans.isDesignTime()) {
/* 145:145 */       setTsCollection(DemoUtils.randomTsCollection(3));
/* 146:146 */       setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 147:147 */       setPreferredSize(new Dimension(200, 150));
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */ 
/* 152:    */   protected void onDataFormatChange()
/* 153:    */   {
/* 154:154 */     updateGridCellRenderer();
/* 155:    */   }
/* 156:    */   
/* 157:    */   protected void onColorSchemeChange()
/* 158:    */   {
/* 159:159 */     if (useColorScheme) {
/* 160:160 */       updateGridCellRenderer();
/* 161:161 */       updateComboCellRenderer();
/* 162:    */     }
/* 163:    */   }
/* 164:    */   
/* 165:    */   protected void onCollectionChange()
/* 166:    */   {
/* 167:167 */     selectionListener.setEnabled(false);
/* 168:168 */     dataFeatureModel.setData(collection.toArray());
/* 169:169 */     updateGridModel();
/* 170:170 */     updateComboModel();
/* 171:171 */     updateNoDataMessage();
/* 172:172 */     selectionListener.setEnabled(true);
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected void onSelectionChange()
/* 176:    */   {
/* 177:177 */     selectionListener.setEnabled(false);
/* 178:178 */     updateSelection();
/* 179:179 */     selectionListener.setEnabled(true);
/* 180:    */   }
/* 181:    */   
/* 182:    */   protected void onUpdateModeChange()
/* 183:    */   {
/* 184:184 */     updateNoDataMessage();
/* 185:    */   }
/* 186:    */   
/* 187:    */ 
/* 188:    */ 
/* 189:    */   protected void onTsActionChange() {}
/* 190:    */   
/* 191:    */ 
/* 192:    */ 
/* 193:    */   protected void onDropContentChange() {}
/* 194:    */   
/* 195:    */ 
/* 196:    */ 
/* 197:    */   protected void onOrientationChange()
/* 198:    */   {
/* 199:199 */     selectionListener.setEnabled(false);
/* 200:200 */     updateGridModel();
/* 201:201 */     updateSelectionBehavior();
/* 202:202 */     updateSelection();
/* 203:203 */     selectionListener.setEnabled(true);
/* 204:    */   }
/* 205:    */   
/* 206:    */   protected void onChronologyChange()
/* 207:    */   {
/* 208:208 */     selectionListener.setEnabled(false);
/* 209:209 */     updateGridModel();
/* 210:210 */     updateSelection();
/* 211:211 */     selectionListener.setEnabled(true);
/* 212:    */   }
/* 213:    */   
/* 214:    */   protected void onModeChange()
/* 215:    */   {
/* 216:216 */     selectionListener.setEnabled(false);
/* 217:217 */     updateGridModel();
/* 218:218 */     updateComboModel();
/* 219:219 */     updateSelectionBehavior();
/* 220:220 */     updateSelection();
/* 221:221 */     selectionListener.setEnabled(true);
/* 222:    */   }
/* 223:    */   
/* 224:    */   protected void onSingleTsIndexChange()
/* 225:    */   {
/* 226:226 */     selectionListener.setEnabled(false);
/* 227:227 */     updateGridModel();
/* 228:228 */     updateSelection();
/* 229:229 */     selectionListener.setEnabled(true);
/* 230:    */   }
/* 231:    */   
/* 232:    */   private void onUseColorSchemeChange() {
/* 233:233 */     grid.setOddBackground(useColorScheme ? null : new Color(250, 250, 250));
/* 234:234 */     updateGridCellRenderer();
/* 235:235 */     updateComboCellRenderer();
/* 236:    */   }
/* 237:    */   
/* 238:    */   private void onShowBarsChange() {
/* 239:239 */     updateGridCellRenderer();
/* 240:    */   }
/* 241:    */   
/* 242:    */   private void onCellRendererChange() {
/* 243:243 */     updateGridCellRenderer();
/* 244:    */   }
/* 245:    */   
/* 246:    */   protected void onZoomChange()
/* 247:    */   {
/* 248:248 */     if (originalFont == null) {
/* 249:249 */       originalFont = getFont();
/* 250:    */     }
/* 251:    */     
/* 252:252 */     Font font = originalFont;
/* 253:    */     
/* 254:254 */     if (zoomRatio != 100) {
/* 255:255 */       float floatRatio = zoomRatio / 100.0F;
/* 256:256 */       float scaledSize = originalFont.getSize2D() * floatRatio;
/* 257:257 */       font = originalFont.deriveFont(scaledSize);
/* 258:    */     }
/* 259:    */     
/* 260:260 */     grid.setFont(font);
/* 261:    */   }
/* 262:    */   
/* 263:    */ 
/* 264:    */   public boolean isUseColorScheme()
/* 265:    */   {
/* 266:266 */     return useColorScheme;
/* 267:    */   }
/* 268:    */   
/* 269:    */   public void setUseColorScheme(boolean useColorScheme) {
/* 270:270 */     boolean old = this.useColorScheme;
/* 271:271 */     this.useColorScheme = useColorScheme;
/* 272:272 */     firePropertyChange("useColorScheme", old, this.useColorScheme);
/* 273:    */   }
/* 274:    */   
/* 275:    */   public int[] getSelectedColumns() {
/* 276:276 */     return grid.getSelectedColumns();
/* 277:    */   }
/* 278:    */   
/* 279:    */   public boolean isShowBars() {
/* 280:280 */     return showBars;
/* 281:    */   }
/* 282:    */   
/* 283:    */   public void setShowBars(boolean showBars) {
/* 284:284 */     boolean old = this.showBars;
/* 285:285 */     this.showBars = showBars;
/* 286:286 */     firePropertyChange("showBars", old, this.showBars);
/* 287:    */   }
/* 288:    */   
/* 289:    */   public TableCellRenderer getCellRenderer() {
/* 290:290 */     return cellRenderer;
/* 291:    */   }
/* 292:    */   
/* 293:    */   public void setCellRenderer(TableCellRenderer cellRenderer) {
/* 294:294 */     TableCellRenderer old = this.cellRenderer;
/* 295:295 */     this.cellRenderer = cellRenderer;
/* 296:296 */     firePropertyChange("cellRenderer", old, this.cellRenderer);
/* 297:    */   }
/* 298:    */   
/* 299:    */   private void updateNoDataMessage()
/* 300:    */   {
/* 301:    */     String message;
/* 302:302 */     if (getTsUpdateMode().isReadOnly()) { String message;
/* 303:303 */       String message; String message; switch (collection.getCount()) {
/* 304:    */       case 0: 
/* 305:305 */         message = "No data";
/* 306:306 */         break;
/* 307:    */       case 1: 
/* 308:308 */         String cause = collection.get(0).getInvalidDataCause();
/* 309:309 */         message = "<html><center><b>Invalid data</b><br>" + Strings.nullToEmpty(cause);
/* 310:310 */         break;
/* 311:    */       default: 
/* 312:312 */         message = "Invalid data";
/* 313:    */         
/* 314:    */ 
/* 315:315 */         break; }
/* 316:316 */     } else { message = "Drop data here";
/* 317:    */     }
/* 318:318 */     grid.setNoDataRenderer(new XTable.DefaultNoDataRenderer(message));
/* 319:    */   }
/* 320:    */   
/* 321:    */   private void updateGridModel() {
/* 322:322 */     int index = mode == ITsGrid.Mode.SINGLETS ? Math.min(singleTsIndex, collection.getCount() - 1) : -1;
/* 323:323 */     grid.setModel(new GridModelAdapter(TsGridData.create(collection, index, orientation, chronology)));
/* 324:    */   }
/* 325:    */   
/* 326:    */   private void updateSelectionBehavior() {
/* 327:327 */     grid.getColumnModel().getSelectionModel().removeListSelectionListener(selectionListener);
/* 328:328 */     grid.getSelectionModel().removeListSelectionListener(selectionListener);
/* 329:329 */     grid.setColumnSelectionAllowed(false);
/* 330:330 */     grid.setRowSelectionAllowed(false);
/* 331:331 */     if (mode == ITsGrid.Mode.MULTIPLETS) {
/* 332:332 */       if (orientation == ITsGrid.Orientation.NORMAL) {
/* 333:333 */         grid.getColumnModel().getSelectionModel().addListSelectionListener(selectionListener);
/* 334:334 */         grid.setColumnSelectionAllowed(true);
/* 335:    */       } else {
/* 336:336 */         grid.getSelectionModel().addListSelectionListener(selectionListener);
/* 337:337 */         grid.setRowSelectionAllowed(true);
/* 338:    */       }
/* 339:    */     }
/* 340:    */   }
/* 341:    */   
/* 342:    */   public void fireTableDataChanged() {
/* 343:343 */     ((AbstractTableModel)grid.getModel()).fireTableDataChanged();
/* 344:    */   }
/* 345:    */   
/* 346:    */   private void updateSelection() {
/* 347:347 */     if (mode == ITsGrid.Mode.MULTIPLETS) {
/* 348:348 */       selectionListener.changeSelection(orientation == ITsGrid.Orientation.NORMAL ? grid.getColumnModel().getSelectionModel() : grid.getSelectionModel());
/* 349:    */     }
/* 350:350 */     else if (!collection.isEmpty()) {
/* 351:351 */       int index = Math.min(singleTsIndex, collection.getCount() - 1);
/* 352:352 */       if (combo.isVisible()) {
/* 353:353 */         combo.setSelectedIndex(index);
/* 354:    */       }
/* 355:355 */       setSelection(new Ts[] { collection.get(index) });
/* 356:    */     }
/* 357:    */   }
/* 358:    */   
/* 359:    */   private void updateComboModel()
/* 360:    */   {
/* 361:361 */     if ((mode == ITsGrid.Mode.SINGLETS) && (collection.getCount() > 1)) {
/* 362:362 */       combo.setModel(new DefaultComboBoxModel(collection.toArray()));
/* 363:363 */       combo.setVisible(true);
/* 364:    */     } else {
/* 365:365 */       combo.setVisible(false);
/* 366:    */     }
/* 367:    */   }
/* 368:    */   
/* 369:    */   private void updateGridCellRenderer() {
/* 370:370 */     grid.setDefaultRenderer(TsGridObs.class, cellRenderer != null ? cellRenderer : new GridCellRenderer(themeSupport.getDataFormat(), useColorScheme ? themeSupport : null, showBars, dataFeatureModel));
/* 371:371 */     grid.repaint();
/* 372:    */   }
/* 373:    */   
/* 374:    */   private void updateComboCellRenderer() {
/* 375:375 */     combo.setRenderer(new ComboCellRenderer(useColorScheme ? themeSupport : null));
/* 376:    */   }
/* 377:    */   
/* 378:    */   protected JGrid buildGrid() {
/* 379:379 */     JGrid result = new JGrid();
/* 380:    */     
/* 381:381 */     result.setDragEnabled(true);
/* 382:382 */     result.setTransferHandler(new ATsCollectionView.TsCollectionTransferHandler(this));
/* 383:383 */     result.setColumnRenderer(new GridColumnRenderer());
/* 384:384 */     result.setRowRenderer(new GridRowRenderer());
/* 385:385 */     result.getSelectionModel().setSelectionMode(2);
/* 386:    */     
/* 387:387 */     result.addMouseListener(new PopupListener.PopupAdapter(buildGridMenu().getPopupMenu()));
/* 388:388 */     result.addMouseListener(new ATsCollectionView.TsActionMouseAdapter(this));
/* 389:    */     
/* 390:390 */     fillActionMap(result.getActionMap());
/* 391:391 */     fillInputMap(result.getInputMap(2));
/* 392:    */     
/* 393:393 */     return result;
/* 394:    */   }
/* 395:    */   
/* 396:    */   protected JMenu buildGridMenu()
/* 397:    */   {
/* 398:398 */     JMenu result = super.buildGridMenu();
/* 399:    */     
/* 400:    */ 
/* 401:    */ 
/* 402:402 */     result.addSeparator();
/* 403:    */     
/* 404:404 */     JMenuItem item = new JMenuItem(getActionMap().get("format"));
/* 405:405 */     item.setText("Edit format...");
/* 406:406 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_GLOBE));
/* 407:407 */     result.add(item);
/* 408:    */     
/* 409:409 */     item = new JCheckBoxMenuItem(JTsGridCommand.toggleUseColorScheme().toAction(this));
/* 410:410 */     item.setText("Use color scheme");
/* 411:411 */     result.add(item);
/* 412:    */     
/* 413:413 */     result.add(buildColorSchemeMenu());
/* 414:    */     
/* 415:415 */     item = new JCheckBoxMenuItem(JTsGridCommand.toggleShowBars().toAction(this));
/* 416:416 */     item.setText("Show bars");
/* 417:417 */     item.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_TASKS));
/* 418:418 */     result.add(item);
/* 419:    */     
/* 420:420 */     JMenu zoom = new JMenu("Zoom");
/* 421:421 */     zoom.setIcon(demetraUI.getPopupMenuIcon(FontAwesome.FA_SEARCH));
/* 422:422 */     final JSlider slider = new JSlider(10, 200, 100);
/* 423:    */     
/* 424:424 */     slider.setPreferredSize(new Dimension(50, getPreferredSize()height));
/* 425:425 */     slider.addChangeListener(new ChangeListener()
/* 426:    */     {
/* 427:    */       public void stateChanged(ChangeEvent e) {
/* 428:428 */         setZoomRatio(slider.getValue());
/* 429:    */       }
/* 430:430 */     });
/* 431:431 */     addPropertyChangeListener("zoom", new PropertyChangeListener()
/* 432:    */     {
/* 433:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 434:434 */         slider.setValue(getZoomRatio());
/* 435:    */       }
/* 436:    */       
/* 437:437 */     });
/* 438:438 */     zoom.add(slider);
/* 439:439 */     for (int o : new int[] { 200, 100, 75, 50, 25 }) {
/* 440:440 */       zoom.add(new JCheckBoxMenuItem(TsGridCommand.applyZoomRatio(o).toAction(this))).setText(o + "%");
/* 441:    */     }
/* 442:442 */     result.add(zoom);
/* 443:    */     
/* 444:444 */     return result;
/* 445:    */   }
/* 446:    */   
/* 447:447 */   private class GridSelectionListener extends ATsCollectionView.TsCollectionSelectionListener { private GridSelectionListener() { super(); }
/* 448:    */     
/* 449:    */     protected void selectionChanged(ListSelectionModel model)
/* 450:    */     {
/* 451:451 */       if (mode == ITsGrid.Mode.MULTIPLETS) {
/* 452:452 */         super.selectionChanged(model);
/* 453:    */       }
/* 454:454 */       else if (collection.getCount() > singleTsIndex) {
/* 455:455 */         setSelection(new Ts[] { collection.get(singleTsIndex) });
/* 456:    */       } else {
/* 457:457 */         setSelection(null);
/* 458:    */       }
/* 459:    */     }
/* 460:    */   }
/* 461:    */   
/* 462:    */   private static class GridColumnRenderer
/* 463:    */     implements TableCellRenderer
/* 464:    */   {
/* 465:    */     private final TableCellRenderer delegate;
/* 466:    */     
/* 467:    */     public GridColumnRenderer()
/* 468:    */     {
/* 469:469 */       delegate = new JTable().getTableHeader().getDefaultRenderer();
/* 470:    */     }
/* 471:    */     
/* 472:    */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 473:    */     {
/* 474:474 */       Component result = delegate.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 475:475 */       if ((result instanceof JLabel)) {
/* 476:476 */         JLabel label = (JLabel)result;
/* 477:477 */         label.setToolTipText(label.getText());
/* 478:    */       }
/* 479:479 */       return result;
/* 480:    */     }
/* 481:    */   }
/* 482:    */   
/* 483:    */   private static class GridRowRenderer extends GridRowHeaderRenderer
/* 484:    */   {
/* 485:    */     public GridRowRenderer() {
/* 486:486 */       setHorizontalAlignment(11);
/* 487:    */     }
/* 488:    */     
/* 489:    */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 490:    */     {
/* 491:491 */       Component result = super.getTableCellRendererComponent(table, value, false, hasFocus, row, column);
/* 492:492 */       if ((result instanceof JLabel)) {
/* 493:493 */         JLabel label = (JLabel)result;
/* 494:494 */         label.setToolTipText(label.getText());
/* 495:    */       }
/* 496:496 */       return result;
/* 497:    */     }
/* 498:    */   }
/* 499:    */   
/* 500:    */   private static class GridCellRenderer extends BarTableCellRenderer
/* 501:    */   {
/* 502:    */     private final Formatters.Formatter<? super TsPeriod> periodFormatter;
/* 503:    */     private final Formatters.Formatter<? super Number> valueFormatter;
/* 504:    */     private final SwingColorSchemeSupport colorSchemeSupport;
/* 505:    */     private final boolean showBars;
/* 506:    */     private final DataFeatureModel dataFeatureModel;
/* 507:    */     private final JToolTip toolTip;
/* 508:    */     
/* 509:    */     public GridCellRenderer(@Nonnull DataFormat dataFormat, @Nullable SwingColorSchemeSupport colorSchemeSupport, boolean showBars, DataFeatureModel dataFeatureModel) {
/* 510:510 */       super();
/* 511:511 */       setHorizontalAlignment(11);
/* 512:512 */       setOpaque(true);
/* 513:513 */       periodFormatter = dataFormat.dateFormatter().compose(JTsGrid.DateFunction.INSTANCE);
/* 514:514 */       valueFormatter = dataFormat.numberFormatter();
/* 515:515 */       this.colorSchemeSupport = colorSchemeSupport;
/* 516:516 */       this.showBars = showBars;
/* 517:517 */       this.dataFeatureModel = dataFeatureModel;
/* 518:518 */       toolTip = super.createToolTip();
/* 519:    */     }
/* 520:    */     
/* 521:    */     public JToolTip createToolTip()
/* 522:    */     {
/* 523:523 */       if (colorSchemeSupport != null) {
/* 524:524 */         toolTip.setBackground(getForeground());
/* 525:525 */         toolTip.setForeground(getBackground());
/* 526:    */       }
/* 527:527 */       return toolTip;
/* 528:    */     }
/* 529:    */     
/* 530:    */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 531:    */     {
/* 532:532 */       super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/* 533:    */       
/* 534:534 */       TsGridObs obs = (TsGridObs)value;
/* 535:    */       
/* 536:536 */       if (colorSchemeSupport != null) {
/* 537:537 */         setBackground((Color)colorSchemeSupport.getPlotColor());
/* 538:538 */         setForeground((Color)colorSchemeSupport.getLineColor(obs.getSeriesIndex()));
/* 539:    */       }
/* 540:    */       
/* 541:541 */       setBarValues(0.0D, 0.0D, 0.0D);
/* 542:    */       
/* 543:543 */       switch (obs.getInfo()) {
/* 544:    */       case Empty: 
/* 545:545 */         setText(null);
/* 546:546 */         setToolTipText(null);
/* 547:547 */         break;
/* 548:    */       case Missing: 
/* 549:549 */         setText(".");
/* 550:550 */         setToolTipText(periodFormatter.formatAsString(obs.getPeriod()));
/* 551:551 */         break;
/* 552:    */       case Valid: 
/* 553:553 */         boolean forecast = dataFeatureModel.hasFeature(Ts.DataFeature.Forecasts, obs.getSeriesIndex(), obs.getIndex());
/* 554:554 */         String valueAsString = valueFormatter.formatAsString(Double.valueOf(obs.getValue()));
/* 555:555 */         String periodAsString = periodFormatter.formatAsString(obs.getPeriod());
/* 556:556 */         if (forecast) {
/* 557:557 */           setText("<html><i>" + valueAsString);
/* 558:558 */           setToolTipText("<html>" + periodAsString + ": " + valueAsString + "<br>Forecast");
/* 559:559 */           if (!isSelected) {
/* 560:560 */             setForeground(getForeground().darker());
/* 561:    */           }
/* 562:    */         } else {
/* 563:563 */           setText(valueAsString);
/* 564:564 */           setToolTipText(periodAsString + ": " + valueAsString);
/* 565:    */         }
/* 566:566 */         if ((showBars) && (!isSelected)) {
/* 567:567 */           DescriptiveStatistics stats = obs.getStats();
/* 568:568 */           setBarValues(stats.getMin(), stats.getMax(), obs.getValue());
/* 569:    */         }
/* 570:    */         break;
/* 571:    */       }
/* 572:    */       
/* 573:573 */       if ((isSelected) && (colorSchemeSupport != null)) {
/* 574:574 */         Color saved = getForeground();
/* 575:575 */         setForeground(getBackground());
/* 576:576 */         setBackground(saved);
/* 577:    */       }
/* 578:    */       
/* 579:579 */       return this;
/* 580:    */     }
/* 581:    */   }
/* 582:    */   
/* 583:    */   private static class ComboCellRenderer extends DefaultListCellRenderer
/* 584:    */   {
/* 585:    */     private final MonikerUI monikerUI;
/* 586:    */     private final SwingColorSchemeSupport colorSchemeSupport;
/* 587:    */     
/* 588:    */     public ComboCellRenderer(@Nullable SwingColorSchemeSupport colorSchemeSupport) {
/* 589:589 */       monikerUI = MonikerUI.getDefault();
/* 590:590 */       this.colorSchemeSupport = colorSchemeSupport;
/* 591:    */     }
/* 592:    */     
/* 593:    */     public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 594:    */     {
/* 595:595 */       super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/* 596:596 */       Ts ts = (Ts)value;
/* 597:597 */       setText(ts.getName());
/* 598:598 */       setIcon(monikerUI.getIcon(ts));
/* 599:599 */       if ((colorSchemeSupport != null) && (index != -1)) {
/* 600:600 */         if (isSelected) {
/* 601:601 */           setBackground((Color)colorSchemeSupport.getPlotColor());
/* 602:    */         }
/* 603:603 */         setForeground((Color)colorSchemeSupport.getLineColor(index));
/* 604:    */       }
/* 605:605 */       return this;
/* 606:    */     }
/* 607:    */   }
/* 608:    */   
/* 609:    */   private static class DateFunction
/* 610:    */     implements Function<TsPeriod, Date>
/* 611:    */   {
/* 612:612 */     public static final DateFunction INSTANCE = new DateFunction();
/* 613:    */     
/* 614:    */     public Date apply(TsPeriod input)
/* 615:    */     {
/* 616:616 */       return input.middle();
/* 617:    */     }
/* 618:    */   }
/* 619:    */ }
