/*  1:   */ package ec.ui.grid;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.design.UtilityClass;
/*  4:   */ import ec.util.various.swing.JCommand;
/*  5:   */ import ec.util.various.swing.JCommand.ActionAdapter;
/*  6:   */ import java.awt.Component;
/*  7:   */ import javax.annotation.Nonnull;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ @UtilityClass({JTsGrid.class})
/* 34:   */ public final class JTsGridCommand
/* 35:   */ {
/* 36:   */   @Nonnull
/* 37:   */   public static JCommand<JTsGrid> toggleUseColorScheme()
/* 38:   */   {
/* 39:39 */     return ToggleUseColorSchemeCommand.INSTANCE;
/* 40:   */   }
/* 41:   */   
/* 42:   */   @Nonnull
/* 43:   */   public static JCommand<JTsGrid> toggleShowBars() {
/* 44:44 */     return ToggleShowBarsCommand.INSTANCE;
/* 45:   */   }
/* 46:   */   
/* 47:   */   private static final class ToggleUseColorSchemeCommand
/* 48:   */     extends JCommand<JTsGrid>
/* 49:   */   {
/* 50:50 */     public static final ToggleUseColorSchemeCommand INSTANCE = new ToggleUseColorSchemeCommand();
/* 51:   */     
/* 52:   */     public void execute(JTsGrid component) throws Exception
/* 53:   */     {
/* 54:54 */       component.setUseColorScheme(!component.isUseColorScheme());
/* 55:   */     }
/* 56:   */     
/* 57:   */     public boolean isSelected(JTsGrid component)
/* 58:   */     {
/* 59:59 */       return component.isUseColorScheme();
/* 60:   */     }
/* 61:   */     
/* 62:   */     public JCommand.ActionAdapter toAction(JTsGrid c)
/* 63:   */     {
/* 64:64 */       JCommand.ActionAdapter result = super.toAction(c);
/* 65:65 */       return (c instanceof Component) ? result.withWeakPropertyChangeListener(c, new String[] { "useColorScheme" }) : result;
/* 66:   */     }
/* 67:   */   }
/* 68:   */   
/* 69:   */   private static final class ToggleShowBarsCommand extends JCommand<JTsGrid>
/* 70:   */   {
/* 71:71 */     public static final ToggleShowBarsCommand INSTANCE = new ToggleShowBarsCommand();
/* 72:   */     
/* 73:   */     public void execute(JTsGrid component) throws Exception
/* 74:   */     {
/* 75:75 */       component.setShowBars(!component.isShowBars());
/* 76:   */     }
/* 77:   */     
/* 78:   */     public boolean isSelected(JTsGrid component)
/* 79:   */     {
/* 80:80 */       return component.isShowBars();
/* 81:   */     }
/* 82:   */     
/* 83:   */     public JCommand.ActionAdapter toAction(JTsGrid c)
/* 84:   */     {
/* 85:85 */       JCommand.ActionAdapter result = super.toAction(c);
/* 86:86 */       return (c instanceof Component) ? result.withWeakPropertyChangeListener(c, new String[] { "showBars" }) : result;
/* 87:   */     }
/* 88:   */   }
/* 89:   */ }
