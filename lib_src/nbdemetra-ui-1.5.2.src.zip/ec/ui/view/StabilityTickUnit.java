/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.jfree.chart.axis.NumberTickUnit;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public class StabilityTickUnit
/* 13:   */   extends NumberTickUnit
/* 14:   */ {
/* 15:   */   private List<String> names;
/* 16:   */   
/* 17:   */   public StabilityTickUnit(List<String> names)
/* 18:   */   {
/* 19:19 */     super(1.0D);
/* 20:20 */     this.names = names;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String valueToString(double value)
/* 24:   */   {
/* 25:25 */     return (String)names.get((int)value);
/* 26:   */   }
/* 27:   */ }
