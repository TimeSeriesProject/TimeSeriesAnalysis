/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import ec.ui.view.res.ResidualsView;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class ResidualsUI<V extends IProcDocumentView<?>>
/* 16:   */   extends DefaultItemUI<V, TsData>
/* 17:   */ {
/* 18:   */   public JComponent getView(V host, TsData information)
/* 19:   */   {
/* 20:20 */     ResidualsView resView = new ResidualsView();
/* 21:21 */     resView.setTsData(information);
/* 22:22 */     return resView;
/* 23:   */   }
/* 24:   */ }
