/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DocumentUIServices;
/*   4:    */ import ec.nbdemetra.ui.DocumentUIServices.UIFactory;
/*   5:    */ import ec.tstoolkit.algorithm.IActiveProcDocument;
/*   6:    */ import ec.tstoolkit.algorithm.IProcSpecification;
/*   7:    */ import ec.tstoolkit.utilities.Id;
/*   8:    */ import ec.ui.interfaces.IDisposable;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import java.beans.PropertyChangeEvent;
/*  11:    */ import javax.swing.AbstractAction;
/*  12:    */ import javax.swing.JButton;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.JPanel;
/*  15:    */ import javax.swing.JSplitPane;
/*  16:    */ import org.openide.explorer.ExplorerManager;
/*  17:    */ import org.openide.explorer.view.BeanTreeView;
/*  18:    */ import org.openide.nodes.Node;
/*  19:    */ 
/*  20:    */ public class DefaultProcessingViewer<D extends IActiveProcDocument> extends JComponent implements IDisposable, org.openide.explorer.ExplorerManager.Provider
/*  21:    */ {
/*  22:    */   public static final String BUTTONS = "Buttons";
/*  23:    */   public static final String BUTTON_APPLY = "Apply";
/*  24:    */   public static final String BUTTON_RESTORE = "Restore";
/*  25:    */   public static final String BUTTON_SAVE = "Save";
/*  26:    */   protected final Type type_;
/*  27:    */   protected final java.util.UUID m_identifier;
/*  28:    */   protected final JSplitPane splitter;
/*  29:    */   protected final JPanel specPanel;
/*  30:    */   protected final BeanTreeView m_tree;
/*  31:    */   protected final ExplorerManager em;
/*  32:    */   protected final javax.swing.JToolBar toolBar;
/*  33:    */   protected final JComponent emptyView;
/*  34:    */   protected IProcDocumentView<D> m_procView;
/*  35:    */   protected ec.tstoolkit.descriptors.IObjectDescriptor<? extends IProcSpecification> specDescriptor;
/*  36:    */   protected IProcSpecification originalSpec;
/*  37:    */   
/*  38:    */   public static enum Type
/*  39:    */   {
/*  40: 40 */     NONE,  APPLY,  APPLY_RESTORE_SAVE;
/*  41:    */   }
/*  42:    */   
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56: 56 */   protected int specWidth_ = 300;
/*  57:    */   
/*  58:    */   protected DefaultProcessingViewer(Type type) {
/*  59: 59 */     type_ = type;
/*  60: 60 */     m_identifier = java.util.UUID.randomUUID();
/*  61:    */     
/*  62: 62 */     specPanel = new JPanel(new java.awt.BorderLayout());
/*  63: 63 */     specPanel.setVisible(false);
/*  64:    */     
/*  65: 65 */     m_tree = new BeanTreeView();
/*  66: 66 */     m_tree.setRootVisible(false);
/*  67: 67 */     m_tree.setSelectionMode(1);
/*  68:    */     
/*  69: 69 */     em = new ExplorerManager();
/*  70: 70 */     em.addVetoableChangeListener(new java.beans.VetoableChangeListener()
/*  71:    */     {
/*  72:    */       public void vetoableChange(PropertyChangeEvent evt) throws java.beans.PropertyVetoException {
/*  73: 73 */         if ("selectedNodes".equals(evt.getPropertyName())) {
/*  74: 74 */           Node[] nodes = (Node[])evt.getNewValue();
/*  75: 75 */           if (nodes.length > 0) {
/*  76: 76 */             Id id = (Id)nodes[0].getLookup().lookup(Id.class);
/*  77: 77 */             DefaultProcessingViewer.this.showComponent(id);
/*  78:    */           }
/*  79:    */           
/*  80:    */         }
/*  81:    */       }
/*  82: 82 */     });
/*  83: 83 */     emptyView = new JPanel(new java.awt.BorderLayout());
/*  84:    */     
/*  85: 85 */     splitter = ec.nbdemetra.ui.NbComponents.newJSplitPane(1, m_tree, emptyView);
/*  86: 86 */     splitter.setDividerLocation(200);
/*  87: 87 */     splitter.setResizeWeight(0.2D);
/*  88:    */     
/*  89: 89 */     toolBar = ec.nbdemetra.ui.NbComponents.newInnerToolbar();
/*  90: 90 */     toolBar.add(javax.swing.Box.createHorizontalGlue());
/*  91: 91 */     toolBar.addSeparator();
/*  92: 92 */     toolBar.add(new javax.swing.JToggleButton(new AbstractAction("Specifications")
/*  93:    */     {
/*  94:    */       public void actionPerformed(ActionEvent e) {
/*  95: 95 */         setSpecificationsVisible(!isSpecificationsVisible());
/*  96:    */       }
/*  97:    */       
/*  98: 98 */     }));
/*  99: 99 */     setLayout(new java.awt.BorderLayout());
/* 100:100 */     add(toolBar, "North");
/* 101:101 */     add(splitter, "Center");
/* 102:102 */     add(specPanel, "East");
/* 103:    */   }
/* 104:    */   
/* 105:    */ 
/* 106:    */   public ExplorerManager getExplorerManager()
/* 107:    */   {
/* 108:108 */     return em;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public java.util.UUID getIdentifier() {
/* 112:112 */     return m_identifier;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public int getSpecWidth() {
/* 116:116 */     return specWidth_;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setSpecWidth(int value) {
/* 120:120 */     specWidth_ = value;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public D getDocument() {
/* 124:124 */     return m_procView == null ? null : (IActiveProcDocument)m_procView.getDocument();
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void setDocument(D doc) {
/* 128:    */     try {
/* 129:129 */       if (m_procView != null) {
/* 130:130 */         m_procView.dispose();
/* 131:131 */         m_procView = null;
/* 132:    */       }
/* 133:133 */       if (doc == null) {
/* 134:134 */         originalSpec = null;
/* 135:135 */         return;
/* 136:    */       }
/* 137:137 */       originalSpec = doc.getSpecification();
/* 138:    */       
/* 139:139 */       DocumentUIServices.UIFactory factory = DocumentUIServices.getDefault().getFactory(doc.getClass());
/* 140:140 */       if (factory == null) {
/* 141:141 */         return;
/* 142:    */       }
/* 143:    */       
/* 144:144 */       m_procView = factory.getDocumentView(doc);
/* 145:145 */       initSpecView(factory, doc);
/* 146:    */     } finally {
/* 147:147 */       buildTree();
/* 148:148 */       refreshHeader();
/* 149:    */     }
/* 150:147 */     buildTree();
/* 151:148 */     refreshHeader();
/* 152:    */   }
/* 153:    */   
/* 154:    */   public boolean isHeaderVisible()
/* 155:    */   {
/* 156:153 */     return toolBar.isVisible();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setHeaderVisible(boolean visible) {
/* 160:157 */     toolBar.setVisible(visible);
/* 161:158 */     if (visible) {
/* 162:159 */       refreshHeader();
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public boolean isSpecificationsVisible() {
/* 167:164 */     return specPanel.isVisible();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void setSpecificationsVisible(boolean visible) {
/* 171:168 */     specPanel.setVisible(visible);
/* 172:    */   }
/* 173:    */   
/* 174:    */ 
/* 175:    */   public void initSpecView()
/* 176:    */   {
/* 177:174 */     ec.tstoolkit.algorithm.IProcDocument doc = getDocument();
/* 178:175 */     if (doc == null) {
/* 179:176 */       return;
/* 180:    */     }
/* 181:178 */     DocumentUIServices.UIFactory factory = DocumentUIServices.getDefault().getFactory(doc.getClass());
/* 182:179 */     if (factory == null) {
/* 183:180 */       return;
/* 184:    */     }
/* 185:182 */     initSpecView(factory, getDocument());
/* 186:    */   }
/* 187:    */   
/* 188:    */   private void initSpecView(DocumentUIServices.UIFactory factory, D document) {
/* 189:186 */     specDescriptor = factory.getSpecificationDescriptor(document);
/* 190:187 */     if (specDescriptor == null) {
/* 191:188 */       return;
/* 192:    */     }
/* 193:190 */     if (type_ == Type.APPLY) {
/* 194:191 */       initApplySpecView(factory);
/* 195:192 */     } else if (type_ == Type.APPLY_RESTORE_SAVE) {
/* 196:193 */       initAllSpecView(factory);
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   private void initApplySpecView(DocumentUIServices.UIFactory factory) {
/* 201:198 */     javax.swing.Action[] commands = {
/* 202:199 */       new AbstractAction("Apply")
/* 203:    */       {
/* 204:    */         public void actionPerformed(ActionEvent e) {
/* 205:202 */           IActiveProcDocument doc = getDocument();
/* 206:203 */           IProcSpecification pspec = (IProcSpecification)specDescriptor.getCore();
/* 207:204 */           doc.setSpecification(pspec.clone());
/* 208:205 */           setDirty(null, false);
/* 209:206 */           firePropertyChange("Apply", null, null);
/* 210:207 */           refreshView();
/* 211:208 */           if (isHeaderVisible()) {
/* 212:209 */             refreshHeader();
/* 213:    */           }
/* 214:    */         }
/* 215:212 */       } };
/* 216:213 */     setPropertiesPanel(commands, factory.getSpecView(specDescriptor), specWidth_);
/* 217:    */   }
/* 218:    */   
/* 219:    */   private void initAllSpecView(DocumentUIServices.UIFactory factory) {
/* 220:217 */     final IActiveProcDocument doc = getDocument();
/* 221:    */     
/* 222:219 */     javax.swing.Action[] commands = {
/* 223:220 */       new AbstractAction("Apply")
/* 224:    */       
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:235 */       new AbstractAction
/* 239:    */       {
/* 240:    */         public void actionPerformed(ActionEvent e) {
/* 241:223 */           IProcSpecification pspec = (IProcSpecification)specDescriptor.getCore();
/* 242:224 */           doc.setSpecification(pspec.clone());
/* 243:225 */           setDirty("Apply", false);
/* 244:226 */           setDirty("Restore", true);
/* 245:227 */           setDirty("Save", true);
/* 246:228 */           firePropertyChange("Apply", null, null);
/* 247:229 */           refreshView();
/* 248:230 */           if (isHeaderVisible()) {
/* 249:231 */             refreshHeader();
/* 250:    */           }
/* 251:    */           
/* 252:    */         }
/* 253:235 */       }, new AbstractAction("Restore")
/* 254:    */       
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:249 */       new AbstractAction
/* 268:    */       {
/* 269:    */         public void actionPerformed(ActionEvent e) {
/* 270:238 */           doc.setSpecification(originalSpec);
/* 271:239 */           setDirty("Apply", false);
/* 272:240 */           setDirty("Restore", false);
/* 273:241 */           setDirty("Save", false);
/* 274:242 */           firePropertyChange("Restore", null, null);
/* 275:243 */           refreshView();
/* 276:244 */           if (isHeaderVisible()) {
/* 277:245 */             refreshHeader();
/* 278:    */           }
/* 279:    */           
/* 280:    */         }
/* 281:249 */       }, new AbstractAction("Save")
/* 282:    */       {
/* 283:    */         public void actionPerformed(ActionEvent e) {
/* 284:252 */           setDirty("Apply", false);
/* 285:253 */           setDirty("Restore", false);
/* 286:254 */           setDirty("Save", false);
/* 287:255 */           firePropertyChange("Save", null, null);
/* 288:    */         }
/* 289:    */         
/* 290:258 */       } };
/* 291:259 */     specDescriptor = factory.getSpecificationDescriptor(doc);
/* 292:260 */     setPropertiesPanel(commands, factory.getSpecView(specDescriptor), specWidth_);
/* 293:    */   }
/* 294:    */   
/* 295:    */   private void setPropertiesPanel(javax.swing.Action[] commands, JComponent pane, int width)
/* 296:    */   {
/* 297:265 */     specPanel.removeAll();
/* 298:266 */     specPanel.add(pane, "Center");
/* 299:267 */     pane.addPropertyChangeListener("specification", new java.beans.PropertyChangeListener()
/* 300:    */     {
/* 301:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 302:270 */         setDirty("Apply", true);
/* 303:271 */         setDirty("Restore", true);
/* 304:    */       }
/* 305:    */       
/* 306:274 */     });
/* 307:275 */     JPanel buttonPanel = new JPanel();
/* 308:276 */     buttonPanel.setName("Buttons");
/* 309:277 */     buttonPanel.setLayout(new javax.swing.BoxLayout(buttonPanel, 0));
/* 310:278 */     for (int i = 0; i < commands.length; i++) {
/* 311:279 */       JButton applyButton = new JButton(commands[i]);
/* 312:280 */       applyButton.setForeground(java.awt.Color.GRAY);
/* 313:281 */       buttonPanel.add(applyButton);
/* 314:282 */       if (i < commands.length - 1) {
/* 315:283 */         buttonPanel.add(javax.swing.Box.createRigidArea(new java.awt.Dimension(2, 0)));
/* 316:    */       }
/* 317:    */     }
/* 318:286 */     specPanel.add(buttonPanel, "South");
/* 319:287 */     specPanel.setPreferredSize(new java.awt.Dimension(width, 100));
/* 320:288 */     specPanel.validate();
/* 321:    */   }
/* 322:    */   
/* 323:    */   public void refreshAll() {
/* 324:292 */     m_procView.refresh();
/* 325:    */     
/* 326:294 */     D doc = getDocument();
/* 327:295 */     DocumentUIServices.UIFactory factory = DocumentUIServices.getDefault().getFactory(doc.getClass());
/* 328:296 */     if (factory != null) {
/* 329:297 */       initSpecView(factory, doc);
/* 330:    */     }
/* 331:    */     
/* 332:300 */     Node[] sel = em.getSelectedNodes();
/* 333:301 */     if (!ec.tstoolkit.utilities.Arrays2.isNullOrEmpty(sel)) {
/* 334:302 */       Id curid = (Id)sel[0].getLookup().lookup(Id.class);
/* 335:303 */       if (curid != null) {
/* 336:304 */         showComponent(curid);
/* 337:    */       }
/* 338:    */     } else {
/* 339:307 */       selectPreferredView();
/* 340:    */     }
/* 341:309 */     if (isHeaderVisible()) {
/* 342:310 */       refreshHeader();
/* 343:    */     }
/* 344:    */   }
/* 345:    */   
/* 346:    */ 
/* 347:    */   public void refreshHeader() {}
/* 348:    */   
/* 349:    */   public void refreshView()
/* 350:    */   {
/* 351:319 */     m_procView.refresh();
/* 352:320 */     Node[] sel = em.getSelectedNodes();
/* 353:321 */     if (!ec.tstoolkit.utilities.Arrays2.isNullOrEmpty(sel)) {
/* 354:322 */       Id curid = (Id)sel[0].getLookup().lookup(Id.class);
/* 355:323 */       if (curid != null) {
/* 356:324 */         showComponent(curid);
/* 357:    */       }
/* 358:    */     } else {
/* 359:327 */       selectPreferredView();
/* 360:    */     }
/* 361:    */   }
/* 362:    */   
/* 363:    */   protected void setTreeTransferHandler(javax.swing.TransferHandler handler) {
/* 364:332 */     m_tree.setTransferHandler(handler);
/* 365:    */   }
/* 366:    */   
/* 367:    */   private void buildTree() {
/* 368:336 */     if (m_procView != null) {
/* 369:337 */       em.setRootContext(new ec.nbdemetra.ui.nodes.DecoratedNode(ec.nbdemetra.ui.nodes.IdNodes.getRootNode(m_procView.getItems())));
/* 370:338 */       selectPreferredView();
/* 371:    */     } else {
/* 372:340 */       em.setRootContext(Node.EMPTY);
/* 373:341 */       showComponent(null);
/* 374:    */     }
/* 375:    */   }
/* 376:    */   
/* 377:    */   private void showComponent(Id id) {
/* 378:346 */     java.awt.Component oldView = splitter.getBottomComponent();
/* 379:347 */     if ((oldView instanceof IDisposable)) {
/* 380:348 */       ((IDisposable)oldView).dispose();
/* 381:    */     }
/* 382:    */     JComponent newView;
/* 383:    */     try
/* 384:    */     {
/* 385:353 */       newView = id == null ? emptyView : m_procView.getView(id);
/* 386:    */     } catch (RuntimeException ex) { JComponent newView;
/* 387:355 */       newView = ec.nbdemetra.ui.awt.ExceptionPanel.create(ex);
/* 388:    */     }
/* 389:    */     
/* 390:358 */     int sep = splitter.getDividerLocation();
/* 391:359 */     splitter.setBottomComponent(newView != null ? newView : emptyView);
/* 392:360 */     splitter.setDividerLocation(sep);
/* 393:    */   }
/* 394:    */   
/* 395:    */   private void selectPreferredView() {
/* 396:364 */     Id pview = m_procView.getPreferredView();
/* 397:365 */     if (pview != null) {
/* 398:366 */       showComponent(pview);
/* 399:367 */       Node node = ec.nbdemetra.ui.nodes.IdNodes.findNode(em.getRootContext(), pview);
/* 400:    */       try {
/* 401:369 */         if (node != null) {
/* 402:370 */           em.setSelectedNodes(new Node[] { node });
/* 403:371 */           ((ec.nbdemetra.ui.nodes.DecoratedNode)node).setHtmlDecorator(ec.nbdemetra.ui.nodes.DecoratedNode.Html.BOLD);
/* 404:    */         }
/* 405:    */       } catch (java.beans.PropertyVetoException ex) {
/* 406:374 */         org.openide.util.Exceptions.printStackTrace(ex);
/* 407:    */       }
/* 408:    */     }
/* 409:    */   }
/* 410:    */   
/* 411:    */   public void dispose()
/* 412:    */   {
/* 413:381 */     if (m_procView != null) {
/* 414:382 */       m_procView.dispose();
/* 415:    */     }
/* 416:384 */     m_tree.setTransferHandler(null);
/* 417:385 */     java.awt.Component old = splitter.getBottomComponent();
/* 418:386 */     if ((old instanceof IDisposable)) {
/* 419:387 */       ((IDisposable)old).dispose();
/* 420:    */     }
/* 421:389 */     splitter.setBottomComponent(emptyView);
/* 422:390 */     removeAll();
/* 423:    */   }
/* 424:    */   
/* 425:    */   public void setDirty(String cmd, boolean b) {
/* 426:394 */     setDirty(specPanel, cmd, b);
/* 427:    */   }
/* 428:    */   
/* 429:    */   private static void setDirty(java.awt.Container container, String cmd, boolean dirty) {
/* 430:398 */     for (java.awt.Component o : container.getComponents()) {
/* 431:399 */       if ((o instanceof JButton)) {
/* 432:400 */         JButton bn = (JButton)o;
/* 433:401 */         String bncmd = bn.getActionCommand();
/* 434:402 */         if ((cmd == null) || (cmd.equals(bncmd))) {
/* 435:403 */           bn.setEnabled(dirty);
/* 436:404 */           bn.setForeground(dirty ? java.awt.Color.BLUE : java.awt.Color.GRAY);
/* 437:405 */           if (cmd == null) {}
/* 438:    */         }
/* 439:    */         
/* 440:    */       }
/* 441:409 */       else if (((o instanceof java.awt.Container)) && ("Buttons".equals(o.getName()))) {
/* 442:410 */         setDirty((java.awt.Container)o, cmd, dirty);
/* 443:    */       }
/* 444:    */     }
/* 445:    */   }
/* 446:    */ }
