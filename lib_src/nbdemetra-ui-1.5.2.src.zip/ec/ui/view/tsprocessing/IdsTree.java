/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.utilities.Id;
/*  4:   */ import ec.tstoolkit.utilities.LinearId;
/*  5:   */ import java.util.HashMap;
/*  6:   */ import java.util.Iterator;
/*  7:   */ import java.util.List;
/*  8:   */ import javax.swing.JTree;
/*  9:   */ import javax.swing.tree.DefaultMutableTreeNode;
/* 10:   */ import javax.swing.tree.DefaultTreeModel;
/* 11:   */ import javax.swing.tree.TreePath;
/* 12:   */ import org.openide.util.NbCollections;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class IdsTree
/* 21:   */ {
/* 22:   */   public static void fill(JTree tree, List<Id> items)
/* 23:   */   {
/* 24:24 */     DefaultMutableTreeNode root = new DefaultMutableTreeNode();
/* 25:   */     
/* 26:26 */     HashMap<Id, DefaultMutableTreeNode> nodes = new HashMap();
/* 27:27 */     Id[] path; int i; for (Iterator localIterator = items.iterator(); localIterator.hasNext(); 
/* 28:   */         
/* 29:   */ 
/* 30:30 */         i < path.length)
/* 31:   */     {
/* 32:27 */       Id id = (Id)localIterator.next();
/* 33:28 */       path = id.path();
/* 34:29 */       DefaultMutableTreeNode prev = null;
/* 35:30 */       i = 0; continue;
/* 36:31 */       DefaultMutableTreeNode cur = (DefaultMutableTreeNode)nodes.get(path[i]);
/* 37:32 */       if (cur == null) {
/* 38:33 */         cur = new DefaultMutableTreeNode(path[i].tail());
/* 39:34 */         if (prev == null) {
/* 40:35 */           root.add(cur);
/* 41:   */         } else {
/* 42:37 */           prev.add(cur);
/* 43:   */         }
/* 44:39 */         nodes.put(path[i], cur);
/* 45:   */       }
/* 46:41 */       prev = cur;i++;
/* 47:   */     }
/* 48:   */     
/* 49:   */ 
/* 50:45 */     DefaultTreeModel model = new DefaultTreeModel(root);
/* 51:46 */     tree.setModel(model);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static Id translate(DefaultMutableTreeNode node) {
/* 55:50 */     Object[] path = node.getUserObjectPath();
/* 56:51 */     if ((path == null) || (path.length <= 1)) {
/* 57:52 */       return null;
/* 58:   */     }
/* 59:54 */     String[] ids = new String[path.length - 1];
/* 60:55 */     for (int i = 0; i < ids.length; i++) {
/* 61:56 */       ids[i] = ((String)path[(i + 1)]);
/* 62:   */     }
/* 63:58 */     return new LinearId(ids);
/* 64:   */   }
/* 65:   */   
/* 66:   */   public static Id translate(TreePath tpath)
/* 67:   */   {
/* 68:63 */     Object[] path = tpath.getPath();
/* 69:64 */     if ((path == null) || (path.length <= 1)) {
/* 70:65 */       return null;
/* 71:   */     }
/* 72:67 */     String[] ids = new String[path.length - 1];
/* 73:68 */     for (int i = 0; i < ids.length; i++) {
/* 74:69 */       DefaultMutableTreeNode cur = (DefaultMutableTreeNode)path[(i + 1)];
/* 75:70 */       ids[i] = ((String)cur.getUserObject());
/* 76:   */     }
/* 77:72 */     return new LinearId(ids);
/* 78:   */   }
/* 79:   */   
/* 80:   */   static DefaultMutableTreeNode search(DefaultTreeModel model, Id pview)
/* 81:   */   {
/* 82:77 */     DefaultMutableTreeNode cur = (DefaultMutableTreeNode)model.getRoot();
/* 83:78 */     if (cur == null) {
/* 84:79 */       return null;
/* 85:   */     }
/* 86:81 */     int pos = 0;
/* 87:82 */     while (pos < pview.getCount()) {
/* 88:83 */       boolean ok = false;
/* 89:84 */       for (DefaultMutableTreeNode node : NbCollections.iterable(cur.children())) {
/* 90:85 */         if (pview.get(pos).equals(node.getUserObject())) {
/* 91:86 */           cur = node;
/* 92:87 */           pos++;
/* 93:88 */           ok = true;
/* 94:89 */           break;
/* 95:   */         }
/* 96:   */       }
/* 97:92 */       if (ok) {
/* 98:93 */         return null;
/* 99:   */       }
/* :0:   */     }
/* :1:96 */     return cur;
/* :2:   */   }
/* :3:   */ }
