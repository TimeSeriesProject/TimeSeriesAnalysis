/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlSlidingSpanSummary;
/*  5:   */ import ec.tstoolkit.timeseries.analysis.SlidingSpans;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public class SlidingSpansUI<V extends IProcDocumentView<?>>
/* 13:   */   extends HtmlItemUI<V, SlidingSpans>
/* 14:   */ {
/* 15:   */   private final String s_;
/* 16:   */   private final String si_;
/* 17:   */   
/* 18:   */   public SlidingSpansUI(String s, String si)
/* 19:   */   {
/* 20:20 */     s_ = s;
/* 21:21 */     si_ = si;
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected IHtmlElement getHtmlElement(V host, SlidingSpans information)
/* 25:   */   {
/* 26:26 */     return new HtmlSlidingSpanSummary(information, s_, si_);
/* 27:   */   }
/* 28:   */ }
