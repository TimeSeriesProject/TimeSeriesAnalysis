/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlDiagnosticSummary;
/*  5:   */ import ec.tss.sa.SaManager;
/*  6:   */ import ec.tstoolkit.algorithm.CompositeResults;
/*  7:   */ import ec.tstoolkit.information.InformationSet;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class DiagnosticsUI<V extends IProcDocumentView<?>>
/* 17:   */   extends HtmlItemUI<V, CompositeResults>
/* 18:   */ {
/* 19:   */   protected IHtmlElement getHtmlElement(V host, CompositeResults information)
/* 20:   */   {
/* 21:21 */     InformationSet diags = SaManager.instance.diagnostic(information);
/* 22:22 */     return new HtmlDiagnosticSummary(diags);
/* 23:   */   }
/* 24:   */ }
