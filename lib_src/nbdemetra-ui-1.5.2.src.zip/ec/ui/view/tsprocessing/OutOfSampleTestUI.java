/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlOneStepAheadForecastingTest;
/*  5:   */ import ec.tstoolkit.modelling.arima.diagnostics.IOneStepAheadForecastingTest;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class OutOfSampleTestUI<V extends IProcDocumentView<?>>
/* 15:   */   extends HtmlItemUI<V, IOneStepAheadForecastingTest>
/* 16:   */ {
/* 17:   */   protected IHtmlElement getHtmlElement(V host, IOneStepAheadForecastingTest information)
/* 18:   */   {
/* 19:19 */     return new HtmlOneStepAheadForecastingTest(information);
/* 20:   */   }
/* 21:   */ }
