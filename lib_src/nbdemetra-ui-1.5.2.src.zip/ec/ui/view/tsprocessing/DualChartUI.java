/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tss.TsFactory;
/*  5:   */ import ec.tss.documents.DocumentManager;
/*  6:   */ import ec.tss.documents.TsDocument;
/*  7:   */ import ec.ui.chart.JTsDualChart;
/*  8:   */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class DualChartUI<D extends TsDocument<?, ?>>
/* 17:   */   extends PooledItemUI<IProcDocumentView<D>, String[][], JTsDualChart>
/* 18:   */ {
/* 19:   */   public DualChartUI()
/* 20:   */   {
/* 21:21 */     super(JTsDualChart.class);
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected void init(JTsDualChart c, IProcDocumentView<D> host, String[][] information)
/* 25:   */   {
/* 26:26 */     String[] hnames = information[0];String[] lnames = information[1];
/* 27:27 */     TsCollection items = TsFactory.instance.createTsCollection();
/* 28:28 */     if (hnames != null) {
/* 29:29 */       for (int i = 0; i < hnames.length; i++) {
/* 30:30 */         items.quietAdd(DocumentManager.instance.getTs(host.getDocument(), hnames[i]));
/* 31:   */       }
/* 32:   */     }
/* 33:33 */     if (lnames != null) {
/* 34:34 */       for (int i = 0; i < lnames.length; i++) {
/* 35:35 */         items.quietAdd(DocumentManager.instance.getTs(host.getDocument(), lnames[i]));
/* 36:   */       }
/* 37:   */     }
/* 38:38 */     c.getTsCollection().quietAppend(items);
/* 39:39 */     c.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 40:40 */     int i = 0;
/* 41:41 */     if (hnames != null) {
/* 42:42 */       for (; i < hnames.length; i++) {
/* 43:43 */         c.setTsLevel(i, false);
/* 44:   */       }
/* 45:   */     }
/* 46:46 */     if (lnames != null) {
/* 47:47 */       for (int j = 0; j < lnames.length; i++) {
/* 48:48 */         c.setTsLevel(i, true);j++;
/* 49:   */       }
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }
