/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tss.TsFactory;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  6:   */ import ec.tstoolkit.utilities.NamedObject;
/*  7:   */ import java.util.List;
/*  8:   */ import javax.swing.JComponent;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class TableUI<V extends IProcDocumentView<?>>
/* 22:   */   extends DefaultItemUI<V, List<NamedObject<TsData>>>
/* 23:   */ {
/* 24:   */   public JComponent getView(V host, List<NamedObject<TsData>> document)
/* 25:   */   {
/* 26:26 */     TsCollection items = TsFactory.instance.createTsCollection();
/* 27:27 */     for (NamedObject<TsData> item : document) {
/* 28:28 */       items.add(TsFactory.instance.createTs(name, null, (TsData)object));
/* 29:   */     }
/* 30:30 */     return host.getToolkit().getGrid(items.clean(true));
/* 31:   */   }
/* 32:   */ }
