/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.satoolkit.DecompositionMode;
/*  4:   */ import ec.tstoolkit.algorithm.IProcResults;
/*  5:   */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  6:   */ import ec.tstoolkit.timeseries.analysis.DiagnosticInfo;
/*  7:   */ import ec.tstoolkit.timeseries.analysis.SlidingSpans;
/*  8:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  9:   */ import ec.ui.view.SlidingSpanView;
/* 10:   */ import javax.swing.JComponent;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class SlidingSpansDetailUI<V extends IProcDocumentView<?>>
/* 20:   */   extends DefaultItemUI<V, SlidingSpans>
/* 21:   */ {
/* 22:   */   private String info_;
/* 23:   */   
/* 24:   */   public SlidingSpansDetailUI(String info)
/* 25:   */   {
/* 26:26 */     info_ = info;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public JComponent getView(V host, SlidingSpans information)
/* 30:   */   {
/* 31:31 */     SlidingSpanView view = new SlidingSpanView();
/* 32:32 */     view.setTsToolkit(host.getToolkit());
/* 33:33 */     if (information != null) {
/* 34:34 */       double threshold = 0.03D;
/* 35:35 */       DecompositionMode mode = (DecompositionMode)information.getReferenceInfo().getData("mode", DecompositionMode.class);
/* 36:36 */       boolean mul = mode == DecompositionMode.Multiplicative;
/* 37:37 */       if (!mul) {
/* 38:38 */         TsData s = (TsData)information.getReferenceInfo().getData(info_, TsData.class);
/* 39:39 */         if (s != null) {
/* 40:40 */           DescriptiveStatistics stats = new DescriptiveStatistics(s.getValues());
/* 41:41 */           threshold = Math.sqrt(stats.getSumSquare() / stats.getDataCount());
/* 42:   */         }
/* 43:   */       }
/* 44:44 */       view.setThreshold(threshold);
/* 45:   */       
/* 46:46 */       if (info_.equals("sa")) {
/* 47:47 */         if (mul) {
/* 48:48 */           view.setInfo(DiagnosticInfo.PeriodToPeriodGrowthDifference);
/* 49:   */         }
/* 50:   */         else {
/* 51:51 */           view.setInfo(DiagnosticInfo.PeriodToPeriodDifference);
/* 52:   */         }
/* 53:   */         
/* 54:   */       }
/* 55:55 */       else if (mul) {
/* 56:56 */         view.setInfo(DiagnosticInfo.RelativeDifference);
/* 57:   */       }
/* 58:   */       else {
/* 59:59 */         view.setInfo(DiagnosticInfo.AbsoluteDifference);
/* 60:   */       }
/* 61:   */       
/* 62:   */ 
/* 63:63 */       view.setInfoName(info_);
/* 64:64 */       view.setSlidingSpans(information);
/* 65:   */     }
/* 66:   */     else {
/* 67:67 */       view.setSlidingSpans(null);
/* 68:   */     }
/* 69:69 */     return view;
/* 70:   */   }
/* 71:   */ }
