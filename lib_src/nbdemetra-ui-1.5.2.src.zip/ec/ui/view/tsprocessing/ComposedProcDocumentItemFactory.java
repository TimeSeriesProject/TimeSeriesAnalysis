/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import ec.nbdemetra.ui.awt.ExceptionPanel;
/*   5:    */ import ec.tstoolkit.algorithm.IProcDocument;
/*   6:    */ import ec.tstoolkit.utilities.Id;
/*   7:    */ import ec.tstoolkit.utilities.InformationExtractor;
/*   8:    */ import java.awt.BorderLayout;
/*   9:    */ import java.awt.Component;
/*  10:    */ import java.awt.Font;
/*  11:    */ import java.util.concurrent.ExecutionException;
/*  12:    */ import javax.annotation.Nonnull;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.JLabel;
/*  15:    */ import javax.swing.SwingWorker;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ public class ComposedProcDocumentItemFactory<D extends IProcDocument, I>
/*  48:    */   extends ProcDocumentItemFactory
/*  49:    */ {
/*  50:    */   protected final Class<D> documentType;
/*  51:    */   protected final Id itemId;
/*  52:    */   protected final InformationExtractor<? super D, ?> informationExtractor;
/*  53:    */   protected final ItemUI itemUI;
/*  54:    */   protected boolean async;
/*  55:    */   
/*  56:    */   public ComposedProcDocumentItemFactory(@Nonnull Class<D> documentType, @Nonnull Id itemId, @Nonnull InformationExtractor<? super D, I> informationExtractor, @Nonnull ItemUI<? extends IProcDocumentView<D>, I> itemUI)
/*  57:    */   {
/*  58: 58 */     this.documentType = ((Class)Preconditions.checkNotNull(documentType, "documentType"));
/*  59: 59 */     this.itemId = ((Id)Preconditions.checkNotNull(itemId, "itemId"));
/*  60: 60 */     this.informationExtractor = ((InformationExtractor)Preconditions.checkNotNull(informationExtractor, "informationExtractor"));
/*  61: 61 */     this.itemUI = ((ItemUI)Preconditions.checkNotNull(itemUI, "itemUI"));
/*  62: 62 */     async = false;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean isAsync() {
/*  66: 66 */     return async;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setAsync(boolean async) {
/*  70: 70 */     this.async = async;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Class<D> getDocumentType()
/*  74:    */   {
/*  75: 75 */     return documentType;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Id getItemId()
/*  79:    */   {
/*  80: 80 */     return itemId;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public JComponent getView(IProcDocumentView<? extends IProcDocument> host, IProcDocument document)
/*  84:    */   {
/*  85: 85 */     Preconditions.checkArgument(getDocumentType().isInstance(document), "Invalid document type");
/*  86: 86 */     D source = (IProcDocument)getDocumentType().cast(document);
/*  87: 87 */     Object info = informationExtractor.retrieve(source);
/*  88: 88 */     if (info == null)
/*  89: 89 */       return host.getToolkit().getMessageViewer("No information for this item");
/*  90: 90 */     return async ? new AsyncView(host, source) : itemUI.getView(host, info);
/*  91:    */   }
/*  92:    */   
/*  93:    */   @Nonnull
/*  94:    */   public InformationExtractor<? super D, ?> getInformationExtractor() {
/*  95: 95 */     return informationExtractor;
/*  96:    */   }
/*  97:    */   
/*  98:    */   @Nonnull
/*  99:    */   public ItemUI getItemUI() {
/* 100:100 */     return itemUI;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private final class AsyncView extends JComponent
/* 104:    */   {
/* 105:    */     public AsyncView(final D host) {
/* 106:106 */       setLayout(new BorderLayout());
/* 107:107 */       add(newLoadingComponent(), "Center");
/* 108:    */       
/* 109:109 */       new SwingWorker()
/* 110:    */       {
/* 111:    */         protected Object doInBackground() throws Exception {
/* 112:112 */           return informationExtractor.retrieve(source);
/* 113:    */         }
/* 114:    */         
/* 115:    */         protected void done()
/* 116:    */         {
/* 117:    */           try {
/* 118:118 */             ComposedProcDocumentItemFactory.AsyncView.this.switchToComponent(itemUI.getView(host, get()));
/* 119:    */           } catch (InterruptedException|ExecutionException ex) {
/* 120:120 */             Thread.currentThread().interrupt();
/* 121:121 */             ComposedProcDocumentItemFactory.AsyncView.this.switchToComponent(ExceptionPanel.create(ex));
/* 122:    */           }
/* 123:    */         }
/* 124:    */       }.execute();
/* 125:    */     }
/* 126:    */     
/* 127:    */     private JComponent newLoadingComponent() {
/* 128:128 */       JLabel result = new JLabel();
/* 129:129 */       result.setHorizontalAlignment(0);
/* 130:130 */       result.setFont(result.getFont().deriveFont(result.getFont().getSize2D() * 2.0F));
/* 131:131 */       result.setText("<html><center>Loading");
/* 132:132 */       return result;
/* 133:    */     }
/* 134:    */     
/* 135:    */     private void switchToComponent(Component c) {
/* 136:136 */       removeAll();
/* 137:137 */       if (c != null) {
/* 138:138 */         add(c, "Center");
/* 139:139 */         validate();
/* 140:140 */         invalidate();
/* 141:141 */         repaint();
/* 142:142 */         c.setSize(getSize());
/* 143:    */       }
/* 144:    */     }
/* 145:    */   }
/* 146:    */ }
