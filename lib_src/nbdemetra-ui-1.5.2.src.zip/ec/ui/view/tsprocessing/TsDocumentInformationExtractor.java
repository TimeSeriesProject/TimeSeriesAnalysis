/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.documents.TsDocument;
/*  4:   */ import ec.tstoolkit.utilities.InformationExtractor;
/*  5:   */ import java.util.HashMap;
/*  6:   */ import java.util.Objects;
/*  7:   */ import java.util.concurrent.atomic.AtomicInteger;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public abstract class TsDocumentInformationExtractor<D extends TsDocument, I>
/* 17:   */   implements InformationExtractor<D, I>
/* 18:   */ {
/* 19:19 */   private static final AtomicInteger gid_ = new AtomicInteger(0);
/* 20:   */   private final int id_;
/* 21:   */   
/* 22:   */   protected TsDocumentInformationExtractor()
/* 23:   */   {
/* 24:24 */     id_ = gid_.incrementAndGet();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public I retrieve(D source)
/* 28:   */   {
/* 29:29 */     String doc = source.getDocumentId();
/* 30:30 */     Key key = new Key(doc, id_);
/* 31:31 */     I info = null;
/* 32:32 */     synchronized (cache_) {
/* 33:33 */       info = cache_.get(key);
/* 34:34 */       if (info == null) {
/* 35:35 */         info = buildInfo(source);
/* 36:36 */         cache_.put(key, info);
/* 37:   */       }
/* 38:   */     }
/* 39:39 */     return info;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void flush(D source)
/* 43:   */   {
/* 44:44 */     String doc = source.getDocumentId();
/* 45:45 */     synchronized (cache_) {
/* 46:46 */       cache_.remove(new Key(doc, id_));
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */ 
/* 51:51 */   private static final HashMap<Key, Object> cache_ = new HashMap();
/* 52:   */   
/* 53:   */   protected abstract I buildInfo(D paramD);
/* 54:   */   
/* 55:   */   private static class Key implements Comparable<Key> {
/* 56:56 */     Key(String doc, int id) { this.doc = doc;
/* 57:57 */       this.id = id;
/* 58:   */     }
/* 59:   */     
/* 60:   */ 
/* 61:   */     String doc;
/* 62:   */     int id;
/* 63:   */     public int compareTo(Key o)
/* 64:   */     {
/* 65:65 */       if (id == id)
/* 66:66 */         return doc.compareTo(doc);
/* 67:67 */       if (id < id) {
/* 68:68 */         return -1;
/* 69:   */       }
/* 70:70 */       return 1;
/* 71:   */     }
/* 72:   */     
/* 73:   */     public boolean equals(Object obj)
/* 74:   */     {
/* 75:75 */       return (this == obj) || (((obj instanceof Key)) && (equals((Key)obj)));
/* 76:   */     }
/* 77:   */     
/* 78:   */     private boolean equals(Key other) {
/* 79:79 */       return (id == id) && (doc.equals(doc));
/* 80:   */     }
/* 81:   */     
/* 82:   */     public int hashCode()
/* 83:   */     {
/* 84:84 */       int hash = 3;
/* 85:85 */       hash = 89 * hash + Objects.hashCode(doc);
/* 86:86 */       hash = 89 * hash + id;
/* 87:87 */       return hash;
/* 88:   */     }
/* 89:   */   }
/* 90:   */ }
