/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Throwables;
/*  4:   */ import ec.tstoolkit.utilities.IPool;
/*  5:   */ import ec.tstoolkit.utilities.IPool.Factory;
/*  6:   */ import ec.tstoolkit.utilities.Pools;
/*  7:   */ import ec.ui.Disposables;
/*  8:   */ import java.awt.Component;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public abstract class PooledItemUI<H, I, C extends JComponent>
/* 15:   */   extends DefaultItemUI<H, I>
/* 16:   */   implements IPool.Factory<C>
/* 17:   */ {
/* 18:   */   final Class<? extends C> clazz;
/* 19:   */   final IPool<C> pool;
/* 20:   */   
/* 21:   */   public PooledItemUI(Class<? extends C> clazz)
/* 22:   */   {
/* 23:23 */     this.clazz = clazz;
/* 24:24 */     pool = Pools.on(this, 10);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public JComponent getView(H host, I information)
/* 28:   */   {
/* 29:29 */     final C result = (JComponent)pool.getOrCreate();
/* 30:30 */     init(result, host, information);
/* 31:   */     
/* 32:32 */     new TsViewToolkit.JDisposable(result)
/* 33:   */     {
/* 34:   */       public void dispose() {
/* 35:35 */         pool.recycle(result);
/* 36:   */       }
/* 37:   */     };
/* 38:   */   }
/* 39:   */   
/* 40:   */   public C create()
/* 41:   */   {
/* 42:   */     try {
/* 43:43 */       return (JComponent)clazz.newInstance();
/* 44:   */     } catch (InstantiationException|IllegalAccessException ex) {
/* 45:45 */       throw Throwables.propagate(ex);
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */ 
/* 50:   */ 
/* 51:   */   public void reset(C o) {}
/* 52:   */   
/* 53:   */ 
/* 54:   */   public void destroy(C o)
/* 55:   */   {
/* 56:56 */     Disposables.dispose(o);
/* 57:   */   }
/* 58:   */   
/* 59:   */   protected abstract void init(C paramC, H paramH, I paramI);
/* 60:   */ }
