/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.documents.DocumentManager;
/*  5:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  6:   */ import ec.tstoolkit.algorithm.IProcResults;
/*  7:   */ import java.util.ArrayList;
/*  8:   */ import java.util.Arrays;
/*  9:   */ import java.util.List;
/* 10:   */ import javax.swing.JComponent;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class GenericGrowthChartUI<D extends IProcDocument<?, ?, ?>>
/* 19:   */   extends DefaultItemUI<IProcDocumentView<D>, IProcResults>
/* 20:   */ {
/* 21:   */   private final List<String> names_;
/* 22:   */   private final boolean full_;
/* 23:   */   
/* 24:   */   public GenericGrowthChartUI(boolean fullNames, String... names)
/* 25:   */   {
/* 26:26 */     names_ = Arrays.asList(names);
/* 27:27 */     full_ = fullNames;
/* 28:   */   }
/* 29:   */   
/* 30:   */ 
/* 31:   */ 
/* 32:   */   public JComponent getView(IProcDocumentView<D> host, IProcResults rslts)
/* 33:   */   {
/* 34:34 */     List<Ts> items = new ArrayList();
/* 35:35 */     for (String s : names_) {
/* 36:36 */       Ts x = DocumentManager.instance.getTs(host.getDocument(), s, full_);
/* 37:37 */       if ((x != null) && (x.getTsData() != null))
/* 38:38 */         items.add(x);
/* 39:   */     }
/* 40:40 */     return host.getToolkit().getChart(items);
/* 41:   */   }
/* 42:   */ }
