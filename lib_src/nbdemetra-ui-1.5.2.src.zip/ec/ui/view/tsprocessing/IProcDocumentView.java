package ec.ui.view.tsprocessing;

import ec.tstoolkit.algorithm.IProcDocument;
import ec.tstoolkit.utilities.Id;
import ec.ui.interfaces.IDisposable;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JComponent;

public abstract interface IProcDocumentView<D extends IProcDocument>
  extends IDisposable
{
  @Nonnull
  public abstract D getDocument();
  
  @Nonnull
  public abstract ITsViewToolkit getToolkit();
  
  @Nonnull
  public abstract List<Id> getItems();
  
  @Nullable
  public abstract JComponent getView(Id paramId);
  
  @Nullable
  public abstract Icon getIcon(Id paramId);
  
  @Nullable
  public abstract Action[] getActions(Id paramId);
  
  @Nullable
  public abstract Id getPreferredView();
  
  public abstract void refresh();
}
