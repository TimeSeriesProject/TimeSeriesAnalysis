/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlRegArima;
/*  5:   */ import ec.tstoolkit.modelling.arima.PreprocessingModel;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class PreprocessingUI<V extends IProcDocumentView<?>>
/* 15:   */   extends HtmlItemUI<V, PreprocessingModel>
/* 16:   */ {
/* 17:   */   protected IHtmlElement getHtmlElement(V host, PreprocessingModel information)
/* 18:   */   {
/* 19:19 */     return new HtmlRegArima(information, false);
/* 20:   */   }
/* 21:   */ }
