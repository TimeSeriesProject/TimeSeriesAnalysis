/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  5:   */ import ec.ui.view.res.ResDistributionView;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class ResidualsDistUI<V extends IProcDocumentView<?>>
/* 15:   */   extends DefaultItemUI<V, TsData>
/* 16:   */ {
/* 17:   */   public JComponent getView(V host, TsData information)
/* 18:   */   {
/* 19:19 */     ResDistributionView resdistView = new ResDistributionView();
/* 20:20 */     if (information != null) {
/* 21:21 */       int n = information.getFrequency().intValue();
/* 22:22 */       resdistView.setAutocorrelationsCount(Math.max(8, n * 3));
/* 23:23 */       resdistView.setData(information.getValues());
/* 24:   */     } else {
/* 25:25 */       resdistView.reset(); }
/* 26:26 */     return resdistView;
/* 27:   */   }
/* 28:   */ }
