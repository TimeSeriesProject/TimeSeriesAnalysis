/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbComponents;
/*  4:   */ import ec.tss.Ts;
/*  5:   */ import ec.tss.TsCollection;
/*  6:   */ import ec.tss.TsFactory;
/*  7:   */ import ec.tss.html.implementation.HtmlTsDifferenceDocument;
/*  8:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  9:   */ import ec.ui.Disposables;
/* 10:   */ import ec.ui.chart.JTsChart;
/* 11:   */ import ec.ui.grid.JTsGrid;
/* 12:   */ import ec.ui.interfaces.IDisposable;
/* 13:   */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/* 14:   */ import java.awt.BorderLayout;
/* 15:   */ import java.util.ArrayList;
/* 16:   */ import javax.swing.Box;
/* 17:   */ import javax.swing.JComponent;
/* 18:   */ import javax.swing.JSplitPane;
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public class BenchmarkingView
/* 26:   */   extends JComponent
/* 27:   */   implements IDisposable
/* 28:   */ {
/* 29:   */   private final JTsGrid grid_;
/* 30:   */   private final JTsChart chart_;
/* 31:   */   private final JTsChart dchart_;
/* 32:   */   private final Box documentPanel_;
/* 33:33 */   private ITsViewToolkit toolkit_ = TsViewToolkit.getInstance();
/* 34:   */   
/* 35:   */   public BenchmarkingView() {
/* 36:36 */     setLayout(new BorderLayout());
/* 37:   */     
/* 38:38 */     grid_ = new JTsGrid();
/* 39:39 */     grid_.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 40:40 */     chart_ = new JTsChart();
/* 41:41 */     chart_.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 42:42 */     dchart_ = new JTsChart();
/* 43:43 */     documentPanel_ = Box.createHorizontalBox();
/* 44:   */     
/* 45:45 */     JSplitPane splitpane1 = NbComponents.newJSplitPane(0, true, chart_, dchart_);
/* 46:46 */     splitpane1.setDividerLocation(0.7D);
/* 47:47 */     splitpane1.setResizeWeight(0.3D);
/* 48:   */     
/* 49:49 */     JSplitPane splitpane2 = NbComponents.newJSplitPane(0, true, grid_, documentPanel_);
/* 50:50 */     splitpane2.setDividerLocation(0.7D);
/* 51:51 */     splitpane2.setResizeWeight(0.3D);
/* 52:   */     
/* 53:53 */     JSplitPane splitpane3 = NbComponents.newJSplitPane(1, true, splitpane1, splitpane2);
/* 54:54 */     splitpane3.setDividerLocation(0.5D);
/* 55:55 */     splitpane3.setResizeWeight(0.5D);
/* 56:   */     
/* 57:   */ 
/* 58:58 */     add(splitpane3, "Center");
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setTsToolkit(ITsViewToolkit toolkit) {
/* 62:62 */     toolkit_ = toolkit;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public ITsViewToolkit getTsToolkit() {
/* 66:66 */     return toolkit_;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void set(Ts benchSa, Ts sa, boolean mul) {
/* 70:70 */     ArrayList<Ts> all = new ArrayList();
/* 71:71 */     all.add(sa);
/* 72:72 */     all.add(benchSa);
/* 73:73 */     chart_.getTsCollection().replace(all);
/* 74:74 */     TsData sdiff = mul ? TsData.divide(benchSa.getTsData(), sa.getTsData()).minus(1.0D) : 
/* 75:75 */       TsData.subtract(benchSa.getTsData(), sa.getTsData());
/* 76:76 */     Ts diff = TsFactory.instance.createTs("Differences");
/* 77:77 */     diff.set(sdiff);
/* 78:78 */     dchart_.getTsCollection().replace(diff);
/* 79:79 */     all.add(diff);
/* 80:80 */     grid_.getTsCollection().replace(all);
/* 81:   */     
/* 82:82 */     HtmlTsDifferenceDocument document = new HtmlTsDifferenceDocument(benchSa, sa, mul);
/* 83:83 */     ((Box)Disposables.disposeAndRemoveAll(documentPanel_)).add(toolkit_.getHtmlViewer(document));
/* 84:84 */     chart_.updateUI();
/* 85:85 */     dchart_.updateUI();
/* 86:   */   }
/* 87:   */   
/* 88:   */   public void dispose()
/* 89:   */   {
/* 90:90 */     grid_.dispose();
/* 91:91 */     chart_.dispose();
/* 92:92 */     dchart_.dispose();
/* 93:   */   }
/* 94:   */ }
