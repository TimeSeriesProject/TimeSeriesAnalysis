/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import ec.tss.documents.TsDocument;
/*   4:    */ import ec.tstoolkit.algorithm.IProcSpecification;
/*   5:    */ import ec.tstoolkit.arima.IArimaModel;
/*   6:    */ import ec.tstoolkit.modelling.ModellingDictionary;
/*   7:    */ import ec.tstoolkit.modelling.arima.ModelDescription;
/*   8:    */ import ec.tstoolkit.modelling.arima.ModelEstimation;
/*   9:    */ import ec.tstoolkit.modelling.arima.PreprocessingModel;
/*  10:    */ import ec.tstoolkit.modelling.arima.diagnostics.IOneStepAheadForecastingTest;
/*  11:    */ import ec.tstoolkit.modelling.arima.diagnostics.OneStepAheadForecastingTest;
/*  12:    */ import ec.tstoolkit.sarima.SarimaComponent;
/*  13:    */ import ec.tstoolkit.sarima.SarimaModel;
/*  14:    */ import ec.tstoolkit.stats.NiidTests;
/*  15:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*  16:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  17:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  18:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  19:    */ import ec.tstoolkit.utilities.DefaultInformationExtractor;
/*  20:    */ import ec.tstoolkit.utilities.Id;
/*  21:    */ import ec.tstoolkit.utilities.InformationExtractor;
/*  22:    */ import ec.tstoolkit.utilities.LinearId;
/*  23:    */ import ec.ui.view.tsprocessing.sa.SaTableUI;
/*  24:    */ import java.util.LinkedHashMap;
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ public abstract class PreprocessingViewFactory<S extends IProcSpecification, D extends TsDocument<S, PreprocessingModel>>
/*  30:    */   extends ProcDocumentViewFactory<D>
/*  31:    */ {
/*  32:    */   public static final String MAIN = "Main results";
/*  33:    */   public static final String PREPROCESSING = "Pre-processing";
/*  34:    */   public static final String MODEL = "Model";
/*  35:    */   public static final String DECOMPOSITION = "Decomposition";
/*  36:    */   public static final String BENCHMARKING = "Benchmarking";
/*  37:    */   public static final String DIAGNOSTICS = "Diagnostics";
/*  38:    */   public static final String PROCESSING = "Processing";
/*  39:    */   public static final String FCASTS = "Forecasts";
/*  40:    */   public static final String OSAMPLE = "Out-of-sample test";
/*  41:    */   public static final String DETAILS = "Details";
/*  42:    */   public static final String STEPS = "Steps";
/*  43:    */   public static final String PREADJUSTMENT = "Pre-adjustment series";
/*  44:    */   public static final String ARIMA = "Arima";
/*  45:    */   public static final String REGRESSORS = "Regressors";
/*  46:    */   public static final String RESIDUALS = "Residuals";
/*  47:    */   public static final String STATS = "Statistics";
/*  48:    */   public static final String DISTRIBUTION = "Distribution";
/*  49:    */   public static final String SPECTRAL = "Spectral analysis";
/*  50:    */   public static final String REVISIONS = "Revisions analysis";
/*  51:    */   public static final String SLIDINGSPANS = "Sliding spans";
/*  52:    */   public static final String STABILITY = "Model stability";
/*  53: 53 */   public static final Id MODEL_SUMMARY = new LinearId("Model");
/*  54: 54 */   public static final Id MODEL_DET = new LinearId("Model", "Pre-adjustment series");
/*  55: 55 */   public static final Id MODEL_FCASTS = new LinearId("Model", "Forecasts");
/*  56: 56 */   public static final Id MODEL_FCASTS_OUTOFSAMPLE = new LinearId(new String[] { "Model", "Forecasts", "Out-of-sample test" });
/*  57: 57 */   public static final Id MODEL_REGS = new LinearId("Model", "Regressors");
/*  58: 58 */   public static final Id MODEL_ARIMA = new LinearId("Model", "Arima");
/*  59: 59 */   public static final Id MODEL_RES = new LinearId("Model", "Residuals");
/*  60: 60 */   public static final Id MODEL_RES_STATS = new LinearId(new String[] { "Model", "Residuals", "Statistics" });
/*  61: 61 */   public static final Id MODEL_RES_DIST = new LinearId(new String[] { "Model", "Residuals", "Distribution" });
/*  62: 62 */   public static final Id MODEL_RES_SPECTRUM = new LinearId(new String[] { "Model", "Residuals", "Spectral analysis" });
/*  63: 63 */   public static final Id PROCESSING_DETAILS = new LinearId("Processing", "Details");
/*  64: 64 */   public static final Id PROCESSING_STEPS = new LinearId("Processing", "Steps");
/*  65: 65 */   public static final Id PREPROCESSING_SUMMARY = new LinearId("Pre-processing");
/*  66: 66 */   public static final Id PREPROCESSING_FCASTS = new LinearId("Pre-processing", "Forecasts");
/*  67: 67 */   public static final Id PREPROCESSING_FCASTS_OUTOFSAMPLE = new LinearId(new String[] { "Pre-processing", "Forecasts", "Out-of-sample test" });
/*  68: 68 */   public static final Id PREPROCESSING_DETAILS = new LinearId("Pre-processing", "Details");
/*  69: 69 */   public static final Id PREPROCESSING_REGS = new LinearId("Pre-processing", "Regressors");
/*  70: 70 */   public static final Id PREPROCESSING_ARIMA = new LinearId("Pre-processing", "Arima");
/*  71: 71 */   public static final Id PREPROCESSING_DET = new LinearId("Pre-processing", "Pre-adjustment series");
/*  72: 72 */   public static final Id PREPROCESSING_RES = new LinearId("Pre-processing", "Residuals");
/*  73: 73 */   public static final Id PREPROCESSING_RES_STATS = new LinearId(new String[] { "Pre-processing", "Residuals", "Statistics" });
/*  74: 74 */   public static final Id PREPROCESSING_RES_DIST = new LinearId(new String[] { "Pre-processing", "Residuals", "Distribution" });
/*  75:    */   
/*  76:    */   @Deprecated
/*  77:    */   public void registerDefault() {
/*  78: 78 */     registerSummary();
/*  79: 79 */     registerForecasts();
/*  80: 80 */     registerModel();
/*  81: 81 */     registerResiduals();
/*  82: 82 */     registerDetails();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Id getPreferredView()
/*  86:    */   {
/*  87: 87 */     return MODEL_SUMMARY;
/*  88:    */   }
/*  89:    */   
/*  90:    */   @Deprecated
/*  91:    */   public void registerSummary() {}
/*  92:    */   
/*  93:    */   @Deprecated
/*  94:    */   public void registerForecasts() {}
/*  95:    */   
/*  96:    */   public static class SummaryFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>> extends PreprocessingViewFactory.ItemFactory<D, PreprocessingModel>
/*  97:    */   {
/*  98:    */     protected SummaryFactory(Class<D> documentType) {
/*  99: 99 */       super(PreprocessingViewFactory.MODEL_SUMMARY, PreprocessingViewFactory.PmExtractor.INSTANCE, new PreprocessingUI());
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */   public static class ModelFCastsFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>>
/* 121:    */     extends PreprocessingViewFactory.ItemFactory<D, EstimationUI.Information>
/* 122:    */   {
/* 123:    */     protected ModelFCastsFactory(Class<D> documentType)
/* 124:    */     {
/* 125:125 */       super(PreprocessingViewFactory.MODEL_FCASTS, new DefaultInformationExtractor()new EstimationUI
/* 126:    */       {
/* 127:    */         public EstimationUI.Information retrieve(D source)
/* 128:    */         {
/* 129:116 */           PreprocessingModel model = (PreprocessingModel)source.getResults();
/* 130:117 */           TsData orig = description.getOriginal();
/* 131:118 */           TsPeriodSelector sel = new TsPeriodSelector();
/* 132:119 */           sel.last(3 * orig.getFrequency().intValue());
/* 133:120 */           return new EstimationUI.Information(orig.select(sel), 
/* 134:121 */             (TsData)model.getData("y_f", TsData.class), 
/* 135:122 */             (TsData)model.getData("y_ef", TsData.class), 
/* 136:123 */             1.96D);
/* 137:    */         }
/* 138:125 */       }, new EstimationUI());
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */   @Deprecated
/* 147:    */   public void registerModel() {}
/* 148:    */   
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */   @Deprecated
/* 154:    */   public void registerResiduals() {}
/* 155:    */   
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */   @Deprecated
/* 160:    */   public void registerDetails() {}
/* 161:    */   
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */   public static class ModelFCastsOutFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>>
/* 166:    */     extends PreprocessingViewFactory.ItemFactory<D, IOneStepAheadForecastingTest>
/* 167:    */   {
/* 168:    */     protected ModelFCastsOutFactory(Class<D> documentType)
/* 169:    */     {
/* 170:157 */       super(PreprocessingViewFactory.MODEL_FCASTS_OUTOFSAMPLE, new DefaultInformationExtractor()new OutOfSampleTestUI
/* 171:    */       {
/* 172:    */         public IOneStepAheadForecastingTest retrieve(D source)
/* 173:    */         {
/* 174:136 */           PreprocessingModel model = (PreprocessingModel)source.getResults();
/* 175:    */           
/* 176:138 */           TsFrequency freq = description.getSeriesDomain().getFrequency();
/* 177:139 */           int lback; int lback; int lback; int lback; switch (freq) {
/* 178:    */           case Yearly: 
/* 179:141 */             lback = 18;
/* 180:142 */             break;
/* 181:    */           case Quarterly: 
/* 182:144 */             lback = 6;
/* 183:145 */             break;
/* 184:    */           case Undefined: 
/* 185:147 */             lback = 9;
/* 186:148 */             break;
/* 187:    */           default: 
/* 188:150 */             lback = 5;
/* 189:    */           }
/* 190:    */           
/* 191:153 */           OneStepAheadForecastingTest test = new OneStepAheadForecastingTest(lback);
/* 192:154 */           test.test(estimation.getRegArima());
/* 193:155 */           return test;
/* 194:    */         }
/* 195:157 */       }, new OutOfSampleTestUI());
/* 196:    */     }
/* 197:    */   }
/* 198:    */   
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */   public static class ModelRegsFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>>
/* 205:    */     extends PreprocessingViewFactory.ItemFactory<D, PreprocessingModel>
/* 206:    */   {
/* 207:    */     protected ModelRegsFactory(Class<D> documentType)
/* 208:    */     {
/* 209:171 */       super(PreprocessingViewFactory.MODEL_REGS, PreprocessingViewFactory.PmExtractor.INSTANCE, new RegressorsUI());
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */   public static class ModelArimaFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>>
/* 221:    */     extends PreprocessingViewFactory.ItemFactory<D, LinkedHashMap<String, IArimaModel>>
/* 222:    */   {
/* 223:    */     protected ModelArimaFactory(Class<D> documentType)
/* 224:    */     {
/* 225:187 */       super(PreprocessingViewFactory.MODEL_ARIMA, new DefaultInformationExtractor()new ArimaUI
/* 226:    */       {
/* 227:    */         public LinkedHashMap<String, IArimaModel> retrieve(D source)
/* 228:    */         {
/* 229:182 */           LinkedHashMap<String, IArimaModel> models = new LinkedHashMap();
/* 230:183 */           SarimaModel model = getResults()estimation.getArima();
/* 231:184 */           models.put("Arima model", model);
/* 232:185 */           return models;
/* 233:    */         }
/* 234:187 */       }, new ArimaUI());
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */   public static class ModelResFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>>
/* 244:    */     extends PreprocessingViewFactory.ItemFactory<D, TsData>
/* 245:    */   {
/* 246:    */     protected ModelResFactory(Class<D> documentType)
/* 247:    */     {
/* 248:201 */       super(PreprocessingViewFactory.MODEL_RES, PreprocessingViewFactory.ResExtractor.INSTANCE, new ResidualsUI());
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:    */ 
/* 259:    */   public static class ModelResStatsFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>>
/* 260:    */     extends PreprocessingViewFactory.ItemFactory<D, NiidTests>
/* 261:    */   {
/* 262:    */     protected ModelResStatsFactory(Class<D> documentType)
/* 263:    */     {
/* 264:217 */       super(PreprocessingViewFactory.MODEL_RES_STATS, new DefaultInformationExtractor()new ResidualsStatsUI
/* 265:    */       {
/* 266:    */         public NiidTests retrieve(D source)
/* 267:    */         {
/* 268:212 */           PreprocessingModel rslt = (PreprocessingModel)source.getResults();
/* 269:213 */           TsData res = rslt.getFullResiduals();
/* 270:214 */           return new NiidTests(res.getValues(), res.getFrequency().intValue(), 
/* 271:215 */             description.getArimaComponent().getFreeParametersCount(), true);
/* 272:    */         }
/* 273:217 */       }, new ResidualsStatsUI());
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   public static class ModelResDist<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>> extends PreprocessingViewFactory.ItemFactory<D, TsData>
/* 278:    */   {
/* 279:    */     protected ModelResDist(Class<D> documentType)
/* 280:    */     {
/* 281:225 */       super(PreprocessingViewFactory.MODEL_RES, PreprocessingViewFactory.ResExtractor.INSTANCE, new ResidualsDistUI());
/* 282:    */     }
/* 283:    */   }
/* 284:    */   
/* 285:    */   public static class ModelResSpectrum<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>> extends PreprocessingViewFactory.ItemFactory<D, TsData>
/* 286:    */   {
/* 287:    */     protected ModelResSpectrum(Class<D> documentType)
/* 288:    */     {
/* 289:233 */       super(PreprocessingViewFactory.MODEL_RES, PreprocessingViewFactory.ResExtractor.INSTANCE, new SpectrumUI(true));
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */   private static class ItemFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>, I>
/* 299:    */     extends ComposedProcDocumentItemFactory<D, I>
/* 300:    */   {
/* 301:    */     public ItemFactory(Class<D> documentType, Id itemId, InformationExtractor<? super D, I> informationExtractor, ItemUI<? extends IProcDocumentView<D>, I> itemUI)
/* 302:    */     {
/* 303:247 */       super(itemId, informationExtractor, itemUI);
/* 304:    */     }
/* 305:    */   }
/* 306:    */   
/* 307:    */   protected static class PmExtractor extends DefaultInformationExtractor<TsDocument<? extends IProcSpecification, PreprocessingModel>, PreprocessingModel>
/* 308:    */   {
/* 309:253 */     static final PmExtractor INSTANCE = new PmExtractor();
/* 310:    */     
/* 311:    */     public PreprocessingModel retrieve(TsDocument<? extends IProcSpecification, PreprocessingModel> source)
/* 312:    */     {
/* 313:257 */       return (PreprocessingModel)source.getResults();
/* 314:    */     }
/* 315:    */   }
/* 316:    */   
/* 317:    */   protected static class ResExtractor extends DefaultInformationExtractor<TsDocument<? extends IProcSpecification, PreprocessingModel>, TsData>
/* 318:    */   {
/* 319:263 */     static final ResExtractor INSTANCE = new ResExtractor();
/* 320:    */     
/* 321:    */     public TsData retrieve(TsDocument<? extends IProcSpecification, PreprocessingModel> source)
/* 322:    */     {
/* 323:267 */       return ((PreprocessingModel)source.getResults()).getFullResiduals();
/* 324:    */     }
/* 325:    */   }
/* 326:    */   
/* 327:    */   protected static class PreprocessingDetFactory<D extends TsDocument<? extends IProcSpecification, PreprocessingModel>> extends PreprocessingViewFactory.ItemFactory<D, PreprocessingModel>
/* 328:    */   {
/* 329:    */     protected PreprocessingDetFactory(Class<D> documentType)
/* 330:    */     {
/* 331:275 */       super(PreprocessingViewFactory.MODEL_DET, PreprocessingViewFactory.PmExtractor.INSTANCE, new SaTableUI(ModellingDictionary.getDeterministicSeries(), null));
/* 332:    */     }
/* 333:    */   }
/* 334:    */ }
