/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import ec.tss.modelling.documents.TramoDocument;
/*   4:    */ import ec.tstoolkit.modelling.arima.tramo.TramoSpecification;
/*   5:    */ import java.util.concurrent.atomic.AtomicReference;
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ public class TramoViewFactory
/*  16:    */   extends PreprocessingViewFactory<TramoSpecification, TramoDocument>
/*  17:    */ {
/*  18: 18 */   private static final AtomicReference<IProcDocumentViewFactory<TramoDocument>> INSTANCE = new AtomicReference(new TramoViewFactory());
/*  19:    */   
/*  20:    */   public static IProcDocumentViewFactory<TramoDocument> getDefault() {
/*  21: 21 */     return (IProcDocumentViewFactory)INSTANCE.get();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static void setDefault(IProcDocumentViewFactory<TramoDocument> factory) {
/*  25: 25 */     INSTANCE.set(factory);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public TramoViewFactory() {
/*  29: 29 */     registerDefault();
/*  30: 30 */     registerFromLookup(TramoDocument.class);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static class SummaryFactory
/*  34:    */     extends PreprocessingViewFactory.SummaryFactory<TramoDocument>
/*  35:    */   {
/*  36:    */     public SummaryFactory()
/*  37:    */     {
/*  38: 38 */       super();
/*  39:    */     }
/*  40:    */   }
/*  41:    */   
/*  42:    */ 
/*  43:    */   public static class ModelFCastsFactory
/*  44:    */     extends PreprocessingViewFactory.ModelFCastsFactory<TramoDocument>
/*  45:    */   {
/*  46:    */     public ModelFCastsFactory()
/*  47:    */     {
/*  48: 48 */       super();
/*  49:    */     }
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static class ModelFCastsOutFactory extends PreprocessingViewFactory.ModelFCastsOutFactory<TramoDocument>
/*  53:    */   {
/*  54:    */     public ModelFCastsOutFactory()
/*  55:    */     {
/*  56: 56 */       super();
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */ 
/*  61:    */   public static class ModelRegsFactory
/*  62:    */     extends PreprocessingViewFactory.ModelRegsFactory<TramoDocument>
/*  63:    */   {
/*  64:    */     public ModelRegsFactory()
/*  65:    */     {
/*  66: 66 */       super();
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static class ModelArimaFactory extends PreprocessingViewFactory.ModelArimaFactory<TramoDocument>
/*  71:    */   {
/*  72:    */     public ModelArimaFactory()
/*  73:    */     {
/*  74: 74 */       super();
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static class PreprocessingDetFactory extends PreprocessingViewFactory.PreprocessingDetFactory<TramoDocument>
/*  79:    */   {
/*  80:    */     public PreprocessingDetFactory()
/*  81:    */     {
/*  82: 82 */       super();
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */ 
/*  87:    */   public static class ModelResFactory
/*  88:    */     extends PreprocessingViewFactory.ModelResFactory<TramoDocument>
/*  89:    */   {
/*  90:    */     public ModelResFactory()
/*  91:    */     {
/*  92: 92 */       super();
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static class ModelResStatsFactory extends PreprocessingViewFactory.ModelResStatsFactory<TramoDocument>
/*  97:    */   {
/*  98:    */     public ModelResStatsFactory()
/*  99:    */     {
/* 100:100 */       super();
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static class ModelResDist extends PreprocessingViewFactory.ModelResDist<TramoDocument>
/* 105:    */   {
/* 106:    */     public ModelResDist()
/* 107:    */     {
/* 108:108 */       super();
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static class ModelResSpectrum extends PreprocessingViewFactory.ModelResSpectrum<TramoDocument>
/* 113:    */   {
/* 114:    */     public ModelResSpectrum()
/* 115:    */     {
/* 116:116 */       super();
/* 117:    */     }
/* 118:    */   }
/* 119:    */ }
