package ec.ui.view.tsprocessing;

import ec.tss.Ts;
import ec.tss.html.IHtmlElement;
import javax.swing.JComponent;

public abstract interface ITsViewToolkit
{
  public abstract JComponent getGrid(Ts paramTs);
  
  public abstract JComponent getGrid(Iterable<Ts> paramIterable);
  
  public abstract JComponent getChart(Iterable<Ts> paramIterable);
  
  public abstract JComponent getGrowthChart(Iterable<Ts> paramIterable);
  
  public abstract JComponent getHtmlViewer(IHtmlElement paramIHtmlElement);
  
  public abstract JComponent getMessageViewer(String paramString);
}
