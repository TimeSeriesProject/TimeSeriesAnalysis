/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public abstract class HtmlItemUI<H extends IProcDocumentView<?>, I>
/* 14:   */   extends DefaultItemUI<H, I>
/* 15:   */ {
/* 16:   */   public JComponent getView(H host, I information)
/* 17:   */   {
/* 18:18 */     return host.getToolkit().getHtmlViewer(getHtmlElement(host, information));
/* 19:   */   }
/* 20:   */   
/* 21:   */   protected abstract IHtmlElement getHtmlElement(H paramH, I paramI);
/* 22:   */ }
