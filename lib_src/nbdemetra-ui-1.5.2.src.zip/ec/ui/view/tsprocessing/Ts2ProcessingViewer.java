/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.MonikerUI;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsMoniker;
/*   6:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   7:    */ import ec.tss.documents.MultiTsDocument;
/*   8:    */ import ec.tstoolkit.algorithm.IProcSpecification;
/*   9:    */ import java.awt.Font;
/*  10:    */ import javax.swing.Box;
/*  11:    */ import javax.swing.JLabel;
/*  12:    */ import javax.swing.JToolBar;
/*  13:    */ import javax.swing.JToolBar.Separator;
/*  14:    */ import javax.swing.TransferHandler;
/*  15:    */ import javax.swing.TransferHandler.TransferSupport;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ public class Ts2ProcessingViewer
/*  23:    */   extends DefaultProcessingViewer<MultiTsDocument>
/*  24:    */ {
/*  25:    */   public static Ts2ProcessingViewer create(MultiTsDocument doc, String y, String z)
/*  26:    */   {
/*  27: 27 */     Ts2ProcessingViewer viewer = new Ts2ProcessingViewer(DefaultProcessingViewer.Type.APPLY, y, z);
/*  28: 28 */     if (doc != null) {
/*  29: 29 */       viewer.setDocument(doc);
/*  30:    */     }
/*  31: 31 */     return viewer;
/*  32:    */   }
/*  33:    */   
/*  34:    */ 
/*  35: 35 */   private static final Font DROP_DATA_FONT = new JLabel().getFont().deriveFont(2);
/*  36:    */   private final JLabel dropDataLabely;
/*  37:    */   private final JLabel dropDataLabelz;
/*  38:    */   private final JLabel tsLabely;
/*  39:    */   private final JLabel tsLabelz;
/*  40:    */   private final JLabel specLabel;
/*  41:    */   
/*  42: 42 */   public Ts2ProcessingViewer(DefaultProcessingViewer.Type type, String y, String z) { super(type);
/*  43: 43 */     dropDataLabely = new JLabel("Drop " + y + " here");
/*  44: 44 */     dropDataLabelz = new JLabel("Drop " + z + " here");
/*  45: 45 */     dropDataLabely.setFont(DROP_DATA_FONT);
/*  46: 46 */     dropDataLabelz.setFont(DROP_DATA_FONT);
/*  47: 47 */     tsLabely = new JLabel(y);
/*  48: 48 */     tsLabely.setVisible(false);
/*  49: 49 */     tsLabelz = new JLabel(z);
/*  50: 50 */     tsLabelz.setVisible(false);
/*  51: 51 */     specLabel = new JLabel("Spec: ");
/*  52: 52 */     specLabel.setVisible(false);
/*  53:    */     
/*  54: 54 */     toolBar.add(Box.createHorizontalStrut(3), 0);
/*  55: 55 */     toolBar.add(dropDataLabely, 1);
/*  56: 56 */     toolBar.add(tsLabely, 2);
/*  57: 57 */     toolBar.add(new JToolBar.Separator(), 3);
/*  58: 58 */     toolBar.add(dropDataLabelz, 4);
/*  59: 59 */     toolBar.add(tsLabelz, 5);
/*  60: 60 */     toolBar.add(new JToolBar.Separator(), 6);
/*  61: 61 */     toolBar.add(specLabel, 7);
/*  62:    */     
/*  63: 63 */     TsHandler hy = new TsHandler(0);
/*  64: 64 */     TsHandler hz = new TsHandler(1);
/*  65: 65 */     tsLabely.setTransferHandler(hy);
/*  66: 66 */     dropDataLabely.setTransferHandler(hy);
/*  67: 67 */     tsLabelz.setTransferHandler(hz);
/*  68: 68 */     dropDataLabelz.setTransferHandler(hz);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void refreshHeader()
/*  72:    */   {
/*  73: 73 */     MultiTsDocument doc = (MultiTsDocument)getDocument();
/*  74: 74 */     if (doc == null) {
/*  75: 75 */       return;
/*  76:    */     }
/*  77: 77 */     Ts[] input = (Ts[])doc.getInput();
/*  78: 78 */     if ((input == null) || (input[0] == null)) {
/*  79: 79 */       dropDataLabely.setVisible(true);
/*  80: 80 */       tsLabely.setVisible(false);
/*  81:    */     } else {
/*  82: 82 */       dropDataLabely.setVisible(false);
/*  83: 83 */       TsMoniker monikery = input[0].getMoniker();
/*  84: 84 */       tsLabely.setIcon(MonikerUI.getDefault().getIcon(input[0]));
/*  85: 85 */       tsLabely.setToolTipText(tsLabely.getText() + (monikery.getSource() != null ? " (" + monikery.getSource() + ")" : ""));
/*  86: 86 */       tsLabely.setVisible(true);
/*  87:    */     }
/*  88: 88 */     if ((input == null) || (input[1] == null)) {
/*  89: 89 */       dropDataLabelz.setVisible(true);
/*  90: 90 */       tsLabelz.setVisible(false);
/*  91:    */     } else {
/*  92: 92 */       dropDataLabelz.setVisible(false);
/*  93: 93 */       TsMoniker monikerz = input[1].getMoniker();
/*  94: 94 */       tsLabelz.setIcon(MonikerUI.getDefault().getIcon(input[1]));
/*  95: 95 */       tsLabelz.setToolTipText(tsLabelz.getText() + (monikerz.getSource() != null ? " (" + monikerz.getSource() + ")" : ""));
/*  96: 96 */       tsLabelz.setVisible(true);
/*  97:    */     }
/*  98: 98 */     if (input != null) {
/*  99: 99 */       IProcSpecification spec = doc.getSpecification();
/* 100:100 */       specLabel.setText("Spec: " + (spec != null ? spec.toString() : ""));
/* 101:101 */       specLabel.setVisible(true);
/* 102:    */     } else {
/* 103:103 */       specLabel.setVisible(false);
/* 104:    */     }
/* 105:105 */     toolBar.doLayout();
/* 106:    */   }
/* 107:    */   
/* 108:    */   class TsHandler extends TransferHandler
/* 109:    */   {
/* 110:    */     private final int pos;
/* 111:    */     
/* 112:    */     TsHandler(int pos)
/* 113:    */     {
/* 114:114 */       this.pos = pos;
/* 115:    */     }
/* 116:    */     
/* 117:    */     public boolean canImport(TransferHandler.TransferSupport support)
/* 118:    */     {
/* 119:119 */       return TssTransferSupport.getDefault().canImport(support.getDataFlavors());
/* 120:    */     }
/* 121:    */     
/* 122:    */     public boolean importData(TransferHandler.TransferSupport support)
/* 123:    */     {
/* 124:124 */       Ts ts = TssTransferSupport.getDefault().toTs(support.getTransferable());
/* 125:125 */       if (ts != null) {
/* 126:126 */         Ts[] input = (Ts[])((MultiTsDocument)getDocument()).getInput();
/* 127:127 */         if (input == null) {
/* 128:128 */           input = new Ts[2];
/* 129:    */         } else
/* 130:130 */           input = (Ts[])input.clone();
/* 131:131 */         input[pos] = ts;
/* 132:132 */         ((MultiTsDocument)getDocument()).setInput(input);
/* 133:133 */         refreshAll();
/* 134:134 */         return true;
/* 135:    */       }
/* 136:136 */       return false;
/* 137:    */     }
/* 138:    */   }
/* 139:    */ }
