package ec.ui.view.tsprocessing;

import ec.tstoolkit.algorithm.IProcDocument;
import ec.tstoolkit.utilities.Id;
import ec.tstoolkit.utilities.InformationExtractor;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public abstract interface IProcDocumentViewFactory<D extends IProcDocument>
{
  @Nonnull
  public abstract IProcDocumentView<D> create(@Nonnull D paramD);
  
  @Deprecated
  public abstract <I> void register(@Nonnull Id paramId, @Nullable InformationExtractor<? super D, I> paramInformationExtractor, @Nonnull ItemUI<? extends IProcDocumentView<D>, I> paramItemUI);
  
  @Deprecated
  public abstract void unregister(@Nonnull Id paramId);
}
