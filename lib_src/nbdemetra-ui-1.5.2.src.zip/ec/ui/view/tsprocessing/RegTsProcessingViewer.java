/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ObjectArrays;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.documents.MultiTsDocument;
/*   7:    */ import ec.tstoolkit.algorithm.IProcSpecification;
/*   8:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*   9:    */ import ec.ui.interfaces.ITsList.InfoType;
/*  10:    */ import ec.ui.list.JTsList;
/*  11:    */ import java.awt.Dimension;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.beans.PropertyChangeListener;
/*  14:    */ import java.util.Arrays;
/*  15:    */ import javax.swing.Box;
/*  16:    */ import javax.swing.JLabel;
/*  17:    */ import javax.swing.JToolBar;
/*  18:    */ import javax.swing.JToolBar.Separator;
/*  19:    */ 
/*  20:    */ public class RegTsProcessingViewer
/*  21:    */   extends DefaultProcessingViewer<MultiTsDocument>
/*  22:    */ {
/*  23:    */   private final JTsList yList;
/*  24:    */   private final JTsList xList;
/*  25:    */   private final JLabel specLabel;
/*  26:    */   private boolean quietRefresh;
/*  27:    */   
/*  28:    */   public static RegTsProcessingViewer create(MultiTsDocument doc)
/*  29:    */   {
/*  30: 30 */     RegTsProcessingViewer viewer = new RegTsProcessingViewer(DefaultProcessingViewer.Type.APPLY);
/*  31: 31 */     if (doc != null) {
/*  32: 32 */       viewer.setDocument(doc);
/*  33:    */     }
/*  34: 34 */     return viewer;
/*  35:    */   }
/*  36:    */   
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */   public RegTsProcessingViewer(DefaultProcessingViewer.Type type)
/*  41:    */   {
/*  42: 42 */     super(type);
/*  43: 43 */     yList = new JTsList();
/*  44: 44 */     yList.setVisible(true);
/*  45: 45 */     yList.setShowHeader(false);
/*  46: 46 */     yList.setTsUpdateMode(ITsCollectionView.TsUpdateMode.Single);
/*  47: 47 */     yList.setInformation(new ITsList.InfoType[] { ITsList.InfoType.Name });
/*  48: 48 */     xList = new JTsList();
/*  49: 49 */     yList.setVisible(true);
/*  50: 50 */     xList.setShowHeader(false);
/*  51: 51 */     xList.setInformation(new ITsList.InfoType[] { ITsList.InfoType.Name });
/*  52: 52 */     specLabel = new JLabel("Spec: ");
/*  53: 53 */     specLabel.setVisible(true);
/*  54: 54 */     xList.setPreferredSize(new Dimension(50, 60));
/*  55: 55 */     yList.setPreferredSize(new Dimension(50, 60));
/*  56:    */     
/*  57: 57 */     toolBar.add(Box.createHorizontalStrut(3), 0);
/*  58: 58 */     toolBar.add(new JLabel("Y: "), 1);
/*  59: 59 */     toolBar.add(new JToolBar.Separator(), 2);
/*  60: 60 */     toolBar.add(yList, 3);
/*  61: 61 */     toolBar.add(new JToolBar.Separator(), 4);
/*  62: 62 */     toolBar.add(new JLabel("X: "), 5);
/*  63: 63 */     toolBar.add(new JToolBar.Separator(), 6);
/*  64: 64 */     toolBar.add(xList, 7);
/*  65: 65 */     toolBar.add(new JToolBar.Separator(), 8);
/*  66: 66 */     toolBar.add(specLabel, 9);
/*  67: 67 */     toolBar.add(new JToolBar.Separator(), 10);
/*  68: 68 */     toolBar.add(Box.createHorizontalStrut(100), 11);
/*  69:    */     
/*  70: 70 */     toolBar.setVisible(true);
/*  71:    */     
/*  72: 72 */     xList.addPropertyChangeListener("tsCollection", new PropertyChangeListener()
/*  73:    */     {
/*  74:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  75: 75 */         if (!quietRefresh) {
/*  76: 76 */           RegTsProcessingViewer.this.updateDocument();
/*  77:    */         }
/*  78:    */       }
/*  79: 79 */     });
/*  80: 80 */     yList.addPropertyChangeListener("tsCollection", new PropertyChangeListener()
/*  81:    */     {
/*  82:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  83: 83 */         if (!quietRefresh) {
/*  84: 84 */           RegTsProcessingViewer.this.updateDocument();
/*  85:    */         }
/*  86:    */       }
/*  87:    */     });
/*  88:    */   }
/*  89:    */   
/*  90:    */   private void updateDocument()
/*  91:    */   {
/*  92:    */     try {
/*  93: 93 */       quietRefresh = true;
/*  94: 94 */       Ts[] y = yList.getTsCollection().toArray();
/*  95: 95 */       if ((y == null) || (y.length == 0)) {
/*  96: 96 */         ((MultiTsDocument)getDocument()).setInput(null);
/*  97:    */       }
/*  98: 98 */       Ts[] x = xList.getTsCollection().toArray();
/*  99: 99 */       if ((x == null) || (x.length == 0)) {
/* 100:100 */         ((MultiTsDocument)getDocument()).setInput(y);
/* 101:    */       } else {
/* 102:102 */         ((MultiTsDocument)getDocument()).setInput((Ts[])ObjectArrays.concat(y[0], x));
/* 103:    */       }
/* 104:104 */       refreshAll();
/* 105:    */     }
/* 106:    */     catch (Exception localException) {}finally {
/* 107:107 */       quietRefresh = false;
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   private void updateList() {
/* 112:112 */     Ts[] s = ((MultiTsDocument)getDocument()).getTs();
/* 113:113 */     if ((s == null) || (s.length == 0)) {
/* 114:114 */       yList.getTsCollection().clear();
/* 115:115 */       xList.getTsCollection().clear();
/* 116:    */     } else {
/* 117:117 */       yList.getTsCollection().replace(s[0]);
/* 118:118 */       xList.getTsCollection().replace((Ts[])Arrays.copyOfRange(s, 1, s.length));
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void refreshSpec() {
/* 123:123 */     MultiTsDocument doc = (MultiTsDocument)getDocument();
/* 124:124 */     IProcSpecification spec = doc.getSpecification();
/* 125:125 */     specLabel.setText("Spec: " + (spec != null ? spec.toString() : ""));
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void refreshHeader()
/* 129:    */   {
/* 130:    */     try {
/* 131:131 */       if (quietRefresh) {
/* 132:132 */         return;
/* 133:    */       }
/* 134:134 */       refreshSpec();
/* 135:135 */       updateList();
/* 136:    */     }
/* 137:    */     catch (Exception localException) {}
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void refreshView()
/* 141:    */   {
/* 142:142 */     super.refreshView();
/* 143:143 */     refreshSpec();
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void dispose()
/* 147:    */   {
/* 148:148 */     super.dispose();
/* 149:149 */     yList.dispose();
/* 150:150 */     xList.dispose();
/* 151:    */   }
/* 152:    */ }
