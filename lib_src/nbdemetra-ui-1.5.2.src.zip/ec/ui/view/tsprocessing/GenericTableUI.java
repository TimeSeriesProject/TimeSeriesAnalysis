/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.TsStatus;
/*  5:   */ import ec.tss.documents.DocumentManager;
/*  6:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  7:   */ import ec.tstoolkit.algorithm.IProcResults;
/*  8:   */ import java.util.ArrayList;
/*  9:   */ import java.util.Arrays;
/* 10:   */ import java.util.List;
/* 11:   */ import javax.swing.JComponent;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class GenericTableUI<D extends IProcDocument<?, ?, ?>>
/* 20:   */   extends DefaultItemUI<IProcDocumentView<D>, IProcResults>
/* 21:   */ {
/* 22:   */   private final List<String> names_;
/* 23:   */   private final boolean full_;
/* 24:   */   
/* 25:   */   public GenericTableUI(boolean fullNames, String... names)
/* 26:   */   {
/* 27:27 */     names_ = Arrays.asList(names);
/* 28:28 */     full_ = fullNames;
/* 29:   */   }
/* 30:   */   
/* 31:   */ 
/* 32:   */ 
/* 33:   */   public JComponent getView(IProcDocumentView<D> host, IProcResults rslts)
/* 34:   */   {
/* 35:35 */     List<Ts> items = new ArrayList();
/* 36:36 */     for (String s : names_) {
/* 37:37 */       Ts x = DocumentManager.instance.getTs(host.getDocument(), s, full_);
/* 38:38 */       if ((x != null) && (x.hasData() == TsStatus.Valid))
/* 39:39 */         items.add(x);
/* 40:   */     }
/* 41:41 */     return host.getToolkit().getGrid(items);
/* 42:   */   }
/* 43:   */ }
