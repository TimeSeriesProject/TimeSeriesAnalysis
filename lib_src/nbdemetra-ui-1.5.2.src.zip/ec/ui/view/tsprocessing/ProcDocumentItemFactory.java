/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  4:   */ import ec.tstoolkit.utilities.Id;
/*  5:   */ import javax.annotation.Nonnull;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ import javax.swing.Action;
/*  8:   */ import javax.swing.Icon;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public abstract class ProcDocumentItemFactory
/* 20:   */ {
/* 21:   */   @Nonnull
/* 22:   */   public abstract Class<? extends IProcDocument> getDocumentType();
/* 23:   */   
/* 24:   */   @Nonnull
/* 25:   */   public abstract Id getItemId();
/* 26:   */   
/* 27:   */   @Nonnull
/* 28:   */   public abstract JComponent getView(@Nonnull IProcDocumentView<? extends IProcDocument> paramIProcDocumentView, @Nonnull IProcDocument paramIProcDocument)
/* 29:   */     throws IllegalArgumentException;
/* 30:   */   
/* 31:   */   @Nullable
/* 32:   */   public Icon getIcon()
/* 33:   */   {
/* 34:34 */     return null;
/* 35:   */   }
/* 36:   */   
/* 37:   */   @Nullable
/* 38:   */   public Action[] getActions() {
/* 39:39 */     return null;
/* 40:   */   }
/* 41:   */ }
