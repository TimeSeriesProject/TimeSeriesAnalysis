/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import javax.swing.Icon;
/*  4:   */ import javax.swing.JMenu;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public abstract class DefaultItemUI<H, I>
/* 14:   */   implements ItemUI<H, I>
/* 15:   */ {
/* 16:   */   public boolean fillMenu(JMenu menu, H host, I information)
/* 17:   */   {
/* 18:18 */     return false;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Icon getIcon(H host, I information)
/* 22:   */   {
/* 23:23 */     return null;
/* 24:   */   }
/* 25:   */ }
