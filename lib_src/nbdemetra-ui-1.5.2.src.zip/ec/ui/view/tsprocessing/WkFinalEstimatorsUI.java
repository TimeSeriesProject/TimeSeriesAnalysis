/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.ui.view.wk.FinalEstimatorsView;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class WkFinalEstimatorsUI<V extends IProcDocumentView<?>>
/* 15:   */   extends DefaultItemUI<V, WkInformation>
/* 16:   */ {
/* 17:   */   public JComponent getView(V host, WkInformation information)
/* 18:   */   {
/* 19:19 */     return new FinalEstimatorsView(estimators, descriptors, frequency);
/* 20:   */   }
/* 21:   */ }
