/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import ec.tss.html.IHtmlElement;
/*   4:    */ import ec.tss.html.implementation.HtmlX13Preprocessing;
/*   5:    */ import ec.tss.modelling.documents.RegArimaDocument;
/*   6:    */ import ec.tstoolkit.modelling.arima.PreprocessingModel;
/*   7:    */ import ec.tstoolkit.modelling.arima.x13.RegArimaSpecification;
/*   8:    */ import ec.tstoolkit.utilities.Id;
/*   9:    */ import ec.tstoolkit.utilities.InformationExtractor;
/*  10:    */ import java.util.concurrent.atomic.AtomicReference;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ public class RegArimaViewFactory
/*  22:    */   extends PreprocessingViewFactory<RegArimaSpecification, RegArimaDocument>
/*  23:    */ {
/*  24: 24 */   private static final AtomicReference<IProcDocumentViewFactory<RegArimaDocument>> INSTANCE = new AtomicReference(new RegArimaViewFactory());
/*  25:    */   
/*  26:    */   public static IProcDocumentViewFactory<RegArimaDocument> getDefault() {
/*  27: 27 */     return (IProcDocumentViewFactory)INSTANCE.get();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void setDefault(IProcDocumentViewFactory<RegArimaDocument> factory) {
/*  31: 31 */     INSTANCE.set(factory);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public RegArimaViewFactory() {
/*  35: 35 */     registerDefault();
/*  36: 36 */     registerFromLookup(RegArimaDocument.class);
/*  37:    */   }
/*  38:    */   
/*  39:    */   @Deprecated
/*  40:    */   public void registerDetails() {}
/*  41:    */   
/*  42:    */   public static class SummaryFactory extends PreprocessingViewFactory.SummaryFactory<RegArimaDocument> {
/*  43:    */     public SummaryFactory() {
/*  44: 44 */       super();
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */ 
/*  49:    */   public static class ModelFCastsFactory
/*  50:    */     extends PreprocessingViewFactory.ModelFCastsFactory<RegArimaDocument>
/*  51:    */   {
/*  52:    */     public ModelFCastsFactory()
/*  53:    */     {
/*  54: 54 */       super();
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static class ModelFCastsOutFactory extends PreprocessingViewFactory.ModelFCastsOutFactory<RegArimaDocument>
/*  59:    */   {
/*  60:    */     public ModelFCastsOutFactory()
/*  61:    */     {
/*  62: 62 */       super();
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */ 
/*  67:    */   public static class ModelRegsFactory
/*  68:    */     extends PreprocessingViewFactory.ModelRegsFactory<RegArimaDocument>
/*  69:    */   {
/*  70:    */     public ModelRegsFactory()
/*  71:    */     {
/*  72: 72 */       super();
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static class ModelArimaFactory extends PreprocessingViewFactory.ModelArimaFactory<RegArimaDocument>
/*  77:    */   {
/*  78:    */     public ModelArimaFactory()
/*  79:    */     {
/*  80: 80 */       super();
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static class PreprocessingDetFactory extends PreprocessingViewFactory.PreprocessingDetFactory<RegArimaDocument>
/*  85:    */   {
/*  86:    */     public PreprocessingDetFactory()
/*  87:    */     {
/*  88: 88 */       super();
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */   public static class ModelResFactory
/*  94:    */     extends PreprocessingViewFactory.ModelResFactory<RegArimaDocument>
/*  95:    */   {
/*  96:    */     public ModelResFactory()
/*  97:    */     {
/*  98: 98 */       super();
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static class ModelResStatsFactory extends PreprocessingViewFactory.ModelResStatsFactory<RegArimaDocument>
/* 103:    */   {
/* 104:    */     public ModelResStatsFactory()
/* 105:    */     {
/* 106:106 */       super();
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static class ModelResDist extends PreprocessingViewFactory.ModelResDist<RegArimaDocument>
/* 111:    */   {
/* 112:    */     public ModelResDist()
/* 113:    */     {
/* 114:114 */       super();
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static class ModelResSpectrum extends PreprocessingViewFactory.ModelResSpectrum<RegArimaDocument>
/* 119:    */   {
/* 120:    */     public ModelResSpectrum()
/* 121:    */     {
/* 122:122 */       super();
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */   public static class ProcessingDetailsFactory
/* 133:    */     extends RegArimaViewFactory.ItemFactory<PreprocessingModel>
/* 134:    */   {
/* 135:    */     public ProcessingDetailsFactory()
/* 136:    */     {
/* 137:137 */       super(PreprocessingViewFactory.PmExtractor.INSTANCE, new HtmlItemUI()
/* 138:    */       {
/* 139:    */         protected IHtmlElement getHtmlElement(ProcDocumentViewFactory<RegArimaDocument>.View host, PreprocessingModel information) {
/* 140:140 */           return new HtmlX13Preprocessing(information);
/* 141:    */         }
/* 142:    */       });
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   private static class ItemFactory<I> extends ComposedProcDocumentItemFactory<RegArimaDocument, I>
/* 147:    */   {
/* 148:    */     public ItemFactory(Id itemId, InformationExtractor<? super RegArimaDocument, I> informationExtractor, ItemUI<? extends IProcDocumentView<RegArimaDocument>, I> itemUI)
/* 149:    */     {
/* 150:150 */       super(itemId, informationExtractor, itemUI);
/* 151:    */     }
/* 152:    */   }
/* 153:    */ }
