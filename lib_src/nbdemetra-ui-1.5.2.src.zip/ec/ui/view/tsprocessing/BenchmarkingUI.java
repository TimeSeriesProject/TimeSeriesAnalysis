/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.documents.DocumentManager;
/*  5:   */ import ec.tstoolkit.information.InformationSet;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class BenchmarkingUI<V extends IProcDocumentView<?>>
/* 18:   */   extends DefaultItemUI<V, Boolean>
/* 19:   */ {
/* 20:   */   public JComponent getView(V host, Boolean information)
/* 21:   */   {
/* 22:22 */     if (information == null) {
/* 23:23 */       return null;
/* 24:   */     }
/* 25:25 */     BenchmarkingView view = new BenchmarkingView();
/* 26:26 */     view.setTsToolkit(host.getToolkit());
/* 27:27 */     Ts tsb = DocumentManager.instance.getTs(host.getDocument(), InformationSet.item("benchmarking", "result"));
/* 28:28 */     Ts tsa = DocumentManager.instance.getTs(host.getDocument(), InformationSet.item("benchmarking", "original"));
/* 29:   */     
/* 30:30 */     if ((tsb == null) || (tsa == null))
/* 31:31 */       return null;
/* 32:32 */     view.set(tsb, tsa, information.booleanValue());
/* 33:33 */     return view;
/* 34:   */   }
/* 35:   */ }
