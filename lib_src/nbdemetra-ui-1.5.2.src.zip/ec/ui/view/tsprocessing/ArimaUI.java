/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.arima.IArimaModel;
/*  4:   */ import ec.ui.view.ArimaView;
/*  5:   */ import java.util.LinkedHashMap;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class ArimaUI<V extends IProcDocumentView<?>>
/* 16:   */   extends DefaultItemUI<V, LinkedHashMap<String, IArimaModel>>
/* 17:   */ {
/* 18:   */   public JComponent getView(V host, LinkedHashMap<String, IArimaModel> information)
/* 19:   */   {
/* 20:20 */     ArimaView arimaView = new ArimaView(information);
/* 21:21 */     return arimaView;
/* 22:   */   }
/* 23:   */ }
