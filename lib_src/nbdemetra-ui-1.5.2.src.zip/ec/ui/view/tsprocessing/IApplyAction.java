package ec.ui.view.tsprocessing;

@Deprecated
public abstract interface IApplyAction
{
  public abstract void apply();
  
  public abstract String getActionName();
}
