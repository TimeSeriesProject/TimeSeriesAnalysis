/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tss.documents.DocumentManager;
/*  5:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  6:   */ import ec.tstoolkit.algorithm.IProcResults;
/*  7:   */ import ec.tstoolkit.modelling.SeriesInfo;
/*  8:   */ import java.util.Arrays;
/*  9:   */ import java.util.List;
/* 10:   */ import javax.swing.JComponent;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class ChartUI<D extends IProcDocument<?, ?, ?>>
/* 20:   */   extends DefaultItemUI<IProcDocumentView<D>, IProcResults>
/* 21:   */ {
/* 22:   */   private final List<SeriesInfo> items_;
/* 23:   */   private final String prefix_;
/* 24:   */   private final List<String> names_;
/* 25:25 */   private boolean clean_ = true;
/* 26:   */   
/* 27:   */   public ChartUI(List<SeriesInfo> items, String prefix) {
/* 28:28 */     items_ = items;
/* 29:29 */     names_ = null;
/* 30:30 */     prefix_ = prefix;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public ChartUI(String... names) {
/* 34:34 */     names_ = Arrays.asList(names);
/* 35:35 */     items_ = null;
/* 36:36 */     prefix_ = null;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public boolean isClean() {
/* 40:40 */     return clean_;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setClean(boolean clean) {
/* 44:44 */     clean_ = clean;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public JComponent getView(IProcDocumentView<D> host, IProcResults document)
/* 48:   */   {
/* 49:   */     TsCollection items;
/* 50:   */     TsCollection items;
/* 51:51 */     if (items_ != null) {
/* 52:52 */       items = DocumentManager.create(items_, host.getDocument(), prefix_, false);
/* 53:   */     } else {
/* 54:54 */       items = DocumentManager.create(names_, host.getDocument());
/* 55:   */     }
/* 56:56 */     if (clean_) {
/* 57:57 */       items = items.clean(true);
/* 58:   */     }
/* 59:59 */     return host.getToolkit().getChart(items);
/* 60:   */   }
/* 61:   */ }
