/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlNiidTest;
/*  5:   */ import ec.tstoolkit.stats.NiidTests;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class ResidualsStatsUI<V extends IProcDocumentView<?>>
/* 15:   */   extends HtmlItemUI<V, NiidTests>
/* 16:   */ {
/* 17:   */   protected IHtmlElement getHtmlElement(V host, NiidTests information)
/* 18:   */   {
/* 19:19 */     return new HtmlNiidTest(information);
/* 20:   */   }
/* 21:   */ }
