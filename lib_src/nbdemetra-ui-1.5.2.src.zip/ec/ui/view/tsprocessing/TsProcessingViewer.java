/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.MonikerUI;
/*  4:   */ import ec.tss.Ts;
/*  5:   */ import ec.tss.TsMoniker;
/*  6:   */ import ec.tss.datatransfer.TssTransferSupport;
/*  7:   */ import ec.tss.documents.TsDocument;
/*  8:   */ import ec.tstoolkit.algorithm.IProcSpecification;
/*  9:   */ import java.awt.Font;
/* 10:   */ import javax.swing.Box;
/* 11:   */ import javax.swing.JLabel;
/* 12:   */ import javax.swing.JToolBar;
/* 13:   */ import javax.swing.JToolBar.Separator;
/* 14:   */ import javax.swing.TransferHandler;
/* 15:   */ import javax.swing.TransferHandler.TransferSupport;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class TsProcessingViewer
/* 23:   */   extends DefaultProcessingViewer<TsDocument>
/* 24:   */ {
/* 25:   */   public static TsProcessingViewer create(TsDocument doc)
/* 26:   */   {
/* 27:27 */     TsProcessingViewer viewer = new TsProcessingViewer(DefaultProcessingViewer.Type.APPLY);
/* 28:28 */     if (doc != null) {
/* 29:29 */       viewer.setDocument(doc);
/* 30:   */     }
/* 31:31 */     return viewer;
/* 32:   */   }
/* 33:   */   
/* 34:   */ 
/* 35:35 */   private static final Font DROP_DATA_FONT = new JLabel().getFont().deriveFont(2);
/* 36:   */   private final JLabel dropDataLabel;
/* 37:   */   private final JLabel tsLabel;
/* 38:   */   private final JLabel specLabel;
/* 39:   */   
/* 40:   */   public TsProcessingViewer(DefaultProcessingViewer.Type type)
/* 41:   */   {
/* 42:42 */     super(type);
/* 43:43 */     dropDataLabel = new JLabel("Drop data here");
/* 44:44 */     dropDataLabel.setFont(DROP_DATA_FONT);
/* 45:45 */     tsLabel = new JLabel();
/* 46:46 */     tsLabel.setVisible(false);
/* 47:47 */     specLabel = new JLabel("Spec: ");
/* 48:48 */     specLabel.setVisible(false);
/* 49:   */     
/* 50:50 */     toolBar.add(Box.createHorizontalStrut(3), 0);
/* 51:51 */     toolBar.add(dropDataLabel, 1);
/* 52:52 */     toolBar.add(tsLabel, 2);
/* 53:53 */     toolBar.add(new JToolBar.Separator(), 3);
/* 54:54 */     toolBar.add(specLabel, 4);
/* 55:   */     
/* 56:56 */     setTransferHandler(new TsHandler());
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void refreshHeader()
/* 60:   */   {
/* 61:61 */     TsDocument doc = (TsDocument)getDocument();
/* 62:62 */     if ((doc == null) || (doc.getTs() == null)) {
/* 63:63 */       dropDataLabel.setVisible(true);
/* 64:64 */       tsLabel.setVisible(false);
/* 65:65 */       specLabel.setVisible(false);
/* 66:   */     } else {
/* 67:67 */       dropDataLabel.setVisible(false);
/* 68:68 */       tsLabel.setText(doc.getTs().getName());
/* 69:69 */       TsMoniker moniker = doc.getMoniker();
/* 70:70 */       tsLabel.setIcon(MonikerUI.getDefault().getIcon(doc.getTs()));
/* 71:71 */       tsLabel.setToolTipText(tsLabel.getText() + (moniker.getSource() != null ? " (" + moniker.getSource() + ")" : ""));
/* 72:72 */       tsLabel.setVisible(true);
/* 73:73 */       IProcSpecification spec = doc.getSpecification();
/* 74:74 */       specLabel.setText("Spec: " + (spec != null ? spec.toString() : ""));
/* 75:75 */       specLabel.setVisible(true);
/* 76:   */     }
/* 77:   */   }
/* 78:   */   
/* 79:   */   class TsHandler extends TransferHandler {
/* 80:   */     TsHandler() {}
/* 81:   */     
/* 82:   */     public boolean canImport(TransferHandler.TransferSupport support) {
/* 83:83 */       return TssTransferSupport.getDefault().canImport(support.getDataFlavors());
/* 84:   */     }
/* 85:   */     
/* 86:   */     public boolean importData(TransferHandler.TransferSupport support)
/* 87:   */     {
/* 88:88 */       Ts ts = TssTransferSupport.getDefault().toTs(support.getTransferable());
/* 89:89 */       if (ts != null) {
/* 90:90 */         ((TsDocument)getDocument()).setTs(ts);
/* 91:91 */         refreshAll();
/* 92:92 */         return true;
/* 93:   */       }
/* 94:94 */       return false;
/* 95:   */     }
/* 96:   */   }
/* 97:   */ }
