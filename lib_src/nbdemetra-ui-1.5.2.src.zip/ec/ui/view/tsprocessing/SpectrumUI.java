/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class SpectrumUI<V extends IProcDocumentView<?>>
/* 14:   */   extends DefaultItemUI<V, TsData>
/* 15:   */ {
/* 16:   */   private boolean wn_;
/* 17:   */   
/* 18:   */   public SpectrumUI(boolean wn)
/* 19:   */   {
/* 20:20 */     wn_ = wn;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public JComponent getView(V host, TsData information)
/* 24:   */   {
/* 25:25 */     return TsViewToolkit.getInstance().getSpectralView(information, wn_);
/* 26:   */   }
/* 27:   */ }
