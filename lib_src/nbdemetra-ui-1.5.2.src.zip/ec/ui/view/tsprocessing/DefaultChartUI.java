/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class DefaultChartUI<D extends IProcDocument<?, ?, ?>>
/* 21:   */   extends DefaultItemUI<IProcDocumentView<D>, TsCollection>
/* 22:   */ {
/* 23:   */   public JComponent getView(IProcDocumentView<D> host, TsCollection rslts)
/* 24:   */   {
/* 25:25 */     return host.getToolkit().getGrid(rslts);
/* 26:   */   }
/* 27:   */ }
