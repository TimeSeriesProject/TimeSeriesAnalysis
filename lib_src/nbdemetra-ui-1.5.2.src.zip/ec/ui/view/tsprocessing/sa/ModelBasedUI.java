/*  1:   */ package ec.ui.view.tsprocessing.sa;
/*  2:   */ 
/*  3:   */ import ec.satoolkit.ISeriesDecomposition;
/*  4:   */ import ec.tss.html.IHtmlElement;
/*  5:   */ import ec.tss.html.implementation.HtmlWienerKolmogorovDiagnostics;
/*  6:   */ import ec.tstoolkit.data.Values;
/*  7:   */ import ec.tstoolkit.modelling.ComponentInformation;
/*  8:   */ import ec.tstoolkit.modelling.ComponentType;
/*  9:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/* 10:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/* 11:   */ import ec.tstoolkit.ucarima.UcarimaModel;
/* 12:   */ import ec.tstoolkit.ucarima.WienerKolmogorovDiagnostics;
/* 13:   */ import ec.ui.view.tsprocessing.HtmlItemUI;
/* 14:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class ModelBasedUI<V extends IProcDocumentView<?>>
/* 22:   */   extends HtmlItemUI<V, Information>
/* 23:   */ {
/* 24:   */   protected IHtmlElement getHtmlElement(V host, Information information)
/* 25:   */   {
/* 26:26 */     ISeriesDecomposition decomposition = decomposition;
/* 27:27 */     UcarimaModel ucm = ucm;
/* 28:28 */     if (ucm.getComponentsCount() > 3) {
/* 29:29 */       ucm = ucm.clone();
/* 30:30 */       ucm.compact(2, 2);
/* 31:   */     }
/* 32:32 */     String[] desc = { "Trend", "Seasonally adjusted", "Seasonal", "Irregular" };
/* 33:33 */     int[] cmps = { 1, -2, 2, 3 };
/* 34:34 */     boolean[] signals = { true, false, true, true };
/* 35:35 */     double err = err;
/* 36:36 */     TsData t = decomposition.getSeries(ComponentType.Trend, ComponentInformation.Value);
/* 37:37 */     TsData s = decomposition.getSeries(ComponentType.Seasonal, ComponentInformation.Value);
/* 38:38 */     TsData i = decomposition.getSeries(ComponentType.Irregular, ComponentInformation.Value);
/* 39:39 */     TsData sa = decomposition.getSeries(ComponentType.SeasonallyAdjusted, ComponentInformation.Value);
/* 40:   */     
/* 41:41 */     double[][] data = {
/* 42:42 */       t == null ? null : t.getValues().internalStorage(), 
/* 43:43 */       sa == null ? null : sa.getValues().internalStorage(), 
/* 44:44 */       s == null ? null : s.getValues().internalStorage(), 
/* 45:45 */       i == null ? null : i.getValues().internalStorage() };
/* 46:   */     
/* 47:   */ 
/* 48:48 */     WienerKolmogorovDiagnostics diags = WienerKolmogorovDiagnostics.make(ucm, err, data, cmps);
/* 49:49 */     if (diags == null) {
/* 50:50 */       return null;
/* 51:   */     }
/* 52:52 */     return new HtmlWienerKolmogorovDiagnostics(diags, desc, signals, t.getFrequency().intValue());
/* 53:   */   }
/* 54:   */   
/* 55:   */   public static class Information
/* 56:   */   {
/* 57:   */     public ISeriesDecomposition decomposition;
/* 58:   */     public UcarimaModel ucm;
/* 59:   */     public double err;
/* 60:   */   }
/* 61:   */ }
