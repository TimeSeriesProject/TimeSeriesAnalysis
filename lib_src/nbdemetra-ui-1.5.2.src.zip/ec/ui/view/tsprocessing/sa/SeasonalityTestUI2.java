/*  1:   */ package ec.ui.view.tsprocessing.sa;
/*  2:   */ 
/*  3:   */ import ec.tss.html.HtmlElements;
/*  4:   */ import ec.tss.html.HtmlHeader;
/*  5:   */ import ec.tss.html.IHtmlElement;
/*  6:   */ import ec.tss.html.implementation.HtmlSeasonalityDiagnostics;
/*  7:   */ import ec.tstoolkit.modelling.arima.tramo.SeasonalityTests;
/*  8:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  9:   */ import ec.ui.view.tsprocessing.HtmlItemUI;
/* 10:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class SeasonalityTestUI2<V extends IProcDocumentView<?>>
/* 19:   */   extends HtmlItemUI<V, Information>
/* 20:   */ {
/* 21:   */   private final String header;
/* 22:   */   private final boolean seasControl;
/* 23:   */   
/* 24:   */   public SeasonalityTestUI2(String header, boolean seasControl)
/* 25:   */   {
/* 26:26 */     this.header = header;
/* 27:27 */     this.seasControl = seasControl;
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected IHtmlElement getHtmlElement(V host, Information information)
/* 31:   */   {
/* 32:32 */     TsData s = s;
/* 33:33 */     if (mul) {
/* 34:34 */       s = s.log();
/* 35:   */     }
/* 36:36 */     if (header == null) {
/* 37:37 */       return new HtmlSeasonalityDiagnostics(SeasonalityTests.seasonalityTest(s, del, mean, true));
/* 38:   */     }
/* 39:39 */     return new HtmlElements(new IHtmlElement[] { new HtmlHeader(1, header, true), 
/* 40:40 */       new HtmlSeasonalityDiagnostics(SeasonalityTests.seasonalityTest(s, del, mean, true), seasControl) });
/* 41:   */   }
/* 42:   */   
/* 43:   */ 
/* 44:   */   public static class Information
/* 45:   */   {
/* 46:   */     public TsData s;
/* 47:   */     public int del;
/* 48:48 */     public boolean mean = true;
/* 49:   */     public boolean mul;
/* 50:   */   }
/* 51:   */ }
