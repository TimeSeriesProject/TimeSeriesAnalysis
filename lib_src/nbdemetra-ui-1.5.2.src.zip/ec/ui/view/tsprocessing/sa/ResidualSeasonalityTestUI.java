/*  1:   */ package ec.ui.view.tsprocessing.sa;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlResidualSeasonalityTest;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  6:   */ import ec.ui.view.tsprocessing.HtmlItemUI;
/*  7:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ public class ResidualSeasonalityTestUI<V extends IProcDocumentView<?>>
/* 33:   */   extends HtmlItemUI<V, TsData>
/* 34:   */ {
/* 35:   */   protected IHtmlElement getHtmlElement(V host, TsData sa)
/* 36:   */   {
/* 37:37 */     return new HtmlResidualSeasonalityTest(sa);
/* 38:   */   }
/* 39:   */ }
