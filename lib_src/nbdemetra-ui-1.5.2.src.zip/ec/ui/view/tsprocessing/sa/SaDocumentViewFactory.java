/*   1:    */ package ec.ui.view.tsprocessing.sa;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.nbdemetra.ui.chart3d.functions.SurfacePlotterUI;
/*   5:    */ import ec.nbdemetra.ui.chart3d.functions.SurfacePlotterUI.Functions;
/*   6:    */ import ec.satoolkit.DecompositionMode;
/*   7:    */ import ec.satoolkit.ISaSpecification;
/*   8:    */ import ec.satoolkit.ISeriesDecomposition;
/*   9:    */ import ec.tss.Ts;
/*  10:    */ import ec.tss.documents.TsDocumentProcessing;
/*  11:    */ import ec.tss.html.IHtmlElement;
/*  12:    */ import ec.tss.html.implementation.HtmlInformationSet;
/*  13:    */ import ec.tss.sa.EstimationPolicyType;
/*  14:    */ import ec.tss.sa.SaManager;
/*  15:    */ import ec.tss.sa.documents.SaDocument;
/*  16:    */ import ec.tss.sa.documents.SaDocumentProcessing;
/*  17:    */ import ec.tstoolkit.algorithm.CompositeResults;
/*  18:    */ import ec.tstoolkit.arima.IArimaModel;
/*  19:    */ import ec.tstoolkit.modelling.ComponentInformation;
/*  20:    */ import ec.tstoolkit.modelling.ComponentType;
/*  21:    */ import ec.tstoolkit.modelling.ModellingDictionary;
/*  22:    */ import ec.tstoolkit.modelling.arima.ModelDescription;
/*  23:    */ import ec.tstoolkit.modelling.arima.ModelEstimation;
/*  24:    */ import ec.tstoolkit.modelling.arima.PreprocessingModel;
/*  25:    */ import ec.tstoolkit.modelling.arima.diagnostics.IOneStepAheadForecastingTest;
/*  26:    */ import ec.tstoolkit.modelling.arima.diagnostics.OneStepAheadForecastingTest;
/*  27:    */ import ec.tstoolkit.sarima.SarimaComponent;
/*  28:    */ import ec.tstoolkit.sarima.SarimaModel;
/*  29:    */ import ec.tstoolkit.stats.NiidTests;
/*  30:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*  31:    */ import ec.tstoolkit.timeseries.analysis.MovingProcessing;
/*  32:    */ import ec.tstoolkit.timeseries.analysis.RevisionHistory;
/*  33:    */ import ec.tstoolkit.timeseries.analysis.SlidingSpans;
/*  34:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  35:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  36:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  37:    */ import ec.tstoolkit.utilities.DefaultInformationExtractor;
/*  38:    */ import ec.tstoolkit.utilities.Id;
/*  39:    */ import ec.tstoolkit.utilities.InformationExtractor;
/*  40:    */ import ec.tstoolkit.utilities.LinearId;
/*  41:    */ import ec.ui.view.tsprocessing.ArimaUI;
/*  42:    */ import ec.ui.view.tsprocessing.BenchmarkingUI;
/*  43:    */ import ec.ui.view.tsprocessing.ChartUI;
/*  44:    */ import ec.ui.view.tsprocessing.ComposedProcDocumentItemFactory;
/*  45:    */ import ec.ui.view.tsprocessing.DefaultItemUI;
/*  46:    */ import ec.ui.view.tsprocessing.DiagnosticsUI;
/*  47:    */ import ec.ui.view.tsprocessing.EstimationUI;
/*  48:    */ import ec.ui.view.tsprocessing.EstimationUI.Information;
/*  49:    */ import ec.ui.view.tsprocessing.GenericTableUI;
/*  50:    */ import ec.ui.view.tsprocessing.HtmlItemUI;
/*  51:    */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  52:    */ import ec.ui.view.tsprocessing.ITsViewToolkit;
/*  53:    */ import ec.ui.view.tsprocessing.ItemUI;
/*  54:    */ import ec.ui.view.tsprocessing.OutOfSampleTestUI;
/*  55:    */ import ec.ui.view.tsprocessing.PreprocessingUI;
/*  56:    */ import ec.ui.view.tsprocessing.ProcDocumentViewFactory;
/*  57:    */ import ec.ui.view.tsprocessing.ProcDocumentViewFactory.DoNothingExtractor;
/*  58:    */ import ec.ui.view.tsprocessing.RegressorsUI;
/*  59:    */ import ec.ui.view.tsprocessing.ResidualsDistUI;
/*  60:    */ import ec.ui.view.tsprocessing.ResidualsStatsUI;
/*  61:    */ import ec.ui.view.tsprocessing.ResidualsUI;
/*  62:    */ import ec.ui.view.tsprocessing.RevisionHistoryUI;
/*  63:    */ import ec.ui.view.tsprocessing.SlidingSpansDetailUI;
/*  64:    */ import ec.ui.view.tsprocessing.SpectrumUI;
/*  65:    */ import ec.ui.view.tsprocessing.StabilityUI;
/*  66:    */ import ec.ui.view.tsprocessing.TsDocumentInformationExtractor;
/*  67:    */ import java.util.LinkedHashMap;
/*  68:    */ import javax.swing.JComponent;
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ public abstract class SaDocumentViewFactory<S extends ISaSpecification, D extends SaDocument<S>>
/*  87:    */   extends ProcDocumentViewFactory<D>
/*  88:    */ {
/*  89:    */   public static final String INPUT = "Input";
/*  90:    */   public static final String SPEC = "Specifications";
/*  91:    */   public static final String SERIES = "Series";
/*  92:    */   public static final String MAIN = "Main results";
/*  93:    */   public static final String PRELIMINARY = "Preliminary tests";
/*  94:    */   public static final String PREPROCESSING = "Pre-processing";
/*  95:    */   public static final String MODEL = "Model";
/*  96:    */   public static final String DECOMPOSITION = "Decomposition";
/*  97:    */   public static final String BENCHMARKING = "Benchmarking";
/*  98:    */   public static final String DIAGNOSTICS = "Diagnostics";
/*  99:    */   public static final String LIKELIHOOD = "Likelihood";
/* 100:    */   public static final String CHART = "Chart";
/* 101:    */   public static final String CHARTS = "Charts";
/* 102:    */   public static final String TABLE = "Table";
/* 103:    */   public static final String SI_RATIO = "S-I ratio";
/* 104:    */   public static final String SA_TREND = "Sa, trend";
/* 105:    */   public static final String C_S_I = "Cal., sea., irr.";
/* 106:    */   public static final String PROCESSING = "Processing";
/* 107:    */   public static final String FCASTS = "Forecasts";
/* 108:    */   public static final String OSAMPLE = "Out-of-sample test";
/* 109:    */   public static final String DETAILS = "Details";
/* 110:    */   public static final String SUMMARY = "Summary";
/* 111:    */   public static final String STEPS = "Steps";
/* 112:    */   public static final String PREADJUSTMENT = "Pre-adjustment series";
/* 113:    */   public static final String ARIMA = "Arima";
/* 114:    */   public static final String REGRESSORS = "Regressors";
/* 115:    */   public static final String RESIDUALS = "Residuals";
/* 116:    */   public static final String STATS = "Statistics";
/* 117:    */   public static final String DISTRIBUTION = "Distribution";
/* 118:    */   public static final String SEASONALITY = "Seasonality tests";
/* 119:    */   public static final String OSEASONALITY = "Original (transformed) series";
/* 120:    */   public static final String RSEASONALITY = "Full residuals";
/* 121:    */   public static final String LASTRSEASONALITY = "Residuals (last periods)";
/* 122:    */   public static final String LSEASONALITY = "Linearized series";
/* 123:    */   public static final String COMBINED = "Combined test";
/* 124:    */   public static final String RESIDUAL = "Residual seasonality";
/* 125:    */   public static final String TRANSFORMATION = "Transformation";
/* 126:    */   public static final String SPECTRAL = "Spectral analysis";
/* 127:    */   public static final String REVISIONS = "Revisions analysis";
/* 128:    */   public static final String SLIDINGSPANS = "Sliding spans";
/* 129:    */   public static final String STABILITY = "Model stability";
/* 130:    */   public static final String IRREGULAR = "Irregular";
/* 131:    */   public static final String SA_ST = "Sa series (stationary)";
/* 132:    */   public static final String SASERIES = "SA series";
/* 133:    */   public static final String LASTIRREGULAR = "Irregular (last periods)";
/* 134:    */   public static final String LASTSASERIES = "SA series (last periods)";
/* 135:    */   public static final String TREND = "Trend";
/* 136:    */   public static final String SEASONAL = "Seasonal";
/* 137:    */   public static final String TRADINGDAYS = "Trading days";
/* 138:    */   public static final String SACHANGES = "SA series (changes)";
/* 139:    */   public static final String REVISION = "Revisions history";
/* 140:    */   public static final String EASTER = "Easter";
/* 141:141 */   public static final Id INPUT_SPEC = new LinearId("Input", "Specifications");
/* 142:142 */   public static final Id INPUT_SERIES = new LinearId("Input", "Series");
/* 143:143 */   public static final Id MAIN_SUMMARY = new LinearId("Main results");
/* 144:144 */   public static final Id MODEL_SUMMARY = new LinearId("Model");
/* 145:145 */   public static final Id MODEL_FCASTS = new LinearId("Model", "Forecasts");
/* 146:146 */   public static final Id MODEL_FCASTS_OUTOFSAMPLE = new LinearId(new String[] { "Model", "Forecasts", "Out-of-sample test" });
/* 147:147 */   public static final Id MODEL_REGS = new LinearId("Model", "Regressors");
/* 148:148 */   public static final Id MODEL_ARIMA = new LinearId("Model", "Arima");
/* 149:149 */   public static final Id MODEL_RES = new LinearId("Model", "Residuals");
/* 150:150 */   public static final Id MODEL_RES_STATS = new LinearId(new String[] { "Model", "Residuals", "Statistics" });
/* 151:151 */   public static final Id MODEL_RES_DIST = new LinearId(new String[] { "Model", "Residuals", "Distribution" });
/* 152:152 */   public static final Id MODEL_RES_SPECTRUM = new LinearId(new String[] { "Model", "Residuals", "Spectral analysis" });
/* 153:153 */   public static final Id MAIN_CHART = new LinearId("Main results", "Chart");
/* 154:154 */   public static final Id MAIN_CHARTS_LOW = new LinearId(new String[] { "Main results", "Charts", "Sa, trend" });
/* 155:155 */   public static final Id MAIN_CHARTS_HIGH = new LinearId(new String[] { "Main results", "Charts", "Cal., sea., irr." });
/* 156:156 */   public static final Id MAIN_TABLE = new LinearId("Main results", "Table");
/* 157:157 */   public static final Id MAIN_SI = new LinearId("Main results", "S-I ratio");
/* 158:158 */   public static final Id PREPROCESSING_SUMMARY = new LinearId("Pre-processing");
/* 159:159 */   public static final Id PREPROCESSING_FCASTS = new LinearId("Pre-processing", "Forecasts");
/* 160:160 */   public static final Id PREPROCESSING_FCASTS_TABLE = new LinearId(new String[] { "Pre-processing", "Forecasts", "Table" });
/* 161:161 */   public static final Id PREPROCESSING_FCASTS_OUTOFSAMPLE = new LinearId(new String[] { "Pre-processing", "Forecasts", "Out-of-sample test" });
/* 162:162 */   public static final Id PREPROCESSING_DETAILS = new LinearId("Pre-processing", "Details");
/* 163:163 */   public static final Id PREPROCESSING_REGS = new LinearId("Pre-processing", "Regressors");
/* 164:164 */   public static final Id PREPROCESSING_ARIMA = new LinearId("Pre-processing", "Arima");
/* 165:165 */   public static final Id PREPROCESSING_DET = new LinearId("Pre-processing", "Pre-adjustment series");
/* 166:166 */   public static final Id PREPROCESSING_RES = new LinearId("Pre-processing", "Residuals");
/* 167:167 */   public static final Id PREPROCESSING_RES_STATS = new LinearId(new String[] { "Pre-processing", "Residuals", "Statistics" });
/* 168:168 */   public static final Id PREPROCESSING_RES_DIST = new LinearId(new String[] { "Pre-processing", "Residuals", "Distribution" });
/* 169:169 */   public static final Id PREPROCESSING_LIKELIHOOD = new LinearId("Pre-processing", "Likelihood");
/* 170:170 */   public static final Id DIAGNOSTICS_SUMMARY = new LinearId("Diagnostics");
/* 171:171 */   public static final Id DIAGNOSTICS_SEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Combined test" });
/* 172:172 */   public static final Id DIAGNOSTICS_OSEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Original (transformed) series" });
/* 173:173 */   public static final Id DIAGNOSTICS_LSEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Linearized series" });
/* 174:174 */   public static final Id DIAGNOSTICS_RSEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Full residuals" });
/* 175:175 */   public static final Id DIAGNOSTICS_SASEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "SA series" });
/* 176:176 */   public static final Id DIAGNOSTICS_LASTRSEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Residuals (last periods)" });
/* 177:177 */   public static final Id DIAGNOSTICS_LASTSASEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "SA series (last periods)" });
/* 178:178 */   public static final Id DIAGNOSTICS_RESIDUALSEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Residual seasonality" });
/* 179:179 */   public static final Id DIAGNOSTICS_ISEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Irregular" });
/* 180:180 */   public static final Id DIAGNOSTICS_LASTISEASONALITY = new LinearId(new String[] { "Diagnostics", "Seasonality tests", "Irregular (last periods)" });
/* 181:181 */   public static final Id DIAGNOSTICS_SPECTRUM_RES = new LinearId(new String[] { "Diagnostics", "Spectral analysis", "Residuals" });
/* 182:182 */   public static final Id DIAGNOSTICS_SPECTRUM_I = new LinearId(new String[] { "Diagnostics", "Spectral analysis", "Irregular" });
/* 183:183 */   public static final Id DIAGNOSTICS_SPECTRUM_SA = new LinearId(new String[] { "Diagnostics", "Spectral analysis", "Sa series (stationary)" });
/* 184:184 */   public static final Id DIAGNOSTICS_SLIDING_SUMMARY = new LinearId("Diagnostics", "Sliding spans");
/* 185:185 */   public static final Id DIAGNOSTICS_SLIDING_SEAS = new LinearId(new String[] { "Diagnostics", "Sliding spans", "Seasonal" });
/* 186:186 */   public static final Id DIAGNOSTICS_SLIDING_TD = new LinearId(new String[] { "Diagnostics", "Sliding spans", "Trading days" });
/* 187:187 */   public static final Id DIAGNOSTICS_SLIDING_SA = new LinearId(new String[] { "Diagnostics", "Sliding spans", "SA series (changes)" });
/* 188:188 */   public static final Id DIAGNOSTICS_REVISION_SA = new LinearId(new String[] { "Diagnostics", "Revisions history", "SA series" });
/* 189:189 */   public static final Id DIAGNOSTICS_REVISION_TREND = new LinearId(new String[] { "Diagnostics", "Revisions history", "Trend" });
/* 190:190 */   public static final Id DIAGNOSTICS_STABILITY_TD = new LinearId(new String[] { "Diagnostics", "Model stability", "Trading days" });
/* 191:191 */   public static final Id DIAGNOSTICS_STABILITY_EASTER = new LinearId(new String[] { "Diagnostics", "Model stability", "Easter" });
/* 192:192 */   public static final Id DIAGNOSTICS_STABILITY_ARIMA = new LinearId(new String[] { "Diagnostics", "Model stability", "Arima" });
/* 193:    */   
/* 194:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, ISaSpecification> specExtractor() {
/* 195:195 */     return SpecExtractor.INSTANCE;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, CompositeResults> saExtractor() {
/* 199:199 */     return SaExtractor.INSTANCE;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, PreprocessingModel> pmExtractor() {
/* 203:203 */     return PmExtractor.INSTANCE;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, TsData> resExtractor() {
/* 207:207 */     return ResExtractor.INSTANCE;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SlidingSpans> ssExtractor() {
/* 211:211 */     return SsExtractor.INSTANCE;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> oseasExtractor() {
/* 215:215 */     return SeasTestExtractor.OINSTANCE;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> lseasExtractor() {
/* 219:219 */     return SeasTestExtractor.LINSTANCE;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> rseasExtractor() {
/* 223:223 */     return SeasTestExtractor.RINSTANCE;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> saseasExtractor() {
/* 227:227 */     return SeasTestExtractor.SAINSTANCE;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> iseasExtractor() {
/* 231:231 */     return SeasTestExtractor.IINSTANCE;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> lastrseasExtractor() {
/* 235:235 */     return SeasTestExtractor.LASTRINSTANCE;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> lastsaseasExtractor() {
/* 239:239 */     return SeasTestExtractor.LASTSAINSTANCE;
/* 240:    */   }
/* 241:    */   
/* 242:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> lastiseasExtractor() {
/* 243:243 */     return SeasTestExtractor.LASTIINSTANCE;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, RevisionHistory> historyExtractor() {
/* 247:247 */     return RevisionExtractor.INSTANCE;
/* 248:    */   }
/* 249:    */   
/* 250:    */   public static InformationExtractor<SaDocument<? extends ISaSpecification>, SurfacePlotterUI.Functions> likelihoodExtractor() {
/* 251:251 */     return LikelihoodExtractor.INSTANCE;
/* 252:    */   }
/* 253:    */   
/* 254:    */ 
/* 255:    */   @Deprecated
/* 256:    */   public void registerSpec() {}
/* 257:    */   
/* 258:    */   protected static class SpecAllFactory<D extends SaDocument<? extends ISaSpecification>>
/* 259:    */     extends SaDocumentViewFactory.ItemFactory<D, ISaSpecification>
/* 260:    */   {
/* 261:    */     protected SpecAllFactory(Class<D> documentType)
/* 262:    */     {
/* 263:263 */       super(SaDocumentViewFactory.INPUT_SPEC, SaDocumentViewFactory.specExtractor(), new HtmlItemUI()
/* 264:    */       {
/* 265:    */         protected IHtmlElement getHtmlElement(IProcDocumentView<D> host, ISaSpecification information) {
/* 266:266 */           return new HtmlInformationSet(information.write(true));
/* 267:    */         }
/* 268:    */       });
/* 269:    */     }
/* 270:    */   }
/* 271:    */   
/* 272:    */ 
/* 273:    */ 
/* 274:    */   @Deprecated
/* 275:    */   public void registerMainViews()
/* 276:    */   {
/* 277:277 */     registerSiView();
/* 278:    */   }
/* 279:    */   
/* 280:    */   @Deprecated
/* 281:    */   public void registerSiView() {}
/* 282:    */   
/* 283:    */   @Deprecated
/* 284:    */   public void registerArimaView() {}
/* 285:    */   
/* 286:    */   @Deprecated
/* 287:    */   public void registerLightPreprocessingViews() {}
/* 288:    */   
/* 289:    */   protected static class MainChartsLowFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, CompositeResults> {
/* 290:    */     private static String[] generateItems() {
/* 291:291 */       StringBuilder y = new StringBuilder();
/* 292:292 */       y.append("@composite@").append("Series=,").append("y")
/* 293:293 */         .append(',').append("y").append("_f");
/* 294:294 */       StringBuilder t = new StringBuilder();
/* 295:295 */       t.append("@composite@").append("Trend=,").append("t")
/* 296:296 */         .append(',').append("t").append("_f");
/* 297:297 */       StringBuilder sa = new StringBuilder();
/* 298:298 */       sa.append("@composite@").append("Seasonally adjusted=,").append("sa")
/* 299:299 */         .append(',').append("sa").append("_f");
/* 300:300 */       return new String[] { y.toString(), t.toString(), sa.toString() };
/* 301:    */     }
/* 302:    */     
/* 303:    */     protected MainChartsLowFactory(Class<D> documentType) {
/* 304:304 */       super(SaDocumentViewFactory.MAIN_CHARTS_LOW, SaDocumentViewFactory.saExtractor(), new ChartUI(generateItems()));
/* 305:    */     }
/* 306:    */   }
/* 307:    */   
/* 308:    */   protected static class MainChartsHighFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, CompositeResults>
/* 309:    */   {
/* 310:    */     private static String[] generateItems()
/* 311:    */     {
/* 312:312 */       StringBuilder cal = new StringBuilder();
/* 313:313 */       cal.append("@composite@").append("Calendar effects=,").append("cal")
/* 314:314 */         .append(',').append("cal").append("_f");
/* 315:315 */       StringBuilder s = new StringBuilder();
/* 316:316 */       s.append("@composite@").append("Seas (component)=,").append("s_cmp")
/* 317:317 */         .append(',').append("s_cmp").append("_f");
/* 318:318 */       StringBuilder i = new StringBuilder();
/* 319:319 */       i.append("@composite@").append("Irregular=,").append("i")
/* 320:320 */         .append(',').append("i").append("_f");
/* 321:321 */       return new String[] { cal.toString(), s.toString(), i.toString() };
/* 322:    */     }
/* 323:    */     
/* 324:    */     protected MainChartsHighFactory(Class<D> documentType) {
/* 325:325 */       super(SaDocumentViewFactory.MAIN_CHARTS_HIGH, SaDocumentViewFactory.saExtractor(), new ChartUI(generateItems()));
/* 326:    */     }
/* 327:    */   }
/* 328:    */   
/* 329:    */   protected static class MainTableFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, CompositeResults>
/* 330:    */   {
/* 331:    */     private static String[] generateItems()
/* 332:    */     {
/* 333:333 */       StringBuilder y = new StringBuilder();
/* 334:334 */       y.append("@composite@").append("Series=,").append("y")
/* 335:335 */         .append(',').append("y").append("_f");
/* 336:336 */       StringBuilder t = new StringBuilder();
/* 337:337 */       t.append("@composite@").append("Trend=,").append("t")
/* 338:338 */         .append(',').append("t").append("_f");
/* 339:339 */       StringBuilder sa = new StringBuilder();
/* 340:340 */       sa.append("@composite@").append("Seasonally adjusted=,").append("sa")
/* 341:341 */         .append(',').append("sa").append("_f");
/* 342:342 */       StringBuilder s = new StringBuilder();
/* 343:343 */       s.append("@composite@").append("Seasonal=,").append("s")
/* 344:344 */         .append(',').append("s").append("_f");
/* 345:345 */       StringBuilder i = new StringBuilder();
/* 346:346 */       i.append("@composite@").append("Irregular=,").append("i")
/* 347:347 */         .append(',').append("i").append("_f");
/* 348:348 */       return new String[] { y.toString(), sa.toString(), t.toString(), s.toString(), i.toString() };
/* 349:    */     }
/* 350:    */     
/* 351:    */     protected MainTableFactory(Class<D> documentType) {
/* 352:352 */       super(SaDocumentViewFactory.MAIN_TABLE, SaDocumentViewFactory.saExtractor(), new GenericTableUI(false, generateItems()));
/* 353:    */     }
/* 354:    */   }
/* 355:    */   
/* 356:    */   protected static class InputFactory<D extends SaDocument<? extends ISaSpecification>>
/* 357:    */     extends SaDocumentViewFactory.ItemFactory<D, D>
/* 358:    */   {
/* 359:    */     protected InputFactory(Class<D> documentType)
/* 360:    */     {
/* 361:361 */       super(SaDocumentViewFactory.INPUT_SERIES, new ProcDocumentViewFactory.DoNothingExtractor(), new DefaultItemUI()
/* 362:    */       {
/* 363:    */         public JComponent getView(IProcDocumentView<D> host, D information) {
/* 364:364 */           return host.getToolkit().getGrid((Ts)information.getInput());
/* 365:    */         }
/* 366:    */       });
/* 367:    */     }
/* 368:    */   }
/* 369:    */   
/* 370:    */   protected static class SeasonalityTestsFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, SeasonalityTestUI2.Information>
/* 371:    */   {
/* 372:    */     protected SeasonalityTestsFactory(Class<D> documentType, Id id, InformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information> extractor, String header, boolean control)
/* 373:    */     {
/* 374:374 */       super(id, extractor, new SeasonalityTestUI2(header, control));
/* 375:    */     }
/* 376:    */   }
/* 377:    */   
/* 378:    */ 
/* 379:    */ 
/* 380:    */ 
/* 381:    */ 
/* 382:    */ 
/* 383:    */ 
/* 384:    */ 
/* 385:    */ 
/* 386:    */ 
/* 387:    */ 
/* 388:    */ 
/* 389:    */ 
/* 390:    */ 
/* 391:    */ 
/* 392:    */ 
/* 393:    */ 
/* 394:    */ 
/* 395:    */ 
/* 396:    */ 
/* 397:    */   protected static class MainSiFactory<D extends SaDocument<? extends ISaSpecification>>
/* 398:    */     extends SaDocumentViewFactory.ItemFactory<D, TsData[]>
/* 399:    */   {
/* 400:    */     protected MainSiFactory(Class<D> documentType)
/* 401:    */     {
/* 402:402 */       super(SaDocumentViewFactory.MAIN_SI, new DefaultInformationExtractor()new SiRatioUI
/* 403:    */       {
/* 404:    */         public TsData[] retrieve(D source)
/* 405:    */         {
/* 406:391 */           CompositeResults rslt = (CompositeResults)source.getResults();
/* 407:392 */           TsData seas = (TsData)rslt.getData("s_cmp", TsData.class);
/* 408:393 */           TsData i = (TsData)rslt.getData("i_cmp", TsData.class);
/* 409:    */           TsData si;
/* 410:395 */           TsData si; if (source.getFinalDecomposition().getMode().isMultiplicative()) {
/* 411:396 */             si = TsData.multiply(seas, i);
/* 412:    */           } else {
/* 413:398 */             si = TsData.add(seas, i);
/* 414:    */           }
/* 415:400 */           return new TsData[] { seas, si };
/* 416:    */         }
/* 417:402 */       }, new SiRatioUI());
/* 418:    */     }
/* 419:    */   }
/* 420:    */   
/* 421:    */ 
/* 422:    */ 
/* 423:    */ 
/* 424:    */ 
/* 425:    */ 
/* 426:    */ 
/* 427:    */ 
/* 428:    */ 
/* 429:    */ 
/* 430:    */ 
/* 431:    */ 
/* 432:    */ 
/* 433:    */ 
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:    */   protected static class PreprocessingArimaFactory<D extends SaDocument<? extends ISaSpecification>>
/* 438:    */     extends SaDocumentViewFactory.ItemFactory<D, LinkedHashMap<String, IArimaModel>>
/* 439:    */   {
/* 440:    */     protected PreprocessingArimaFactory(Class<D> documentType)
/* 441:    */     {
/* 442:427 */       super(SaDocumentViewFactory.PREPROCESSING_ARIMA, new DefaultInformationExtractor()new ArimaUI
/* 443:    */       {
/* 444:    */         public LinkedHashMap<String, IArimaModel> retrieve(D source)
/* 445:    */         {
/* 446:419 */           LinkedHashMap<String, IArimaModel> models = new LinkedHashMap();
/* 447:420 */           PreprocessingModel preprocessingPart = source.getPreprocessingPart();
/* 448:421 */           if (preprocessingPart != null) {
/* 449:422 */             SarimaModel tmodel = estimation.getArima();
/* 450:423 */             models.put("RegArima model", tmodel);
/* 451:    */           }
/* 452:425 */           return models;
/* 453:    */         }
/* 454:427 */       }, new ArimaUI());
/* 455:    */     }
/* 456:    */   }
/* 457:    */   
/* 458:    */ 
/* 459:    */ 
/* 460:    */ 
/* 461:    */ 
/* 462:    */ 
/* 463:    */   protected static class PreprocessingSummaryFactory<D extends SaDocument<? extends ISaSpecification>>
/* 464:    */     extends SaDocumentViewFactory.ItemFactory<D, PreprocessingModel>
/* 465:    */   {
/* 466:    */     protected PreprocessingSummaryFactory(Class<D> documentType)
/* 467:    */     {
/* 468:441 */       super(SaDocumentViewFactory.PREPROCESSING_SUMMARY, SaDocumentViewFactory.pmExtractor(), new PreprocessingUI());
/* 469:    */     }
/* 470:    */   }
/* 471:    */   
/* 472:    */   protected static class PreprocessingRegsFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, PreprocessingModel>
/* 473:    */   {
/* 474:    */     protected PreprocessingRegsFactory(Class<D> documentType)
/* 475:    */     {
/* 476:449 */       super(SaDocumentViewFactory.PREPROCESSING_REGS, SaDocumentViewFactory.pmExtractor(), new RegressorsUI());
/* 477:    */     }
/* 478:    */   }
/* 479:    */   
/* 480:    */   protected static class PreprocessingDetFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, CompositeResults>
/* 481:    */   {
/* 482:    */     protected PreprocessingDetFactory(Class<D> documentType)
/* 483:    */     {
/* 484:457 */       super(SaDocumentViewFactory.PREPROCESSING_DET, SaDocumentViewFactory.saExtractor(), new SaTableUI(ModellingDictionary.getDeterministicSeries(), null));
/* 485:    */     }
/* 486:    */   }
/* 487:    */   
/* 488:    */ 
/* 489:    */   @Deprecated
/* 490:    */   public void registerPreprocessingViews()
/* 491:    */   {
/* 492:465 */     registerArimaView();
/* 493:    */   }
/* 494:    */   
/* 495:    */ 
/* 496:    */ 
/* 497:    */ 
/* 498:    */ 
/* 499:    */ 
/* 500:    */ 
/* 501:    */   @Deprecated
/* 502:    */   public void registerBenchmarkingView() {}
/* 503:    */   
/* 504:    */ 
/* 505:    */ 
/* 506:    */ 
/* 507:    */ 
/* 508:    */ 
/* 509:    */   protected static class PreprocessingFCastsFactory<D extends SaDocument<? extends ISaSpecification>>
/* 510:    */     extends SaDocumentViewFactory.ItemFactory<D, EstimationUI.Information>
/* 511:    */   {
/* 512:    */     protected PreprocessingFCastsFactory(Class<D> documentType)
/* 513:    */     {
/* 514:487 */       super(SaDocumentViewFactory.PREPROCESSING_FCASTS, new DefaultInformationExtractor()new EstimationUI
/* 515:    */       {
/* 516:    */         public EstimationUI.Information retrieve(D source)
/* 517:    */         {
/* 518:475 */           PreprocessingModel model = source.getPreprocessingPart();
/* 519:476 */           if (model == null) {
/* 520:477 */             return null;
/* 521:    */           }
/* 522:479 */           TsData orig = description.getOriginal();
/* 523:480 */           TsPeriodSelector sel = new TsPeriodSelector();
/* 524:481 */           sel.last(3 * orig.getFrequency().intValue());
/* 525:482 */           return new EstimationUI.Information(orig.select(sel), 
/* 526:483 */             (TsData)model.getData("y_f", TsData.class), 
/* 527:484 */             (TsData)model.getData("y_ef", TsData.class), 
/* 528:485 */             1.96D);
/* 529:    */         }
/* 530:487 */       }, new EstimationUI());
/* 531:    */     }
/* 532:    */   }
/* 533:    */   
/* 534:    */   protected static class PreprocessingFCastsTableFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, CompositeResults>
/* 535:    */   {
/* 536:    */     private static String[] generateItems()
/* 537:    */     {
/* 538:495 */       return new String[] { "y_f", "y_ef" };
/* 539:    */     }
/* 540:    */     
/* 541:    */     protected PreprocessingFCastsTableFactory(Class<D> documentType) {
/* 542:499 */       super(SaDocumentViewFactory.PREPROCESSING_FCASTS_TABLE, SaDocumentViewFactory.saExtractor(), new GenericTableUI(false, generateItems()));
/* 543:    */     }
/* 544:    */   }
/* 545:    */   
/* 546:    */ 
/* 547:    */ 
/* 548:    */ 
/* 549:    */ 
/* 550:    */ 
/* 551:    */ 
/* 552:    */ 
/* 553:    */ 
/* 554:    */ 
/* 555:    */ 
/* 556:    */ 
/* 557:    */ 
/* 558:    */ 
/* 559:    */ 
/* 560:    */ 
/* 561:    */ 
/* 562:    */ 
/* 563:    */ 
/* 564:    */ 
/* 565:    */ 
/* 566:    */ 
/* 567:    */ 
/* 568:    */ 
/* 569:    */ 
/* 570:    */ 
/* 571:    */ 
/* 572:    */ 
/* 573:    */ 
/* 574:    */   protected static class PreprocessingFCastsOutFactory<D extends SaDocument<? extends ISaSpecification>>
/* 575:    */     extends SaDocumentViewFactory.ItemFactory<D, IOneStepAheadForecastingTest>
/* 576:    */   {
/* 577:    */     protected PreprocessingFCastsOutFactory(Class<D> documentType)
/* 578:    */     {
/* 579:536 */       super(SaDocumentViewFactory.PREPROCESSING_FCASTS_OUTOFSAMPLE, new DefaultInformationExtractor()new OutOfSampleTestUI
/* 580:    */       {
/* 581:    */         public IOneStepAheadForecastingTest retrieve(D source)
/* 582:    */         {
/* 583:510 */           PreprocessingModel model = source.getPreprocessingPart();
/* 584:511 */           if (model == null) {
/* 585:512 */             return null;
/* 586:    */           }
/* 587:    */           
/* 588:515 */           TsFrequency freq = description.getSeriesDomain().getFrequency();
/* 589:516 */           int lback; int lback; int lback; int lback; switch (freq) {
/* 590:    */           case Yearly: 
/* 591:518 */             lback = 18;
/* 592:519 */             break;
/* 593:    */           case Quarterly: 
/* 594:521 */             lback = 6;
/* 595:522 */             break;
/* 596:    */           case Undefined: 
/* 597:524 */             lback = 9;
/* 598:525 */             break;
/* 599:    */           default: 
/* 600:527 */             lback = 5;
/* 601:    */           }
/* 602:    */           
/* 603:530 */           OneStepAheadForecastingTest test = new OneStepAheadForecastingTest(lback);
/* 604:531 */           test.test(estimation.getRegArima());
/* 605:    */           
/* 606:    */ 
/* 607:534 */           return test;
/* 608:    */         }
/* 609:536 */       }, new OutOfSampleTestUI());
/* 610:    */     }
/* 611:    */   }
/* 612:    */   
/* 613:    */   protected static class PreprocessingResFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, TsData>
/* 614:    */   {
/* 615:    */     protected PreprocessingResFactory(Class<D> documentType)
/* 616:    */     {
/* 617:544 */       super(SaDocumentViewFactory.PREPROCESSING_RES, SaDocumentViewFactory.resExtractor(), new ResidualsUI());
/* 618:    */     }
/* 619:    */   }
/* 620:    */   
/* 621:    */ 
/* 622:    */ 
/* 623:    */ 
/* 624:    */ 
/* 625:    */ 
/* 626:    */ 
/* 627:    */ 
/* 628:    */ 
/* 629:    */ 
/* 630:    */ 
/* 631:    */   protected static class PreprocessingResStatsFactory<D extends SaDocument<? extends ISaSpecification>>
/* 632:    */     extends SaDocumentViewFactory.ItemFactory<D, NiidTests>
/* 633:    */   {
/* 634:    */     protected PreprocessingResStatsFactory(Class<D> documentType)
/* 635:    */     {
/* 636:563 */       super(SaDocumentViewFactory.PREPROCESSING_RES_STATS, new DefaultInformationExtractor()new ResidualsStatsUI
/* 637:    */       {
/* 638:    */         public NiidTests retrieve(D source)
/* 639:    */         {
/* 640:555 */           PreprocessingModel pp = source.getPreprocessingPart();
/* 641:556 */           if (pp == null) {
/* 642:557 */             return null;
/* 643:    */           }
/* 644:559 */           TsData res = pp.getFullResiduals();
/* 645:560 */           return new NiidTests(res.getValues(), res.getFrequency().intValue(), 
/* 646:561 */             description.getArimaComponent().getFreeParametersCount(), true);
/* 647:    */         }
/* 648:563 */       }, new ResidualsStatsUI());
/* 649:    */     }
/* 650:    */   }
/* 651:    */   
/* 652:    */   protected static class PreprocessingResDistFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, TsData>
/* 653:    */   {
/* 654:    */     protected PreprocessingResDistFactory(Class<D> documentType)
/* 655:    */     {
/* 656:571 */       super(SaDocumentViewFactory.PREPROCESSING_RES_DIST, SaDocumentViewFactory.resExtractor(), new ResidualsDistUI());
/* 657:    */     }
/* 658:    */   }
/* 659:    */   
/* 660:    */ 
/* 661:    */ 
/* 662:    */ 
/* 663:    */ 
/* 664:    */ 
/* 665:    */ 
/* 666:    */ 
/* 667:    */ 
/* 668:    */ 
/* 669:    */ 
/* 670:    */ 
/* 671:    */ 
/* 672:    */ 
/* 673:    */   protected static class BenchmarkingFactory<D extends SaDocument<? extends ISaSpecification>>
/* 674:    */     extends SaDocumentViewFactory.ItemFactory<D, Boolean>
/* 675:    */   {
/* 676:    */     protected BenchmarkingFactory(Class<D> documentType)
/* 677:    */     {
/* 678:593 */       super(new LinearId("Benchmarking"), new DefaultInformationExtractor()new BenchmarkingUI
/* 679:    */       {
/* 680:    */         public Boolean retrieve(D source)
/* 681:    */         {
/* 682:588 */           if (source.getBenchmarking() == null) {
/* 683:589 */             return null;
/* 684:    */           }
/* 685:591 */           if (source.getFinalDecomposition().getMode() != DecompositionMode.Additive) return Boolean.valueOf(true); return Boolean.valueOf(false);
/* 686:    */         }
/* 687:593 */       }, new BenchmarkingUI());
/* 688:    */     }
/* 689:    */   }
/* 690:    */   
/* 691:    */ 
/* 692:    */   @Deprecated
/* 693:    */   public void registerDiagnosticsViews()
/* 694:    */   {
/* 695:601 */     registerSeasonalityView();
/* 696:602 */     registerSlidingSpansView();
/* 697:    */   }
/* 698:    */   
/* 699:    */   @Deprecated
/* 700:    */   public void registerSeasonalityView() {}
/* 701:    */   
/* 702:    */   protected static class DiagnosticsSummaryFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, CompositeResults> {
/* 703:609 */     protected DiagnosticsSummaryFactory(Class<D> documentType) { super(SaDocumentViewFactory.DIAGNOSTICS_SUMMARY, SaDocumentViewFactory.saExtractor(), new DiagnosticsUI()); }
/* 704:    */   }
/* 705:    */   
/* 706:    */   protected static class DiagnosticsSpectrumResFactory<D extends SaDocument<? extends ISaSpecification>>
/* 707:    */     extends SaDocumentViewFactory.ItemFactory<D, TsData>
/* 708:    */   {
/* 709:    */     protected DiagnosticsSpectrumResFactory(Class<D> documentType)
/* 710:    */     {
/* 711:617 */       super(SaDocumentViewFactory.DIAGNOSTICS_SPECTRUM_RES, SaDocumentViewFactory.resExtractor(), new SpectrumUI(true));
/* 712:    */     }
/* 713:    */   }
/* 714:    */   
/* 715:    */ 
/* 716:    */ 
/* 717:    */ 
/* 718:    */ 
/* 719:    */   protected static class DiagnosticsSpectrumIFactory<D extends SaDocument<? extends ISaSpecification>>
/* 720:    */     extends SaDocumentViewFactory.ItemFactory<D, TsData>
/* 721:    */   {
/* 722:    */     protected DiagnosticsSpectrumIFactory(Class<D> documentType)
/* 723:    */     {
/* 724:630 */       super(SaDocumentViewFactory.DIAGNOSTICS_SPECTRUM_I, new DefaultInformationExtractor()new SpectrumUI
/* 725:    */       {
/* 726:    */         public TsData retrieve(D source)
/* 727:    */         {
/* 728:628 */           return source.getFinalDecomposition().getSeries(ComponentType.Irregular, ComponentInformation.Value);
/* 729:    */         }
/* 730:630 */       }, new SpectrumUI(false));
/* 731:    */     }
/* 732:    */   }
/* 733:    */   
/* 734:    */ 
/* 735:    */ 
/* 736:    */ 
/* 737:    */ 
/* 738:    */ 
/* 739:    */ 
/* 740:    */ 
/* 741:    */ 
/* 742:    */ 
/* 743:    */   protected static class DiagnosticsSpectrumSaFactory<D extends SaDocument<? extends ISaSpecification>>
/* 744:    */     extends SaDocumentViewFactory.ItemFactory<D, TsData>
/* 745:    */   {
/* 746:    */     protected DiagnosticsSpectrumSaFactory(Class<D> documentType)
/* 747:    */     {
/* 748:648 */       super(SaDocumentViewFactory.DIAGNOSTICS_SPECTRUM_SA, new DefaultInformationExtractor()new SpectrumUI
/* 749:    */       {
/* 750:    */         public TsData retrieve(D source)
/* 751:    */         {
/* 752:641 */           TsData s = source.getFinalDecomposition().getSeries(ComponentType.SeasonallyAdjusted, ComponentInformation.Value);
/* 753:    */           
/* 754:    */ 
/* 755:    */ 
/* 756:    */ 
/* 757:646 */           return s.delta(1);
/* 758:    */         }
/* 759:648 */       }, new SpectrumUI(false));
/* 760:    */     }
/* 761:    */   }
/* 762:    */   
/* 763:    */   protected static class DiagnosticsRevisionSaFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, RevisionHistory>
/* 764:    */   {
/* 765:    */     protected DiagnosticsRevisionSaFactory(Class<D> documentType)
/* 766:    */     {
/* 767:656 */       super(SaDocumentViewFactory.DIAGNOSTICS_REVISION_SA, SaDocumentViewFactory.RevisionExtractor.access$1(), new RevisionHistoryUI("sa"));
/* 768:    */     }
/* 769:    */   }
/* 770:    */   
/* 771:    */   protected static class DiagnosticsRevisionTrendFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, RevisionHistory>
/* 772:    */   {
/* 773:    */     protected DiagnosticsRevisionTrendFactory(Class<D> documentType)
/* 774:    */     {
/* 775:664 */       super(SaDocumentViewFactory.DIAGNOSTICS_REVISION_TREND, SaDocumentViewFactory.RevisionExtractor.access$1(), new RevisionHistoryUI("t"));
/* 776:    */     }
/* 777:    */   }
/* 778:    */   
/* 779:    */   protected static class StabilityTDFactory<D extends SaDocument<? extends ISaSpecification>>
/* 780:    */     extends SaDocumentViewFactory.ItemFactory<D, MovingProcessing>
/* 781:    */   {
/* 782:671 */     private static final String[] Items = {
/* 783:672 */       "regression.td(1)", 
/* 784:673 */       "regression.td(2)", 
/* 785:674 */       "regression.td(3)", 
/* 786:675 */       "regression.td(4)", 
/* 787:676 */       "regression.td(5)", 
/* 788:677 */       "regression.td(6)" };
/* 789:    */     
/* 790:    */     protected StabilityTDFactory(Class<D> documentType)
/* 791:    */     {
/* 792:681 */       super(SaDocumentViewFactory.DIAGNOSTICS_STABILITY_TD, SaDocumentViewFactory.MovingProcessingExtractor.INSTANCE, new StabilityUI("Trading days", Items));
/* 793:    */     }
/* 794:    */   }
/* 795:    */   
/* 796:    */   protected static class StabilityEasterFactory<D extends SaDocument<? extends ISaSpecification>>
/* 797:    */     extends SaDocumentViewFactory.ItemFactory<D, MovingProcessing>
/* 798:    */   {
/* 799:688 */     private static final String[] Items = {
/* 800:689 */       "regression.easter" };
/* 801:    */     
/* 802:    */     protected StabilityEasterFactory(Class<D> documentType)
/* 803:    */     {
/* 804:693 */       super(SaDocumentViewFactory.DIAGNOSTICS_STABILITY_EASTER, SaDocumentViewFactory.MovingProcessingExtractor.INSTANCE, new StabilityUI("Easter", Items));
/* 805:    */     }
/* 806:    */   }
/* 807:    */   
/* 808:    */   protected static class StabilityArimaFactory<D extends SaDocument<? extends ISaSpecification>>
/* 809:    */     extends SaDocumentViewFactory.ItemFactory<D, MovingProcessing>
/* 810:    */   {
/* 811:700 */     private static final String[] Items = {
/* 812:701 */       "arima.phi(1)", "arima.phi(2)", "arima.phi(3)", "arima.th(1)", "arima.th(2)", "arima.th(3)", 
/* 813:702 */       "arima.bphi(1)", "arima.bth(1)" };
/* 814:    */     
/* 815:    */     protected StabilityArimaFactory(Class<D> documentType)
/* 816:    */     {
/* 817:706 */       super(SaDocumentViewFactory.DIAGNOSTICS_STABILITY_ARIMA, SaDocumentViewFactory.MovingProcessingExtractor.INSTANCE, new StabilityUI("Arima", Items));
/* 818:    */     }
/* 819:    */   }
/* 820:    */   
/* 821:    */ 
/* 822:    */   protected static class LikelihoodFactory<D extends SaDocument<? extends ISaSpecification>>
/* 823:    */     extends SaDocumentViewFactory.ItemFactory<D, SurfacePlotterUI.Functions>
/* 824:    */   {
/* 825:    */     protected LikelihoodFactory(Class<D> documentType)
/* 826:    */     {
/* 827:716 */       super(SaDocumentViewFactory.PREPROCESSING_LIKELIHOOD, SaDocumentViewFactory.LikelihoodExtractor.INSTANCE, new SurfacePlotterUI());
/* 828:    */     }
/* 829:    */   }
/* 830:    */   
/* 831:    */ 
/* 832:    */ 
/* 833:    */ 
/* 834:    */ 
/* 835:    */ 
/* 836:    */ 
/* 837:    */ 
/* 838:    */ 
/* 839:    */ 
/* 840:    */ 
/* 841:    */ 
/* 842:    */   protected static class ResidualSeasonalityFactory<D extends SaDocument<? extends ISaSpecification>>
/* 843:    */     extends SaDocumentViewFactory.ItemFactory<D, TsData>
/* 844:    */   {
/* 845:    */     protected ResidualSeasonalityFactory(Class<D> documentType)
/* 846:    */     {
/* 847:736 */       super(SaDocumentViewFactory.DIAGNOSTICS_RESIDUALSEASONALITY, new DefaultInformationExtractor()new ResidualSeasonalityTestUI
/* 848:    */       {
/* 849:    */         public TsData retrieve(D source)
/* 850:    */         {
/* 851:733 */           CompositeResults rslt = (CompositeResults)source.getResults();
/* 852:734 */           return (TsData)rslt.getData("sa", TsData.class);
/* 853:    */         }
/* 854:736 */       }, new ResidualSeasonalityTestUI());
/* 855:    */     }
/* 856:    */   }
/* 857:    */   
/* 858:    */ 
/* 859:    */ 
/* 860:    */ 
/* 861:    */ 
/* 862:    */ 
/* 863:    */ 
/* 864:    */ 
/* 865:    */   @Deprecated
/* 866:    */   public void registerSlidingSpansView() {}
/* 867:    */   
/* 868:    */ 
/* 869:    */ 
/* 870:    */ 
/* 871:    */ 
/* 872:    */ 
/* 873:    */ 
/* 874:    */ 
/* 875:    */   protected static class DiagnosticsSeasonalityFactory<D extends SaDocument<? extends ISaSpecification>>
/* 876:    */     extends SaDocumentViewFactory.ItemFactory<D, SeasonalityTestUI.Information>
/* 877:    */   {
/* 878:    */     protected DiagnosticsSeasonalityFactory(Class<D> documentType)
/* 879:    */     {
/* 880:762 */       super(SaDocumentViewFactory.DIAGNOSTICS_SEASONALITY, new DefaultInformationExtractor()new SeasonalityTestUI
/* 881:    */       {
/* 882:    */         public SeasonalityTestUI.Information retrieve(D source)
/* 883:    */         {
/* 884:747 */           CompositeResults rslt = (CompositeResults)source.getResults();
/* 885:748 */           TsData seas = (TsData)rslt.getData("s_cmp", TsData.class);
/* 886:749 */           TsData i = (TsData)rslt.getData("i_cmp", TsData.class);
/* 887:    */           
/* 888:751 */           boolean mul = source.getFinalDecomposition().getMode().isMultiplicative();
/* 889:752 */           TsData si; TsData si; if (mul) {
/* 890:753 */             si = TsData.multiply(seas, i);
/* 891:    */           } else {
/* 892:755 */             si = TsData.add(seas, i);
/* 893:    */           }
/* 894:757 */           SeasonalityTestUI.Information info = new SeasonalityTestUI.Information();
/* 895:758 */           si = si;
/* 896:759 */           mul = mul;
/* 897:760 */           return info;
/* 898:    */         }
/* 899:762 */       }, new SeasonalityTestUI());
/* 900:    */     }
/* 901:    */   }
/* 902:    */   
/* 903:    */ 
/* 904:    */ 
/* 905:    */ 
/* 906:    */ 
/* 907:    */ 
/* 908:    */   protected static class DiagnosticsSlidingTdFactory<D extends SaDocument<? extends ISaSpecification>>
/* 909:    */     extends SaDocumentViewFactory.ItemFactory<D, SlidingSpans>
/* 910:    */   {
/* 911:    */     protected DiagnosticsSlidingTdFactory(Class<D> documentType)
/* 912:    */     {
/* 913:776 */       super(SaDocumentViewFactory.DIAGNOSTICS_SLIDING_TD, SaDocumentViewFactory.ssExtractor(), new SlidingSpansDetailUI("tde"));
/* 914:    */     }
/* 915:    */   }
/* 916:    */   
/* 917:    */   protected static class DiagnosticsSlidingSaFactory<D extends SaDocument<? extends ISaSpecification>> extends SaDocumentViewFactory.ItemFactory<D, SlidingSpans>
/* 918:    */   {
/* 919:    */     protected DiagnosticsSlidingSaFactory(Class<D> documentType)
/* 920:    */     {
/* 921:784 */       super(SaDocumentViewFactory.DIAGNOSTICS_SLIDING_SA, SaDocumentViewFactory.ssExtractor(), new SlidingSpansDetailUI("sa"));
/* 922:    */     }
/* 923:    */   }
/* 924:    */   
/* 925:    */   public static class ItemFactory<D extends SaDocument<? extends ISaSpecification>, I> extends ComposedProcDocumentItemFactory<D, I>
/* 926:    */   {
/* 927:    */     protected ItemFactory(Class<D> documentType, Id itemId, InformationExtractor<? super D, I> informationExtractor, ItemUI<? extends IProcDocumentView<D>, I> itemUI)
/* 928:    */     {
/* 929:792 */       super(itemId, informationExtractor, itemUI);
/* 930:    */     }
/* 931:    */   }
/* 932:    */   
/* 933:    */   private static class SpecExtractor
/* 934:    */     extends DefaultInformationExtractor<SaDocument<? extends ISaSpecification>, ISaSpecification>
/* 935:    */   {
/* 936:799 */     private static final SpecExtractor INSTANCE = new SpecExtractor();
/* 937:    */     
/* 938:    */     public ISaSpecification retrieve(SaDocument<? extends ISaSpecification> source)
/* 939:    */     {
/* 940:803 */       return (ISaSpecification)source.getSpecification();
/* 941:    */     }
/* 942:    */   }
/* 943:    */   
/* 944:    */   private static class SaExtractor extends DefaultInformationExtractor<SaDocument<? extends ISaSpecification>, CompositeResults>
/* 945:    */   {
/* 946:809 */     private static final SaExtractor INSTANCE = new SaExtractor();
/* 947:    */     
/* 948:    */     public CompositeResults retrieve(SaDocument<? extends ISaSpecification> source)
/* 949:    */     {
/* 950:813 */       return (CompositeResults)source.getResults();
/* 951:    */     }
/* 952:    */   }
/* 953:    */   
/* 954:    */   private static class PmExtractor extends DefaultInformationExtractor<SaDocument<? extends ISaSpecification>, PreprocessingModel>
/* 955:    */   {
/* 956:819 */     private static final PmExtractor INSTANCE = new PmExtractor();
/* 957:    */     
/* 958:    */     public PreprocessingModel retrieve(SaDocument<? extends ISaSpecification> source)
/* 959:    */     {
/* 960:823 */       return source.getPreprocessingPart();
/* 961:    */     }
/* 962:    */   }
/* 963:    */   
/* 964:    */   private static class ResExtractor extends DefaultInformationExtractor<SaDocument<? extends ISaSpecification>, TsData>
/* 965:    */   {
/* 966:829 */     private static final ResExtractor INSTANCE = new ResExtractor();
/* 967:    */     
/* 968:    */     public TsData retrieve(SaDocument<? extends ISaSpecification> source)
/* 969:    */     {
/* 970:833 */       PreprocessingModel preprocessing = source.getPreprocessingPart();
/* 971:834 */       return preprocessing == null ? null : preprocessing.getFullResiduals();
/* 972:    */     }
/* 973:    */   }
/* 974:    */   
/* 975:    */   private static class SsExtractor extends TsDocumentInformationExtractor<SaDocument<? extends ISaSpecification>, SlidingSpans>
/* 976:    */   {
/* 977:840 */     private static final SsExtractor INSTANCE = new SsExtractor();
/* 978:    */     
/* 979:    */     protected SlidingSpans buildInfo(SaDocument<? extends ISaSpecification> source)
/* 980:    */     {
/* 981:844 */       TsData s = source.getSeries();
/* 982:845 */       TsDomain domain = s.getDomain();
/* 983:846 */       SaDocument<? extends ISaSpecification> cl = SaManager.instance.refreshDocument(source, domain, EstimationPolicyType.FreeParameters, false);
/* 984:847 */       return new SlidingSpans(new TsDocumentProcessing(cl), domain);
/* 985:    */     }
/* 986:    */   }
/* 987:    */   
/* 988:    */   private static class RevisionExtractor extends TsDocumentInformationExtractor<SaDocument<? extends ISaSpecification>, RevisionHistory>
/* 989:    */   {
/* 990:853 */     private final DemetraUI demetraUI = DemetraUI.getDefault();
/* 991:854 */     private static final RevisionExtractor INSTANCE = new RevisionExtractor();
/* 992:    */     
/* 993:    */     protected RevisionHistory buildInfo(SaDocument<? extends ISaSpecification> source)
/* 994:    */     {
/* 995:858 */       SaDocumentProcessing process = new SaDocumentProcessing(source, demetraUI.getEstimationPolicyType());
/* 996:859 */       TsDomain d = getPreprocessingPart()description.getEstimationDomain();
/* 997:860 */       process.process(d);
/* 998:861 */       RevisionHistory history = new RevisionHistory(process, d);
/* 999:862 */       return history;
/* :00:    */     }
/* :01:    */   }
/* :02:    */   
/* :03:    */   private static class LikelihoodExtractor extends TsDocumentInformationExtractor<SaDocument<? extends ISaSpecification>, SurfacePlotterUI.Functions>
/* :04:    */   {
/* :05:868 */     public static final LikelihoodExtractor INSTANCE = new LikelihoodExtractor();
/* :06:    */     
/* :07:    */     protected SurfacePlotterUI.Functions buildInfo(SaDocument<? extends ISaSpecification> source)
/* :08:    */     {
/* :09:872 */       PreprocessingModel preprocessingPart = source.getPreprocessingPart();
/* :10:873 */       if (preprocessingPart == null) {
/* :11:874 */         return null;
/* :12:    */       }
/* :13:876 */       return SurfacePlotterUI.Functions.create(preprocessingPart.likelihoodFunction(), source.getPreprocessingPart().maxLikelihoodFunction());
/* :14:    */     }
/* :15:    */   }
/* :16:    */   
/* :17:    */   private static class MovingProcessingExtractor
/* :18:    */     extends TsDocumentInformationExtractor<SaDocument<? extends ISaSpecification>, MovingProcessing>
/* :19:    */   {
/* :20:883 */     private final DemetraUI demetraUI = DemetraUI.getDefault();
/* :21:884 */     private static final MovingProcessingExtractor INSTANCE = new MovingProcessingExtractor();
/* :22:    */     
/* :23:    */     protected MovingProcessing buildInfo(SaDocument<? extends ISaSpecification> source)
/* :24:    */     {
/* :25:888 */       SaDocumentProcessing process = new SaDocumentProcessing(source, demetraUI.getEstimationPolicyType());
/* :26:889 */       PreprocessingModel preprocessingPart = source.getPreprocessingPart();
/* :27:    */       TsDomain d;
/* :28:891 */       TsDomain d; if (preprocessingPart != null) {
/* :29:892 */         d = description.getEstimationDomain();
/* :30:    */       } else {
/* :31:894 */         d = source.getSeries().getDomain();
/* :32:    */       }
/* :33:896 */       process.process(d);
/* :34:897 */       MovingProcessing mm = new MovingProcessing(process, d);
/* :35:898 */       mm.setWindowLength(demetraUI.getStabilityLength().intValue() * mm.getWindowIncrement());
/* :36:    */       
/* :37:900 */       return mm;
/* :38:    */     }
/* :39:    */   }
/* :40:    */   
/* :41:    */   private static class SeasTestExtractor extends TsDocumentInformationExtractor<SaDocument<? extends ISaSpecification>, SeasonalityTestUI2.Information>
/* :42:    */   {
/* :43:906 */     private static final SeasTestExtractor OINSTANCE = new SeasTestExtractor("y");
/* :44:907 */     private static final SeasTestExtractor LINSTANCE = new SeasTestExtractor("l");
/* :45:908 */     private static final SeasTestExtractor RINSTANCE = new SeasTestExtractor("full_res");
/* :46:909 */     private static final SeasTestExtractor SAINSTANCE = new SeasTestExtractor("sa_cmp");
/* :47:910 */     private static final SeasTestExtractor IINSTANCE = new SeasTestExtractor("i_cmp");
/* :48:911 */     private static final SeasTestExtractor LASTRINSTANCE = new SeasTestExtractor("full_res", 10);
/* :49:912 */     private static final SeasTestExtractor LASTSAINSTANCE = new SeasTestExtractor("sa_cmp", 10);
/* :50:913 */     private static final SeasTestExtractor LASTIINSTANCE = new SeasTestExtractor("i_cmp", 10);
/* :51:    */     private final String name;
/* :52:    */     private final int nlast;
/* :53:    */     
/* :54:    */     protected SeasTestExtractor(String name)
/* :55:    */     {
/* :56:919 */       this.name = name;
/* :57:920 */       nlast = 0;
/* :58:    */     }
/* :59:    */     
/* :60:    */     protected SeasTestExtractor(String name, int nlast) {
/* :61:924 */       this.name = name;
/* :62:925 */       this.nlast = nlast;
/* :63:    */     }
/* :64:    */     
/* :65:    */ 
/* :66:    */     protected SeasonalityTestUI2.Information buildInfo(SaDocument<? extends ISaSpecification> source)
/* :67:    */     {
/* :68:931 */       SeasonalityTestUI2.Information info = new SeasonalityTestUI2.Information();
/* :69:932 */       mean = true;
/* :70:933 */       String str1; switch ((str1 = name).hashCode()) {case 99898480:  if (str1.equals("i_cmp")) break;  case 1331374832:  if ((goto 98) && (str1.equals("full_res")))
/* :71:    */         {
/* :72:935 */           del = 0;
/* :73:936 */           mean = false;
/* :74:    */           
/* :75:    */           break label108;
/* :76:939 */           del = 0;
/* :77:940 */           mean = true; }
/* :78:941 */         break;
/* :79:    */       }
/* :80:943 */       del = 1;
/* :81:944 */       mean = true;
/* :82:    */       
/* :83:    */       label108:
/* :84:947 */       PreprocessingModel preprocessingPart = source.getPreprocessingPart();
/* :85:948 */       if (preprocessingPart != null) { String str2;
/* :86:949 */         switch ((str2 = name).hashCode()) {case 121:  if (str2.equals("y")) break; break; case 1331374832:  if (!str2.equals("full_res")) {
/* :87:    */             break label219;
/* :88:951 */             s = description.transformedOriginal();
/* :89:952 */             mul = false;
/* :90:    */             break label293;
/* :91:    */           } else {
/* :92:955 */             s = preprocessingPart.getFullResiduals();
/* :93:956 */             mul = false; }
/* :94:957 */           break; }
/* :95:    */         label219:
/* :96:959 */         s = ((TsData)((CompositeResults)source.getResults()).getData(name, TsData.class));
/* :97:960 */         mul = preprocessingPart.isMultiplicative();
/* :98:    */       }
/* :99:    */       else
/* ;00:    */       {
/* ;01:964 */         s = ((TsData)((CompositeResults)source.getResults()).getData(name, TsData.class));
/* ;02:965 */         mul = source.getFinalDecomposition().getMode().isMultiplicative(); }
/* ;03:    */       label293:
/* ;04:967 */       if (s == null)
/* ;05:968 */         return null;
/* ;06:969 */       if (nlast != 0) {
/* ;07:970 */         TsPeriodSelector selector = new TsPeriodSelector();
/* ;08:971 */         selector.last(nlast * s.getFrequency().intValue());
/* ;09:972 */         s = s.select(selector);
/* ;10:    */       }
/* ;11:974 */       if (s.getLength() < 4 * s.getFrequency().intValue())
/* ;12:975 */         return null;
/* ;13:976 */       return info;
/* ;14:    */     }
/* ;15:    */   }
/* ;16:    */ }
