/*  1:   */ package ec.ui.view.tsprocessing.sa;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import ec.ui.view.SIView;
/*  5:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  6:   */ import ec.ui.view.tsprocessing.PooledItemUI;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class SiRatioUI<V extends IProcDocumentView<?>>
/* 15:   */   extends PooledItemUI<V, TsData[], SIView>
/* 16:   */ {
/* 17:   */   public SiRatioUI()
/* 18:   */   {
/* 19:19 */     super(SIView.class);
/* 20:   */   }
/* 21:   */   
/* 22:   */   protected void init(SIView c, V host, TsData[] information)
/* 23:   */   {
/* 24:24 */     if (information.length == 2) {
/* 25:25 */       c.setSiData(information[0], information[1]);
/* 26:26 */     } else if (information.length == 1) {
/* 27:27 */       c.setData(information[0]);
/* 28:   */     }
/* 29:   */   }
/* 30:   */ }
