/*  1:   */ package ec.ui.view.tsprocessing.sa;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tss.documents.DocumentManager;
/*  5:   */ import ec.tss.documents.TsDocument;
/*  6:   */ import ec.tstoolkit.algorithm.IProcResults;
/*  7:   */ import ec.tstoolkit.modelling.SeriesInfo;
/*  8:   */ import ec.ui.view.tsprocessing.DefaultItemUI;
/*  9:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/* 10:   */ import ec.ui.view.tsprocessing.ITsViewToolkit;
/* 11:   */ import java.util.Arrays;
/* 12:   */ import java.util.List;
/* 13:   */ import javax.swing.JComponent;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class SaTableUI<D extends TsDocument<?, ?>>
/* 23:   */   extends DefaultItemUI<IProcDocumentView<D>, IProcResults>
/* 24:   */ {
/* 25:   */   private final List<SeriesInfo> items_;
/* 26:   */   private final String prefix_;
/* 27:   */   private final List<String> names_;
/* 28:   */   
/* 29:   */   public SaTableUI(List<SeriesInfo> items, String prefix)
/* 30:   */   {
/* 31:31 */     items_ = items;
/* 32:32 */     names_ = null;
/* 33:33 */     prefix_ = prefix;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public SaTableUI(String... names) {
/* 37:37 */     names_ = Arrays.asList(names);
/* 38:38 */     items_ = null;
/* 39:39 */     prefix_ = null;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public JComponent getView(IProcDocumentView<D> host, IProcResults document)
/* 43:   */   {
/* 44:   */     TsCollection items;
/* 45:   */     TsCollection items;
/* 46:46 */     if (items_ != null) {
/* 47:47 */       items = DocumentManager.create(items_, host.getDocument(), prefix_, false);
/* 48:   */     } else {
/* 49:49 */       items = DocumentManager.create(names_, host.getDocument());
/* 50:   */     }
/* 51:   */     
/* 52:   */ 
/* 53:53 */     return host.getToolkit().getGrid(items.clean(true));
/* 54:   */   }
/* 55:   */ }
