/*  1:   */ package ec.ui.view.tsprocessing.sa;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlSeasonalityTest;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  6:   */ import ec.ui.view.tsprocessing.HtmlItemUI;
/*  7:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class SeasonalityTestUI<V extends IProcDocumentView<?>>
/* 17:   */   extends HtmlItemUI<V, Information>
/* 18:   */ {
/* 19:   */   protected IHtmlElement getHtmlElement(V host, Information information)
/* 20:   */   {
/* 21:21 */     return new HtmlSeasonalityTest(si, mul);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static class Information
/* 25:   */   {
/* 26:   */     public TsData si;
/* 27:   */     public boolean mul;
/* 28:   */   }
/* 29:   */ }
