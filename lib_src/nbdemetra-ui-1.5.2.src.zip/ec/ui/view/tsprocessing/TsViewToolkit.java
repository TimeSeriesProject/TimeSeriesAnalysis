/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ComponentFactory;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.html.HtmlUtil;
/*   7:    */ import ec.tss.html.IHtmlElement;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*   9:    */ import ec.tstoolkit.utilities.IPool;
/*  10:    */ import ec.tstoolkit.utilities.IPool.Factory;
/*  11:    */ import ec.tstoolkit.utilities.Pools;
/*  12:    */ import ec.ui.AHtmlView;
/*  13:    */ import ec.ui.ATsChart;
/*  14:    */ import ec.ui.ATsGrid;
/*  15:    */ import ec.ui.ATsGrowthChart;
/*  16:    */ import ec.ui.interfaces.IDisposable;
/*  17:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  18:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*  19:    */ import ec.ui.view.SpectralView;
/*  20:    */ import java.awt.BorderLayout;
/*  21:    */ import java.awt.Component;
/*  22:    */ import java.awt.Font;
/*  23:    */ import javax.swing.JComponent;
/*  24:    */ import javax.swing.JLabel;
/*  25:    */ import javax.swing.text.html.StyleSheet;
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ public final class TsViewToolkit
/*  45:    */   implements ITsViewToolkit
/*  46:    */ {
/*  47: 47 */   private static final TsViewToolkit INSTANCE = new TsViewToolkit();
/*  48:    */   private final IPool<ATsChart> chartPool;
/*  49:    */   private final IPool<ATsGrowthChart> growthchartPool;
/*  50:    */   private final IPool<ATsGrid> gridPool;
/*  51:    */   private final IPool<AHtmlView> htmlPool;
/*  52:    */   private StyleSheet styleSheet;
/*  53:    */   
/*  54:    */   private TsViewToolkit()
/*  55:    */   {
/*  56: 56 */     chartPool = Pools.on(new ChartFactory(null), 10);
/*  57: 57 */     growthchartPool = Pools.on(new GrowthChartFactory(null), 10);
/*  58: 58 */     gridPool = Pools.on(new GridFactory(null), 10);
/*  59: 59 */     htmlPool = Pools.on(new HtmlFactory(null), 10);
/*  60: 60 */     styleSheet = createStyleSheet(13, 13, 12, 12, 11, true);
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */   public static TsViewToolkit getInstance()
/*  66:    */   {
/*  67: 67 */     return INSTANCE;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public JComponent getGrid(Iterable<Ts> series)
/*  71:    */   {
/*  72: 72 */     final ATsGrid result = (ATsGrid)gridPool.getOrCreate();
/*  73: 73 */     result.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  74: 74 */     result.setMode(ITsGrid.Mode.MULTIPLETS);
/*  75: 75 */     result.getTsCollection().replace(series);
/*  76:    */     
/*  77: 77 */     new JDisposable(result)
/*  78:    */     {
/*  79:    */       public void dispose() {
/*  80: 80 */         gridPool.recycle(result);
/*  81:    */       }
/*  82:    */     };
/*  83:    */   }
/*  84:    */   
/*  85:    */   public JComponent getGrid(Ts series)
/*  86:    */   {
/*  87: 87 */     final ATsGrid result = (ATsGrid)gridPool.getOrCreate();
/*  88: 88 */     result.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  89: 89 */     result.setMode(ITsGrid.Mode.SINGLETS);
/*  90: 90 */     result.getTsCollection().replace(series);
/*  91:    */     
/*  92: 92 */     new JDisposable(result)
/*  93:    */     {
/*  94:    */       public void dispose() {
/*  95: 95 */         gridPool.recycle(result);
/*  96:    */       }
/*  97:    */     };
/*  98:    */   }
/*  99:    */   
/* 100:    */   public JComponent getChart(Iterable<Ts> series)
/* 101:    */   {
/* 102:102 */     final ATsChart result = (ATsChart)chartPool.getOrCreate();
/* 103:103 */     result.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 104:104 */     result.getTsCollection().replace(series);
/* 105:    */     
/* 106:106 */     new JDisposable(result)
/* 107:    */     {
/* 108:    */       public void dispose() {
/* 109:109 */         chartPool.recycle(result);
/* 110:    */       }
/* 111:    */     };
/* 112:    */   }
/* 113:    */   
/* 114:    */   public JComponent getGrowthChart(Iterable<Ts> series)
/* 115:    */   {
/* 116:116 */     final ATsGrowthChart result = (ATsGrowthChart)growthchartPool.getOrCreate();
/* 117:117 */     result.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 118:118 */     result.getTsCollection().replace(series);
/* 119:    */     
/* 120:120 */     new JDisposable(result)
/* 121:    */     {
/* 122:    */       public void dispose() {
/* 123:123 */         growthchartPool.recycle(result);
/* 124:    */       }
/* 125:    */     };
/* 126:    */   }
/* 127:    */   
/* 128:    */   public JComponent getHtmlViewer(IHtmlElement html)
/* 129:    */   {
/* 130:130 */     final AHtmlView result = (AHtmlView)htmlPool.getOrCreate();
/* 131:131 */     result.loadContent(HtmlUtil.toString(html));
/* 132:    */     
/* 133:133 */     new JDisposable(result)
/* 134:    */     {
/* 135:    */       public void dispose() {
/* 136:136 */         htmlPool.recycle(result);
/* 137:    */       }
/* 138:    */     };
/* 139:    */   }
/* 140:    */   
/* 141:    */   public JComponent getSpectralView(TsData s, boolean wn) {
/* 142:142 */     if (s == null) {
/* 143:143 */       return null;
/* 144:    */     }
/* 145:145 */     SpectralView spectrum = new SpectralView();
/* 146:146 */     spectrum.set(s, wn);
/* 147:147 */     return spectrum;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public JComponent getMessageViewer(String msg)
/* 151:    */   {
/* 152:152 */     JLabel result = new JLabel();
/* 153:153 */     result.setHorizontalAlignment(0);
/* 154:154 */     result.setFont(result.getFont().deriveFont(result.getFont().getSize2D() * 2.0F));
/* 155:155 */     result.setText("<html><center>" + msg);
/* 156:156 */     return result;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setStyleSheet(StyleSheet styleSheet) {
/* 160:160 */     this.styleSheet = styleSheet;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static StyleSheet createStyleSheet(int h1, int h2, int h3, int h4, int body, boolean tableBorder) {
/* 164:164 */     StyleSheet result = new StyleSheet();
/* 165:165 */     result.addRule("body {font-family: arial, verdana;}");
/* 166:166 */     result.addRule("body {font-size: " + Integer.toString(body) + ";}");
/* 167:167 */     result.addRule("h1 {font-size: " + Integer.toString(h1) + ";}");
/* 168:168 */     result.addRule("h2 {font-size: " + Integer.toString(h2) + ";}");
/* 169:169 */     result.addRule("h3 {font-size: " + Integer.toString(h3) + ";}");
/* 170:170 */     result.addRule("h4 {font-size: " + Integer.toString(h4) + ";}");
/* 171:    */     
/* 172:172 */     result.addRule("td, th{text-align: right; margin-left: 5px; margin-right: 5 px");
/* 173:173 */     if (tableBorder) {
/* 174:174 */       result.addRule("table {border-style: outset;}");
/* 175:    */     }
/* 176:176 */     return result;
/* 177:    */   }
/* 178:    */   
/* 179:    */   static abstract class JDisposable extends JComponent implements IDisposable
/* 180:    */   {
/* 181:    */     JDisposable(Component c) {
/* 182:182 */       setLayout(new BorderLayout());
/* 183:183 */       add(c, "Center");
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   private static abstract class DisposableFactory<T extends IDisposable> implements IPool.Factory<T>
/* 188:    */   {
/* 189:    */     public void destroy(T o)
/* 190:    */     {
/* 191:191 */       o.dispose();
/* 192:    */     }
/* 193:    */     
/* 194:    */     public void reset(T o) {}
/* 195:    */   }
/* 196:    */   
/* 197:    */   private static class ChartFactory extends TsViewToolkit.DisposableFactory<ATsChart> {
/* 198:    */     private ChartFactory() {
/* 199:199 */       super();
/* 200:    */     }
/* 201:    */     
/* 202:    */ 
/* 203:203 */     public ATsChart create() { return ComponentFactory.getDefault().newTsChart(); }
/* 204:    */   }
/* 205:    */   
/* 206:    */   private static class GrowthChartFactory extends TsViewToolkit.DisposableFactory<ATsGrowthChart> {
/* 207:207 */     private GrowthChartFactory() { super(); }
/* 208:    */     
/* 209:    */ 
/* 210:    */ 
/* 211:211 */     public ATsGrowthChart create() { return ComponentFactory.getDefault().newTsGrowthChart(); }
/* 212:    */   }
/* 213:    */   
/* 214:    */   private static class GridFactory extends TsViewToolkit.DisposableFactory<ATsGrid> {
/* 215:215 */     private GridFactory() { super(); }
/* 216:    */     
/* 217:    */ 
/* 218:    */ 
/* 219:219 */     public ATsGrid create() { return ComponentFactory.getDefault().newTsGrid(); }
/* 220:    */   }
/* 221:    */   
/* 222:    */   private static class HtmlFactory extends TsViewToolkit.DisposableFactory<AHtmlView> {
/* 223:223 */     private HtmlFactory() { super(); }
/* 224:    */     
/* 225:    */     public AHtmlView create()
/* 226:    */     {
/* 227:227 */       return ComponentFactory.getDefault().newHtmlView();
/* 228:    */     }
/* 229:    */   }
/* 230:    */ }
