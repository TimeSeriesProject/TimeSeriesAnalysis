/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  4:   */ import ec.tstoolkit.timeseries.analysis.MovingProcessing;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  6:   */ import ec.ui.view.StabilityView;
/*  7:   */ import java.util.Map;
/*  8:   */ import java.util.Map.Entry;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class StabilityUI<V extends IProcDocumentView<?>>
/* 29:   */   extends PooledItemUI<V, MovingProcessing, StabilityView>
/* 30:   */ {
/* 31:   */   private String node;
/* 32:   */   private final String[] items;
/* 33:   */   
/* 34:   */   public StabilityUI(String node, String[] items)
/* 35:   */   {
/* 36:36 */     super(StabilityView.class);
/* 37:37 */     this.node = node;
/* 38:38 */     this.items = items;
/* 39:   */   }
/* 40:   */   
/* 41:   */   protected void init(StabilityView c, V host, MovingProcessing information)
/* 42:   */   {
/* 43:43 */     c.reset();
/* 44:44 */     boolean empty = true;
/* 45:45 */     for (int i = 0; i < items.length; i++) {
/* 46:46 */       Map<TsDomain, Double> movingInfo = information.movingInfo(items[i]);
/* 47:47 */       if (isDefined(movingInfo)) {
/* 48:48 */         empty = false;
/* 49:49 */         c.add(items[i], movingInfo, null, false);
/* 50:   */       }
/* 51:   */     }
/* 52:52 */     if (empty)
/* 53:53 */       switch ((i = node).hashCode()) {case 63529420:  if (i.equals("Arima")) {} break; case 1454308374:  if (i.equals("Trading days")) break; break; case 2068533642:  if (!i.equals("Easter"))
/* 54:   */         {
/* 55:55 */           return;c.showException("No information available on trading days !");
/* 56:   */         }
/* 57:   */         else {
/* 58:58 */           c.showException("No information available on easter effects !");
/* 59:59 */           return;
/* 60:   */           
/* 61:61 */           c.showException("No information available !");
/* 62:   */         }
/* 63:   */         break; } else {
/* 64:64 */       c.display();
/* 65:   */     }
/* 66:   */   }
/* 67:   */   
/* 68:   */   private boolean isDefined(Map<TsDomain, Double> data) {
/* 69:69 */     if ((data == null) || (data.isEmpty())) {
/* 70:70 */       return false;
/* 71:   */     }
/* 72:   */     
/* 73:73 */     for (Map.Entry<TsDomain, Double> d : data.entrySet()) {
/* 74:74 */       if (DescriptiveStatistics.isFinite(((Double)d.getValue()).doubleValue())) {
/* 75:75 */         return true;
/* 76:   */       }
/* 77:   */     }
/* 78:78 */     return false;
/* 79:   */   }
/* 80:   */ }
