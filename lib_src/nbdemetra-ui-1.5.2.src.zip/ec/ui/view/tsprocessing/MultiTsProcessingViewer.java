/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tss.documents.MultiTsDocument;
/*  5:   */ import ec.tstoolkit.algorithm.IProcSpecification;
/*  6:   */ import ec.ui.list.JTsList;
/*  7:   */ import java.awt.Font;
/*  8:   */ import java.beans.PropertyChangeEvent;
/*  9:   */ import java.beans.PropertyChangeListener;
/* 10:   */ import javax.swing.Box;
/* 11:   */ import javax.swing.JLabel;
/* 12:   */ import javax.swing.JToolBar;
/* 13:   */ import javax.swing.JToolBar.Separator;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class MultiTsProcessingViewer
/* 22:   */   extends DefaultProcessingViewer<MultiTsDocument>
/* 23:   */ {
/* 24:   */   public static MultiTsProcessingViewer create(MultiTsDocument doc)
/* 25:   */   {
/* 26:26 */     MultiTsProcessingViewer viewer = new MultiTsProcessingViewer(DefaultProcessingViewer.Type.APPLY);
/* 27:27 */     if (doc != null) {
/* 28:28 */       viewer.setDocument(doc);
/* 29:   */     }
/* 30:30 */     return viewer;
/* 31:   */   }
/* 32:   */   
/* 33:   */ 
/* 34:34 */   private static final Font DROP_DATA_FONT = new JLabel().getFont().deriveFont(2);
/* 35:   */   private final JTsList tsList;
/* 36:   */   private final JLabel specLabel;
/* 37:   */   private boolean quietRefresh;
/* 38:   */   
/* 39:   */   public MultiTsProcessingViewer(DefaultProcessingViewer.Type type)
/* 40:   */   {
/* 41:41 */     super(type);
/* 42:42 */     tsList = new JTsList();
/* 43:43 */     tsList.setVisible(true);
/* 44:44 */     specLabel = new JLabel("Spec: ");
/* 45:45 */     specLabel.setVisible(true);
/* 46:   */     
/* 47:47 */     toolBar.add(Box.createHorizontalStrut(3), 0);
/* 48:48 */     toolBar.add(tsList, 2);
/* 49:49 */     toolBar.add(new JToolBar.Separator(), 3);
/* 50:50 */     toolBar.add(specLabel, 4);
/* 51:   */     
/* 52:52 */     tsList.addPropertyChangeListener("tsCollection", new PropertyChangeListener()
/* 53:   */     {
/* 54:   */       public void propertyChange(PropertyChangeEvent evt) {
/* 55:55 */         if (!quietRefresh) {
/* 56:56 */           ((MultiTsDocument)getDocument()).setInput(tsList.getTsCollection().toArray());
/* 57:   */         }
/* 58:   */       }
/* 59:   */     });
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void refreshHeader()
/* 63:   */   {
/* 64:   */     try {
/* 65:65 */       MultiTsDocument doc = (MultiTsDocument)getDocument();
/* 66:66 */       IProcSpecification spec = doc.getSpecification();
/* 67:67 */       specLabel.setText("Spec: " + (spec != null ? spec.toString() : ""));
/* 68:68 */       quietRefresh = true;
/* 69:69 */       tsList.getTsCollection().replace(doc.getTs());
/* 70:   */     }
/* 71:   */     catch (Exception localException) {}finally {
/* 72:72 */       quietRefresh = false;
/* 73:   */     }
/* 74:   */   }
/* 75:   */ }
