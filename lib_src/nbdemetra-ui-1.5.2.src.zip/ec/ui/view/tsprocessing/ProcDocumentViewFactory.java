/*   1:    */ package ec.ui.view.tsprocessing;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Iterables;
/*   4:    */ import com.google.common.collect.Lists;
/*   5:    */ import com.google.common.collect.Maps;
/*   6:    */ import ec.tstoolkit.algorithm.IProcDocument;
/*   7:    */ import ec.tstoolkit.utilities.DefaultInformationExtractor;
/*   8:    */ import ec.tstoolkit.utilities.Id;
/*   9:    */ import ec.tstoolkit.utilities.InformationExtractor;
/*  10:    */ import java.util.LinkedHashMap;
/*  11:    */ import java.util.List;
/*  12:    */ import javax.annotation.Nonnull;
/*  13:    */ import javax.annotation.Nullable;
/*  14:    */ import javax.swing.Action;
/*  15:    */ import javax.swing.Icon;
/*  16:    */ import javax.swing.JComponent;
/*  17:    */ import org.openide.util.Lookup;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ public abstract class ProcDocumentViewFactory<D extends IProcDocument>
/*  25:    */   implements IProcDocumentViewFactory<D>
/*  26:    */ {
/*  27:    */   public class View
/*  28:    */     implements IProcDocumentView<D>
/*  29:    */   {
/*  30:    */     private final D document_;
/*  31:    */     
/*  32:    */     public View()
/*  33:    */     {
/*  34: 34 */       document_ = document;
/*  35:    */     }
/*  36:    */     
/*  37:    */     public ITsViewToolkit getToolkit()
/*  38:    */     {
/*  39: 39 */       return toolkit_;
/*  40:    */     }
/*  41:    */     
/*  42:    */     @Deprecated
/*  43:    */     public ItemUI getUI(Id id) {
/*  44: 44 */       return ProcDocumentViewFactory.this.getUI(id);
/*  45:    */     }
/*  46:    */     
/*  47:    */     @Deprecated
/*  48:    */     @Nullable
/*  49:    */     public InformationExtractor<? super D, ?> getExtractor(Id id) {
/*  50: 50 */       return ProcDocumentViewFactory.this.getExtractor(id);
/*  51:    */     }
/*  52:    */     
/*  53:    */     @Deprecated
/*  54:    */     protected Object getInformation(Id id) {
/*  55: 55 */       InformationExtractor extractor = getExtractor(id);
/*  56: 56 */       return extractor != null ? extractor.retrieve(document_) : document_;
/*  57:    */     }
/*  58:    */     
/*  59:    */     public JComponent getView(Id path)
/*  60:    */     {
/*  61: 61 */       if ((document_ == null) || (document_.getResults() == null)) {
/*  62: 62 */         return null;
/*  63:    */       }
/*  64: 64 */       ProcDocumentItemFactory itemFactory = (ProcDocumentItemFactory)itemFactories.get(path);
/*  65: 65 */       return itemFactory != null ? itemFactory.getView(this, document_) : null;
/*  66:    */     }
/*  67:    */     
/*  68:    */     public List<Id> getItems()
/*  69:    */     {
/*  70: 70 */       return ProcDocumentViewFactory.this.getItems();
/*  71:    */     }
/*  72:    */     
/*  73:    */     public Icon getIcon(Id path)
/*  74:    */     {
/*  75: 75 */       return ProcDocumentViewFactory.this.getIcon(path);
/*  76:    */     }
/*  77:    */     
/*  78:    */     public void refresh()
/*  79:    */     {
/*  80: 80 */       for (ComposedProcDocumentItemFactory o : Iterables.filter(itemFactories.values(), ComposedProcDocumentItemFactory.class)) {
/*  81: 81 */         o.getInformationExtractor().flush(document_);
/*  82:    */       }
/*  83:    */     }
/*  84:    */     
/*  85:    */     public void dispose()
/*  86:    */     {
/*  87: 87 */       refresh();
/*  88:    */     }
/*  89:    */     
/*  90:    */     public D getDocument()
/*  91:    */     {
/*  92: 92 */       return document_;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public Action[] getActions(Id path)
/*  96:    */     {
/*  97: 97 */       return ProcDocumentViewFactory.this.getActions(path);
/*  98:    */     }
/*  99:    */     
/* 100:    */     public Id getPreferredView()
/* 101:    */     {
/* 102:102 */       return ProcDocumentViewFactory.this.getPreferredView();
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:106 */   private final LinkedHashMap<Id, ProcDocumentItemFactory> itemFactories = Maps.newLinkedHashMap();
/* 107:107 */   private ITsViewToolkit toolkit_ = TsViewToolkit.getInstance();
/* 108:    */   
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */   protected void registerFromLookup(Class<D> documentType)
/* 115:    */   {
/* 116:116 */     for (ProcDocumentItemFactory o : Lookup.getDefault().lookupAll(ProcDocumentItemFactory.class)) {
/* 117:117 */       if (o.getDocumentType().isAssignableFrom(documentType)) {
/* 118:118 */         itemFactories.put(o.getItemId(), o);
/* 119:    */       }
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public Icon getIcon(Id id) {
/* 124:124 */     ProcDocumentItemFactory o = (ProcDocumentItemFactory)itemFactories.get(id);
/* 125:125 */     return (o instanceof ComposedProcDocumentItemFactory) ? ((ComposedProcDocumentItemFactory)o).getIcon() : null;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public abstract Id getPreferredView();
/* 129:    */   
/* 130:    */   public Action[] getActions(Id path) {
/* 131:131 */     ProcDocumentItemFactory o = (ProcDocumentItemFactory)itemFactories.get(path);
/* 132:132 */     return (o instanceof ComposedProcDocumentItemFactory) ? ((ComposedProcDocumentItemFactory)o).getActions() : null;
/* 133:    */   }
/* 134:    */   
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:    */   @Deprecated
/* 139:    */   public <I> void register(Id id, InformationExtractor<? super D, I> info, ItemUI<? extends IProcDocumentView<D>, I> ui)
/* 140:    */   {
/* 141:141 */     itemFactories.put(id, new ComposedProcDocumentItemFactory(IProcDocument.class, id, info != null ? info : new DoNothingExtractor(), ui));
/* 142:    */   }
/* 143:    */   
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */   @Deprecated
/* 148:    */   public void unregister(Id id)
/* 149:    */   {
/* 150:150 */     itemFactories.remove(id);
/* 151:    */   }
/* 152:    */   
/* 153:    */ 
/* 154:    */ 
/* 155:    */   @Deprecated
/* 156:    */   public void unregisterAll()
/* 157:    */   {
/* 158:158 */     itemFactories.clear();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void registerToolkit(@Nullable ITsViewToolkit toolkit) {
/* 162:162 */     toolkit_ = (toolkit != null ? toolkit : TsViewToolkit.getInstance());
/* 163:    */   }
/* 164:    */   
/* 165:    */   @Nonnull
/* 166:    */   public ITsViewToolkit getToolkit() {
/* 167:167 */     return toolkit_;
/* 168:    */   }
/* 169:    */   
/* 170:    */   @Nonnull
/* 171:    */   public List<Id> getItems() {
/* 172:172 */     return Lists.newArrayList(itemFactories.keySet());
/* 173:    */   }
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */   @Deprecated
/* 178:    */   @Nullable
/* 179:    */   public ItemUI<? extends IProcDocumentView<D>, ?> getUI(Id id)
/* 180:    */   {
/* 181:181 */     ProcDocumentItemFactory o = (ProcDocumentItemFactory)itemFactories.get(id);
/* 182:182 */     return (o instanceof ComposedProcDocumentItemFactory) ? ((ComposedProcDocumentItemFactory)o).getItemUI() : null;
/* 183:    */   }
/* 184:    */   
/* 185:    */ 
/* 186:    */ 
/* 187:    */   @Deprecated
/* 188:    */   @Nullable
/* 189:    */   public InformationExtractor<? super D, ?> getExtractor(Id id)
/* 190:    */   {
/* 191:191 */     ProcDocumentItemFactory o = (ProcDocumentItemFactory)itemFactories.get(id);
/* 192:192 */     return (o instanceof ComposedProcDocumentItemFactory) ? ((ComposedProcDocumentItemFactory)o).getInformationExtractor() : null;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public final IProcDocumentView<D> create(D document)
/* 196:    */   {
/* 197:197 */     return new View(document);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static class DoNothingExtractor<S>
/* 201:    */     extends DefaultInformationExtractor<S, S>
/* 202:    */   {
/* 203:    */     public S retrieve(S source)
/* 204:    */     {
/* 205:205 */       return source;
/* 206:    */     }
/* 207:    */   }
/* 208:    */ }
