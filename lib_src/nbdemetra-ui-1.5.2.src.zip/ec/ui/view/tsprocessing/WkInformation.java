package ec.ui.view.tsprocessing;

import ec.satoolkit.ComponentDescriptor;
import ec.tstoolkit.timeseries.simplets.TsFrequency;
import ec.tstoolkit.ucarima.WienerKolmogorovEstimators;

public class WkInformation
{
  public WienerKolmogorovEstimators estimators;
  public ComponentDescriptor[] descriptors;
  public TsFrequency frequency;
}
