/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.analysis.RevisionHistory;
/*  4:   */ import ec.ui.view.RevisionSaSeriesView;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public class RevisionHistoryUI<V extends IProcDocumentView<?>>
/* 25:   */   extends PooledItemUI<V, RevisionHistory, RevisionSaSeriesView>
/* 26:   */ {
/* 27:   */   private String info;
/* 28:   */   
/* 29:   */   public RevisionHistoryUI()
/* 30:   */   {
/* 31:31 */     super(RevisionSaSeriesView.class);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public RevisionHistoryUI(String info) {
/* 35:35 */     super(RevisionSaSeriesView.class);
/* 36:36 */     this.info = info;
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected void init(RevisionSaSeriesView c, V host, RevisionHistory information)
/* 40:   */   {
/* 41:41 */     c.setInfo(info);
/* 42:42 */     c.setHistory(information);
/* 43:   */   }
/* 44:   */ }
