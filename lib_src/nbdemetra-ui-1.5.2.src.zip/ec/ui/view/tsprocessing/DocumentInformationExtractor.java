/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Objects;
/*  4:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  5:   */ import ec.tstoolkit.utilities.InformationExtractor;
/*  6:   */ import java.util.HashMap;
/*  7:   */ import java.util.concurrent.atomic.AtomicInteger;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public abstract class DocumentInformationExtractor<D extends IProcDocument<?, ?, ?>, I>
/* 17:   */   implements InformationExtractor<D, I>
/* 18:   */ {
/* 19:19 */   private static final AtomicInteger gid_ = new AtomicInteger(0);
/* 20:   */   private final int id_;
/* 21:   */   
/* 22:   */   protected DocumentInformationExtractor() {
/* 23:23 */     id_ = gid_.incrementAndGet();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public I retrieve(D source)
/* 27:   */   {
/* 28:28 */     long doc = source.getKey();
/* 29:29 */     Key key = new Key(doc, id_);
/* 30:30 */     I info = null;
/* 31:31 */     synchronized (cache_) {
/* 32:32 */       info = cache_.get(key);
/* 33:33 */       if (info == null) {
/* 34:34 */         info = buildInfo(source);
/* 35:35 */         cache_.put(key, info);
/* 36:   */       }
/* 37:   */     }
/* 38:38 */     return info;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void flush(D source)
/* 42:   */   {
/* 43:43 */     long doc = source.getKey();
/* 44:44 */     synchronized (cache_) {
/* 45:45 */       cache_.remove(new Key(doc, id_));
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */ 
/* 50:50 */   private static final HashMap<Key, Object> cache_ = new HashMap();
/* 51:   */   
/* 52:   */   protected abstract I buildInfo(D paramD);
/* 53:   */   
/* 54:   */   private static class Key implements Comparable<Key> {
/* 55:55 */     Key(long doc, int id) { this.doc = doc;
/* 56:56 */       this.id = id;
/* 57:   */     }
/* 58:   */     
/* 59:   */     long doc;
/* 60:   */     int id;
/* 61:   */     public int compareTo(Key o)
/* 62:   */     {
/* 63:63 */       if (id == id) {
/* 64:64 */         if (doc == doc) {
/* 65:65 */           return 0;
/* 66:   */         }
/* 67:67 */         if (doc < doc) {
/* 68:68 */           return -1;
/* 69:   */         }
/* 70:   */         
/* 71:71 */         return 1;
/* 72:   */       }
/* 73:   */       
/* 74:74 */       if (id < id) {
/* 75:75 */         return -1;
/* 76:   */       }
/* 77:   */       
/* 78:78 */       return 1;
/* 79:   */     }
/* 80:   */     
/* 81:   */ 
/* 82:   */     public boolean equals(Object obj)
/* 83:   */     {
/* 84:84 */       return (this == obj) || (((obj instanceof Key)) && (equals((Key)obj)));
/* 85:   */     }
/* 86:   */     
/* 87:   */     private boolean equals(Key other) {
/* 88:88 */       return (id == id) && (doc == doc);
/* 89:   */     }
/* 90:   */     
/* 91:   */     public int hashCode()
/* 92:   */     {
/* 93:93 */       return Objects.hashCode(new Object[] { Long.valueOf(doc), Integer.valueOf(id) });
/* 94:   */     }
/* 95:   */   }
/* 96:   */ }
