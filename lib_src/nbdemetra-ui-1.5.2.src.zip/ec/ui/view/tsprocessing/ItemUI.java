package ec.ui.view.tsprocessing;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JMenu;

public abstract interface ItemUI<H, I>
{
  public abstract JComponent getView(H paramH, I paramI);
  
  public abstract boolean fillMenu(JMenu paramJMenu, H paramH, I paramI);
  
  public abstract Icon getIcon(H paramH, I paramI);
}
