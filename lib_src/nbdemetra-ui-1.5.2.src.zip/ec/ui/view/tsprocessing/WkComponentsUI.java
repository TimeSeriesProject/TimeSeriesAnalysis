/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.ui.view.wk.ComponentsView;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class WkComponentsUI<V extends IProcDocumentView<?>>
/* 16:   */   extends DefaultItemUI<V, WkInformation>
/* 17:   */ {
/* 18:   */   public JComponent getView(V host, WkInformation information)
/* 19:   */   {
/* 20:20 */     return new ComponentsView(estimators, descriptors, frequency);
/* 21:   */   }
/* 22:   */ }
