/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  4:   */ import ec.tstoolkit.utilities.IPool;
/*  5:   */ import ec.tstoolkit.utilities.Pools;
/*  6:   */ import ec.ui.interfaces.IDisposable;
/*  7:   */ import ec.ui.view.MarginView;
/*  8:   */ import java.awt.BorderLayout;
/*  9:   */ import java.awt.Component;
/* 10:   */ import java.util.Date;
/* 11:   */ import javax.swing.JComponent;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class EstimationUI<V extends IProcDocumentView<?>>
/* 22:   */   extends DefaultItemUI<V, Information>
/* 23:   */ {
/* 24:24 */   private final IPool<MarginView> pool = Pools.on(MarginView.class, 10);
/* 25:   */   
/* 26:   */   public JComponent getView(V host, Information information)
/* 27:   */   {
/* 28:28 */     if (original == null) {
/* 29:29 */       return null;
/* 30:   */     }
/* 31:31 */     final MarginView view = (MarginView)pool.getOrCreate();
/* 32:32 */     view.setData(original.update(fcasts), lfcasts, ufcasts, markers);
/* 33:33 */     new JDisposable(view)
/* 34:   */     {
/* 35:   */ 
/* 36:36 */       public void dispose() { pool.recycle(view); } }; }
/* 37:   */   
/* 38:   */   public static class Information { final TsData original;
/* 39:   */     final TsData fcasts;
/* 40:   */     final TsData lfcasts;
/* 41:   */     final TsData ufcasts;
/* 42:   */     public Date[] markers;
/* 43:   */     
/* 44:44 */     public Information(TsData o, TsData f, TsData l, TsData u) { original = o;
/* 45:45 */       fcasts = f;
/* 46:46 */       lfcasts = l;
/* 47:47 */       ufcasts = u;
/* 48:   */     }
/* 49:   */     
/* 50:   */     public Information(TsData o, TsData f, TsData ef, double c) {
/* 51:51 */       original = o;
/* 52:52 */       fcasts = f;
/* 53:53 */       TsData e = ef.times(c);
/* 54:54 */       lfcasts = TsData.subtract(f, e);
/* 55:55 */       ufcasts = TsData.add(f, e);
/* 56:   */     }
/* 57:   */   }
/* 58:   */   
/* 59:   */ 
/* 60:   */   private static abstract class JDisposable
/* 61:   */     extends JComponent
/* 62:   */     implements IDisposable
/* 63:   */   {
/* 64:   */     JDisposable(Component c)
/* 65:   */     {
/* 66:66 */       setLayout(new BorderLayout());
/* 67:67 */       add(c, "Center");
/* 68:   */     }
/* 69:   */   }
/* 70:   */ }
