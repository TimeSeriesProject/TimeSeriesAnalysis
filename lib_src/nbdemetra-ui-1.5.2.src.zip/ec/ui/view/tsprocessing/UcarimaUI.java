/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.html.IHtmlElement;
/*  4:   */ import ec.tss.html.implementation.HtmlUcarima;
/*  5:   */ import ec.tstoolkit.arima.ArimaModel;
/*  6:   */ import ec.tstoolkit.arima.IArimaModel;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class UcarimaUI<V extends IProcDocumentView<?>>
/* 16:   */   extends HtmlItemUI<V, Information>
/* 17:   */ {
/* 18:   */   protected IHtmlElement getHtmlElement(V host, Information information)
/* 19:   */   {
/* 20:20 */     return new HtmlUcarima(model, cmps, names);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static class Information
/* 24:   */   {
/* 25:   */     public IArimaModel model;
/* 26:   */     public ArimaModel[] cmps;
/* 27:   */     public String[] names;
/* 28:   */   }
/* 29:   */ }
