/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import ec.tss.TsCollection;
/*  4:   */ import ec.tss.TsFactory;
/*  5:   */ import ec.tstoolkit.data.DataBlock;
/*  6:   */ import ec.tstoolkit.modelling.arima.ModelDescription;
/*  7:   */ import ec.tstoolkit.modelling.arima.PreprocessingModel;
/*  8:   */ import ec.tstoolkit.timeseries.regression.ITsVariable;
/*  9:   */ import ec.tstoolkit.timeseries.regression.TsVariableList;
/* 10:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/* 11:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/* 12:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/* 13:   */ import java.util.ArrayList;
/* 14:   */ import javax.swing.JComponent;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class RegressorsUI<V extends IProcDocumentView<?>>
/* 23:   */   extends DefaultItemUI<V, PreprocessingModel>
/* 24:   */ {
/* 25:   */   public JComponent getView(V host, PreprocessingModel information)
/* 26:   */   {
/* 27:27 */     TsCollection items = createRegressors(information);
/* 28:28 */     return host.getToolkit().getGrid(items);
/* 29:   */   }
/* 30:   */   
/* 31:   */   private TsCollection createRegressors(PreprocessingModel information) {
/* 32:32 */     TsCollection collection = TsFactory.instance.createTsCollection();
/* 33:33 */     TsDomain edomain = description.getSeriesDomain();
/* 34:34 */     TsPeriod start = edomain.getStart();
/* 35:35 */     int n = edomain.getLength();
/* 36:36 */     TsVariableList list = description.buildRegressionVariables();
/* 37:37 */     ITsVariable[] vars = list.items();
/* 38:38 */     if (vars != null) {
/* 39:39 */       for (int i = 0; i < vars.length; i++) {
/* 40:40 */         ITsVariable cur = vars[i];
/* 41:41 */         int dim = cur.getDim();
/* 42:42 */         ArrayList<DataBlock> tmp = new ArrayList();
/* 43:43 */         for (int j = 0; j < dim; j++) {
/* 44:44 */           tmp.add(new DataBlock(n));
/* 45:   */         }
/* 46:46 */         cur.data(edomain, tmp);
/* 47:47 */         for (int j = 0; j < dim; j++) {
/* 48:48 */           collection.quietAdd(TsFactory.instance.createTs(cur.getItemDescription(j), null, new TsData(start, ((DataBlock)tmp.get(j)).getData(), false)));
/* 49:   */         }
/* 50:   */       }
/* 51:   */     }
/* 52:52 */     return collection;
/* 53:   */   }
/* 54:   */ }
