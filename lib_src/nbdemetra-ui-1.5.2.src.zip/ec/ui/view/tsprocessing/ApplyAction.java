/*  1:   */ package ec.ui.view.tsprocessing;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import javax.swing.AbstractAction;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ @Deprecated
/* 14:   */ public abstract class ApplyAction
/* 15:   */   implements IApplyAction
/* 16:   */ {
/* 17:   */   private static final String APPLY = "Apply";
/* 18:   */   private final String name_;
/* 19:   */   
/* 20:   */   public ApplyAction(String name)
/* 21:   */   {
/* 22:22 */     name_ = name;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public ApplyAction() {
/* 26:26 */     name_ = "Apply";
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getActionName()
/* 30:   */   {
/* 31:31 */     return name_;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static AbstractAction toSwingAction(final IApplyAction action) {
/* 35:35 */     new AbstractAction(action.getActionName())
/* 36:   */     {
/* 37:   */       public void actionPerformed(ActionEvent e) {
/* 38:38 */         action.apply();
/* 39:   */       }
/* 40:   */     };
/* 41:   */   }
/* 42:   */ }
