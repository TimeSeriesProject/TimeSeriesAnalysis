/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.tstoolkit.data.AutoRegressiveSpectrum;
/*   5:    */ import ec.tstoolkit.data.DataBlock;
/*   6:    */ import ec.tstoolkit.data.Values;
/*   7:    */ import java.beans.PropertyChangeEvent;
/*   8:    */ import java.beans.PropertyChangeListener;
/*   9:    */ import org.jfree.data.xy.XYSeries;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ public class AutoRegressiveSpectrumView
/*  23:    */   extends ARPView
/*  24:    */ {
/*  25: 25 */   private int lag = 1; private int del = 1;
/*  26: 26 */   private boolean log = false;
/*  27:    */   
/*  28:    */   public static final String LOG_PROPERTY = "logTransformation";
/*  29:    */   
/*  30:    */   public static final String DIFF_PROPERTY = "differencing";
/*  31:    */   
/*  32:    */   public static final String DIFF_LAG_PROPERTY = "differencingLag";
/*  33:    */   public static final String AR_COUNT_PROPERTY = "arCount";
/*  34:    */   public static final String RESOLUTION_PROPERTY = "resolution";
/*  35:    */   public static final String LASTYEARS_PROPERTY = "lastYears";
/*  36:    */   private int lastYears;
/*  37:    */   
/*  38:    */   public AutoRegressiveSpectrumView()
/*  39:    */   {
/*  40: 40 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  41: 41 */     lastYears = demetraUI.getSpectralLastYears().intValue();
/*  42:    */     
/*  43: 43 */     arcount = 0;
/*  44: 44 */     resolution = 5;
/*  45: 45 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  46:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  47:    */         String str;
/*  48: 48 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1600030548:  if (str.equals("resolution")) {} break; case -1379041160:  if (str.equals("differencingLag")) {} break; case -1196656966:  if (str.equals("differencing")) {} break; case -777434274:  if (str.equals("arCount")) break; break; case 1574730605:  if (str.equals("logTransformation")) {} break; case 2007313120:  if (!str.equals("lastYears"))
/*  49:    */           {
/*  50: 50 */             return;onArCountChange();
/*  51: 51 */             return;
/*  52:    */             
/*  53: 53 */             onFreqCountChange();
/*  54: 54 */             return;
/*  55:    */             
/*  56: 56 */             onLogChange();
/*  57: 57 */             return;
/*  58:    */             
/*  59: 59 */             onDiffChange();
/*  60: 60 */             return;
/*  61:    */             
/*  62: 62 */             onDiffChange();
/*  63:    */           }
/*  64:    */           else {
/*  65: 65 */             onLastYearsChange(); }
/*  66:    */           break; } } }); }
/*  67:    */   
/*  68:    */   private static final int DEFAULT_AR_COUNT = 0;
/*  69:    */   private static final int DEFAULT_RESOLUTION = 5;
/*  70:    */   private static final boolean DEFAULT_LOG = false;
/*  71:    */   private static final int DEFAULT_DIFF = 1;
/*  72:    */   
/*  73: 73 */   public boolean isLogTransformation() { return log; }
/*  74:    */   
/*  75:    */   private static final int DEFAULT_DIFF_LAG = 1;
/*  76:    */   
/*  77: 77 */   public void setLogTransformation(boolean log) { boolean old = this.log;
/*  78: 78 */     this.log = log;
/*  79: 79 */     firePropertyChange("logTransformation", old, this.log); }
/*  80:    */   
/*  81:    */   public static final int DEFAULT_LAST = 0;
/*  82:    */   
/*  83: 83 */   public int getDifferencingOrder() { return del; }
/*  84:    */   
/*  85:    */   protected int arcount;
/*  86:    */   protected int resolution;
/*  87: 87 */   public void setDifferencingOrder(int order) { if (order < 0) {
/*  88: 88 */       throw new IllegalArgumentException("Differencing order should be >=0.");
/*  89:    */     }
/*  90: 90 */     int old = del;
/*  91: 91 */     del = order;
/*  92: 92 */     firePropertyChange("differencing", old, del);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public int getLastYears() {
/*  96: 96 */     return lastYears;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setLastYears(int length) {
/* 100:100 */     if (length < 0) {
/* 101:101 */       throw new IllegalArgumentException("Last years should be >=0.");
/* 102:    */     }
/* 103:103 */     int old = lastYears;
/* 104:104 */     lastYears = length;
/* 105:105 */     firePropertyChange("differencing", old, lastYears);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public int getDifferencingLag() {
/* 109:109 */     return lag;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setDifferencingLag(int lag) {
/* 113:113 */     if (lag <= 0) {
/* 114:114 */       throw new IllegalArgumentException("Lag order should be >0.");
/* 115:    */     }
/* 116:116 */     int old = this.lag;
/* 117:117 */     this.lag = lag;
/* 118:118 */     firePropertyChange("differencingLag", old, this.lag);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public int getArCount() {
/* 122:122 */     return arcount;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setArCount(int count) {
/* 126:126 */     if (count < 0) {
/* 127:127 */       throw new IllegalArgumentException("AR count should be >0.");
/* 128:    */     }
/* 129:129 */     int old = arcount;
/* 130:130 */     arcount = count;
/* 131:131 */     firePropertyChange("arCount", old, arcount);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public int getResolution() {
/* 135:135 */     return resolution;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setResolution(int count) {
/* 139:139 */     if (count <= 0) {
/* 140:140 */       throw new IllegalArgumentException("Resolution should be strictly positive.");
/* 141:    */     }
/* 142:142 */     int old = resolution;
/* 143:143 */     resolution = count;
/* 144:144 */     firePropertyChange("resolution", old, resolution);
/* 145:    */   }
/* 146:    */   
/* 147:    */   protected void onArCountChange() {
/* 148:148 */     onARPDataChange();
/* 149:    */   }
/* 150:    */   
/* 151:    */   protected void onFreqCountChange() {
/* 152:152 */     onARPDataChange();
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected void onLogChange() {
/* 156:156 */     onARPDataChange();
/* 157:    */   }
/* 158:    */   
/* 159:    */   protected void onDiffChange() {
/* 160:160 */     onARPDataChange();
/* 161:    */   }
/* 162:    */   
/* 163:    */   protected void onDiffLagChange() {
/* 164:164 */     onARPDataChange();
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected void onLastYearsChange() {
/* 168:168 */     onARPDataChange();
/* 169:    */   }
/* 170:    */   
/* 171:    */   protected void onARPDataChange()
/* 172:    */   {
/* 173:173 */     super.onARPDataChange();
/* 174:174 */     if (data == null) {
/* 175:175 */       return;
/* 176:    */     }
/* 177:177 */     onColorSchemeChange();
/* 178:    */   }
/* 179:    */   
/* 180:    */   protected XYSeries computeSeries()
/* 181:    */   {
/* 182:182 */     Values val = data.values.clone();
/* 183:183 */     if (log) {
/* 184:184 */       val.log();
/* 185:    */     }
/* 186:186 */     if (del > 0) {
/* 187:187 */       double[] s = new double[val.getLength()];
/* 188:188 */       val.copyTo(s, 0);
/* 189:189 */       for (int i = 0; i < del; i++) {
/* 190:190 */         for (int j = s.length - 1; j >= (i + 1) * lag; j--) {
/* 191:191 */           s[j] -= s[(j - lag)];
/* 192:    */         }
/* 193:    */       }
/* 194:194 */       val = new Values(new DataBlock(s, del * lag, s.length, 1));
/* 195:    */     }
/* 196:196 */     if ((lastYears > 0) && (data.freq > 0)) {
/* 197:197 */       int nmax = lastYears * data.freq;
/* 198:198 */       int nbeg = val.getLength() - nmax;
/* 199:199 */       if (nbeg > 0) {
/* 200:200 */         val = val.drop(nbeg, 0);
/* 201:    */       }
/* 202:    */     }
/* 203:    */     
/* 204:204 */     int nar = arcount;
/* 205:205 */     if (nar <= 0) {
/* 206:206 */       nar = Math.min(val.getLength() - 1, 30 * data.freq / 12);
/* 207:    */     }
/* 208:208 */     AutoRegressiveSpectrum ar = new AutoRegressiveSpectrum(val, nar);
/* 209:209 */     XYSeries result = new XYSeries(data.name);
/* 210:210 */     int nf = resolution * 60;
/* 211:211 */     for (int i = 0; i <= nf; i++) {
/* 212:212 */       double f = 3.141592653589793D * i / nf;
/* 213:213 */       result.add(f, ar.value(f));
/* 214:    */     }
/* 215:    */     
/* 216:216 */     return result;
/* 217:    */   }
/* 218:    */ }
