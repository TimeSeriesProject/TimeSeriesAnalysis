/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.arima.AutoCovarianceFunction;
/*  4:   */ import ec.tstoolkit.arima.LinearModel;
/*  5:   */ import ec.util.chart.swing.Charts;
/*  6:   */ import java.awt.BorderLayout;
/*  7:   */ import java.awt.geom.Rectangle2D.Double;
/*  8:   */ import java.text.DecimalFormat;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import org.jfree.chart.ChartFactory;
/* 11:   */ import org.jfree.chart.ChartPanel;
/* 12:   */ import org.jfree.chart.JFreeChart;
/* 13:   */ import org.jfree.chart.axis.NumberAxis;
/* 14:   */ import org.jfree.chart.axis.NumberTickUnit;
/* 15:   */ import org.jfree.chart.plot.PlotOrientation;
/* 16:   */ import org.jfree.chart.plot.XYPlot;
/* 17:   */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/* 18:   */ import org.jfree.data.xy.XYSeries;
/* 19:   */ import org.jfree.data.xy.XYSeriesCollection;
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class AcgfView
/* 28:   */   extends JComponent
/* 29:   */ {
/* 30:   */   private XYSeriesCollection coll_;
/* 31:   */   private ChartPanel panel_;
/* 32:32 */   private int n_ = 36;
/* 33:   */   
/* 34:   */   public AcgfView() {
/* 35:35 */     setLayout(new BorderLayout());
/* 36:   */     
/* 37:37 */     panel_ = new ChartPanel(null);
/* 38:38 */     Charts.avoidScaling(panel_);
/* 39:39 */     add(panel_, "Center");
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void add(String name, LinearModel model) {
/* 43:43 */     add(name, model.doStationary().getAutoCovarianceFunction());
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void add(String name, double[] acgf) {
/* 47:47 */     XYSeries series = new XYSeries(name);
/* 48:48 */     for (int i = 0; i <= n_; i++)
/* 49:   */     {
/* 50:50 */       series.add(i + 1, acgf[i]);
/* 51:   */     }
/* 52:52 */     coll_ = new XYSeriesCollection(series);
/* 53:53 */     panel_.setChart(
/* 54:54 */       ChartFactory.createScatterPlot(null, null, null, coll_, PlotOrientation.VERTICAL, coll_.getSeriesCount() > 1, false, false));
/* 55:   */     
/* 56:56 */     XYPlot plot = panel_.getChart().getXYPlot();
/* 57:57 */     configurePlot(plot);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void add(String name, AutoCovarianceFunction acgf) {
/* 61:61 */     XYSeries series = new XYSeries(name);
/* 62:62 */     double v = acgf.get(0);
/* 63:63 */     for (int i = 0; i <= n_; i++)
/* 64:   */     {
/* 65:65 */       series.add(i + 1, acgf.get(i + 1) / v);
/* 66:   */     }
/* 67:67 */     coll_ = new XYSeriesCollection(series);
/* 68:68 */     panel_.setChart(
/* 69:69 */       ChartFactory.createScatterPlot(null, null, null, coll_, PlotOrientation.VERTICAL, coll_.getSeriesCount() > 1, false, false));
/* 70:   */     
/* 71:71 */     XYPlot plot = panel_.getChart().getXYPlot();
/* 72:72 */     configurePlot(plot);
/* 73:   */   }
/* 74:   */   
/* 75:   */   private void configurePlot(XYPlot plot)
/* 76:   */   {
/* 77:77 */     NumberAxis ra = new NumberAxis();
/* 78:78 */     ra.setRange(-1.0D, 1.0D);
/* 79:79 */     ra.setTickUnit(new NumberTickUnit(0.1D));
/* 80:80 */     ra.setNumberFormatOverride(new DecimalFormat("0.##"));
/* 81:81 */     plot.setRangeAxis(ra);
/* 82:   */     
/* 83:   */ 
/* 84:84 */     NumberAxis da = new NumberAxis();
/* 85:85 */     da.setRange(0.0D, 35.0D);
/* 86:86 */     da.setTickUnit(new NumberTickUnit(5.0D));
/* 87:87 */     plot.setDomainAxis(da);
/* 88:   */     
/* 89:89 */     XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
/* 90:90 */     for (int i = 0; i < coll_.getSeriesCount(); i++) {
/* 91:91 */       renderer.setSeriesShape(i, new Rectangle2D.Double(-2.0D, -2.0D, 4.0D, 4.0D));
/* 92:92 */       renderer.setSeriesShapesFilled(i, false);
/* 93:   */     }
/* 94:   */     
/* 95:95 */     plot.setRenderer(renderer);
/* 96:   */   }
/* 97:   */ }
