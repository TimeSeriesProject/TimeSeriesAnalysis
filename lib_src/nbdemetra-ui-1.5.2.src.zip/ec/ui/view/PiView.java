/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*   5:    */ import ec.tstoolkit.uihelper.ContinuousDisplayDomain;
/*   6:    */ import ec.tstoolkit.uihelper.IContinuousInformationProvider;
/*   7:    */ import ec.ui.chart.TsCharts;
/*   8:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*   9:    */ import ec.util.chart.swing.ChartCommand;
/*  10:    */ import ec.util.chart.swing.Charts;
/*  11:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  12:    */ import java.awt.Paint;
/*  13:    */ import java.awt.Stroke;
/*  14:    */ import java.text.DecimalFormat;
/*  15:    */ import javax.swing.JMenu;
/*  16:    */ import javax.swing.JMenuItem;
/*  17:    */ import org.jfree.chart.ChartFactory;
/*  18:    */ import org.jfree.chart.ChartPanel;
/*  19:    */ import org.jfree.chart.JFreeChart;
/*  20:    */ import org.jfree.chart.axis.NumberAxis;
/*  21:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  22:    */ import org.jfree.chart.block.BlockBorder;
/*  23:    */ import org.jfree.chart.plot.PlotOrientation;
/*  24:    */ import org.jfree.chart.plot.XYPlot;
/*  25:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  26:    */ import org.jfree.chart.title.LegendTitle;
/*  27:    */ import org.jfree.chart.title.TextTitle;
/*  28:    */ import org.jfree.data.xy.XYDataset;
/*  29:    */ import org.jfree.data.xy.XYSeries;
/*  30:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ public class PiView
/*  35:    */   extends AChartView
/*  36:    */ {
/*  37:    */   public static final double DEFAULT_MIN_X = 0.0D;
/*  38:    */   public static final double DEFAULT_MAX_X = 3.141592653589793D;
/*  39:    */   public static final double DEFAULT_MIN_Y = 0.0D;
/*  40:    */   public static final double DEFAULT_MAX_Y = 1.0D;
/*  41: 41 */   public static final NumberTickUnit DEFAULT_TICKUNIT_X = new PiNumberTickUnit(1.570796326794897D);
/*  42: 42 */   public static final NumberTickUnit DEFAULT_TICKUNIT_Y = new NumberTickUnit(0.05D);
/*  43: 43 */   public static final DecimalFormat DEFAULT_FORMAT = new DecimalFormat("0.###");
/*  44:    */   protected final IContinuousInformationProvider provider;
/*  45:    */   
/*  46:    */   public PiView(IContinuousInformationProvider provider)
/*  47:    */   {
/*  48: 48 */     super(600, PlotOrientation.VERTICAL, 0.0D, 3.141592653589793D, 0.0D, 1.0D, DEFAULT_TICKUNIT_X, DEFAULT_TICKUNIT_Y, DEFAULT_FORMAT);
/*  49: 49 */     this.provider = provider;
/*  50: 50 */     chartPanel.setChart(createPiViewChart(seriesCollection));
/*  51: 51 */     onDomainChange();
/*  52: 52 */     chartPanel.setPopupMenu(buildMenu(chartPanel).getPopupMenu());
/*  53:    */   }
/*  54:    */   
/*  55:    */ 
/*  56:    */   public void onDomainChange()
/*  57:    */   {
/*  58: 58 */     ContinuousDisplayDomain domain = isBaseValues() ? 
/*  59: 59 */       provider.getContinuousDisplayDomain(getPoints()) : 
/*  60: 60 */       provider.getContinuousDisplayDomain(getMinX(), getMaxX(), getPoints());
/*  61:    */     
/*  62: 62 */     seriesCollection.removeAllSeries();
/*  63:    */     
/*  64: 64 */     String[] components = provider.getComponents();
/*  65: 65 */     for (int i = 0; i < components.length; i++) {
/*  66: 66 */       if (provider.isDefined(i)) {
/*  67: 67 */         double[] data = provider.getDataArray(i, domain);
/*  68: 68 */         XYSeries series = new XYSeries(components[i]);
/*  69: 69 */         for (int j = 0; j < data.length; j++) {
/*  70: 70 */           series.add(domain.x(j), Double.isInfinite(data[j]) ? 999.0D : data[j]);
/*  71:    */         }
/*  72: 72 */         seriesCollection.addSeries(series);
/*  73:    */       }
/*  74:    */     }
/*  75:    */     
/*  76: 76 */     chartPanel.getChart().getLegend().setVisible(seriesCollection.getSeriesCount() > 1);
/*  77:    */     
/*  78: 78 */     configureAxis();
/*  79: 79 */     onColorSchemeChange();
/*  80: 80 */     onFocusChange();
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected void onColorSchemeChange()
/*  84:    */   {
/*  85: 85 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/*  86: 86 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/*  87: 87 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/*  88: 88 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/*  89: 89 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/*  90:    */     
/*  91: 91 */     XYItemRenderer renderer = plot.getRenderer();
/*  92: 92 */     for (int i = 0; i < seriesCollection.getSeriesCount(); i++) {
/*  93: 93 */       renderer.setSeriesPaint(i, themeSupport.getLineColor(i));
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   protected void onFocusChange()
/*  98:    */   {
/*  99: 99 */     Stroke normalStroke = TsCharts.getNormalStroke(ITsChart.LinesThickness.Thin);
/* 100:100 */     Stroke strongStroke = TsCharts.getStrongStroke(ITsChart.LinesThickness.Thin);
/* 101:101 */     int focusIndex = getFocusIndex();
/* 102:102 */     XYItemRenderer renderer = chartPanel.getChart().getXYPlot().getRenderer();
/* 103:103 */     for (int i = 0; i < seriesCollection.getSeriesCount(); i++) {
/* 104:104 */       renderer.setSeriesStroke(i, focusIndex == i ? strongStroke : normalStroke);
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static JFreeChart createPiViewChart(XYDataset dataset)
/* 109:    */   {
/* 110:110 */     JFreeChart result = ChartFactory.createXYLineChart("", "", "", Charts.emptyXYDataset(), PlotOrientation.VERTICAL, true, false, false);
/* 111:111 */     result.setPadding(TsCharts.CHART_PADDING);
/* 112:112 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 113:113 */     result.getLegend().setFrame(BlockBorder.NONE);
/* 114:114 */     result.getLegend().setBackgroundPaint(null);
/* 115:    */     
/* 116:116 */     XYPlot plot = result.getXYPlot();
/* 117:117 */     plot.setDataset(dataset);
/* 118:    */     
/* 119:119 */     NumberAxis rangeAxis = new NumberAxis();
/* 120:120 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 121:121 */     plot.setRangeAxis(rangeAxis);
/* 122:    */     
/* 123:123 */     NumberAxis domainAxis = new NumberAxis();
/* 124:124 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 125:125 */     plot.setDomainAxis(domainAxis);
/* 126:    */     
/* 127:127 */     return result;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static JMenu buildMenu(ChartPanel chartPanel) {
/* 131:131 */     JMenu result = new JMenu();
/* 132:    */     
/* 133:133 */     result.add(new CustomCommand(null).toAction(chartPanel)).setText("Copy all visible");
/* 134:    */     
/* 135:135 */     JMenu export = new JMenu("Export image to");
/* 136:136 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 137:137 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 138:138 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 139:139 */     result.add(export);
/* 140:    */     
/* 141:141 */     return result;
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static class CustomCommand extends MatrixChartCommand
/* 145:    */   {
/* 146:    */     protected Matrix toMatrix(ChartPanel chartPanel)
/* 147:    */     {
/* 148:148 */       XYDataset dataset = chartPanel.getChart().getXYPlot().getDataset(0);
/* 149:149 */       Matrix result = new Matrix(dataset.getItemCount(0), dataset.getSeriesCount() + 1);
/* 150:150 */       for (int i = 0; i < result.getRowsCount(); i++) {
/* 151:151 */         result.set(i, 0, dataset.getXValue(0, i));
/* 152:152 */         for (int j = 0; j < dataset.getSeriesCount(); j++) {
/* 153:153 */           result.set(i, j + 1, dataset.getYValue(j, i));
/* 154:    */         }
/* 155:    */       }
/* 156:156 */       return result;
/* 157:    */     }
/* 158:    */     
/* 159:    */     public boolean isEnabled(ChartPanel chartPanel)
/* 160:    */     {
/* 161:161 */       XYPlot plot = chartPanel.getChart().getXYPlot();
/* 162:162 */       return (plot.getDatasetCount() > 0) && (plot.getDataset(0).getSeriesCount() > 0);
/* 163:    */     }
/* 164:    */   }
/* 165:    */ }
