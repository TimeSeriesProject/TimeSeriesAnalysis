/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*   5:    */ import ec.tstoolkit.data.IReadDataBlock;
/*   6:    */ import ec.tstoolkit.stats.AutoCorrelations;
/*   7:    */ import ec.tstoolkit.utilities.Jdk6.Collections;
/*   8:    */ import ec.ui.ATsControl;
/*   9:    */ import ec.ui.chart.TsCharts;
/*  10:    */ import ec.ui.interfaces.IReadDataBlockView;
/*  11:    */ import ec.util.chart.ColorScheme;
/*  12:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  13:    */ import ec.util.chart.swing.ChartCommand;
/*  14:    */ import ec.util.chart.swing.Charts;
/*  15:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  16:    */ import java.awt.BasicStroke;
/*  17:    */ import java.awt.BorderLayout;
/*  18:    */ import java.awt.Color;
/*  19:    */ import java.awt.Paint;
/*  20:    */ import java.awt.Stroke;
/*  21:    */ import java.beans.PropertyChangeEvent;
/*  22:    */ import java.beans.PropertyChangeListener;
/*  23:    */ import java.util.Collection;
/*  24:    */ import javax.swing.JMenu;
/*  25:    */ import javax.swing.JMenuItem;
/*  26:    */ import org.jfree.chart.ChartPanel;
/*  27:    */ import org.jfree.chart.JFreeChart;
/*  28:    */ import org.jfree.chart.axis.NumberAxis;
/*  29:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  30:    */ import org.jfree.chart.plot.Marker;
/*  31:    */ import org.jfree.chart.plot.ValueMarker;
/*  32:    */ import org.jfree.chart.plot.XYPlot;
/*  33:    */ import org.jfree.chart.renderer.xy.XYBarRenderer;
/*  34:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  35:    */ import org.jfree.chart.title.TextTitle;
/*  36:    */ import org.jfree.data.xy.XYBarDataset;
/*  37:    */ import org.jfree.data.xy.XYSeries;
/*  38:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  39:    */ 
/*  40:    */ public class AutoCorrelationsView extends ATsControl implements IReadDataBlockView, ec.ui.interfaces.IColorSchemeAble
/*  41:    */ {
/*  42:    */   public static enum ACKind
/*  43:    */   {
/*  44: 44 */     Normal,  Partial;
/*  45:    */   }
/*  46:    */   
/*  47: 47 */   protected static final Stroke MARKER_STROKE = new BasicStroke(1.0F, 1, 1, 1.0F, new float[] { 6.0F, 6.0F }, 0.0F);
/*  48:    */   protected static final float MARKER_ALPHA = 0.8F;
/*  49: 49 */   protected static final ColorScheme.KnownColor NORMAL_COLOR = ColorScheme.KnownColor.BLUE;
/*  50: 50 */   protected static final ColorScheme.KnownColor PARTIAL_COLOR = ColorScheme.KnownColor.BROWN;
/*  51: 51 */   protected static final ColorScheme.KnownColor MARKER_COLOR = ColorScheme.KnownColor.GREEN;
/*  52:    */   
/*  53:    */   public static final String LENGTH_PROPERTY = "length";
/*  54:    */   
/*  55:    */   public static final String KIND_PROPERTY = "kind";
/*  56:    */   public static final String MEAN_CORRECTION_PROPERTY = "meanCorrection";
/*  57:    */   public static final String AUTO_CORRELATIONS_PROPERTY = "autoCorrelations";
/*  58:    */   protected static final int DEFAULT_LENGTH = 36;
/*  59: 59 */   protected static final ACKind DEFAULT_KIND = ACKind.Normal;
/*  60:    */   protected static final boolean DEFAULT_MEAN_CORRECTION = false;
/*  61: 61 */   protected static final AutoCorrelations DEFAULT_AUTO_CORRELATIONS = null;
/*  62:    */   
/*  63:    */   protected int length;
/*  64:    */   protected ACKind kind;
/*  65:    */   protected boolean meanCorrection;
/*  66:    */   protected AutoCorrelations ac;
/*  67:    */   protected final ChartPanel chartPanel;
/*  68:    */   
/*  69:    */   public AutoCorrelationsView()
/*  70:    */   {
/*  71: 71 */     length = 36;
/*  72: 72 */     kind = DEFAULT_KIND;
/*  73: 73 */     meanCorrection = false;
/*  74: 74 */     ac = DEFAULT_AUTO_CORRELATIONS;
/*  75:    */     
/*  76: 76 */     chartPanel = new ChartPanel(createAutoCorrelationsViewChart());
/*  77: 77 */     setLayout(new BorderLayout());
/*  78: 78 */     Charts.avoidScaling(chartPanel);
/*  79: 79 */     add(chartPanel, "Center");
/*  80:    */     
/*  81: 81 */     onDataFormatChange();
/*  82: 82 */     onColorSchemeChange();
/*  83:    */     
/*  84: 84 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  85:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  86:    */         String str;
/*  87: 87 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1480376704:  if (str.equals("autoCorrelations")) {} break; case -1106363674:  if (str.equals("length")) break; break; case -446112509:  if (str.equals("meanCorrection")) {} break; case 3292052:  if (!str.equals("kind"))
/*  88:    */           {
/*  89: 89 */             return;onDataChange();
/*  90:    */           }
/*  91:    */           else {
/*  92: 92 */             onDataChange();
/*  93: 93 */             return;
/*  94:    */             
/*  95: 95 */             onDataChange();
/*  96: 96 */             return;
/*  97:    */             
/*  98: 98 */             onDataChange();
/*  99:    */           }
/* 100:    */           break;
/* 101:    */         }
/* 102:    */       }
/* 103:103 */     });
/* 104:104 */     chartPanel.setPopupMenu(buildMenu(chartPanel).getPopupMenu());
/* 105:    */   }
/* 106:    */   
/* 107:    */ 
/* 108:    */ 
/* 109:    */   protected void onDataFormatChange() {}
/* 110:    */   
/* 111:    */ 
/* 112:    */ 
/* 113:    */   protected void onColorSchemeChange()
/* 114:    */   {
/* 115:115 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 116:116 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 117:117 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 118:118 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 119:119 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 120:    */     
/* 121:121 */     XYItemRenderer renderer = plot.getRenderer();
/* 122:122 */     ColorScheme.KnownColor color = ACKind.Normal == kind ? NORMAL_COLOR : PARTIAL_COLOR;
/* 123:123 */     renderer.setBasePaint((Paint)themeSupport.getAreaColor(color));
/* 124:124 */     renderer.setBaseOutlinePaint((Paint)themeSupport.getLineColor(color));
/* 125:    */     
/* 126:126 */     Collection<Marker> markers = plot.getDomainMarkers(org.jfree.ui.Layer.FOREGROUND);
/* 127:127 */     if (!Jdk6.Collections.isNullOrEmpty(markers)) {
/* 128:128 */       Color markerColor = (Color)themeSupport.getLineColor(MARKER_COLOR);
/* 129:129 */       for (Marker o : markers) {
/* 130:130 */         o.setPaint(markerColor);
/* 131:    */       }
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected void onDataChange() {
/* 136:136 */     chartPanel.getChart().setTitle(ACKind.Normal == kind ? "Autocorrelations" : "Partial autocorrelations");
/* 137:137 */     NumberAxis domainAxis = (NumberAxis)chartPanel.getChart().getXYPlot().getDomainAxis();
/* 138:138 */     domainAxis.setRange(0.0D, length);
/* 139:139 */     domainAxis.setTickUnit(new NumberTickUnit(length / 6));
/* 140:    */     
/* 141:141 */     if (ac == DEFAULT_AUTO_CORRELATIONS) {
/* 142:142 */       chartPanel.getChart().getXYPlot().setDataset(Charts.emptyXYDataset());
/* 143:    */     } else {
/* 144:144 */       ac.setCorrectedForMean(meanCorrection);
/* 145:145 */       ac.setKMax(length);
/* 146:    */       
/* 147:147 */       double[] vals = ACKind.Normal == kind ? ac.getAC() : ac.getPAC();
/* 148:148 */       XYSeries series = new XYSeries("");
/* 149:149 */       for (int i = 0; i < vals.length; i++) {
/* 150:150 */         series.add(i + 1, vals[i]);
/* 151:    */       }
/* 152:    */       
/* 153:153 */       XYPlot plot = chartPanel.getChart().getXYPlot();
/* 154:154 */       plot.clearRangeMarkers();
/* 155:155 */       plot.setDataset(new XYBarDataset(new XYSeriesCollection(series), 1.0D));
/* 156:    */       
/* 157:157 */       double z = 2.0D / Math.sqrt(ac.getUnderlyingData().getDataCount() - ac.getUnderlyingData().getMissingValuesCount());
/* 158:158 */       for (double o : new double[] { z, -z }) {
/* 159:159 */         ValueMarker marker = new ValueMarker(o);
/* 160:160 */         marker.setStroke(MARKER_STROKE);
/* 161:161 */         marker.setAlpha(0.8F);
/* 162:162 */         plot.addRangeMarker(marker);
/* 163:    */       }
/* 164:    */       
/* 165:165 */       onColorSchemeChange();
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:    */ 
/* 170:    */   public int getLength()
/* 171:    */   {
/* 172:172 */     return length;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void setLength(int length) {
/* 176:176 */     int old = this.length;
/* 177:177 */     this.length = (length >= 0 ? length : 36);
/* 178:178 */     firePropertyChange("length", old, this.length);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public ACKind getKind() {
/* 182:182 */     return kind;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setKind(ACKind kind) {
/* 186:186 */     ACKind old = this.kind;
/* 187:187 */     this.kind = (kind != null ? kind : DEFAULT_KIND);
/* 188:188 */     firePropertyChange("kind", old, this.kind);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public boolean isMeanCorrection() {
/* 192:192 */     return meanCorrection;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setMeanCorrection(boolean meanCorrection) {
/* 196:196 */     boolean old = this.meanCorrection;
/* 197:197 */     this.meanCorrection = meanCorrection;
/* 198:198 */     firePropertyChange("meanCorrection", old, this.meanCorrection);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void setAutoCorrelations(AutoCorrelations ac) {
/* 202:202 */     AutoCorrelations old = this.ac;
/* 203:203 */     this.ac = (ac != null ? ac : DEFAULT_AUTO_CORRELATIONS);
/* 204:204 */     firePropertyChange("autoCorrelations", old, this.ac);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public AutoCorrelations getAutoCorrelations() {
/* 208:208 */     return ac;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public ColorScheme getColorScheme()
/* 212:    */   {
/* 213:213 */     return themeSupport.getLocalColorScheme();
/* 214:    */   }
/* 215:    */   
/* 216:    */   public void setColorScheme(ColorScheme theme)
/* 217:    */   {
/* 218:218 */     themeSupport.setLocalColorScheme(theme);
/* 219:    */   }
/* 220:    */   
/* 221:    */ 
/* 222:    */   public void setDataBlock(IReadDataBlock data)
/* 223:    */   {
/* 224:224 */     setAutoCorrelations(new AutoCorrelations(data));
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void reset()
/* 228:    */   {
/* 229:229 */     setAutoCorrelations(DEFAULT_AUTO_CORRELATIONS);
/* 230:    */   }
/* 231:    */   
/* 232:    */   private static JFreeChart createAutoCorrelationsViewChart() {
/* 233:233 */     JFreeChart result = org.jfree.chart.ChartFactory.createXYBarChart("", "", false, "", Charts.emptyXYDataset(), org.jfree.chart.plot.PlotOrientation.VERTICAL, false, false, false);
/* 234:234 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 235:235 */     result.setPadding(TsCharts.CHART_PADDING);
/* 236:    */     
/* 237:237 */     XYPlot plot = result.getXYPlot();
/* 238:    */     
/* 239:239 */     XYBarRenderer renderer = (XYBarRenderer)plot.getRenderer();
/* 240:240 */     renderer.setShadowVisible(false);
/* 241:241 */     renderer.setDrawBarOutline(true);
/* 242:242 */     renderer.setAutoPopulateSeriesPaint(false);
/* 243:243 */     renderer.setAutoPopulateSeriesOutlinePaint(false);
/* 244:    */     
/* 245:245 */     NumberAxis rangeAxis = new NumberAxis();
/* 246:246 */     rangeAxis.setAutoRangeIncludesZero(false);
/* 247:247 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 248:248 */     plot.setRangeAxis(rangeAxis);
/* 249:    */     
/* 250:250 */     NumberAxis domainAxis = new NumberAxis();
/* 251:251 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 252:252 */     plot.setDomainAxis(domainAxis);
/* 253:    */     
/* 254:254 */     return result;
/* 255:    */   }
/* 256:    */   
/* 257:    */   private static JMenu buildMenu(ChartPanel chartPanel) {
/* 258:258 */     JMenu result = new JMenu();
/* 259:    */     
/* 260:260 */     result.add(MatrixChartCommand.copySeries(0, 0).toAction(chartPanel)).setText("Copy series");
/* 261:    */     
/* 262:262 */     JMenu export = new JMenu("Export image to");
/* 263:263 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 264:264 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 265:265 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 266:266 */     result.add(export);
/* 267:    */     
/* 268:268 */     return result;
/* 269:    */   }
/* 270:    */ }
