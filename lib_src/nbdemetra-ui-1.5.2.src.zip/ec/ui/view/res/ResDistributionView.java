/*  1:   */ package ec.ui.view.res;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbComponents;
/*  4:   */ import ec.tstoolkit.data.IReadDataBlock;
/*  5:   */ import ec.tstoolkit.dstats.Normal;
/*  6:   */ import ec.tstoolkit.stats.AutoCorrelations;
/*  7:   */ import ec.ui.view.AutoCorrelationsView;
/*  8:   */ import ec.ui.view.AutoCorrelationsView.ACKind;
/*  9:   */ import ec.ui.view.DistributionView;
/* 10:   */ import java.awt.BorderLayout;
/* 11:   */ import javax.swing.JComponent;
/* 12:   */ import javax.swing.JSplitPane;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class ResDistributionView
/* 20:   */   extends JComponent
/* 21:   */ {
/* 22:   */   private AutoCorrelationsView acView_;
/* 23:   */   private AutoCorrelationsView pacView_;
/* 24:   */   private DistributionView distView_;
/* 25:   */   
/* 26:   */   public ResDistributionView()
/* 27:   */   {
/* 28:28 */     acView_ = new AutoCorrelationsView();
/* 29:29 */     acView_.setKind(AutoCorrelationsView.ACKind.Normal);
/* 30:30 */     pacView_ = new AutoCorrelationsView();
/* 31:31 */     pacView_.setKind(AutoCorrelationsView.ACKind.Partial);
/* 32:32 */     JSplitPane acpane = NbComponents.newJSplitPane(0, acView_, pacView_);
/* 33:33 */     acpane.setDividerLocation(0.5D);
/* 34:34 */     acpane.setResizeWeight(0.5D);
/* 35:35 */     distView_ = new DistributionView();
/* 36:36 */     JSplitPane acdpane = NbComponents.newJSplitPane(1, acpane, distView_);
/* 37:37 */     acdpane.setDividerLocation(0.5D);
/* 38:38 */     acdpane.setResizeWeight(0.5D);
/* 39:   */     
/* 40:40 */     setLayout(new BorderLayout());
/* 41:41 */     add(acdpane, "Center");
/* 42:42 */     acpane.setResizeWeight(0.5D);
/* 43:43 */     acdpane.setResizeWeight(0.5D);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setAutocorrelationsCount(int na) {
/* 47:47 */     acView_.setLength(na);
/* 48:48 */     pacView_.setLength(na);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setData(IReadDataBlock data) {
/* 52:52 */     if (data != null) {
/* 53:53 */       AutoCorrelations ac = new AutoCorrelations(data);
/* 54:54 */       acView_.setAutoCorrelations(ac);
/* 55:55 */       pacView_.setAutoCorrelations(ac);
/* 56:56 */       distView_.setDistribution(new Normal());
/* 57:57 */       distView_.setDataBlock(data);
/* 58:   */     }
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void reset() {
/* 62:62 */     acView_.reset();
/* 63:63 */     pacView_.reset();
/* 64:64 */     distView_.reset();
/* 65:   */   }
/* 66:   */ }
