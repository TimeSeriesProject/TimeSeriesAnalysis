/*   1:    */ package ec.ui.view.res;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.TsFactory;
/*   7:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   8:    */ import ec.tstoolkit.MetaData;
/*   9:    */ import ec.tstoolkit.data.DataBlock;
/*  10:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  11:    */ import ec.tstoolkit.data.Values;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  13:    */ import ec.ui.ATsDataView;
/*  14:    */ import ec.ui.chart.TsCharts;
/*  15:    */ import ec.ui.chart.TsXYDatasets;
/*  16:    */ import ec.ui.grid.JTsGrid;
/*  17:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  18:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*  19:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  20:    */ import ec.util.chart.swing.ChartCommand;
/*  21:    */ import ec.util.chart.swing.Charts;
/*  22:    */ import java.awt.BorderLayout;
/*  23:    */ import java.awt.Paint;
/*  24:    */ import java.text.DateFormat;
/*  25:    */ import javax.swing.ActionMap;
/*  26:    */ import javax.swing.JMenu;
/*  27:    */ import javax.swing.JMenuItem;
/*  28:    */ import javax.swing.JSplitPane;
/*  29:    */ import org.jfree.chart.ChartFactory;
/*  30:    */ import org.jfree.chart.ChartPanel;
/*  31:    */ import org.jfree.chart.JFreeChart;
/*  32:    */ import org.jfree.chart.axis.DateAxis;
/*  33:    */ import org.jfree.chart.axis.DateTickMarkPosition;
/*  34:    */ import org.jfree.chart.axis.NumberAxis;
/*  35:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  36:    */ import org.jfree.chart.plot.PlotOrientation;
/*  37:    */ import org.jfree.chart.plot.XYPlot;
/*  38:    */ import org.jfree.chart.renderer.xy.XYBarRenderer;
/*  39:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  40:    */ import org.jfree.chart.title.TextTitle;
/*  41:    */ import org.jfree.data.Range;
/*  42:    */ import org.jfree.ui.RectangleInsets;
/*  43:    */ 
/*  44:    */ public class ResidualsView
/*  45:    */   extends ATsDataView
/*  46:    */ {
/*  47: 47 */   protected static final ColorScheme.KnownColor MAIN_COLOR = ColorScheme.KnownColor.BLUE;
/*  48:    */   protected final ChartPanel chartPanel;
/*  49:    */   protected final JTsGrid grid;
/*  50:    */   
/*  51:    */   public ResidualsView()
/*  52:    */   {
/*  53: 53 */     setLayout(new BorderLayout());
/*  54:    */     
/*  55: 55 */     chartPanel = new ChartPanel(buildResidualViewChart());
/*  56: 56 */     Charts.avoidScaling(chartPanel);
/*  57: 57 */     grid = new JTsGrid();
/*  58: 58 */     grid.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  59: 59 */     grid.setMode(ITsGrid.Mode.SINGLETS);
/*  60:    */     
/*  61: 61 */     onDataFormatChange();
/*  62: 62 */     onColorSchemeChange();
/*  63:    */     
/*  64: 64 */     JSplitPane splitPane = NbComponents.newJSplitPane(0, chartPanel, grid);
/*  65: 65 */     splitPane.setDividerLocation(0.5D);
/*  66: 66 */     splitPane.setResizeWeight(0.5D);
/*  67: 67 */     add(splitPane, "Center");
/*  68:    */     
/*  69: 69 */     chartPanel.setPopupMenu(buildMenu().getPopupMenu());
/*  70:    */   }
/*  71:    */   
/*  72:    */ 
/*  73:    */   protected void onTsDataChange()
/*  74:    */   {
/*  75: 75 */     chartPanel.getChart().getXYPlot().setDataset(TsXYDatasets.from("", tsData));
/*  76: 76 */     if (tsData != DEFAULT_TS_DATA) {
/*  77: 77 */       Range rng = calcRange(tsData.getValues().internalStorage());
/*  78: 78 */       ((NumberAxis)chartPanel.getChart().getXYPlot().getRangeAxis()).setTickUnit(new NumberTickUnit(calcTick(rng)));
/*  79:    */       
/*  80: 80 */       grid.getTsCollection().replace(TsFactory.instance.createTs("Residuals", new MetaData(), tsData));
/*  81:    */     } else {
/*  82: 82 */       grid.getTsCollection().clear();
/*  83:    */     }
/*  84: 84 */     onColorSchemeChange();
/*  85:    */   }
/*  86:    */   
/*  87:    */   protected void onDataFormatChange()
/*  88:    */   {
/*  89: 89 */     grid.setDataFormat(getDataFormat());
/*  90:    */     try {
/*  91: 91 */       DateFormat dateFormat = themeSupport.getDataFormat().newDateFormat();
/*  92: 92 */       ((DateAxis)chartPanel.getChart().getXYPlot().getDomainAxis()).setDateFormatOverride(dateFormat);
/*  93:    */     }
/*  94:    */     catch (IllegalArgumentException localIllegalArgumentException) {}
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */   protected void onColorSchemeChange()
/*  99:    */   {
/* 100:100 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 101:101 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 102:102 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 103:103 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 104:104 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 105:    */     
/* 106:106 */     XYItemRenderer renderer = plot.getRenderer();
/* 107:107 */     renderer.setBasePaint((Paint)themeSupport.getAreaColor(MAIN_COLOR));
/* 108:108 */     renderer.setBaseOutlinePaint((Paint)themeSupport.getLineColor(MAIN_COLOR));
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static JFreeChart buildResidualViewChart()
/* 112:    */   {
/* 113:113 */     JFreeChart result = ChartFactory.createXYBarChart("Full residuals", "", false, "", Charts.emptyXYDataset(), PlotOrientation.VERTICAL, false, false, false);
/* 114:114 */     result.setPadding(TsCharts.CHART_PADDING);
/* 115:115 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 116:    */     
/* 117:117 */     XYPlot plot = result.getXYPlot();
/* 118:    */     
/* 119:119 */     DateAxis domainAxis = new DateAxis();
/* 120:120 */     domainAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 121:121 */     domainAxis.setLowerMargin(0.0D);
/* 122:122 */     domainAxis.setUpperMargin(0.0D);
/* 123:123 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 124:124 */     plot.setDomainAxis(domainAxis);
/* 125:    */     
/* 126:126 */     NumberAxis rangeAxis = new NumberAxis();
/* 127:127 */     rangeAxis.setAutoRangeIncludesZero(false);
/* 128:128 */     rangeAxis.setTickLabelInsets(new RectangleInsets(10.0D, 5.0D, 10.0D, 2.0D));
/* 129:129 */     rangeAxis.setLowerMargin(0.02D);
/* 130:130 */     rangeAxis.setUpperMargin(0.02D);
/* 131:131 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 132:132 */     plot.setRangeAxis(rangeAxis);
/* 133:    */     
/* 134:134 */     XYBarRenderer renderer = (XYBarRenderer)plot.getRenderer();
/* 135:135 */     renderer.setShadowVisible(false);
/* 136:136 */     renderer.setDrawBarOutline(true);
/* 137:137 */     renderer.setAutoPopulateSeriesPaint(false);
/* 138:138 */     renderer.setAutoPopulateSeriesOutlinePaint(false);
/* 139:    */     
/* 140:140 */     return result;
/* 141:    */   }
/* 142:    */   
/* 143:    */   private JMenu buildMenu() {
/* 144:144 */     JMenu result = new JMenu();
/* 145:    */     
/* 146:146 */     result.add(grid.getActionMap().get("copyAll")).setText("Copy series");
/* 147:    */     
/* 148:148 */     JMenu export = new JMenu("Export image to");
/* 149:149 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 150:150 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 151:151 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 152:152 */     result.add(export);
/* 153:    */     
/* 154:154 */     return result;
/* 155:    */   }
/* 156:    */   
/* 157:    */   private Range calcRange(double[] values) {
/* 158:158 */     double min = (-1.0D / 0.0D);double max = (-1.0D / 0.0D);
/* 159:    */     
/* 160:160 */     DescriptiveStatistics stats = new DescriptiveStatistics(new DataBlock(values));
/* 161:161 */     double smin = stats.getMin();double smax = stats.getMax();
/* 162:162 */     if ((Double.isInfinite(min)) || (smin < min)) {
/* 163:163 */       min = smin;
/* 164:    */     }
/* 165:165 */     if ((Double.isInfinite(max)) || (smax > max)) {
/* 166:166 */       max = smax;
/* 167:    */     }
/* 168:    */     
/* 169:169 */     if ((Double.isInfinite(max)) || (Double.isInfinite(min))) {
/* 170:170 */       return new Range(0.0D, 1.0D);
/* 171:    */     }
/* 172:172 */     double length = max - min;
/* 173:173 */     if (length == 0.0D) {
/* 174:174 */       return new Range(0.0D, 1.0D);
/* 175:    */     }
/* 176:    */     
/* 177:    */ 
/* 178:178 */     return new Range(min, max);
/* 179:    */   }
/* 180:    */   
/* 181:    */   private double calcTick(Range rng)
/* 182:    */   {
/* 183:183 */     double tick = 0.0D;
/* 184:184 */     double avg = (rng.getUpperBound() - rng.getLowerBound()) / 6.0D;
/* 185:185 */     for (int i = 0; (i < 10) && (tick == 0.0D); i++) {
/* 186:186 */       double power = Math.pow(10.0D, i);
/* 187:187 */       if ((avg > 0.01D * power) && (avg <= 0.02D * power)) {
/* 188:188 */         tick = 0.02D * power;
/* 189:189 */       } else if ((avg > 0.02D * power) && (avg <= 0.05D * power)) {
/* 190:190 */         tick = 0.05D * power;
/* 191:191 */       } else if ((avg > 0.05D * power) && (avg <= 0.1D * power)) {
/* 192:192 */         tick = 0.1D * power;
/* 193:    */       }
/* 194:    */     }
/* 195:195 */     return tick;
/* 196:    */   }
/* 197:    */ }
