/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*   5:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*   6:    */ import ec.ui.ATsView;
/*   7:    */ import ec.ui.chart.BasicXYDataset;
/*   8:    */ import ec.ui.chart.BasicXYDataset.Series;
/*   9:    */ import ec.ui.chart.TsCharts;
/*  10:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  11:    */ import ec.util.chart.swing.Charts;
/*  12:    */ import java.awt.BasicStroke;
/*  13:    */ import java.awt.BorderLayout;
/*  14:    */ import java.awt.CardLayout;
/*  15:    */ import java.awt.Color;
/*  16:    */ import java.awt.Paint;
/*  17:    */ import java.awt.Stroke;
/*  18:    */ import java.awt.event.MouseAdapter;
/*  19:    */ import java.awt.event.MouseEvent;
/*  20:    */ import java.awt.geom.Ellipse2D.Double;
/*  21:    */ import java.text.DecimalFormat;
/*  22:    */ import java.util.ArrayList;
/*  23:    */ import java.util.Collections;
/*  24:    */ import java.util.LinkedHashMap;
/*  25:    */ import java.util.List;
/*  26:    */ import java.util.Map;
/*  27:    */ import java.util.Map.Entry;
/*  28:    */ import javax.swing.JLabel;
/*  29:    */ import javax.swing.JPanel;
/*  30:    */ import org.jfree.chart.JFreeChart;
/*  31:    */ import org.jfree.chart.axis.NumberAxis;
/*  32:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  33:    */ import org.jfree.chart.labels.StandardXYToolTipGenerator;
/*  34:    */ import org.jfree.chart.plot.DatasetRenderingOrder;
/*  35:    */ import org.jfree.chart.plot.ValueMarker;
/*  36:    */ import org.jfree.chart.plot.XYPlot;
/*  37:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  38:    */ import org.jfree.data.xy.XYDataset;
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ public class StabilityView
/*  58:    */   extends ATsView
/*  59:    */ {
/*  60:    */   private static final int POINTS_INDEX = 0;
/*  61:    */   private static final int MEAN_INDEX = 1;
/*  62:    */   private static final int SMOOTH_INDEX = 2;
/*  63: 63 */   private static final Stroke MARKER_STROKE = new BasicStroke(0.5F);
/*  64: 64 */   private static final Paint MARKER_PAINT = Color.GRAY;
/*  65:    */   private static final float MARKER_ALPHA = 1.0F;
/*  66:    */   private final Map<Bornes, Graphs> graphs_;
/*  67:    */   private JFreeChart mainChart;
/*  68:    */   private JFreeChart detailChart;
/*  69:    */   private JChartPanel panel;
/*  70:    */   private final XYLineAndShapeRenderer meanRenderer;
/*  71:    */   private final XYLineAndShapeRenderer pointsRenderer;
/*  72:    */   private final XYLineAndShapeRenderer smoothRenderer;
/*  73: 73 */   private List<StabilityViewItem> items = new ArrayList();
/*  74:    */   private JPanel cards;
/*  75:    */   private JPanel errorPanel;
/*  76:    */   private JLabel errorLabel;
/*  77: 77 */   private final String MAIN_PANEL = "mainPanel";
/*  78: 78 */   private final String ERROR_PANEL = "errorPanel";
/*  79: 79 */   private int indexSelected = -1;
/*  80:    */   
/*  81:    */   public StabilityView()
/*  82:    */   {
/*  83: 83 */     setLayout(new BorderLayout());
/*  84:    */     
/*  85: 85 */     graphs_ = new LinkedHashMap();
/*  86:    */     
/*  87: 87 */     meanRenderer = new XYLineAndShapeRenderer(true, false);
/*  88: 88 */     meanRenderer.setAutoPopulateSeriesPaint(false);
/*  89: 89 */     meanRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/*  90:    */     
/*  91: 91 */     pointsRenderer = new XYLineAndShapeRenderer(false, true);
/*  92: 92 */     pointsRenderer.setAutoPopulateSeriesPaint(false);
/*  93: 93 */     pointsRenderer.setAutoPopulateSeriesShape(false);
/*  94: 94 */     pointsRenderer.setBaseShape(new Ellipse2D.Double(-2.0D, -2.0D, 4.0D, 4.0D));
/*  95: 95 */     pointsRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/*  96: 96 */     pointsRenderer.setBaseShapesFilled(false);
/*  97:    */     
/*  98: 98 */     smoothRenderer = new XYLineAndShapeRenderer(true, false);
/*  99: 99 */     smoothRenderer.setAutoPopulateSeriesPaint(false);
/* 100:100 */     smoothRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.GREEN));
/* 101:    */     
/* 102:102 */     mainChart = createChart();
/* 103:103 */     detailChart = createChart();
/* 104:    */     
/* 105:105 */     panel = new JChartPanel(null);
/* 106:    */     
/* 107:107 */     errorPanel = new JPanel(new BorderLayout());
/* 108:108 */     errorLabel = new JLabel();
/* 109:109 */     errorLabel.setHorizontalAlignment(0);
/* 110:110 */     errorPanel.add(errorLabel, "Center");
/* 111:    */     
/* 112:112 */     panel.addMouseListener(new MouseAdapter()
/* 113:    */     {
/* 114:    */       public void mouseClicked(MouseEvent e) {
/* 115:115 */         indexSelected = -1;
/* 116:116 */         if ((e.getButton() == 1) && (e.getClickCount() == 2)) {
/* 117:117 */           double x = panel.getChartX(e.getX());
/* 118:118 */           StabilityView.Graphs g = null;
/* 119:119 */           for (StabilityView.Bornes b : graphs_.keySet()) {
/* 120:120 */             indexSelected += 1;
/* 121:121 */             if ((x >= min_) && (x <= max_)) {
/* 122:122 */               g = (StabilityView.Graphs)graphs_.get(b);
/* 123:123 */               break;
/* 124:    */             }
/* 125:    */           }
/* 126:126 */           if (g == null) {
/* 127:127 */             return;
/* 128:    */           }
/* 129:    */           
/* 130:130 */           StabilityView.this.showDetail(g);
/* 131:131 */         } else if (e.getButton() == 3) {
/* 132:132 */           StabilityView.this.showMain();
/* 133:133 */           indexSelected = -1;
/* 134:    */         }
/* 135:    */         
/* 136:    */       }
/* 137:137 */     });
/* 138:138 */     StandardXYToolTipGenerator generator = new StandardXYToolTipGenerator() {
/* 139:139 */       final DecimalFormat format = new DecimalFormat("0.0000");
/* 140:    */       
/* 141:    */       public String generateToolTip(XYDataset dataset, int series, int item)
/* 142:    */       {
/* 143:    */         try {
/* 144:144 */           StabilityView.StabilityViewItem i = (StabilityView.StabilityViewItem)items.get(indexSelected == -1 ? series : indexSelected);
/* 145:145 */           int cpt = 0;
/* 146:146 */           for (Map.Entry<TsDomain, Double> e : StabilityView.StabilityViewItem.access$0(i).entrySet()) {
/* 147:147 */             if (cpt == item) {
/* 148:148 */               TsDomain dom = (TsDomain)e.getKey();
/* 149:149 */               return "(" + dom.getStart().toString() + ", " + dom.getEnd().toString() + ") : " + format.format(e.getValue());
/* 150:    */             }
/* 151:151 */             cpt++;
/* 152:    */           }
/* 153:    */         }
/* 154:    */         catch (IndexOutOfBoundsException localIndexOutOfBoundsException) {}
/* 155:155 */         return null;
/* 156:    */       }
/* 157:157 */     };
/* 158:158 */     pointsRenderer.setBaseToolTipGenerator(generator);
/* 159:159 */     cards = new JPanel(new CardLayout());
/* 160:    */     
/* 161:161 */     cards.add("mainPanel", panel);
/* 162:    */     
/* 163:163 */     cards.add("errorPanel", errorPanel);
/* 164:    */     
/* 165:165 */     add(cards, "Center");
/* 166:    */     
/* 167:167 */     onColorSchemeChange();
/* 168:    */   }
/* 169:    */   
/* 170:    */   private void showMain() {
/* 171:171 */     panel.setChart(mainChart);
/* 172:172 */     onColorSchemeChange();
/* 173:173 */     CardLayout cl = (CardLayout)cards.getLayout();
/* 174:174 */     cl.show(cards, "mainPanel");
/* 175:    */   }
/* 176:    */   
/* 177:    */ 
/* 178:    */ 
/* 179:    */   public void showException(String msg)
/* 180:    */   {
/* 181:181 */     errorLabel.setText(msg);
/* 182:182 */     CardLayout cl = (CardLayout)cards.getLayout();
/* 183:183 */     cl.show(cards, "errorPanel");
/* 184:    */   }
/* 185:    */   
/* 186:    */   private void showDetail(Graphs g) {
/* 187:187 */     XYPlot plot = detailChart.getXYPlot();
/* 188:    */     
/* 189:189 */     NumberAxis yAxis = new NumberAxis();
/* 190:190 */     yAxis.setTickLabelPaint(Color.GRAY);
/* 191:191 */     plot.setRangeAxis(yAxis);
/* 192:    */     
/* 193:193 */     NumberAxis xAxis = new NumberAxis();
/* 194:194 */     xAxis.setTickLabelPaint(Color.GRAY);
/* 195:195 */     xAxis.setTickUnit(new NumberTickUnit(1.0D));
/* 196:196 */     xAxis.setRange(-0.5D, g.getMaxElements() - 0.5D);
/* 197:197 */     plot.setDomainAxis(xAxis);
/* 198:    */     
/* 199:199 */     plot.setDataset(1, new BasicXYDataset(Collections.singletonList(S1_)));
/* 200:200 */     plot.setDataset(0, new BasicXYDataset(Collections.singletonList(S2_)));
/* 201:201 */     plot.setDataset(2, new BasicXYDataset(Collections.singletonList(S3_)));
/* 202:    */     
/* 203:203 */     rescaleAxis((NumberAxis)plot.getRangeAxis());
/* 204:    */     
/* 205:205 */     detailChart.setTitle(label_);
/* 206:206 */     panel.setChart(detailChart);
/* 207:207 */     panel.setToolTipText("Right click to show complete data");
/* 208:208 */     onColorSchemeChange();
/* 209:    */   }
/* 210:    */   
/* 211:    */ 
/* 212:    */ 
/* 213:    */   public void reset()
/* 214:    */   {
/* 215:215 */     items.clear();
/* 216:216 */     graphs_.clear();
/* 217:217 */     panel.setChart(null);
/* 218:    */   }
/* 219:    */   
/* 220:    */   private void rescaleAxis(NumberAxis axis) {
/* 221:221 */     axis.setAutoRangeIncludesZero(false);
/* 222:    */   }
/* 223:    */   
/* 224:    */   private JFreeChart createChart() {
/* 225:225 */     XYPlot plot = new XYPlot();
/* 226:    */     
/* 227:227 */     plot.setDataset(2, Charts.emptyXYDataset());
/* 228:228 */     plot.setRenderer(2, smoothRenderer);
/* 229:229 */     plot.mapDatasetToDomainAxis(2, 0);
/* 230:230 */     plot.mapDatasetToRangeAxis(2, 0);
/* 231:    */     
/* 232:232 */     plot.setDataset(1, Charts.emptyXYDataset());
/* 233:233 */     plot.setRenderer(1, meanRenderer);
/* 234:234 */     plot.mapDatasetToDomainAxis(1, 0);
/* 235:235 */     plot.mapDatasetToRangeAxis(1, 0);
/* 236:    */     
/* 237:237 */     plot.setDataset(0, Charts.emptyXYDataset());
/* 238:238 */     plot.setRenderer(0, pointsRenderer);
/* 239:239 */     plot.mapDatasetToDomainAxis(0, 0);
/* 240:240 */     plot.mapDatasetToRangeAxis(0, 0);
/* 241:241 */     plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
/* 242:    */     
/* 243:243 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, false);
/* 244:244 */     result.setPadding(TsCharts.CHART_PADDING);
/* 245:245 */     return result;
/* 246:    */   }
/* 247:    */   
/* 248:    */   private void add(StabilityViewItem item, boolean redraw) {
/* 249:249 */     items.add(item);
/* 250:250 */     if (redraw) {
/* 251:251 */       display();
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */   public void add(String name, Map<TsDomain, Double> data, double[] sdata, boolean redraw)
/* 263:    */   {
/* 264:264 */     add(new StabilityViewItem(name, data, sdata), redraw);
/* 265:    */   }
/* 266:    */   
/* 267:    */ 
/* 268:    */ 
/* 269:    */   public void display()
/* 270:    */   {
/* 271:271 */     BasicXYDataset pointsDataset = new BasicXYDataset();
/* 272:272 */     BasicXYDataset meanDataset = new BasicXYDataset();
/* 273:273 */     BasicXYDataset smoothDataset = new BasicXYDataset();
/* 274:274 */     int np = ((StabilityViewItem)items.get(0)).getDataArray().length - 1;
/* 275:275 */     double xstart = -0.4D;
/* 276:276 */     double xend = 0.4D;
/* 277:277 */     double xstep = 0.8D / np;
/* 278:    */     
/* 279:    */ 
/* 280:280 */     String[] itemNames = new String[items.size()];
/* 281:281 */     for (int i = 0; i < items.size(); i++) {
/* 282:282 */       itemNames[i] = items.get(i)).name;
/* 283:    */     }
/* 284:    */     
/* 285:285 */     for (int i = 0; i < items.size(); i++) {
/* 286:286 */       double x = xstart;
/* 287:287 */       StabilityViewItem it = (StabilityViewItem)items.get(i);
/* 288:288 */       double[] array = it.getDataArray();
/* 289:289 */       if ((array != null) && (array.length > 0)) {
/* 290:290 */         boolean smoothData = false;
/* 291:    */         
/* 292:292 */         int n = array.length;
/* 293:293 */         double m = it.getAverage();
/* 294:294 */         double[] meanX = { xstart, xend };
/* 295:295 */         double[] mean2X = { 0.0D, n - 1 };
/* 296:296 */         double[] meanY = { m, m };
/* 297:297 */         double[] pointsX = new double[n];double[] points2X = new double[n];
/* 298:298 */         double[] pointsY = new double[n];double[] points2Y = new double[n];
/* 299:299 */         double[] smoothX = new double[n];double[] smooth2X = new double[n];
/* 300:300 */         double[] smoothY = new double[n];double[] smooth2Y = new double[n];
/* 301:    */         
/* 302:    */ 
/* 303:303 */         for (int j = 0; j < n; j++) {
/* 304:304 */           pointsX[j] = x;
/* 305:305 */           pointsY[j] = array[j];
/* 306:306 */           points2X[j] = j;
/* 307:307 */           points2Y[j] = array[j];
/* 308:308 */           x += xstep;
/* 309:    */         }
/* 310:    */         
/* 311:    */ 
/* 312:312 */         if ((smoothedData != null) && (smoothedData.length > 0)) {
/* 313:313 */           smoothData = true;
/* 314:314 */           for (int j = 0; j < n; j++) {
/* 315:315 */             smoothX[j] = x;
/* 316:316 */             smoothY[j] = smoothedData[j];
/* 317:317 */             smooth2X[j] = j;
/* 318:318 */             smooth2Y[j] = smoothedData[j];
/* 319:319 */             x += xstep;
/* 320:    */           }
/* 321:    */         }
/* 322:    */         
/* 323:323 */         BasicXYDataset.Series mean = BasicXYDataset.Series.of(itemNames[i], meanX, meanY);
/* 324:324 */         BasicXYDataset.Series mean2 = BasicXYDataset.Series.of(itemNames[i], mean2X, meanY);
/* 325:325 */         BasicXYDataset.Series points = BasicXYDataset.Series.of(itemNames[i], pointsX, pointsY);
/* 326:326 */         BasicXYDataset.Series points2 = BasicXYDataset.Series.of(itemNames[i], points2X, points2Y);
/* 327:327 */         BasicXYDataset.Series smooth = smoothData ? BasicXYDataset.Series.of(itemNames[i], smoothX, smoothY) : BasicXYDataset.Series.empty(itemNames[i]);
/* 328:328 */         BasicXYDataset.Series smooth2 = smoothData ? BasicXYDataset.Series.of(itemNames[i], smooth2X, smooth2Y) : BasicXYDataset.Series.empty(itemNames[i]);
/* 329:    */         
/* 330:330 */         Bornes b = new Bornes(xstart, xend);
/* 331:331 */         Graphs g = new Graphs(mean2, points2, smooth2, itemNames[i]);
/* 332:332 */         graphs_.put(b, g);
/* 333:    */         
/* 334:334 */         smoothDataset.addSeries(smooth);
/* 335:335 */         meanDataset.addSeries(mean);
/* 336:336 */         pointsDataset.addSeries(points);
/* 337:    */       }
/* 338:    */       
/* 339:339 */       xstart += 1.0D;
/* 340:340 */       xend += 1.0D;
/* 341:    */     }
/* 342:    */     
/* 343:343 */     XYPlot plot = mainChart.getXYPlot();
/* 344:344 */     configureAxis(plot);
/* 345:345 */     plot.setDataset(2, smoothDataset);
/* 346:346 */     plot.setDataset(1, meanDataset);
/* 347:347 */     plot.setDataset(0, pointsDataset);
/* 348:    */     
/* 349:349 */     showMain();
/* 350:    */   }
/* 351:    */   
/* 352:    */   private void configureAxis(XYPlot plot) {
/* 353:353 */     int nb = graphs_.size();
/* 354:354 */     List<String> names = new ArrayList();
/* 355:355 */     for (Map.Entry<Bornes, Graphs> entry : graphs_.entrySet()) {
/* 356:356 */       names.add(getValue()label_);
/* 357:    */     }
/* 358:    */     
/* 359:359 */     NumberAxis xAxis = new NumberAxis();
/* 360:360 */     xAxis.setTickLabelPaint(Color.GRAY);
/* 361:361 */     xAxis.setTickUnit(new StabilityTickUnit(names));
/* 362:362 */     xAxis.setRange(-0.5D, nb - 0.5D);
/* 363:363 */     plot.setDomainAxis(xAxis);
/* 364:364 */     plot.setDomainGridlinesVisible(false);
/* 365:365 */     NumberAxis yaxis = new NumberAxis();
/* 366:366 */     rescaleAxis(yaxis);
/* 367:367 */     plot.setRangeAxis(yaxis);
/* 368:    */     
/* 369:369 */     for (int i = 0; i < nb; i++) {
/* 370:370 */       ValueMarker marker = new ValueMarker(i + 0.5D);
/* 371:371 */       marker.setStroke(MARKER_STROKE);
/* 372:372 */       marker.setPaint(MARKER_PAINT);
/* 373:373 */       marker.setAlpha(1.0F);
/* 374:374 */       plot.addDomainMarker(marker);
/* 375:    */     }
/* 376:    */   }
/* 377:    */   
/* 378:    */ 
/* 379:    */ 
/* 380:    */   protected void onTsChange() {}
/* 381:    */   
/* 382:    */ 
/* 383:    */ 
/* 384:    */   protected void onDataFormatChange() {}
/* 385:    */   
/* 386:    */ 
/* 387:    */ 
/* 388:    */   protected void onColorSchemeChange()
/* 389:    */   {
/* 390:390 */     pointsRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 391:391 */     meanRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 392:392 */     smoothRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.GREEN));
/* 393:    */     
/* 394:394 */     XYPlot mainPlot = mainChart.getXYPlot();
/* 395:395 */     mainPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 396:396 */     mainPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 397:397 */     mainPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 398:398 */     mainChart.setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 399:    */     
/* 400:400 */     XYPlot detailPlot = detailChart.getXYPlot();
/* 401:401 */     detailPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 402:402 */     detailPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 403:403 */     detailPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 404:404 */     detailChart.setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 405:    */   }
/* 406:    */   
/* 407:    */ 
/* 408:    */ 
/* 409:    */ 
/* 410:    */ 
/* 411:    */ 
/* 412:    */   static class Bornes
/* 413:    */   {
/* 414:414 */     static final Bornes ZERO = new Bornes(0.0D, 0.0D);
/* 415:    */     final double min_;
/* 416:    */     final double max_;
/* 417:    */     
/* 418:    */     Bornes(double min, double max) {
/* 419:419 */       min_ = min;
/* 420:420 */       max_ = max;
/* 421:    */     }
/* 422:    */   }
/* 423:    */   
/* 424:    */ 
/* 425:    */   static class Graphs
/* 426:    */   {
/* 427:    */     final BasicXYDataset.Series S1_;
/* 428:    */     
/* 429:    */     final BasicXYDataset.Series S2_;
/* 430:    */     final BasicXYDataset.Series S3_;
/* 431:    */     final String label_;
/* 432:    */     
/* 433:    */     Graphs(BasicXYDataset.Series s1, BasicXYDataset.Series s2, BasicXYDataset.Series s3, String label)
/* 434:    */     {
/* 435:435 */       S1_ = s1;
/* 436:436 */       S2_ = s2;
/* 437:437 */       S3_ = s3;
/* 438:438 */       label_ = label;
/* 439:    */     }
/* 440:    */     
/* 441:    */     int getMaxElements() {
/* 442:442 */       int elements = S1_.getItemCount();
/* 443:443 */       if (elements < S2_.getItemCount()) {
/* 444:444 */         elements = S2_.getItemCount();
/* 445:    */       }
/* 446:446 */       if (elements < S3_.getItemCount()) {
/* 447:447 */         elements = S3_.getItemCount();
/* 448:    */       }
/* 449:    */       
/* 450:450 */       return elements;
/* 451:    */     }
/* 452:    */   }
/* 453:    */   
/* 454:    */   static class StabilityViewItem
/* 455:    */   {
/* 456:    */     private String name;
/* 457:    */     private Map<TsDomain, Double> data;
/* 458:    */     private double[] smoothedData;
/* 459:    */     
/* 460:    */     public StabilityViewItem(String name, Map<TsDomain, Double> data, double[] sdata) {
/* 461:461 */       this.name = name;
/* 462:462 */       this.data = data;
/* 463:463 */       smoothedData = sdata;
/* 464:    */     }
/* 465:    */     
/* 466:    */     public double[] getDataArray() {
/* 467:467 */       double[] array = new double[data.size()];
/* 468:468 */       int i = 0;
/* 469:469 */       for (Map.Entry<TsDomain, Double> e : data.entrySet()) {
/* 470:470 */         array[i] = ((Double)e.getValue()).doubleValue();
/* 471:471 */         i++;
/* 472:    */       }
/* 473:    */       
/* 474:474 */       return array;
/* 475:    */     }
/* 476:    */     
/* 477:    */     public double getAverage() {
/* 478:478 */       if (data == null) {
/* 479:479 */         return (0.0D / 0.0D);
/* 480:    */       }
/* 481:481 */       int n = 0;
/* 482:482 */       double s = 0.0D;
/* 483:483 */       for (Map.Entry<TsDomain, Double> e : data.entrySet()) {
/* 484:484 */         if (!Double.isNaN(((Double)e.getValue()).doubleValue())) {
/* 485:485 */           s += ((Double)e.getValue()).doubleValue();
/* 486:486 */           n++;
/* 487:    */         }
/* 488:    */       }
/* 489:    */       
/* 490:490 */       if (n == 0) {
/* 491:491 */         return (0.0D / 0.0D);
/* 492:    */       }
/* 493:493 */       return s / n;
/* 494:    */     }
/* 495:    */   }
/* 496:    */ }
