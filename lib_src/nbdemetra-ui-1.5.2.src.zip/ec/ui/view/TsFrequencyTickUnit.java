/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  5:   */ import org.jfree.chart.axis.NumberTickUnit;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class TsFrequencyTickUnit
/* 14:   */   extends NumberTickUnit
/* 15:   */ {
/* 16:   */   private TsFrequency freq_;
/* 17:   */   
/* 18:   */   public TsFrequencyTickUnit(TsFrequency freq)
/* 19:   */   {
/* 20:20 */     super(1.0D);
/* 21:21 */     freq_ = freq;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String valueToString(double value)
/* 25:   */   {
/* 26:26 */     return TsPeriod.formatShortPeriod(freq_, (int)value);
/* 27:   */   }
/* 28:   */ }
