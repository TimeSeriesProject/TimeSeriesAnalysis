/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import java.awt.Rectangle;
/*  4:   */ import java.awt.Shape;
/*  5:   */ import org.jfree.chart.entity.EntityCollection;
/*  6:   */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  7:   */ import org.jfree.data.xy.XYDataset;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class PreciseXYLineAndShapeRenderer
/* 16:   */   extends XYLineAndShapeRenderer
/* 17:   */ {
/* 18:   */   public PreciseXYLineAndShapeRenderer(boolean lines, boolean shapes)
/* 19:   */   {
/* 20:20 */     super(lines, shapes);
/* 21:   */   }
/* 22:   */   
/* 23:   */   protected void addEntity(EntityCollection entities, Shape area, XYDataset dataset, int series, int item, double entityX, double entityY)
/* 24:   */   {
/* 25:25 */     if ((getBounds()width < 2) || (getBounds()height < 2)) {
/* 26:26 */       super.addEntity(entities, null, dataset, series, item, entityX, entityY);
/* 27:   */     } else {
/* 28:28 */       super.addEntity(entities, area, dataset, series, item, entityX, entityY);
/* 29:   */     }
/* 30:   */   }
/* 31:   */ }
