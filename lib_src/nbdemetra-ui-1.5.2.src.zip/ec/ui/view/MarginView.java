/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tss.TsCollection;
/*   5:    */ import ec.tss.TsFactory;
/*   6:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   7:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   8:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*   9:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  10:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  11:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  13:    */ import ec.tstoolkit.utilities.Jdk6.Collections;
/*  14:    */ import ec.ui.ATsControl;
/*  15:    */ import ec.ui.chart.TsCharts;
/*  16:    */ import ec.ui.chart.TsXYDatasets;
/*  17:    */ import ec.ui.chart.TsXYDatasets.Builder;
/*  18:    */ import ec.ui.interfaces.IColorSchemeAble;
/*  19:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*  20:    */ import ec.util.chart.ColorScheme;
/*  21:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  22:    */ import ec.util.chart.swing.ChartCommand;
/*  23:    */ import ec.util.chart.swing.Charts;
/*  24:    */ import ec.util.chart.swing.SwingColorSchemeSupport;
/*  25:    */ import java.awt.BasicStroke;
/*  26:    */ import java.awt.BorderLayout;
/*  27:    */ import java.awt.Color;
/*  28:    */ import java.awt.Font;
/*  29:    */ import java.awt.Graphics2D;
/*  30:    */ import java.awt.Paint;
/*  31:    */ import java.awt.Shape;
/*  32:    */ import java.awt.Stroke;
/*  33:    */ import java.awt.Toolkit;
/*  34:    */ import java.awt.datatransfer.Clipboard;
/*  35:    */ import java.awt.datatransfer.Transferable;
/*  36:    */ import java.awt.event.ActionEvent;
/*  37:    */ import java.awt.event.KeyEvent;
/*  38:    */ import java.awt.event.KeyListener;
/*  39:    */ import java.awt.geom.Ellipse2D.Double;
/*  40:    */ import java.beans.PropertyChangeEvent;
/*  41:    */ import java.beans.PropertyChangeListener;
/*  42:    */ import java.util.Collection;
/*  43:    */ import java.util.Date;
/*  44:    */ import javax.swing.AbstractAction;
/*  45:    */ import javax.swing.JCheckBoxMenuItem;
/*  46:    */ import javax.swing.JMenu;
/*  47:    */ import javax.swing.JMenuItem;
/*  48:    */ import org.jfree.chart.ChartFactory;
/*  49:    */ import org.jfree.chart.ChartMouseEvent;
/*  50:    */ import org.jfree.chart.ChartMouseListener;
/*  51:    */ import org.jfree.chart.ChartPanel;
/*  52:    */ import org.jfree.chart.JFreeChart;
/*  53:    */ import org.jfree.chart.axis.DateAxis;
/*  54:    */ import org.jfree.chart.axis.DateTickMarkPosition;
/*  55:    */ import org.jfree.chart.axis.NumberAxis;
/*  56:    */ import org.jfree.chart.entity.XYItemEntity;
/*  57:    */ import org.jfree.chart.plot.DatasetRenderingOrder;
/*  58:    */ import org.jfree.chart.plot.IntervalMarker;
/*  59:    */ import org.jfree.chart.plot.Marker;
/*  60:    */ import org.jfree.chart.plot.Plot;
/*  61:    */ import org.jfree.chart.plot.PlotOrientation;
/*  62:    */ import org.jfree.chart.plot.ValueMarker;
/*  63:    */ import org.jfree.chart.plot.XYPlot;
/*  64:    */ import org.jfree.chart.renderer.AbstractRenderer;
/*  65:    */ import org.jfree.chart.renderer.xy.XYDifferenceRenderer;
/*  66:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  67:    */ import org.jfree.data.xy.XYDataset;
/*  68:    */ import org.jfree.ui.Layer;
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ public final class MarginView
/*  85:    */   extends ATsControl
/*  86:    */   implements IColorSchemeAble
/*  87:    */ {
/*  88:    */   private static final String DATA_PROPERTY = "data";
/*  89:    */   private static final String PRECISION_MARKERS_VISIBLE_PROPERTY = "precisionMarkersVisible";
/*  90:    */   private static final int MAIN_INDEX = 1;
/*  91:    */   private static final int DIFFERENCE_INDEX = 0;
/*  92: 92 */   private static final Stroke DATE_MARKER_STROKE = new BasicStroke(1.0F, 1, 1, 1.0F, new float[] { 6.0F, 6.0F }, 0.0F);
/*  93:    */   private static final float DATE_MARKER_ALPHA = 0.8F;
/*  94: 94 */   private static final ColorScheme.KnownColor MAIN_COLOR = ColorScheme.KnownColor.RED;
/*  95: 95 */   private static final ColorScheme.KnownColor DIFFERENCE_COLOR = ColorScheme.KnownColor.BLUE;
/*  96: 96 */   private static final ColorScheme.KnownColor DATE_MARKER_COLOR = ColorScheme.KnownColor.ORANGE;
/*  97:    */   
/*  98:    */   private final ChartPanel chartPanel;
/*  99:    */   private MarginData data;
/* 100:    */   private boolean precisionMarkersVisible;
/* 101:    */   private final RevealObs revealObs;
/* 102:    */   private static XYItemEntity highlight;
/* 103:    */   
/* 104:    */   public MarginView()
/* 105:    */   {
/* 106:106 */     chartPanel = new ChartPanel(createMarginViewChart());
/* 107:107 */     data = new MarginData(null, null, null, false, null);
/* 108:108 */     precisionMarkersVisible = false;
/* 109:109 */     revealObs = new RevealObs();
/* 110:    */     
/* 111:111 */     Charts.avoidScaling(chartPanel);
/* 112:112 */     Charts.enableFocusOnClick(chartPanel);
/* 113:113 */     setLayout(new BorderLayout());
/* 114:114 */     add(chartPanel, "Center");
/* 115:    */     
/* 116:116 */     addPropertyChangeListener(new PropertyChangeListener() {
/* 117:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 118:    */         String str;
/* 119:119 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1702971689:  if (str.equals("precisionMarkersVisible")) break;  case 3076010:  if ((goto 77) && (str.equals("data")))
/* 120:    */           {
/* 121:121 */             MarginView.this.onDataChange();
/* 122:122 */             return;
/* 123:    */             
/* 124:124 */             MarginView.this.onPrecisionMarkersVisible();
/* 125:    */           }
/* 126:    */           break;
/* 127:    */         }
/* 128:    */       }
/* 129:129 */     });
/* 130:130 */     chartPanel.addChartMouseListener(new HighlightChartMouseListener2(null));
/* 131:131 */     chartPanel.addKeyListener(revealObs);
/* 132:    */     
/* 133:133 */     onDataFormatChange();
/* 134:134 */     onColorSchemeChange();
/* 135:    */     
/* 136:136 */     chartPanel.setPopupMenu(buildMenu().getPopupMenu());
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */   protected void onDataFormatChange()
/* 141:    */   {
/* 142:142 */     DateAxis domainAxis = (DateAxis)chartPanel.getChart().getXYPlot().getDomainAxis();
/* 143:    */     try {
/* 144:144 */       domainAxis.setDateFormatOverride(themeSupport.getDataFormat().newDateFormat());
/* 145:    */     }
/* 146:    */     catch (IllegalArgumentException localIllegalArgumentException) {}
/* 147:    */   }
/* 148:    */   
/* 149:    */ 
/* 150:    */   protected void onColorSchemeChange()
/* 151:    */   {
/* 152:152 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 153:153 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 154:154 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 155:155 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 156:156 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 157:    */     
/* 158:158 */     XYLineAndShapeRenderer main = (XYLineAndShapeRenderer)plot.getRenderer(1);
/* 159:159 */     main.setBasePaint((Paint)themeSupport.getLineColor(MAIN_COLOR));
/* 160:    */     
/* 161:161 */     XYDifferenceRenderer difference = (XYDifferenceRenderer)plot.getRenderer(0);
/* 162:162 */     Color diffArea = SwingColorSchemeSupport.withAlpha((Color)themeSupport.getAreaColor(DIFFERENCE_COLOR), 150);
/* 163:163 */     difference.setPositivePaint(diffArea);
/* 164:164 */     difference.setNegativePaint(diffArea);
/* 165:165 */     difference.setBasePaint((Paint)themeSupport.getLineColor(DIFFERENCE_COLOR));
/* 166:    */     
/* 167:167 */     Collection<Marker> markers = plot.getDomainMarkers(Layer.FOREGROUND);
/* 168:168 */     if (!Jdk6.Collections.isNullOrEmpty(markers)) {
/* 169:169 */       Color markerColor = (Color)themeSupport.getLineColor(DATE_MARKER_COLOR);
/* 170:170 */       for (Marker o : markers) {
/* 171:171 */         o.setPaint(markerColor);
/* 172:    */       }
/* 173:    */     }
/* 174:    */     
/* 175:175 */     Collection<Marker> intervalMarkers = plot.getDomainMarkers(Layer.BACKGROUND);
/* 176:176 */     if (!Jdk6.Collections.isNullOrEmpty(intervalMarkers)) {
/* 177:177 */       Color markerColor = (Color)themeSupport.getLineColor(ColorScheme.KnownColor.ORANGE);
/* 178:178 */       for (Marker o : intervalMarkers) {
/* 179:179 */         o.setPaint(markerColor);
/* 180:    */       }
/* 181:    */     }
/* 182:    */   }
/* 183:    */   
/* 184:    */   private void onDataChange() {
/* 185:185 */     chartPanel.getChart().setNotify(false);
/* 186:    */     
/* 187:187 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 188:    */     
/* 189:189 */     plot.setDataset(1, TsXYDatasets.from("series", data.series));
/* 190:190 */     plot.setDataset(0, TsXYDatasets.builder().add("lower", data.lower).add("upper", data.upper).build());
/* 191:    */     
/* 192:192 */     onPrecisionMarkersVisible();
/* 193:193 */     onDataFormatChange();
/* 194:    */     
/* 195:195 */     chartPanel.getChart().setNotify(true);
/* 196:    */   }
/* 197:    */   
/* 198:    */   private void onPrecisionMarkersVisible() {
/* 199:199 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 200:200 */     plot.clearDomainMarkers();
/* 201:201 */     addDateMarkers();
/* 202:202 */     if (precisionMarkersVisible) {
/* 203:203 */       addPrecisionMarkers();
/* 204:    */     }
/* 205:205 */     onColorSchemeChange();
/* 206:    */   }
/* 207:    */   
/* 208:    */ 
/* 209:    */ 
/* 210:    */   public ColorScheme getColorScheme()
/* 211:    */   {
/* 212:212 */     return themeSupport.getLocalColorScheme();
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void setColorScheme(ColorScheme colorScheme)
/* 216:    */   {
/* 217:217 */     themeSupport.setLocalColorScheme(colorScheme);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setData(TsData series, TsData lower, TsData upper, Date... markers) {
/* 221:221 */     setData(series, lower, upper, false, markers);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void setData(TsData series, TsData lower, TsData upper, boolean multiplicative, Date... markers) {
/* 225:225 */     data = new MarginData(series, lower, upper, multiplicative, markers);
/* 226:226 */     firePropertyChange("data", null, data);
/* 227:    */   }
/* 228:    */   
/* 229:    */   private boolean isPrecisionMarkersVisible() {
/* 230:230 */     return precisionMarkersVisible;
/* 231:    */   }
/* 232:    */   
/* 233:    */   private void setPrecisionMarkersVisible(boolean precisionMarkersVisible) {
/* 234:234 */     boolean old = this.precisionMarkersVisible;
/* 235:235 */     this.precisionMarkersVisible = precisionMarkersVisible;
/* 236:236 */     firePropertyChange("precisionMarkersVisible", old, this.precisionMarkersVisible);
/* 237:    */   }
/* 238:    */   
/* 239:    */   private void addDateMarkers()
/* 240:    */   {
/* 241:241 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 242:242 */     if (data.markers != null) {
/* 243:243 */       for (Date o : data.markers) {
/* 244:244 */         ValueMarker marker = new ValueMarker(new org.jfree.data.time.Day(o).getFirstMillisecond());
/* 245:245 */         marker.setStroke(DATE_MARKER_STROKE);
/* 246:246 */         marker.setAlpha(0.8F);
/* 247:247 */         plot.addDomainMarker(marker, Layer.FOREGROUND);
/* 248:    */       }
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   private void addPrecisionMarkers() {
/* 253:253 */     TsData tmp = data.series.fittoDomain(data.upper.getDomain());
/* 254:254 */     TsData values = data.multiplicative ? tmp.div(data.upper) : tmp.minus(data.upper);
/* 255:255 */     DescriptiveStatistics stats = new DescriptiveStatistics(values);
/* 256:256 */     double min = stats.getMin();
/* 257:257 */     double max = stats.getMax();
/* 258:258 */     if (max - min > 0.0D) {
/* 259:259 */       XYPlot plot = chartPanel.getChart().getXYPlot();
/* 260:260 */       TsDomain domain = values.getDomain().extend(0, 1);
/* 261:261 */       for (int i = 0; i < domain.getLength() - 1; i++) {
/* 262:262 */         float val = (float)((values.get(i) - min) / (max - min));
/* 263:263 */         IntervalMarker marker = new IntervalMarker(
/* 264:264 */           domain.get(i).firstday().getTime().getTime(), 
/* 265:265 */           domain.get(i + 1).firstday().getTime().getTime());
/* 266:266 */         marker.setOutlineStroke(null);
/* 267:267 */         marker.setAlpha(1.0F - val);
/* 268:268 */         plot.addDomainMarker(marker, Layer.BACKGROUND);
/* 269:    */       }
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   private JFreeChart createMarginViewChart() {
/* 274:274 */     JFreeChart result = ChartFactory.createXYLineChart("", "", "", Charts.emptyXYDataset(), PlotOrientation.VERTICAL, false, false, false);
/* 275:275 */     result.setPadding(TsCharts.CHART_PADDING);
/* 276:    */     
/* 277:277 */     XYPlot plot = result.getXYPlot();
/* 278:278 */     plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
/* 279:    */     
/* 280:280 */     ITsChart.LinesThickness linesThickness = ITsChart.LinesThickness.Thin;
/* 281:    */     
/* 282:282 */     XYLineAndShapeRenderer main = new LineRenderer();
/* 283:283 */     plot.setRenderer(1, main);
/* 284:    */     
/* 285:285 */     XYDifferenceRenderer difference = new XYDifferenceRenderer();
/* 286:286 */     difference.setAutoPopulateSeriesPaint(false);
/* 287:287 */     difference.setAutoPopulateSeriesStroke(false);
/* 288:288 */     difference.setBaseStroke(TsCharts.getNormalStroke(linesThickness));
/* 289:289 */     plot.setRenderer(0, difference);
/* 290:    */     
/* 291:291 */     DateAxis domainAxis = new DateAxis();
/* 292:292 */     domainAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 293:293 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 294:294 */     plot.setDomainAxis(domainAxis);
/* 295:    */     
/* 296:296 */     NumberAxis rangeAxis = new NumberAxis();
/* 297:297 */     rangeAxis.setAutoRangeIncludesZero(false);
/* 298:298 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 299:299 */     plot.setRangeAxis(rangeAxis);
/* 300:    */     
/* 301:301 */     return result;
/* 302:    */   }
/* 303:    */   
/* 304:    */   private JMenu buildMenu() {
/* 305:305 */     JMenu result = new JMenu();
/* 306:    */     
/* 307:307 */     result.add(new JCheckBoxMenuItem(new AbstractAction()
/* 308:    */     {
/* 309:    */       public void actionPerformed(ActionEvent e) {
/* 310:310 */         MarginView.this.setPrecisionMarkersVisible(!MarginView.this.isPrecisionMarkersVisible());
/* 311:    */       }
/* 312:312 */     })).setText("Show precision gradient");
/* 313:    */     
/* 314:314 */     result.add(new AbstractAction()
/* 315:    */     {
/* 316:    */       public void actionPerformed(ActionEvent e) {
/* 317:317 */         TsCollection col = TsFactory.instance.createTsCollection();
/* 318:318 */         col.add(TsFactory.instance.createTs("series", null, data.series));
/* 319:319 */         col.add(TsFactory.instance.createTs("lower", null, data.lower));
/* 320:320 */         col.add(TsFactory.instance.createTs("upper", null, data.upper));
/* 321:321 */         Transferable t = TssTransferSupport.getDefault().fromTsCollection(col);
/* 322:322 */         Toolkit.getDefaultToolkit().getSystemClipboard().setContents(t, null);
/* 323:    */       }
/* 324:324 */     }).setText("Copy all series");
/* 325:    */     
/* 326:326 */     JMenu export = new JMenu("Export image to");
/* 327:327 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 328:328 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 329:329 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 330:330 */     result.add(export);
/* 331:    */     
/* 332:332 */     return result;
/* 333:    */   }
/* 334:    */   
/* 335:    */   private static final class MarginData
/* 336:    */   {
/* 337:    */     final TsData series;
/* 338:    */     final TsData lower;
/* 339:    */     final TsData upper;
/* 340:    */     final Date[] markers;
/* 341:    */     final boolean multiplicative;
/* 342:    */     
/* 343:    */     public MarginData(TsData series, TsData lower, TsData upper, boolean multiplicative, Date[] markers) {
/* 344:344 */       this.series = series;
/* 345:345 */       this.lower = lower;
/* 346:346 */       this.upper = upper;
/* 347:347 */       this.markers = markers;
/* 348:348 */       this.multiplicative = multiplicative;
/* 349:    */     }
/* 350:    */   }
/* 351:    */   
/* 352:    */   private final class HighlightChartMouseListener2 implements ChartMouseListener
/* 353:    */   {
/* 354:    */     private HighlightChartMouseListener2() {}
/* 355:    */     
/* 356:    */     public void chartMouseClicked(ChartMouseEvent event) {}
/* 357:    */     
/* 358:    */     public void chartMouseMoved(ChartMouseEvent event)
/* 359:    */     {
/* 360:360 */       if ((event.getEntity() instanceof XYItemEntity)) {
/* 361:361 */         XYItemEntity xxx = (XYItemEntity)event.getEntity();
/* 362:362 */         MarginView.this.setHighlightedObs(xxx);
/* 363:    */       } else {
/* 364:364 */         MarginView.this.setHighlightedObs(null);
/* 365:    */       }
/* 366:    */     }
/* 367:    */   }
/* 368:    */   
/* 369:    */   private void setHighlightedObs(XYItemEntity item) {
/* 370:370 */     if ((item == null) || (highlight != item)) {
/* 371:371 */       highlight = item;
/* 372:372 */       chartPanel.getChart().fireChartChanged();
/* 373:    */     }
/* 374:    */   }
/* 375:    */   
/* 376:    */   public final class RevealObs implements KeyListener
/* 377:    */   {
/* 378:378 */     private boolean enabled = false;
/* 379:    */     
/* 380:    */     public RevealObs() {}
/* 381:    */     
/* 382:    */     public void keyTyped(KeyEvent e) {}
/* 383:    */     
/* 384:    */     public void keyPressed(KeyEvent e)
/* 385:    */     {
/* 386:386 */       if (e.getKeyChar() == 'r') {
/* 387:387 */         setEnabled(true);
/* 388:    */       }
/* 389:    */     }
/* 390:    */     
/* 391:    */     public void keyReleased(KeyEvent e)
/* 392:    */     {
/* 393:393 */       if (e.getKeyChar() == 'r') {
/* 394:394 */         setEnabled(false);
/* 395:    */       }
/* 396:    */     }
/* 397:    */     
/* 398:    */     private void setEnabled(boolean enabled) {
/* 399:399 */       if (this.enabled != enabled) {
/* 400:400 */         this.enabled = enabled;
/* 401:401 */         firePropertyChange("revealObs", !enabled, enabled);
/* 402:402 */         chartPanel.getChart().fireChartChanged();
/* 403:    */       }
/* 404:    */     }
/* 405:    */     
/* 406:    */     public boolean isEnabled() {
/* 407:407 */       return enabled;
/* 408:    */     }
/* 409:    */   }
/* 410:    */   
/* 411:411 */   private static final Shape ITEM_SHAPE = new Ellipse2D.Double(-3.0D, -3.0D, 6.0D, 6.0D);
/* 412:    */   
/* 413:    */   private class LineRenderer extends XYLineAndShapeRenderer
/* 414:    */   {
/* 415:    */     public LineRenderer() {
/* 416:416 */       setBaseItemLabelsVisible(true);
/* 417:417 */       setAutoPopulateSeriesShape(false);
/* 418:418 */       setAutoPopulateSeriesFillPaint(false);
/* 419:419 */       setAutoPopulateSeriesOutlineStroke(false);
/* 420:420 */       setBaseShape(MarginView.ITEM_SHAPE);
/* 421:421 */       setUseFillPaint(true);
/* 422:    */     }
/* 423:    */     
/* 424:    */     public boolean getItemShapeVisible(int series, int item)
/* 425:    */     {
/* 426:426 */       return (revealObs.isEnabled()) || (isObsHighlighted(series, item));
/* 427:    */     }
/* 428:    */     
/* 429:    */     private boolean isObsHighlighted(int series, int item) {
/* 430:430 */       XYPlot plot = (XYPlot)chartPanel.getChart().getPlot();
/* 431:431 */       if ((MarginView.highlight != null) && (MarginView.highlight.getDataset().equals(plot.getDataset(1)))) {
/* 432:432 */         return (MarginView.highlight.getSeriesIndex() == series) && (MarginView.highlight.getItem() == item);
/* 433:    */       }
/* 434:434 */       return false;
/* 435:    */     }
/* 436:    */     
/* 437:    */ 
/* 438:    */     public boolean isItemLabelVisible(int series, int item)
/* 439:    */     {
/* 440:440 */       return isObsHighlighted(series, item);
/* 441:    */     }
/* 442:    */     
/* 443:    */     public Paint getSeriesPaint(int series)
/* 444:    */     {
/* 445:445 */       return (Paint)themeSupport.getLineColor(MarginView.MAIN_COLOR);
/* 446:    */     }
/* 447:    */     
/* 448:    */     public Paint getItemPaint(int series, int item)
/* 449:    */     {
/* 450:450 */       return (Paint)themeSupport.getLineColor(MarginView.MAIN_COLOR);
/* 451:    */     }
/* 452:    */     
/* 453:    */     public Paint getItemFillPaint(int series, int item)
/* 454:    */     {
/* 455:455 */       return chartPanel.getChart().getPlot().getBackgroundPaint();
/* 456:    */     }
/* 457:    */     
/* 458:    */     public Stroke getSeriesStroke(int series)
/* 459:    */     {
/* 460:460 */       return TsCharts.getStrongStroke(ITsChart.LinesThickness.Thin);
/* 461:    */     }
/* 462:    */     
/* 463:    */     public Stroke getItemOutlineStroke(int series, int item)
/* 464:    */     {
/* 465:465 */       return TsCharts.getStrongStroke(ITsChart.LinesThickness.Thin);
/* 466:    */     }
/* 467:    */     
/* 468:    */     protected void drawItemLabel(Graphics2D g2, PlotOrientation orientation, XYDataset dataset, int series, int item, double x, double y, boolean negative)
/* 469:    */     {
/* 470:470 */       String label = generateLabel();
/* 471:471 */       Font font = chartPanel.getFont();
/* 472:472 */       Paint paint = chartPanel.getChart().getPlot().getBackgroundPaint();
/* 473:473 */       Paint fillPaint = (Paint)themeSupport.getLineColor(MarginView.MAIN_COLOR);
/* 474:474 */       Stroke outlineStroke = AbstractRenderer.DEFAULT_STROKE;
/* 475:475 */       Charts.drawItemLabelAsTooltip(g2, x, y, 3.0D, label, font, paint, fillPaint, paint, outlineStroke);
/* 476:    */     }
/* 477:    */     
/* 478:    */     private String generateLabel() {
/* 479:479 */       TsPeriod p = new TsPeriod(data.series.getFrequency(), new Date(MarginView.highlight.getDataset().getX(0, MarginView.highlight.getItem()).longValue()));
/* 480:480 */       String label = "Period : " + p.toString() + "\nValue : ";
/* 481:481 */       label = label + themeSupport.getDataFormat().numberFormatter().formatAsString(Double.valueOf(data.series.get(p)));
/* 482:482 */       return label;
/* 483:    */     }
/* 484:    */   }
/* 485:    */ }
