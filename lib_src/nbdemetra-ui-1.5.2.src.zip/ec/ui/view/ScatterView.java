/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*   5:    */ import ec.tstoolkit.uihelper.DiscreteDisplayDomain;
/*   6:    */ import ec.tstoolkit.uihelper.IDiscreteInformationProvider;
/*   7:    */ import ec.ui.chart.TsCharts;
/*   8:    */ import ec.util.chart.swing.ChartCommand;
/*   9:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  10:    */ import java.awt.Paint;
/*  11:    */ import java.awt.geom.Rectangle2D.Double;
/*  12:    */ import java.text.DecimalFormat;
/*  13:    */ import javax.swing.JMenu;
/*  14:    */ import javax.swing.JMenuItem;
/*  15:    */ import org.jfree.chart.ChartFactory;
/*  16:    */ import org.jfree.chart.ChartPanel;
/*  17:    */ import org.jfree.chart.JFreeChart;
/*  18:    */ import org.jfree.chart.axis.NumberAxis;
/*  19:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  20:    */ import org.jfree.chart.block.BlockBorder;
/*  21:    */ import org.jfree.chart.plot.PlotOrientation;
/*  22:    */ import org.jfree.chart.plot.XYPlot;
/*  23:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  24:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  25:    */ import org.jfree.chart.title.LegendTitle;
/*  26:    */ import org.jfree.chart.title.TextTitle;
/*  27:    */ import org.jfree.data.xy.XYDataset;
/*  28:    */ import org.jfree.data.xy.XYSeries;
/*  29:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ public class ScatterView
/*  34:    */   extends AChartView
/*  35:    */ {
/*  36:    */   public static final double DEFAULT_MIN_X = 0.0D;
/*  37:    */   public static final double DEFAULT_MAX_X = 35.0D;
/*  38:    */   public static final double DEFAULT_MIN_Y = -1.0D;
/*  39:    */   public static final double DEFAULT_MAX_Y = 1.0D;
/*  40: 40 */   public static final NumberTickUnit DEFAULT_TICKUNIT_X = new NumberTickUnit(2.0D);
/*  41: 41 */   public static final NumberTickUnit DEFAULT_TICKUNIT_Y = new NumberTickUnit(0.1D);
/*  42: 42 */   public static final DecimalFormat DEFAULT_FORMAT = new DecimalFormat("0.##");
/*  43:    */   protected final IDiscreteInformationProvider provider;
/*  44:    */   
/*  45:    */   public ScatterView(IDiscreteInformationProvider provider)
/*  46:    */   {
/*  47: 47 */     super(36, PlotOrientation.VERTICAL, 1.0D, 36.0D, -1.0D, 1.0D, DEFAULT_TICKUNIT_X, DEFAULT_TICKUNIT_Y, DEFAULT_FORMAT);
/*  48: 48 */     setZoomable(false);
/*  49: 49 */     this.provider = provider;
/*  50: 50 */     chartPanel.setChart(createScatterViewChart(seriesCollection));
/*  51: 51 */     onDomainChange();
/*  52: 52 */     chartPanel.setPopupMenu(buildMenu(chartPanel).getPopupMenu());
/*  53:    */   }
/*  54:    */   
/*  55:    */ 
/*  56:    */   protected void onColorSchemeChange()
/*  57:    */   {
/*  58: 58 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/*  59: 59 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/*  60: 60 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/*  61: 61 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/*  62: 62 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/*  63:    */     
/*  64: 64 */     XYItemRenderer renderer = plot.getRenderer();
/*  65: 65 */     for (int i = 0; i < seriesCollection.getSeriesCount(); i++) {
/*  66: 66 */       renderer.setSeriesPaint(i, themeSupport.getLineColor(i));
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void onDomainChange()
/*  71:    */   {
/*  72: 72 */     DiscreteDisplayDomain domain = isBaseValues() ? 
/*  73: 73 */       provider.getDiscreteDisplayDomain(getPoints()) : 
/*  74: 74 */       provider.getDiscreteDisplayDomain((int)getMinX(), (int)getMaxX());
/*  75:    */     
/*  76: 76 */     seriesCollection.removeAllSeries();
/*  77:    */     
/*  78: 78 */     String[] components = provider.getComponents();
/*  79: 79 */     for (int i = 0; i < components.length; i++) {
/*  80: 80 */       if (provider.isDefined(i)) {
/*  81: 81 */         double[] data = provider.getDataArray(i, domain);
/*  82: 82 */         XYSeries series = new XYSeries(components[i]);
/*  83: 83 */         for (int j = 0; j < data.length; j++) {
/*  84: 84 */           series.add(domain.x(j), data[j]);
/*  85:    */         }
/*  86: 86 */         seriesCollection.addSeries(series);
/*  87:    */       }
/*  88:    */     }
/*  89:    */     
/*  90: 90 */     int fx = getFactorX();
/*  91: 91 */     chartPanel.getChart().getXYPlot().getRenderer().setBaseShape(new Rectangle2D.Double(-2 * fx, -2 * fx, 4 * fx, 4 * fx));
/*  92: 92 */     chartPanel.getChart().getLegend().setVisible(seriesCollection.getSeriesCount() > 1);
/*  93:    */     
/*  94: 94 */     configureAxis();
/*  95: 95 */     onColorSchemeChange();
/*  96: 96 */     onFocusChange();
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected void onFocusChange()
/* 100:    */   {
/* 101:101 */     int focusIndex = getFocusIndex();
/* 102:102 */     XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer)chartPanel.getChart().getXYPlot().getRenderer();
/* 103:103 */     for (int i = 0; i < seriesCollection.getSeriesCount(); i++) {
/* 104:104 */       renderer.setSeriesShapesFilled(i, focusIndex == i);
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static JFreeChart createScatterViewChart(XYDataset dataset)
/* 109:    */   {
/* 110:110 */     JFreeChart result = ChartFactory.createScatterPlot("", "", "", dataset, PlotOrientation.VERTICAL, true, false, false);
/* 111:111 */     result.setPadding(TsCharts.CHART_PADDING);
/* 112:112 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 113:113 */     result.getLegend().setFrame(BlockBorder.NONE);
/* 114:114 */     result.getLegend().setBackgroundPaint(null);
/* 115:    */     
/* 116:116 */     XYPlot plot = result.getXYPlot();
/* 117:    */     
/* 118:118 */     XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
/* 119:119 */     renderer.setAutoPopulateSeriesShape(false);
/* 120:120 */     renderer.setAutoPopulateSeriesFillPaint(false);
/* 121:121 */     renderer.setBaseShapesFilled(false);
/* 122:122 */     plot.setRenderer(renderer);
/* 123:    */     
/* 124:124 */     NumberAxis rangeAxis = new NumberAxis();
/* 125:125 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 126:126 */     plot.setRangeAxis(rangeAxis);
/* 127:    */     
/* 128:128 */     NumberAxis domainAxis = new NumberAxis();
/* 129:129 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 130:130 */     plot.setDomainAxis(domainAxis);
/* 131:    */     
/* 132:132 */     return result;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static JMenu buildMenu(ChartPanel chartPanel) {
/* 136:136 */     JMenu result = new JMenu();
/* 137:    */     
/* 138:138 */     result.add(new CustomCommand(null).toAction(chartPanel)).setText("Copy all visible");
/* 139:    */     
/* 140:140 */     JMenu export = new JMenu("Export image to");
/* 141:141 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 142:142 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 143:143 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 144:144 */     result.add(export);
/* 145:    */     
/* 146:146 */     return result;
/* 147:    */   }
/* 148:    */   
/* 149:    */   private static class CustomCommand extends MatrixChartCommand
/* 150:    */   {
/* 151:    */     protected Matrix toMatrix(ChartPanel chartPanel)
/* 152:    */     {
/* 153:153 */       XYDataset dataset = chartPanel.getChart().getXYPlot().getDataset(0);
/* 154:154 */       Matrix result = new Matrix(dataset.getItemCount(0), dataset.getSeriesCount() + 1);
/* 155:155 */       for (int i = 0; i < result.getRowsCount(); i++) {
/* 156:156 */         result.set(i, 0, dataset.getXValue(0, i));
/* 157:157 */         for (int j = 0; j < dataset.getSeriesCount(); j++) {
/* 158:158 */           result.set(i, j + 1, dataset.getYValue(j, i));
/* 159:    */         }
/* 160:    */       }
/* 161:161 */       return result;
/* 162:    */     }
/* 163:    */     
/* 164:    */     public boolean isEnabled(ChartPanel chartPanel)
/* 165:    */     {
/* 166:166 */       XYPlot plot = chartPanel.getChart().getXYPlot();
/* 167:167 */       return (plot.getDatasetCount() > 0) && (plot.getDataset(0).getSeriesCount() > 0);
/* 168:    */     }
/* 169:    */   }
/* 170:    */ }
