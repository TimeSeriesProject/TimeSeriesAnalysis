/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.arima.Spectrum;
/*  4:   */ import ec.util.chart.swing.Charts;
/*  5:   */ import java.awt.BorderLayout;
/*  6:   */ import java.text.DecimalFormat;
/*  7:   */ import javax.swing.JComponent;
/*  8:   */ import org.jfree.chart.ChartFactory;
/*  9:   */ import org.jfree.chart.ChartPanel;
/* 10:   */ import org.jfree.chart.JFreeChart;
/* 11:   */ import org.jfree.chart.axis.NumberAxis;
/* 12:   */ import org.jfree.chart.axis.NumberTickUnit;
/* 13:   */ import org.jfree.chart.plot.PlotOrientation;
/* 14:   */ import org.jfree.chart.plot.XYPlot;
/* 15:   */ import org.jfree.data.xy.XYSeries;
/* 16:   */ import org.jfree.data.xy.XYSeriesCollection;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public class SpectrumView
/* 25:   */   extends JComponent
/* 26:   */ {
/* 27:   */   private XYSeriesCollection coll_;
/* 28:   */   private ChartPanel panel_;
/* 29:29 */   private int n_ = 600;
/* 30:30 */   private double g_max = 1000000.0D;
/* 31:   */   
/* 32:   */   public SpectrumView() {
/* 33:33 */     setLayout(new BorderLayout());
/* 34:   */     
/* 35:35 */     panel_ = new ChartPanel(null);
/* 36:36 */     Charts.avoidScaling(panel_);
/* 37:37 */     add(panel_, "Center");
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void add(String name, Spectrum spectrum) {
/* 41:41 */     XYSeries series = new XYSeries(name);
/* 42:42 */     for (int i = 0; i <= n_; i++)
/* 43:   */     {
/* 44:44 */       double f = i * 3.141592653589793D / n_;
/* 45:45 */       double s = spectrum.get(f);
/* 46:46 */       series.add(f, (Double.isNaN(s)) || (s > g_max) ? g_max : s);
/* 47:   */     }
/* 48:48 */     coll_ = new XYSeriesCollection(series);
/* 49:49 */     panel_.setChart(
/* 50:50 */       ChartFactory.createXYLineChart(null, null, null, coll_, PlotOrientation.VERTICAL, coll_.getSeriesCount() > 1, false, false));
/* 51:   */     
/* 52:52 */     XYPlot plot = panel_.getChart().getXYPlot();
/* 53:53 */     configurePlot(plot);
/* 54:   */   }
/* 55:   */   
/* 56:   */   private void configurePlot(XYPlot plot)
/* 57:   */   {
/* 58:58 */     NumberAxis ra = new NumberAxis();
/* 59:59 */     ra.setRange(0.0D, 1.0D);
/* 60:60 */     ra.setTickUnit(new NumberTickUnit(0.1D));
/* 61:61 */     ra.setNumberFormatOverride(new DecimalFormat("0.###"));
/* 62:62 */     plot.setRangeAxis(ra);
/* 63:   */     
/* 64:   */ 
/* 65:65 */     NumberAxis da = new NumberAxis();
/* 66:66 */     da.setRange(0.0D, 3.141592653589793D);
/* 67:67 */     da.setTickUnit(new PiNumberTickUnit(1.570796326794897D));
/* 68:68 */     plot.setDomainAxis(da);
/* 69:   */   }
/* 70:   */ }
