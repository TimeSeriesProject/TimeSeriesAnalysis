/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tstoolkit.data.IReadDataBlock;
/*   6:    */ import ec.tstoolkit.data.Periodogram;
/*   7:    */ import ec.tstoolkit.data.Values;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*   9:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  10:    */ import ec.ui.ATsView;
/*  11:    */ import ec.ui.ATsView.TsTransferHandler;
/*  12:    */ import ec.ui.chart.TsCharts;
/*  13:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  14:    */ import ec.util.chart.swing.ChartCommand;
/*  15:    */ import ec.util.chart.swing.Charts;
/*  16:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  17:    */ import java.awt.BasicStroke;
/*  18:    */ import java.awt.BorderLayout;
/*  19:    */ import java.awt.Paint;
/*  20:    */ import java.awt.Stroke;
/*  21:    */ import java.util.ArrayList;
/*  22:    */ import java.util.Collection;
/*  23:    */ import java.util.List;
/*  24:    */ import javax.swing.JMenu;
/*  25:    */ import javax.swing.JMenuItem;
/*  26:    */ import org.jfree.chart.ChartFactory;
/*  27:    */ import org.jfree.chart.ChartPanel;
/*  28:    */ import org.jfree.chart.JFreeChart;
/*  29:    */ import org.jfree.chart.axis.NumberAxis;
/*  30:    */ import org.jfree.chart.axis.ValueAxis;
/*  31:    */ import org.jfree.chart.plot.Marker;
/*  32:    */ import org.jfree.chart.plot.PlotOrientation;
/*  33:    */ import org.jfree.chart.plot.ValueMarker;
/*  34:    */ import org.jfree.chart.plot.XYPlot;
/*  35:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  36:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  37:    */ import org.jfree.chart.title.TextTitle;
/*  38:    */ import org.jfree.data.xy.XYSeries;
/*  39:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  40:    */ import org.jfree.ui.Layer;
/*  41:    */ 
/*  42:    */ public abstract class ARPView extends ATsView
/*  43:    */ {
/*  44:    */   protected static final double TWO_PI = 6.283185307179586D;
/*  45: 45 */   protected static final Stroke FREQ_MARKER_STROKE = new BasicStroke(5.0F);
/*  46:    */   
/*  47:    */   protected static final float FREQ_MARKER_ALPHA = 0.4F;
/*  48:    */   protected final ChartPanel chartPanel;
/*  49: 49 */   protected ARPData data = null;
/*  50:    */   
/*  51:    */   protected ARPView() {
/*  52: 52 */     chartPanel = new ChartPanel(createARPChart());
/*  53: 53 */     Charts.avoidScaling(chartPanel);
/*  54: 54 */     chartPanel.setDomainZoomable(false);
/*  55: 55 */     chartPanel.setRangeZoomable(false);
/*  56:    */     
/*  57: 57 */     setLayout(new BorderLayout());
/*  58: 58 */     add(chartPanel, "Center");
/*  59:    */     
/*  60: 60 */     setTransferHandler(new ATsView.TsTransferHandler(this));
/*  61: 61 */     chartPanel.setPopupMenu(buildMenu().getPopupMenu());
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void reset() {
/*  65: 65 */     XYPlot plot = getPlot();
/*  66: 66 */     plot.clearDomainMarkers();
/*  67: 67 */     plot.clearRangeMarkers();
/*  68:    */     
/*  69: 69 */     if (data == null) {
/*  70: 70 */       plot.setDataset(Charts.emptyXYDataset());
/*  71: 71 */       chartPanel.getChart().getTitle().setText("");
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */ 
/*  76:    */   protected void onTsChange()
/*  77:    */   {
/*  78: 78 */     if (m_ts == null) {
/*  79: 79 */       return;
/*  80:    */     }
/*  81:    */     
/*  82: 82 */     switch (m_ts.hasData()) {
/*  83:    */     case Invalid: 
/*  84: 84 */       setData("Loading " + m_ts.getName(), 0, null);
/*  85: 85 */       break;
/*  86:    */     case Undefined: 
/*  87: 87 */       setData(m_ts.getName(), m_ts.getTsData().getFrequency().intValue(), m_ts.getTsData().getValues());
/*  88:    */     }
/*  89:    */     
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */ 
/*  94:    */   protected void onDataFormatChange() {}
/*  95:    */   
/*  96:    */ 
/*  97:    */   protected void onColorSchemeChange()
/*  98:    */   {
/*  99: 99 */     XYPlot plot = getPlot();
/* 100:100 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 101:101 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 102:102 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 103:103 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 104:    */     
/* 105:105 */     plot.getRenderer().setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BROWN));
/* 106:    */     
/* 107:107 */     List<Marker> markers = new ArrayList();
/* 108:108 */     Collection rm = plot.getRangeMarkers(Layer.FOREGROUND);
/* 109:109 */     if (rm != null) {
/* 110:110 */       markers.addAll(rm);
/* 111:    */     }
/* 112:112 */     Collection dm = plot.getDomainMarkers(Layer.FOREGROUND);
/* 113:113 */     if (dm != null) {
/* 114:114 */       markers.addAll(dm);
/* 115:    */     }
/* 116:116 */     for (Marker o : markers) {
/* 117:117 */       if ((o instanceof ExtValueMarker)) {
/* 118:118 */         ((ExtValueMarker)o).applyColorScheme(themeSupport);
/* 119:    */       }
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   protected void onARPDataChange() {
/* 124:124 */     XYPlot plot = getPlot();
/* 125:125 */     reset();
/* 126:126 */     if ((data == null) || (data.values == null)) {
/* 127:127 */       return;
/* 128:    */     }
/* 129:129 */     XYSeries series = computeSeries();
/* 130:    */     
/* 131:131 */     plot.setDataset(new XYSeriesCollection(series));
/* 132:132 */     chartPanel.getChart().getTitle().setText(data.name);
/* 133:    */     
/* 134:134 */     if (data.freq > 0) {
/* 135:135 */       int freq2 = data.freq / 2;
/* 136:    */       
/* 137:137 */       for (int i = 1; i <= freq2; i++) {
/* 138:138 */         double f = i * 6.283185307179586D / data.freq;
/* 139:139 */         addFreqMarker(f, ColorScheme.KnownColor.BLUE);
/* 140:    */       }
/* 141:    */       
/* 142:142 */       double[] tdfreq = Periodogram.getTradingDaysFrequencies(data.freq);
/* 143:143 */       if (tdfreq != null) {
/* 144:144 */         for (int i = 0; i < tdfreq.length; i++) {
/* 145:145 */           addFreqMarker(tdfreq[i], ColorScheme.KnownColor.RED);
/* 146:    */         }
/* 147:    */       }
/* 148:148 */       configureChart(series);
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   protected abstract XYSeries computeSeries();
/* 153:    */   
/* 154:    */   protected XYPlot getPlot()
/* 155:    */   {
/* 156:156 */     return chartPanel.getChart().getXYPlot();
/* 157:    */   }
/* 158:    */   
/* 159:    */   protected void addFreqMarker(double f, ColorScheme.KnownColor basicColor) {
/* 160:160 */     ExtValueMarker vm = new ExtValueMarker(f, basicColor);
/* 161:161 */     vm.setStroke(FREQ_MARKER_STROKE);
/* 162:162 */     vm.setAlpha(0.4F);
/* 163:163 */     getPlot().addDomainMarker(vm);
/* 164:    */   }
/* 165:    */   
/* 166:    */   protected void configureChart(XYSeries series)
/* 167:    */   {
/* 168:168 */     double max = series.getMaxY();
/* 169:169 */     double min = series.getMinY();
/* 170:170 */     double inset = 3.0D * (max - min) / 100.0D;
/* 171:171 */     getPlot().getRangeAxis().setRange(min - inset, max + inset);
/* 172:    */     
/* 173:    */ 
/* 174:174 */     NumberAxis na = (NumberAxis)getPlot().getDomainAxis();
/* 175:175 */     na.setRange(0.0D, 3.141592653589793D);
/* 176:176 */     na.setTickUnit(new PiNumberTickUnit(1.570796326794897D));
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected JMenu buildMenu() {
/* 180:180 */     JMenu result = new JMenu();
/* 181:    */     
/* 182:182 */     result.add(MatrixChartCommand.copySeries(0, 0).toAction(chartPanel)).setText("Copy series");
/* 183:    */     
/* 184:184 */     JMenu export = new JMenu("Export image to");
/* 185:185 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 186:186 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 187:187 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 188:188 */     result.add(export);
/* 189:    */     
/* 190:190 */     return result;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void setData(String name, int freq, IReadDataBlock values) {
/* 194:194 */     data = new ARPData(name, freq, values);
/* 195:195 */     onARPDataChange();
/* 196:196 */     onColorSchemeChange();
/* 197:    */   }
/* 198:    */   
/* 199:    */   static JFreeChart createARPChart() {
/* 200:200 */     JFreeChart result = ChartFactory.createXYLineChart("", "", "", Charts.emptyXYDataset(), PlotOrientation.VERTICAL, false, false, false);
/* 201:201 */     result.setPadding(TsCharts.CHART_PADDING);
/* 202:202 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 203:    */     
/* 204:204 */     XYPlot plot = result.getXYPlot();
/* 205:    */     
/* 206:206 */     plot.setNoDataMessage("Drop data here");
/* 207:207 */     plot.getRangeAxis().setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 208:208 */     plot.getDomainAxis().setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 209:    */     
/* 210:210 */     ((XYLineAndShapeRenderer)plot.getRenderer()).setAutoPopulateSeriesPaint(false);
/* 211:    */     
/* 212:212 */     return result;
/* 213:    */   }
/* 214:    */   
/* 215:    */   protected static class ARPData
/* 216:    */   {
/* 217:    */     final String name;
/* 218:    */     final int freq;
/* 219:    */     final Values values;
/* 220:    */     
/* 221:    */     ARPData(String name, int freq, IReadDataBlock values) {
/* 222:222 */       this.name = name;
/* 223:223 */       this.freq = freq;
/* 224:224 */       this.values = new Values(values);
/* 225:    */     }
/* 226:    */   }
/* 227:    */   
/* 228:    */   protected static class ExtValueMarker extends ValueMarker
/* 229:    */   {
/* 230:    */     final ColorScheme.KnownColor color;
/* 231:    */     
/* 232:    */     public ExtValueMarker(double value, ColorScheme.KnownColor color) {
/* 233:233 */       super();
/* 234:234 */       this.color = color;
/* 235:    */     }
/* 236:    */     
/* 237:    */     void applyColorScheme(ThemeSupport support) {
/* 238:238 */       setPaint((Paint)support.getAreaColor(color));
/* 239:    */     }
/* 240:    */   }
/* 241:    */ }
