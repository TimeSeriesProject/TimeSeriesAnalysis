/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.nbdemetra.ui.awt.ExceptionPanel;
/*   5:    */ import ec.nbdemetra.ui.nodes.DecoratedNode;
/*   6:    */ import ec.nbdemetra.ui.nodes.DecoratedNode.Html;
/*   7:    */ import ec.nbdemetra.ui.nodes.IdNodes;
/*   8:    */ import ec.tstoolkit.algorithm.IProcDocument;
/*   9:    */ import ec.tstoolkit.utilities.Arrays2;
/*  10:    */ import ec.tstoolkit.utilities.Id;
/*  11:    */ import ec.ui.interfaces.IDisposable;
/*  12:    */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  13:    */ import java.awt.BorderLayout;
/*  14:    */ import java.awt.Component;
/*  15:    */ import java.beans.PropertyChangeEvent;
/*  16:    */ import java.beans.PropertyVetoException;
/*  17:    */ import java.beans.VetoableChangeListener;
/*  18:    */ import java.util.UUID;
/*  19:    */ import javax.swing.JComponent;
/*  20:    */ import javax.swing.JPanel;
/*  21:    */ import javax.swing.JSplitPane;
/*  22:    */ import org.openide.explorer.ExplorerManager;
/*  23:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  24:    */ import org.openide.explorer.view.BeanTreeView;
/*  25:    */ import org.openide.nodes.Node;
/*  26:    */ import org.openide.util.Exceptions;
/*  27:    */ import org.openide.util.Lookup;
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ public abstract class AbstractDocumentViewer<D extends IProcDocument>
/*  35:    */   extends JComponent
/*  36:    */   implements IDisposable, ExplorerManager.Provider
/*  37:    */ {
/*  38:    */   protected final UUID m_identifier;
/*  39:    */   protected final JSplitPane splitter;
/*  40:    */   protected final BeanTreeView m_tree;
/*  41:    */   protected final ExplorerManager em;
/*  42:    */   protected final JComponent emptyView;
/*  43:    */   protected IProcDocumentView<D> m_procView;
/*  44:    */   
/*  45:    */   protected AbstractDocumentViewer()
/*  46:    */   {
/*  47: 47 */     m_identifier = UUID.randomUUID();
/*  48:    */     
/*  49: 49 */     m_tree = new BeanTreeView();
/*  50: 50 */     m_tree.setRootVisible(false);
/*  51: 51 */     m_tree.setSelectionMode(1);
/*  52:    */     
/*  53: 53 */     em = new ExplorerManager();
/*  54: 54 */     em.addVetoableChangeListener(new VetoableChangeListener()
/*  55:    */     {
/*  56:    */       public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
/*  57: 57 */         if ("selectedNodes".equals(evt.getPropertyName())) {
/*  58: 58 */           Node[] nodes = (Node[])evt.getNewValue();
/*  59: 59 */           if (nodes.length > 0) {
/*  60: 60 */             Id id = (Id)nodes[0].getLookup().lookup(Id.class);
/*  61: 61 */             AbstractDocumentViewer.this.showComponent(id);
/*  62:    */           }
/*  63:    */           
/*  64:    */         }
/*  65:    */       }
/*  66: 66 */     });
/*  67: 67 */     emptyView = new JPanel(new BorderLayout());
/*  68:    */     
/*  69: 69 */     splitter = NbComponents.newJSplitPane(1, m_tree, emptyView);
/*  70: 70 */     splitter.setDividerLocation(200);
/*  71: 71 */     splitter.setResizeWeight(0.2D);
/*  72:    */     
/*  73: 73 */     setLayout(new BorderLayout());
/*  74: 74 */     add(splitter, "Center");
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */   public ExplorerManager getExplorerManager()
/*  79:    */   {
/*  80: 80 */     return em;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public UUID getIdentifier() {
/*  84: 84 */     return m_identifier;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public D getDocument() {
/*  88: 88 */     return m_procView == null ? null : m_procView.getDocument();
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected abstract IProcDocumentView<D> getView(D paramD);
/*  92:    */   
/*  93:    */   public void setDocument(D doc) {
/*  94:    */     try {
/*  95: 95 */       if (m_procView != null) {
/*  96: 96 */         m_procView.dispose();
/*  97: 97 */         m_procView = null;
/*  98:    */       }
/*  99: 99 */       m_procView = getView(doc);
/* 100:    */     } finally {
/* 101:101 */       buildTree();
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void refresh() {
/* 106:106 */     m_procView.refresh();
/* 107:107 */     Node[] sel = em.getSelectedNodes();
/* 108:108 */     if (!Arrays2.isNullOrEmpty(sel)) {
/* 109:109 */       Id curid = (Id)sel[0].getLookup().lookup(Id.class);
/* 110:110 */       if (curid != null) {
/* 111:111 */         showComponent(curid);
/* 112:    */       }
/* 113:    */     } else {
/* 114:114 */       selectPreferredView();
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   private void buildTree() {
/* 119:119 */     if (m_procView != null) {
/* 120:120 */       em.setRootContext(new DecoratedNode(IdNodes.getRootNode(m_procView.getItems())));
/* 121:121 */       selectPreferredView();
/* 122:    */     } else {
/* 123:123 */       em.setRootContext(Node.EMPTY);
/* 124:124 */       showComponent(null);
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   private void showComponent(Id id) {
/* 129:129 */     Component oldView = splitter.getBottomComponent();
/* 130:130 */     if ((oldView instanceof IDisposable)) {
/* 131:131 */       ((IDisposable)oldView).dispose();
/* 132:    */     }
/* 133:    */     JComponent newView;
/* 134:    */     try
/* 135:    */     {
/* 136:136 */       newView = id != null ? m_procView.getView(id) : emptyView;
/* 137:    */     } catch (RuntimeException ex) { JComponent newView;
/* 138:138 */       newView = ExceptionPanel.create(ex);
/* 139:    */     }
/* 140:    */     
/* 141:141 */     int sep = splitter.getDividerLocation();
/* 142:142 */     splitter.setBottomComponent(newView != null ? newView : emptyView);
/* 143:143 */     splitter.setDividerLocation(sep);
/* 144:    */   }
/* 145:    */   
/* 146:    */   private void selectPreferredView() {
/* 147:147 */     Id pview = m_procView.getPreferredView();
/* 148:148 */     if (pview != null) {
/* 149:149 */       showComponent(pview);
/* 150:150 */       Node node = IdNodes.findNode(em.getRootContext(), pview);
/* 151:    */       try {
/* 152:152 */         em.setSelectedNodes(new Node[] { node });
/* 153:153 */         ((DecoratedNode)node).setHtmlDecorator(DecoratedNode.Html.BOLD);
/* 154:    */       } catch (PropertyVetoException ex) {
/* 155:155 */         Exceptions.printStackTrace(ex);
/* 156:    */       }
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void dispose()
/* 161:    */   {
/* 162:162 */     if (m_procView != null) {
/* 163:163 */       m_procView.dispose();
/* 164:    */     }
/* 165:165 */     m_tree.setTransferHandler(null);
/* 166:166 */     Component old = splitter.getBottomComponent();
/* 167:167 */     if ((old instanceof IDisposable)) {
/* 168:168 */       ((IDisposable)old).dispose();
/* 169:    */     }
/* 170:170 */     splitter.setBottomComponent(emptyView);
/* 171:171 */     removeAll();
/* 172:    */   }
/* 173:    */ }
