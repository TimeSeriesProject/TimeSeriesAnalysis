/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import java.text.DecimalFormat;
/*  4:   */ import java.text.NumberFormat;
/*  5:   */ import org.jfree.chart.axis.NumberTickUnit;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ public class ScaleTickUnit
/* 10:   */   extends NumberTickUnit
/* 11:   */ {
/* 12:   */   private ScalingType type_;
/* 13:   */   private double factor_;
/* 14:   */   private NumberFormat formatter_;
/* 15:   */   
/* 16:   */   public static enum ScalingType
/* 17:   */   {
/* 18:18 */     None, 
/* 19:19 */     Multiply, 
/* 20:20 */     Divide;
/* 21:   */   }
/* 22:   */   
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:28 */   public ScaleTickUnit(double value, ScalingType type, double factor) { this(value, type, factor, new DecimalFormat("0.00")); }
/* 29:   */   
/* 30:   */   public ScaleTickUnit(double value, ScalingType type, double factor, NumberFormat format) {
/* 31:31 */     super(value);
/* 32:32 */     type_ = type;
/* 33:33 */     factor_ = factor;
/* 34:34 */     formatter_ = format;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String valueToString(double value)
/* 38:   */   {
/* 39:39 */     if (type_ == ScalingType.Multiply) value *= factor_;
/* 40:40 */     if (type_ == ScalingType.Divide) value /= factor_;
/* 41:41 */     return formatter_.format(value);
/* 42:   */   }
/* 43:   */ }
