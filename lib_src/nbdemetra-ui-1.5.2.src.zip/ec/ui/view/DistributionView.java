/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.data.DataBlock;
/*   5:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*   6:    */ import ec.tstoolkit.data.IReadDataBlock;
/*   7:    */ import ec.tstoolkit.dstats.BoundaryType;
/*   8:    */ import ec.tstoolkit.dstats.IContinuousDistribution;
/*   9:    */ import ec.ui.ATsControl;
/*  10:    */ import ec.ui.chart.TsCharts;
/*  11:    */ import ec.ui.interfaces.IReadDataBlockView;
/*  12:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*  13:    */ import ec.util.chart.ColorScheme;
/*  14:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  15:    */ import ec.util.chart.swing.ChartCommand;
/*  16:    */ import ec.util.chart.swing.Charts;
/*  17:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  18:    */ import java.awt.BorderLayout;
/*  19:    */ import java.awt.Paint;
/*  20:    */ import java.beans.PropertyChangeEvent;
/*  21:    */ import java.beans.PropertyChangeListener;
/*  22:    */ import java.text.DecimalFormat;
/*  23:    */ import javax.swing.JMenu;
/*  24:    */ import javax.swing.JMenuItem;
/*  25:    */ import org.jfree.chart.ChartPanel;
/*  26:    */ import org.jfree.chart.JFreeChart;
/*  27:    */ import org.jfree.chart.axis.NumberAxis;
/*  28:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  29:    */ import org.jfree.chart.block.BlockBorder;
/*  30:    */ import org.jfree.chart.labels.XYSeriesLabelGenerator;
/*  31:    */ import org.jfree.chart.plot.XYPlot;
/*  32:    */ import org.jfree.chart.renderer.xy.XYBarRenderer;
/*  33:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  34:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  35:    */ import org.jfree.chart.renderer.xy.XYSplineRenderer;
/*  36:    */ import org.jfree.chart.title.LegendTitle;
/*  37:    */ import org.jfree.chart.title.TextTitle;
/*  38:    */ import org.jfree.data.function.Function2D;
/*  39:    */ import org.jfree.data.general.DatasetUtilities;
/*  40:    */ import org.jfree.data.xy.XYBarDataset;
/*  41:    */ import org.jfree.data.xy.XYDataset;
/*  42:    */ import org.jfree.data.xy.XYSeries;
/*  43:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  44:    */ 
/*  45:    */ public class DistributionView extends ATsControl implements IReadDataBlockView, ec.ui.interfaces.IColorSchemeAble
/*  46:    */ {
/*  47:    */   protected static final int HISTOGRAM_INDEX = 1;
/*  48:    */   protected static final int DISTRIBUTION_INDEX = 0;
/*  49: 49 */   protected static final ColorScheme.KnownColor HISTOGRAM_COLOR = ColorScheme.KnownColor.BLUE;
/*  50: 50 */   protected static final ColorScheme.KnownColor DISTRIBUTION_COLOR = ColorScheme.KnownColor.RED;
/*  51:    */   
/*  52:    */   public static final String L_BOUND_PROPERTY = "lBound";
/*  53:    */   
/*  54:    */   public static final String R_BOUND_PROPERTY = "rBound";
/*  55:    */   public static final String DISTRIBUTION_PROPERTY = "distribution";
/*  56:    */   public static final String ADJUST_DISTRIBUTION_PROPERTY = "adjustDistribution";
/*  57:    */   public static final String H_COUNT_PROPERTY = "hCount";
/*  58:    */   public static final String DATA_PROPERTY = "data";
/*  59:    */   protected static final double DEFAULT_L_BOUND = 0.0D;
/*  60:    */   protected static final double DEFAULT_R_BOUND = 0.0D;
/*  61: 61 */   protected static final IContinuousDistribution DEFAULT_DISTRIBUTION = null;
/*  62:    */   protected static final boolean DEFAULT_ADJUST_DISTRIBUTION = true;
/*  63:    */   protected static final int DEFAULT_H_COUNT = 0;
/*  64: 64 */   protected static final double[] DEFAULT_DATA = null;
/*  65:    */   
/*  66:    */   protected double lBound;
/*  67:    */   protected double rBound;
/*  68:    */   protected IContinuousDistribution distribution;
/*  69:    */   protected boolean adjustDistribution;
/*  70:    */   protected int hCount;
/*  71:    */   protected double[] data;
/*  72:    */   protected final ChartPanel chartPanel;
/*  73:    */   
/*  74:    */   public DistributionView()
/*  75:    */   {
/*  76: 76 */     lBound = 0.0D;
/*  77: 77 */     rBound = 0.0D;
/*  78: 78 */     distribution = DEFAULT_DISTRIBUTION;
/*  79: 79 */     adjustDistribution = true;
/*  80: 80 */     hCount = 0;
/*  81: 81 */     data = DEFAULT_DATA;
/*  82:    */     
/*  83: 83 */     setLayout(new BorderLayout());
/*  84: 84 */     chartPanel = new ChartPanel(createDistributionViewChart());
/*  85: 85 */     Charts.avoidScaling(chartPanel);
/*  86: 86 */     add(chartPanel, "Center");
/*  87:    */     
/*  88: 88 */     onDataFormatChange();
/*  89: 89 */     onColorSchemeChange();
/*  90:    */     
/*  91: 91 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  92:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  93:    */         String str;
/*  94: 94 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1580708220:  if (str.equals("distribution")) {} break; case -1427965005:  if (str.equals("adjustDistribution")) {} break; case -1252236921:  if (str.equals("hCount")) {} break; case -1138643854:  if (str.equals("lBound")) break; break; case -966868948:  if (str.equals("rBound")) {} break; case 3076010:  if (!str.equals("data"))
/*  95:    */           {
/*  96: 96 */             return;onDataChange();
/*  97: 97 */             return;
/*  98:    */             
/*  99: 99 */             onDataChange();
/* 100:100 */             return;
/* 101:    */             
/* 102:102 */             onDataChange();
/* 103:103 */             return;
/* 104:    */             
/* 105:105 */             onDataChange();
/* 106:106 */             return;
/* 107:    */             
/* 108:108 */             onDataChange();
/* 109:    */           }
/* 110:    */           else {
/* 111:111 */             onDataChange();
/* 112:    */           }
/* 113:    */           break;
/* 114:    */         }
/* 115:    */       }
/* 116:116 */     });
/* 117:117 */     chartPanel.setPopupMenu(buildMenu(chartPanel).getPopupMenu());
/* 118:    */   }
/* 119:    */   
/* 120:    */ 
/* 121:    */ 
/* 122:    */   protected void onDataFormatChange() {}
/* 123:    */   
/* 124:    */ 
/* 125:    */ 
/* 126:    */   protected void onColorSchemeChange()
/* 127:    */   {
/* 128:128 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 129:129 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 130:130 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 131:131 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 132:132 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 133:    */     
/* 134:134 */     plot.getRenderer(1).setBasePaint((Paint)themeSupport.getAreaColor(HISTOGRAM_COLOR));
/* 135:135 */     plot.getRenderer(1).setBaseOutlinePaint((Paint)themeSupport.getLineColor(HISTOGRAM_COLOR));
/* 136:136 */     plot.getRenderer(0).setBasePaint((Paint)themeSupport.getLineColor(DISTRIBUTION_COLOR));
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected void onDataChange() {
/* 140:140 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 141:    */     
/* 142:142 */     if (data != DEFAULT_DATA) {
/* 143:143 */       DescriptiveStatistics stats = new DescriptiveStatistics(new DataBlock(data));
/* 144:    */       
/* 145:145 */       double m = 0.0D;double M = 0.0D;double dv = 1.0D;
/* 146:146 */       if ((adjustDistribution) && (distribution != DEFAULT_DISTRIBUTION)) {
/* 147:147 */         m = stats.getAverage();
/* 148:148 */         M = distribution.getExpectation();
/* 149:149 */         double v = stats.getVar();
/* 150:150 */         double V = distribution.getVariance();
/* 151:151 */         dv = Math.sqrt(v / V);
/* 152:    */       }
/* 153:    */       
/* 154:154 */       double xmin = stats.getMin() < lBound ? stats.getMin() : lBound;
/* 155:155 */       double xmax = stats.getMax() > rBound ? stats.getMax() : rBound;
/* 156:156 */       int n = hCount != 0 ? hCount : (int)Math.ceil(Math.sqrt(stats.getObservationsCount()));
/* 157:157 */       double xstep = (xmax - xmin) / n;
/* 158:    */       
/* 159:    */ 
/* 160:160 */       if (distribution != DEFAULT_DISTRIBUTION) {
/* 161:161 */         Function2D density = new Function2D()
/* 162:    */         {
/* 163:    */           public double getValue(double x) {
/* 164:164 */             return distribution.getDensity(x);
/* 165:    */           }
/* 166:    */           
/* 167:167 */         };
/* 168:168 */         double zmin = distribution.hasLeftBound() != BoundaryType.None ? distribution.getLeftBound() : (xmin - xstep - m) / dv + M;
/* 169:169 */         double zmax = distribution.hasRightBound() != BoundaryType.None ? distribution.getRightBound() : (xmax + xstep - m) / dv + M;
/* 170:    */         
/* 171:    */ 
/* 172:172 */         String name = distribution.getClass().getSimpleName();
/* 173:    */         
/* 174:174 */         ((XYLineAndShapeRenderer)plot.getRenderer(0)).setLegendItemToolTipGenerator(getTooltipGenerator(distribution));
/* 175:175 */         plot.setDataset(0, DatasetUtilities.sampleFunction2D(density, zmin, zmax, n, name));
/* 176:    */       } else {
/* 177:177 */         plot.setDataset(0, Charts.emptyXYDataset());
/* 178:    */       }
/* 179:    */       
/* 180:    */ 
/* 181:    */ 
/* 182:182 */       XYSeries hSeries = new XYSeries("");
/* 183:183 */       double nobs = stats.getObservationsCount();
/* 184:184 */       for (int i = 0; i <= n; i++) {
/* 185:185 */         double x0 = xmin + i * xstep;
/* 186:186 */         double x1 = x0 + xstep;
/* 187:187 */         double y = stats.countBetween(x0, x1) / (nobs * xstep / dv);
/* 188:188 */         hSeries.add(((x0 + x1) / 2.0D - m) / dv + M, y);
/* 189:    */       }
/* 190:    */       
/* 191:191 */       plot.setDataset(1, new XYBarDataset(new XYSeriesCollection(hSeries), xstep / dv + M));
/* 192:    */     }
/* 193:    */     else {
/* 194:194 */       plot.setDataset(1, Charts.emptyXYDataset());
/* 195:195 */       plot.setDataset(0, Charts.emptyXYDataset());
/* 196:    */     }
/* 197:    */     
/* 198:198 */     onColorSchemeChange();
/* 199:    */   }
/* 200:    */   
/* 201:    */ 
/* 202:    */   public double getLBound()
/* 203:    */   {
/* 204:204 */     return lBound;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setLBound(double lBound) {
/* 208:208 */     double old = this.lBound;
/* 209:209 */     this.lBound = lBound;
/* 210:210 */     firePropertyChange("lBound", old, this.lBound);
/* 211:    */   }
/* 212:    */   
/* 213:    */   public double getRBound() {
/* 214:214 */     return rBound;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void setRBound(double rBound) {
/* 218:218 */     double old = this.rBound;
/* 219:219 */     this.rBound = rBound;
/* 220:220 */     firePropertyChange("rBound", old, this.rBound);
/* 221:    */   }
/* 222:    */   
/* 223:    */   public IContinuousDistribution getDistribution() {
/* 224:224 */     return distribution;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void setDistribution(IContinuousDistribution distribution) {
/* 228:228 */     IContinuousDistribution old = this.distribution;
/* 229:229 */     this.distribution = (distribution != null ? distribution : DEFAULT_DISTRIBUTION);
/* 230:230 */     firePropertyChange("distribution", old, this.distribution);
/* 231:    */   }
/* 232:    */   
/* 233:    */   public double[] getData() {
/* 234:234 */     return data;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void setData(double[] data) {
/* 238:238 */     double[] old = this.data;
/* 239:239 */     this.data = (data != null ? data : DEFAULT_DATA);
/* 240:240 */     firePropertyChange("data", old, this.data);
/* 241:    */   }
/* 242:    */   
/* 243:    */   public boolean isAdjustDistribution() {
/* 244:244 */     return adjustDistribution;
/* 245:    */   }
/* 246:    */   
/* 247:    */   public void setAdjustDistribution(boolean adjustDistribution) {
/* 248:248 */     boolean old = this.adjustDistribution;
/* 249:249 */     this.adjustDistribution = adjustDistribution;
/* 250:250 */     firePropertyChange("adjustDistribution", old, this.adjustDistribution);
/* 251:    */   }
/* 252:    */   
/* 253:    */   public int getHCount() {
/* 254:254 */     return hCount;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public void setHCount(int hCount) {
/* 258:258 */     int old = this.hCount;
/* 259:259 */     this.hCount = (hCount >= 0 ? hCount : 0);
/* 260:260 */     firePropertyChange("hCount", old, this.hCount);
/* 261:    */   }
/* 262:    */   
/* 263:    */   public ColorScheme getColorScheme()
/* 264:    */   {
/* 265:265 */     return themeSupport.getLocalColorScheme();
/* 266:    */   }
/* 267:    */   
/* 268:    */   public void setColorScheme(ColorScheme theme)
/* 269:    */   {
/* 270:270 */     themeSupport.setLocalColorScheme(theme);
/* 271:    */   }
/* 272:    */   
/* 273:    */   public void setDataBlock(IReadDataBlock data)
/* 274:    */   {
/* 275:    */     double[] tmp;
/* 276:    */     double[] tmp;
/* 277:277 */     if (data == null) {
/* 278:278 */       tmp = null;
/* 279:    */     } else {
/* 280:280 */       tmp = new double[data.getLength()];
/* 281:281 */       data.copyTo(tmp, 0);
/* 282:    */     }
/* 283:283 */     setData(tmp);
/* 284:    */   }
/* 285:    */   
/* 286:    */   public void reset()
/* 287:    */   {
/* 288:288 */     setData(null);
/* 289:289 */     setDistribution(null);
/* 290:    */   }
/* 291:    */   
/* 292:    */   private static JFreeChart createDistributionViewChart() {
/* 293:293 */     XYPlot plot = new XYPlot();
/* 294:    */     
/* 295:295 */     XYLineAndShapeRenderer dRenderer = new XYSplineRenderer();
/* 296:296 */     dRenderer.setBaseShapesVisible(false);
/* 297:297 */     dRenderer.setAutoPopulateSeriesPaint(false);
/* 298:298 */     dRenderer.setAutoPopulateSeriesStroke(false);
/* 299:299 */     dRenderer.setBaseStroke(TsCharts.getStrongStroke(ITsChart.LinesThickness.Thin));
/* 300:300 */     dRenderer.setDrawSeriesLineAsPath(true);
/* 301:301 */     plot.setDataset(0, Charts.emptyXYDataset());
/* 302:302 */     plot.setRenderer(0, dRenderer);
/* 303:    */     
/* 304:304 */     XYBarRenderer hRenderer = new XYBarRenderer();
/* 305:305 */     hRenderer.setShadowVisible(false);
/* 306:306 */     hRenderer.setDrawBarOutline(true);
/* 307:307 */     hRenderer.setAutoPopulateSeriesPaint(false);
/* 308:308 */     hRenderer.setAutoPopulateSeriesOutlinePaint(false);
/* 309:309 */     hRenderer.setBaseSeriesVisibleInLegend(false);
/* 310:310 */     plot.setDataset(1, Charts.emptyXYDataset());
/* 311:311 */     plot.setRenderer(1, hRenderer);
/* 312:    */     
/* 313:313 */     NumberAxis domainAxis = new NumberAxis();
/* 314:314 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 315:315 */     plot.setDomainAxis(domainAxis);
/* 316:316 */     plot.setDomainGridlinesVisible(false);
/* 317:    */     
/* 318:318 */     NumberAxis rangeAxis = new NumberAxis();
/* 319:319 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 320:320 */     rangeAxis.setTickUnit(new NumberTickUnit(0.05D));
/* 321:321 */     rangeAxis.setNumberFormatOverride(new DecimalFormat("0.###"));
/* 322:322 */     plot.setRangeAxis(rangeAxis);
/* 323:    */     
/* 324:324 */     plot.mapDatasetToDomainAxis(0, 0);
/* 325:325 */     plot.mapDatasetToRangeAxis(0, 0);
/* 326:326 */     plot.mapDatasetToDomainAxis(1, 0);
/* 327:327 */     plot.mapDatasetToRangeAxis(1, 0);
/* 328:    */     
/* 329:329 */     JFreeChart result = new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, plot, true);
/* 330:330 */     result.setPadding(TsCharts.CHART_PADDING);
/* 331:331 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 332:332 */     result.getLegend().setFrame(BlockBorder.NONE);
/* 333:333 */     result.getLegend().setBackgroundPaint(null);
/* 334:334 */     return result;
/* 335:    */   }
/* 336:    */   
/* 337:    */   protected static XYSeriesLabelGenerator getTooltipGenerator(IContinuousDistribution distribution) {
/* 338:338 */     new XYSeriesLabelGenerator()
/* 339:    */     {
/* 340:    */       public String generateLabel(XYDataset dataset, int series) {
/* 341:341 */         return getDescription();
/* 342:    */       }
/* 343:    */     };
/* 344:    */   }
/* 345:    */   
/* 346:    */   private static JMenu buildMenu(ChartPanel chartPanel) {
/* 347:347 */     JMenu result = new JMenu();
/* 348:    */     
/* 349:349 */     result.add(MatrixChartCommand.copySeries(0, 0).toAction(chartPanel)).setText("Copy distribution");
/* 350:350 */     result.add(MatrixChartCommand.copySeries(1, 0).toAction(chartPanel)).setText("Copy histogram");
/* 351:    */     
/* 352:352 */     JMenu export = new JMenu("Export image to");
/* 353:353 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 354:354 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 355:355 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 356:356 */     result.add(export);
/* 357:    */     
/* 358:358 */     return result;
/* 359:    */   }
/* 360:    */ }
