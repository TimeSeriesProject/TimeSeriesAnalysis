/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.util.chart.swing.Charts;
/*  4:   */ import java.awt.geom.Rectangle2D;
/*  5:   */ import org.jfree.chart.ChartPanel;
/*  6:   */ import org.jfree.chart.JFreeChart;
/*  7:   */ import org.jfree.chart.axis.ValueAxis;
/*  8:   */ import org.jfree.chart.plot.XYPlot;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class JChartPanel
/* 16:   */   extends ChartPanel
/* 17:   */ {
/* 18:   */   public static final String ZOOM_SELECTION_CHANGED = "Zoom Selection Changed";
/* 19:   */   
/* 20:   */   public JChartPanel(JFreeChart chart)
/* 21:   */   {
/* 22:22 */     super(chart);
/* 23:23 */     Charts.avoidScaling(this);
/* 24:24 */     setDomainZoomable(false);
/* 25:25 */     setRangeZoomable(false);
/* 26:26 */     setPopupMenu(null);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public double getChartX(double x) {
/* 30:30 */     Rectangle2D plotArea = getScreenDataArea();
/* 31:31 */     XYPlot plot = (XYPlot)getChart().getPlot();
/* 32:32 */     return plot.getDomainAxis().java2DToValue(x, plotArea, plot.getDomainAxisEdge());
/* 33:   */   }
/* 34:   */   
/* 35:   */   public double getChartY(double y) {
/* 36:36 */     Rectangle2D plotArea = getScreenDataArea();
/* 37:37 */     XYPlot plot = (XYPlot)getChart().getPlot();
/* 38:38 */     return plot.getRangeAxis().java2DToValue(y, plotArea, plot.getRangeAxisEdge());
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void zoom(Rectangle2D selection)
/* 42:   */   {
/* 43:43 */     firePropertyChange("Zoom Selection Changed", null, selection);
/* 44:   */   }
/* 45:   */ }
