/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import java.text.DecimalFormat;
/*  4:   */ import java.text.NumberFormat;
/*  5:   */ import java.util.Locale;
/*  6:   */ import org.jfree.chart.axis.NumberTickUnit;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class PercentageTickUnit
/* 17:   */   extends NumberTickUnit
/* 18:   */ {
/* 19:19 */   private final DecimalFormat formatter = (DecimalFormat)NumberFormat.getNumberInstance(Locale.ROOT);
/* 20:   */   
/* 21:   */   public PercentageTickUnit(double size) {
/* 22:22 */     super(size);
/* 23:23 */     formatter.applyPattern("#0.00");
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String valueToString(double value)
/* 27:   */   {
/* 28:28 */     return formatter.format(value * 100.0D) + "%";
/* 29:   */   }
/* 30:   */ }
