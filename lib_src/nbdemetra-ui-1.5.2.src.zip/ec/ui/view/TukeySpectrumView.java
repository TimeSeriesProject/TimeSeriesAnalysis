/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.tstoolkit.data.BlackmanTukeySpectrum;
/*   5:    */ import ec.tstoolkit.data.DataBlock;
/*   6:    */ import ec.tstoolkit.data.TukeyHanningTaper;
/*   7:    */ import ec.tstoolkit.data.Values;
/*   8:    */ import ec.tstoolkit.data.WindowType;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import org.jfree.data.xy.XYSeries;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ public class TukeySpectrumView
/*  19:    */   extends ARPView
/*  20:    */ {
/*  21:    */   public static final String WINDOW_LENGTH_PROPERTY = "windowLength";
/*  22:    */   public static final String WINDOW_TYPE_PROPERTY = "windowType";
/*  23:    */   public static final String TAPER_PART_PROPERTY = "tapingPart";
/*  24:    */   public static final String LOG_PROPERTY = "logTransformation";
/*  25:    */   public static final String DIFF_PROPERTY = "differencing";
/*  26:    */   public static final String DIFF_LAG_PROPERTY = "differencingLag";
/*  27:    */   public static final String LASTYEARS_PROPERTY = "lastYears";
/*  28:    */   private static final int DEFAULT_WINDOW_LENGTH = 0;
/*  29: 29 */   private static final WindowType DEFAULT_WINDOW_TYPE = WindowType.Tukey;
/*  30:    */   
/*  31:    */   private static final double DEFAULT_TAPER_PART = 0.0D;
/*  32:    */   private static final boolean DEFAULT_LOG = false;
/*  33:    */   private static final int DEFAULT_DIFF = 1;
/*  34:    */   private static final int DEFAULT_DIFF_LAG = 1;
/*  35:    */   protected int windowLength;
/*  36: 36 */   protected WindowType windowType = DEFAULT_WINDOW_TYPE;
/*  37: 37 */   protected double taperPart = 0.0D;
/*  38: 38 */   private int del = 1; private int lag = 1;
/*  39: 39 */   private boolean log = false;
/*  40:    */   private int lastYears;
/*  41:    */   
/*  42:    */   public TukeySpectrumView() {
/*  43: 43 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  44: 44 */     lastYears = demetraUI.getSpectralLastYears().intValue();
/*  45:    */     
/*  46: 46 */     windowLength = 0;
/*  47:    */     
/*  48: 48 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  49:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  50:    */         String str;
/*  51: 51 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1379041160:  if (str.equals("differencingLag")) {} break; case -1329180938:  if (str.equals("windowLength")) break; break; case -1196656966:  if (str.equals("differencing")) {} break; case -978476558:  if (str.equals("tapingPart")) {} break; case 1574730605:  if (str.equals("logTransformation")) {} break; case 1862559562:  if (str.equals("windowType")) {} break; case 2007313120:  if (!str.equals("lastYears"))
/*  52:    */           {
/*  53: 53 */             return;onWindowLengthChange();
/*  54: 54 */             return;
/*  55:    */             
/*  56: 56 */             onWindowTypeChange();
/*  57: 57 */             return;
/*  58:    */             
/*  59: 59 */             onTaperChange();
/*  60: 60 */             return;
/*  61:    */             
/*  62: 62 */             onLogChange();
/*  63: 63 */             return;
/*  64:    */             
/*  65: 65 */             onDiffChange();
/*  66: 66 */             return;
/*  67:    */             
/*  68: 68 */             onDiffChange();
/*  69:    */           }
/*  70:    */           else {
/*  71: 71 */             onLastYearsChange();
/*  72:    */           }
/*  73:    */           break; }
/*  74:    */       }
/*  75:    */     });
/*  76:    */   }
/*  77:    */   
/*  78:    */   protected void onWindowLengthChange() {
/*  79: 79 */     onARPDataChange();
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected void onWindowTypeChange() {
/*  83: 83 */     onARPDataChange();
/*  84:    */   }
/*  85:    */   
/*  86:    */   protected void onTaperChange() {
/*  87: 87 */     onARPDataChange();
/*  88:    */   }
/*  89:    */   
/*  90:    */   protected void onLogChange() {
/*  91: 91 */     onARPDataChange();
/*  92:    */   }
/*  93:    */   
/*  94:    */   protected void onDiffChange() {
/*  95: 95 */     onARPDataChange();
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected void onLastYearsChange() {
/*  99: 99 */     onARPDataChange();
/* 100:    */   }
/* 101:    */   
/* 102:    */   protected void onARPDataChange()
/* 103:    */   {
/* 104:104 */     super.onARPDataChange();
/* 105:105 */     if (data == null) {
/* 106:106 */       return;
/* 107:    */     }
/* 108:108 */     onColorSchemeChange();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public int getWindowLength()
/* 112:    */   {
/* 113:113 */     return windowLength;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void setWindowLength(int windowLength) {
/* 117:117 */     int old = this.windowLength;
/* 118:118 */     this.windowLength = (windowLength > 0 ? windowLength : 0);
/* 119:119 */     firePropertyChange("windowLength", old, this.windowLength);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public WindowType getWindowType() {
/* 123:123 */     return windowType;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setWindowType(WindowType windowType) {
/* 127:127 */     if (windowType != this.windowType) {
/* 128:128 */       WindowType old = this.windowType;
/* 129:129 */       this.windowType = windowType;
/* 130:130 */       firePropertyChange("windowType", old, this.windowType);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public double getTaperPart() {
/* 135:135 */     return taperPart;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setTaperPart(double part) {
/* 139:139 */     if (part != taperPart) {
/* 140:140 */       double old = taperPart;
/* 141:141 */       taperPart = part;
/* 142:142 */       firePropertyChange("tapingPart", old, taperPart);
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean isLogTransformation() {
/* 147:147 */     return log;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void setLogTransformation(boolean log) {
/* 151:151 */     boolean old = this.log;
/* 152:152 */     this.log = log;
/* 153:153 */     firePropertyChange("logTransformation", old, this.log);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public int getDifferencingOrder() {
/* 157:157 */     return del;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void setDifferencingOrder(int order) {
/* 161:161 */     if (order < 0) {
/* 162:162 */       throw new IllegalArgumentException("Differencing order should be >=0.");
/* 163:    */     }
/* 164:164 */     int old = del;
/* 165:165 */     del = order;
/* 166:166 */     firePropertyChange("differencing", old, del);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public int getDifferencingLag() {
/* 170:170 */     return lag;
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void setDifferencingLag(int lag) {
/* 174:174 */     if (lag <= 0) {
/* 175:175 */       throw new IllegalArgumentException("Lag order should be >0.");
/* 176:    */     }
/* 177:177 */     int old = this.lag;
/* 178:178 */     this.lag = lag;
/* 179:179 */     firePropertyChange("differencingLag", old, this.lag);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public int getLastYears() {
/* 183:183 */     return lastYears;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void setLastYears(int length) {
/* 187:187 */     if (length < 0) {
/* 188:188 */       throw new IllegalArgumentException("Last years should be >=0.");
/* 189:    */     }
/* 190:190 */     int old = lastYears;
/* 191:191 */     lastYears = length;
/* 192:192 */     firePropertyChange("differencing", old, lastYears);
/* 193:    */   }
/* 194:    */   
/* 195:    */   protected XYSeries computeSeries()
/* 196:    */   {
/* 197:197 */     XYSeries result = new XYSeries(data.name);
/* 198:198 */     Values val = data.values.clone();
/* 199:199 */     if (log) {
/* 200:200 */       val.log();
/* 201:    */     }
/* 202:202 */     if (del > 0) {
/* 203:203 */       double[] s = new double[val.getLength()];
/* 204:204 */       val.copyTo(s, 0);
/* 205:205 */       for (int i = 0; i < del; i++) {
/* 206:206 */         for (int j = s.length - 1; j >= (i + 1) * lag; j--) {
/* 207:207 */           s[j] -= s[(j - lag)];
/* 208:    */         }
/* 209:    */       }
/* 210:210 */       val = new Values(new DataBlock(s, del * lag, s.length, 1));
/* 211:    */     }
/* 212:212 */     if ((lastYears > 0) && (data.freq > 0)) {
/* 213:213 */       int nmax = lastYears * data.freq;
/* 214:214 */       int nbeg = val.getLength() - nmax;
/* 215:215 */       if (nbeg > 0) {
/* 216:216 */         val = val.drop(nbeg, 0);
/* 217:    */       }
/* 218:    */     }
/* 219:    */     
/* 220:220 */     BlackmanTukeySpectrum tukey = new BlackmanTukeySpectrum();
/* 221:221 */     tukey.setTaper(new TukeyHanningTaper(taperPart));
/* 222:222 */     tukey.setWindowType(windowType);
/* 223:223 */     if ((windowLength == 0) || (windowLength >= val.getLength() - 1)) {
/* 224:224 */       tukey.setWindowLength(val.getLength() * 3 / 4 / data.freq * data.freq);
/* 225:    */     } else {
/* 226:226 */       tukey.setWindowLength(windowLength);
/* 227:    */     }
/* 228:228 */     tukey.setData(val.internalStorage());
/* 229:229 */     double[] yp = tukey.getSpectrum();
/* 230:230 */     for (int i = 0; i < yp.length; i++) {
/* 231:231 */       result.add(i * 6.283185307179586D / tukey.getWindowLength(), yp[i]);
/* 232:    */     }
/* 233:    */     
/* 234:234 */     return result;
/* 235:    */   }
/* 236:    */ }
