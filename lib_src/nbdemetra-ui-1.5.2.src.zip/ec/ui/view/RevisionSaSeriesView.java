/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ComponentFactory;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   6:    */ import ec.tss.html.HtmlUtil;
/*   7:    */ import ec.tss.html.implementation.HtmlRevisionsDocument;
/*   8:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*   9:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*  10:    */ import ec.tstoolkit.timeseries.analysis.DiagnosticInfo;
/*  11:    */ import ec.tstoolkit.timeseries.analysis.RevisionHistory;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  13:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  16:    */ import ec.ui.AHtmlView;
/*  17:    */ import ec.ui.ATsView;
/*  18:    */ import ec.ui.chart.ChartPopup;
/*  19:    */ import ec.ui.chart.TsCharts;
/*  20:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  21:    */ import java.awt.BorderLayout;
/*  22:    */ import java.awt.Paint;
/*  23:    */ import java.awt.Point;
/*  24:    */ import java.awt.datatransfer.ClipboardOwner;
/*  25:    */ import java.awt.event.MouseEvent;
/*  26:    */ import java.awt.geom.Ellipse2D.Double;
/*  27:    */ import java.awt.geom.Rectangle2D;
/*  28:    */ import java.beans.PropertyChangeEvent;
/*  29:    */ import java.beans.PropertyChangeListener;
/*  30:    */ import java.text.SimpleDateFormat;
/*  31:    */ import java.util.ArrayList;
/*  32:    */ import java.util.Date;
/*  33:    */ import java.util.List;
/*  34:    */ import javax.swing.JSplitPane;
/*  35:    */ import javax.swing.SwingUtilities;
/*  36:    */ import org.jfree.chart.ChartFactory;
/*  37:    */ import org.jfree.chart.ChartMouseEvent;
/*  38:    */ import org.jfree.chart.ChartMouseListener;
/*  39:    */ import org.jfree.chart.JFreeChart;
/*  40:    */ import org.jfree.chart.axis.DateAxis;
/*  41:    */ import org.jfree.chart.axis.DateTickMarkPosition;
/*  42:    */ import org.jfree.chart.axis.NumberAxis;
/*  43:    */ import org.jfree.chart.entity.XYItemEntity;
/*  44:    */ import org.jfree.chart.plot.PlotOrientation;
/*  45:    */ import org.jfree.chart.plot.XYPlot;
/*  46:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  47:    */ import org.jfree.data.Range;
/*  48:    */ import org.jfree.data.time.Day;
/*  49:    */ import org.jfree.data.time.TimeSeries;
/*  50:    */ import org.jfree.data.time.TimeSeriesCollection;
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ public class RevisionSaSeriesView
/*  68:    */   extends ATsView
/*  69:    */   implements ClipboardOwner
/*  70:    */ {
/*  71:    */   private static final int S_INDEX = 1;
/*  72:    */   private static final int REV_INDEX = 0;
/*  73:    */   private final JChartPanel chartpanel_;
/*  74:    */   private final AHtmlView documentpanel_;
/*  75:    */   private final XYLineAndShapeRenderer sRenderer;
/*  76:    */   private final XYLineAndShapeRenderer revRenderer;
/*  77:    */   private final JFreeChart mainChart;
/*  78: 78 */   private String info_ = "sa";
/*  79:    */   private RevisionHistory history_;
/*  80: 80 */   private DiagnosticInfo diag_ = DiagnosticInfo.RelativeDifference;
/*  81: 81 */   private int years_ = 4;
/*  82: 82 */   private int minyears_ = 5;
/*  83: 83 */   private int threshold_ = 2;
/*  84: 84 */   private int lastIndexSelected = -1;
/*  85:    */   
/*  86:    */   private ChartPopup popup;
/*  87:    */   
/*  88:    */   private TsPeriod firstPeriod;
/*  89:    */   private TsData sRef;
/*  90:    */   private Range range;
/*  91:    */   
/*  92:    */   public RevisionSaSeriesView()
/*  93:    */   {
/*  94: 94 */     setLayout(new BorderLayout());
/*  95:    */     
/*  96: 96 */     sRenderer = new XYLineAndShapeRenderer();
/*  97: 97 */     sRenderer.setBaseShapesVisible(false);
/*  98:    */     
/*  99: 99 */     sRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 100:    */     
/* 101:101 */     revRenderer = new XYLineAndShapeRenderer(false, true);
/* 102:    */     
/* 103:103 */     mainChart = createMainChart();
/* 104:    */     
/* 105:105 */     chartpanel_ = new JChartPanel(ChartFactory.createLineChart(null, null, null, null, PlotOrientation.VERTICAL, false, false, false));
/* 106:    */     
/* 107:107 */     documentpanel_ = ComponentFactory.getDefault().newHtmlView();
/* 108:    */     
/* 109:109 */     JSplitPane splitpane = NbComponents.newJSplitPane(0, chartpanel_, NbComponents.newJScrollPane(documentpanel_));
/* 110:110 */     splitpane.setDividerLocation(0.5D);
/* 111:111 */     splitpane.setResizeWeight(0.5D);
/* 112:    */     
/* 113:113 */     popup = new ChartPopup(null, false);
/* 114:    */     
/* 115:115 */     chartpanel_.addChartMouseListener(new ChartMouseListener()
/* 116:    */     {
/* 117:    */       public void chartMouseClicked(ChartMouseEvent e) {
/* 118:118 */         if (lastIndexSelected != -1) {
/* 119:119 */           revRenderer.setSeriesShapesFilled(lastIndexSelected, false);
/* 120:    */         }
/* 121:121 */         if ((e.getEntity() != null) && 
/* 122:122 */           ((e.getEntity() instanceof XYItemEntity))) {
/* 123:123 */           XYItemEntity item = (XYItemEntity)e.getEntity();
/* 124:124 */           if (item.getDataset().equals(mainChart.getXYPlot().getDataset(0))) {
/* 125:125 */             int i = item.getSeriesIndex();
/* 126:    */             
/* 127:127 */             revRenderer.setSeriesShape(i, new Ellipse2D.Double(-3.0D, -3.0D, 6.0D, 6.0D));
/* 128:128 */             revRenderer.setSeriesShapesFilled(i, true);
/* 129:129 */             revRenderer.setSeriesPaint(i, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 130:    */             
/* 131:131 */             lastIndexSelected = i;
/* 132:    */             
/* 133:133 */             RevisionSaSeriesView.this.showRevisionPopup(e);
/* 134:    */           }
/* 135:    */         }
/* 136:    */       }
/* 137:    */       
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */       public void chartMouseMoved(ChartMouseEvent cme) {}
/* 143:143 */     });
/* 144:144 */     chartpanel_.addPropertyChangeListener(new PropertyChangeListener()
/* 145:    */     {
/* 146:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 147:147 */         if (evt.getPropertyName().equals("Zoom Selection Changed")) {
/* 148:148 */           RevisionSaSeriesView.this.showSelectionPopup((Rectangle2D)evt.getNewValue());
/* 149:    */         }
/* 150:    */         
/* 151:    */       }
/* 152:152 */     });
/* 153:153 */     add(splitpane, "Center");
/* 154:154 */     splitpane.setResizeWeight(0.5D);
/* 155:    */     
/* 156:156 */     onColorSchemeChange();
/* 157:    */   }
/* 158:    */   
/* 159:    */   private void showSelectionPopup(Rectangle2D rectangle) {
/* 160:160 */     XYPlot plot = chartpanel_.getChart().getXYPlot();
/* 161:161 */     Rectangle2D dataArea = chartpanel_.getScreenDataArea();
/* 162:162 */     DateAxis domainAxis = (DateAxis)plot.getDomainAxis();
/* 163:163 */     double minX = domainAxis.java2DToValue(rectangle.getMinX(), dataArea, plot.getDomainAxisEdge());
/* 164:164 */     double maxX = domainAxis.java2DToValue(rectangle.getMaxX(), dataArea, plot.getDomainAxisEdge());
/* 165:    */     
/* 166:166 */     Date startDate = new Date(minX);
/* 167:167 */     Date endDate = new Date(maxX);
/* 168:168 */     TsPeriod start = new TsPeriod(firstPeriod.getFrequency(), startDate);
/* 169:169 */     TsPeriod end = new TsPeriod(firstPeriod.getFrequency(), endDate);
/* 170:    */     
/* 171:171 */     if (end.minus(start) == 0) {
/* 172:172 */       return;
/* 173:    */     }
/* 174:    */     
/* 175:175 */     TsPeriodSelector sel = new TsPeriodSelector();
/* 176:176 */     sel.between(start.firstday(), end.lastday());
/* 177:177 */     List<TsData> listSeries = history_.Select(info_, startDate, endDate);
/* 178:178 */     List<TsData> revSeries = new ArrayList();
/* 179:    */     
/* 180:180 */     for (TsData t : listSeries) {
/* 181:181 */       revSeries.add(t.select(sel));
/* 182:    */     }
/* 183:    */     
/* 184:184 */     Point pt = new Point((int)rectangle.getX(), (int)rectangle.getY());
/* 185:185 */     pt.translate(3, 3);
/* 186:186 */     SwingUtilities.convertPointToScreen(pt, chartpanel_);
/* 187:187 */     popup.setLocation(pt);
/* 188:188 */     popup.setChartTitle(info_.toUpperCase() + " First estimations");
/* 189:189 */     popup.setTsData(sRef.select(sel), revSeries);
/* 190:190 */     popup.setVisible(true);
/* 191:191 */     chartpanel_.repaint();
/* 192:    */   }
/* 193:    */   
/* 194:    */   private void showRevisionsDocument(TsData s) {
/* 195:195 */     HtmlRevisionsDocument document = new HtmlRevisionsDocument(s, diag_);
/* 196:196 */     document.setThreshold(threshold_);
/* 197:197 */     documentpanel_.loadContent(HtmlUtil.toString(document));
/* 198:    */   }
/* 199:    */   
/* 200:    */   private TsData revisions() {
/* 201:201 */     if (sRef == null) {
/* 202:202 */       sRef = history_.referenceSeries(info_);
/* 203:    */     }
/* 204:204 */     int freq = sRef.getDomain().getFrequency().intValue();
/* 205:205 */     int l = years_ * freq + 1;
/* 206:206 */     int n0 = sRef.getDomain().getLength() - l;
/* 207:207 */     if (n0 < minyears_ * freq) {
/* 208:208 */       n0 = minyears_ * freq;
/* 209:    */     }
/* 210:210 */     TsPeriod start = sRef.getDomain().get(n0);
/* 211:211 */     TsPeriod end = sRef.getDomain().getLast();
/* 212:212 */     int n = end.minus(start);
/* 213:213 */     if (n <= 0) {
/* 214:214 */       return null;
/* 215:    */     }
/* 216:216 */     TsData rev = new TsData(start, n);
/* 217:217 */     for (int i = 0; i < n; i++) {
/* 218:218 */       double r = history_.seriesRevision(info_, rev.getDomain().get(i), diag_);
/* 219:219 */       if ((diag_ != DiagnosticInfo.AbsoluteDifference) && (diag_ != DiagnosticInfo.PeriodToPeriodDifference)) {
/* 220:220 */         r *= 100.0D;
/* 221:    */       }
/* 222:222 */       rev.set(i, r);
/* 223:    */     }
/* 224:224 */     return rev;
/* 225:    */   }
/* 226:    */   
/* 227:    */   private void showRevisionPopup(ChartMouseEvent e) {
/* 228:228 */     XYItemEntity entity = (XYItemEntity)e.getEntity();
/* 229:229 */     TsPeriod start = firstPeriod.plus(entity.getSeriesIndex());
/* 230:230 */     popup.setTsData(history_.tsRevision(info_, start, start), null);
/* 231:231 */     Point p = e.getTrigger().getLocationOnScreen();
/* 232:232 */     p.translate(3, 3);
/* 233:233 */     popup.setLocation(p);
/* 234:234 */     popup.setChartTitle(info_.toUpperCase() + "[" + start.toString() + "] Revisions");
/* 235:235 */     popup.setVisible(true);
/* 236:    */   }
/* 237:    */   
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */   public String getInfo()
/* 244:    */   {
/* 245:245 */     return info_;
/* 246:    */   }
/* 247:    */   
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:    */   public void setInfo(String info_)
/* 253:    */   {
/* 254:254 */     this.info_ = info_;
/* 255:    */   }
/* 256:    */   
/* 257:    */   private void addSeries(TimeSeriesCollection chartSeries, TsData data) {
/* 258:258 */     TimeSeries chartTs = new TimeSeries("");
/* 259:259 */     for (int i = 0; i < data.getDomain().getLength(); i++) {
/* 260:260 */       if (DescriptiveStatistics.isFinite(data.get(i))) {
/* 261:261 */         Day day = new Day(data.getDomain().get(i).middle());
/* 262:262 */         chartTs.addOrUpdate(day, data.get(i));
/* 263:    */       }
/* 264:    */     }
/* 265:265 */     chartSeries.addSeries(chartTs);
/* 266:    */   }
/* 267:    */   
/* 268:    */   private void addStart(TimeSeriesCollection chartSeries, String name, TsPeriod start) {
/* 269:269 */     TsData ts = history_.series(name, start);
/* 270:270 */     if (ts != null) {
/* 271:271 */       TimeSeries chartTs = new TimeSeries("");
/* 272:272 */       int pos = start.minus(ts.getStart());
/* 273:273 */       Day day = new Day(start.middle());
/* 274:274 */       chartTs.add(day, ts.get(pos));
/* 275:275 */       chartSeries.addSeries(chartTs);
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   private void showResults() {
/* 280:280 */     if (history_ == null) {
/* 281:281 */       return;
/* 282:    */     }
/* 283:    */     
/* 284:284 */     lastIndexSelected = -1;
/* 285:    */     
/* 286:286 */     TimeSeriesCollection chartSeries = new TimeSeriesCollection();
/* 287:287 */     sRef = history_.referenceSeries(info_);
/* 288:288 */     TsPeriodSelector selector = new TsPeriodSelector();
/* 289:289 */     int n = sRef.getDomain().getLength();
/* 290:290 */     int freq = sRef.getDomain().getFrequency().intValue();
/* 291:291 */     int l = years_ * freq + 1;
/* 292:292 */     int n0 = n - l;
/* 293:293 */     if (n0 < minyears_ * freq) {
/* 294:294 */       n0 = minyears_ * freq;
/* 295:    */     }
/* 296:296 */     if (n0 < n) {
/* 297:297 */       firstPeriod = sRef.getDomain().get(n0);
/* 298:298 */       selector.from(sRef.getDomain().get(n0).firstday());
/* 299:    */     } else {
/* 300:300 */       firstPeriod = sRef.getStart();
/* 301:    */     }
/* 302:302 */     addSeries(chartSeries, sRef.select(selector));
/* 303:    */     
/* 304:304 */     TimeSeriesCollection startSeries = new TimeSeriesCollection();
/* 305:305 */     TsDomain dom = sRef.getDomain();
/* 306:306 */     for (int i = n0; i < n - 1; i++) {
/* 307:307 */       addStart(startSeries, info_, dom.get(i));
/* 308:    */     }
/* 309:    */     
/* 310:310 */     if ((startSeries.getSeriesCount() == 0) || (chartSeries.getSeriesCount() == 0)) {
/* 311:311 */       chartpanel_.setChart(mainChart);
/* 312:312 */       return;
/* 313:    */     }
/* 314:    */     
/* 315:315 */     setRange(chartSeries, startSeries);
/* 316:    */     
/* 317:317 */     XYPlot plot = mainChart.getXYPlot();
/* 318:318 */     plot.setDataset(1, chartSeries);
/* 319:    */     
/* 320:320 */     plot.setDataset(0, startSeries);
/* 321:    */     
/* 322:322 */     for (int i = 0; i < startSeries.getSeriesCount(); i++) {
/* 323:323 */       revRenderer.setSeriesShape(i, new Ellipse2D.Double(-3.0D, -3.0D, 6.0D, 6.0D));
/* 324:324 */       revRenderer.setSeriesShapesFilled(i, false);
/* 325:325 */       revRenderer.setSeriesPaint(i, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 326:    */     }
/* 327:327 */     plot.setRenderer(0, revRenderer);
/* 328:    */     
/* 329:329 */     setRange(chartSeries, startSeries);
/* 330:330 */     configureAxis(plot);
/* 331:    */     
/* 332:332 */     plot.mapDatasetToDomainAxis(1, 0);
/* 333:333 */     plot.mapDatasetToRangeAxis(1, 0);
/* 334:334 */     plot.mapDatasetToDomainAxis(0, 0);
/* 335:335 */     plot.mapDatasetToRangeAxis(0, 0);
/* 336:    */     
/* 337:337 */     chartpanel_.setChart(mainChart);
/* 338:    */     
/* 339:339 */     showRevisionsDocument(revisions());
/* 340:    */   }
/* 341:    */   
/* 342:    */   private JFreeChart createMainChart() {
/* 343:343 */     XYPlot plot = new XYPlot();
/* 344:344 */     configureAxis(plot);
/* 345:    */     
/* 346:346 */     plot.setRenderer(1, sRenderer);
/* 347:    */     
/* 348:348 */     plot.setRenderer(0, revRenderer);
/* 349:    */     
/* 350:350 */     plot.setNoDataMessage("Not enough data to compute revision history !");
/* 351:351 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, false);
/* 352:352 */     result.setPadding(TsCharts.CHART_PADDING);
/* 353:353 */     return result;
/* 354:    */   }
/* 355:    */   
/* 356:    */   private void configureAxis(XYPlot plot) {
/* 357:357 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-yyyy");
/* 358:358 */     DateAxis dateAxis = new DateAxis();
/* 359:359 */     dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 360:360 */     dateAxis.setDateFormatOverride(sdf);
/* 361:361 */     plot.setDomainAxis(dateAxis);
/* 362:362 */     NumberAxis yaxis = new NumberAxis();
/* 363:363 */     if (range != null) {
/* 364:364 */       yaxis.setRange(range);
/* 365:    */     }
/* 366:366 */     plot.setRangeAxis(yaxis);
/* 367:    */   }
/* 368:    */   
/* 369:    */ 
/* 370:    */ 
/* 371:    */ 
/* 372:    */ 
/* 373:    */ 
/* 374:    */   public void setHistory(RevisionHistory history)
/* 375:    */   {
/* 376:376 */     if ((history_ == null) || (!history_.equals(history))) {
/* 377:377 */       history_ = history;
/* 378:378 */       chartpanel_.setChart(null);
/* 379:379 */       showResults();
/* 380:    */     }
/* 381:    */   }
/* 382:    */   
/* 383:    */ 
/* 384:    */ 
/* 385:    */   protected void onTsChange() {}
/* 386:    */   
/* 387:    */ 
/* 388:    */ 
/* 389:    */   protected void onDataFormatChange() {}
/* 390:    */   
/* 391:    */ 
/* 392:    */ 
/* 393:    */   protected void onColorSchemeChange()
/* 394:    */   {
/* 395:395 */     sRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 396:396 */     revRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 397:    */     
/* 398:398 */     XYPlot mainPlot = mainChart.getXYPlot();
/* 399:399 */     for (int i = 0; i < mainPlot.getSeriesCount(); i++) {
/* 400:400 */       revRenderer.setSeriesShape(i, new Ellipse2D.Double(-3.0D, -3.0D, 6.0D, 6.0D));
/* 401:401 */       revRenderer.setSeriesShapesFilled(i, false);
/* 402:402 */       revRenderer.setSeriesPaint(i, (Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 403:    */     }
/* 404:    */     
/* 405:405 */     mainPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 406:406 */     mainPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 407:407 */     mainPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 408:408 */     mainChart.setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 409:    */   }
/* 410:    */   
/* 411:    */   private void setRange(TimeSeriesCollection chartSeries, TimeSeriesCollection startSeries)
/* 412:    */   {
/* 413:413 */     Range chart = chartSeries.getRangeBounds(true);
/* 414:414 */     Range start = startSeries.getRangeBounds(true);
/* 415:415 */     double min = chart.getLowerBound();
/* 416:416 */     double max = chart.getUpperBound();
/* 417:    */     
/* 418:418 */     if (min > start.getLowerBound()) {
/* 419:419 */       min = start.getLowerBound();
/* 420:    */     }
/* 421:    */     
/* 422:422 */     if (max < start.getUpperBound()) {
/* 423:423 */       max = start.getUpperBound();
/* 424:    */     }
/* 425:    */     
/* 426:426 */     min -= Math.abs(min) * 0.03D;
/* 427:427 */     max += Math.abs(max) * 0.03D;
/* 428:    */     
/* 429:429 */     range = new Range(min, max);
/* 430:    */   }
/* 431:    */ }
