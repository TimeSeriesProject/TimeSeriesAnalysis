/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbComponents;
/*  4:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  5:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  6:   */ import ec.ui.interfaces.IDisposable;
/*  7:   */ import java.awt.BorderLayout;
/*  8:   */ import javax.swing.JComponent;
/*  9:   */ import javax.swing.JSplitPane;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class SpectralView
/* 16:   */   extends JComponent
/* 17:   */   implements IDisposable
/* 18:   */ {
/* 19:   */   private final JSplitPane m_splitter;
/* 20:   */   AutoRegressiveSpectrumView m_arView;
/* 21:   */   PeriodogramView m_pView;
/* 22:   */   
/* 23:   */   public SpectralView()
/* 24:   */   {
/* 25:25 */     m_splitter = NbComponents.newJSplitPane(0);
/* 26:26 */     m_arView = new AutoRegressiveSpectrumView();
/* 27:27 */     m_pView = new PeriodogramView();
/* 28:28 */     build();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void set(TsData series, boolean wn) {
/* 32:32 */     int freq = series.getFrequency().intValue();
/* 33:33 */     m_pView.setLimitVisible(wn);
/* 34:34 */     m_pView.setData("Periodogram", freq, series.getValues());
/* 35:35 */     m_arView.setData("Auto-regressive spectrum", freq, series.getValues());
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setDifferencingOrder(int order) {
/* 39:39 */     m_pView.setDifferencingOrder(order);
/* 40:40 */     m_arView.setDifferencingOrder(order);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setDifferencingLag(int lag) {
/* 44:44 */     m_pView.setDifferencingLag(lag);
/* 45:45 */     m_arView.setDifferencingLag(lag);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setLogTransformation(boolean log) {
/* 49:49 */     m_pView.setLogTransformation(log);
/* 50:50 */     m_arView.setLogTransformation(log);
/* 51:   */   }
/* 52:   */   
/* 53:53 */   private void build() { setLayout(new BorderLayout());
/* 54:54 */     add(m_splitter, "Center");
/* 55:   */     
/* 56:56 */     m_splitter.setTopComponent(m_pView);
/* 57:57 */     m_splitter.setBottomComponent(m_arView);
/* 58:58 */     m_splitter.setDividerLocation(0.5D);
/* 59:59 */     m_splitter.setResizeWeight(0.5D);
/* 60:   */     
/* 61:61 */     m_pView.setDifferencingOrder(0);
/* 62:62 */     m_arView.setDifferencingOrder(0);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public void dispose()
/* 66:   */   {
/* 67:67 */     m_pView.dispose();
/* 68:68 */     m_arView.dispose();
/* 69:   */   }
/* 70:   */ }
