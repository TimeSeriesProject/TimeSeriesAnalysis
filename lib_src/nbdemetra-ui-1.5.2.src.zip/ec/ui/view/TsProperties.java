/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.TsMoniker;
/*   7:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   8:    */ import ec.tstoolkit.MetaData;
/*   9:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  10:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  11:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  12:    */ import ec.ui.chart.JTsChart;
/*  13:    */ import ec.ui.grid.JTsGrid;
/*  14:    */ import ec.ui.interfaces.IDisposable;
/*  15:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  16:    */ import javax.swing.Box;
/*  17:    */ import javax.swing.JLabel;
/*  18:    */ import javax.swing.JSplitPane;
/*  19:    */ import javax.swing.JTree;
/*  20:    */ import javax.swing.TransferHandler;
/*  21:    */ import javax.swing.TransferHandler.TransferSupport;
/*  22:    */ import javax.swing.tree.DefaultMutableTreeNode;
/*  23:    */ import javax.swing.tree.TreeNode;
/*  24:    */ import javax.swing.tree.TreePath;
/*  25:    */ 
/*  26:    */ public class TsProperties extends javax.swing.JComponent implements IDisposable
/*  27:    */ {
/*  28:    */   private JTsChart chart_;
/*  29:    */   private JTsGrid grid_;
/*  30:    */   private JLabel labelSeries_;
/*  31:    */   private JLabel labelSource_;
/*  32:    */   private JTree tree_;
/*  33:    */   
/*  34:    */   public TsProperties()
/*  35:    */   {
/*  36: 36 */     labelSeries_ = new JLabel();
/*  37: 37 */     labelSource_ = new JLabel();
/*  38: 38 */     Box header = Box.createHorizontalBox();
/*  39: 39 */     header.add(new JLabel("Series: "));
/*  40: 40 */     header.add(labelSeries_);
/*  41: 41 */     header.add(Box.createRigidArea(new java.awt.Dimension(20, 20)));
/*  42: 42 */     header.add(new JLabel("Source: "));
/*  43: 43 */     header.add(labelSource_);
/*  44: 44 */     header.add(Box.createHorizontalGlue());
/*  45:    */     
/*  46: 46 */     tree_ = new JTree();
/*  47:    */     
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52: 52 */     tree_.setModel(null);
/*  53: 53 */     tree_.setRootVisible(false);
/*  54: 54 */     chart_ = new JTsChart();
/*  55: 55 */     chart_.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  56: 56 */     chart_.setLegendVisible(false);
/*  57: 57 */     JSplitPane leftPane = NbComponents.newJSplitPane(0, NbComponents.newJScrollPane(tree_), chart_);
/*  58: 58 */     leftPane.setResizeWeight(0.5D);
/*  59:    */     
/*  60: 60 */     grid_ = new JTsGrid();
/*  61: 61 */     grid_.setMode(ec.ui.interfaces.ITsGrid.Mode.SINGLETS);
/*  62: 62 */     grid_.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  63: 63 */     JSplitPane splitPane = NbComponents.newJSplitPane(1, leftPane, grid_);
/*  64: 64 */     splitPane.setResizeWeight(0.5D);
/*  65:    */     
/*  66: 66 */     setLayout(new java.awt.BorderLayout());
/*  67: 67 */     add(header, "North");
/*  68: 68 */     add(splitPane, "Center");
/*  69: 69 */     tree_.setTransferHandler(new TsHandler());
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setTs(Ts ts) {
/*  73: 73 */     ts.load(ec.tss.TsInformationType.All);
/*  74: 74 */     chart_.getTsCollection().clear();
/*  75: 75 */     chart_.getTsCollection().add(ts);
/*  76:    */     
/*  77: 77 */     grid_.getTsCollection().clear();
/*  78: 78 */     grid_.getTsCollection().add(ts);
/*  79:    */     
/*  80: 80 */     labelSeries_.setText(ts.getName());
/*  81: 81 */     labelSource_.setText(ts.getMoniker().getSource());
/*  82:    */     
/*  83: 83 */     DescriptiveStatistics ds = new DescriptiveStatistics(ts.getTsData().getValues());
/*  84:    */     
/*  85: 85 */     DefaultMutableTreeNode root = new DefaultMutableTreeNode();
/*  86: 86 */     DefaultMutableTreeNode metaNode = new DefaultMutableTreeNode("Metadata");
/*  87: 87 */     if (ts.getMetaData() != null) {
/*  88: 88 */       for (String name : ts.getMetaData().keySet()) {
/*  89: 89 */         metaNode.add(new DefaultMutableTreeNode(name + " = " + ts.getMetaData().get(name)));
/*  90:    */       }
/*  91:    */     }
/*  92: 92 */     root.add(metaNode);
/*  93: 93 */     DefaultMutableTreeNode statNode = new DefaultMutableTreeNode("Statistics");
/*  94: 94 */     statNode.setAllowsChildren(true);
/*  95: 95 */     statNode.add(new DefaultMutableTreeNode("Time span: " + 
/*  96: 96 */       ts.getTsData().getDomain().getStart() + 
/*  97: 97 */       " to " + 
/*  98: 98 */       ts.getTsData().getDomain().getEnd()));
/*  99: 99 */     statNode.add(new DefaultMutableTreeNode("Number of observations: " + 
/* 100:100 */       ds.getDataCount()));
/* 101:101 */     statNode.add(new DefaultMutableTreeNode("Number of missing values: " + 
/* 102:102 */       ds.getMissingValuesCount()));
/* 103:103 */     statNode.add(new DefaultMutableTreeNode("Min: " + 
/* 104:104 */       ds.getMin()));
/* 105:105 */     statNode.add(new DefaultMutableTreeNode("Max: " + 
/* 106:106 */       ds.getMax()));
/* 107:107 */     statNode.add(new DefaultMutableTreeNode("Average: " + 
/* 108:108 */       ds.getAverage()));
/* 109:109 */     statNode.add(new DefaultMutableTreeNode("Median: " + 
/* 110:110 */       ds.getMedian()));
/* 111:111 */     statNode.add(new DefaultMutableTreeNode("Stdev: " + 
/* 112:112 */       ds.getStdev()));
/* 113:113 */     root.add(statNode);
/* 114:114 */     root.setAllowsChildren(true);
/* 115:    */     
/* 116:116 */     tree_.setModel(new javax.swing.tree.DefaultTreeModel(root, true));
/* 117:117 */     tree_.invalidate();
/* 118:118 */     expandAll(tree_, new TreePath(root));
/* 119:119 */     tree_.setRootVisible(false);
/* 120:    */   }
/* 121:    */   
/* 122:    */   private void expandAll(JTree tree, TreePath parent) {
/* 123:123 */     TreeNode node = (TreeNode)parent.getLastPathComponent();
/* 124:124 */     if (node.getChildCount() >= 0) {
/* 125:125 */       for (Object n : org.openide.util.NbCollections.iterable(node.children())) {
/* 126:126 */         TreePath path = parent.pathByAddingChild(n);
/* 127:127 */         expandAll(tree, path);
/* 128:    */       }
/* 129:    */     }
/* 130:130 */     tree.expandPath(parent);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void dispose()
/* 134:    */   {
/* 135:135 */     chart_.dispose();
/* 136:136 */     grid_.dispose();
/* 137:    */   }
/* 138:    */   
/* 139:    */   class TsHandler
/* 140:    */     extends TransferHandler
/* 141:    */   {
/* 142:    */     TsHandler() {}
/* 143:    */     
/* 144:    */     public boolean canImport(TransferHandler.TransferSupport support)
/* 145:    */     {
/* 146:146 */       return TssTransferSupport.getDefault().canImport(support.getDataFlavors());
/* 147:    */     }
/* 148:    */     
/* 149:    */     public boolean importData(TransferHandler.TransferSupport support)
/* 150:    */     {
/* 151:151 */       Ts s = TssTransferSupport.getDefault().toTs(support.getTransferable());
/* 152:152 */       if (s != null) {
/* 153:153 */         setTs(s);
/* 154:    */       }
/* 155:155 */       return super.importData(support);
/* 156:    */     }
/* 157:    */   }
/* 158:    */ }
