/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.ui.interfaces.IColorSchemeAble;
/*   5:    */ import ec.ui.interfaces.IDisposable;
/*   6:    */ import ec.util.chart.ColorScheme;
/*   7:    */ import java.awt.BorderLayout;
/*   8:    */ import java.awt.event.MouseAdapter;
/*   9:    */ import java.awt.event.MouseEvent;
/*  10:    */ import java.text.DecimalFormat;
/*  11:    */ import javax.swing.JComponent;
/*  12:    */ import org.jfree.chart.ChartMouseEvent;
/*  13:    */ import org.jfree.chart.JFreeChart;
/*  14:    */ import org.jfree.chart.axis.NumberAxis;
/*  15:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  16:    */ import org.jfree.chart.entity.ChartEntity;
/*  17:    */ import org.jfree.chart.entity.LegendItemEntity;
/*  18:    */ import org.jfree.chart.plot.PlotOrientation;
/*  19:    */ import org.jfree.chart.plot.XYPlot;
/*  20:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  21:    */ 
/*  22:    */ public abstract class AChartView extends JComponent implements IColorSchemeAble, IDisposable
/*  23:    */ {
/*  24:    */   protected PlotOrientation orientation_;
/*  25:    */   protected int points_;
/*  26:    */   protected double customXmin;
/*  27:    */   protected double customXmax;
/*  28:    */   protected double customYmin;
/*  29:    */   protected double customYmax;
/*  30:    */   protected double baseminx_;
/*  31:    */   protected double basemaxx_;
/*  32:    */   protected double baseminy_;
/*  33:    */   protected double basemaxy_;
/*  34:    */   protected double minx_;
/*  35:    */   protected double maxx_;
/*  36:    */   protected double miny_;
/*  37:    */   protected double maxy_;
/*  38:    */   protected NumberTickUnit basetickunitx_;
/*  39:    */   protected NumberTickUnit basetickunity_;
/*  40:    */   protected NumberTickUnit tickunitx_;
/*  41:    */   protected NumberTickUnit tickunity_;
/*  42:    */   protected DecimalFormat basedecimalformat_;
/*  43:    */   protected DecimalFormat decimalformat_;
/*  44: 44 */   protected boolean zoomable_ = true;
/*  45: 45 */   protected Comparable focus = "";
/*  46:    */   protected final ThemeSupport themeSupport;
/*  47:    */   protected final JChartPanel chartPanel;
/*  48:    */   protected final XYSeriesCollection seriesCollection;
/*  49:    */   
/*  50:    */   public AChartView(int points, PlotOrientation orientation, double baseminx, double basemaxx, double baseminy, double basemaxy, NumberTickUnit basetickunitx, NumberTickUnit basetickunity, DecimalFormat baseformat)
/*  51:    */   {
/*  52: 52 */     setLayout(new BorderLayout());
/*  53:    */     
/*  54: 54 */     points_ = points;
/*  55: 55 */     baseminx_ = baseminx;
/*  56: 56 */     basemaxx_ = basemaxx;
/*  57: 57 */     baseminy_ = baseminy;
/*  58: 58 */     basemaxy_ = basemaxy;
/*  59: 59 */     basetickunitx_ = basetickunitx;
/*  60: 60 */     basetickunity_ = basetickunity;
/*  61: 61 */     basedecimalformat_ = baseformat;
/*  62: 62 */     orientation_ = orientation;
/*  63:    */     
/*  64: 64 */     themeSupport = new ThemeSupport()
/*  65:    */     {
/*  66:    */       protected void colorSchemeChanged()
/*  67:    */       {
/*  68: 68 */         onColorSchemeChange();
/*  69:    */       }
/*  70: 70 */     };
/*  71: 71 */     seriesCollection = new XYSeriesCollection();
/*  72: 72 */     chartPanel = new JChartPanel(org.jfree.chart.ChartFactory.createLineChart(null, null, null, null, orientation_, false, false, false));
/*  73:    */     
/*  74: 74 */     ec.util.chart.swing.Charts.avoidScaling(chartPanel);
/*  75:    */     
/*  76: 76 */     chartPanel.addChartMouseListener(new org.jfree.chart.ChartMouseListener()
/*  77:    */     {
/*  78:    */       public void chartMouseClicked(ChartMouseEvent cme)
/*  79:    */       {
/*  80: 80 */         ChartEntity entity = cme.getEntity();
/*  81: 81 */         if ((entity != null) && ((entity instanceof LegendItemEntity))) {
/*  82: 82 */           LegendItemEntity ent = (LegendItemEntity)entity;
/*  83: 83 */           setFocus(ent.getSeriesKey());
/*  84:    */         }
/*  85:    */       }
/*  86:    */       
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */       public void chartMouseMoved(ChartMouseEvent cme) {}
/*  91: 91 */     });
/*  92: 92 */     chartPanel.addMouseListener(new MouseAdapter()
/*  93:    */     {
/*  94:    */       public void mousePressed(MouseEvent e)
/*  95:    */       {
/*  96: 96 */         if (e.getButton() == 1) {
/*  97: 97 */           customXmin = e.getX();
/*  98: 98 */           customYmin = e.getY();
/*  99:    */         }
/* 100:    */       }
/* 101:    */       
/* 102:    */       public void mouseReleased(MouseEvent e)
/* 103:    */       {
/* 104:104 */         if (e.getButton() == 1) {
/* 105:105 */           customXmax = e.getX();
/* 106:106 */           customYmax = e.getY();
/* 107:    */           
/* 108:    */ 
/* 109:109 */           if (e.isControlDown()) {
/* 110:110 */             double panDistance = Math.abs(Math.abs(chartPanel.getChartX(customXmax)) - Math.abs(chartPanel.getChartX(customXmin)));
/* 111:111 */             if (customXmin > customXmax) {
/* 112:112 */               panRight(panDistance);
/* 113:    */             } else {
/* 114:114 */               panLeft(panDistance);
/* 115:    */             }
/* 116:    */             
/* 117:    */           }
/* 118:118 */           else if ((customXmax > customXmin) && (isZoomable())) {
/* 119:119 */             boolean zoomTrigger1 = Math.abs(customXmax) - customXmin >= chartPanel.getZoomTriggerDistance();
/* 120:120 */             boolean zoomTrigger2 = Math.abs(customYmax) - customYmin >= chartPanel.getZoomTriggerDistance();
/* 121:121 */             if ((zoomTrigger1) && (zoomTrigger2)) {
/* 122:122 */               zoom(chartPanel.getChartX(customXmin), chartPanel.getChartX(customXmax), chartPanel.getChartY(customYmax), chartPanel.getChartY(customYmin));
/* 123:    */             }
/* 124:    */           }
/* 125:    */         }
/* 126:    */         else {
/* 127:127 */           restoreBaseValues();
/* 128:    */         }
/* 129:129 */         onDomainChange();
/* 130:    */       }
/* 131:    */       
/* 132:132 */     });
/* 133:133 */     restoreBaseValues();
/* 134:134 */     add(chartPanel, "Center");
/* 135:135 */     themeSupport.register();
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void dispose()
/* 139:    */   {
/* 140:140 */     themeSupport.dispose();
/* 141:    */   }
/* 142:    */   
/* 143:    */ 
/* 144:    */   protected abstract void onDomainChange();
/* 145:    */   
/* 146:    */ 
/* 147:    */   protected abstract void onColorSchemeChange();
/* 148:    */   
/* 149:    */   protected abstract void onFocusChange();
/* 150:    */   
/* 151:    */   public double getBaseMinX()
/* 152:    */   {
/* 153:153 */     return baseminx_;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public double getBaseMaxX() {
/* 157:157 */     return basemaxx_;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public double getBaseMinY() {
/* 161:161 */     return baseminy_;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public double getBaseMaxY() {
/* 165:165 */     return basemaxy_;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public NumberTickUnit getBaseTickUnitX() {
/* 169:169 */     return basetickunitx_;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public NumberTickUnit getBaseTickUnitY() {
/* 173:173 */     return basetickunity_;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public DecimalFormat getBaseDecimalFormat() {
/* 177:177 */     return basedecimalformat_;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public NumberTickUnit getTickUnitX() {
/* 181:181 */     return tickunitx_;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void setTickUnitX(NumberTickUnit tickunit) {
/* 185:185 */     tickunitx_ = tickunit;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public NumberTickUnit getTickUnitY() {
/* 189:189 */     return tickunity_;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void setTickUnitY(NumberTickUnit tickunit) {
/* 193:193 */     tickunity_ = tickunit;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public DecimalFormat getDecimalFormat() {
/* 197:197 */     return decimalformat_;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void setDecimalFormat(DecimalFormat format) {
/* 201:201 */     decimalformat_ = format;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public int getPoints() {
/* 205:205 */     return points_;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public double getMinX() {
/* 209:209 */     return minx_;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void setMinX(double value) {
/* 213:213 */     minx_ = value;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public double getMaxX() {
/* 217:217 */     return maxx_;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setMaxX(double value) {
/* 221:221 */     maxx_ = value;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public double getMinY() {
/* 225:225 */     return miny_;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public void setMinY(double value) {
/* 229:229 */     miny_ = value;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public double getMaxY() {
/* 233:233 */     return maxy_;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public void setMaxY(double value) {
/* 237:237 */     maxy_ = value;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public boolean isZoomable() {
/* 241:241 */     return zoomable_;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public void setZoomable(boolean value) {
/* 245:245 */     zoomable_ = value;
/* 246:    */   }
/* 247:    */   
/* 248:    */   public void setColorScheme(ColorScheme theme)
/* 249:    */   {
/* 250:250 */     themeSupport.setLocalColorScheme(theme);
/* 251:    */   }
/* 252:    */   
/* 253:    */   public ColorScheme getColorScheme()
/* 254:    */   {
/* 255:255 */     return themeSupport.getLocalColorScheme();
/* 256:    */   }
/* 257:    */   
/* 258:    */   public void setFocus(Comparable key) {
/* 259:259 */     focus = (focus.equals(key) ? "" : key);
/* 260:260 */     onFocusChange();
/* 261:    */   }
/* 262:    */   
/* 263:    */   public Comparable getFocus() {
/* 264:264 */     return focus;
/* 265:    */   }
/* 266:    */   
/* 267:    */   protected int getFactorX()
/* 268:    */   {
/* 269:269 */     double totaldefaultlength = Math.abs(getBaseMaxX()) - getBaseMinX();
/* 270:270 */     double totalcustomlength = Math.abs(getMaxX()) - getMinX();
/* 271:271 */     return (int)(totaldefaultlength / totalcustomlength);
/* 272:    */   }
/* 273:    */   
/* 274:    */   protected int getFactorY() {
/* 275:275 */     double totaldefaultlength = Math.abs(getBaseMaxY()) - getBaseMinY();
/* 276:276 */     double totalcustomlength = Math.abs(getMaxY()) - getMinY();
/* 277:277 */     return (int)(totaldefaultlength / totalcustomlength);
/* 278:    */   }
/* 279:    */   
/* 280:    */   protected boolean isBaseValues() {
/* 281:281 */     return (getMinX() == getBaseMinX()) && (getMaxX() == getBaseMaxX());
/* 282:    */   }
/* 283:    */   
/* 284:    */   protected void restoreBaseValues() {
/* 285:285 */     minx_ = getBaseMinX();
/* 286:286 */     maxx_ = getBaseMaxX();
/* 287:287 */     miny_ = getBaseMinY();
/* 288:288 */     maxy_ = getBaseMaxY();
/* 289:289 */     tickunitx_ = getBaseTickUnitX();
/* 290:290 */     tickunity_ = getBaseTickUnitY();
/* 291:291 */     decimalformat_ = getBaseDecimalFormat();
/* 292:    */   }
/* 293:    */   
/* 294:    */   protected void setValues(double minx, double maxx, double miny, double maxy) {
/* 295:295 */     setMinX(minx);
/* 296:296 */     setMaxX(maxx);
/* 297:297 */     setMinY(miny);
/* 298:298 */     setMaxY(maxy);
/* 299:    */     
/* 300:300 */     setTickUnitX(new PiNumberTickUnit(getBaseTickUnitX().getSize() / getFactorX()));
/* 301:301 */     setTickUnitY(new NumberTickUnit(getBaseTickUnitY().getSize() / getFactorY()));
/* 302:    */     
/* 303:303 */     onDomainChange();
/* 304:    */   }
/* 305:    */   
/* 306:    */   protected void zoom(double minx, double maxx, double miny, double maxy) {
/* 307:307 */     setValues(minx, maxx, miny, maxy);
/* 308:    */   }
/* 309:    */   
/* 310:    */   protected void panLeft(double value) {
/* 311:311 */     setValues(getMinX() - value, getMaxX() - value, getMinY(), getMaxY());
/* 312:    */   }
/* 313:    */   
/* 314:    */   protected void panRight(double value) {
/* 315:315 */     setValues(getMinX() + value, getMaxX() + value, getMinY(), getMaxY());
/* 316:    */   }
/* 317:    */   
/* 318:    */   protected int getFocusIndex() {
/* 319:319 */     return seriesCollection.getSeriesIndex(focus);
/* 320:    */   }
/* 321:    */   
/* 322:    */   protected void configureAxis() {
/* 323:323 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 324:    */     
/* 325:325 */     NumberAxis rangeAxis = (NumberAxis)plot.getRangeAxis();
/* 326:326 */     rangeAxis.setRange(getMinY(), getMaxY());
/* 327:    */     
/* 328:328 */     rangeAxis.setNumberFormatOverride(getDecimalFormat());
/* 329:    */     
/* 330:330 */     NumberAxis domainAxis = (NumberAxis)plot.getDomainAxis();
/* 331:331 */     domainAxis.setRange(getMinX(), getMaxX());
/* 332:332 */     domainAxis.setTickUnit(getTickUnitX());
/* 333:    */   }
/* 334:    */ }
