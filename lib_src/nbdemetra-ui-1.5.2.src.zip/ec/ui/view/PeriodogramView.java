/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUI;
/*   4:    */ import ec.tstoolkit.data.DataBlock;
/*   5:    */ import ec.tstoolkit.data.Periodogram;
/*   6:    */ import ec.tstoolkit.data.Values;
/*   7:    */ import ec.tstoolkit.dstats.Chi2;
/*   8:    */ import ec.tstoolkit.dstats.ProbabilityType;
/*   9:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  10:    */ import java.awt.BasicStroke;
/*  11:    */ import java.awt.Stroke;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.beans.PropertyChangeListener;
/*  14:    */ import org.jfree.chart.plot.XYPlot;
/*  15:    */ import org.jfree.data.xy.XYSeries;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ public class PeriodogramView
/*  21:    */   extends ARPView
/*  22:    */ {
/*  23: 23 */   private static final Stroke LIMIT_STROKE = new BasicStroke(2.0F);
/*  24:    */   
/*  25:    */   public static final String LIMIT_VISIBLE_PROPERTY = "limitVisible";
/*  26:    */   
/*  27:    */   public static final String WINDOW_LENGTH_PROPERTY = "windowLength";
/*  28:    */   
/*  29:    */   public static final String LOG_PROPERTY = "logTransformation";
/*  30:    */   public static final String DIFF_PROPERTY = "differencing";
/*  31:    */   public static final String DIFF_LAG_PROPERTY = "differencingLag";
/*  32:    */   public static final String LASTYEARS_PROPERTY = "lastYears";
/*  33:    */   private static final boolean DEFAULT_LIMIT_VISIBLE = true;
/*  34:    */   private static final int DEFAULT_WINDOW_LENGTH = 1;
/*  35:    */   private static final boolean DEFAULT_LOG = false;
/*  36:    */   private static final int DEFAULT_DIFF = 1;
/*  37:    */   private static final int DEFAULT_DIFF_LAG = 1;
/*  38:    */   protected boolean limitVisible;
/*  39:    */   protected int windowLength;
/*  40: 40 */   private int del = 1; private int lag = 1;
/*  41: 41 */   private boolean log = false;
/*  42:    */   private int lastYears;
/*  43:    */   
/*  44:    */   public PeriodogramView() {
/*  45: 45 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  46: 46 */     lastYears = demetraUI.getSpectralLastYears().intValue();
/*  47:    */     
/*  48: 48 */     limitVisible = true;
/*  49: 49 */     windowLength = 1;
/*  50:    */     
/*  51: 51 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  52:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  53:    */         String str;
/*  54: 54 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1379041160:  if (str.equals("differencingLag")) {} break; case -1329180938:  if (str.equals("windowLength")) {} break; case -1255627721:  if (str.equals("limitVisible")) break; break; case -1196656966:  if (str.equals("differencing")) {} break; case 1574730605:  if (str.equals("logTransformation")) {} break; case 2007313120:  if (!str.equals("lastYears"))
/*  55:    */           {
/*  56: 56 */             return;onLimitVisibleChange();
/*  57: 57 */             return;
/*  58:    */             
/*  59: 59 */             onWindowLengthChange();
/*  60: 60 */             return;
/*  61:    */             
/*  62: 62 */             onLogChange();
/*  63: 63 */             return;
/*  64:    */             
/*  65: 65 */             onDiffChange();
/*  66: 66 */             return;
/*  67:    */             
/*  68: 68 */             onDiffChange();
/*  69:    */           }
/*  70:    */           else {
/*  71: 71 */             onLastYearsChange();
/*  72:    */           }
/*  73:    */           break;
/*  74:    */         }
/*  75:    */       }
/*  76: 76 */     });
/*  77: 77 */     onColorSchemeChange();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isLogTransformation() {
/*  81: 81 */     return log;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setLogTransformation(boolean log) {
/*  85: 85 */     boolean old = this.log;
/*  86: 86 */     this.log = log;
/*  87: 87 */     firePropertyChange("logTransformation", old, this.log);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public int getDifferencingOrder() {
/*  91: 91 */     return del;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setDifferencingOrder(int order) {
/*  95: 95 */     if (order < 0) {
/*  96: 96 */       throw new IllegalArgumentException("Differencing order should be >=0.");
/*  97:    */     }
/*  98: 98 */     int old = del;
/*  99: 99 */     del = order;
/* 100:100 */     firePropertyChange("differencing", old, del);
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected void onLimitVisibleChange()
/* 104:    */   {
/* 105:105 */     getPlot().clearRangeMarkers();
/* 106:106 */     if (limitVisible) {
/* 107:107 */       Chi2 chi = new Chi2();
/* 108:108 */       chi.setDegreesofFreedom(2);
/* 109:109 */       double val = chi.getProbabilityInverse(0.005D, ProbabilityType.Upper);
/* 110:    */       
/* 111:111 */       ARPView.ExtValueMarker limitMarker = new ARPView.ExtValueMarker(val, ColorScheme.KnownColor.GREEN);
/* 112:112 */       limitMarker.setStroke(LIMIT_STROKE);
/* 113:113 */       getPlot().addRangeMarker(limitMarker);
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   protected void onWindowLengthChange() {
/* 118:118 */     onARPDataChange();
/* 119:    */   }
/* 120:    */   
/* 121:    */   protected void onLogChange() {
/* 122:122 */     onARPDataChange();
/* 123:    */   }
/* 124:    */   
/* 125:    */   protected void onDiffChange() {
/* 126:126 */     onARPDataChange();
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected void onLastYearsChange() {
/* 130:130 */     onARPDataChange();
/* 131:    */   }
/* 132:    */   
/* 133:    */   public int getDifferencingLag() {
/* 134:134 */     return lag;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void setDifferencingLag(int lag) {
/* 138:138 */     if (lag <= 0) {
/* 139:139 */       throw new IllegalArgumentException("Lag order should be >0.");
/* 140:    */     }
/* 141:141 */     int old = this.lag;
/* 142:142 */     this.lag = lag;
/* 143:143 */     firePropertyChange("differencingLag", old, this.lag);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public int getLastYears() {
/* 147:147 */     return lastYears;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void setLastYears(int length) {
/* 151:151 */     if (length < 0) {
/* 152:152 */       throw new IllegalArgumentException("Last years should be >=0.");
/* 153:    */     }
/* 154:154 */     int old = lastYears;
/* 155:155 */     lastYears = length;
/* 156:156 */     firePropertyChange("differencing", old, lastYears);
/* 157:    */   }
/* 158:    */   
/* 159:    */   protected void onARPDataChange()
/* 160:    */   {
/* 161:161 */     super.onARPDataChange();
/* 162:162 */     if (data == null) {
/* 163:163 */       return;
/* 164:    */     }
/* 165:165 */     onColorSchemeChange();
/* 166:166 */     onLimitVisibleChange();
/* 167:    */   }
/* 168:    */   
/* 169:    */ 
/* 170:    */   public boolean isLimitVisible()
/* 171:    */   {
/* 172:172 */     return limitVisible;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void setLimitVisible(boolean limitVisible) {
/* 176:176 */     boolean old = this.limitVisible;
/* 177:177 */     this.limitVisible = limitVisible;
/* 178:178 */     firePropertyChange("limitVisible", old, this.limitVisible);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public int getWindowLength() {
/* 182:182 */     return windowLength;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setWindowLength(int windowLength) {
/* 186:186 */     int old = this.windowLength;
/* 187:187 */     this.windowLength = (windowLength > 0 ? windowLength : 1);
/* 188:188 */     firePropertyChange("windowLength", old, this.windowLength);
/* 189:    */   }
/* 190:    */   
/* 191:    */ 
/* 192:    */   protected XYSeries computeSeries()
/* 193:    */   {
/* 194:194 */     XYSeries result = new XYSeries(data.name);
/* 195:195 */     Values val = data.values.clone();
/* 196:196 */     if (log) {
/* 197:197 */       val.log();
/* 198:    */     }
/* 199:199 */     if (del > 0) {
/* 200:200 */       double[] s = new double[val.getLength()];
/* 201:201 */       val.copyTo(s, 0);
/* 202:202 */       for (int i = 0; i < del; i++) {
/* 203:203 */         for (int j = s.length - 1; j >= (i + 1) * lag; j--) {
/* 204:204 */           s[j] -= s[(j - lag)];
/* 205:    */         }
/* 206:    */       }
/* 207:207 */       val = new Values(new DataBlock(s, del * lag, s.length, 1));
/* 208:    */     }
/* 209:209 */     if ((lastYears > 0) && (data.freq > 0)) {
/* 210:210 */       int nmax = lastYears * data.freq;
/* 211:211 */       int nbeg = val.getLength() - nmax;
/* 212:212 */       if (nbeg > 0) {
/* 213:213 */         val = val.drop(nbeg, 0);
/* 214:    */       }
/* 215:    */     }
/* 216:216 */     Periodogram periodogram = new Periodogram(val);
/* 217:217 */     periodogram.setWindowLength(windowLength);
/* 218:218 */     double[] yp = periodogram.getS();
/* 219:219 */     for (int i = 0; i < yp.length; i++) {
/* 220:220 */       result.add(i * 6.283185307179586D / (val.getLength() - 1), yp[i]);
/* 221:    */     }
/* 222:    */     
/* 223:223 */     return result;
/* 224:    */   }
/* 225:    */ }
