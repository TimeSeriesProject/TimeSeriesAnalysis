/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*   5:    */ import ec.tstoolkit.uihelper.DiscreteDisplayDomain;
/*   6:    */ import ec.tstoolkit.uihelper.IDiscreteInformationProvider;
/*   7:    */ import ec.ui.chart.TsCharts;
/*   8:    */ import ec.util.chart.swing.ChartCommand;
/*   9:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  10:    */ import java.awt.Color;
/*  11:    */ import java.awt.Paint;
/*  12:    */ import java.awt.geom.Ellipse2D.Double;
/*  13:    */ import java.text.DecimalFormat;
/*  14:    */ import javax.swing.JMenu;
/*  15:    */ import javax.swing.JMenuItem;
/*  16:    */ import org.jfree.chart.ChartPanel;
/*  17:    */ import org.jfree.chart.JFreeChart;
/*  18:    */ import org.jfree.chart.axis.NumberAxis;
/*  19:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  20:    */ import org.jfree.chart.block.BlockBorder;
/*  21:    */ import org.jfree.chart.plot.PlotOrientation;
/*  22:    */ import org.jfree.chart.plot.XYPlot;
/*  23:    */ import org.jfree.chart.renderer.xy.XYBarRenderer;
/*  24:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  25:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  26:    */ import org.jfree.chart.title.LegendTitle;
/*  27:    */ import org.jfree.data.xy.XYBarDataset;
/*  28:    */ import org.jfree.data.xy.XYDataset;
/*  29:    */ import org.jfree.data.xy.XYSeries;
/*  30:    */ import org.jfree.data.xy.XYSeriesCollection;
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ public class FilterView
/*  35:    */   extends AChartView
/*  36:    */ {
/*  37:    */   public static final double DEFAULT_MIN_X = -35.0D;
/*  38:    */   public static final double DEFAULT_MAX_X = 35.0D;
/*  39:    */   public static final double DEFAULT_MIN_Y = -0.2D;
/*  40:    */   public static final double DEFAULT_MAX_Y = 1.0D;
/*  41: 41 */   public static final NumberTickUnit DEFAULT_TICKUNIT_X = new NumberTickUnit(5.0D);
/*  42: 42 */   public static final NumberTickUnit DEFAULT_TICKUNIT_Y = new NumberTickUnit(0.1D);
/*  43: 43 */   public static final DecimalFormat DEFAULT_FORMAT = new DecimalFormat("0.##");
/*  44:    */   protected static final int DOT_INDEX = 0;
/*  45:    */   protected static final int BAR_INDEX = 1;
/*  46:    */   protected final IDiscreteInformationProvider provider;
/*  47:    */   
/*  48:    */   public FilterView(IDiscreteInformationProvider provider)
/*  49:    */   {
/*  50: 50 */     super(100, PlotOrientation.VERTICAL, -35.0D, 35.0D, -0.2D, 1.0D, DEFAULT_TICKUNIT_X, DEFAULT_TICKUNIT_Y, DEFAULT_FORMAT);
/*  51: 51 */     setZoomable(false);
/*  52: 52 */     this.provider = provider;
/*  53: 53 */     chartPanel.setChart(createFilterView(seriesCollection));
/*  54: 54 */     onDomainChange();
/*  55: 55 */     chartPanel.setPopupMenu(buildMenu(chartPanel).getPopupMenu());
/*  56:    */   }
/*  57:    */   
/*  58:    */ 
/*  59:    */   protected void onColorSchemeChange()
/*  60:    */   {
/*  61: 61 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/*  62: 62 */     plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/*  63: 63 */     plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/*  64: 64 */     plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/*  65: 65 */     chartPanel.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/*  66:    */     
/*  67: 67 */     XYLineAndShapeRenderer dotRenderer = (XYLineAndShapeRenderer)plot.getRenderer(0);
/*  68: 68 */     XYBarRenderer barRenderer = (XYBarRenderer)plot.getRenderer(1);
/*  69: 69 */     for (int i = 0; i < seriesCollection.getSeriesCount(); i++) {
/*  70: 70 */       Color color = themeSupport.getLineColor(i);
/*  71: 71 */       dotRenderer.setSeriesPaint(i, color);
/*  72: 72 */       barRenderer.setSeriesPaint(i, color);
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected void onDomainChange()
/*  77:    */   {
/*  78: 78 */     DiscreteDisplayDomain domain = isBaseValues() ? 
/*  79: 79 */       provider.getDiscreteDisplayDomain(getPoints()) : 
/*  80: 80 */       provider.getDiscreteDisplayDomain((int)getMinX(), (int)getMaxX());
/*  81:    */     
/*  82: 82 */     seriesCollection.removeAllSeries();
/*  83:    */     
/*  84: 84 */     String[] components = provider.getComponents();
/*  85: 85 */     for (int i = 0; i < components.length; i++) {
/*  86: 86 */       if (provider.isDefined(i)) {
/*  87: 87 */         double[] data = provider.getDataArray(i, domain);
/*  88: 88 */         XYSeries series = new XYSeries(components[i]);
/*  89: 89 */         for (int j = 0; j < data.length; j++) {
/*  90: 90 */           series.add(domain.x(j), data[j]);
/*  91:    */         }
/*  92: 92 */         seriesCollection.addSeries(series);
/*  93:    */       }
/*  94:    */     }
/*  95:    */     
/*  96: 96 */     int fx = getFactorX();
/*  97: 97 */     chartPanel.getChart().getXYPlot().getRenderer(0).setBaseShape(new Ellipse2D.Double(-2 * fx, -2 * fx, 4 * fx, 4 * fx));
/*  98: 98 */     chartPanel.getChart().getLegend().setVisible(seriesCollection.getSeriesCount() > 1);
/*  99:    */     
/* 100:100 */     configureAxis();
/* 101:101 */     onColorSchemeChange();
/* 102:102 */     onFocusChange();
/* 103:    */   }
/* 104:    */   
/* 105:    */   protected void onFocusChange()
/* 106:    */   {
/* 107:107 */     int focusIndex = getFocusIndex();
/* 108:108 */     XYPlot plot = chartPanel.getChart().getXYPlot();
/* 109:109 */     XYLineAndShapeRenderer dotRenderer = (XYLineAndShapeRenderer)plot.getRenderer(0);
/* 110:    */     
/* 111:111 */     for (int i = 0; i < seriesCollection.getSeriesCount(); i++) {
/* 112:112 */       boolean hasFocus = i == focusIndex;
/* 113:113 */       dotRenderer.setSeriesShapesFilled(i, hasFocus);
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */ 
/* 118:    */   private static JFreeChart createFilterView(XYDataset dataset)
/* 119:    */   {
/* 120:120 */     XYPlot plot = new XYPlot();
/* 121:    */     
/* 122:122 */     XYLineAndShapeRenderer dotRenderer = new XYLineAndShapeRenderer(false, true);
/* 123:123 */     dotRenderer.setAutoPopulateSeriesShape(false);
/* 124:124 */     dotRenderer.setAutoPopulateSeriesFillPaint(false);
/* 125:125 */     dotRenderer.setBaseShapesFilled(false);
/* 126:126 */     plot.setRenderer(0, dotRenderer);
/* 127:127 */     plot.setDataset(0, dataset);
/* 128:    */     
/* 129:129 */     XYBarRenderer barRenderer = new XYBarRenderer();
/* 130:130 */     barRenderer.setShadowVisible(false);
/* 131:131 */     barRenderer.setBaseSeriesVisibleInLegend(false);
/* 132:132 */     plot.setRenderer(1, barRenderer);
/* 133:133 */     plot.setDataset(1, new XYBarDataset(dataset, 0.1D));
/* 134:    */     
/* 135:135 */     NumberAxis rangeAxis = new NumberAxis();
/* 136:136 */     rangeAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 137:137 */     plot.setRangeAxis(rangeAxis);
/* 138:    */     
/* 139:139 */     NumberAxis domainAxis = new NumberAxis();
/* 140:140 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 141:141 */     plot.setDomainAxis(domainAxis);
/* 142:    */     
/* 143:143 */     plot.mapDatasetToDomainAxis(0, 0);
/* 144:144 */     plot.mapDatasetToRangeAxis(0, 0);
/* 145:145 */     plot.mapDatasetToDomainAxis(1, 0);
/* 146:146 */     plot.mapDatasetToRangeAxis(1, 0);
/* 147:    */     
/* 148:148 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, true);
/* 149:149 */     result.setPadding(TsCharts.CHART_PADDING);
/* 150:150 */     result.getLegend().setFrame(BlockBorder.NONE);
/* 151:151 */     result.getLegend().setBackgroundPaint(null);
/* 152:152 */     return result;
/* 153:    */   }
/* 154:    */   
/* 155:    */   private static JMenu buildMenu(ChartPanel chartPanel) {
/* 156:156 */     JMenu result = new JMenu();
/* 157:    */     
/* 158:158 */     result.add(new CustomCommand(null).toAction(chartPanel)).setText("Copy all visible");
/* 159:    */     
/* 160:160 */     JMenu export = new JMenu("Export image to");
/* 161:161 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 162:162 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 163:163 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 164:164 */     result.add(export);
/* 165:    */     
/* 166:166 */     return result;
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static class CustomCommand extends MatrixChartCommand
/* 170:    */   {
/* 171:    */     protected Matrix toMatrix(ChartPanel chartPanel)
/* 172:    */     {
/* 173:173 */       XYDataset dataset = chartPanel.getChart().getXYPlot().getDataset(0);
/* 174:174 */       Matrix result = new Matrix(dataset.getItemCount(0), dataset.getSeriesCount() + 1);
/* 175:175 */       for (int i = 0; i < result.getRowsCount(); i++) {
/* 176:176 */         result.set(i, 0, dataset.getXValue(0, i));
/* 177:177 */         for (int j = 0; j < dataset.getSeriesCount(); j++) {
/* 178:178 */           result.set(i, j + 1, dataset.getYValue(j, i));
/* 179:    */         }
/* 180:    */       }
/* 181:181 */       return result;
/* 182:    */     }
/* 183:    */     
/* 184:    */     public boolean isEnabled(ChartPanel chartPanel)
/* 185:    */     {
/* 186:186 */       XYPlot plot = chartPanel.getChart().getXYPlot();
/* 187:187 */       return (plot.getDatasetCount() > 0) && (plot.getDataset(0).getSeriesCount() > 0);
/* 188:    */     }
/* 189:    */   }
/* 190:    */ }
