/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbComponents;
/*  4:   */ import ec.tss.html.HtmlStream;
/*  5:   */ import ec.tss.html.implementation.HtmlArima;
/*  6:   */ import ec.tss.html.implementation.HtmlSArima;
/*  7:   */ import ec.tstoolkit.arima.IArimaModel;
/*  8:   */ import ec.tstoolkit.sarima.SarimaModel;
/*  9:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/* 10:   */ import ec.tstoolkit.uihelper.ModelInformationProvider;
/* 11:   */ import ec.ui.html.JHtmlPane;
/* 12:   */ import java.awt.BorderLayout;
/* 13:   */ import java.io.IOException;
/* 14:   */ import java.io.StringWriter;
/* 15:   */ import java.util.Iterator;
/* 16:   */ import java.util.Map;
/* 17:   */ import java.util.Map.Entry;
/* 18:   */ import javax.swing.JComponent;
/* 19:   */ import javax.swing.JSplitPane;
/* 20:   */ import javax.swing.text.html.StyleSheet;
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class ArimaView
/* 29:   */   extends JComponent
/* 30:   */ {
/* 31:   */   private PiView spectrumPanel_;
/* 32:   */   private JHtmlPane documentPanel_;
/* 33:   */   
/* 34:   */   public ArimaView(Map<String, ? extends IArimaModel> models)
/* 35:   */   {
/* 36:36 */     setLayout(new BorderLayout());
/* 37:37 */     ModelInformationProvider spectrum = new ModelInformationProvider(models);
/* 38:38 */     spectrum.setFrequency(TsFrequency.Monthly);
/* 39:39 */     spectrum.setInformation("Spectrum");
/* 40:40 */     spectrumPanel_ = new PiView(spectrum);
/* 41:41 */     ModelInformationProvider ac = new ModelInformationProvider(models);
/* 42:42 */     ac.setFrequency(TsFrequency.Monthly);
/* 43:43 */     ac.setInformation("Auto-correlations");
/* 44:   */     
/* 45:45 */     documentPanel_ = new JHtmlPane();
/* 46:46 */     StyleSheet ss = new StyleSheet();
/* 47:47 */     ss.addRule("body {font-family: arial, verdana;}");
/* 48:48 */     ss.addRule("body {font-size: 11;}");
/* 49:49 */     ss.addRule("h4 {color: blue;}");
/* 50:50 */     ss.addRule("td, th{text-align: right; margin-left: 5px; margin-right: 5 px;}");
/* 51:51 */     ss.addRule("table {border: solid;}");
/* 52:52 */     documentPanel_.setStyleSheet(ss);
/* 53:   */     
/* 54:54 */     JSplitPane split = NbComponents.newJSplitPane(0, spectrumPanel_, NbComponents.newJScrollPane(documentPanel_));
/* 55:55 */     split.setDividerLocation(0.5D);
/* 56:56 */     split.setResizeWeight(0.5D);
/* 57:   */     
/* 58:58 */     add(split, "Center");
/* 59:   */     
/* 60:60 */     displayHtml(models);
/* 61:   */   }
/* 62:   */   
/* 63:   */   private void displayHtml(Map<String, ? extends IArimaModel> models) {
/* 64:64 */     StringWriter writer = new StringWriter();
/* 65:65 */     try { Object localObject1 = null;Object localObject4 = null; Object localObject3; label268: try { stream = new HtmlStream(writer);
/* 66:   */       }
/* 67:   */       finally
/* 68:   */       {
/* 69:   */         HtmlStream stream;
/* 70:   */         
/* 71:   */         Iterator localIterator;
/* 72:   */         
/* 73:   */         Map.Entry<String, ? extends IArimaModel> o;
/* 74:   */         
/* 75:   */         IArimaModel model;
/* 76:   */         
/* 77:   */         SarimaModel sarima;
/* 78:   */         
/* 79:   */         HtmlSArima document;
/* 80:   */         
/* 81:   */         StringBuilder title;
/* 82:   */         
/* 83:   */         HtmlArima document;
/* 84:84 */         localObject3 = localThrowable; break label268; if (localObject3 != localThrowable) localObject3.addSuppressed(localThrowable);
/* 85:   */       }
/* 86:   */     }
/* 87:   */     catch (IOException localIOException1) {
/* 88:88 */       documentPanel_.setText(writer.toString());
/* 89:   */     }
/* 90:   */   }
/* 91:   */ }
