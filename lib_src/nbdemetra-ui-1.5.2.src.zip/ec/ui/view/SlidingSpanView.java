/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   5:    */ import ec.satoolkit.DecompositionMode;
/*   6:    */ import ec.tss.datatransfer.TssTransferSupport;
/*   7:    */ import ec.tss.html.implementation.HtmlSlidingSpanDocument;
/*   8:    */ import ec.tstoolkit.algorithm.IProcResults;
/*   9:    */ import ec.tstoolkit.data.DataBlock;
/*  10:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*  11:    */ import ec.tstoolkit.data.Values;
/*  12:    */ import ec.tstoolkit.timeseries.analysis.DiagnosticInfo;
/*  13:    */ import ec.tstoolkit.timeseries.analysis.SlidingSpans;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  15:    */ import ec.ui.Disposables;
/*  16:    */ import ec.ui.chart.TsCharts;
/*  17:    */ import ec.ui.chart.TsXYDatasets;
/*  18:    */ import ec.ui.interfaces.IColorSchemeAble;
/*  19:    */ import ec.ui.view.tsprocessing.ITsViewToolkit;
/*  20:    */ import ec.ui.view.tsprocessing.TsViewToolkit;
/*  21:    */ import ec.util.chart.ColorScheme;
/*  22:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  23:    */ import ec.util.chart.swing.ChartCommand;
/*  24:    */ import ec.util.chart.swing.Charts;
/*  25:    */ import ec.util.chart.swing.ext.MatrixChartCommand;
/*  26:    */ import java.awt.BorderLayout;
/*  27:    */ import java.awt.Paint;
/*  28:    */ import java.awt.Toolkit;
/*  29:    */ import java.awt.datatransfer.Clipboard;
/*  30:    */ import java.awt.datatransfer.Transferable;
/*  31:    */ import java.beans.PropertyChangeEvent;
/*  32:    */ import java.beans.PropertyChangeListener;
/*  33:    */ import java.text.DecimalFormat;
/*  34:    */ import java.text.NumberFormat;
/*  35:    */ import java.text.SimpleDateFormat;
/*  36:    */ import java.util.Arrays;
/*  37:    */ import java.util.Iterator;
/*  38:    */ import java.util.List;
/*  39:    */ import javax.swing.Box;
/*  40:    */ import javax.swing.JComponent;
/*  41:    */ import javax.swing.JMenu;
/*  42:    */ import javax.swing.JMenuItem;
/*  43:    */ import javax.swing.JSplitPane;
/*  44:    */ import org.jfree.chart.ChartFactory;
/*  45:    */ import org.jfree.chart.ChartPanel;
/*  46:    */ import org.jfree.chart.JFreeChart;
/*  47:    */ import org.jfree.chart.axis.DateAxis;
/*  48:    */ import org.jfree.chart.axis.DateTickUnit;
/*  49:    */ import org.jfree.chart.axis.DateTickUnitType;
/*  50:    */ import org.jfree.chart.axis.NumberAxis;
/*  51:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  52:    */ import org.jfree.chart.axis.ValueAxis;
/*  53:    */ import org.jfree.chart.plot.PlotOrientation;
/*  54:    */ import org.jfree.chart.plot.XYPlot;
/*  55:    */ import org.jfree.chart.renderer.xy.XYAreaRenderer;
/*  56:    */ import org.jfree.chart.renderer.xy.XYBarRenderer;
/*  57:    */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/*  58:    */ import org.jfree.chart.title.TextTitle;
/*  59:    */ import org.jfree.data.Range;
/*  60:    */ import org.jfree.data.xy.DefaultXYDataset;
/*  61:    */ 
/*  62:    */ public class SlidingSpanView
/*  63:    */   extends JComponent
/*  64:    */   implements IColorSchemeAble
/*  65:    */ {
/*  66:    */   protected static final int N = 18;
/*  67:    */   public static final String SLIDING_SPANS_PROPERTY = "slidingSpans";
/*  68:    */   public static final String INFO_NAME_PROPERTY = "infoName";
/*  69:    */   public static final String THRESHOLD_PROPERTY = "threshold";
/*  70:    */   public static final String INFO_PROPERTY = "info";
/*  71:    */   protected static final double DEFAULT_THRESHOLD = 3.0D;
/*  72: 72 */   protected static final DiagnosticInfo DEFAULT_INFO = DiagnosticInfo.RelativeDifference;
/*  73:    */   
/*  74:    */   protected SlidingSpans<?> slidingSpans;
/*  75:    */   
/*  76:    */   protected String infoName;
/*  77:    */   protected double threshold;
/*  78:    */   protected DiagnosticInfo info;
/*  79:    */   protected final ThemeSupport themeSupport;
/*  80:    */   private final JChartPanel seriesPanel;
/*  81:    */   private final JChartPanel distributionPanel;
/*  82:    */   private final Box documentPanel;
/*  83: 83 */   private ITsViewToolkit toolkit_ = TsViewToolkit.getInstance();
/*  84:    */   
/*  85:    */   public SlidingSpanView()
/*  86:    */   {
/*  87: 87 */     slidingSpans = null;
/*  88: 88 */     infoName = null;
/*  89: 89 */     threshold = 3.0D;
/*  90: 90 */     info = DEFAULT_INFO;
/*  91: 91 */     themeSupport = new ThemeSupport()
/*  92:    */     {
/*  93:    */       protected void colorSchemeChanged() {
/*  94: 94 */         onColorSchemeChange();
/*  95:    */       }
/*  96:    */       
/*  97: 97 */     };
/*  98: 98 */     seriesPanel = new JChartPanel(createSeriesChart());
/*  99: 99 */     Charts.avoidScaling(seriesPanel);
/* 100:100 */     distributionPanel = new JChartPanel(createDistributionChart());
/* 101:101 */     Charts.avoidScaling(distributionPanel);
/* 102:102 */     documentPanel = Box.createHorizontalBox();
/* 103:    */     
/* 104:104 */     JSplitPane splitpane1 = NbComponents.newJSplitPane(1, true, distributionPanel, documentPanel);
/* 105:105 */     splitpane1.setDividerLocation(0.5D);
/* 106:106 */     splitpane1.setResizeWeight(0.5D);
/* 107:    */     
/* 108:108 */     JSplitPane splitpane2 = NbComponents.newJSplitPane(0, true, seriesPanel, splitpane1);
/* 109:109 */     splitpane2.setDividerLocation(0.4D);
/* 110:110 */     splitpane2.setResizeWeight(0.5D);
/* 111:    */     
/* 112:112 */     setLayout(new BorderLayout());
/* 113:113 */     add(splitpane2, "Center");
/* 114:    */     
/* 115:115 */     themeSupport.register();
/* 116:    */     
/* 117:117 */     addPropertyChangeListener(new PropertyChangeListener() {
/* 118:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 119:    */         String str;
/* 120:120 */         switch ((str = evt.getPropertyName()).hashCode()) {case -1545477013:  if (str.equals("threshold")) {} break; case 3237038:  if (str.equals("info")) {} break; case 177753177:  if (str.equals("infoName")) break;  case 1828027611:  if ((goto 137) && (str.equals("slidingSpans")))
/* 121:    */           {
/* 122:122 */             onSlidingSpansChange();
/* 123:123 */             return;
/* 124:    */             
/* 125:125 */             onInfoNameChange();
/* 126:126 */             return;
/* 127:    */             
/* 128:128 */             onThresholdChange();
/* 129:129 */             return;
/* 130:    */             
/* 131:131 */             onInfoChange();
/* 132:    */           }
/* 133:    */           break;
/* 134:    */         }
/* 135:    */       }
/* 136:136 */     });
/* 137:137 */     seriesPanel.setPopupMenu(createSeriesMenu(seriesPanel).getPopupMenu());
/* 138:138 */     distributionPanel.setPopupMenu(createDistributionMenu(distributionPanel).getPopupMenu());
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected void onSlidingSpansChange()
/* 142:    */   {
/* 143:143 */     if (slidingSpans == null) {
/* 144:144 */       return;
/* 145:    */     }
/* 146:    */     
/* 147:147 */     clear();
/* 148:148 */     TsData data = slidingSpans.Statistics(infoName, info);
/* 149:149 */     if ((data == null) || (data.getValues().getMissingValuesCount() == data.getValues().getLength())) {
/* 150:150 */       return;
/* 151:    */     }
/* 152:    */     
/* 153:153 */     DescriptiveStatistics stats = new DescriptiveStatistics(new DataBlock(data.getValues().internalStorage()));
/* 154:154 */     if (stats.isConstant()) {
/* 155:155 */       return;
/* 156:    */     }
/* 157:    */     
/* 158:158 */     DecompositionMode mode = (DecompositionMode)((IProcResults)slidingSpans.getReferenceInfo()).getData("mode", DecompositionMode.class);
/* 159:    */     
/* 160:160 */     showSeries(data, mode);
/* 161:161 */     showDistribution(stats, mode);
/* 162:162 */     showStatistics();
/* 163:    */     
/* 164:164 */     onColorSchemeChange();
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected void onInfoNameChange() {
/* 168:168 */     onSlidingSpansChange();
/* 169:    */   }
/* 170:    */   
/* 171:    */   protected void onThresholdChange() {
/* 172:172 */     onSlidingSpansChange();
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected void onInfoChange() {
/* 176:176 */     onSlidingSpansChange();
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected void onColorSchemeChange() {
/* 180:180 */     Iterator localIterator = Arrays.asList(new JChartPanel[] { seriesPanel, distributionPanel }).iterator();
/* 181:    */     
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:187 */     while (localIterator.hasNext())
/* 188:    */     {
/* 189:180 */       JChartPanel o = (JChartPanel)localIterator.next();
/* 190:181 */       XYPlot plot = o.getChart().getXYPlot();
/* 191:182 */       plot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 192:183 */       plot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 193:184 */       plot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 194:185 */       plot.getRenderer().setBasePaint((Paint)themeSupport.getAreaColor(ColorScheme.KnownColor.BLUE));
/* 195:186 */       plot.getRenderer().setBaseOutlinePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 196:187 */       o.getChart().setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void setTsToolkit(ITsViewToolkit toolkit)
/* 201:    */   {
/* 202:193 */     toolkit_ = toolkit;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public ITsViewToolkit getTsToolkit() {
/* 206:197 */     return toolkit_;
/* 207:    */   }
/* 208:    */   
/* 209:    */   private Range calcRange(double[] values) {
/* 210:201 */     double min = (-1.0D / 0.0D);double max = (-1.0D / 0.0D);
/* 211:    */     
/* 212:203 */     DescriptiveStatistics stats = new DescriptiveStatistics(new DataBlock(values));
/* 213:204 */     double smin = stats.getMin();double smax = stats.getMax();
/* 214:205 */     if ((Double.isInfinite(min)) || (smin < min)) {
/* 215:206 */       min = smin;
/* 216:    */     }
/* 217:208 */     if ((Double.isInfinite(max)) || (smax > max)) {
/* 218:209 */       max = smax;
/* 219:    */     }
/* 220:    */     
/* 221:212 */     if ((Double.isInfinite(max)) || (Double.isInfinite(min))) {
/* 222:213 */       return new Range(0.0D, 1.0D);
/* 223:    */     }
/* 224:215 */     double length = max - min;
/* 225:216 */     if (length == 0.0D) {
/* 226:217 */       return new Range(0.0D, 1.0D);
/* 227:    */     }
/* 228:    */     
/* 229:    */ 
/* 230:221 */     return new Range(min, max);
/* 231:    */   }
/* 232:    */   
/* 233:    */   private double calcTick(Range rng)
/* 234:    */   {
/* 235:226 */     double tick = 0.0D;
/* 236:227 */     double avg = (rng.getUpperBound() - rng.getLowerBound()) / 6.0D;
/* 237:228 */     for (int i = 0; (i < 10) && (tick == 0.0D); i++) {
/* 238:229 */       double power = Math.pow(10.0D, i);
/* 239:230 */       if ((avg > 0.1D * power) && (avg <= 0.2D * power)) {
/* 240:231 */         tick = 0.2D * power;
/* 241:232 */       } else if ((avg > 0.2D * power) && (avg <= 0.5D * power)) {
/* 242:233 */         tick = 0.5D * power;
/* 243:234 */       } else if ((avg > 0.5D * power) && (avg <= 1.0D * power)) {
/* 244:235 */         tick = 1.0D * power;
/* 245:    */       }
/* 246:    */     }
/* 247:238 */     return tick;
/* 248:    */   }
/* 249:    */   
/* 250:    */   private void showDistribution(DescriptiveStatistics stats, DecompositionMode mode) {
/* 251:242 */     DefaultXYDataset dataset = new DefaultXYDataset();
/* 252:    */     
/* 253:244 */     double nobs = stats.getObservationsCount();
/* 254:245 */     double step = threshold / 6.0D;
/* 255:246 */     double[] xvalues = new double[18];
/* 256:247 */     double[] values = new double[18];
/* 257:248 */     for (int i = 0; i < 18; i++) {
/* 258:249 */       xvalues[i] = (step * (i + 0.5D));
/* 259:250 */       values[i] = (stats.countBetween(i * step, (i + 1) * step) / nobs);
/* 260:    */     }
/* 261:252 */     dataset.addSeries("", new double[][] { xvalues, values });
/* 262:    */     
/* 263:254 */     XYPlot plot = distributionPanel.getChart().getXYPlot();
/* 264:255 */     plot.setDataset(dataset);
/* 265:    */     
/* 266:257 */     NumberAxis xAxis = (NumberAxis)plot.getDomainAxis();
/* 267:258 */     NumberAxis yAxis = (NumberAxis)plot.getRangeAxis();
/* 268:259 */     switch (mode) {
/* 269:    */     case Multiplicative: 
/* 270:261 */       xAxis.setTickUnit(new NumberTickUnit(0.02D));
/* 271:262 */       xAxis.setRange(0.0D, 0.1D);
/* 272:263 */       yAxis.setTickUnit(new PercentageTickUnit(0.05D));
/* 273:264 */       break;
/* 274:    */     case LogAdditive: 
/* 275:266 */       Range rng = calcRange(xvalues);
/* 276:267 */       xAxis.setTickUnit(new NumberTickUnit(calcTick(rng)));
/* 277:268 */       yAxis.setTickUnit(new PercentageTickUnit(0.05D));
/* 278:    */     }
/* 279:    */   }
/* 280:    */   
/* 281:    */   private void showStatistics()
/* 282:    */   {
/* 283:274 */     HtmlSlidingSpanDocument document = new HtmlSlidingSpanDocument(slidingSpans, infoName, info);
/* 284:275 */     document.setThreshold(threshold);
/* 285:276 */     ((Box)Disposables.disposeAndRemoveAll(documentPanel)).add(toolkit_.getHtmlViewer(document));
/* 286:    */   }
/* 287:    */   
/* 288:    */   private void showSeries(TsData data, DecompositionMode mode)
/* 289:    */   {
/* 290:281 */     seriesPanel.putClientProperty("TS_DATA", data);
/* 291:    */     
/* 292:283 */     XYPlot plot = seriesPanel.getChart().getXYPlot();
/* 293:284 */     plot.setDataset(TsXYDatasets.from(infoName, data));
/* 294:    */     
/* 295:286 */     NumberAxis yAxis = (NumberAxis)plot.getRangeAxis();
/* 296:287 */     switch (mode) {
/* 297:    */     case Multiplicative: 
/* 298:289 */       NumberFormat nf = new DecimalFormat("0.##");
/* 299:290 */       yAxis.setNumberFormatOverride(nf);
/* 300:291 */       yAxis.setTickUnit(new NumberTickUnit(0.01D));
/* 301:292 */       break;
/* 302:    */     case LogAdditive: 
/* 303:294 */       Range rng = calcRange(data.getValues().internalStorage());
/* 304:295 */       yAxis.setTickUnit(new NumberTickUnit(calcTick(rng)));
/* 305:    */     }
/* 306:    */     
/* 307:    */   }
/* 308:    */   
/* 309:    */ 
/* 310:    */   private void clear() {}
/* 311:    */   
/* 312:    */ 
/* 313:    */   public String getInfoName()
/* 314:    */   {
/* 315:306 */     return infoName;
/* 316:    */   }
/* 317:    */   
/* 318:    */   public void setInfoName(String infoName) {
/* 319:310 */     String old = this.infoName;
/* 320:311 */     this.infoName = infoName;
/* 321:312 */     firePropertyChange("infoName", old, this.infoName);
/* 322:    */   }
/* 323:    */   
/* 324:    */   public double getThreshold() {
/* 325:316 */     return threshold;
/* 326:    */   }
/* 327:    */   
/* 328:    */   public void setThreshold(double threshold) {
/* 329:320 */     double old = this.threshold;
/* 330:321 */     this.threshold = threshold;
/* 331:322 */     firePropertyChange("threshold", old, this.threshold);
/* 332:    */   }
/* 333:    */   
/* 334:    */   public DiagnosticInfo getInfo() {
/* 335:326 */     return info;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public void setInfo(DiagnosticInfo info) {
/* 339:330 */     DiagnosticInfo old = this.info;
/* 340:331 */     this.info = info;
/* 341:332 */     firePropertyChange("infoName", old, this.info);
/* 342:    */   }
/* 343:    */   
/* 344:    */   public SlidingSpans getSlidingSpans() {
/* 345:336 */     return slidingSpans;
/* 346:    */   }
/* 347:    */   
/* 348:    */   public void setSlidingSpans(SlidingSpans<?> slidingspans) {
/* 349:340 */     SlidingSpans<?> old = slidingSpans;
/* 350:341 */     slidingSpans = slidingspans;
/* 351:342 */     firePropertyChange("slidingSpans", old, slidingSpans);
/* 352:    */   }
/* 353:    */   
/* 354:    */   public ColorScheme getColorScheme()
/* 355:    */   {
/* 356:347 */     return themeSupport.getLocalColorScheme();
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void setColorScheme(ColorScheme theme)
/* 360:    */   {
/* 361:352 */     themeSupport.setLocalColorScheme(theme);
/* 362:    */   }
/* 363:    */   
/* 364:    */   static JFreeChart createSeriesChart()
/* 365:    */   {
/* 366:357 */     JFreeChart result = ChartFactory.createXYBarChart("", "", false, "", Charts.emptyXYDataset(), PlotOrientation.VERTICAL, false, false, false);
/* 367:358 */     result.setPadding(TsCharts.CHART_PADDING);
/* 368:359 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 369:    */     
/* 370:361 */     XYPlot plot = result.getXYPlot();
/* 371:    */     
/* 372:363 */     DateAxis domainAxis = new DateAxis();
/* 373:    */     
/* 374:365 */     domainAxis.setTickUnit(new DateTickUnit(DateTickUnitType.YEAR, 1));
/* 375:366 */     domainAxis.setDateFormatOverride(new SimpleDateFormat("yyyy-MM"));
/* 376:367 */     domainAxis.setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 377:368 */     plot.setDomainAxis(domainAxis);
/* 378:    */     
/* 379:370 */     plot.getRangeAxis().setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 380:    */     
/* 381:372 */     XYBarRenderer renderer = (XYBarRenderer)plot.getRenderer();
/* 382:373 */     renderer.setShadowVisible(false);
/* 383:374 */     renderer.setDrawBarOutline(true);
/* 384:375 */     renderer.setAutoPopulateSeriesPaint(false);
/* 385:376 */     renderer.setAutoPopulateSeriesOutlinePaint(false);
/* 386:    */     
/* 387:378 */     return result;
/* 388:    */   }
/* 389:    */   
/* 390:    */   static JMenu createSeriesMenu(ChartPanel chartPanel) {
/* 391:382 */     JMenu result = new JMenu();
/* 392:    */     
/* 393:384 */     ChartCommand copy = new ChartCommand()
/* 394:    */     {
/* 395:    */       public void execute(ChartPanel chartPanel) {
/* 396:387 */         TsData data = (TsData)chartPanel.getClientProperty("TS_DATA");
/* 397:388 */         Transferable t = TssTransferSupport.getDefault().fromTsData(data);
/* 398:389 */         Toolkit.getDefaultToolkit().getSystemClipboard().setContents(t, null);
/* 399:    */       }
/* 400:    */       
/* 401:    */       public boolean isEnabled(ChartPanel chartPanel)
/* 402:    */       {
/* 403:394 */         return chartPanel.getClientProperty("TS_DATA") instanceof TsData;
/* 404:    */       }
/* 405:    */       
/* 406:397 */     };
/* 407:398 */     result.add(copy.toAction(chartPanel)).setText("Copy series");
/* 408:    */     
/* 409:400 */     JMenu export = new JMenu("Export image to");
/* 410:401 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 411:402 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 412:403 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 413:404 */     result.add(export);
/* 414:    */     
/* 415:406 */     return result;
/* 416:    */   }
/* 417:    */   
/* 418:    */   static JFreeChart createDistributionChart() {
/* 419:410 */     JFreeChart result = ChartFactory.createXYAreaChart("Distribution", "", "", Charts.emptyXYDataset(), PlotOrientation.VERTICAL, false, false, false);
/* 420:411 */     result.setPadding(TsCharts.CHART_PADDING);
/* 421:412 */     result.getTitle().setFont(TsCharts.CHART_TITLE_FONT);
/* 422:    */     
/* 423:414 */     XYPlot plot = result.getXYPlot();
/* 424:415 */     plot.getDomainAxis().setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 425:416 */     plot.getRangeAxis().setTickLabelPaint(TsCharts.CHART_TICK_LABEL_COLOR);
/* 426:    */     
/* 427:418 */     XYAreaRenderer renderer = (XYAreaRenderer)plot.getRenderer();
/* 428:419 */     renderer.setAutoPopulateSeriesPaint(false);
/* 429:420 */     renderer.setOutline(true);
/* 430:    */     
/* 431:422 */     return result;
/* 432:    */   }
/* 433:    */   
/* 434:    */   static JMenu createDistributionMenu(ChartPanel chartPanel) {
/* 435:426 */     JMenu result = new JMenu();
/* 436:    */     
/* 437:428 */     result.add(MatrixChartCommand.copySeries(0, 0).toAction(chartPanel)).setText("Copy distribution");
/* 438:    */     
/* 439:430 */     JMenu export = new JMenu("Export image to");
/* 440:431 */     export.add(ChartCommand.printImage().toAction(chartPanel)).setText("Printer...");
/* 441:432 */     export.add(ChartCommand.copyImage().toAction(chartPanel)).setText("Clipboard");
/* 442:433 */     export.add(ChartCommand.saveImage().toAction(chartPanel)).setText("File...");
/* 443:434 */     result.add(export);
/* 444:    */     
/* 445:436 */     return result;
/* 446:    */   }
/* 447:    */ }
