/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.TsCollection;
/*  5:   */ import ec.ui.chart.JTsDualChart;
/*  6:   */ import java.awt.BorderLayout;
/*  7:   */ import java.util.ArrayList;
/*  8:   */ import java.util.List;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class DecompositionView
/* 17:   */   extends JComponent
/* 18:   */ {
/* 19:   */   private JTsDualChart dualchart_;
/* 20:   */   
/* 21:   */   public DecompositionView()
/* 22:   */   {
/* 23:23 */     dualchart_ = new JTsDualChart();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void set(List<Ts> high, List<Ts> low) {
/* 27:27 */     List<Ts> coll = new ArrayList();
/* 28:28 */     coll.addAll(high);
/* 29:29 */     coll.addAll(low);
/* 30:30 */     for (int i = high.size(); i < coll.size(); i++) {
/* 31:31 */       dualchart_.setTsLevel(i, true);
/* 32:   */     }
/* 33:33 */     dualchart_.getTsCollection().replace(coll);
/* 34:   */     
/* 35:35 */     setLayout(new BorderLayout());
/* 36:36 */     add(dualchart_, "Center");
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void clear() {
/* 40:40 */     dualchart_.reset();
/* 41:   */   }
/* 42:   */ }
