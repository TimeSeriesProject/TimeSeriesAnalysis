/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.satoolkit.DecompositionMode;
/*   5:    */ import ec.tss.Ts;
/*   6:    */ import ec.tstoolkit.data.DataBlock;
/*   7:    */ import ec.tstoolkit.timeseries.simplets.PeriodIterator;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*   9:    */ import ec.tstoolkit.timeseries.simplets.TsDataBlock;
/*  10:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  11:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  13:    */ import ec.ui.ATsView;
/*  14:    */ import ec.ui.chart.BasicXYDataset;
/*  15:    */ import ec.ui.chart.BasicXYDataset.Series;
/*  16:    */ import ec.ui.chart.TsCharts;
/*  17:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  18:    */ import ec.util.chart.swing.Charts;
/*  19:    */ import java.awt.BasicStroke;
/*  20:    */ import java.awt.BorderLayout;
/*  21:    */ import java.awt.Color;
/*  22:    */ import java.awt.Paint;
/*  23:    */ import java.awt.Stroke;
/*  24:    */ import java.awt.datatransfer.Clipboard;
/*  25:    */ import java.awt.datatransfer.ClipboardOwner;
/*  26:    */ import java.awt.datatransfer.Transferable;
/*  27:    */ import java.awt.event.ComponentAdapter;
/*  28:    */ import java.awt.event.ComponentEvent;
/*  29:    */ import java.awt.event.MouseAdapter;
/*  30:    */ import java.awt.event.MouseEvent;
/*  31:    */ import java.awt.geom.Ellipse2D.Double;
/*  32:    */ import java.text.DecimalFormat;
/*  33:    */ import java.util.Collections;
/*  34:    */ import java.util.HashMap;
/*  35:    */ import java.util.Map;
/*  36:    */ import org.jfree.chart.JFreeChart;
/*  37:    */ import org.jfree.chart.axis.NumberAxis;
/*  38:    */ import org.jfree.chart.axis.NumberTickUnit;
/*  39:    */ import org.jfree.chart.labels.StandardXYToolTipGenerator;
/*  40:    */ import org.jfree.chart.plot.DatasetRenderingOrder;
/*  41:    */ import org.jfree.chart.plot.ValueMarker;
/*  42:    */ import org.jfree.chart.plot.XYPlot;
/*  43:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  44:    */ import org.jfree.data.xy.XYDataset;
/*  45:    */ 
/*  46:    */ public class SIView
/*  47:    */   extends ATsView
/*  48:    */   implements ClipboardOwner
/*  49:    */ {
/*  50:    */   private static final int S_INDEX = 0;
/*  51:    */   private static final int T_INDEX = 1;
/*  52:    */   private static final int SI_INDEX = 2;
/*  53: 53 */   private static final Stroke MARKER_STROKE = new BasicStroke(0.5F);
/*  54: 54 */   private static final Paint MARKER_PAINT = Color.DARK_GRAY;
/*  55:    */   
/*  56:    */   private static final float MARKER_ALPHA = 0.8F;
/*  57:    */   private final Map<Bornes, Graphs> graphs_;
/*  58:    */   private final JChartPanel chartpanel_;
/*  59:    */   private final XYLineAndShapeRenderer sRenderer;
/*  60:    */   private final XYLineAndShapeRenderer tRenderer;
/*  61:    */   private final XYLineAndShapeRenderer siRenderer1;
/*  62:    */   private final PreciseXYLineAndShapeRenderer siRenderer2;
/*  63:    */   private final JFreeChart mainchart_;
/*  64:    */   private final JFreeChart detailchart_;
/*  65:    */   
/*  66:    */   static class Bornes
/*  67:    */   {
/*  68: 68 */     static final Bornes ZERO = new Bornes(0.0D, 0.0D);
/*  69:    */     final double min_;
/*  70:    */     final double max_;
/*  71:    */     
/*  72:    */     Bornes(double min, double max) {
/*  73: 73 */       min_ = min;
/*  74: 74 */       max_ = max;
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   static class Graphs
/*  79:    */   {
/*  80:    */     final BasicXYDataset.Series S1_;
/*  81:    */     final BasicXYDataset.Series S2_;
/*  82:    */     final BasicXYDataset.Series S3_;
/*  83:    */     final String label_;
/*  84:    */     
/*  85:    */     Graphs(BasicXYDataset.Series s1, BasicXYDataset.Series s2, BasicXYDataset.Series s3, String label) {
/*  86: 86 */       S1_ = s1;
/*  87: 87 */       S2_ = s2;
/*  88: 88 */       S3_ = s3;
/*  89: 89 */       label_ = label;
/*  90:    */     }
/*  91:    */     
/*  92:    */     static double minYear(BasicXYDataset.Series S) {
/*  93: 93 */       return S.getXValue(0);
/*  94:    */     }
/*  95:    */     
/*  96:    */     static double maxYear(BasicXYDataset.Series S) {
/*  97: 97 */       return S.getXValue(S.getItemCount() - 1);
/*  98:    */     }
/*  99:    */     
/* 100:    */     int getMinYear() {
/* 101:101 */       double year = 9999.0D;
/* 102:102 */       if ((S1_.getItemCount() > 0) && (minYear(S1_) < year)) {
/* 103:103 */         year = minYear(S1_);
/* 104:    */       }
/* 105:105 */       if ((S2_.getItemCount() > 0) && (minYear(S2_) < year)) {
/* 106:106 */         year = minYear(S2_);
/* 107:    */       }
/* 108:108 */       if ((S3_.getItemCount() > 0) && (minYear(S3_) < year)) {
/* 109:109 */         year = minYear(S3_);
/* 110:    */       }
/* 111:111 */       return (int)year;
/* 112:    */     }
/* 113:    */     
/* 114:    */     int getMaxYear() {
/* 115:115 */       double year = 0.0D;
/* 116:116 */       if ((S1_ != null) && (maxYear(S1_) > year)) {
/* 117:117 */         year = maxYear(S1_);
/* 118:    */       }
/* 119:119 */       if ((S2_ != null) && (maxYear(S2_) > year)) {
/* 120:120 */         year = maxYear(S2_);
/* 121:    */       }
/* 122:122 */       if ((S3_ != null) && (maxYear(S3_) > year)) {
/* 123:123 */         year = maxYear(S3_);
/* 124:    */       }
/* 125:125 */       return (int)year;
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public SIView() {
/* 130:130 */     setLayout(new BorderLayout());
/* 131:    */     
/* 132:132 */     graphs_ = new HashMap();
/* 133:    */     
/* 134:134 */     sRenderer = new XYLineAndShapeRenderer(true, false);
/* 135:135 */     sRenderer.setAutoPopulateSeriesPaint(false);
/* 136:    */     
/* 137:137 */     tRenderer = new XYLineAndShapeRenderer(true, false);
/* 138:138 */     tRenderer.setAutoPopulateSeriesPaint(false);
/* 139:    */     
/* 140:140 */     siRenderer1 = new XYLineAndShapeRenderer(false, true);
/* 141:141 */     siRenderer1.setAutoPopulateSeriesPaint(false);
/* 142:142 */     siRenderer1.setAutoPopulateSeriesShape(false);
/* 143:143 */     siRenderer1.setBaseShape(new Ellipse2D.Double(-0.1D, -0.1D, 2.0D, 2.0D));
/* 144:144 */     siRenderer1.setBaseShapesFilled(false);
/* 145:    */     
/* 146:146 */     siRenderer2 = new PreciseXYLineAndShapeRenderer(false, true);
/* 147:147 */     siRenderer2.setAutoPopulateSeriesPaint(false);
/* 148:148 */     siRenderer2.setAutoPopulateSeriesShape(false);
/* 149:149 */     siRenderer2.setBaseShape(new Ellipse2D.Double(-0.1D, -0.1D, 2.0D, 2.0D));
/* 150:150 */     siRenderer2.setBaseShapesFilled(false);
/* 151:    */     
/* 152:152 */     StandardXYToolTipGenerator generator = new StandardXYToolTipGenerator() {
/* 153:153 */       final DecimalFormat format = new DecimalFormat("0");
/* 154:    */       
/* 155:    */       public String generateToolTip(XYDataset dataset, int series, int item)
/* 156:    */       {
/* 157:157 */         for (SIView.Bornes b : graphs_.keySet()) {
/* 158:158 */           if ((dataset.getXValue(series, item) >= min_) && (dataset.getXValue(series, item) <= max_)) {
/* 159:159 */             return format.format(graphs_.get(b)).S3_.getXValue(item));
/* 160:    */           }
/* 161:    */         }
/* 162:162 */         return null;
/* 163:    */       }
/* 164:164 */     };
/* 165:165 */     siRenderer2.setBaseToolTipGenerator(generator);
/* 166:    */     
/* 167:167 */     mainchart_ = createMainChart(sRenderer, tRenderer, siRenderer2);
/* 168:168 */     detailchart_ = createDetailChart(sRenderer, tRenderer, siRenderer1);
/* 169:    */     
/* 170:170 */     chartpanel_ = new JChartPanel(null);
/* 171:171 */     chartpanel_.addComponentListener(new ComponentAdapter()
/* 172:    */     {
/* 173:    */       public void componentResized(ComponentEvent e) {
/* 174:174 */         if (chartpanel_.getChart() != null) {
/* 175:175 */           SIView.rescaleAxis((NumberAxis)chartpanel_.getChart().getXYPlot().getRangeAxis());
/* 176:    */         }
/* 177:    */       }
/* 178:178 */     });
/* 179:179 */     chartpanel_.addMouseListener(new MouseAdapter()
/* 180:    */     {
/* 181:    */       public void mouseClicked(MouseEvent e) {
/* 182:182 */         if ((e.getButton() == 1) && (e.getClickCount() == 2)) {
/* 183:183 */           double x = chartpanel_.getChartX(e.getX());
/* 184:184 */           SIView.Graphs g = null;
/* 185:185 */           SIView.Bornes fb = SIView.Bornes.ZERO;
/* 186:186 */           for (SIView.Bornes b : graphs_.keySet()) {
/* 187:187 */             if ((x >= min_) && (x <= max_)) {
/* 188:188 */               g = (SIView.Graphs)graphs_.get(b);
/* 189:189 */               fb = b;
/* 190:190 */               break;
/* 191:    */             }
/* 192:    */           }
/* 193:193 */           if (g == null) {
/* 194:194 */             return;
/* 195:    */           }
/* 196:    */           
/* 197:197 */           SIView.this.showDetail(g, fb);
/* 198:198 */         } else if (e.getButton() == 3) {
/* 199:199 */           SIView.this.showMain();
/* 200:    */         }
/* 201:    */         
/* 202:    */       }
/* 203:203 */     });
/* 204:204 */     add(chartpanel_, "Center");
/* 205:    */   }
/* 206:    */   
/* 207:    */   private void showMain() {
/* 208:208 */     chartpanel_.setChart(mainchart_);
/* 209:209 */     onColorSchemeChange();
/* 210:    */   }
/* 211:    */   
/* 212:    */   private void showDetail(Graphs g, Bornes fb) {
/* 213:213 */     XYPlot plot = detailchart_.getXYPlot();
/* 214:    */     
/* 215:    */ 
/* 216:216 */     NumberAxis yAxis = new NumberAxis();
/* 217:217 */     yAxis.setTickLabelPaint(Color.GRAY);
/* 218:218 */     rescaleAxis(yAxis);
/* 219:219 */     plot.setRangeAxis(yAxis);
/* 220:    */     
/* 221:221 */     NumberAxis xAxis = new NumberAxis();
/* 222:222 */     xAxis.setTickLabelPaint(Color.GRAY);
/* 223:223 */     xAxis.setTickUnit(new NumberTickUnit(1.0D));
/* 224:224 */     xAxis.setNumberFormatOverride(new DecimalFormat("0000"));
/* 225:225 */     xAxis.setRange(g.getMinYear() - 1, g.getMaxYear() + 1);
/* 226:226 */     plot.setDomainAxis(xAxis);
/* 227:    */     
/* 228:228 */     plot.setDataset(0, new BasicXYDataset(Collections.singletonList(S2_)));
/* 229:229 */     plot.setDataset(1, new BasicXYDataset(Collections.singletonList(S1_)));
/* 230:230 */     plot.setDataset(2, new BasicXYDataset(Collections.singletonList(S3_)));
/* 231:    */     
/* 232:232 */     detailchart_.setTitle(label_);
/* 233:233 */     chartpanel_.setChart(detailchart_);
/* 234:234 */     onColorSchemeChange();
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void setData(TsData seas) {
/* 238:238 */     reset();
/* 239:239 */     if (seas != null) {
/* 240:240 */       displayData(seas, null, null);
/* 241:    */     }
/* 242:    */   }
/* 243:    */   
/* 244:    */   public void setData(TsData seas, TsData irr, DecompositionMode mode) {
/* 245:245 */     reset();
/* 246:246 */     if ((seas == null) && (irr == null)) {
/* 247:247 */       return;
/* 248:    */     }
/* 249:249 */     if (seas == null) {
/* 250:250 */       seas = new TsData(irr.getDomain(), mode == DecompositionMode.Multiplicative ? 1 : 0);
/* 251:251 */     } else if (irr == null) {
/* 252:252 */       irr = new TsData(seas.getDomain(), mode == DecompositionMode.Multiplicative ? 1 : 0);
/* 253:    */     }
/* 254:254 */     displayData(seas, irr, mode);
/* 255:    */   }
/* 256:    */   
/* 257:    */   public void setSiData(TsData seas, TsData si)
/* 258:    */   {
/* 259:259 */     setData(seas, si, DecompositionMode.Undefined);
/* 260:    */   }
/* 261:    */   
/* 262:    */   public void reset() {
/* 263:263 */     graphs_.clear();
/* 264:264 */     chartpanel_.setChart(null);
/* 265:    */   }
/* 266:    */   
/* 267:    */   private void displayData(TsData seas, TsData irr, DecompositionMode mode) {
/* 268:268 */     TsFrequency freq = seas.getFrequency();
/* 269:269 */     if (freq == TsFrequency.Undefined) {
/* 270:270 */       return;
/* 271:    */     }
/* 272:    */     
/* 273:273 */     TsPeriod end = seas.getEnd().minus(1);
/* 274:274 */     TsPeriod start = seas.getStart();
/* 275:275 */     int np = end.getYear() - start.getYear();
/* 276:    */     
/* 277:277 */     BasicXYDataset sDataset = new BasicXYDataset();
/* 278:278 */     BasicXYDataset siDataset = new BasicXYDataset();
/* 279:279 */     BasicXYDataset tDataset = new BasicXYDataset();
/* 280:280 */     PeriodIterator speriods = new PeriodIterator(seas);
/* 281:281 */     double xstart = -0.4D;
/* 282:282 */     double xend = 0.4D;
/* 283:283 */     double xstep = 0.8D / np;
/* 284:284 */     int il = 0;
/* 285:285 */     while (speriods.hasMoreElements()) {
/* 286:286 */       int startyear = start.getYear();
/* 287:287 */       int endyear = end.getYear() - 1;
/* 288:    */       
/* 289:289 */       TsDataBlock datablock = speriods.nextElement();
/* 290:290 */       DataBlock src = data;
/* 291:    */       
/* 292:292 */       String key = "p" + Integer.toString(il);
/* 293:    */       
/* 294:294 */       int n = src.getLength();
/* 295:295 */       if (n > 0) {
/* 296:296 */         double m = src.sum() / n;
/* 297:297 */         double[] tX = { xstart, xend };
/* 298:298 */         double[] tX2 = { startyear, endyear };
/* 299:299 */         double[] tY = { m, m };
/* 300:    */         
/* 301:301 */         double[] sX = new double[n];
/* 302:302 */         double[] sX2 = new double[n];
/* 303:303 */         double[] sY = new double[n];
/* 304:304 */         double[] siY = new double[n];
/* 305:    */         
/* 306:306 */         double x = xstart + xstep * (start.getYear() - start.getYear());
/* 307:307 */         for (int i = 0; i < n; startyear++) {
/* 308:308 */           sX[i] = x;
/* 309:309 */           sX2[i] = startyear;
/* 310:310 */           sY[i] = src.get(i);
/* 311:311 */           if (irr != null) {
/* 312:312 */             int pos = irr.getDomain().search(datablock.period(i));
/* 313:313 */             switch (mode) {
/* 314:    */             case Multiplicative: 
/* 315:315 */               sY[i] *= irr.get(pos);
/* 316:316 */               break;
/* 317:    */             case LogAdditive: 
/* 318:318 */               sY[i] += irr.get(pos);
/* 319:319 */               break;
/* 320:    */             default: 
/* 321:321 */               siY[i] = irr.get(pos);
/* 322:    */             }
/* 323:    */           }
/* 324:307 */           i++;x += xstep;
/* 325:    */         }
/* 326:    */         
/* 327:    */ 
/* 328:    */ 
/* 329:    */ 
/* 330:    */ 
/* 331:    */ 
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:327 */         BasicXYDataset.Series t = BasicXYDataset.Series.of(key, tX, tY);
/* 345:328 */         BasicXYDataset.Series t2 = BasicXYDataset.Series.of(key, tX2, tY);
/* 346:    */         
/* 347:330 */         BasicXYDataset.Series s = BasicXYDataset.Series.of(key, sX, sY);
/* 348:331 */         BasicXYDataset.Series s2 = BasicXYDataset.Series.of(key, sX2, sY);
/* 349:    */         
/* 350:333 */         BasicXYDataset.Series si = irr != null ? BasicXYDataset.Series.of(key, sX, siY) : BasicXYDataset.Series.empty(key);
/* 351:334 */         BasicXYDataset.Series si2 = irr != null ? BasicXYDataset.Series.of(key, sX2, siY) : BasicXYDataset.Series.empty(key);
/* 352:    */         
/* 353:336 */         Bornes b = new Bornes(xstart, xend);
/* 354:337 */         Graphs g = new Graphs(t2, s2, si2, TsPeriod.formatPeriod(freq, il));
/* 355:338 */         graphs_.put(b, g);
/* 356:    */         
/* 357:340 */         sDataset.addSeries(s);
/* 358:341 */         tDataset.addSeries(t);
/* 359:342 */         siDataset.addSeries(si);
/* 360:    */       }
/* 361:    */       
/* 362:345 */       xstart += 1.0D;
/* 363:346 */       xend += 1.0D;
/* 364:347 */       il++;
/* 365:    */     }
/* 366:    */     
/* 367:350 */     XYPlot plot = mainchart_.getXYPlot();
/* 368:351 */     configureAxis(plot, freq);
/* 369:352 */     plot.setDataset(0, sDataset);
/* 370:353 */     plot.setDataset(1, tDataset);
/* 371:354 */     plot.setDataset(2, siDataset);
/* 372:    */     
/* 373:356 */     showMain();
/* 374:    */   }
/* 375:    */   
/* 376:    */   static void configureAxis(XYPlot plot, TsFrequency freq) {
/* 377:360 */     NumberAxis yAxis = new NumberAxis();
/* 378:361 */     yAxis.setTickLabelPaint(Color.GRAY);
/* 379:362 */     rescaleAxis(yAxis);
/* 380:363 */     plot.setRangeAxis(yAxis);
/* 381:    */     
/* 382:365 */     NumberAxis xAxis = new NumberAxis();
/* 383:366 */     xAxis.setTickLabelPaint(Color.GRAY);
/* 384:367 */     int periods = freq.intValue();
/* 385:368 */     xAxis.setTickUnit(new TsFrequencyTickUnit(freq));
/* 386:369 */     xAxis.setRange(-0.5D, periods - 0.5D);
/* 387:370 */     plot.setDomainAxis(xAxis);
/* 388:371 */     plot.setDomainGridlinesVisible(false);
/* 389:372 */     for (int i = 0; i < periods; i++) {
/* 390:373 */       ValueMarker marker = new ValueMarker(i + 0.5D);
/* 391:374 */       marker.setStroke(MARKER_STROKE);
/* 392:375 */       marker.setPaint(MARKER_PAINT);
/* 393:376 */       marker.setAlpha(0.8F);
/* 394:377 */       plot.addDomainMarker(marker);
/* 395:    */     }
/* 396:    */   }
/* 397:    */   
/* 398:    */   static void rescaleAxis(NumberAxis axis) {
/* 399:382 */     axis.setAutoRangeIncludesZero(false);
/* 400:    */   }
/* 401:    */   
/* 402:    */ 
/* 403:    */ 
/* 404:    */   public void lostOwnership(Clipboard clipboard, Transferable contents) {}
/* 405:    */   
/* 406:    */ 
/* 407:    */   protected void onTsChange()
/* 408:    */   {
/* 409:392 */     setData(m_ts != null ? m_ts.getTsData() : null);
/* 410:    */   }
/* 411:    */   
/* 412:    */   protected void onColorSchemeChange()
/* 413:    */   {
/* 414:397 */     sRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 415:398 */     tRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 416:399 */     siRenderer1.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.GRAY));
/* 417:400 */     siRenderer2.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.GRAY));
/* 418:    */     
/* 419:402 */     XYPlot mainPlot = mainchart_.getXYPlot();
/* 420:403 */     mainPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 421:404 */     mainPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 422:405 */     mainPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 423:406 */     mainchart_.setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 424:    */     
/* 425:408 */     XYPlot detailPlot = detailchart_.getXYPlot();
/* 426:409 */     detailPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 427:410 */     detailPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 428:411 */     detailPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 429:412 */     detailchart_.setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 430:    */   }
/* 431:    */   
/* 432:    */ 
/* 433:    */ 
/* 434:    */   protected void onDataFormatChange() {}
/* 435:    */   
/* 436:    */ 
/* 437:    */   static JFreeChart createMainChart(XYLineAndShapeRenderer sRenderer, XYLineAndShapeRenderer tRenderer, PreciseXYLineAndShapeRenderer siRenderer2)
/* 438:    */   {
/* 439:422 */     XYPlot plot = new XYPlot();
/* 440:    */     
/* 441:424 */     plot.setDataset(0, Charts.emptyXYDataset());
/* 442:425 */     plot.setRenderer(0, sRenderer);
/* 443:426 */     plot.mapDatasetToDomainAxis(0, 0);
/* 444:427 */     plot.mapDatasetToRangeAxis(0, 0);
/* 445:    */     
/* 446:429 */     plot.setDataset(1, Charts.emptyXYDataset());
/* 447:430 */     plot.setRenderer(1, tRenderer);
/* 448:431 */     plot.mapDatasetToDomainAxis(1, 0);
/* 449:432 */     plot.mapDatasetToRangeAxis(1, 0);
/* 450:    */     
/* 451:434 */     plot.setDataset(2, Charts.emptyXYDataset());
/* 452:435 */     plot.setRenderer(2, siRenderer2);
/* 453:436 */     plot.mapDatasetToDomainAxis(2, 0);
/* 454:437 */     plot.mapDatasetToRangeAxis(2, 0);
/* 455:438 */     plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
/* 456:    */     
/* 457:440 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, false);
/* 458:441 */     result.setPadding(TsCharts.CHART_PADDING);
/* 459:442 */     return result;
/* 460:    */   }
/* 461:    */   
/* 462:    */   static JFreeChart createDetailChart(XYLineAndShapeRenderer sRenderer, XYLineAndShapeRenderer tRenderer, XYLineAndShapeRenderer siRenderer1) {
/* 463:446 */     XYPlot plot = new XYPlot();
/* 464:    */     
/* 465:448 */     plot.setDataset(0, Charts.emptyXYDataset());
/* 466:449 */     plot.setRenderer(0, sRenderer);
/* 467:450 */     plot.mapDatasetToDomainAxis(0, 0);
/* 468:451 */     plot.mapDatasetToRangeAxis(0, 0);
/* 469:    */     
/* 470:453 */     plot.setDataset(1, Charts.emptyXYDataset());
/* 471:454 */     plot.setRenderer(1, tRenderer);
/* 472:455 */     plot.mapDatasetToDomainAxis(1, 0);
/* 473:456 */     plot.mapDatasetToRangeAxis(1, 0);
/* 474:    */     
/* 475:458 */     plot.setDataset(2, Charts.emptyXYDataset());
/* 476:459 */     plot.setRenderer(2, siRenderer1);
/* 477:460 */     plot.mapDatasetToDomainAxis(2, 0);
/* 478:461 */     plot.mapDatasetToRangeAxis(2, 0);
/* 479:    */     
/* 480:463 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, false);
/* 481:464 */     result.setPadding(TsCharts.CHART_PADDING);
/* 482:465 */     return result;
/* 483:    */   }
/* 484:    */ }
