/*  1:   */ package ec.ui.view;
/*  2:   */ 
/*  3:   */ import org.jfree.chart.axis.NumberTickUnit;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public class PiNumberTickUnit
/* 13:   */   extends NumberTickUnit
/* 14:   */ {
/* 15:   */   private static final double margin_ = 0.01D;
/* 16:   */   
/* 17:   */   public PiNumberTickUnit(double size)
/* 18:   */   {
/* 19:19 */     super(size);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String valueToString(double value)
/* 23:   */   {
/* 24:24 */     if ((value <= 3.151592653589793D) && (value >= 3.131592653589793D))
/* 25:25 */       return "PI";
/* 26:26 */     for (int i = 2; i <= 12; i++) {
/* 27:27 */       if ((value <= 3.141592653589793D / i + 0.01D) && (value >= 3.141592653589793D / i - 0.01D))
/* 28:28 */         return "PI/" + i;
/* 29:   */     }
/* 30:30 */     for (int i = 3; i <= 12; i++) {
/* 31:31 */       if ((value <= 6.283185307179586D / i + 0.01D) && (value >= 6.283185307179586D / i - 0.01D))
/* 32:32 */         return "2PI/" + i;
/* 33:   */     }
/* 34:34 */     for (int i = 2; i <= 12; i++) {
/* 35:35 */       if ((value <= 9.424777960769379D / i + 0.01D) && (value >= 9.424777960769379D / i - 0.01D))
/* 36:36 */         return "3PI/" + i;
/* 37:   */     }
/* 38:38 */     return super.valueToString(value);
/* 39:   */   }
/* 40:   */ }
