/*   1:    */ package ec.ui.view;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   5:    */ import ec.tss.html.HtmlUtil;
/*   6:    */ import ec.tss.html.implementation.HtmlRevisionsDocument;
/*   7:    */ import ec.tstoolkit.data.DescriptiveStatistics;
/*   8:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*   9:    */ import ec.tstoolkit.timeseries.analysis.DiagnosticInfo;
/*  10:    */ import ec.tstoolkit.timeseries.analysis.DiagnosticTarget;
/*  11:    */ import ec.tstoolkit.timeseries.analysis.RevisionHistory;
/*  12:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  13:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  16:    */ import ec.ui.html.JHtmlPane;
/*  17:    */ import ec.ui.interfaces.IColorSchemeAble;
/*  18:    */ import ec.util.chart.ColorScheme;
/*  19:    */ import java.awt.BasicStroke;
/*  20:    */ import java.awt.BorderLayout;
/*  21:    */ import java.awt.Color;
/*  22:    */ import java.awt.geom.Ellipse2D.Double;
/*  23:    */ import java.text.NumberFormat;
/*  24:    */ import java.text.SimpleDateFormat;
/*  25:    */ import javax.swing.JComponent;
/*  26:    */ import javax.swing.JSplitPane;
/*  27:    */ import javax.swing.text.html.StyleSheet;
/*  28:    */ import org.jfree.chart.ChartFactory;
/*  29:    */ import org.jfree.chart.JFreeChart;
/*  30:    */ import org.jfree.chart.axis.DateAxis;
/*  31:    */ import org.jfree.chart.axis.DateTickMarkPosition;
/*  32:    */ import org.jfree.chart.axis.NumberAxis;
/*  33:    */ import org.jfree.chart.labels.StandardXYToolTipGenerator;
/*  34:    */ import org.jfree.chart.plot.PlotOrientation;
/*  35:    */ import org.jfree.chart.plot.XYPlot;
/*  36:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  37:    */ import org.jfree.data.time.Day;
/*  38:    */ import org.jfree.data.time.TimeSeries;
/*  39:    */ import org.jfree.data.time.TimeSeriesCollection;
/*  40:    */ import org.slf4j.Logger;
/*  41:    */ import org.slf4j.LoggerFactory;
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ public class RevisionHistoryView
/*  48:    */   extends JComponent
/*  49:    */   implements IColorSchemeAble
/*  50:    */ {
/*  51: 51 */   private static final Logger LOGGER = LoggerFactory.getLogger(RevisionHistoryView.class);
/*  52: 52 */   private String info_ = "SA";
/*  53:    */   private RevisionHistory history_;
/*  54: 54 */   private DiagnosticTarget target_ = DiagnosticTarget.Final;
/*  55: 55 */   private DiagnosticInfo diag_ = DiagnosticInfo.RelativeDifference;
/*  56: 56 */   private int revcount_ = 12;
/*  57: 57 */   private int revlag_ = 1;
/*  58: 58 */   private int years_ = 4;
/*  59: 59 */   private int minyears_ = 5;
/*  60: 60 */   private int threshold_ = 2;
/*  61:    */   private final JChartPanel chartpanel_;
/*  62:    */   private final JHtmlPane documentpanel_;
/*  63:    */   protected final ThemeSupport themeSupport;
/*  64:    */   
/*  65:    */   public RevisionHistoryView() {
/*  66: 66 */     setLayout(new BorderLayout());
/*  67:    */     
/*  68: 68 */     themeSupport = new ThemeSupport()
/*  69:    */     {
/*  70:    */ 
/*  71:    */       protected void colorSchemeChanged() {}
/*  72:    */ 
/*  73:    */ 
/*  74: 74 */     };
/*  75: 75 */     chartpanel_ = new JChartPanel(ChartFactory.createLineChart(null, null, null, null, PlotOrientation.VERTICAL, false, false, false));
/*  76: 76 */     documentpanel_ = new JHtmlPane();
/*  77:    */     
/*  78: 78 */     StyleSheet ss = new StyleSheet();
/*  79: 79 */     ss.addRule("body {font-family: arial, verdana;}");
/*  80: 80 */     ss.addRule("body {font-size: 11;}");
/*  81: 81 */     ss.addRule("h4 {color: blue;}");
/*  82: 82 */     ss.addRule("td, th{text-align: right; margin-left: 5px; margin-right: 5 px;}");
/*  83: 83 */     ss.addRule("table {border: solid;}");
/*  84: 84 */     documentpanel_.setStyleSheet(ss);
/*  85:    */     
/*  86: 86 */     JSplitPane splitpane = NbComponents.newJSplitPane(0, chartpanel_, documentpanel_);
/*  87: 87 */     splitpane.setDividerLocation(0.5D);
/*  88: 88 */     splitpane.setResizeWeight(0.5D);
/*  89:    */     
/*  90: 90 */     add(splitpane, "Center");
/*  91: 91 */     splitpane.setResizeWeight(0.5D);
/*  92: 92 */     themeSupport.register();
/*  93:    */   }
/*  94:    */   
/*  95:    */   private void addSeries(TimeSeriesCollection chartSeries, TsData data) {
/*  96: 96 */     TimeSeries chartTs = new TimeSeries("");
/*  97: 97 */     for (int i = 0; i < data.getDomain().getLength(); i++) {
/*  98: 98 */       if (DescriptiveStatistics.isFinite(data.get(i))) {
/*  99: 99 */         Day day = new Day(data.getDomain().get(i).middle());
/* 100:100 */         chartTs.addOrUpdate(day, data.get(i));
/* 101:    */       }
/* 102:    */     }
/* 103:103 */     chartSeries.addSeries(chartTs);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private void addStart(TimeSeriesCollection chartSeries, String name, TsPeriod start) {
/* 107:107 */     TsData ts = history_.series(name, start);
/* 108:108 */     if (ts != null) {
/* 109:109 */       TimeSeries chartTs = new TimeSeries("");
/* 110:110 */       int pos = start.minus(ts.getStart());
/* 111:111 */       Day day = new Day(start.middle());
/* 112:112 */       chartTs.add(day, ts.get(pos));
/* 113:113 */       chartSeries.addSeries(chartTs);
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void showResults() {
/* 118:118 */     if (history_ == null) {
/* 119:119 */       return;
/* 120:    */     }
/* 121:    */     
/* 122:122 */     TimeSeriesCollection chartSeries = new TimeSeriesCollection();
/* 123:123 */     TsData s = history_.referenceSeries(info_);
/* 124:124 */     TsPeriodSelector selector = new TsPeriodSelector();
/* 125:125 */     int n = s.getDomain().getLength();
/* 126:126 */     int freq = s.getDomain().getFrequency().intValue();
/* 127:127 */     int l = years_ * freq + 1;
/* 128:128 */     int n0 = n - l;
/* 129:129 */     if (n0 < minyears_ * freq) {
/* 130:130 */       n0 = minyears_ * freq;
/* 131:    */     }
/* 132:132 */     if (n0 < n) {
/* 133:133 */       selector.from(s.getDomain().get(n0).firstday());
/* 134:    */     }
/* 135:135 */     addSeries(chartSeries, s.select(selector));
/* 136:136 */     TsData ps = history_.series(info_, s.getDomain().getLast().minus(s.getDomain().getFrequency().intValue()));
/* 137:137 */     addSeries(chartSeries, ps.select(selector));
/* 138:138 */     JFreeChart seriesChart = createSeriesChart(chartSeries);
/* 139:    */     
/* 140:140 */     TimeSeriesCollection startSeries = new TimeSeriesCollection();
/* 141:141 */     for (int i = n0; i < n - 1; i++) {
/* 142:142 */       addStart(startSeries, info_, s.getDomain().get(i));
/* 143:    */     }
/* 144:144 */     JFreeChart startChart = createStartChart(startSeries);
/* 145:    */     
/* 146:146 */     XYPlot plot = new XYPlot();
/* 147:147 */     plot.setDataset(0, seriesChart.getXYPlot().getDataset());
/* 148:148 */     plot.setRenderer(0, seriesChart.getXYPlot().getRenderer());
/* 149:    */     
/* 150:150 */     plot.setDataset(1, startChart.getXYPlot().getDataset());
/* 151:151 */     plot.setRenderer(1, startChart.getXYPlot().getRenderer());
/* 152:    */     
/* 153:153 */     configureAxis(plot);
/* 154:    */     
/* 155:155 */     plot.mapDatasetToDomainAxis(0, 0);
/* 156:156 */     plot.mapDatasetToRangeAxis(0, 0);
/* 157:157 */     plot.mapDatasetToDomainAxis(1, 0);
/* 158:158 */     plot.mapDatasetToRangeAxis(1, 0);
/* 159:    */     
/* 160:160 */     chartpanel_.setChart(new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, plot, false));
/* 161:    */     
/* 162:162 */     TsData rev = revisions();
/* 163:163 */     showRevisionsChart(rev);
/* 164:164 */     showRevisionsDocument(rev);
/* 165:    */   }
/* 166:    */   
/* 167:    */   private void configureAxis(XYPlot plot)
/* 168:    */   {
/* 169:169 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-yyyy");
/* 170:170 */     DateAxis dateAxis = new DateAxis();
/* 171:171 */     dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 172:172 */     dateAxis.setDateFormatOverride(sdf);
/* 173:173 */     plot.setDomainAxis(dateAxis);
/* 174:174 */     NumberAxis yaxis = new NumberAxis();
/* 175:175 */     yaxis.setAutoRangeIncludesZero(false);
/* 176:176 */     plot.setRangeAxis(yaxis);
/* 177:    */   }
/* 178:    */   
/* 179:    */   private JFreeChart createSeriesChart(TimeSeriesCollection chartSeries) {
/* 180:180 */     JFreeChart chart = ChartFactory.createXYLineChart("", "x-axis", "y-axis", chartSeries, PlotOrientation.VERTICAL, false, true, false);
/* 181:    */     
/* 182:182 */     XYPlot plot = chart.getXYPlot();
/* 183:183 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-yyyy");
/* 184:184 */     DateAxis dateAxis = new DateAxis();
/* 185:185 */     dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 186:186 */     dateAxis.setDateFormatOverride(sdf);
/* 187:187 */     plot.setDomainAxis(dateAxis);
/* 188:188 */     NumberAxis yaxis = new NumberAxis();
/* 189:189 */     yaxis.setAutoRangeIncludesZero(false);
/* 190:190 */     plot.setRangeAxis(yaxis);
/* 191:    */     
/* 192:192 */     XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer)plot.getRenderer();
/* 193:193 */     renderer.setBaseShapesVisible(false);
/* 194:194 */     renderer.setSeriesStroke(1, new BasicStroke(0.75F, 1, 1, 1.0F, new float[] { 2.0F, 3.0F }, 0.0F));
/* 195:195 */     renderer.setSeriesPaint(0, Color.RED);
/* 196:196 */     renderer.setSeriesPaint(1, Color.BLACK);
/* 197:197 */     renderer.setBaseToolTipGenerator(new StandardXYToolTipGenerator("({0}) {1}: {2}", sdf, NumberFormat.getInstance()));
/* 198:    */     
/* 199:199 */     return chart;
/* 200:    */   }
/* 201:    */   
/* 202:    */   private JFreeChart createStartChart(TimeSeriesCollection chartSeries) {
/* 203:203 */     JFreeChart chart = ChartFactory.createScatterPlot(null, null, null, chartSeries, PlotOrientation.VERTICAL, chartSeries.getSeriesCount() > 1, false, false);
/* 204:204 */     XYPlot plot = chart.getXYPlot();
/* 205:    */     
/* 206:206 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-yyyy");
/* 207:207 */     DateAxis dateAxis = new DateAxis();
/* 208:208 */     dateAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
/* 209:209 */     dateAxis.setDateFormatOverride(sdf);
/* 210:210 */     plot.setDomainAxis(dateAxis);
/* 211:211 */     NumberAxis yaxis = new NumberAxis();
/* 212:212 */     yaxis.setAutoRangeIncludesZero(false);
/* 213:213 */     plot.setRangeAxis(yaxis);
/* 214:    */     
/* 215:215 */     XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
/* 216:216 */     for (int i = 0; i < chartSeries.getSeriesCount(); i++) {
/* 217:217 */       renderer.setSeriesShape(i, new Ellipse2D.Double(-2.0D, -2.0D, 4.0D, 4.0D));
/* 218:218 */       renderer.setSeriesShapesFilled(i, false);
/* 219:219 */       renderer.setSeriesPaint(i, Color.BLUE);
/* 220:    */     }
/* 221:221 */     plot.setRenderer(renderer);
/* 222:222 */     return chart;
/* 223:    */   }
/* 224:    */   
/* 225:    */   private void showRevisionsChart(TsData s) {}
/* 226:    */   
/* 227:    */   private void showRevisionsDocument(TsData s)
/* 228:    */   {
/* 229:229 */     HtmlRevisionsDocument document = new HtmlRevisionsDocument(s, diag_);
/* 230:230 */     document.setThreshold(threshold_);
/* 231:231 */     documentpanel_.setText(HtmlUtil.toString(document));
/* 232:    */   }
/* 233:    */   
/* 234:    */   private TsData revisions() {
/* 235:235 */     TsData s = history_.referenceSeries(info_);
/* 236:236 */     int freq = s.getDomain().getFrequency().intValue();
/* 237:237 */     int l = years_ * freq + 1;
/* 238:238 */     int n0 = s.getDomain().getLength() - l;
/* 239:239 */     if (n0 < minyears_ * freq) {
/* 240:240 */       n0 = minyears_ * freq;
/* 241:    */     }
/* 242:242 */     TsPeriod start = s.getDomain().get(n0);
/* 243:243 */     TsPeriod end = s.getDomain().getLast();
/* 244:244 */     int n = end.minus(start);
/* 245:245 */     if (n <= 0) {
/* 246:246 */       return null;
/* 247:    */     }
/* 248:248 */     TsData rev = new TsData(start, n);
/* 249:249 */     for (int i = 0; i < n; i++) {
/* 250:250 */       double r = history_.seriesRevision(info_, rev.getDomain().get(i), diag_);
/* 251:251 */       if ((diag_ != DiagnosticInfo.AbsoluteDifference) && (diag_ != DiagnosticInfo.PeriodToPeriodDifference)) {
/* 252:252 */         r *= 100.0D;
/* 253:    */       }
/* 254:254 */       rev.set(i, r);
/* 255:    */     }
/* 256:256 */     return rev;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public String getInformation() {
/* 260:260 */     return info_;
/* 261:    */   }
/* 262:    */   
/* 263:    */   public void setInformation(String info) {
/* 264:264 */     info_ = info;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public void setHistory(RevisionHistory history) {
/* 268:268 */     history_ = history;
/* 269:269 */     showResults();
/* 270:    */   }
/* 271:    */   
/* 272:    */   public DiagnosticTarget getTarget() {
/* 273:273 */     return target_;
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void setTarget(DiagnosticTarget target) {
/* 277:277 */     target_ = target;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public DiagnosticInfo getDiagInfo() {
/* 281:281 */     return diag_;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public void setDiagInfo(DiagnosticInfo info) {
/* 285:285 */     diag_ = info;
/* 286:    */   }
/* 287:    */   
/* 288:    */   public int getRevisionsLag() {
/* 289:289 */     return revlag_;
/* 290:    */   }
/* 291:    */   
/* 292:    */   public void setRevisionsLag(int revlag) {
/* 293:293 */     revlag_ = revlag;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public int getRevisionsCount() {
/* 297:297 */     return revcount_;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void setRevisionsCount(int revcount) {
/* 301:301 */     revcount_ = revcount;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public int getThreshold() {
/* 305:305 */     return threshold_;
/* 306:    */   }
/* 307:    */   
/* 308:    */   public void setThreshold(int threshold) {
/* 309:309 */     threshold_ = threshold;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public int getPeriodLength() {
/* 313:313 */     return years_;
/* 314:    */   }
/* 315:    */   
/* 316:    */   public void setPeriodLenth(int years) {
/* 317:317 */     years_ = years;
/* 318:    */   }
/* 319:    */   
/* 320:    */   public ColorScheme getColorScheme()
/* 321:    */   {
/* 322:322 */     return themeSupport.getLocalColorScheme();
/* 323:    */   }
/* 324:    */   
/* 325:    */   public void setColorScheme(ColorScheme theme)
/* 326:    */   {
/* 327:327 */     themeSupport.setLocalColorScheme(theme);
/* 328:    */   }
/* 329:    */ }
