/*   1:    */ package ec.ui;
/*   2:    */ 
/*   3:    */ import ec.tss.TsCollection;
/*   4:    */ import ec.tss.TsFactory;
/*   5:    */ import ec.tstoolkit.MetaData;
/*   6:    */ import ec.tstoolkit.arima.ArimaModelBuilder;
/*   7:    */ import ec.tstoolkit.data.ReadDataBlock;
/*   8:    */ import ec.tstoolkit.design.IBuilder;
/*   9:    */ import ec.tstoolkit.random.IRandomNumberGenerator;
/*  10:    */ import ec.tstoolkit.random.XorshiftRNG;
/*  11:    */ import ec.tstoolkit.sarima.SarimaModel;
/*  12:    */ import ec.tstoolkit.sarima.SarimaSpecification;
/*  13:    */ import ec.tstoolkit.timeseries.Day;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  16:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  17:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  18:    */ import java.util.Date;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public final class DemoUtils
/*  31:    */ {
/*  32:    */   public static TsCollection randomTsCollection(int nSeries)
/*  33:    */   {
/*  34: 34 */     return randomTsCollection(nSeries, 24, new XorshiftRNG(0));
/*  35:    */   }
/*  36:    */   
/*  37:    */ 
/*  38: 38 */   public static TsCollection randomTsCollection(int nSeries, int nObs, IRandomNumberGenerator rng) { return new RandomTsCollectionBuilder().withSeries(nSeries).withObs(nObs).withRNG(rng).build(); }
/*  39:    */   
/*  40:    */   private static abstract interface RandomValuesStrategy {
/*  41:    */     public abstract double[][] getValues(int paramInt1, int paramInt2, IRandomNumberGenerator paramIRandomNumberGenerator, long paramLong);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static final class RandomTsCollectionBuilder implements IBuilder<TsCollection> { private final DemoUtils.RandomValuesStrategy strategy;
/*  45:    */     private int nSeries;
/*  46:    */     private int nObs;
/*  47:    */     private IRandomNumberGenerator rng;
/*  48:    */     private int forecastCount;
/*  49:    */     private long startTimeMillis;
/*  50:    */     private TsFrequency frequency;
/*  51:    */     
/*  52: 52 */     public RandomTsCollectionBuilder() { strategy = new DemoUtils.CustomStrategy(null);
/*  53: 53 */       nSeries = 3;
/*  54: 54 */       nObs = 24;
/*  55: 55 */       rng = new XorshiftRNG(0);
/*  56: 56 */       forecastCount = 0;
/*  57: 57 */       startTimeMillis = System.currentTimeMillis();
/*  58: 58 */       frequency = TsFrequency.Monthly;
/*  59:    */     }
/*  60:    */     
/*  61:    */     public RandomTsCollectionBuilder withSeries(int count)
/*  62:    */     {
/*  63: 63 */       nSeries = count;
/*  64: 64 */       return this;
/*  65:    */     }
/*  66:    */     
/*  67:    */     public RandomTsCollectionBuilder withObs(int count) {
/*  68: 68 */       nObs = count;
/*  69: 69 */       return this;
/*  70:    */     }
/*  71:    */     
/*  72:    */     public RandomTsCollectionBuilder withRNG(IRandomNumberGenerator rng) {
/*  73: 73 */       this.rng = rng;
/*  74: 74 */       return this;
/*  75:    */     }
/*  76:    */     
/*  77:    */     public RandomTsCollectionBuilder withForecast(int count) {
/*  78: 78 */       forecastCount = count;
/*  79: 79 */       return this;
/*  80:    */     }
/*  81:    */     
/*  82:    */     public RandomTsCollectionBuilder withStartTimeMillis(long time) {
/*  83: 83 */       startTimeMillis = time;
/*  84: 84 */       return this;
/*  85:    */     }
/*  86:    */     
/*  87:    */     public RandomTsCollectionBuilder withFrequency(TsFrequency frequency) {
/*  88: 88 */       this.frequency = frequency;
/*  89: 89 */       return this;
/*  90:    */     }
/*  91:    */     
/*  92:    */ 
/*  93:    */     public TsCollection build()
/*  94:    */     {
/*  95: 95 */       TsCollection result = TsFactory.instance.createTsCollection();
/*  96:    */       
/*  97: 97 */       TsPeriod start = new TsPeriod(frequency, new Date(startTimeMillis));
/*  98: 98 */       double[][] values = strategy.getValues(nSeries, nObs, rng, startTimeMillis);
/*  99:    */       
/* 100:100 */       for (int i = 0; i < values.length; i++) {
/* 101:101 */         TsData data = new TsData(start, values[i], false);
/* 102:102 */         MetaData meta = new MetaData();
/* 103:103 */         if (forecastCount > 0) {
/* 104:104 */           meta.put("@end", data.getDomain().get(data.getLength() - forecastCount - 1).lastday().toString());
/* 105:    */         }
/* 106:106 */         String name = "S" + i;
/* 107:107 */         result.quietAdd(TsFactory.instance.createTs(name, meta, data));
/* 108:    */       }
/* 109:    */       
/* 110:110 */       return result;
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */   private static class CustomStrategy
/* 120:    */     implements DemoUtils.RandomValuesStrategy
/* 121:    */   {
/* 122:    */     public double[][] getValues(int series, int obs, IRandomNumberGenerator rng, long startTimeMillis)
/* 123:    */     {
/* 124:124 */       double[][] result = new double[series][obs];
/* 125:125 */       for (int i = 0; i < series; i++) {
/* 126:126 */         for (int j = 0; j < obs; j++) {
/* 127:127 */           result[i][j] = Math.abs(100.0D * Math.cos(startTimeMillis * i) + 100.0D * (Math.sin(startTimeMillis) - Math.cos(rng.nextDouble()) + Math.tan(rng.nextDouble())));
/* 128:    */         }
/* 129:    */       }
/* 130:130 */       return result;
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   private static class ArimaStrategy implements DemoUtils.RandomValuesStrategy
/* 135:    */   {
/* 136:    */     final SarimaModel model;
/* 137:    */     
/* 138:    */     public ArimaStrategy() {
/* 139:139 */       SarimaSpecification spec = new SarimaSpecification(12);
/* 140:140 */       spec.setP(0);
/* 141:141 */       spec.setD(1);
/* 142:142 */       spec.setQ(1);
/* 143:143 */       spec.setBP(0);
/* 144:144 */       spec.setBD(1);
/* 145:145 */       spec.setBQ(1);
/* 146:146 */       model = new SarimaModel(spec);
/* 147:147 */       model.setParameters(new ReadDataBlock(new double[] { -0.8D, -0.6D }));
/* 148:    */     }
/* 149:    */     
/* 150:    */ 
/* 151:    */     public double[][] getValues(int series, int obs, IRandomNumberGenerator rng, long startTimeMillis)
/* 152:    */     {
/* 153:153 */       ArimaModelBuilder builder = new ArimaModelBuilder();
/* 154:154 */       builder.setRandomNumberGenerator(rng);
/* 155:    */       
/* 156:156 */       double[][] result = new double[series][];
/* 157:157 */       for (int i = 0; i < series; i++) {
/* 158:158 */         result[i] = builder.generate(model, obs);
/* 159:    */       }
/* 160:160 */       return result;
/* 161:    */     }
/* 162:    */   }
/* 163:    */ }
