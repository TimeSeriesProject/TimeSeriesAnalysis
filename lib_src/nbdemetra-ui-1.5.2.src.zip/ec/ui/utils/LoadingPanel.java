/*  1:   */ package ec.ui.utils;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import java.awt.CardLayout;
/*  5:   */ import java.awt.Font;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ import javax.swing.JLabel;
/*  8:   */ import javax.swing.JPanel;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class LoadingPanel
/* 29:   */   extends JPanel
/* 30:   */ {
/* 31:31 */   private boolean loading = false;
/* 32:   */   private final JComponent mainPanel;
/* 33:33 */   private final GlassPane loadingPanel = new GlassPane();
/* 34:34 */   private final String LOADING = "LOADING";
/* 35:35 */   private final String MAIN = "MAIN";
/* 36:   */   
/* 37:   */   public LoadingPanel(JComponent pane)
/* 38:   */   {
/* 39:39 */     setLayout(new CardLayout());
/* 40:40 */     mainPanel = pane;
/* 41:41 */     add(mainPanel, "MAIN");
/* 42:42 */     add(loadingPanel, "LOADING");
/* 43:   */   }
/* 44:   */   
/* 45:   */   public boolean isLoading() {
/* 46:46 */     return loading;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setLoading(boolean loading) {
/* 50:50 */     this.loading = loading;
/* 51:51 */     CardLayout cl = (CardLayout)getLayout();
/* 52:52 */     cl.show(this, loading ? "LOADING" : "MAIN");
/* 53:   */   }
/* 54:   */   
/* 55:   */   private class GlassPane extends JPanel
/* 56:   */   {
/* 57:   */     public GlassPane() {
/* 58:58 */       setLayout(new BorderLayout());
/* 59:59 */       JLabel label = new JLabel("Loading...", 0);
/* 60:60 */       label.setFont(label.getFont().deriveFont(16.0F));
/* 61:61 */       add(label, "Center");
/* 62:62 */       setOpaque(false);
/* 63:   */     }
/* 64:   */   }
/* 65:   */ }
