/*  1:   */ package ec.nbdemetra.ws.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.Workspace;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.awt.event.ActionListener;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public final class SaveWorkspaceAs
/* 23:   */   implements ActionListener
/* 24:   */ {
/* 25:   */   public void actionPerformed(ActionEvent e)
/* 26:   */   {
/* 27:27 */     WorkspaceFactory.getInstance().getActiveWorkspace().saveAs();
/* 28:   */   }
/* 29:   */ }
