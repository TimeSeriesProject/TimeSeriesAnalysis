/*  1:   */ package ec.nbdemetra.ws.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.ActiveViewManager;
/*  4:   */ import ec.tstoolkit.utilities.Id;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import javax.swing.AbstractAction;
/*  7:   */ import javax.swing.SwingUtilities;
/*  8:   */ import org.openide.util.Lookup;
/*  9:   */ import org.openide.util.Lookup.Result;
/* 10:   */ import org.openide.util.LookupEvent;
/* 11:   */ import org.openide.util.LookupListener;
/* 12:   */ import org.openide.util.Utilities;
/* 13:   */ import org.openide.windows.TopComponent;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public abstract class AbstractIdAction2<T extends TopComponent>
/* 17:   */   extends AbstractAction
/* 18:   */   implements LookupListener
/* 19:   */ {
/* 20:   */   protected final Lookup context;
/* 21:   */   protected Lookup.Result<Id> all;
/* 22:   */   private final Class<T> tclass;
/* 23:   */   
/* 24:   */   public AbstractIdAction2(Class<T> tclass)
/* 25:   */   {
/* 26:26 */     this.tclass = tclass;
/* 27:27 */     context = Utilities.actionsGlobalContext();
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected AbstractIdAction2(Class<T> tclass, Lookup context) {
/* 31:31 */     this.tclass = tclass;
/* 32:32 */     this.context = context;
/* 33:   */   }
/* 34:   */   
/* 35:   */   protected void init() {
/* 36:36 */     assert (SwingUtilities.isEventDispatchThread()) : "this shall be called just from AWT thread";
/* 37:   */     
/* 38:38 */     if (all == null)
/* 39:   */     {
/* 40:   */ 
/* 41:   */ 
/* 42:42 */       all = context.lookupResult(Id.class);
/* 43:43 */       all.addLookupListener(this);
/* 44:44 */       resultChanged(null);
/* 45:   */     }
/* 46:46 */     initAction();
/* 47:   */   }
/* 48:   */   
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */   protected T content()
/* 56:   */   {
/* 57:57 */     return (TopComponent)ActiveViewManager.getInstance().getLookup().lookup(tclass);
/* 58:   */   }
/* 59:   */   
/* 60:   */ 
/* 61:   */ 
/* 62:   */ 
/* 63:   */   protected abstract void initAction();
/* 64:   */   
/* 65:   */ 
/* 66:   */ 
/* 67:   */   protected abstract void process(T paramT);
/* 68:   */   
/* 69:   */ 
/* 70:   */ 
/* 71:   */   public void resultChanged(LookupEvent ev) {}
/* 72:   */   
/* 73:   */ 
/* 74:   */ 
/* 75:   */   public void actionPerformed(ActionEvent ev)
/* 76:   */   {
/* 77:77 */     init();
/* 78:78 */     T cur = content();
/* 79:79 */     if (cur != null) {
/* 80:80 */       process(cur);
/* 81:   */     }
/* 82:   */   }
/* 83:   */ }
