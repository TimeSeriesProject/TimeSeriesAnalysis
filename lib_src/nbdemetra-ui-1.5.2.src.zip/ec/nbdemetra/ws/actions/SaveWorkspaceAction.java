/*  1:   */ package ec.nbdemetra.ws.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.Workspace;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import javax.swing.AbstractAction;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public final class SaveWorkspaceAction
/* 29:   */   extends AbstractAction
/* 30:   */ {
/* 31:   */   public void actionPerformed(ActionEvent e)
/* 32:   */   {
/* 33:33 */     WorkspaceFactory.getInstance().getActiveWorkspace().save();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean isEnabled()
/* 37:   */   {
/* 38:38 */     refreshAction();
/* 39:39 */     return super.isEnabled();
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void refreshAction() {
/* 43:43 */     Workspace activeWorkspace = WorkspaceFactory.getInstance().getActiveWorkspace();
/* 44:44 */     enabled = ((activeWorkspace != null) && (activeWorkspace.isDirty()));
/* 45:   */   }
/* 46:   */ }
