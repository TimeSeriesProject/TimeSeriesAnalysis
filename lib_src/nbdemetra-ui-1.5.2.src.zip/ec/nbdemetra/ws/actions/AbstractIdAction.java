/*  1:   */ package ec.nbdemetra.ws.actions;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import javax.swing.AbstractAction;
/*  5:   */ import org.openide.util.ContextAwareAction;
/*  6:   */ import org.openide.windows.TopComponent;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public abstract class AbstractIdAction<T extends TopComponent>
/* 14:   */   extends AbstractAction
/* 15:   */   implements ContextAwareAction
/* 16:   */ {
/* 17:   */   protected final T topComponent;
/* 18:   */   
/* 19:   */   public AbstractIdAction(T topComponent)
/* 20:   */   {
/* 21:21 */     this.topComponent = topComponent;
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected T content() {
/* 25:25 */     return topComponent;
/* 26:   */   }
/* 27:   */   
/* 28:   */ 
/* 29:   */   protected abstract void initAction();
/* 30:   */   
/* 31:   */   protected abstract void process(T paramT);
/* 32:   */   
/* 33:   */   public void actionPerformed(ActionEvent ev)
/* 34:   */   {
/* 35:35 */     initAction();
/* 36:36 */     if (topComponent != null) {
/* 37:37 */       process(topComponent);
/* 38:   */     }
/* 39:   */   }
/* 40:   */ }
