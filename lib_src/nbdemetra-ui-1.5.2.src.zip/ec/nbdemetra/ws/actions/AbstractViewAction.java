/*  1:   */ package ec.nbdemetra.ws.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.ActiveViewManager;
/*  4:   */ import java.awt.event.ActionEvent;
/*  5:   */ import javax.swing.AbstractAction;
/*  6:   */ import javax.swing.Action;
/*  7:   */ import org.openide.util.ContextAwareAction;
/*  8:   */ import org.openide.util.Lookup;
/*  9:   */ import org.openide.windows.TopComponent;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public abstract class AbstractViewAction<T extends TopComponent>
/* 15:   */   extends AbstractAction
/* 16:   */   implements ContextAwareAction
/* 17:   */ {
/* 18:   */   protected final Class<T> tclass;
/* 19:   */   
/* 20:   */   private static <T extends TopComponent> T getUI(Class<T> tclass)
/* 21:   */   {
/* 22:22 */     return (TopComponent)ActiveViewManager.getInstance().getLookup().lookup(tclass);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public AbstractViewAction(Class<T> tclass)
/* 26:   */   {
/* 27:27 */     this.tclass = tclass;
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected T context() {
/* 31:31 */     return getUI(tclass);
/* 32:   */   }
/* 33:   */   
/* 34:   */   protected abstract void refreshAction();
/* 35:   */   
/* 36:   */   protected abstract void process(T paramT);
/* 37:   */   
/* 38:   */   public void actionPerformed(ActionEvent ev)
/* 39:   */   {
/* 40:40 */     T topComponent = context();
/* 41:41 */     if (topComponent != null) {
/* 42:42 */       process(topComponent);
/* 43:   */     }
/* 44:   */   }
/* 45:   */   
/* 46:   */   public Action createContextAwareInstance(Lookup lkp)
/* 47:   */   {
/* 48:48 */     refreshAction();
/* 49:49 */     return this;
/* 50:   */   }
/* 51:   */ }
