/*  1:   */ package ec.nbdemetra.ws.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  4:   */ import java.awt.event.ActionEvent;
/*  5:   */ import java.awt.event.ActionListener;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public final class OpenWorkspace
/* 23:   */   implements ActionListener
/* 24:   */ {
/* 25:   */   public void actionPerformed(ActionEvent e)
/* 26:   */   {
/* 27:27 */     WorkspaceFactory.getInstance().openWorkspace();
/* 28:   */   }
/* 29:   */ }
