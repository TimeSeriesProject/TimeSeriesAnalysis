/*   1:    */ package ec.nbdemetra.ws;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.mru.SourceId;
/*   4:    */ import ec.tss.tsproviders.DataSource;
/*   5:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*   6:    */ import ec.tstoolkit.utilities.Id;
/*   7:    */ import ec.ui.interfaces.IDisposable;
/*   8:    */ import java.lang.reflect.InvocationTargetException;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.concurrent.atomic.AtomicLong;
/*  14:    */ import javax.swing.SwingUtilities;
/*  15:    */ import org.openide.util.Exceptions;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ public class Workspace
/*  28:    */   implements IDisposable
/*  29:    */ {
/*  30: 30 */   static final AtomicLong wsId = new AtomicLong(0L);
/*  31: 31 */   static final AtomicLong curId = new AtomicLong(0L);
/*  32:    */   private SourceId id;
/*  33: 33 */   private final ProcessingContext context_ = new ProcessingContext();
/*  34: 34 */   private boolean dirty_ = false;
/*  35: 35 */   private final List<WorkspaceItem<?>> items_ = new ArrayList();
/*  36: 36 */   private final HashMap<Id, Id> defaultSpecs_ = new HashMap();
/*  37:    */   
/*  38:    */   public Workspace(DataSource source) {
/*  39: 39 */     id = new SourceId(source, "Workspace-" + Long.toString(wsId.incrementAndGet()));
/*  40: 40 */     addDefaultItems();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Workspace(DataSource source, String name) {
/*  44: 44 */     id = new SourceId(source, name);
/*  45: 45 */     addDefaultItems();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public IWorkspaceRepository getRepository() {
/*  49: 49 */     return WorkspaceFactory.getInstance().getRepository(id.getDataSource().getProviderName());
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void add(WorkspaceItem<?> item) {
/*  53: 53 */     item.setOwner(this);
/*  54: 54 */     items_.add(item);
/*  55: 55 */     if (!item.getStatus().isVolatile()) {
/*  56: 56 */       dirty_ = true;
/*  57:    */     }
/*  58:    */     
/*  59: 59 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, item.getId(), 11);
/*  60: 60 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void sort() {
/*  64: 64 */     Collections.sort(items_);
/*  65: 65 */     dirty_ = true;
/*  66: 66 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, null, 6);
/*  67: 67 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void sortFamily(Id family) {
/*  71: 71 */     Collections.sort(items_, new WorkspaceItem.InnerComparator(family));
/*  72: 72 */     dirty_ = true;
/*  73: 73 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, null, 6);
/*  74: 74 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void quietAdd(WorkspaceItem<?> item) {
/*  78: 78 */     item.setOwner(this);
/*  79: 79 */     items_.add(item);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void quietRemove(WorkspaceItem<?> item) {
/*  83: 83 */     item.setOwner(null);
/*  84: 84 */     items_.remove(item);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void remove(WorkspaceItem<?> item) {
/*  88: 88 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, item.getId(), 13);
/*  89: 89 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/*  90: 90 */     item.setOwner(null);
/*  91: 91 */     items_.remove(item);
/*  92: 92 */     dirty_ = true;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void rename(WorkspaceItem<?> item, String newName) {
/*  96: 96 */     item.setDisplayName(newName);
/*  97: 97 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, item.getId(), 17);
/*  98: 98 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public <T> WorkspaceItem<T> searchDocument(T element) {
/* 102:102 */     for (WorkspaceItem<?> item : items_) {
/* 103:103 */       if (item.getElement() == element) {
/* 104:104 */         return item;
/* 105:    */       }
/* 106:    */     }
/* 107:107 */     return null;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public WorkspaceItem<?> searchDocument(Id family, String name) {
/* 111:111 */     for (WorkspaceItem<?> item : items_) {
/* 112:112 */       if ((name.equals(item.getIdentifier())) && (family.equals(item.getFamily()))) {
/* 113:113 */         return item;
/* 114:    */       }
/* 115:    */     }
/* 116:116 */     return null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public WorkspaceItem<?> searchDocument(Id id) {
/* 120:120 */     for (WorkspaceItem<?> item : items_) {
/* 121:121 */       if (id.equals(item.getId())) {
/* 122:122 */         return item;
/* 123:    */       }
/* 124:    */     }
/* 125:125 */     return null;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public <T> WorkspaceItem<T> searchDocument(Id id, Class<T> tclass) {
/* 129:129 */     IWorkspaceItemManager<?> manager = WorkspaceFactory.getInstance().getManager(id.parent());
/* 130:130 */     if (manager == null) {
/* 131:131 */       return null;
/* 132:    */     }
/* 133:133 */     Class<?> mclass = manager.getItemClass();
/* 134:134 */     if (!tclass.isAssignableFrom(mclass)) {
/* 135:135 */       return null;
/* 136:    */     }
/* 137:137 */     for (WorkspaceItem<?> item : items_) {
/* 138:138 */       if (id.equals(item.getId())) {
/* 139:139 */         return item;
/* 140:    */       }
/* 141:    */     }
/* 142:142 */     return null;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public List<WorkspaceItem<?>> searchDocuments(Id family) {
/* 146:146 */     ArrayList<WorkspaceItem<?>> sel = new ArrayList();
/* 147:147 */     for (WorkspaceItem item : items_) {
/* 148:148 */       if (family.equals(item.getFamily())) {
/* 149:149 */         sel.add(item);
/* 150:    */       }
/* 151:    */     }
/* 152:152 */     return sel;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public <T> List<WorkspaceItem<T>> searchDocuments(Class<T> tclass) {
/* 156:156 */     ArrayList<WorkspaceItem<T>> sel = new ArrayList();
/* 157:157 */     for (WorkspaceItem item : items_) {
/* 158:158 */       IWorkspaceItemManager<?> manager = WorkspaceFactory.getInstance().getManager(item.getFamily());
/* 159:159 */       if (manager != null)
/* 160:    */       {
/* 161:    */ 
/* 162:162 */         Class<?> mclass = manager.getItemClass();
/* 163:163 */         if (tclass.isAssignableFrom(mclass))
/* 164:164 */           sel.add(item);
/* 165:    */       }
/* 166:    */     }
/* 167:167 */     return sel;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public List<WorkspaceItem<?>> searchCompatibleDocuments(Id family) {
/* 171:171 */     ArrayList<WorkspaceItem<?>> sel = new ArrayList();
/* 172:172 */     for (WorkspaceItem item : items_) {
/* 173:173 */       if (item.getFamily().startsWith(family)) {
/* 174:174 */         sel.add(item);
/* 175:    */       }
/* 176:    */     }
/* 177:177 */     return sel;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public WorkspaceItem<?> searchDocumentByName(Id family, String displayName) {
/* 181:181 */     for (WorkspaceItem<?> item : items_) {
/* 182:182 */       if ((family.equals(item.getFamily())) && (item.getDisplayName().equals(displayName))) {
/* 183:183 */         return item;
/* 184:    */       }
/* 185:    */     }
/* 186:186 */     return null;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public List<WorkspaceItem<?>> getItems() {
/* 190:190 */     return Collections.unmodifiableList(items_);
/* 191:    */   }
/* 192:    */   
/* 193:    */   public String getName() {
/* 194:194 */     return id.getLabel();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public ProcessingContext getContext() {
/* 198:198 */     return context_;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void setName(String value) {
/* 202:202 */     id = new SourceId(id.getDataSource(), value);
/* 203:203 */     dirty_ = true;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public DataSource getDataSource() {
/* 207:207 */     return id.getDataSource();
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void setDataSource(DataSource value) {
/* 211:211 */     id = new SourceId(value, id.getLabel());
/* 212:212 */     dirty_ = true;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public boolean isDirty() {
/* 216:216 */     if (dirty_) {
/* 217:217 */       return true;
/* 218:    */     }
/* 219:219 */     if (context_.isDirty()) {
/* 220:220 */       return true;
/* 221:    */     }
/* 222:222 */     for (WorkspaceItem<?> item : items_) {
/* 223:223 */       if (item.isDirty()) {
/* 224:224 */         return true;
/* 225:    */       }
/* 226:    */     }
/* 227:227 */     return false;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void resetDirty() {
/* 231:231 */     dirty_ = false;
/* 232:    */   }
/* 233:    */   
/* 234:    */   private void addDefaultItems() {
/* 235:235 */     for (IWorkspaceItemManager mgr : WorkspaceFactory.getInstance().getManagers()) {
/* 236:236 */       List<WorkspaceItem<?>> defaultItems = mgr.getDefaultItems();
/* 237:237 */       if (defaultItems != null) {
/* 238:238 */         items_.addAll(defaultItems);
/* 239:    */       }
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   public boolean setDefaultSpec(Id family, Id id) {
/* 244:244 */     if (id == null) {
/* 245:245 */       defaultSpecs_.remove(family);
/* 246:246 */       return true;
/* 247:    */     }
/* 248:248 */     if (!id.startsWith(family)) {
/* 249:249 */       return false;
/* 250:    */     }
/* 251:251 */     WorkspaceItem<?> spec = searchDocument(id);
/* 252:252 */     if (spec == null) {
/* 253:253 */       return false;
/* 254:    */     }
/* 255:255 */     if (WorkspaceFactory.getInstance().getManager(spec.getFamily()).getItemType() != IWorkspaceItemManager.ItemType.Spec) {
/* 256:256 */       return false;
/* 257:    */     }
/* 258:258 */     defaultSpecs_.put(family, id);
/* 259:259 */     return true;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public Id getDefaultSpec(Id family)
/* 263:    */   {
/* 264:264 */     return (Id)defaultSpecs_.get(family);
/* 265:    */   }
/* 266:    */   
/* 267:    */   public void loadAll() {
/* 268:268 */     for (WorkspaceItem<?> item : items_) {
/* 269:269 */       item.load();
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   public void save() {
/* 274:274 */     if (!isDirty()) {
/* 275:275 */       return;
/* 276:    */     }
/* 277:277 */     getRepository().save(this, false);
/* 278:278 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, null, 3);
/* 279:279 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/* 280:    */   }
/* 281:    */   
/* 282:    */ 
/* 283:    */ 
/* 284:    */   public void saveAs()
/* 285:    */   {
/* 286:286 */     getRepository().saveAs(this);
/* 287:287 */     WorkspaceFactory.Event ev = new WorkspaceFactory.Event(this, null, 4);
/* 288:288 */     WorkspaceFactory.getInstance().notifyEvent(ev);
/* 289:    */   }
/* 290:    */   
/* 291:    */   public boolean hasOpenItems() {
/* 292:292 */     for (WorkspaceItem<?> item : items_) {
/* 293:293 */       if (item.isOpen()) {
/* 294:294 */         return true;
/* 295:    */       }
/* 296:    */     }
/* 297:297 */     return false;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public boolean closeOpenDocuments() {
/* 301:301 */     for (final WorkspaceItem<?> item : items_) {
/* 302:302 */       if (!SwingUtilities.isEventDispatchThread()) {
/* 303:    */         try
/* 304:    */         {
/* 305:305 */           SwingUtilities.invokeAndWait(new Runnable()
/* 306:    */           {
/* 307:    */             public void run() {
/* 308:308 */               item.closeView();
/* 309:    */             }
/* 310:    */           });
/* 311:    */         } catch (InterruptedException|InvocationTargetException ex) {
/* 312:312 */           Thread.currentThread().interrupt();
/* 313:313 */           Exceptions.printStackTrace(ex);
/* 314:    */         }
/* 315:315 */       } else if (!item.closeView()) {
/* 316:316 */         return false;
/* 317:    */       }
/* 318:    */     }
/* 319:319 */     return true;
/* 320:    */   }
/* 321:    */   
/* 322:    */   public SourceId getSourceId() {
/* 323:323 */     return id;
/* 324:    */   }
/* 325:    */   
/* 326:    */   public void dispose()
/* 327:    */   {
/* 328:328 */     for (WorkspaceItem<?> item : items_) {
/* 329:329 */       item.setOwner(null);
/* 330:    */     }
/* 331:331 */     items_.clear();
/* 332:    */   }
/* 333:    */ }
