/*   1:    */ package ec.nbdemetra.ws;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Throwables;
/*   4:    */ import ec.tss.xml.IXmlConverter;
/*   5:    */ import ec.tss.xml.information.XmlInformationSet;
/*   6:    */ import ec.tstoolkit.information.InformationSetSerializable;
/*   7:    */ import ec.tstoolkit.utilities.Paths;
/*   8:    */ import java.io.File;
/*   9:    */ import javax.xml.bind.JAXBContext;
/*  10:    */ import javax.xml.bind.JAXBException;
/*  11:    */ import javax.xml.bind.Unmarshaller;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ public abstract class AbstractFileItemRepository<D>
/*  25:    */   extends AbstractWorkspaceItemRepository<D>
/*  26:    */ {
/*  27:    */   static final JAXBContext XML_INFORMATION_SET_CONTEXT;
/*  28:    */   
/*  29:    */   static
/*  30:    */   {
/*  31:    */     try
/*  32:    */     {
/*  33: 33 */       XML_INFORMATION_SET_CONTEXT = JAXBContext.newInstance(new Class[] { XmlInformationSet.class });
/*  34:    */     } catch (JAXBException ex) {
/*  35: 35 */       throw Throwables.propagate(ex);
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected String fullName(WorkspaceItem<D> item, String repo, boolean createDir) {
/*  40: 40 */     if (item.getOwner() == null) {
/*  41: 41 */       return null;
/*  42:    */     }
/*  43: 43 */     String folder = FileRepository.getRepositoryFolder(item.getOwner(), repo, createDir);
/*  44: 44 */     String sfile = Paths.concatenate(folder, item.getIdentifier());
/*  45: 45 */     sfile = Paths.addExtension(sfile, "xml");
/*  46: 46 */     return sfile;
/*  47:    */   }
/*  48:    */   
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */   public static <S, X extends IXmlConverter<S>> S loadLegacy(String sfile, Class<X> xclass)
/*  61:    */   {
/*  62: 62 */     File file = new File(sfile);
/*  63: 63 */     if (!file.exists()) {
/*  64: 64 */       return null;
/*  65:    */     }
/*  66: 66 */     if (!file.canRead()) {
/*  67: 67 */       return null;
/*  68:    */     }
/*  69:    */     try
/*  70:    */     {
/*  71: 71 */       JAXBContext context = JAXBContext.newInstance(new Class[] { xclass });
/*  72: 72 */       Unmarshaller unmarshaller = context.createUnmarshaller();
/*  73: 73 */       X x = (IXmlConverter)unmarshaller.unmarshal(file);
/*  74: 74 */       return x.create();
/*  75:    */     } catch (Exception ex) {}
/*  76: 76 */     return null;
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */   public static <X> X loadXmlLegacy(String sfile, Class<X> xclass)
/*  81:    */   {
/*  82: 82 */     File file = new File(sfile);
/*  83: 83 */     if (!file.exists()) {
/*  84: 84 */       return null;
/*  85:    */     }
/*  86: 86 */     if (!file.canRead()) {
/*  87: 87 */       return null;
/*  88:    */     }
/*  89:    */     try
/*  90:    */     {
/*  91: 91 */       JAXBContext context = JAXBContext.newInstance(new Class[] { xclass });
/*  92: 92 */       Unmarshaller unmarshaller = context.createUnmarshaller();
/*  93: 93 */       return unmarshaller.unmarshal(file);
/*  94:    */     }
/*  95:    */     catch (Exception ex) {}
/*  96: 96 */     return null;
/*  97:    */   }
/*  98:    */   
/*  99:    */ 
/* 100:    */   public static <X extends InformationSetSerializable> X loadInfo(String sfile, Class<X> xclass)
/* 101:    */   {
/* 102:102 */     File file = new File(sfile);
/* 103:103 */     if (!file.exists()) {
/* 104:104 */       return null;
/* 105:    */     }
/* 106:106 */     if (!file.canRead()) {
/* 107:107 */       return null;
/* 108:    */     }
/* 109:    */     try
/* 110:    */     {
/* 111:111 */       Unmarshaller unmarshaller = XML_INFORMATION_SET_CONTEXT.createUnmarshaller();
/* 112:112 */       XmlInformationSet x = (XmlInformationSet)unmarshaller.unmarshal(file);
/* 113:113 */       X t = (InformationSetSerializable)xclass.newInstance();
/* 114:114 */       if (!t.read(x.create())) {
/* 115:115 */         return null;
/* 116:    */       }
/* 117:117 */       return t;
/* 118:    */     } catch (JAXBException|InstantiationException|IllegalAccessException ex) {}
/* 119:119 */     return null;
/* 120:    */   }
/* 121:    */   
/* 122:    */   /* Error */
/* 123:    */   public static <T, X extends IXmlConverter<T>> boolean saveLegacy(String sfile, WorkspaceItem item, Class<X> xclass)
/* 124:    */   {
/* 125:    */     // Byte code:
/* 126:    */     //   0: new 85	java/io/File
/* 127:    */     //   3: dup
/* 128:    */     //   4: aload_0
/* 129:    */     //   5: invokespecial 87	java/io/File:<init>	(Ljava/lang/String;)V
/* 130:    */     //   8: astore_3
/* 131:    */     //   9: aconst_null
/* 132:    */     //   10: astore 4
/* 133:    */     //   12: aconst_null
/* 134:    */     //   13: astore 5
/* 135:    */     //   15: new 156	java/io/FileOutputStream
/* 136:    */     //   18: dup
/* 137:    */     //   19: aload_3
/* 138:    */     //   20: invokespecial 158	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/* 139:    */     //   23: astore 6
/* 140:    */     //   25: aconst_null
/* 141:    */     //   26: astore 7
/* 142:    */     //   28: aconst_null
/* 143:    */     //   29: astore 8
/* 144:    */     //   31: new 161	java/io/OutputStreamWriter
/* 145:    */     //   34: dup
/* 146:    */     //   35: aload 6
/* 147:    */     //   37: getstatic 163	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/* 148:    */     //   40: invokespecial 169	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
/* 149:    */     //   43: astore 9
/* 150:    */     //   45: iconst_1
/* 151:    */     //   46: anewarray 10	java/lang/Class
/* 152:    */     //   49: dup
/* 153:    */     //   50: iconst_0
/* 154:    */     //   51: aload_2
/* 155:    */     //   52: aastore
/* 156:    */     //   53: invokestatic 14	javax/xml/bind/JAXBContext:newInstance	([Ljava/lang/Class;)Ljavax/xml/bind/JAXBContext;
/* 157:    */     //   56: astore 10
/* 158:    */     //   58: aload 10
/* 159:    */     //   60: invokevirtual 172	javax/xml/bind/JAXBContext:createMarshaller	()Ljavax/xml/bind/Marshaller;
/* 160:    */     //   63: astore 11
/* 161:    */     //   65: aload 11
/* 162:    */     //   67: ldc 176
/* 163:    */     //   69: iconst_1
/* 164:    */     //   70: invokestatic 178	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
/* 165:    */     //   73: invokeinterface 184 3 0
/* 166:    */     //   78: aload_2
/* 167:    */     //   79: invokevirtual 133	java/lang/Class:newInstance	()Ljava/lang/Object;
/* 168:    */     //   82: checkcast 107	ec/tss/xml/IXmlConverter
/* 169:    */     //   85: astore 12
/* 170:    */     //   87: aload 12
/* 171:    */     //   89: aload_1
/* 172:    */     //   90: invokevirtual 190	ec/nbdemetra/ws/WorkspaceItem:getElement	()Ljava/lang/Object;
/* 173:    */     //   93: invokeinterface 193 2 0
/* 174:    */     //   98: aload 11
/* 175:    */     //   100: aload 12
/* 176:    */     //   102: aload 9
/* 177:    */     //   104: invokeinterface 197 3 0
/* 178:    */     //   109: aload_1
/* 179:    */     //   110: invokevirtual 201	ec/nbdemetra/ws/WorkspaceItem:resetDirty	()V
/* 180:    */     //   113: aload 9
/* 181:    */     //   115: invokevirtual 204	java/io/OutputStreamWriter:flush	()V
/* 182:    */     //   118: aload 9
/* 183:    */     //   120: ifnull +8 -> 128
/* 184:    */     //   123: aload 9
/* 185:    */     //   125: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 186:    */     //   128: aload 6
/* 187:    */     //   130: ifnull +8 -> 138
/* 188:    */     //   133: aload 6
/* 189:    */     //   135: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 190:    */     //   138: iconst_1
/* 191:    */     //   139: ireturn
/* 192:    */     //   140: astore 7
/* 193:    */     //   142: aload 9
/* 194:    */     //   144: ifnull +8 -> 152
/* 195:    */     //   147: aload 9
/* 196:    */     //   149: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 197:    */     //   152: aload 7
/* 198:    */     //   154: athrow
/* 199:    */     //   155: astore 8
/* 200:    */     //   157: aload 7
/* 201:    */     //   159: ifnonnull +10 -> 169
/* 202:    */     //   162: aload 8
/* 203:    */     //   164: astore 7
/* 204:    */     //   166: goto +17 -> 183
/* 205:    */     //   169: aload 7
/* 206:    */     //   171: aload 8
/* 207:    */     //   173: if_acmpeq +10 -> 183
/* 208:    */     //   176: aload 7
/* 209:    */     //   178: aload 8
/* 210:    */     //   180: invokevirtual 211	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 211:    */     //   183: aload 7
/* 212:    */     //   185: athrow
/* 213:    */     //   186: astore 4
/* 214:    */     //   188: aload 6
/* 215:    */     //   190: ifnull +8 -> 198
/* 216:    */     //   193: aload 6
/* 217:    */     //   195: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 218:    */     //   198: aload 4
/* 219:    */     //   200: athrow
/* 220:    */     //   201: astore 5
/* 221:    */     //   203: aload 4
/* 222:    */     //   205: ifnonnull +10 -> 215
/* 223:    */     //   208: aload 5
/* 224:    */     //   210: astore 4
/* 225:    */     //   212: goto +17 -> 229
/* 226:    */     //   215: aload 4
/* 227:    */     //   217: aload 5
/* 228:    */     //   219: if_acmpeq +10 -> 229
/* 229:    */     //   222: aload 4
/* 230:    */     //   224: aload 5
/* 231:    */     //   226: invokevirtual 211	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 232:    */     //   229: aload 4
/* 233:    */     //   231: athrow
/* 234:    */     //   232: astore 4
/* 235:    */     //   234: iconst_0
/* 236:    */     //   235: ireturn
/* 237:    */     // Line number table:
/* 238:    */     //   Java source line #131	-> byte code offset #0
/* 239:    */     //   Java source line #132	-> byte code offset #9
/* 240:    */     //   Java source line #132	-> byte code offset #15
/* 241:    */     //   Java source line #134	-> byte code offset #25
/* 242:    */     //   Java source line #134	-> byte code offset #31
/* 243:    */     //   Java source line #136	-> byte code offset #45
/* 244:    */     //   Java source line #137	-> byte code offset #58
/* 245:    */     //   Java source line #138	-> byte code offset #65
/* 246:    */     //   Java source line #139	-> byte code offset #78
/* 247:    */     //   Java source line #140	-> byte code offset #87
/* 248:    */     //   Java source line #141	-> byte code offset #98
/* 249:    */     //   Java source line #142	-> byte code offset #109
/* 250:    */     //   Java source line #143	-> byte code offset #113
/* 251:    */     //   Java source line #145	-> byte code offset #118
/* 252:    */     //   Java source line #146	-> byte code offset #128
/* 253:    */     //   Java source line #144	-> byte code offset #138
/* 254:    */     //   Java source line #145	-> byte code offset #142
/* 255:    */     //   Java source line #146	-> byte code offset #188
/* 256:    */     //   Java source line #147	-> byte code offset #234
/* 257:    */     // Local variable table:
/* 258:    */     //   start	length	slot	name	signature
/* 259:    */     //   0	236	0	sfile	String
/* 260:    */     //   0	236	1	item	WorkspaceItem
/* 261:    */     //   0	236	2	xclass	Class<X>
/* 262:    */     //   8	12	3	file	File
/* 263:    */     //   10	1	4	localObject1	Object
/* 264:    */     //   186	18	4	localObject2	Object
/* 265:    */     //   210	20	4	localObject3	Object
/* 266:    */     //   232	3	4	ex	Exception
/* 267:    */     //   13	1	5	localObject4	Object
/* 268:    */     //   201	24	5	localThrowable1	java.lang.Throwable
/* 269:    */     //   23	171	6	stream	java.io.FileOutputStream
/* 270:    */     //   26	1	7	localObject5	Object
/* 271:    */     //   140	18	7	localObject6	Object
/* 272:    */     //   164	20	7	localObject7	Object
/* 273:    */     //   29	1	8	localObject8	Object
/* 274:    */     //   155	24	8	localThrowable2	java.lang.Throwable
/* 275:    */     //   43	105	9	writer	java.io.OutputStreamWriter
/* 276:    */     //   56	3	10	context	JAXBContext
/* 277:    */     //   63	36	11	marshaller	javax.xml.bind.Marshaller
/* 278:    */     //   85	16	12	x	X
/* 279:    */     // Exception table:
/* 280:    */     //   from	to	target	type
/* 281:    */     //   45	118	140	finally
/* 282:    */     //   128	140	140	finally
/* 283:    */     //   31	155	155	finally
/* 284:    */     //   25	128	186	finally
/* 285:    */     //   138	186	186	finally
/* 286:    */     //   15	201	201	finally
/* 287:    */     //   9	138	232	java/lang/Exception
/* 288:    */     //   140	232	232	java/lang/Exception
/* 289:    */   }
/* 290:    */   
/* 291:    */   /* Error */
/* 292:    */   public static <T extends ec.tstoolkit.utilities.IModifiable, X extends IXmlConverter<T>> boolean saveLegacy(String sfile, T item, Class<X> xclass)
/* 293:    */   {
/* 294:    */     // Byte code:
/* 295:    */     //   0: new 85	java/io/File
/* 296:    */     //   3: dup
/* 297:    */     //   4: aload_0
/* 298:    */     //   5: invokespecial 87	java/io/File:<init>	(Ljava/lang/String;)V
/* 299:    */     //   8: astore_3
/* 300:    */     //   9: aconst_null
/* 301:    */     //   10: astore 4
/* 302:    */     //   12: aconst_null
/* 303:    */     //   13: astore 5
/* 304:    */     //   15: new 156	java/io/FileOutputStream
/* 305:    */     //   18: dup
/* 306:    */     //   19: aload_3
/* 307:    */     //   20: invokespecial 158	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/* 308:    */     //   23: astore 6
/* 309:    */     //   25: aconst_null
/* 310:    */     //   26: astore 7
/* 311:    */     //   28: aconst_null
/* 312:    */     //   29: astore 8
/* 313:    */     //   31: new 161	java/io/OutputStreamWriter
/* 314:    */     //   34: dup
/* 315:    */     //   35: aload 6
/* 316:    */     //   37: getstatic 163	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/* 317:    */     //   40: invokespecial 169	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
/* 318:    */     //   43: astore 9
/* 319:    */     //   45: iconst_1
/* 320:    */     //   46: anewarray 10	java/lang/Class
/* 321:    */     //   49: dup
/* 322:    */     //   50: iconst_0
/* 323:    */     //   51: aload_2
/* 324:    */     //   52: aastore
/* 325:    */     //   53: invokestatic 14	javax/xml/bind/JAXBContext:newInstance	([Ljava/lang/Class;)Ljavax/xml/bind/JAXBContext;
/* 326:    */     //   56: astore 10
/* 327:    */     //   58: aload 10
/* 328:    */     //   60: invokevirtual 172	javax/xml/bind/JAXBContext:createMarshaller	()Ljavax/xml/bind/Marshaller;
/* 329:    */     //   63: astore 11
/* 330:    */     //   65: aload 11
/* 331:    */     //   67: ldc 176
/* 332:    */     //   69: iconst_1
/* 333:    */     //   70: invokestatic 178	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
/* 334:    */     //   73: invokeinterface 184 3 0
/* 335:    */     //   78: aload_2
/* 336:    */     //   79: invokevirtual 133	java/lang/Class:newInstance	()Ljava/lang/Object;
/* 337:    */     //   82: checkcast 107	ec/tss/xml/IXmlConverter
/* 338:    */     //   85: astore 12
/* 339:    */     //   87: aload 12
/* 340:    */     //   89: aload_1
/* 341:    */     //   90: invokeinterface 193 2 0
/* 342:    */     //   95: aload 11
/* 343:    */     //   97: aload 12
/* 344:    */     //   99: aload 9
/* 345:    */     //   101: invokeinterface 197 3 0
/* 346:    */     //   106: aload 9
/* 347:    */     //   108: invokevirtual 204	java/io/OutputStreamWriter:flush	()V
/* 348:    */     //   111: aload_1
/* 349:    */     //   112: invokeinterface 225 1 0
/* 350:    */     //   117: aload 9
/* 351:    */     //   119: ifnull +8 -> 127
/* 352:    */     //   122: aload 9
/* 353:    */     //   124: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 354:    */     //   127: aload 6
/* 355:    */     //   129: ifnull +8 -> 137
/* 356:    */     //   132: aload 6
/* 357:    */     //   134: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 358:    */     //   137: iconst_1
/* 359:    */     //   138: ireturn
/* 360:    */     //   139: astore 7
/* 361:    */     //   141: aload 9
/* 362:    */     //   143: ifnull +8 -> 151
/* 363:    */     //   146: aload 9
/* 364:    */     //   148: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 365:    */     //   151: aload 7
/* 366:    */     //   153: athrow
/* 367:    */     //   154: astore 8
/* 368:    */     //   156: aload 7
/* 369:    */     //   158: ifnonnull +10 -> 168
/* 370:    */     //   161: aload 8
/* 371:    */     //   163: astore 7
/* 372:    */     //   165: goto +17 -> 182
/* 373:    */     //   168: aload 7
/* 374:    */     //   170: aload 8
/* 375:    */     //   172: if_acmpeq +10 -> 182
/* 376:    */     //   175: aload 7
/* 377:    */     //   177: aload 8
/* 378:    */     //   179: invokevirtual 211	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 379:    */     //   182: aload 7
/* 380:    */     //   184: athrow
/* 381:    */     //   185: astore 4
/* 382:    */     //   187: aload 6
/* 383:    */     //   189: ifnull +8 -> 197
/* 384:    */     //   192: aload 6
/* 385:    */     //   194: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 386:    */     //   197: aload 4
/* 387:    */     //   199: athrow
/* 388:    */     //   200: astore 5
/* 389:    */     //   202: aload 4
/* 390:    */     //   204: ifnonnull +10 -> 214
/* 391:    */     //   207: aload 5
/* 392:    */     //   209: astore 4
/* 393:    */     //   211: goto +17 -> 228
/* 394:    */     //   214: aload 4
/* 395:    */     //   216: aload 5
/* 396:    */     //   218: if_acmpeq +10 -> 228
/* 397:    */     //   221: aload 4
/* 398:    */     //   223: aload 5
/* 399:    */     //   225: invokevirtual 211	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 400:    */     //   228: aload 4
/* 401:    */     //   230: athrow
/* 402:    */     //   231: astore 4
/* 403:    */     //   233: iconst_0
/* 404:    */     //   234: ireturn
/* 405:    */     // Line number table:
/* 406:    */     //   Java source line #152	-> byte code offset #0
/* 407:    */     //   Java source line #153	-> byte code offset #9
/* 408:    */     //   Java source line #153	-> byte code offset #15
/* 409:    */     //   Java source line #155	-> byte code offset #25
/* 410:    */     //   Java source line #155	-> byte code offset #31
/* 411:    */     //   Java source line #157	-> byte code offset #45
/* 412:    */     //   Java source line #158	-> byte code offset #58
/* 413:    */     //   Java source line #159	-> byte code offset #65
/* 414:    */     //   Java source line #160	-> byte code offset #78
/* 415:    */     //   Java source line #161	-> byte code offset #87
/* 416:    */     //   Java source line #162	-> byte code offset #95
/* 417:    */     //   Java source line #163	-> byte code offset #106
/* 418:    */     //   Java source line #164	-> byte code offset #111
/* 419:    */     //   Java source line #166	-> byte code offset #117
/* 420:    */     //   Java source line #167	-> byte code offset #127
/* 421:    */     //   Java source line #165	-> byte code offset #137
/* 422:    */     //   Java source line #166	-> byte code offset #141
/* 423:    */     //   Java source line #167	-> byte code offset #187
/* 424:    */     //   Java source line #168	-> byte code offset #233
/* 425:    */     // Local variable table:
/* 426:    */     //   start	length	slot	name	signature
/* 427:    */     //   0	235	0	sfile	String
/* 428:    */     //   0	235	1	item	T
/* 429:    */     //   0	235	2	xclass	Class<X>
/* 430:    */     //   8	12	3	file	File
/* 431:    */     //   10	1	4	localObject1	Object
/* 432:    */     //   185	18	4	localObject2	Object
/* 433:    */     //   209	20	4	localObject3	Object
/* 434:    */     //   231	3	4	ex	Exception
/* 435:    */     //   13	1	5	localObject4	Object
/* 436:    */     //   200	24	5	localThrowable1	java.lang.Throwable
/* 437:    */     //   23	170	6	stream	java.io.FileOutputStream
/* 438:    */     //   26	1	7	localObject5	Object
/* 439:    */     //   139	18	7	localObject6	Object
/* 440:    */     //   163	20	7	localObject7	Object
/* 441:    */     //   29	1	8	localObject8	Object
/* 442:    */     //   154	24	8	localThrowable2	java.lang.Throwable
/* 443:    */     //   43	104	9	writer	java.io.OutputStreamWriter
/* 444:    */     //   56	3	10	context	JAXBContext
/* 445:    */     //   63	33	11	marshaller	javax.xml.bind.Marshaller
/* 446:    */     //   85	13	12	x	X
/* 447:    */     // Exception table:
/* 448:    */     //   from	to	target	type
/* 449:    */     //   45	117	139	finally
/* 450:    */     //   127	139	139	finally
/* 451:    */     //   31	154	154	finally
/* 452:    */     //   25	127	185	finally
/* 453:    */     //   137	185	185	finally
/* 454:    */     //   15	200	200	finally
/* 455:    */     //   9	137	231	java/lang/Exception
/* 456:    */     //   139	231	231	java/lang/Exception
/* 457:    */   }
/* 458:    */   
/* 459:    */   /* Error */
/* 460:    */   public static <T extends InformationSetSerializable> boolean saveInfo(String sfile, T item)
/* 461:    */   {
/* 462:    */     // Byte code:
/* 463:    */     //   0: new 85	java/io/File
/* 464:    */     //   3: dup
/* 465:    */     //   4: aload_0
/* 466:    */     //   5: invokespecial 87	java/io/File:<init>	(Ljava/lang/String;)V
/* 467:    */     //   8: astore_2
/* 468:    */     //   9: aconst_null
/* 469:    */     //   10: astore_3
/* 470:    */     //   11: aconst_null
/* 471:    */     //   12: astore 4
/* 472:    */     //   14: new 156	java/io/FileOutputStream
/* 473:    */     //   17: dup
/* 474:    */     //   18: aload_2
/* 475:    */     //   19: invokespecial 158	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/* 476:    */     //   22: astore 5
/* 477:    */     //   24: aconst_null
/* 478:    */     //   25: astore 6
/* 479:    */     //   27: aconst_null
/* 480:    */     //   28: astore 7
/* 481:    */     //   30: new 161	java/io/OutputStreamWriter
/* 482:    */     //   33: dup
/* 483:    */     //   34: aload 5
/* 484:    */     //   36: getstatic 163	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/* 485:    */     //   39: invokespecial 169	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
/* 486:    */     //   42: astore 8
/* 487:    */     //   44: getstatic 20	ec/nbdemetra/ws/AbstractFileItemRepository:XML_INFORMATION_SET_CONTEXT	Ljavax/xml/bind/JAXBContext;
/* 488:    */     //   47: invokevirtual 172	javax/xml/bind/JAXBContext:createMarshaller	()Ljavax/xml/bind/Marshaller;
/* 489:    */     //   50: astore 9
/* 490:    */     //   52: aload 9
/* 491:    */     //   54: ldc 176
/* 492:    */     //   56: iconst_1
/* 493:    */     //   57: invokestatic 178	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
/* 494:    */     //   60: invokeinterface 184 3 0
/* 495:    */     //   65: aload_1
/* 496:    */     //   66: iconst_0
/* 497:    */     //   67: invokeinterface 233 2 0
/* 498:    */     //   72: astore 10
/* 499:    */     //   74: aload 10
/* 500:    */     //   76: ifnonnull +25 -> 101
/* 501:    */     //   79: aload 8
/* 502:    */     //   81: ifnull +8 -> 89
/* 503:    */     //   84: aload 8
/* 504:    */     //   86: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 505:    */     //   89: aload 5
/* 506:    */     //   91: ifnull +8 -> 99
/* 507:    */     //   94: aload 5
/* 508:    */     //   96: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 509:    */     //   99: iconst_0
/* 510:    */     //   100: ireturn
/* 511:    */     //   101: new 12	ec/tss/xml/information/XmlInformationSet
/* 512:    */     //   104: dup
/* 513:    */     //   105: invokespecial 237	ec/tss/xml/information/XmlInformationSet:<init>	()V
/* 514:    */     //   108: astore 11
/* 515:    */     //   110: aload 11
/* 516:    */     //   112: aload 10
/* 517:    */     //   114: invokevirtual 238	ec/tss/xml/information/XmlInformationSet:copy	(Lec/tstoolkit/information/InformationSet;)V
/* 518:    */     //   117: aload 9
/* 519:    */     //   119: aload 11
/* 520:    */     //   121: aload 8
/* 521:    */     //   123: invokeinterface 197 3 0
/* 522:    */     //   128: aload 8
/* 523:    */     //   130: invokevirtual 204	java/io/OutputStreamWriter:flush	()V
/* 524:    */     //   133: aload 8
/* 525:    */     //   135: ifnull +8 -> 143
/* 526:    */     //   138: aload 8
/* 527:    */     //   140: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 528:    */     //   143: aload 5
/* 529:    */     //   145: ifnull +8 -> 153
/* 530:    */     //   148: aload 5
/* 531:    */     //   150: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 532:    */     //   153: iconst_1
/* 533:    */     //   154: ireturn
/* 534:    */     //   155: astore 6
/* 535:    */     //   157: aload 8
/* 536:    */     //   159: ifnull +8 -> 167
/* 537:    */     //   162: aload 8
/* 538:    */     //   164: invokevirtual 207	java/io/OutputStreamWriter:close	()V
/* 539:    */     //   167: aload 6
/* 540:    */     //   169: athrow
/* 541:    */     //   170: astore 7
/* 542:    */     //   172: aload 6
/* 543:    */     //   174: ifnonnull +10 -> 184
/* 544:    */     //   177: aload 7
/* 545:    */     //   179: astore 6
/* 546:    */     //   181: goto +17 -> 198
/* 547:    */     //   184: aload 6
/* 548:    */     //   186: aload 7
/* 549:    */     //   188: if_acmpeq +10 -> 198
/* 550:    */     //   191: aload 6
/* 551:    */     //   193: aload 7
/* 552:    */     //   195: invokevirtual 211	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 553:    */     //   198: aload 6
/* 554:    */     //   200: athrow
/* 555:    */     //   201: astore_3
/* 556:    */     //   202: aload 5
/* 557:    */     //   204: ifnull +8 -> 212
/* 558:    */     //   207: aload 5
/* 559:    */     //   209: invokevirtual 210	java/io/FileOutputStream:close	()V
/* 560:    */     //   212: aload_3
/* 561:    */     //   213: athrow
/* 562:    */     //   214: astore 4
/* 563:    */     //   216: aload_3
/* 564:    */     //   217: ifnonnull +9 -> 226
/* 565:    */     //   220: aload 4
/* 566:    */     //   222: astore_3
/* 567:    */     //   223: goto +15 -> 238
/* 568:    */     //   226: aload_3
/* 569:    */     //   227: aload 4
/* 570:    */     //   229: if_acmpeq +9 -> 238
/* 571:    */     //   232: aload_3
/* 572:    */     //   233: aload 4
/* 573:    */     //   235: invokevirtual 211	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 574:    */     //   238: aload_3
/* 575:    */     //   239: athrow
/* 576:    */     //   240: astore_3
/* 577:    */     //   241: iconst_0
/* 578:    */     //   242: ireturn
/* 579:    */     // Line number table:
/* 580:    */     //   Java source line #173	-> byte code offset #0
/* 581:    */     //   Java source line #174	-> byte code offset #9
/* 582:    */     //   Java source line #174	-> byte code offset #14
/* 583:    */     //   Java source line #176	-> byte code offset #24
/* 584:    */     //   Java source line #176	-> byte code offset #30
/* 585:    */     //   Java source line #178	-> byte code offset #44
/* 586:    */     //   Java source line #179	-> byte code offset #52
/* 587:    */     //   Java source line #180	-> byte code offset #65
/* 588:    */     //   Java source line #181	-> byte code offset #74
/* 589:    */     //   Java source line #189	-> byte code offset #79
/* 590:    */     //   Java source line #190	-> byte code offset #89
/* 591:    */     //   Java source line #182	-> byte code offset #99
/* 592:    */     //   Java source line #184	-> byte code offset #101
/* 593:    */     //   Java source line #185	-> byte code offset #110
/* 594:    */     //   Java source line #186	-> byte code offset #117
/* 595:    */     //   Java source line #187	-> byte code offset #128
/* 596:    */     //   Java source line #189	-> byte code offset #133
/* 597:    */     //   Java source line #190	-> byte code offset #143
/* 598:    */     //   Java source line #188	-> byte code offset #153
/* 599:    */     //   Java source line #189	-> byte code offset #157
/* 600:    */     //   Java source line #190	-> byte code offset #202
/* 601:    */     //   Java source line #191	-> byte code offset #241
/* 602:    */     // Local variable table:
/* 603:    */     //   start	length	slot	name	signature
/* 604:    */     //   0	243	0	sfile	String
/* 605:    */     //   0	243	1	item	T
/* 606:    */     //   8	11	2	file	File
/* 607:    */     //   10	1	3	localObject1	Object
/* 608:    */     //   201	16	3	localObject2	Object
/* 609:    */     //   222	17	3	localObject3	Object
/* 610:    */     //   240	2	3	ex	Exception
/* 611:    */     //   12	1	4	localObject4	Object
/* 612:    */     //   214	20	4	localThrowable1	java.lang.Throwable
/* 613:    */     //   22	186	5	stream	java.io.FileOutputStream
/* 614:    */     //   25	1	6	localObject5	Object
/* 615:    */     //   155	18	6	localObject6	Object
/* 616:    */     //   179	20	6	localObject7	Object
/* 617:    */     //   28	1	7	localObject8	Object
/* 618:    */     //   170	24	7	localThrowable2	java.lang.Throwable
/* 619:    */     //   42	121	8	writer	java.io.OutputStreamWriter
/* 620:    */     //   50	68	9	marshaller	javax.xml.bind.Marshaller
/* 621:    */     //   72	41	10	info	ec.tstoolkit.information.InformationSet
/* 622:    */     //   108	12	11	x	XmlInformationSet
/* 623:    */     // Exception table:
/* 624:    */     //   from	to	target	type
/* 625:    */     //   44	79	155	finally
/* 626:    */     //   89	133	155	finally
/* 627:    */     //   143	155	155	finally
/* 628:    */     //   30	170	170	finally
/* 629:    */     //   24	89	201	finally
/* 630:    */     //   99	143	201	finally
/* 631:    */     //   153	201	201	finally
/* 632:    */     //   14	214	214	finally
/* 633:    */     //   9	99	240	java/lang/Exception
/* 634:    */     //   101	153	240	java/lang/Exception
/* 635:    */     //   155	240	240	java/lang/Exception
/* 636:    */   }
/* 637:    */   
/* 638:    */   protected boolean delete(WorkspaceItem<D> doc, String repo)
/* 639:    */   {
/* 640:196 */     String sfile = fullName(doc, repo, false);
/* 641:197 */     if (sfile == null) {
/* 642:198 */       return false;
/* 643:    */     }
/* 644:200 */     File file = new File(sfile);
/* 645:201 */     if (file.exists()) {
/* 646:202 */       file.delete();
/* 647:203 */       return true;
/* 648:    */     }
/* 649:205 */     return false;
/* 650:    */   }
/* 651:    */ }
