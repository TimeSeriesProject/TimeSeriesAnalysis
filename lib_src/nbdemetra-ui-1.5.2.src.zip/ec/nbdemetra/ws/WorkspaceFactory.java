/*   1:    */ package ec.nbdemetra.ws;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Lists;
/*   4:    */ import ec.tstoolkit.utilities.Id;
/*   5:    */ import ec.tstoolkit.utilities.TreeOfIds;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.List;
/*   9:    */ import org.openide.DialogDisplayer;
/*  10:    */ import org.openide.NotifyDescriptor;
/*  11:    */ import org.openide.NotifyDescriptor.Confirmation;
/*  12:    */ import org.openide.util.Lookup;
/*  13:    */ import org.openide.util.Lookup.Result;
/*  14:    */ import org.openide.util.LookupEvent;
/*  15:    */ import org.openide.util.lookup.AbstractLookup;
/*  16:    */ import org.openide.util.lookup.InstanceContent;
/*  17:    */ 
/*  18:    */ public class WorkspaceFactory implements org.openide.util.LookupListener
/*  19:    */ {
/*  20:    */   private static final String CLOSE_MSG = "Do you want to save the changes you made to the workspace?";
/*  21:    */   public static final String WSCONTEXTPATH = "ws.common.context";
/*  22:    */   public static final String TSCONTEXTPATH = "ws.common.context.ts";
/*  23:    */   public static final String SPECIFICATIONS = "specifications";
/*  24:    */   public static final String DOCUMENTS = "documents";
/*  25:    */   public static final String TOOLS = "tools";
/*  26:    */   public static final String MULTIDOCUMENTS = "multi-documents";
/*  27:    */   private static WorkspaceFactory instance_;
/*  28:    */   private Lookup.Result<IWorkspaceItemManager> workspaceManagersLookup;
/*  29:    */   private Lookup.Result<IWorkspaceRepository> repositoryLookup;
/*  30:    */   
/*  31:    */   public void notifyEvent(Event ev)
/*  32:    */   {
/*  33: 33 */     content.set(Collections.singleton(ev), null);
/*  34:    */   }
/*  35:    */   
/*  36:    */ 
/*  37: 37 */   public void notifyEvents(Event[] ev) { content.set(Lists.newArrayList(ev), null); }
/*  38:    */   
/*  39:    */   public static final class Event {
/*  40:    */     public static final int UNDEFINED = 0;
/*  41:    */     public static final int NEW = 1;
/*  42:    */     
/*  43: 43 */     public Event(Workspace ws, Id id, int info) { workspace = ws;
/*  44: 44 */       this.id = id;
/*  45: 45 */       this.info = info;
/*  46: 46 */       source = null;
/*  47:    */     }
/*  48:    */     
/*  49:    */     public static final int OPEN = 2;
/*  50:    */     public static final int SAVE = 3;
/*  51:    */     public static final int SAVEAS = 4;
/*  52:    */     public static final int CLOSE = 5;
/*  53:    */     public static final int SORT = 6;
/*  54:    */     public static final int ADDINGITEM = 10;
/*  55:    */     public static final int ITEMADDED = 11;
/*  56:    */     public static final int OPENITEM = 12;
/*  57: 57 */     public Event(Workspace ws, Id id, int info, Object source) { workspace = ws;
/*  58: 58 */       this.id = id;
/*  59: 59 */       this.info = info;
/*  60: 60 */       this.source = source;
/*  61:    */     }
/*  62:    */     
/*  63:    */ 
/*  64:    */     public static final int REMOVINGITEM = 13;
/*  65:    */     
/*  66:    */     public static final int ITEMREMOVED = 14;
/*  67:    */     public static final int CLOSEITEM = 15;
/*  68:    */     public static final int ITEMCHANGED = 16;
/*  69:    */     public static final int ITEMRENAMED = 17;
/*  70:    */     public static final int MANAGERS_CHANGED = 99;
/*  71:    */     public final Workspace workspace;
/*  72:    */     public final Id id;
/*  73:    */     public final int info;
/*  74:    */     public final Object source;
/*  75:    */     public boolean cancelled;
/*  76:    */   }
/*  77:    */   
/*  78: 78 */   private final InstanceContent content = new InstanceContent();
/*  79:    */   private final Lookup wsLookup;
/*  80:    */   
/*  81:    */   public static synchronized WorkspaceFactory getInstance() {
/*  82: 82 */     if (instance_ == null) {
/*  83: 83 */       instance_ = new WorkspaceFactory();
/*  84: 84 */       instance_.register();
/*  85:    */     }
/*  86: 86 */     return instance_; }
/*  87:    */   
/*  88: 88 */   private final ArrayList<IWorkspaceRepository> repositories_ = new ArrayList();
/*  89: 89 */   private final List<IWorkspaceItemManager> modules_ = new ArrayList();
/*  90:    */   
/*  91:    */   private int activeRepository;
/*  92: 92 */   private int id_ = 1;
/*  93:    */   private Workspace ws_;
/*  94:    */   private TreeOfIds wsTree_;
/*  95:    */   
/*  96:    */   private WorkspaceFactory() {
/*  97: 97 */     workspaceManagersLookup = Lookup.getDefault().lookupResult(IWorkspaceItemManager.class);
/*  98: 98 */     modules_.addAll(workspaceManagersLookup.allInstances());
/*  99: 99 */     repositoryLookup = Lookup.getDefault().lookupResult(IWorkspaceRepository.class);
/* 100:100 */     for (IWorkspaceRepository fac : repositoryLookup.allInstances()) {
/* 101:101 */       fac.initialize();
/* 102:102 */       repositories_.add(fac);
/* 103:    */     }
/* 104:    */     
/* 105:105 */     wsLookup = new AbstractLookup(content);
/* 106:    */   }
/* 107:    */   
/* 108:    */   private void register() {
/* 109:109 */     workspaceManagersLookup.addLookupListener(this);
/* 110:110 */     repositoryLookup.addLookupListener(this);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Lookup getLookup() {
/* 114:114 */     return wsLookup;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public IWorkspaceItemManager<?> getManager(Id family) {
/* 118:118 */     for (IWorkspaceItemManager mgr : modules_) {
/* 119:119 */       if (mgr.getId().compareTo(family) == 0) {
/* 120:120 */         return mgr;
/* 121:    */       }
/* 122:    */     }
/* 123:123 */     return null;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public <T extends IWorkspaceItemManager> T getManager(Class<T> tclass) {
/* 127:127 */     for (IWorkspaceItemManager mgr : modules_) {
/* 128:128 */       if (mgr.getClass().equals(tclass)) {
/* 129:129 */         return mgr;
/* 130:    */       }
/* 131:    */     }
/* 132:132 */     return null;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public String getActionsPath(Id id) {
/* 136:136 */     if (id == null) {
/* 137:137 */       return null;
/* 138:    */     }
/* 139:139 */     IWorkspaceItemManager mgr = getManager(id);
/* 140:140 */     if (mgr != null) {
/* 141:141 */       String s = mgr.getActionsPath();
/* 142:142 */       if (s != null) {
/* 143:143 */         return s;
/* 144:    */       }
/* 145:145 */       return id.toString();
/* 146:    */     }
/* 147:    */     
/* 148:148 */     mgr = getManager(id.parent());
/* 149:149 */     if (mgr != null) {
/* 150:150 */       String s = mgr.getActionsPath();
/* 151:151 */       if (s != null) {
/* 152:152 */         return s + ".item";
/* 153:    */       }
/* 154:154 */       return id.toString() + ".item";
/* 155:    */     }
/* 156:    */     
/* 157:157 */     return id.toString();
/* 158:    */   }
/* 159:    */   
/* 160:    */   private String getNextWKSName() {
/* 161:161 */     return "Workspace_" + Integer.toString(id_++);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public Workspace getActiveWorkspace() {
/* 165:165 */     if (ws_ == null) {
/* 166:166 */       newWorkspace();
/* 167:    */     }
/* 168:168 */     return ws_;
/* 169:    */   }
/* 170:    */   
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */   public void setActiveWorkspace(Workspace wks, int event)
/* 216:    */   {
/* 217:217 */     if (ws_ != null) {
/* 218:218 */       closeWorkspace(false);
/* 219:    */     }
/* 220:220 */     ws_ = wks;
/* 221:221 */     ec.tstoolkit.algorithm.ProcessingContext.setActiveContext(ws_.getContext());
/* 222:222 */     if (event > 0) {
/* 223:223 */       content.set(Collections.singleton(new Event(ws_, null, event)), null);
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void newWorkspace() {
/* 228:228 */     newWorkspace(getActiveRepository());
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void newWorkspace(IWorkspaceRepository repo) {
/* 232:232 */     Workspace nws = new Workspace(repo.getDefaultDataSource(), getNextWKSName());
/* 233:233 */     nws.resetDirty();
/* 234:234 */     setActiveWorkspace(nws, 1);
/* 235:    */   }
/* 236:    */   
/* 237:    */   public boolean closeWorkspace(boolean interactive) {
/* 238:238 */     if (ws_ == null) {
/* 239:239 */       return true;
/* 240:    */     }
/* 241:241 */     if (!ws_.closeOpenDocuments()) {
/* 242:242 */       return false;
/* 243:    */     }
/* 244:244 */     if ((interactive) && (ws_.isDirty())) {
/* 245:245 */       NotifyDescriptor nd = new NotifyDescriptor.Confirmation("Do you want to save the changes you made to the workspace?", 1);
/* 246:246 */       Object notify = DialogDisplayer.getDefault().notify(nd);
/* 247:247 */       if (notify == NotifyDescriptor.YES_OPTION) {
/* 248:248 */         ws_.save();
/* 249:249 */       } else if (notify == NotifyDescriptor.CANCEL_OPTION) {
/* 250:250 */         return false;
/* 251:    */       }
/* 252:    */     }
/* 253:253 */     getActiveRepository().close(ws_);
/* 254:254 */     ws_.dispose();
/* 255:255 */     ws_ = null;
/* 256:256 */     return true;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public boolean openWorkspace() {
/* 260:260 */     return openWorkspace(getActiveRepository());
/* 261:    */   }
/* 262:    */   
/* 263:    */   public boolean openWorkspace(IWorkspaceRepository repo) {
/* 264:    */     try {
/* 265:265 */       Workspace ws = repo.open();
/* 266:266 */       if (ws == null) {
/* 267:267 */         return false;
/* 268:    */       }
/* 269:269 */       if (!closeWorkspace(true)) {
/* 270:270 */         return false;
/* 271:    */       }
/* 272:272 */       setActiveWorkspace(ws, 2);
/* 273:273 */       return true;
/* 274:    */     } catch (Exception ex) {
/* 275:275 */       newWorkspace(); }
/* 276:276 */     return true;
/* 277:    */   }
/* 278:    */   
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */   public void saveAsWorkspace() {}
/* 288:    */   
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */   public void getManagerIds(List<Id> ids)
/* 297:    */   {
/* 298:298 */     for (IWorkspaceItemManager mgr : modules_) {
/* 299:299 */       ids.add(mgr.getId());
/* 300:    */     }
/* 301:    */   }
/* 302:    */   
/* 303:    */   public List<IWorkspaceItemManager> getManagers() {
/* 304:304 */     return Collections.unmodifiableList(modules_);
/* 305:    */   }
/* 306:    */   
/* 307:    */   public void resultChanged(LookupEvent le)
/* 308:    */   {
/* 309:309 */     if (le.getSource().equals(workspaceManagersLookup)) {
/* 310:310 */       modules_.clear();
/* 311:311 */       modules_.addAll(workspaceManagersLookup.allInstances());
/* 312:312 */       wsTree_ = null;
/* 313:313 */       Event ev = new Event(null, null, 99);
/* 314:314 */       notifyEvent(ev);
/* 315:315 */     } else if (le.getSource().equals(repositoryLookup)) {
/* 316:316 */       repositories_.clear();
/* 317:317 */       for (IWorkspaceRepository fac : repositoryLookup.allInstances()) {
/* 318:318 */         fac.initialize();
/* 319:319 */         repositories_.add(fac);
/* 320:    */       }
/* 321:321 */       activeRepository = 0;
/* 322:    */     }
/* 323:    */   }
/* 324:    */   
/* 325:    */   public TreeOfIds getTree() {
/* 326:326 */     if (wsTree_ == null) {
/* 327:327 */       ArrayList<Id> items = new ArrayList();
/* 328:328 */       for (IWorkspaceItemManager mgr : modules_) {
/* 329:329 */         items.add(mgr.getId());
/* 330:    */       }
/* 331:331 */       wsTree_ = new TreeOfIds(items);
/* 332:    */     }
/* 333:333 */     return wsTree_;
/* 334:    */   }
/* 335:    */   
/* 336:    */   public List<IWorkspaceRepository> getRepositories() {
/* 337:337 */     return Collections.unmodifiableList(repositories_);
/* 338:    */   }
/* 339:    */   
/* 340:    */   public IWorkspaceRepository getActiveRepository() {
/* 341:341 */     if (activeRepository < repositories_.size()) {
/* 342:342 */       return (IWorkspaceRepository)repositories_.get(activeRepository);
/* 343:    */     }
/* 344:344 */     return null;
/* 345:    */   }
/* 346:    */   
/* 347:    */   public <D extends IWorkspaceRepository> D getRepository(Class<D> dclass)
/* 348:    */   {
/* 349:349 */     for (IWorkspaceRepository repo : repositories_) {
/* 350:350 */       if (dclass.isInstance(repo)) {
/* 351:351 */         return repo;
/* 352:    */       }
/* 353:    */     }
/* 354:354 */     return null;
/* 355:    */   }
/* 356:    */   
/* 357:    */   public IWorkspaceRepository getRepository(String name) {
/* 358:358 */     for (IWorkspaceRepository repo : repositories_) {
/* 359:359 */       if (repo.getName().equals(name)) {
/* 360:360 */         return repo;
/* 361:    */       }
/* 362:    */     }
/* 363:363 */     return null;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void setActiveRepository(int pos) {
/* 367:367 */     activeRepository = pos;
/* 368:    */   }
/* 369:    */ }
