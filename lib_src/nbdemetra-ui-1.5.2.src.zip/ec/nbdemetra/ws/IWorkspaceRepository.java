package ec.nbdemetra.ws;

import ec.tss.tsproviders.DataSource;
import java.util.Collection;

public abstract interface IWorkspaceRepository
{
  public abstract Collection<Class> getSupportedTypes();
  
  public abstract void initialize();
  
  public abstract String getName();
  
  public abstract Object getProperties();
  
  public abstract void setProperties();
  
  public abstract Workspace open();
  
  public abstract boolean saveAs(Workspace paramWorkspace);
  
  public abstract boolean load(Workspace paramWorkspace);
  
  public abstract boolean save(Workspace paramWorkspace, boolean paramBoolean);
  
  public abstract boolean delete(Workspace paramWorkspace);
  
  public abstract <D> boolean canHandleItem(Class<D> paramClass);
  
  public abstract boolean loadItem(WorkspaceItem<?> paramWorkspaceItem);
  
  public abstract boolean saveItem(WorkspaceItem<?> paramWorkspaceItem);
  
  public abstract boolean deleteItem(WorkspaceItem<?> paramWorkspaceItem);
  
  public abstract void close(Workspace paramWorkspace);
  
  public abstract DataSource getDefaultDataSource();
}
