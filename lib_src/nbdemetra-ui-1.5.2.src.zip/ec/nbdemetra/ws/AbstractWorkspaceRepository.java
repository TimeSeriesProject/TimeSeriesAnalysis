/*   1:    */ package ec.nbdemetra.ws;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.List;
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ public abstract class AbstractWorkspaceRepository
/*  16:    */   implements IWorkspaceRepository
/*  17:    */ {
/*  18: 18 */   private HashMap<Class, ArrayList<IWorkspaceItemRepository>> map_ = new HashMap();
/*  19:    */   
/*  20:    */   public <D> void register(Class<D> dclass, IWorkspaceItemRepository<D> repo) {
/*  21: 21 */     ArrayList<IWorkspaceItemRepository> list = (ArrayList)map_.get(dclass);
/*  22: 22 */     if (list == null) {
/*  23: 23 */       list = new ArrayList();
/*  24: 24 */       map_.put(dclass, list);
/*  25:    */     }
/*  26: 26 */     list.add(repo);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public <D> void unregister(Class<D> dclass) {
/*  30: 30 */     map_.remove(dclass);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public List<IWorkspaceItemRepository> getRepositories(WorkspaceItem<?> item) {
/*  34: 34 */     Class<?> mclass = WorkspaceFactory.getInstance().getManager(item.getFamily()).getItemClass();
/*  35: 35 */     return getRepositories(mclass);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public List<IWorkspaceItemRepository> getRepositories(Class dclass) {
/*  39: 39 */     return (List)map_.get(dclass);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Object getProperties()
/*  43:    */   {
/*  44: 44 */     return null;
/*  45:    */   }
/*  46:    */   
/*  47:    */ 
/*  48:    */   public void setProperties() {}
/*  49:    */   
/*  50:    */ 
/*  51:    */   public boolean save(Workspace ws, boolean force)
/*  52:    */   {
/*  53: 53 */     if (ws.getDataSource() == null)
/*  54: 54 */       return false;
/*  55: 55 */     if (!saveWorkspace(ws))
/*  56: 56 */       return false;
/*  57: 57 */     for (WorkspaceItem<?> item : ws.getItems()) {
/*  58: 58 */       if (((item.isDirty()) || ((force) && (!item.getStatus().isVolatile()))) && 
/*  59: 59 */         (!saveItem(item))) {
/*  60: 60 */         return false;
/*  61:    */       }
/*  62:    */     }
/*  63:    */     
/*  64: 64 */     return true;
/*  65:    */   }
/*  66:    */   
/*  67:    */   protected abstract boolean saveWorkspace(Workspace paramWorkspace);
/*  68:    */   
/*  69:    */   public boolean delete(Workspace ws)
/*  70:    */   {
/*  71: 71 */     for (WorkspaceItem<?> item : ws.getItems()) {
/*  72: 72 */       if (!deleteItem(item)) {
/*  73: 73 */         return false;
/*  74:    */       }
/*  75:    */     }
/*  76: 76 */     return deleteWorkspace(ws);
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */   protected abstract boolean deleteWorkspace(Workspace paramWorkspace);
/*  81:    */   
/*  82:    */ 
/*  83:    */   public void close(Workspace ws_) {}
/*  84:    */   
/*  85:    */   public boolean loadItem(WorkspaceItem<?> item)
/*  86:    */   {
/*  87: 87 */     IWorkspaceItemManager<?> manager = WorkspaceFactory.getInstance().getManager(item.getFamily());
/*  88: 88 */     if (manager == null) {
/*  89: 89 */       return false;
/*  90:    */     }
/*  91: 91 */     List<IWorkspaceItemRepository> repos = getRepositories(manager.getItemClass());
/*  92: 92 */     if (repos == null) {
/*  93: 93 */       return false;
/*  94:    */     }
/*  95: 95 */     for (IWorkspaceItemRepository repo : repos) {
/*  96: 96 */       if (repo.load(item)) {
/*  97: 97 */         return true;
/*  98:    */       }
/*  99:    */     }
/* 100:100 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean saveItem(WorkspaceItem<?> item)
/* 104:    */   {
/* 105:105 */     if (!item.getStatus().canBeSaved()) {
/* 106:106 */       return true;
/* 107:    */     }
/* 108:108 */     List<IWorkspaceItemRepository> repos = getRepositories(item);
/* 109:109 */     if (repos == null) {
/* 110:110 */       return true;
/* 111:    */     }
/* 112:112 */     for (IWorkspaceItemRepository repo : repos) {
/* 113:113 */       if (repo.save(item)) {
/* 114:114 */         return true;
/* 115:    */       }
/* 116:    */     }
/* 117:117 */     return false;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean deleteItem(WorkspaceItem<?> item)
/* 121:    */   {
/* 122:122 */     if (!item.getStatus().hasStorage()) {
/* 123:123 */       return true;
/* 124:    */     }
/* 125:125 */     List<IWorkspaceItemRepository> repos = getRepositories(item);
/* 126:126 */     if (repos == null) {
/* 127:127 */       return true;
/* 128:    */     }
/* 129:129 */     for (IWorkspaceItemRepository repo : repos) {
/* 130:130 */       if (repo.delete(item)) {
/* 131:131 */         return true;
/* 132:    */       }
/* 133:    */     }
/* 134:134 */     return false;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public <D> boolean canHandleItem(Class<D> dclass)
/* 138:    */   {
/* 139:139 */     return map_.containsKey(dclass);
/* 140:    */   }
/* 141:    */ }
