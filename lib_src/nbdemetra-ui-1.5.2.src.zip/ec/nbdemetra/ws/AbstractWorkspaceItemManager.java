/*  1:   */ package ec.nbdemetra.ws;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import javax.swing.Icon;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public abstract class AbstractWorkspaceItemManager<D>
/* 13:   */   implements IWorkspaceItemManager<D>
/* 14:   */ {
/* 15:   */   protected abstract String getItemPrefix();
/* 16:   */   
/* 17:   */   protected boolean isUsed(String name)
/* 18:   */   {
/* 19:19 */     if (WorkspaceFactory.getInstance().getActiveWorkspace().searchDocument(getId(), name) != null) {
/* 20:20 */       return true;
/* 21:   */     }
/* 22:22 */     return false;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getNextItemName() {
/* 26:26 */     return getNextItemName(null);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getNextItemName(String pname)
/* 30:   */   {
/* 31:31 */     String name = pname;
/* 32:32 */     int id = 1;
/* 33:33 */     while ((name == null) || (isUsed(name))) {
/* 34:34 */       StringBuilder builder = new StringBuilder();
/* 35:35 */       builder.append(getItemPrefix());
/* 36:36 */       builder.append("-").append(id++);
/* 37:37 */       name = builder.toString();
/* 38:   */     }
/* 39:39 */     return name;
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected abstract D createNewObject();
/* 43:   */   
/* 44:   */   public WorkspaceItem<D> create(Workspace ws)
/* 45:   */   {
/* 46:46 */     D newObject = createNewObject();
/* 47:47 */     if (newObject == null)
/* 48:48 */       return null;
/* 49:49 */     WorkspaceItem<D> item = WorkspaceItem.newItem(getId(), getNextItemName(), newObject);
/* 50:50 */     if (ws != null) {
/* 51:51 */       ws.add(item);
/* 52:   */     }
/* 53:53 */     return item;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public List<WorkspaceItem<D>> getDefaultItems()
/* 57:   */   {
/* 58:58 */     return null;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public Icon getItemIcon(WorkspaceItem<D> doc)
/* 62:   */   {
/* 63:63 */     return getManagerIcon();
/* 64:   */   }
/* 65:   */   
/* 66:   */   public Icon getManagerIcon()
/* 67:   */   {
/* 68:68 */     return null;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public boolean isAutoLoad()
/* 72:   */   {
/* 73:73 */     return false;
/* 74:   */   }
/* 75:   */   
/* 76:   */   protected void cloneItem(WorkspaceItem<D> doc) {}
/* 77:   */ }
