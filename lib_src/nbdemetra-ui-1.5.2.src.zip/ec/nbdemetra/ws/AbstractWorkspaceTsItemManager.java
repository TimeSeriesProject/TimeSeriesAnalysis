/*  1:   */ package ec.nbdemetra.ws;
/*  2:   */ 
/*  3:   */ import ec.tss.documents.TsDocument;
/*  4:   */ import ec.tstoolkit.algorithm.IProcSpecification;
/*  5:   */ import ec.tstoolkit.utilities.Id;
/*  6:   */ import java.awt.event.ActionEvent;
/*  7:   */ import javax.swing.AbstractAction;
/*  8:   */ import javax.swing.Action;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public abstract class AbstractWorkspaceTsItemManager<S extends IProcSpecification, D extends TsDocument<S, ?>>
/* 18:   */   extends AbstractWorkspaceItemManager<D>
/* 19:   */ {
/* 20:   */   public Action getPreferredItemAction(final Id child)
/* 21:   */   {
/* 22:22 */     new AbstractAction()
/* 23:   */     {
/* 24:   */       public void actionPerformed(ActionEvent e)
/* 25:   */       {
/* 26:26 */         WorkspaceItem<D> doc = WorkspaceFactory.getInstance().getActiveWorkspace().searchDocument(child);
/* 27:27 */         if (doc != null) {
/* 28:28 */           openDocument(doc);
/* 29:   */         }
/* 30:   */       }
/* 31:   */     };
/* 32:   */   }
/* 33:   */   
/* 34:   */   public abstract void openDocument(WorkspaceItem<D> paramWorkspaceItem);
/* 35:   */   
/* 36:   */   public WorkspaceItem<D> create(Workspace ws)
/* 37:   */   {
/* 38:38 */     return super.create(ws);
/* 39:   */   }
/* 40:   */ }
