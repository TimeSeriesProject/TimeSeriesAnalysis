package ec.nbdemetra.ws;

public abstract interface IWorkspaceItemRepository<D>
{
  public abstract Class<D> getSupportedType();
  
  public abstract boolean load(WorkspaceItem<D> paramWorkspaceItem);
  
  public abstract boolean save(WorkspaceItem<D> paramWorkspaceItem);
  
  public abstract boolean delete(WorkspaceItem<D> paramWorkspaceItem);
}
