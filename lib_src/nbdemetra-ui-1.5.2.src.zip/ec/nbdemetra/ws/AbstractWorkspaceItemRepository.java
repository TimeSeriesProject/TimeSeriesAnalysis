/*  1:   */ package ec.nbdemetra.ws;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ public abstract class AbstractWorkspaceItemRepository<D>
/* 11:   */   implements IWorkspaceItemRepository<D>
/* 12:   */ {
/* 13:   */   public boolean load(WorkspaceItem<D> item)
/* 14:   */   {
/* 15:15 */     return false;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean save(WorkspaceItem<D> item)
/* 19:   */   {
/* 20:20 */     return false;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean delete(WorkspaceItem<D> doc)
/* 24:   */   {
/* 25:25 */     return false;
/* 26:   */   }
/* 27:   */ }
