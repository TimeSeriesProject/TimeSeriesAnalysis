/*   1:    */ package ec.nbdemetra.ws.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import com.google.common.base.Predicate;
/*   5:    */ import com.google.common.base.Predicates;
/*   6:    */ import com.google.common.collect.FluentIterable;
/*   7:    */ import ec.nbdemetra.ui.awt.IDialogDescriptorProvider;
/*   8:    */ import ec.nbdemetra.ui.awt.JComponent2;
/*   9:    */ import ec.nbdemetra.ui.awt.JProperty;
/*  10:    */ import ec.nbdemetra.ui.calendars.CustomDialogDescriptor;
/*  11:    */ import ec.nbdemetra.ui.nodes.DecoratedNode;
/*  12:    */ import ec.nbdemetra.ui.nodes.DecoratedNode.PreferredAction;
/*  13:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  14:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*  15:    */ import ec.nbdemetra.ws.WorkspaceItem.Status;
/*  16:    */ import ec.nbdemetra.ws.nodes.DummyWsNode;
/*  17:    */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*  18:    */ import ec.satoolkit.ISaSpecification;
/*  19:    */ import ec.tss.tsproviders.utils.IConstraint;
/*  20:    */ import ec.tstoolkit.utilities.Id;
/*  21:    */ import ec.tstoolkit.utilities.LinearId;
/*  22:    */ import java.awt.BorderLayout;
/*  23:    */ import java.awt.Dimension;
/*  24:    */ import java.awt.Image;
/*  25:    */ import java.beans.PropertyChangeEvent;
/*  26:    */ import java.beans.PropertyChangeListener;
/*  27:    */ import java.beans.PropertyVetoException;
/*  28:    */ import java.beans.VetoableChangeListener;
/*  29:    */ import org.openide.DialogDescriptor;
/*  30:    */ import org.openide.explorer.ExplorerManager;
/*  31:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  32:    */ import org.openide.explorer.view.BeanTreeView;
/*  33:    */ import org.openide.nodes.Node;
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ public class SpecSelectionComponent
/*  53:    */   extends JComponent2
/*  54:    */   implements ExplorerManager.Provider, IDialogDescriptorProvider
/*  55:    */ {
/*  56: 56 */   public static final Id SPECS_ID = new LinearId("Seasonal adjustment", "specifications");
/*  57:    */   
/*  58:    */   public static final String SPECIFICATION_PROPERTY = "specification";
/*  59:    */   public static final String ICON_PROPERTY = "icon";
/*  60:    */   private final BeanTreeView tree;
/*  61:    */   private final ExplorerManager em;
/*  62:    */   private final SelectionListener selectionListener;
/*  63:    */   private final JProperty<ISaSpecification> specification;
/*  64:    */   private final JProperty<Image> icon;
/*  65:    */   
/*  66:    */   public SpecSelectionComponent()
/*  67:    */   {
/*  68: 68 */     this(false);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public SpecSelectionComponent(boolean showSystemOnly) {
/*  72: 72 */     tree = new BeanTreeView();
/*  73: 73 */     em = new ExplorerManager();
/*  74: 74 */     selectionListener = new SelectionListener();
/*  75: 75 */     specification = newProperty("specification", null);
/*  76: 76 */     icon = newProperty("icon", null);
/*  77:    */     
/*  78: 78 */     tree.setRootVisible(false);
/*  79: 79 */     tree.setSelectionMode(1);
/*  80:    */     
/*  81: 81 */     DecoratedNode root = new DecoratedNode(new DummyWsNode(WorkspaceFactory.getInstance().getActiveWorkspace(), SPECS_ID), showSystemOnly ? ItemWsNodeFilter.SYSTEM_ONLY : Predicates.alwaysTrue());
/*  82: 82 */     for (DecoratedNode o : root.breadthFirstIterable()) {
/*  83: 83 */       o.setPreferredActionDecorator(DecoratedNode.PreferredAction.DO_NOTHING);
/*  84:    */     }
/*  85:    */     
/*  86: 86 */     em.setRootContext(root);
/*  87:    */     
/*  88: 88 */     setLayout(new BorderLayout());
/*  89: 89 */     add(tree, "Center");
/*  90: 90 */     setPreferredSize(new Dimension(225, 300));
/*  91:    */     
/*  92: 92 */     em.addVetoableChangeListener(selectionListener);
/*  93: 93 */     addPropertyChangeListener(new PropertyChangeListener()
/*  94:    */     {
/*  95:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  96: 96 */         String p = evt.getPropertyName();
/*  97: 97 */         if (p.equals("specification")) {
/*  98: 98 */           onSpecificationChange();
/*  99:    */         }
/* 100:    */       }
/* 101:    */     });
/* 102:    */   }
/* 103:    */   
/* 104:    */   boolean isCurrentSpecificationNode(Node o) {
/* 105:105 */     return ((o instanceof ItemWsNode)) && (((ItemWsNode)o).getItem().getElement().equals(specification.get()));
/* 106:    */   }
/* 107:    */   
/* 108:    */   class SelectionListener implements VetoableChangeListener
/* 109:    */   {
/* 110:110 */     boolean enable = true;
/* 111:    */     
/* 112:    */     SelectionListener() {}
/* 113:    */     
/* 114:114 */     public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException { if ((enable) && ("selectedNodes".equals(evt.getPropertyName()))) {
/* 115:115 */         Node[] nodes = (Node[])evt.getNewValue();
/* 116:116 */         if ((nodes.length > 0) && ((((DecoratedNode)nodes[0]).getOriginal() instanceof ItemWsNode))) {
/* 117:117 */           ItemWsNode node = (ItemWsNode)((DecoratedNode)nodes[0]).getOriginal();
/* 118:118 */           setSpecification((ISaSpecification)node.getItem().getElement());
/* 119:119 */           setIcon(node.getIcon(1));
/* 120:    */         } else {
/* 121:121 */           setSpecification(null);
/* 122:122 */           setIcon(null);
/* 123:    */         }
/* 124:    */       }
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   protected void onSpecificationChange() {
/* 129:129 */     selectionListener.enable = false;
/* 130:    */     
/* 131:    */ 
/* 132:    */ 
/* 133:133 */     DecoratedNode root = (DecoratedNode)em.getRootContext();
/* 134:134 */     Optional<DecoratedNode> node = root.breadthFirstIterable().firstMatch(new Predicate()
/* 135:    */     {
/* 136:    */       public boolean apply(DecoratedNode input) {
/* 137:137 */         return isCurrentSpecificationNode(input.getOriginal());
/* 138:    */       }
/* 139:    */     });
/* 140:140 */     if (node.isPresent()) {
/* 141:    */       try
/* 142:    */       {
/* 143:143 */         em.setSelectedNodes(new Node[] { (Node)node.get() });
/* 144:    */       }
/* 145:    */       catch (PropertyVetoException localPropertyVetoException) {}
/* 146:    */     }
/* 147:    */     
/* 148:148 */     selectionListener.enable = true;
/* 149:    */   }
/* 150:    */   
/* 151:    */ 
/* 152:    */   public ExplorerManager getExplorerManager()
/* 153:    */   {
/* 154:154 */     return em;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public ISaSpecification getSpecification() {
/* 158:158 */     return (ISaSpecification)specification.get();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void setSpecification(ISaSpecification specification) {
/* 162:162 */     this.specification.set(specification);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public Image getIcon() {
/* 166:166 */     return (Image)icon.get();
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void setIcon(Image icon) {
/* 170:170 */     this.icon.set(icon);
/* 171:    */   }
/* 172:    */   
/* 173:    */ 
/* 174:    */   public DialogDescriptor createDialogDescriptor(String title)
/* 175:    */   {
/* 176:176 */     return new SpecSelectionDialogDescriptor(this, title);
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static class SpecSelectionDialogDescriptor extends CustomDialogDescriptor<SpecSelectionComponent>
/* 180:    */   {
/* 181:    */     SpecSelectionDialogDescriptor(SpecSelectionComponent p, String title) {
/* 182:182 */       super(title, p);
/* 183:183 */       validate(SpecSelectionComponent.SpecSelectionConstraints.values());
/* 184:    */     }
/* 185:    */     
/* 186:    */     public void propertyChange(PropertyChangeEvent evt)
/* 187:    */     {
/* 188:188 */       String p = evt.getPropertyName();
/* 189:189 */       if (p.equals("specification")) {
/* 190:190 */         validate(SpecSelectionComponent.SpecSelectionConstraints.values());
/* 191:    */       }
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   private static enum SpecSelectionConstraints implements IConstraint<SpecSelectionComponent>
/* 196:    */   {
/* 197:197 */     SELECTION;
/* 198:    */     
/* 199:    */     public String check(SpecSelectionComponent t)
/* 200:    */     {
/* 201:201 */       return t.getSpecification() == null ? "Specification not selected" : null;
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   private static enum ItemWsNodeFilter implements Predicate<Node>
/* 206:    */   {
/* 207:207 */     SYSTEM_ONLY;
/* 208:    */     
/* 209:    */     public boolean apply(Node input)
/* 210:    */     {
/* 211:211 */       return (!(input instanceof ItemWsNode)) || 
/* 212:212 */         (((ItemWsNode)input).getItem().getStatus() == WorkspaceItem.Status.System);
/* 213:    */     }
/* 214:    */   }
/* 215:    */ }
