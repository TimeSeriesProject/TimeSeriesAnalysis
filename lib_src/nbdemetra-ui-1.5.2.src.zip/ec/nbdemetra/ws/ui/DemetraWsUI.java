/*   1:    */ package ec.nbdemetra.ws.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.mru.MruList;
/*   4:    */ import ec.nbdemetra.ws.Workspace;
/*   5:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   6:    */ import ec.nbdemetra.ws.WorkspaceFactory.Event;
/*   7:    */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*   8:    */ import ec.nbdemetra.ws.nodes.WsNode;
/*   9:    */ import ec.nbdemetra.ws.nodes.WsRootNode;
/*  10:    */ import ec.tstoolkit.utilities.Id;
/*  11:    */ import java.awt.BorderLayout;
/*  12:    */ import java.util.Properties;
/*  13:    */ import javax.swing.JScrollPane;
/*  14:    */ import org.openide.explorer.ExplorerManager;
/*  15:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  16:    */ import org.openide.explorer.view.BeanTreeView;
/*  17:    */ import org.openide.nodes.AbstractNode;
/*  18:    */ import org.openide.nodes.Children;
/*  19:    */ import org.openide.nodes.Node;
/*  20:    */ import org.openide.util.Lookup.Result;
/*  21:    */ import org.openide.util.LookupEvent;
/*  22:    */ import org.openide.util.LookupListener;
/*  23:    */ import org.openide.util.lookup.InstanceContent;
/*  24:    */ import org.openide.windows.TopComponent;
/*  25:    */ import org.openide.windows.TopComponent.Description;
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ @TopComponent.Description(preferredID="WorkspaceTopComponent", iconBase="ec/nbdemetra/ui/table.png", persistenceType=0)
/*  71:    */ public class DemetraWsUI
/*  72:    */   extends TopComponent
/*  73:    */   implements ExplorerManager.Provider, LookupListener
/*  74:    */ {
/*  75:    */   private final ExplorerManager mgr;
/*  76:    */   private final InstanceContent content;
/*  77:    */   private Lookup.Result<WorkspaceFactory.Event> result;
/*  78:    */   private JScrollPane jScrollPane1;
/*  79:    */   
/*  80:    */   private void initComponents()
/*  81:    */   {
/*  82: 82 */     BeanTreeView tree = new BeanTreeView();
/*  83: 83 */     jScrollPane1 = tree;
/*  84:    */     
/*  85: 85 */     setLayout(new BorderLayout());
/*  86: 86 */     add(jScrollPane1, "Center");
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   public void componentOpened()
/*  93:    */   {
/*  94: 94 */     result.addLookupListener(this);
/*  95:    */     
/*  96: 96 */     mgr.setRootContext(new WsRootNode(WorkspaceFactory.getInstance().getActiveWorkspace()));
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void componentClosed()
/* 100:    */   {
/* 101:101 */     mgr.setRootContext(new AbstractNode(Children.LEAF));
/* 102:    */   }
/* 103:    */   
/* 104:    */ 
/* 105:    */   void writeProperties(Properties p)
/* 106:    */   {
/* 107:107 */     p.setProperty("version", "1.0");
/* 108:    */   }
/* 109:    */   
/* 110:    */   void readProperties(Properties p)
/* 111:    */   {
/* 112:112 */     String version = p.getProperty("version");
/* 113:    */   }
/* 114:    */   
/* 115:    */ 
/* 116:    */   public ExplorerManager getExplorerManager()
/* 117:    */   {
/* 118:118 */     return mgr;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void resultChanged(LookupEvent le)
/* 122:    */   {
/* 123:123 */     for (WorkspaceFactory.Event ev : result.allInstances()) {
/* 124:124 */       switch (info) {
/* 125:    */       case 1: 
/* 126:126 */         processNew(ev);
/* 127:127 */         break;
/* 128:    */       case 2: 
/* 129:129 */         processOpen(ev);
/* 130:130 */         break;
/* 131:    */       case 3: 
/* 132:132 */         processSave(ev);
/* 133:133 */         break;
/* 134:    */       case 4: 
/* 135:135 */         processSaveAs(ev);
/* 136:136 */         break;
/* 137:    */       case 11: 
/* 138:138 */         processItemAdded(ev);
/* 139:139 */         break;
/* 140:    */       case 13: 
/* 141:141 */         processRemovingItem(ev);
/* 142:142 */         break;
/* 143:    */       case 17: 
/* 144:144 */         refreshItem(id);
/* 145:145 */         break;
/* 146:    */       case 5: case 6: case 7: case 8: case 9: case 10: case 12: case 14: case 15: case 16: default: 
/* 147:147 */         mgr.setRootContext(new WsRootNode(WorkspaceFactory.getInstance().getActiveWorkspace()));
/* 148:    */       }
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   private void refreshItem(Id id)
/* 153:    */   {
/* 154:154 */     WsNode node = search(id);
/* 155:155 */     if (node != null) {
/* 156:156 */       node.updateUI();
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   private void processSave(WorkspaceFactory.Event ev) {
/* 161:161 */     MruList.getWorkspacesInstance().add(workspace.getSourceId());
/* 162:    */   }
/* 163:    */   
/* 164:    */   private void processSaveAs(WorkspaceFactory.Event ev) {
/* 165:165 */     MruList.getWorkspacesInstance().add(workspace.getSourceId());
/* 166:166 */     mgr.getRootContext().setDisplayName(workspace.getName());
/* 167:    */   }
/* 168:    */   
/* 169:    */   private void processNew(WorkspaceFactory.Event ev) {
/* 170:170 */     mgr.setRootContext(new WsRootNode(workspace));
/* 171:    */   }
/* 172:    */   
/* 173:    */   private void processOpen(WorkspaceFactory.Event ev) {
/* 174:174 */     mgr.setRootContext(new WsRootNode(workspace));
/* 175:175 */     MruList.getWorkspacesInstance().add(workspace.getSourceId());
/* 176:    */   }
/* 177:    */   
/* 178:    */   private void processItemAdded(WorkspaceFactory.Event ev) {
/* 179:179 */     Node managerNode = search(id.parent());
/* 180:180 */     if (managerNode != null) {
/* 181:181 */       managerNode.getChildren().add(new Node[] { new ItemWsNode(workspace, id) });
/* 182:    */     }
/* 183:    */   }
/* 184:    */   
/* 185:    */   private void processRemovingItem(WorkspaceFactory.Event ev) {
/* 186:186 */     ItemWsNode itemNode = (ItemWsNode)search(id);
/* 187:187 */     if (itemNode != null) {
/* 188:188 */       Node parent = itemNode.getParentNode();
/* 189:189 */       if (parent != null) {
/* 190:190 */         parent.getChildren().remove(new Node[] { itemNode });
/* 191:    */       }
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   private WsNode search(Id id) {
/* 196:196 */     Node node = mgr.getRootContext();
/* 197:197 */     return search(id, node);
/* 198:    */   }
/* 199:    */   
/* 200:    */   private WsNode search(Id id, Node node) {
/* 201:201 */     if ((node instanceof WsNode)) {
/* 202:202 */       WsNode wnode = (WsNode)node;
/* 203:203 */       if (((Id)wnode.lookup()).equals(id)) {
/* 204:204 */         return wnode;
/* 205:    */       }
/* 206:    */     }
/* 207:207 */     for (Node child : node.getChildren().snapshot()) {
/* 208:208 */       WsNode wnode = search(id, child);
/* 209:209 */       if (wnode != null) {
/* 210:210 */         return wnode;
/* 211:    */       }
/* 212:    */     }
/* 213:213 */     return null;
/* 214:    */   }
/* 215:    */ }
