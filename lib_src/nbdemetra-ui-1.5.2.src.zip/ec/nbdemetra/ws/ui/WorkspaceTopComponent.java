/*   1:    */ package ec.nbdemetra.ws.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ActiveViewManager;
/*   4:    */ import ec.nbdemetra.ui.IActiveView;
/*   5:    */ import ec.nbdemetra.ui.Menus;
/*   6:    */ import ec.nbdemetra.ws.Workspace;
/*   7:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   8:    */ import ec.nbdemetra.ws.WorkspaceFactory.Event;
/*   9:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import javax.swing.Action;
/*  13:    */ import javax.swing.JMenu;
/*  14:    */ import javax.swing.SwingUtilities;
/*  15:    */ import org.openide.explorer.ExplorerManager;
/*  16:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  17:    */ import org.openide.explorer.ExplorerUtils;
/*  18:    */ import org.openide.nodes.Node;
/*  19:    */ import org.openide.util.Lookup;
/*  20:    */ import org.openide.util.Lookup.Result;
/*  21:    */ import org.openide.util.LookupEvent;
/*  22:    */ import org.openide.util.LookupListener;
/*  23:    */ import org.openide.windows.TopComponent;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ public abstract class WorkspaceTopComponent<T>
/*  27:    */   extends TopComponent
/*  28:    */   implements ExplorerManager.Provider, IActiveView, LookupListener
/*  29:    */ {
/*  30:    */   private final WorkspaceItem<T> doc;
/*  31:    */   protected Lookup.Result<WorkspaceFactory.Event> result;
/*  32:    */   
/*  33:    */   protected abstract String getContextPath();
/*  34:    */   
/*  35:    */   protected WorkspaceTopComponent(WorkspaceItem<T> doc)
/*  36:    */   {
/*  37: 37 */     this.doc = doc;
/*  38: 38 */     result = WorkspaceFactory.getInstance().getLookup().lookupResult(WorkspaceFactory.Event.class);
/*  39: 39 */     associateLookup(ExplorerUtils.createLookup(ActiveViewManager.getInstance().getExplorerManager(), getActionMap()));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public WorkspaceItem<T> getDocument() {
/*  43: 43 */     return doc;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean hasContextMenu()
/*  47:    */   {
/*  48: 48 */     return true;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Node getNode()
/*  52:    */   {
/*  53: 53 */     return null;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Action[] getActions()
/*  57:    */   {
/*  58: 58 */     return Menus.createActions(super.getActions(), new String[] { getContextPath() });
/*  59:    */   }
/*  60:    */   
/*  61:    */   public ExplorerManager getExplorerManager()
/*  62:    */   {
/*  63: 63 */     return ActiveViewManager.getInstance().getExplorerManager();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean fill(JMenu menu)
/*  67:    */   {
/*  68: 68 */     if (doc != null) {
/*  69: 69 */       Menus.fillMenu(menu, new String[] { getContextPath() });
/*  70:    */     }
/*  71: 71 */     return true;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void componentOpened()
/*  75:    */   {
/*  76: 76 */     result.addLookupListener(this);
/*  77: 77 */     if ((doc != null) && (doc.getView() == null)) {
/*  78: 78 */       doc.setView(this);
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */   public void componentClosed()
/*  84:    */   {
/*  85: 85 */     if (doc != null) {
/*  86: 86 */       doc.setView(null);
/*  87:    */     }
/*  88: 88 */     result.removeLookupListener(this);
/*  89:    */   }
/*  90:    */   
/*  91:    */ 
/*  92:    */   public void refresh() {}
/*  93:    */   
/*  94:    */   public void resultChanged(LookupEvent le)
/*  95:    */   {
/*  96: 96 */     if (doc == null) {
/*  97: 97 */       return;
/*  98:    */     }
/*  99: 99 */     Collection<? extends WorkspaceFactory.Event> all = result.allInstances();
/* 100:100 */     if (!all.isEmpty()) {
/* 101:101 */       Iterator<? extends WorkspaceFactory.Event> iterator = all.iterator();
/* 102:102 */       while (iterator.hasNext()) {
/* 103:103 */         WorkspaceFactory.Event ev = (WorkspaceFactory.Event)iterator.next();
/* 104:104 */         if (info == 13) {
/* 105:105 */           WorkspaceItem<?> wdoc = workspace.searchDocument(id);
/* 106:106 */           if (wdoc == doc) {
/* 107:107 */             SwingUtilities.invokeLater(new Runnable()
/* 108:    */             {
/* 109:    */               public void run() {
/* 110:110 */                 doc.closeView();
/* 111:    */               }
/* 112:    */             });
/* 113:    */           }
/* 114:114 */         } else if ((info == 16) && 
/* 115:115 */           (source != this)) {
/* 116:116 */           WorkspaceItem<?> wdoc = workspace.searchDocument(id);
/* 117:117 */           if (wdoc == doc) {
/* 118:118 */             SwingUtilities.invokeLater(new Runnable()
/* 119:    */             {
/* 120:    */               public void run() {
/* 121:121 */                 refresh();
/* 122:    */               }
/* 123:    */             });
/* 124:    */           }
/* 125:    */         }
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */ 
/* 131:    */   public void componentActivated()
/* 132:    */   {
/* 133:133 */     if (doc != null) {
/* 134:134 */       ActiveViewManager.getInstance().set(this);
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void componentDeactivated()
/* 139:    */   {
/* 140:140 */     if (doc != null) {
/* 141:141 */       ActiveViewManager.getInstance().set(null);
/* 142:    */     }
/* 143:    */   }
/* 144:    */ }
