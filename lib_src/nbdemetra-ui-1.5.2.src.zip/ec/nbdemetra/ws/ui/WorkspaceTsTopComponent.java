/*  1:   */ package ec.nbdemetra.ws.ui;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.ActiveViewManager;
/*  4:   */ import ec.nbdemetra.ui.Menus;
/*  5:   */ import ec.nbdemetra.ui.TsTopComponent;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  7:   */ import ec.tss.documents.TsDocument;
/*  8:   */ import javax.swing.Action;
/*  9:   */ import javax.swing.JMenu;
/* 10:   */ import org.openide.explorer.ExplorerUtils;
/* 11:   */ import org.openide.nodes.Node;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public abstract class WorkspaceTsTopComponent<T extends TsDocument<?, ?>>
/* 22:   */   extends TsTopComponent
/* 23:   */ {
/* 24:   */   private final WorkspaceItem<T> doc;
/* 25:   */   
/* 26:   */   protected abstract String getContextPath();
/* 27:   */   
/* 28:   */   protected WorkspaceTsTopComponent(WorkspaceItem<T> doc)
/* 29:   */   {
/* 30:30 */     this.doc = doc;
/* 31:31 */     associateLookup(ExplorerUtils.createLookup(ActiveViewManager.getInstance().getExplorerManager(), getActionMap()));
/* 32:   */   }
/* 33:   */   
/* 34:   */   public WorkspaceItem<T> getDocument() {
/* 35:35 */     return doc;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean hasContextMenu()
/* 39:   */   {
/* 40:40 */     return true;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public boolean fill(JMenu menu)
/* 44:   */   {
/* 45:45 */     Menus.fillMenu(menu, new String[] { "ws.common.context.ts", getContextPath() });
/* 46:46 */     return true;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Node getNode()
/* 50:   */   {
/* 51:51 */     return null;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Action[] getActions()
/* 55:   */   {
/* 56:56 */     return Menus.createActions(super.getActions(), new String[] { "ws.common.context.ts", getContextPath() });
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void componentOpened()
/* 60:   */   {
/* 61:61 */     super.componentOpened();
/* 62:62 */     doc.setView(this);
/* 63:   */   }
/* 64:   */   
/* 65:   */ 
/* 66:   */ 
/* 67:   */   public void componentClosed()
/* 68:   */   {
/* 69:69 */     doc.setView(null);
/* 70:70 */     super.componentClosed();
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void componentActivated()
/* 74:   */   {
/* 75:75 */     ActiveViewManager.getInstance().set(this);
/* 76:   */   }
/* 77:   */   
/* 78:   */   public void componentDeactivated()
/* 79:   */   {
/* 80:80 */     ActiveViewManager.getInstance().set(null);
/* 81:   */   }
/* 82:   */ }
