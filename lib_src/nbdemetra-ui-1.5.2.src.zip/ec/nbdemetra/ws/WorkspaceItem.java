/*   1:    */ package ec.nbdemetra.ws;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.utilities.IModifiable;
/*   4:    */ import ec.tstoolkit.utilities.Id;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import org.openide.windows.TopComponent;
/*   7:    */ 
/*   8:    */ public class WorkspaceItem<T>
/*   9:    */   implements IModifiable, Comparable<WorkspaceItem>
/*  10:    */ {
/*  11:    */   private Workspace owner_;
/*  12:    */   private final Id family_;
/*  13:    */   private T element_;
/*  14:    */   private String name_;
/*  15:    */   private boolean dirty_;
/*  16:    */   private String id_;
/*  17:    */   
/*  18:    */   public int compareTo(WorkspaceItem o)
/*  19:    */   {
/*  20: 20 */     int cmp = family_.compareTo(family_);
/*  21: 21 */     if (cmp != 0) {
/*  22: 22 */       return cmp;
/*  23:    */     }
/*  24: 24 */     cmp = status_.compareTo(status_);
/*  25: 25 */     if (cmp != 0) {
/*  26: 26 */       return cmp;
/*  27:    */     }
/*  28: 28 */     return name_.compareTo(name_);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static enum Status
/*  32:    */   {
/*  33: 33 */     System,  Temporary,  New,  Undefined,  Valid,  Invalid;
/*  34:    */     
/*  35:    */     public boolean isVolatile() {
/*  36: 36 */       return (this == System) || (this == Temporary);
/*  37:    */     }
/*  38:    */     
/*  39:    */     public boolean canBeLoaded() {
/*  40: 40 */       return this == Undefined;
/*  41:    */     }
/*  42:    */     
/*  43:    */     public boolean canBeSaved() {
/*  44: 44 */       return (this == New) || (this == Valid);
/*  45:    */     }
/*  46:    */     
/*  47:    */     public boolean hasStorage() {
/*  48: 48 */       return (this == Valid) || (this == Undefined) || (this == Invalid);
/*  49:    */     }
/*  50:    */   }
/*  51:    */   
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58: 58 */   private Status status_ = Status.Undefined;
/*  59:    */   private TopComponent view_;
/*  60:    */   
/*  61:    */   public static <T> WorkspaceItem<T> system(Id family, String name, T element) {
/*  62: 62 */     WorkspaceItem<T> item = new WorkspaceItem(family, name, element);
/*  63: 63 */     status_ = Status.System;
/*  64: 64 */     return item;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <T> WorkspaceItem<T> temporary(Id family, String name, T element) {
/*  68: 68 */     WorkspaceItem<T> item = new WorkspaceItem(family, name, element);
/*  69: 69 */     status_ = Status.Temporary;
/*  70: 70 */     return item;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static <T> WorkspaceItem<T> newItem(Id family, String name, T element) {
/*  74: 74 */     WorkspaceItem<T> item = new WorkspaceItem(family, name, element);
/*  75: 75 */     status_ = Status.New;
/*  76: 76 */     dirty_ = true;
/*  77: 77 */     return item;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static <T> WorkspaceItem<T> item(Id family, String name, String id) {
/*  81: 81 */     WorkspaceItem<T> item = new WorkspaceItem(family, name, id);
/*  82: 82 */     status_ = Status.Undefined;
/*  83: 83 */     return item;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private WorkspaceItem(Id family, String name, T element) {
/*  87: 87 */     family_ = family;
/*  88: 88 */     name_ = name;
/*  89: 89 */     id_ = name;
/*  90: 90 */     element_ = element;
/*  91:    */   }
/*  92:    */   
/*  93:    */   private WorkspaceItem(Id family, String name, String id) {
/*  94: 94 */     family_ = family;
/*  95: 95 */     name_ = name;
/*  96: 96 */     id_ = id;
/*  97: 97 */     if (id == null) {
/*  98: 98 */       id_ = name;
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Id getFamily() {
/* 103:103 */     return family_;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public Id getId() {
/* 107:107 */     return family_.extend(id_);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Workspace getOwner() {
/* 111:111 */     return owner_;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Status getStatus() {
/* 115:115 */     return status_;
/* 116:    */   }
/* 117:    */   
/* 118:    */   void setStatus(Status status) {
/* 119:119 */     status_ = status;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public T getElement() {
/* 123:123 */     load();
/* 124:124 */     return element_;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean load() {
/* 128:128 */     if (!status_.canBeLoaded()) {
/* 129:129 */       return false;
/* 130:    */     }
/* 131:131 */     if (owner_.getRepository().loadItem(this)) {
/* 132:132 */       status_ = Status.Valid;
/* 133:133 */       return true;
/* 134:    */     }
/* 135:135 */     status_ = Status.Invalid;
/* 136:136 */     return false;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean close()
/* 140:    */   {
/* 141:141 */     if (!status_.canBeSaved()) {
/* 142:142 */       return false;
/* 143:    */     }
/* 144:144 */     if (owner_.getRepository().saveItem(this)) {
/* 145:145 */       closeView();
/* 146:146 */       element_ = null;
/* 147:147 */       status_ = Status.Undefined;
/* 148:148 */       return true;
/* 149:    */     }
/* 150:150 */     return false;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public boolean reload()
/* 154:    */   {
/* 155:155 */     if (!status_.hasStorage()) {
/* 156:156 */       return false;
/* 157:    */     }
/* 158:158 */     element_ = null;
/* 159:159 */     status_ = Status.Undefined;
/* 160:160 */     return load();
/* 161:    */   }
/* 162:    */   
/* 163:    */   void setOwner(Workspace owner) {
/* 164:164 */     owner_ = owner;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void setElement(T element) {
/* 168:168 */     element_ = element;
/* 169:169 */     dirty_ = true;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public String toString()
/* 173:    */   {
/* 174:174 */     return getDisplayName();
/* 175:    */   }
/* 176:    */   
/* 177:    */   public String getDisplayName()
/* 178:    */   {
/* 179:179 */     return name_;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setDisplayName(String value) {
/* 183:183 */     if (!name_.equals(value)) {
/* 184:184 */       name_ = value;
/* 185:185 */       if (view_ != null) {
/* 186:186 */         view_.setDisplayName(value);
/* 187:    */       }
/* 188:188 */       dirty_ = true;
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   public String getIdentifier() {
/* 193:193 */     return id_;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void setIdentifier(String value) {
/* 197:197 */     if (!id_.equals(value)) {
/* 198:198 */       id_ = value;
/* 199:199 */       dirty_ = true;
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   public boolean isReadOnly() {
/* 204:204 */     return status_ == Status.System;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public boolean isDirty()
/* 208:    */   {
/* 209:209 */     if (dirty_) {
/* 210:210 */       return true;
/* 211:    */     }
/* 212:212 */     if ((element_ != null) && ((element_ instanceof IModifiable))) {
/* 213:213 */       return ((IModifiable)element_).isDirty();
/* 214:    */     }
/* 215:215 */     return false;
/* 216:    */   }
/* 217:    */   
/* 218:    */ 
/* 219:    */   public void resetDirty()
/* 220:    */   {
/* 221:221 */     if ((element_ != null) && ((element_ instanceof IModifiable))) {
/* 222:222 */       ((IModifiable)element_).resetDirty();
/* 223:    */     }
/* 224:224 */     dirty_ = false;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public boolean isOpen() {
/* 228:228 */     return view_ != null;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void setView(TopComponent view) {
/* 232:232 */     view_ = view;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public TopComponent getView() {
/* 236:236 */     return view_;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public boolean closeView() {
/* 240:    */     try {
/* 241:241 */       if (view_ == null) {
/* 242:242 */         return true;
/* 243:    */       }
/* 244:244 */       if (!view_.canClose()) {
/* 245:245 */         return false;
/* 246:    */       }
/* 247:247 */       view_.close();
/* 248:248 */       return true;
/* 249:    */     }
/* 250:    */     catch (Exception err) {}
/* 251:251 */     return true;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public void notify(int event, Object source)
/* 255:    */   {
/* 256:256 */     WorkspaceFactory.getInstance().notifyEvent(new WorkspaceFactory.Event(owner_, getId(), event, source));
/* 257:    */   }
/* 258:    */   
/* 259:    */   public static class InnerComparator implements Comparator<WorkspaceItem<?>>
/* 260:    */   {
/* 261:    */     private final Id family_;
/* 262:    */     
/* 263:    */     public InnerComparator(Id family) {
/* 264:264 */       family_ = family;
/* 265:    */     }
/* 266:    */     
/* 267:    */     public int compare(WorkspaceItem<?> o1, WorkspaceItem<?> o2)
/* 268:    */     {
/* 269:269 */       if ((family_.equals(family_)) && 
/* 270:270 */         (family_.equals(family_))) {
/* 271:271 */         return o1.compareTo(o2);
/* 272:    */       }
/* 273:273 */       return 0;
/* 274:    */     }
/* 275:    */   }
/* 276:    */ }
