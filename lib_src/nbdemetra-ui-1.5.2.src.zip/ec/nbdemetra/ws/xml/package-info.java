package ec.nbdemetra.ws.xml;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

@XmlSchema(namespace="ec/tss.demetra", elementFormDefault=XmlNsForm.QUALIFIED, attributeFormDefault=XmlNsForm.UNQUALIFIED, xmlns={@javax.xml.bind.annotation.XmlNs(prefix="", namespaceURI="ec/tss.core")})
abstract interface package-info {}
