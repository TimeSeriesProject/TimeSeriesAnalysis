package ec.nbdemetra.ws.xml.compatibility;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name="demetraItemType")
public class XmlWksElement
{
  static final String NAME = "demetraItemType";
  @XmlElement
  public String name;
  @XmlElement
  public String file;
  @XmlAttribute
  public boolean readOnly;
}
