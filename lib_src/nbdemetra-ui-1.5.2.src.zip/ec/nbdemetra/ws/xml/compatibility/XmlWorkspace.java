/*   1:    */ package ec.nbdemetra.ws.xml.compatibility;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ws.IWorkspaceItemManager;
/*   4:    */ import ec.nbdemetra.ws.Workspace;
/*   5:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   6:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*   7:    */ import ec.satoolkit.algorithm.implementation.TramoSeatsProcessingFactory;
/*   8:    */ import ec.satoolkit.algorithm.implementation.X13ProcessingFactory;
/*   9:    */ import ec.tstoolkit.algorithm.AlgorithmDescriptor;
/*  10:    */ import ec.tstoolkit.modelling.arima.Method;
/*  11:    */ import ec.tstoolkit.utilities.Id;
/*  12:    */ import ec.tstoolkit.utilities.LinearId;
/*  13:    */ import javax.xml.bind.annotation.XmlAttribute;
/*  14:    */ import javax.xml.bind.annotation.XmlElement;
/*  15:    */ import javax.xml.bind.annotation.XmlElementWrapper;
/*  16:    */ import javax.xml.bind.annotation.XmlRootElement;
/*  17:    */ import javax.xml.bind.annotation.XmlType;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ @XmlRootElement(name="demetraWorkspace")
/*  25:    */ @XmlType(name="demetraWorkspaceType")
/*  26:    */ public class XmlWorkspace
/*  27:    */ {
/*  28:    */   static final String NAME = "demetraWorkspaceType";
/*  29:    */   static final String RNAME = "demetraWorkspace";
/*  30: 30 */   public static final Id TRAMOSEATSSPEC = new LinearId(new String[] { DESCRIPTORfamily, "specifications", DESCRIPTORname });
/*  31: 31 */   public static final Id TRAMOSEATSDOC = new LinearId(new String[] { DESCRIPTORfamily, "documents", DESCRIPTORname });
/*  32: 32 */   public static final Id X13SPEC = new LinearId(new String[] { DESCRIPTORfamily, "specifications", DESCRIPTORname });
/*  33: 33 */   public static final Id X13DOC = new LinearId(new String[] { DESCRIPTORfamily, "documents", DESCRIPTORname });
/*  34: 34 */   public static final Id SAPROCESSING = new LinearId("Seasonal adjustment", "multi-documents");
/*  35:    */   
/*  36:    */   @XmlElementWrapper
/*  37:    */   @XmlElement(name="tramoseatsSpec")
/*  38:    */   public XmlWksElement[] tramoseatsSpecs;
/*  39:    */   
/*  40:    */   @XmlElementWrapper
/*  41:    */   @XmlElement(name="x12Spec")
/*  42:    */   public XmlWksElement[] x12Specs;
/*  43:    */   
/*  44:    */   @XmlElementWrapper
/*  45:    */   @XmlElement(name="tramoseatsDoc")
/*  46:    */   public XmlWksElement[] tramoseatsDocs;
/*  47:    */   
/*  48:    */   @XmlElementWrapper
/*  49:    */   @XmlElement(name="x12Doc")
/*  50:    */   public XmlWksElement[] x12Docs;
/*  51:    */   @XmlElementWrapper
/*  52:    */   @XmlElement(name="processing")
/*  53:    */   public XmlWksElement[] saProcessing;
/*  54:    */   @XmlElement
/*  55:    */   public XmlWksElement calendars;
/*  56:    */   @XmlElement
/*  57:    */   public XmlWksElement variables;
/*  58:    */   @XmlAttribute
/*  59:    */   public String defaultSpec;
/*  60:    */   @XmlAttribute
/*  61:    */   public Method defaultMethod;
/*  62:    */   
/*  63:    */   public boolean load(Workspace ws)
/*  64:    */   {
/*  65: 65 */     if (tramoseatsSpecs != null) {
/*  66: 66 */       IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager(TRAMOSEATSSPEC);
/*  67: 67 */       if (mgr != null) {
/*  68: 68 */         for (int i = 0; i < tramoseatsSpecs.length; i++) {
/*  69: 69 */           WorkspaceItem<?> item = WorkspaceItem.item(mgr.getId(), tramoseatsSpecs[i].name, tramoseatsSpecs[i].file);
/*  70: 70 */           ws.quietAdd(item);
/*  71:    */         }
/*  72:    */       }
/*  73:    */     }
/*  74: 74 */     if (x12Specs != null) {
/*  75: 75 */       IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager(X13SPEC);
/*  76: 76 */       if (mgr != null) {
/*  77: 77 */         for (int i = 0; i < x12Specs.length; i++) {
/*  78: 78 */           WorkspaceItem<?> item = WorkspaceItem.item(mgr.getId(), x12Specs[i].name, x12Specs[i].file);
/*  79: 79 */           ws.quietAdd(item);
/*  80:    */         }
/*  81:    */       }
/*  82:    */     }
/*  83: 83 */     if (tramoseatsDocs != null) {
/*  84: 84 */       IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager(TRAMOSEATSDOC);
/*  85: 85 */       if (mgr != null) {
/*  86: 86 */         for (int i = 0; i < tramoseatsDocs.length; i++) {
/*  87: 87 */           WorkspaceItem<?> item = WorkspaceItem.item(mgr.getId(), tramoseatsDocs[i].name, tramoseatsDocs[i].file);
/*  88: 88 */           ws.quietAdd(item);
/*  89:    */         }
/*  90:    */       }
/*  91:    */     }
/*  92: 92 */     if (x12Docs != null) {
/*  93: 93 */       IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager(X13DOC);
/*  94: 94 */       if (mgr != null) {
/*  95: 95 */         for (int i = 0; i < x12Docs.length; i++) {
/*  96: 96 */           WorkspaceItem<?> item = WorkspaceItem.item(mgr.getId(), x12Docs[i].name, x12Docs[i].file);
/*  97: 97 */           ws.quietAdd(item);
/*  98:    */         }
/*  99:    */       }
/* 100:    */     }
/* 101:101 */     if (saProcessing != null) {
/* 102:102 */       IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager(SAPROCESSING);
/* 103:103 */       if (mgr != null) {
/* 104:104 */         for (int i = 0; i < saProcessing.length; i++) {
/* 105:105 */           WorkspaceItem<?> item = WorkspaceItem.item(mgr.getId(), saProcessing[i].name, saProcessing[i].file);
/* 106:106 */           ws.quietAdd(item);
/* 107:    */         }
/* 108:    */       }
/* 109:    */     }
/* 110:110 */     return true;
/* 111:    */   }
/* 112:    */ }
