package ec.nbdemetra.ws.xml;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name="demetraGenericItemType")
public class XmlWorkspaceItem
{
  static final String NAME = "demetraGenericItemType";
  @XmlElement
  public String family;
  @XmlElement
  public String name;
  @XmlElement
  public String file;
  @XmlAttribute
  public boolean readOnly;
}
