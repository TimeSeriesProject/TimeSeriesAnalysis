/*  1:   */ package ec.nbdemetra.ws.xml;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.IWorkspaceItemManager;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  7:   */ import ec.nbdemetra.ws.WorkspaceItem.Status;
/*  8:   */ import ec.tstoolkit.utilities.DefaultIdAggregator;
/*  9:   */ import ec.tstoolkit.utilities.LinearId;
/* 10:   */ import java.util.ArrayList;
/* 11:   */ import java.util.List;
/* 12:   */ import javax.xml.bind.annotation.XmlAttribute;
/* 13:   */ import javax.xml.bind.annotation.XmlElement;
/* 14:   */ import javax.xml.bind.annotation.XmlElementWrapper;
/* 15:   */ import javax.xml.bind.annotation.XmlRootElement;
/* 16:   */ import javax.xml.bind.annotation.XmlType;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ @XmlRootElement(name="demetraGenericWorkspace")
/* 25:   */ @XmlType(name="demetraGenericWorkspaceType")
/* 26:   */ public class XmlGenericWorkspace
/* 27:   */ {
/* 28:   */   static final String NAME = "demetraGenericWorkspaceType";
/* 29:   */   static final String RNAME = "demetraGenericWorkspace";
/* 30:   */   @XmlAttribute
/* 31:   */   public String name;
/* 32:   */   @XmlElementWrapper
/* 33:   */   @XmlElement(name="item")
/* 34:   */   public XmlWorkspaceItem[] items;
/* 35:   */   private static final String SEP = "@";
/* 36:   */   
/* 37:   */   public boolean to(Workspace ws)
/* 38:   */   {
/* 39:39 */     ws.setName(name);
/* 40:40 */     if (items != null) {
/* 41:41 */       for (XmlWorkspaceItem item : items) {
/* 42:42 */         WorkspaceItem<?> witem = WorkspaceItem.item(new LinearId(family.split("@")), name, file);
/* 43:43 */         ws.quietAdd(witem);
/* 44:44 */         IWorkspaceItemManager<?> manager = WorkspaceFactory.getInstance().getManager(witem.getFamily());
/* 45:45 */         if ((manager != null) && (manager.isAutoLoad()))
/* 46:   */         {
/* 47:47 */           witem.load();
/* 48:   */         }
/* 49:   */       }
/* 50:   */     }
/* 51:51 */     return true;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public boolean from(Workspace ws) {
/* 55:55 */     name = ws.getName();
/* 56:56 */     List<WorkspaceItem<?>> witems = ws.getItems();
/* 57:57 */     if (witems.isEmpty()) {
/* 58:58 */       return true;
/* 59:   */     }
/* 60:60 */     ArrayList<XmlWorkspaceItem> xitems = new ArrayList();
/* 61:61 */     DefaultIdAggregator agg = new DefaultIdAggregator("@".charAt(0));
/* 62:62 */     for (WorkspaceItem<?> witem : witems) {
/* 63:63 */       if (witem.getStatus() != WorkspaceItem.Status.System) {
/* 64:64 */         XmlWorkspaceItem cur = new XmlWorkspaceItem();
/* 65:65 */         family = agg.aggregate(witem.getFamily());
/* 66:66 */         file = witem.getIdentifier();
/* 67:67 */         name = witem.getDisplayName();
/* 68:68 */         xitems.add(cur);
/* 69:   */       }
/* 70:   */     }
/* 71:71 */     if (!xitems.isEmpty()) {
/* 72:72 */       items = new XmlWorkspaceItem[xitems.size()];
/* 73:73 */       xitems.toArray(items);
/* 74:   */     }
/* 75:75 */     return true;
/* 76:   */   }
/* 77:   */ }
