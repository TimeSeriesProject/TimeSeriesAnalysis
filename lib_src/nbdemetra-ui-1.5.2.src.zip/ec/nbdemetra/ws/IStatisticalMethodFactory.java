package ec.nbdemetra.ws;

import ec.tstoolkit.algorithm.AlgorithmDescriptor;
import ec.tstoolkit.algorithm.IProcSpecification;
import java.util.List;

public abstract interface IStatisticalMethodFactory
{
  public abstract int getPriority();
  
  public abstract AlgorithmDescriptor getDescriptor();
  
  public abstract List<IProcSpecification> getDefaultSpecifications();
}
