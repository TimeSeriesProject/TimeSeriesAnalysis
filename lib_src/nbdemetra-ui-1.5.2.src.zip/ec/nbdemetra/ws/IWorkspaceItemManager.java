/*  1:   */ package ec.nbdemetra.ws;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.utilities.Id;
/*  4:   */ 
/*  5:   */ public abstract interface IWorkspaceItemManager<D>
/*  6:   */ {
/*  7:   */   public abstract Status getStatus();
/*  8:   */   
/*  9:   */   public abstract ItemType getItemType();
/* 10:   */   
/* 11:   */   public abstract Class<D> getItemClass();
/* 12:   */   
/* 13:   */   public abstract Id getId();
/* 14:   */   
/* 15:   */   public abstract String getActionsPath();
/* 16:   */   
/* 17:   */   public abstract javax.swing.Action getPreferredItemAction(Id paramId);
/* 18:   */   
/* 19:   */   public static enum ItemType
/* 20:   */   {
/* 21:21 */     Undefined, 
/* 22:22 */     Spec, 
/* 23:23 */     Doc, 
/* 24:24 */     MultiDoc, 
/* 25:25 */     Tool;
/* 26:   */   }
/* 27:   */   
/* 28:28 */   public static enum Status implements ec.tstoolkit.design.IntValue { Certified(1), 
/* 29:29 */     Acceptable(2), 
/* 30:30 */     Legacy(3), 
/* 31:31 */     Experimental(5), 
/* 32:32 */     User(10);
/* 33:   */     
/* 34:   */     private Status(int value) {
/* 35:35 */       this.value = value;
/* 36:   */     }
/* 37:   */     
/* 38:   */     private final int value;
/* 39:   */     public int intValue()
/* 40:   */     {
/* 41:41 */       return value;
/* 42:   */     }
/* 43:   */   }
/* 44:   */   
/* 45:   */   public abstract String getNextItemName(String paramString);
/* 46:   */   
/* 47:   */   public abstract java.util.List<WorkspaceItem<D>> getDefaultItems();
/* 48:   */   
/* 49:   */   public abstract WorkspaceItem<D> create(Workspace paramWorkspace);
/* 50:   */   
/* 51:   */   public abstract boolean isAutoLoad();
/* 52:   */   
/* 53:   */   public abstract javax.swing.Icon getItemIcon(WorkspaceItem<D> paramWorkspaceItem);
/* 54:   */   
/* 55:   */   public abstract javax.swing.Icon getManagerIcon();
/* 56:   */ }
