/*  1:   */ package ec.nbdemetra.ws;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.information.InformationSetSerializable;
/*  4:   */ import ec.tstoolkit.utilities.IModifiable;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public abstract class DefaultFileItemRepository<D extends IModifiable,  extends InformationSetSerializable>
/* 14:   */   extends AbstractFileItemRepository<D>
/* 15:   */ {
/* 16:   */   public abstract String getRepository();
/* 17:   */   
/* 18:   */   public boolean load(WorkspaceItem<D> item)
/* 19:   */   {
/* 20:20 */     String sfile = fullName(item, getRepository(), false);
/* 21:21 */     if (sfile == null)
/* 22:22 */       return false;
/* 23:23 */     D doc = (IModifiable)AbstractFileItemRepository.loadInfo(sfile, getSupportedType());
/* 24:24 */     item.setElement(doc);
/* 25:25 */     item.resetDirty();
/* 26:26 */     return doc != null;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean save(WorkspaceItem<D> item)
/* 30:   */   {
/* 31:31 */     String sfile = fullName(item, getRepository(), true);
/* 32:32 */     if (sfile == null)
/* 33:33 */       return false;
/* 34:34 */     if (saveInfo(sfile, (IModifiable)item.getElement())) {
/* 35:35 */       item.resetDirty();
/* 36:36 */       ((IModifiable)item.getElement()).resetDirty();
/* 37:37 */       return true;
/* 38:   */     }
/* 39:39 */     return false;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean delete(WorkspaceItem<D> doc)
/* 43:   */   {
/* 44:44 */     return delete(doc, getRepository());
/* 45:   */   }
/* 46:   */ }
