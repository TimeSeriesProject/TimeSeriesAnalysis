/*  1:   */ package ec.nbdemetra.ws.nodes;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.BasicChildFactory;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  6:   */ import ec.tstoolkit.utilities.Id;
/*  7:   */ import ec.tstoolkit.utilities.TreeOfIds;
/*  8:   */ import java.awt.Image;
/*  9:   */ import java.util.Arrays;
/* 10:   */ import java.util.List;
/* 11:   */ import org.openide.nodes.Node;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class DummyWsNode
/* 19:   */   extends WsNode
/* 20:   */ {
/* 21:   */   public DummyWsNode(Workspace ws, Id id)
/* 22:   */   {
/* 23:23 */     super(createItems(ws, id), ws, id);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Image getIcon(int type)
/* 27:   */   {
/* 28:28 */     return super.getIcon(type);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Image getOpenedIcon(int type)
/* 32:   */   {
/* 33:33 */     return super.getOpenedIcon(type);
/* 34:   */   }
/* 35:   */   
/* 36:   */   @Deprecated
/* 37:   */   static class DummyChildFactory extends BasicChildFactory<Id>
/* 38:   */   {
/* 39:   */     final Workspace workspace_;
/* 40:   */     final Id managerId;
/* 41:   */     
/* 42:   */     public DummyChildFactory(Workspace ws, Id managerId) {
/* 43:43 */       workspace_ = ws;
/* 44:44 */       this.managerId = managerId;
/* 45:   */     }
/* 46:   */     
/* 47:   */     protected Node createNodeForKey(Id id)
/* 48:   */     {
/* 49:49 */       if (ManagerWsNode.isManager(id)) {
/* 50:50 */         return new ManagerWsNode(workspace_, id);
/* 51:   */       }
/* 52:52 */       return new DummyWsNode(workspace_, id);
/* 53:   */     }
/* 54:   */     
/* 55:   */     protected void tryCreateKeys(List<Id> list)
/* 56:   */       throws Exception
/* 57:   */     {
/* 58:58 */       list.addAll(Arrays.asList(WorkspaceFactory.getInstance().getTree().children(managerId)));
/* 59:   */     }
/* 60:   */   }
/* 61:   */ }
