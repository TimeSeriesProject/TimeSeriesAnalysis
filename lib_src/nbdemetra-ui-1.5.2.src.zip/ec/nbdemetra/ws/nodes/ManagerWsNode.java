/*  1:   */ package ec.nbdemetra.ws.nodes;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.BasicChildFactory;
/*  4:   */ import ec.nbdemetra.ws.IWorkspaceItemManager;
/*  5:   */ import ec.nbdemetra.ws.Workspace;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  7:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  8:   */ import ec.tstoolkit.utilities.Id;
/*  9:   */ import java.awt.Image;
/* 10:   */ import java.util.List;
/* 11:   */ import javax.swing.Icon;
/* 12:   */ import org.openide.nodes.Node;
/* 13:   */ import org.openide.util.ImageUtilities;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class ManagerWsNode
/* 23:   */   extends WsNode
/* 24:   */ {
/* 25:   */   public ManagerWsNode(Workspace ws, Id id)
/* 26:   */   {
/* 27:27 */     super(createFinalItems(ws, id), ws, id);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public IWorkspaceItemManager<?> getManager() {
/* 31:31 */     return WorkspaceFactory.getInstance().getManager((Id)lookup());
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Image getIcon(int type)
/* 35:   */   {
/* 36:36 */     Icon result = getManager().getManagerIcon();
/* 37:37 */     return result != null ? ImageUtilities.icon2Image(result) : super.getIcon(type);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Image getOpenedIcon(int type)
/* 41:   */   {
/* 42:42 */     Icon result = getManager().getManagerIcon();
/* 43:43 */     return result != null ? ImageUtilities.icon2Image(result) : super.getOpenedIcon(type);
/* 44:   */   }
/* 45:   */   
/* 46:   */   @Deprecated
/* 47:   */   static class ManagerChildFactory extends BasicChildFactory<Id>
/* 48:   */   {
/* 49:   */     final Workspace workspace_;
/* 50:   */     final Id managerId;
/* 51:   */     
/* 52:   */     public ManagerChildFactory(Workspace ws, Id managerId) {
/* 53:53 */       workspace_ = ws;
/* 54:54 */       this.managerId = managerId;
/* 55:   */     }
/* 56:   */     
/* 57:   */     protected Node createNodeForKey(Id id)
/* 58:   */     {
/* 59:59 */       return new ItemWsNode(workspace_, id);
/* 60:   */     }
/* 61:   */     
/* 62:   */     protected void tryCreateKeys(List<Id> list) throws Exception
/* 63:   */     {
/* 64:64 */       for (WorkspaceItem<?> doc : workspace_.searchDocuments(managerId)) {
/* 65:65 */         list.add(doc.getId());
/* 66:   */       }
/* 67:   */     }
/* 68:   */   }
/* 69:   */ }
