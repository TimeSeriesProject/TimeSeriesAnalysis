/*  1:   */ package ec.nbdemetra.ws.nodes;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbUtilities;
/*  4:   */ import ec.nbdemetra.ws.IWorkspaceItemManager;
/*  5:   */ import ec.nbdemetra.ws.Workspace;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  7:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  8:   */ import ec.tstoolkit.IDocumented;
/*  9:   */ import ec.tstoolkit.MetaData;
/* 10:   */ import ec.tstoolkit.utilities.Id;
/* 11:   */ import java.awt.Image;
/* 12:   */ import javax.swing.Action;
/* 13:   */ import javax.swing.Icon;
/* 14:   */ import org.openide.nodes.Children;
/* 15:   */ import org.openide.nodes.Sheet;
/* 16:   */ import org.openide.nodes.Sheet.Set;
/* 17:   */ import org.openide.util.ImageUtilities;
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public class ItemWsNode
/* 25:   */   extends WsNode
/* 26:   */ {
/* 27:   */   public static boolean isItem(Workspace ws, Id id)
/* 28:   */   {
/* 29:29 */     return ws.searchDocument(id) != null;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public ItemWsNode(Workspace ws, Id id) {
/* 33:33 */     super(Children.LEAF, ws, id);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public WorkspaceItem<?> getItem() {
/* 37:37 */     return workspace_.searchDocument((Id)lookup());
/* 38:   */   }
/* 39:   */   
/* 40:   */   public <T> WorkspaceItem<T> getItem(Class<T> tclass) {
/* 41:41 */     return workspace_.searchDocument((Id)lookup(), tclass);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getDisplayName()
/* 45:   */   {
/* 46:46 */     WorkspaceItem<?> item = getItem();
/* 47:47 */     return item == null ? "" : item.getDisplayName();
/* 48:   */   }
/* 49:   */   
/* 50:   */   public boolean canDestroy()
/* 51:   */   {
/* 52:52 */     WorkspaceItem<?> item = getItem();
/* 53:53 */     return (item != null) && (!item.isReadOnly());
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void destroy()
/* 57:   */   {
/* 58:58 */     WorkspaceItem<?> item = getItem();
/* 59:59 */     if (item != null) {
/* 60:60 */       workspace_.remove(item);
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public Image getIcon(int type)
/* 65:   */   {
/* 66:66 */     IWorkspaceItemManager manager = WorkspaceFactory.getInstance().getManager(((Id)lookup()).parent());
/* 67:67 */     Icon result = manager.getItemIcon(getItem());
/* 68:68 */     return result != null ? ImageUtilities.icon2Image(result) : super.getIcon(type);
/* 69:   */   }
/* 70:   */   
/* 71:   */   public Action getPreferredAction()
/* 72:   */   {
/* 73:73 */     IWorkspaceItemManager<?> manager = WorkspaceFactory.getInstance().getManager(((Id)lookup()).parent());
/* 74:74 */     return manager != null ? manager.getPreferredItemAction((Id)lookup()) : null;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public Sheet createSheet()
/* 78:   */   {
/* 79:79 */     Sheet sheet = super.createSheet();
/* 80:80 */     WorkspaceItem<IDocumented> doc = workspace_.searchDocument((Id)lookup(), IDocumented.class);
/* 81:81 */     if (doc == null) {
/* 82:82 */       return sheet;
/* 83:   */     }
/* 84:84 */     MetaData metaData = ((IDocumented)doc.getElement()).getMetaData();
/* 85:85 */     if (MetaData.isNullOrEmpty(metaData)) {
/* 86:86 */       return sheet;
/* 87:   */     }
/* 88:   */     
/* 89:89 */     Sheet.Set info = NbUtilities.createMetadataPropertiesSet(metaData);
/* 90:90 */     sheet.put(info);
/* 91:91 */     return sheet;
/* 92:   */   }
/* 93:   */ }
