/*   1:    */ package ec.nbdemetra.ws.nodes;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.nodes.BasicChildFactory;
/*   4:    */ import ec.nbdemetra.ui.nodes.BasicNode;
/*   5:    */ import ec.nbdemetra.ui.nodes.IdNodes.IdIcon;
/*   6:    */ import ec.nbdemetra.ws.Workspace;
/*   7:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   8:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*   9:    */ import ec.tstoolkit.utilities.Id;
/*  10:    */ import ec.tstoolkit.utilities.TreeOfIds;
/*  11:    */ import java.awt.Image;
/*  12:    */ import java.util.List;
/*  13:    */ import org.openide.nodes.Children;
/*  14:    */ import org.openide.nodes.Children.Array;
/*  15:    */ import org.openide.nodes.Node;
/*  16:    */ import org.openide.util.ImageUtilities;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ public abstract class WsNode
/*  21:    */   extends BasicNode<Id>
/*  22:    */ {
/*  23:    */   protected final Workspace workspace_;
/*  24:    */   
/*  25:    */   public static boolean isManager(Id id)
/*  26:    */   {
/*  27: 27 */     return WorkspaceFactory.getInstance().getManager(id) != null;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static Children createChildren(Workspace ws, Id id) {
/*  31: 31 */     if (id == null) {
/*  32: 32 */       return createItems(ws);
/*  33:    */     }
/*  34: 34 */     if (isManager(id)) {
/*  35: 35 */       return createFinalItems(ws, id);
/*  36:    */     }
/*  37: 37 */     return createItems(ws, id);
/*  38:    */   }
/*  39:    */   
/*  40:    */   static Children createFinalItems(Workspace ws, Id managerId) {
/*  41: 41 */     List<WorkspaceItem<?>> items = ws.searchDocuments(managerId);
/*  42: 42 */     Node[] nodes = new Node[items.size()];
/*  43: 43 */     int n = 0;
/*  44: 44 */     for (WorkspaceItem<?> doc : items) {
/*  45: 45 */       nodes[(n++)] = new ItemWsNode(ws, doc.getId());
/*  46:    */     }
/*  47: 47 */     Children.Array children = new Children.Array();
/*  48: 48 */     children.add(nodes);
/*  49: 49 */     return children;
/*  50:    */   }
/*  51:    */   
/*  52:    */   static Children createItems(Workspace ws) {
/*  53: 53 */     Node[] nodes = roots(ws);
/*  54: 54 */     Children.Array children = new Children.Array();
/*  55: 55 */     children.add(nodes);
/*  56: 56 */     return children;
/*  57:    */   }
/*  58:    */   
/*  59:    */   static Node[] roots(Workspace ws) {
/*  60: 60 */     Id[] nroots = WorkspaceFactory.getInstance().getTree().roots();
/*  61: 61 */     Node[] nodes = new Node[nroots.length];
/*  62: 62 */     for (int i = 0; i < nroots.length; i++) {
/*  63: 63 */       if (ManagerWsNode.isManager(nroots[i])) {
/*  64: 64 */         nodes[i] = new ManagerWsNode(ws, nroots[i]);
/*  65:    */       } else {
/*  66: 66 */         nodes[i] = new DummyWsNode(ws, nroots[i]);
/*  67:    */       }
/*  68:    */     }
/*  69: 69 */     return nodes;
/*  70:    */   }
/*  71:    */   
/*  72:    */   static Children createItems(Workspace ws, Id id) {
/*  73: 73 */     Node[] nodes = items(ws, id);
/*  74: 74 */     Children.Array children = new Children.Array();
/*  75: 75 */     children.add(nodes);
/*  76: 76 */     return children;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static Node[] items(Workspace ws, Id id) {
/*  80: 80 */     Id[] nroots = WorkspaceFactory.getInstance().getTree().children(id);
/*  81: 81 */     Node[] nodes = new Node[nroots.length];
/*  82: 82 */     for (int i = 0; i < nroots.length; i++) {
/*  83: 83 */       if (ManagerWsNode.isManager(nroots[i])) {
/*  84: 84 */         nodes[i] = new ManagerWsNode(ws, nroots[i]);
/*  85:    */       } else {
/*  86: 86 */         nodes[i] = new DummyWsNode(ws, nroots[i]);
/*  87:    */       }
/*  88:    */     }
/*  89: 89 */     return nodes;
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */   public WsNode(Children children, Workspace ws, Id id)
/*  94:    */   {
/*  95: 95 */     super(children, id, WorkspaceFactory.getInstance().getActionsPath(id));
/*  96: 96 */     workspace_ = ws;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public WsNode(BasicChildFactory<?> factory, Workspace ws, Id id) {
/* 100:100 */     super(factory, id, WorkspaceFactory.getInstance().getActionsPath(id));
/* 101:101 */     workspace_ = ws;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void updateUI() {
/* 105:105 */     fireDisplayNameChange(null, ((Id)lookup()).tail());
/* 106:    */   }
/* 107:    */   
/* 108:    */   public String getDisplayName()
/* 109:    */   {
/* 110:110 */     return ((Id)lookup()).tail();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Image getIcon(int type)
/* 114:    */   {
/* 115:115 */     return ImageUtilities.icon2Image(new IdNodes.IdIcon((Id)lookup()));
/* 116:    */   }
/* 117:    */   
/* 118:    */   public Image getOpenedIcon(int type)
/* 119:    */   {
/* 120:120 */     return getIcon(type);
/* 121:    */   }
/* 122:    */   
/* 123:    */   public Workspace getWorkspace() {
/* 124:124 */     return workspace_;
/* 125:    */   }
/* 126:    */ }
