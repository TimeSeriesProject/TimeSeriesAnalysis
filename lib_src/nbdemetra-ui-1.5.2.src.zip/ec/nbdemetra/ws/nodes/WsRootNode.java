/*  1:   */ package ec.nbdemetra.ws.nodes;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.NbUtilities;
/*  4:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  5:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  6:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  7:   */ import ec.nbdemetra.ws.Workspace;
/*  8:   */ import org.openide.nodes.AbstractNode;
/*  9:   */ import org.openide.nodes.Children;
/* 10:   */ import org.openide.nodes.Sheet;
/* 11:   */ import org.openide.nodes.Sheet.Set;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class WsRootNode
/* 17:   */   extends AbstractNode
/* 18:   */ {
/* 19:   */   Workspace ws_;
/* 20:   */   
/* 21:   */   public WsRootNode(Workspace ws)
/* 22:   */   {
/* 23:23 */     super(Children.create(new WsRootChildFactory(ws), false));
/* 24:24 */     ws_ = ws;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getDisplayName()
/* 28:   */   {
/* 29:29 */     return ws_.getName();
/* 30:   */   }
/* 31:   */   
/* 32:   */ 
/* 33:   */   public Sheet createSheet()
/* 34:   */   {
/* 35:35 */     Sheet sheet = super.createSheet();
/* 36:36 */     Sheet.Set identification = Sheet.createPropertiesSet();
/* 37:37 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Active workspace");
/* 38:38 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select("Name", ws_.getName())).add();
/* 39:39 */     sheet.put(b.build());
/* 40:40 */     sheet.put(NbUtilities.creatDataSourcePropertiesSet(ws_.getDataSource()));
/* 41:41 */     return sheet;
/* 42:   */   }
/* 43:   */ }
