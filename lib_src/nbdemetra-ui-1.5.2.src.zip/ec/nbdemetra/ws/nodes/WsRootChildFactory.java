/*  1:   */ package ec.nbdemetra.ws.nodes;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.Workspace;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  5:   */ import ec.tstoolkit.utilities.Id;
/*  6:   */ import ec.tstoolkit.utilities.TreeOfIds;
/*  7:   */ import java.util.Arrays;
/*  8:   */ import java.util.List;
/*  9:   */ import org.openide.nodes.ChildFactory;
/* 10:   */ import org.openide.nodes.Node;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class WsRootChildFactory
/* 18:   */   extends ChildFactory<Id>
/* 19:   */ {
/* 20:   */   private final Workspace workspace_;
/* 21:   */   
/* 22:   */   public WsRootChildFactory(Workspace ws)
/* 23:   */   {
/* 24:24 */     workspace_ = ws;
/* 25:   */   }
/* 26:   */   
/* 27:   */   protected Node createNodeForKey(Id id)
/* 28:   */   {
/* 29:29 */     if (ManagerWsNode.isManager(id)) {
/* 30:30 */       return new ManagerWsNode(workspace_, id);
/* 31:   */     }
/* 32:32 */     return new DummyWsNode(workspace_, id);
/* 33:   */   }
/* 34:   */   
/* 35:   */ 
/* 36:   */   protected boolean createKeys(List<Id> list)
/* 37:   */   {
/* 38:38 */     list.addAll(Arrays.asList(WorkspaceFactory.getInstance().getTree().roots()));
/* 39:39 */     return true;
/* 40:   */   }
/* 41:   */ }
