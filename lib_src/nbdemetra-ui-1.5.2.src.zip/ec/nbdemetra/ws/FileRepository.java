/*   1:    */ package ec.nbdemetra.ws;
/*   2:    */ 
/*   3:    */ import com.google.common.base.StandardSystemProperty;
/*   4:    */ import com.google.common.base.Throwables;
/*   5:    */ import ec.nbdemetra.ui.calendars.CalendarDocumentManager;
/*   6:    */ import ec.nbdemetra.ws.xml.XmlGenericWorkspace;
/*   7:    */ import ec.nbdemetra.ws.xml.compatibility.XmlWorkspace;
/*   8:    */ import ec.tss.tsproviders.DataSource;
/*   9:    */ import ec.tss.tsproviders.DataSource.Builder;
/*  10:    */ import ec.tss.xml.legacy.XmlTsVariables;
/*  11:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  12:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  13:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  14:    */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  15:    */ import ec.tstoolkit.utilities.NameManager;
/*  16:    */ import ec.tstoolkit.utilities.Paths;
/*  17:    */ import ec.util.desktop.Desktop;
/*  18:    */ import ec.util.desktop.Desktop.KnownFolder;
/*  19:    */ import ec.util.desktop.DesktopManager;
/*  20:    */ import java.io.File;
/*  21:    */ import java.util.Collection;
/*  22:    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*  23:    */ import javax.xml.bind.JAXBContext;
/*  24:    */ import javax.xml.bind.JAXBException;
/*  25:    */ import javax.xml.bind.Unmarshaller;
/*  26:    */ import org.openide.DialogDisplayer;
/*  27:    */ import org.openide.NotifyDescriptor;
/*  28:    */ import org.openide.NotifyDescriptor.Message;
/*  29:    */ import org.openide.filesystems.FileChooserBuilder;
/*  30:    */ import org.openide.util.Lookup;
/*  31:    */ import org.openide.util.Lookup.Result;
/*  32:    */ import org.openide.util.LookupEvent;
/*  33:    */ import org.openide.util.LookupListener;
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ public class FileRepository
/*  39:    */   extends AbstractWorkspaceRepository
/*  40:    */   implements LookupListener
/*  41:    */ {
/*  42:    */   public static final String NAME = "File";
/*  43:    */   public static final String FILENAME = "fileName";
/*  44:    */   public static final String VERSION = "20120925";
/*  45:    */   static final JAXBContext XML_GENERIC_WS_CONTEXT;
/*  46:    */   static final JAXBContext XML_WS_CONTEXT;
/*  47:    */   private static final FileChooserBuilder calendarChooserBuilder;
/*  48:    */   private Lookup.Result<IWorkspaceItemRepository> repositoryLookup;
/*  49:    */   private final FileChooserBuilder fileChooserBuilder;
/*  50:    */   
/*  51:    */   static
/*  52:    */   {
/*  53:    */     try
/*  54:    */     {
/*  55: 55 */       calendarChooserBuilder = new FileChooserBuilder(CalendarDocumentManager.class);
/*  56: 56 */       calendarChooserBuilder.setFileFilter(new FileNameExtensionFilter("Xml files", new String[] { "xml" }));
/*  57: 57 */       XML_GENERIC_WS_CONTEXT = JAXBContext.newInstance(new Class[] { XmlGenericWorkspace.class });
/*  58: 58 */       XML_WS_CONTEXT = JAXBContext.newInstance(new Class[] { XmlWorkspace.class });
/*  59:    */     } catch (JAXBException ex) {
/*  60: 60 */       throw Throwables.propagate(ex);
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */ 
/*  65:    */   public FileRepository()
/*  66:    */   {
/*  67: 67 */     repositoryLookup = Lookup.getDefault().lookupResult(IWorkspaceItemRepository.class);
/*  68: 68 */     fileChooserBuilder = new FileChooserBuilder(FileRepository.class);
/*  69: 69 */     fileChooserBuilder.setFileFilter(new FileNameExtensionFilter("Xml files", new String[] { "xml" }));
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static DataSource encode(File file) {
/*  73: 73 */     DataSource.Builder builder = DataSource.builder("File", "20120925");
/*  74: 74 */     if (file != null) {
/*  75: 75 */       String sfile = file.getAbsolutePath();
/*  76: 76 */       sfile = Paths.changeExtension(sfile, "xml");
/*  77: 77 */       builder.put("fileName", sfile);
/*  78:    */     }
/*  79: 79 */     return builder.build();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static File decode(DataSource source) {
/*  83: 83 */     if (!source.getProviderName().equals("File")) {
/*  84: 84 */       return null;
/*  85:    */     }
/*  86: 86 */     if (source.getVersion().equals("20120925")) {
/*  87: 87 */       String file = source.get("fileName");
/*  88: 88 */       if (file != null) {
/*  89: 89 */         return new File(file);
/*  90:    */       }
/*  91:    */     }
/*  92: 92 */     return null;
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static String path() {
/*  96: 96 */     File documents = DesktopManager.get().getKnownFolder(Desktop.KnownFolder.DOCUMENTS);
/*  97: 97 */     if (documents == null)
/*  98:    */     {
/*  99: 99 */       documents = new File(StandardSystemProperty.USER_HOME.value());
/* 100:    */     }
/* 101:101 */     File def = new File(documents, "Demetra+");
/* 102:102 */     if (!def.exists()) {
/* 103:103 */       def.mkdirs();
/* 104:    */     }
/* 105:105 */     return def.getAbsolutePath(); }
/* 106:    */   
/* 107:107 */   private static String defPath = path();
/* 108:    */   private static final String CALENDARS_REPOSITORY = "Calendars";
/* 109:    */   private static final String CALENDARS = "Calendars.xml";
/* 110:    */   
/* 111:111 */   public String getName() { return "File"; }
/* 112:    */   
/* 113:    */ 
/* 114:    */   public DataSource getDefaultDataSource()
/* 115:    */   {
/* 116:116 */     return encode(null);
/* 117:    */   }
/* 118:    */   
/* 119:    */ 
/* 120:    */   public Object getProperties()
/* 121:    */   {
/* 122:122 */     return null;
/* 123:    */   }
/* 124:    */   
/* 125:    */ 
/* 126:    */   private static final String VARIABLES_REPOSITORY = "Variables";
/* 127:    */   private static final String VARIABLES = "Variables.xml";
/* 128:    */   public void setProperties() {}
/* 129:    */   
/* 130:    */   public boolean saveAs(Workspace ws)
/* 131:    */   {
/* 132:132 */     File file = fileChooserBuilder.showSaveDialog();
/* 133:133 */     if (file != null) {
/* 134:    */       try {
/* 135:135 */         ws.loadAll();
/* 136:136 */         ws.setName(Paths.changeExtension(file.getName(), null));
/* 137:137 */         ws.setDataSource(encode(file));
/* 138:138 */         return save(ws, true);
/* 139:    */       } catch (Exception ex) {
/* 140:140 */         return false;
/* 141:    */       }
/* 142:    */     }
/* 143:143 */     return false;
/* 144:    */   }
/* 145:    */   
/* 146:    */   /* Error */
/* 147:    */   protected boolean saveWorkspace(Workspace ws)
/* 148:    */   {
/* 149:    */     // Byte code:
/* 150:    */     //   0: aload_1
/* 151:    */     //   1: invokevirtual 255	ec/nbdemetra/ws/Workspace:getDataSource	()Lec/tss/tsproviders/DataSource;
/* 152:    */     //   4: invokestatic 258	ec/nbdemetra/ws/FileRepository:decode	(Lec/tss/tsproviders/DataSource;)Ljava/io/File;
/* 153:    */     //   7: astore_2
/* 154:    */     //   8: aload_2
/* 155:    */     //   9: ifnonnull +9 -> 18
/* 156:    */     //   12: aload_0
/* 157:    */     //   13: aload_1
/* 158:    */     //   14: invokevirtual 260	ec/nbdemetra/ws/FileRepository:saveAs	(Lec/nbdemetra/ws/Workspace;)Z
/* 159:    */     //   17: ireturn
/* 160:    */     //   18: aconst_null
/* 161:    */     //   19: astore_3
/* 162:    */     //   20: aconst_null
/* 163:    */     //   21: astore 4
/* 164:    */     //   23: new 262	java/io/FileOutputStream
/* 165:    */     //   26: dup
/* 166:    */     //   27: aload_2
/* 167:    */     //   28: invokespecial 264	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/* 168:    */     //   31: astore 5
/* 169:    */     //   33: aconst_null
/* 170:    */     //   34: astore 6
/* 171:    */     //   36: aconst_null
/* 172:    */     //   37: astore 7
/* 173:    */     //   39: new 267	java/io/OutputStreamWriter
/* 174:    */     //   42: dup
/* 175:    */     //   43: aload 5
/* 176:    */     //   45: getstatic 269	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/* 177:    */     //   48: invokespecial 275	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
/* 178:    */     //   51: astore 8
/* 179:    */     //   53: getstatic 79	ec/nbdemetra/ws/FileRepository:XML_GENERIC_WS_CONTEXT	Ljavax/xml/bind/JAXBContext;
/* 180:    */     //   56: invokevirtual 278	javax/xml/bind/JAXBContext:createMarshaller	()Ljavax/xml/bind/Marshaller;
/* 181:    */     //   59: astore 9
/* 182:    */     //   61: aload 9
/* 183:    */     //   63: ldc_w 282
/* 184:    */     //   66: iconst_1
/* 185:    */     //   67: invokestatic 284	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
/* 186:    */     //   70: invokeinterface 290 3 0
/* 187:    */     //   75: new 71	ec/nbdemetra/ws/xml/XmlGenericWorkspace
/* 188:    */     //   78: dup
/* 189:    */     //   79: invokespecial 296	ec/nbdemetra/ws/xml/XmlGenericWorkspace:<init>	()V
/* 190:    */     //   82: astore 10
/* 191:    */     //   84: aload 10
/* 192:    */     //   86: aload_1
/* 193:    */     //   87: invokevirtual 297	ec/nbdemetra/ws/xml/XmlGenericWorkspace:from	(Lec/nbdemetra/ws/Workspace;)Z
/* 194:    */     //   90: ifne +25 -> 115
/* 195:    */     //   93: aload 8
/* 196:    */     //   95: ifnull +8 -> 103
/* 197:    */     //   98: aload 8
/* 198:    */     //   100: invokevirtual 300	java/io/OutputStreamWriter:close	()V
/* 199:    */     //   103: aload 5
/* 200:    */     //   105: ifnull +8 -> 113
/* 201:    */     //   108: aload 5
/* 202:    */     //   110: invokevirtual 303	java/io/FileOutputStream:close	()V
/* 203:    */     //   113: iconst_0
/* 204:    */     //   114: ireturn
/* 205:    */     //   115: aload 9
/* 206:    */     //   117: aload 10
/* 207:    */     //   119: aload 8
/* 208:    */     //   121: invokeinterface 304 3 0
/* 209:    */     //   126: aload_1
/* 210:    */     //   127: invokevirtual 308	ec/nbdemetra/ws/Workspace:resetDirty	()V
/* 211:    */     //   130: aload 8
/* 212:    */     //   132: invokevirtual 311	java/io/OutputStreamWriter:flush	()V
/* 213:    */     //   135: aload_0
/* 214:    */     //   136: aload_1
/* 215:    */     //   137: invokespecial 314	ec/nbdemetra/ws/FileRepository:saveContext	(Lec/nbdemetra/ws/Workspace;)V
/* 216:    */     //   140: aload 8
/* 217:    */     //   142: ifnull +8 -> 150
/* 218:    */     //   145: aload 8
/* 219:    */     //   147: invokevirtual 300	java/io/OutputStreamWriter:close	()V
/* 220:    */     //   150: aload 5
/* 221:    */     //   152: ifnull +8 -> 160
/* 222:    */     //   155: aload 5
/* 223:    */     //   157: invokevirtual 303	java/io/FileOutputStream:close	()V
/* 224:    */     //   160: iconst_1
/* 225:    */     //   161: ireturn
/* 226:    */     //   162: astore 6
/* 227:    */     //   164: aload 8
/* 228:    */     //   166: ifnull +8 -> 174
/* 229:    */     //   169: aload 8
/* 230:    */     //   171: invokevirtual 300	java/io/OutputStreamWriter:close	()V
/* 231:    */     //   174: aload 6
/* 232:    */     //   176: athrow
/* 233:    */     //   177: astore 7
/* 234:    */     //   179: aload 6
/* 235:    */     //   181: ifnonnull +10 -> 191
/* 236:    */     //   184: aload 7
/* 237:    */     //   186: astore 6
/* 238:    */     //   188: goto +17 -> 205
/* 239:    */     //   191: aload 6
/* 240:    */     //   193: aload 7
/* 241:    */     //   195: if_acmpeq +10 -> 205
/* 242:    */     //   198: aload 6
/* 243:    */     //   200: aload 7
/* 244:    */     //   202: invokevirtual 318	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 245:    */     //   205: aload 6
/* 246:    */     //   207: athrow
/* 247:    */     //   208: astore_3
/* 248:    */     //   209: aload 5
/* 249:    */     //   211: ifnull +8 -> 219
/* 250:    */     //   214: aload 5
/* 251:    */     //   216: invokevirtual 303	java/io/FileOutputStream:close	()V
/* 252:    */     //   219: aload_3
/* 253:    */     //   220: athrow
/* 254:    */     //   221: astore 4
/* 255:    */     //   223: aload_3
/* 256:    */     //   224: ifnonnull +9 -> 233
/* 257:    */     //   227: aload 4
/* 258:    */     //   229: astore_3
/* 259:    */     //   230: goto +15 -> 245
/* 260:    */     //   233: aload_3
/* 261:    */     //   234: aload 4
/* 262:    */     //   236: if_acmpeq +9 -> 245
/* 263:    */     //   239: aload_3
/* 264:    */     //   240: aload 4
/* 265:    */     //   242: invokevirtual 318	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 266:    */     //   245: aload_3
/* 267:    */     //   246: athrow
/* 268:    */     //   247: astore_3
/* 269:    */     //   248: iconst_0
/* 270:    */     //   249: ireturn
/* 271:    */     // Line number table:
/* 272:    */     //   Java source line #148	-> byte code offset #0
/* 273:    */     //   Java source line #149	-> byte code offset #8
/* 274:    */     //   Java source line #150	-> byte code offset #12
/* 275:    */     //   Java source line #152	-> byte code offset #18
/* 276:    */     //   Java source line #152	-> byte code offset #23
/* 277:    */     //   Java source line #154	-> byte code offset #33
/* 278:    */     //   Java source line #154	-> byte code offset #39
/* 279:    */     //   Java source line #156	-> byte code offset #53
/* 280:    */     //   Java source line #157	-> byte code offset #61
/* 281:    */     //   Java source line #158	-> byte code offset #75
/* 282:    */     //   Java source line #159	-> byte code offset #84
/* 283:    */     //   Java source line #167	-> byte code offset #93
/* 284:    */     //   Java source line #168	-> byte code offset #103
/* 285:    */     //   Java source line #160	-> byte code offset #113
/* 286:    */     //   Java source line #162	-> byte code offset #115
/* 287:    */     //   Java source line #163	-> byte code offset #126
/* 288:    */     //   Java source line #164	-> byte code offset #130
/* 289:    */     //   Java source line #165	-> byte code offset #135
/* 290:    */     //   Java source line #167	-> byte code offset #140
/* 291:    */     //   Java source line #168	-> byte code offset #150
/* 292:    */     //   Java source line #166	-> byte code offset #160
/* 293:    */     //   Java source line #167	-> byte code offset #164
/* 294:    */     //   Java source line #168	-> byte code offset #209
/* 295:    */     //   Java source line #169	-> byte code offset #248
/* 296:    */     // Local variable table:
/* 297:    */     //   start	length	slot	name	signature
/* 298:    */     //   0	250	0	this	FileRepository
/* 299:    */     //   0	250	1	ws	Workspace
/* 300:    */     //   7	21	2	file	File
/* 301:    */     //   19	1	3	localObject1	Object
/* 302:    */     //   208	16	3	localObject2	Object
/* 303:    */     //   229	17	3	localObject3	Object
/* 304:    */     //   247	2	3	ex	Exception
/* 305:    */     //   21	1	4	localObject4	Object
/* 306:    */     //   221	20	4	localThrowable1	java.lang.Throwable
/* 307:    */     //   31	184	5	stream	java.io.FileOutputStream
/* 308:    */     //   34	1	6	localObject5	Object
/* 309:    */     //   162	18	6	localObject6	Object
/* 310:    */     //   186	20	6	localObject7	Object
/* 311:    */     //   37	1	7	localObject8	Object
/* 312:    */     //   177	24	7	localThrowable2	java.lang.Throwable
/* 313:    */     //   51	119	8	writer	java.io.OutputStreamWriter
/* 314:    */     //   59	57	9	marshaller	javax.xml.bind.Marshaller
/* 315:    */     //   82	36	10	xws	XmlGenericWorkspace
/* 316:    */     // Exception table:
/* 317:    */     //   from	to	target	type
/* 318:    */     //   53	93	162	finally
/* 319:    */     //   103	140	162	finally
/* 320:    */     //   150	162	162	finally
/* 321:    */     //   39	177	177	finally
/* 322:    */     //   33	103	208	finally
/* 323:    */     //   113	150	208	finally
/* 324:    */     //   160	208	208	finally
/* 325:    */     //   23	221	221	finally
/* 326:    */     //   18	113	247	java/lang/Exception
/* 327:    */     //   115	160	247	java/lang/Exception
/* 328:    */     //   162	247	247	java/lang/Exception
/* 329:    */   }
/* 330:    */   
/* 331:    */   protected boolean deleteWorkspace(Workspace ws)
/* 332:    */   {
/* 333:176 */     return false;
/* 334:    */   }
/* 335:    */   
/* 336:    */   public Workspace open()
/* 337:    */   {
/* 338:181 */     File file = fileChooserBuilder.showOpenDialog();
/* 339:182 */     if (file != null) {
/* 340:183 */       Workspace ws = new Workspace(encode(file), Paths.changeExtension(file.getName(), null));
/* 341:184 */       if (!load(ws)) {
/* 342:185 */         NotifyDescriptor nd = new NotifyDescriptor.Message(file.getName() + " is not a valid workspace!");
/* 343:186 */         DialogDisplayer.getDefault().notify(nd);
/* 344:187 */         return null;
/* 345:    */       }
/* 346:189 */       return ws;
/* 347:    */     }
/* 348:    */     
/* 349:192 */     return null;
/* 350:    */   }
/* 351:    */   
/* 352:    */   public boolean load(Workspace ws)
/* 353:    */   {
/* 354:197 */     if (!(ws.getRepository() instanceof FileRepository)) {
/* 355:198 */       return false;
/* 356:    */     }
/* 357:200 */     if (loadWorkspace(ws)) {
/* 358:201 */       loadContext(ws);
/* 359:202 */       return true;
/* 360:    */     }
/* 361:204 */     if (loadLegacyWorkspace(ws)) {
/* 362:205 */       loadContext(ws);
/* 363:206 */       return true;
/* 364:    */     }
/* 365:208 */     return false;
/* 366:    */   }
/* 367:    */   
/* 368:    */   private boolean loadLegacyWorkspace(Workspace ws) {
/* 369:212 */     File file = decode(ws.getDataSource());
/* 370:    */     try {
/* 371:214 */       Unmarshaller unmarshaller = XML_WS_CONTEXT.createUnmarshaller();
/* 372:215 */       XmlWorkspace xws = (XmlWorkspace)unmarshaller.unmarshal(file);
/* 373:216 */       if (xws == null) {
/* 374:217 */         return false;
/* 375:    */       }
/* 376:219 */       if (!xws.load(ws)) {
/* 377:220 */         return false;
/* 378:    */       }
/* 379:222 */       ws.resetDirty();
/* 380:223 */       return true;
/* 381:    */     } catch (Exception ex) {}
/* 382:225 */     return false;
/* 383:    */   }
/* 384:    */   
/* 385:    */   private boolean loadWorkspace(Workspace ws)
/* 386:    */   {
/* 387:230 */     File file = decode(ws.getDataSource());
/* 388:    */     try {
/* 389:232 */       Unmarshaller unmarshaller = XML_GENERIC_WS_CONTEXT.createUnmarshaller();
/* 390:233 */       XmlGenericWorkspace xws = (XmlGenericWorkspace)unmarshaller.unmarshal(file);
/* 391:234 */       if (xws == null) {
/* 392:235 */         return false;
/* 393:    */       }
/* 394:237 */       if (!xws.to(ws)) {
/* 395:238 */         return false;
/* 396:    */       }
/* 397:240 */       ws.resetDirty();
/* 398:241 */       return true;
/* 399:    */     } catch (Exception ex) {}
/* 400:243 */     return false;
/* 401:    */   }
/* 402:    */   
/* 403:    */   public static String getRepositoryRootFolder(Workspace ws)
/* 404:    */   {
/* 405:248 */     File id = decode(ws.getDataSource());
/* 406:249 */     if (id == null) {
/* 407:250 */       return Paths.concatenate(defPath, ws.getName());
/* 408:    */     }
/* 409:252 */     return Paths.changeExtension(id.getAbsolutePath(), null);
/* 410:    */   }
/* 411:    */   
/* 412:    */   public static String getRepositoryFolder(Workspace ws, String repository, boolean create)
/* 413:    */   {
/* 414:257 */     String root = getRepositoryRootFolder(ws);
/* 415:258 */     File frepo = new File(root, repository);
/* 416:259 */     if ((frepo.exists()) && (!frepo.isDirectory())) {
/* 417:260 */       return null;
/* 418:    */     }
/* 419:262 */     if ((!frepo.exists()) && (create)) {
/* 420:263 */       frepo.mkdirs();
/* 421:    */     }
/* 422:265 */     return frepo.getAbsolutePath();
/* 423:    */   }
/* 424:    */   
/* 425:    */   public Collection<Class> getSupportedTypes()
/* 426:    */   {
/* 427:270 */     throw new UnsupportedOperationException("Not supported yet.");
/* 428:    */   }
/* 429:    */   
/* 430:    */   public void initialize()
/* 431:    */   {
/* 432:275 */     for (IWorkspaceItemRepository fac : repositoryLookup.allInstances()) {
/* 433:276 */       register(fac.getSupportedType(), fac);
/* 434:    */     }
/* 435:    */   }
/* 436:    */   
/* 437:    */   public void resultChanged(LookupEvent le)
/* 438:    */   {
/* 439:282 */     initialize();
/* 440:    */   }
/* 441:    */   
/* 442:    */   private void loadContext(Workspace ws) {
/* 443:286 */     loadCalendars(ws, getCalendarsFile(ws, false));
/* 444:287 */     loadVariables(ws, getVariablesFile(ws, false));
/* 445:288 */     ws.getContext().resetDirty();
/* 446:    */   }
/* 447:    */   
/* 448:    */   private void saveContext(Workspace ws) {
/* 449:292 */     saveCalendars(ws, getCalendarsFile(ws, true));
/* 450:293 */     ws.getContext().resetDirty();
/* 451:    */   }
/* 452:    */   
/* 453:    */   public static void importCalendars(Workspace ws) {
/* 454:297 */     File file = calendarChooserBuilder.showOpenDialog();
/* 455:298 */     if (file != null) {
/* 456:299 */       loadCalendars(ws, file.getAbsolutePath());
/* 457:    */     }
/* 458:    */   }
/* 459:    */   
/* 460:    */   public static boolean loadCalendars(Workspace ws, String file) {
/* 461:304 */     GregorianCalendarManager wsMgr = ws.getContext().getGregorianCalendars();
/* 462:305 */     ec.tss.xml.calendar.XmlCalendars xml = (ec.tss.xml.calendar.XmlCalendars)AbstractFileItemRepository.loadXmlLegacy(file, ec.tss.xml.calendar.XmlCalendars.class);
/* 463:306 */     if (xml != null) {
/* 464:307 */       xml.copyTo(wsMgr);
/* 465:    */     }
/* 466:    */     else {
/* 467:310 */       ec.tss.xml.legacy.XmlCalendars oxml = (ec.tss.xml.legacy.XmlCalendars)AbstractFileItemRepository.loadXmlLegacy(file, ec.tss.xml.legacy.XmlCalendars.class);
/* 468:311 */       if (oxml != null) {
/* 469:312 */         oxml.copyTo(wsMgr);
/* 470:    */       } else {
/* 471:314 */         return false;
/* 472:    */       }
/* 473:    */     }
/* 474:317 */     for (String s : wsMgr.getNames()) {
/* 475:318 */       IGregorianCalendarProvider cal = (IGregorianCalendarProvider)wsMgr.get(s);
/* 476:319 */       if (ws.searchDocument(cal) == null) {
/* 477:320 */         WorkspaceItem<IGregorianCalendarProvider> item = WorkspaceItem.system(CalendarDocumentManager.ID, s, cal);
/* 478:321 */         ws.add(item);
/* 479:    */       }
/* 480:    */     }
/* 481:324 */     return true;
/* 482:    */   }
/* 483:    */   
/* 484:    */   public static boolean loadVariables(Workspace ws, String file) {
/* 485:328 */     NameManager<TsVariables> wsMgr = ws.getContext().getTsVariableManagers();
/* 486:329 */     TsVariables mgr = (TsVariables)AbstractFileItemRepository.loadLegacy(file, XmlTsVariables.class);
/* 487:330 */     if (mgr != null) {
/* 488:331 */       wsMgr.set("legacy", mgr);
/* 489:332 */       return true;
/* 490:    */     }
/* 491:334 */     return false;
/* 492:    */   }
/* 493:    */   
/* 494:    */   public static boolean saveCalendars(Workspace ws, String file)
/* 495:    */   {
/* 496:339 */     GregorianCalendarManager wsMgr = ws.getContext().getGregorianCalendars();
/* 497:340 */     return AbstractFileItemRepository.saveLegacy(file, wsMgr, ec.tss.xml.calendar.XmlCalendars.class);
/* 498:    */   }
/* 499:    */   
/* 500:    */   private static String getCalendarsFile(Workspace ws, boolean create) {
/* 501:344 */     String folder = getRepositoryFolder(ws, "Calendars", create);
/* 502:345 */     return Paths.concatenate(folder, "Calendars.xml");
/* 503:    */   }
/* 504:    */   
/* 505:    */ 
/* 506:    */   private static String getVariablesFile(Workspace ws, boolean create)
/* 507:    */   {
/* 508:351 */     String folder = getRepositoryFolder(ws, "Variables", create);
/* 509:352 */     return Paths.concatenate(folder, "Variables.xml");
/* 510:    */   }
/* 511:    */ }
