/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import javax.swing.Icon;
/*  6:   */ import javax.swing.ImageIcon;
/*  7:   */ import org.openide.util.ImageUtilities;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public enum DemetraUiIcon
/* 17:   */   implements Icon
/* 18:   */ {
/* 19:19 */   COLOR_SWATCH_16("color-swatch_16x16.png"), 
/* 20:20 */   DOCUMENT_PRINT_16("document-print_16x16.png"), 
/* 21:21 */   EDIT_CLEAR_16("edit-clear_16x16.png"), 
/* 22:22 */   EDIT_COPY_16("edit-copy_16x16.png"), 
/* 23:23 */   SORT_DATE_DESCENDING_16("sort-date-descending_16x16.png"), 
/* 24:24 */   SORT_DATE_16("sort-date_16x16.png"), 
/* 25:25 */   TABLE_RELATION_16("tables-relation_16x16.png"), 
/* 26:26 */   HORIZONTAL_16("horizontal_16x16.png"), 
/* 27:27 */   VERTICAL_16("vertical_16x16.png"), 
/* 28:28 */   GO_DOWN_16("go-down_16x16.png"), 
/* 29:29 */   GO_UP_16("go-up_16x16.png"), 
/* 30:30 */   LIST_ADD_16("list-add_16x16.png"), 
/* 31:31 */   LIST_REMOVE_16("list-remove_16x16.png"), 
/* 32:32 */   PUZZLE_16("puzzle_16x16.png"), 
/* 33:33 */   COMPILE_16("compile_16x16.png"), 
/* 34:34 */   DOCUMENT_16("document_16x16.png"), 
/* 35:35 */   DELETE_16("delete_16x16.png"), 
/* 36:36 */   LOCALE_ALTERNATE_16("locale-alternate_16x16.png"), 
/* 37:37 */   DOCUMENT_TASK_16("document-task_16x16.png"), 
/* 38:38 */   CALENDAR_16("calendar_16x16.png"), 
/* 39:39 */   CLIPBOARD_PASTE_DOCUMENT_TEXT_16("clipboard-paste-document-text_16x16.png"), 
/* 40:40 */   MAGNIFYING_TOOL("zoom_16x16.png"), 
/* 41:41 */   NB_CHECK_LAST_16("nb-check-last_16x16.png"), 
/* 42:42 */   PREFERENCES("preferences-system_16x16.png"), 
/* 43:43 */   EXCLAMATION_MARK_16("nodes/exclamation-red.png"), 
/* 44:44 */   BLOG_16("blog_16x16.png"), 
/* 45:45 */   WARNING("nodes/warning.png");
/* 46:   */   
/* 47:   */   final String path;
/* 48:   */   
/* 49:   */   private DemetraUiIcon(String path) {
/* 50:50 */     this.path = ("ec/nbdemetra/ui/" + path);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public ImageIcon getImageIcon() {
/* 54:54 */     return ImageUtilities.loadImageIcon(path, true);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void paintIcon(Component c, Graphics g, int x, int y)
/* 58:   */   {
/* 59:59 */     getImageIcon().paintIcon(c, g, x, y);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public int getIconWidth()
/* 63:   */   {
/* 64:64 */     return getImageIcon().getIconWidth();
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int getIconHeight()
/* 68:   */   {
/* 69:69 */     return getImageIcon().getIconHeight();
/* 70:   */   }
/* 71:   */ }
