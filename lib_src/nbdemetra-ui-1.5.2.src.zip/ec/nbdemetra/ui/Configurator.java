/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import javax.annotation.Nonnull;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ public abstract class Configurator<R>
/* 24:   */ {
/* 25:   */   @Nonnull
/* 26:   */   public abstract Config getConfig(@Nonnull R paramR);
/* 27:   */   
/* 28:   */   public abstract void setConfig(@Nonnull R paramR, @Nonnull Config paramConfig)
/* 29:   */     throws IllegalArgumentException;
/* 30:   */   
/* 31:   */   @Nonnull
/* 32:   */   public abstract Config editConfig(@Nonnull Config paramConfig)
/* 33:   */     throws IllegalArgumentException;
/* 34:   */   
/* 35:   */   @Nonnull
/* 36:   */   public IConfigurable toConfigurable(@Nonnull R resource)
/* 37:   */   {
/* 38:38 */     return new ConfigurableImpl(this, resource);
/* 39:   */   }
/* 40:   */   
/* 41:   */   private static final class ConfigurableImpl<R> implements IConfigurable
/* 42:   */   {
/* 43:   */     private final Configurator<R> support;
/* 44:   */     private final R resource;
/* 45:   */     
/* 46:   */     public ConfigurableImpl(Configurator<R> support, R resource)
/* 47:   */     {
/* 48:48 */       this.support = support;
/* 49:49 */       this.resource = resource;
/* 50:   */     }
/* 51:   */     
/* 52:   */     public Config getConfig()
/* 53:   */     {
/* 54:54 */       return support.getConfig(resource);
/* 55:   */     }
/* 56:   */     
/* 57:   */     public void setConfig(Config config) throws IllegalArgumentException
/* 58:   */     {
/* 59:59 */       support.setConfig(resource, config);
/* 60:   */     }
/* 61:   */     
/* 62:   */     public Config editConfig(Config config) throws IllegalArgumentException
/* 63:   */     {
/* 64:64 */       return support.editConfig(config);
/* 65:   */     }
/* 66:   */   }
/* 67:   */ }
