/*  1:   */ package ec.nbdemetra.ui.calendars.actions;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Converter;
/*  4:   */ import ec.nbdemetra.ui.Config;
/*  5:   */ import ec.nbdemetra.ui.Config.Builder;
/*  6:   */ import ec.tss.tsproviders.utils.Formatters;
/*  7:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  8:   */ import ec.tss.tsproviders.utils.Parsers;
/*  9:   */ import ec.tss.tsproviders.utils.Parsers.Parser;
/* 10:   */ import ec.tss.xml.calendar.AbstractXmlCalendar;
/* 11:   */ import ec.tss.xml.calendar.XmlChainedCalendar;
/* 12:   */ import ec.tss.xml.calendar.XmlCompositeCalendar;
/* 13:   */ import ec.tss.xml.calendar.XmlNationalCalendar;
/* 14:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/* 15:   */ import ec.tstoolkit.timeseries.calendars.ChainedGregorianCalendarProvider;
/* 16:   */ import ec.tstoolkit.timeseries.calendars.CompositeGregorianCalendarProvider;
/* 17:   */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/* 18:   */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/* 19:   */ import ec.tstoolkit.timeseries.calendars.NationalCalendarProvider;
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ final class CalendarConfig
/* 38:   */   extends Converter<IGregorianCalendarProvider, Config>
/* 39:   */ {
/* 40:40 */   public static final String DOMAIN = AbstractXmlCalendar.class.getName();
/* 41:   */   
/* 42:42 */   private final Formatters.Formatter<XmlNationalCalendar> nationalFormatter = Formatters.onJAXB(XmlNationalCalendar.class, false);
/* 43:43 */   private final Formatters.Formatter<XmlChainedCalendar> chainedFormatter = Formatters.onJAXB(XmlChainedCalendar.class, false);
/* 44:44 */   private final Formatters.Formatter<XmlCompositeCalendar> compositeFormatter = Formatters.onJAXB(XmlCompositeCalendar.class, false);
/* 45:   */   
/* 46:46 */   private final Parsers.Parser<XmlNationalCalendar> nationalParser = Parsers.onJAXB(XmlNationalCalendar.class);
/* 47:47 */   private final Parsers.Parser<XmlChainedCalendar> chainedParser = Parsers.onJAXB(XmlChainedCalendar.class);
/* 48:48 */   private final Parsers.Parser<XmlCompositeCalendar> compositeParser = Parsers.onJAXB(XmlCompositeCalendar.class);
/* 49:   */   
/* 50:   */   protected Config doForward(IGregorianCalendarProvider cal)
/* 51:   */   {
/* 52:52 */     GregorianCalendarManager manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/* 53:53 */     Config.Builder result = Config.builder(DOMAIN, manager.get(cal), "");
/* 54:54 */     String code = manager.get(cal);
/* 55:55 */     result.put("type", cal.getClass().getName());
/* 56:56 */     String xml = format(cal, code, manager);
/* 57:57 */     if (xml == null) {
/* 58:58 */       throw new RuntimeException("Cannot format calendar");
/* 59:   */     }
/* 60:60 */     result.put("xml", xml);
/* 61:61 */     return result.build();
/* 62:   */   }
/* 63:   */   
/* 64:   */   private String format(IGregorianCalendarProvider cal, String code, GregorianCalendarManager manager) {
/* 65:65 */     if ((cal instanceof NationalCalendarProvider))
/* 66:66 */       return nationalFormatter.formatAsString(XmlNationalCalendar.create(code, manager));
/* 67:67 */     if ((cal instanceof ChainedGregorianCalendarProvider))
/* 68:68 */       return chainedFormatter.formatAsString(XmlChainedCalendar.create(code, manager));
/* 69:69 */     if ((cal instanceof CompositeGregorianCalendarProvider)) {
/* 70:70 */       return compositeFormatter.formatAsString(XmlCompositeCalendar.create(code, manager));
/* 71:   */     }
/* 72:72 */     return null;
/* 73:   */   }
/* 74:   */   
/* 75:   */   protected IGregorianCalendarProvider doBackward(Config config)
/* 76:   */   {
/* 77:77 */     GregorianCalendarManager manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/* 78:78 */     AbstractXmlCalendar xmlCal = parse(config.get("type"), config.get("xml"));
/* 79:79 */     if (xmlCal != null) {
/* 80:80 */       if (xmlCal.addTo(manager)) {
/* 81:81 */         return (IGregorianCalendarProvider)manager.get(name);
/* 82:   */       }
/* 83:83 */       throw new IllegalArgumentException("Cannot add calendar to manager");
/* 84:   */     }
/* 85:85 */     throw new IllegalArgumentException("Cannot parse config");
/* 86:   */   }
/* 87:   */   
/* 88:   */   private AbstractXmlCalendar parse(String type, String xml) {
/* 89:89 */     if (NationalCalendarProvider.class.getName().equals(type))
/* 90:90 */       return (AbstractXmlCalendar)nationalParser.parse(xml);
/* 91:91 */     if (ChainedGregorianCalendarProvider.class.getName().equals(type))
/* 92:92 */       return (AbstractXmlCalendar)chainedParser.parse(xml);
/* 93:93 */     if (CompositeGregorianCalendarProvider.class.getName().equals(type)) {
/* 94:94 */       return (AbstractXmlCalendar)compositeParser.parse(xml);
/* 95:   */     }
/* 96:96 */     return null;
/* 97:   */   }
/* 98:   */ }
