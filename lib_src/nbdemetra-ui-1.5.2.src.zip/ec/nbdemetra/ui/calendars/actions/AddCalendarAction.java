/*   1:    */ package ec.nbdemetra.ui.calendars.actions;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.calendars.CalendarDocumentManager;
/*   4:    */ import ec.nbdemetra.ws.Workspace;
/*   5:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   6:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*   7:    */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*   8:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*   9:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import javax.swing.AbstractAction;
/*  12:    */ import javax.swing.JMenuItem;
/*  13:    */ import org.openide.util.actions.Presenter.Menu;
/*  14:    */ import org.openide.util.actions.Presenter.Popup;
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ public final class AddCalendarAction
/*  42:    */   extends AbstractAction
/*  43:    */   implements Presenter.Popup, Presenter.Menu
/*  44:    */ {
/*  45:    */   public void actionPerformed(ActionEvent ae)
/*  46:    */   {
/*  47: 47 */     throw new UnsupportedOperationException("Not supported yet.");
/*  48:    */   }
/*  49:    */   
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */   public JMenuItem getMenuPresenter()
/*  56:    */   {
/*  57: 57 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n\t无法解析 Bundle\n\t无法解析 Bundle\n\t无法解析 Bundle\n");
/*  58:    */   }
/*  59:    */   
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */   public JMenuItem getPopupPresenter()
/*  80:    */   {
/*  81: 81 */     return getMenuPresenter();
/*  82:    */   }
/*  83:    */   
/*  84:    */   static IGregorianCalendarProvider getProvider(ItemWsNode activatedNode) {
/*  85: 85 */     WorkspaceItem<IGregorianCalendarProvider> tmp = activatedNode.getItem(IGregorianCalendarProvider.class);
/*  86: 86 */     return tmp != null ? (IGregorianCalendarProvider)tmp.getElement() : null;
/*  87:    */   }
/*  88:    */   
/*  89:    */   static void add(GregorianCalendarManager manager, String name, IGregorianCalendarProvider p) {
/*  90: 90 */     manager.set(name, p);
/*  91: 91 */     WorkspaceFactory.getInstance().getActiveWorkspace().add(CalendarDocumentManager.systemItem(name, p));
/*  92:    */   }
/*  93:    */   
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */   static void addNationalCalendar(GregorianCalendarManager paramGregorianCalendarManager)
/*  99:    */   {
/* 100:100 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */   static void addChainedCalendar(GregorianCalendarManager paramGregorianCalendarManager)
/* 114:    */   {
/* 115:115 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 116:    */   }
/* 117:    */   
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */   static void addCompositeCalendar(GregorianCalendarManager paramGregorianCalendarManager)
/* 129:    */   {
/* 130:130 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 131:    */   }
/* 132:    */ }
