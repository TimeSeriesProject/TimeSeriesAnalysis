/*   1:    */ package ec.nbdemetra.ui.calendars.actions;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*   4:    */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*   5:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*   6:    */ import ec.tstoolkit.timeseries.calendars.ChainedGregorianCalendarProvider;
/*   7:    */ import ec.tstoolkit.timeseries.calendars.CompositeGregorianCalendarProvider;
/*   8:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*   9:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  10:    */ import ec.tstoolkit.timeseries.calendars.NationalCalendarProvider;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ public final class CloneCalendarAction
/*  34:    */   extends SingleNodeAction<ItemWsNode>
/*  35:    */ {
/*  36:    */   public CloneCalendarAction()
/*  37:    */   {
/*  38: 38 */     super(ItemWsNode.class);
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected void performAction(ItemWsNode activatedNode)
/*  42:    */   {
/*  43: 43 */     GregorianCalendarManager manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/*  44: 44 */     IGregorianCalendarProvider o = AddCalendarAction.getProvider(activatedNode);
/*  45: 45 */     if ((o instanceof NationalCalendarProvider)) {
/*  46: 46 */       cloneNationalCalendar(manager, (NationalCalendarProvider)o, activatedNode);
/*  47: 47 */     } else if ((o instanceof ChainedGregorianCalendarProvider)) {
/*  48: 48 */       cloneChainedCalendar(manager, (ChainedGregorianCalendarProvider)o, activatedNode);
/*  49: 49 */     } else if ((o instanceof CompositeGregorianCalendarProvider)) {
/*  50: 50 */       cloneCompositeCalendar(manager, (CompositeGregorianCalendarProvider)o, activatedNode);
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   protected boolean enable(ItemWsNode activatedNode)
/*  55:    */   {
/*  56: 56 */     IGregorianCalendarProvider o = AddCalendarAction.getProvider(activatedNode);
/*  57: 57 */     return ((o instanceof NationalCalendarProvider)) || 
/*  58: 58 */       ((o instanceof ChainedGregorianCalendarProvider)) || 
/*  59: 59 */       ((o instanceof CompositeGregorianCalendarProvider));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public String getName()
/*  63:    */   {
/*  64: 64 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  65:    */   }
/*  66:    */   
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */   static void cloneNationalCalendar(GregorianCalendarManager paramGregorianCalendarManager, NationalCalendarProvider paramNationalCalendarProvider, ItemWsNode paramItemWsNode)
/*  74:    */   {
/*  75: 75 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  76:    */   }
/*  77:    */   
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */   static void cloneChainedCalendar(GregorianCalendarManager paramGregorianCalendarManager, ChainedGregorianCalendarProvider paramChainedGregorianCalendarProvider, ItemWsNode paramItemWsNode)
/*  91:    */   {
/*  92: 92 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  93:    */   }
/*  94:    */   
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */   static void cloneCompositeCalendar(GregorianCalendarManager paramGregorianCalendarManager, CompositeGregorianCalendarProvider paramCompositeGregorianCalendarProvider, ItemWsNode paramItemWsNode)
/* 105:    */   {
/* 106:106 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 107:    */   }
/* 108:    */ }
