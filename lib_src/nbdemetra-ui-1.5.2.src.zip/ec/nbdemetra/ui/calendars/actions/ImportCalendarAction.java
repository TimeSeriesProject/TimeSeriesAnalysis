/*  1:   */ package ec.nbdemetra.ui.calendars.actions;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Converter;
/*  4:   */ import com.google.common.collect.ImmutableList;
/*  5:   */ import ec.nbdemetra.ui.Config;
/*  6:   */ import ec.nbdemetra.ui.calendars.CalendarDocumentManager;
/*  7:   */ import ec.nbdemetra.ui.interchange.Importable;
/*  8:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  9:   */ import ec.nbdemetra.ws.Workspace;
/* 10:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/* 11:   */ import ec.nbdemetra.ws.WorkspaceItem;
/* 12:   */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/* 13:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/* 14:   */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/* 15:   */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/* 16:   */ import javax.swing.JMenuItem;
/* 17:   */ import org.openide.util.actions.Presenter.Popup;
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ public final class ImportCalendarAction
/* 49:   */   extends SingleNodeAction<ItemWsNode>
/* 50:   */   implements Presenter.Popup
/* 51:   */ {
/* 52:52 */   private static final Converter<Config, IGregorianCalendarProvider> CONVERTER = new CalendarConfig().reverse();
/* 53:53 */   private static final ImmutableList<Importable> IMPORTABLES = ImmutableList.of(new ImportableCalendar(null));
/* 54:   */   
/* 55:   */   public ImportCalendarAction() {
/* 56:56 */     super(ItemWsNode.class);
/* 57:   */   }
/* 58:   */   
/* 59:   */ 
/* 60:   */   public JMenuItem getPopupPresenter()
/* 61:   */   {
/* 62:62 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 63:   */   }
/* 64:   */   
/* 65:   */ 
/* 66:   */ 
/* 67:   */   protected void performAction(ItemWsNode activatedNode) {}
/* 68:   */   
/* 69:   */ 
/* 70:   */   protected boolean enable(ItemWsNode activatedNode)
/* 71:   */   {
/* 72:72 */     return true;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String getName()
/* 76:   */   {
/* 77:77 */     return null;
/* 78:   */   }
/* 79:   */   
/* 80:   */   private static final class ImportableCalendar implements Importable
/* 81:   */   {
/* 82:   */     public String getDomain()
/* 83:   */     {
/* 84:84 */       return CalendarConfig.DOMAIN;
/* 85:   */     }
/* 86:   */     
/* 87:   */     public void importConfig(Config config) throws IllegalArgumentException
/* 88:   */     {
/* 89:89 */       IGregorianCalendarProvider cal = (IGregorianCalendarProvider)ImportCalendarAction.CONVERTER.convert(config);
/* 90:90 */       Workspace ws = WorkspaceFactory.getInstance().getActiveWorkspace();
/* 91:91 */       if (ws.searchDocument(cal) == null) {
/* 92:92 */         String name = ProcessingContext.getActiveContext().getGregorianCalendars().get(cal);
/* 93:93 */         ws.add(WorkspaceItem.system(CalendarDocumentManager.ID, name, cal));
/* 94:   */       }
/* 95:   */     }
/* 96:   */   }
/* 97:   */ }
