/*   1:    */ package ec.nbdemetra.ui.calendars.actions;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Converter;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Predicate;
/*   6:    */ import com.google.common.collect.FluentIterable;
/*   7:    */ import ec.nbdemetra.ui.Config;
/*   8:    */ import ec.nbdemetra.ui.interchange.Exportable;
/*   9:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*  10:    */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*  11:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  12:    */ import java.util.List;
/*  13:    */ import javax.swing.JMenuItem;
/*  14:    */ import org.openide.nodes.Node;
/*  15:    */ import org.openide.util.HelpCtx;
/*  16:    */ import org.openide.util.actions.NodeAction;
/*  17:    */ import org.openide.util.actions.Presenter.Popup;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ public final class ExportCalendarAction
/*  51:    */   extends NodeAction
/*  52:    */   implements Presenter.Popup
/*  53:    */ {
/*  54: 54 */   private static final Converter<IGregorianCalendarProvider, Config> CONVERTER = new CalendarConfig();
/*  55: 55 */   private static final Predicate<ItemWsNode> IS_EXPORTABLE = new Predicate()
/*  56:    */   {
/*  57:    */     public boolean apply(ItemWsNode input) {
/*  58: 58 */       return !input.getDisplayName().equals("Default");
/*  59:    */     }
/*  60:    */   };
/*  61: 61 */   private static final Function<ItemWsNode, Exportable> TO_EXPORTABLE = new Function()
/*  62:    */   {
/*  63:    */     public Exportable apply(ItemWsNode input) {
/*  64: 64 */       return new ExportCalendarAction.ExportableCalendar(input);
/*  65:    */     }
/*  66:    */   };
/*  67:    */   
/*  68:    */ 
/*  69:    */   public JMenuItem getPopupPresenter()
/*  70:    */   {
/*  71: 71 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */ 
/*  76:    */   protected void performAction(Node[] activatedNodes) {}
/*  77:    */   
/*  78:    */ 
/*  79:    */   protected boolean enable(Node[] activatedNodes)
/*  80:    */   {
/*  81: 81 */     return !Nodes.asIterable(activatedNodes).filter(ItemWsNode.class).filter(IS_EXPORTABLE).isEmpty();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public String getName()
/*  85:    */   {
/*  86: 86 */     return null;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public HelpCtx getHelpCtx()
/*  90:    */   {
/*  91: 91 */     return null;
/*  92:    */   }
/*  93:    */   
/*  94:    */   private static List<Exportable> getExportables(Node[] activatedNodes) {
/*  95: 95 */     return 
/*  96:    */     
/*  97:    */ 
/*  98:    */ 
/*  99: 99 */       Nodes.asIterable(activatedNodes).filter(ItemWsNode.class).filter(IS_EXPORTABLE).transform(TO_EXPORTABLE).toList();
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static final class ExportableCalendar implements Exportable
/* 103:    */   {
/* 104:    */     private final ItemWsNode input;
/* 105:    */     
/* 106:    */     public ExportableCalendar(ItemWsNode input) {
/* 107:107 */       this.input = input;
/* 108:    */     }
/* 109:    */     
/* 110:    */     public Config exportConfig()
/* 111:    */     {
/* 112:112 */       IGregorianCalendarProvider cal = AddCalendarAction.getProvider(input);
/* 113:113 */       return (Config)ExportCalendarAction.CONVERTER.convert(cal);
/* 114:    */     }
/* 115:    */   }
/* 116:    */ }
