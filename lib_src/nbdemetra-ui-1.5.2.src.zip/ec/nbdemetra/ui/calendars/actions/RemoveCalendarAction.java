/*  1:   */ package ec.nbdemetra.ui.calendars.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*  5:   */ import ec.tstoolkit.timeseries.calendars.ChainedGregorianCalendarProvider;
/*  6:   */ import ec.tstoolkit.timeseries.calendars.CompositeGregorianCalendarProvider;
/*  7:   */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  8:   */ import ec.tstoolkit.timeseries.calendars.NationalCalendarProvider;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public final class RemoveCalendarAction
/* 30:   */   extends SingleNodeAction<ItemWsNode>
/* 31:   */ {
/* 32:   */   public RemoveCalendarAction()
/* 33:   */   {
/* 34:34 */     super(ItemWsNode.class);
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected void performAction(ItemWsNode activatedNode)
/* 38:   */   {
/* 39:39 */     IGregorianCalendarProvider o = AddCalendarAction.getProvider(activatedNode);
/* 40:40 */     if ((o instanceof NationalCalendarProvider)) {
/* 41:41 */       removeNationalCalendar((NationalCalendarProvider)o, activatedNode);
/* 42:42 */     } else if ((o instanceof ChainedGregorianCalendarProvider))
/* 43:43 */       removeChainedCalendar((ChainedGregorianCalendarProvider)o, activatedNode); else {
/* 44:44 */       (o instanceof CompositeGregorianCalendarProvider);
/* 45:   */     }
/* 46:   */   }
/* 47:   */   
/* 48:   */   protected boolean enable(ItemWsNode activatedNode)
/* 49:   */   {
/* 50:50 */     IGregorianCalendarProvider o = AddCalendarAction.getProvider(activatedNode);
/* 51:51 */     return (((o instanceof NationalCalendarProvider)) && (!((NationalCalendarProvider)o).isLocked())) || 
/* 52:52 */       ((o instanceof ChainedGregorianCalendarProvider)) || 
/* 53:53 */       ((o instanceof CompositeGregorianCalendarProvider));
/* 54:   */   }
/* 55:   */   
/* 56:   */   public String getName()
/* 57:   */   {
/* 58:58 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 59:   */   }
/* 60:   */   
/* 61:   */ 
/* 62:   */ 
/* 63:   */ 
/* 64:   */ 
/* 65:   */   static void removeNationalCalendar(NationalCalendarProvider paramNationalCalendarProvider, ItemWsNode paramItemWsNode)
/* 66:   */   {
/* 67:67 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n\t无法解析 Bundle\n");
/* 68:   */   }
/* 69:   */   
/* 70:   */ 
/* 71:   */ 
/* 72:   */ 
/* 73:   */ 
/* 74:   */ 
/* 75:   */ 
/* 76:   */ 
/* 77:   */ 
/* 78:   */ 
/* 79:   */ 
/* 80:   */ 
/* 81:   */   static void removeChainedCalendar(ChainedGregorianCalendarProvider paramChainedGregorianCalendarProvider, ItemWsNode paramItemWsNode)
/* 82:   */   {
/* 83:83 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n\t无法解析 Bundle\n");
/* 84:   */   }
/* 85:   */   
/* 86:   */ 
/* 87:   */ 
/* 88:   */ 
/* 89:   */ 
/* 90:   */ 
/* 91:   */ 
/* 92:   */ 
/* 93:   */ 
/* 94:   */ 
/* 95:   */ 
/* 96:   */ 
/* 97:   */   static void removeCompositeCalendar(CompositeGregorianCalendarProvider paramCompositeGregorianCalendarProvider, ItemWsNode paramItemWsNode)
/* 98:   */   {
/* 99:99 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n\t无法解析 Bundle\n");
/* :0:   */   }
/* :1:   */ }
