/*   1:    */ package ec.nbdemetra.ui.calendars.actions;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.calendars.CalendarDocumentManager;
/*   4:    */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*   5:    */ import ec.nbdemetra.ws.Workspace;
/*   6:    */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*   7:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*   8:    */ import ec.tstoolkit.timeseries.calendars.ChainedGregorianCalendarProvider;
/*   9:    */ import ec.tstoolkit.timeseries.calendars.CompositeGregorianCalendarProvider;
/*  10:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  11:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  12:    */ import ec.tstoolkit.timeseries.calendars.NationalCalendarProvider;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public final class EditCalendarAction
/*  37:    */   extends SingleNodeAction<ItemWsNode>
/*  38:    */ {
/*  39:    */   public EditCalendarAction()
/*  40:    */   {
/*  41: 41 */     super(ItemWsNode.class);
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected void performAction(ItemWsNode activatedNode)
/*  45:    */   {
/*  46: 46 */     GregorianCalendarManager manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/*  47: 47 */     IGregorianCalendarProvider o = AddCalendarAction.getProvider(activatedNode);
/*  48: 48 */     if ((o instanceof NationalCalendarProvider)) {
/*  49: 49 */       editNationalCalendar(manager, (NationalCalendarProvider)o, activatedNode);
/*  50: 50 */     } else if ((o instanceof ChainedGregorianCalendarProvider)) {
/*  51: 51 */       editChainedCalendar(manager, (ChainedGregorianCalendarProvider)o, activatedNode);
/*  52: 52 */     } else if ((o instanceof CompositeGregorianCalendarProvider)) {
/*  53: 53 */       editCompositeCalendar(manager, (CompositeGregorianCalendarProvider)o, activatedNode);
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   protected boolean enable(ItemWsNode activatedNode)
/*  58:    */   {
/*  59: 59 */     IGregorianCalendarProvider o = AddCalendarAction.getProvider(activatedNode);
/*  60: 60 */     return (((o instanceof NationalCalendarProvider)) && (!((NationalCalendarProvider)o).isLocked())) || 
/*  61: 61 */       ((o instanceof ChainedGregorianCalendarProvider)) || 
/*  62: 62 */       ((o instanceof CompositeGregorianCalendarProvider));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public String getName()
/*  66:    */   {
/*  67: 67 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  68:    */   }
/*  69:    */   
/*  70:    */   static void replace(GregorianCalendarManager manager, String oldName, String newName, IGregorianCalendarProvider newObj, ItemWsNode node) {
/*  71: 71 */     manager.remove(oldName);
/*  72: 72 */     manager.set(newName, newObj);
/*  73: 73 */     node.getWorkspace().remove(node.getItem());
/*  74: 74 */     node.getWorkspace().add(CalendarDocumentManager.systemItem(newName, newObj));
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */   static void editNationalCalendar(GregorianCalendarManager paramGregorianCalendarManager, NationalCalendarProvider paramNationalCalendarProvider, ItemWsNode paramItemWsNode)
/*  88:    */   {
/*  89: 89 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */   static void editChainedCalendar(GregorianCalendarManager paramGregorianCalendarManager, ChainedGregorianCalendarProvider paramChainedGregorianCalendarProvider, ItemWsNode paramItemWsNode)
/* 110:    */   {
/* 111:111 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 112:    */   }
/* 113:    */   
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */   static void editCompositeCalendar(GregorianCalendarManager paramGregorianCalendarManager, CompositeGregorianCalendarProvider paramCompositeGregorianCalendarProvider, ItemWsNode paramItemWsNode)
/* 129:    */   {
/* 130:130 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 131:    */   }
/* 132:    */ }
