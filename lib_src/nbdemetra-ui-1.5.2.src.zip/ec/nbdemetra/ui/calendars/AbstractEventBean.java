/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.awt.ListenableBean;
/*  4:   */ import ec.tstoolkit.timeseries.Day;
/*  5:   */ import ec.tstoolkit.timeseries.ValidityPeriod;
/*  6:   */ import ec.tstoolkit.timeseries.calendars.ISpecialDay;
/*  7:   */ import ec.tstoolkit.timeseries.calendars.SpecialDayEvent;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public abstract class AbstractEventBean
/* 18:   */   extends ListenableBean
/* 19:   */ {
/* 20:   */   public static final String START_PROPERTY = "start";
/* 21:   */   public static final String END_PROPERTY = "end";
/* 22:   */   public static final String WEIGHT_PROPERTY = "weight";
/* 23:   */   protected Day start;
/* 24:   */   protected Day end;
/* 25:   */   protected double weight;
/* 26:   */   
/* 27:   */   public AbstractEventBean(Day start, Day end, double weight)
/* 28:   */   {
/* 29:29 */     this.start = start;
/* 30:30 */     this.end = end;
/* 31:31 */     this.weight = weight;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Day getEnd() {
/* 35:35 */     return end;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setEnd(Day end) {
/* 39:39 */     Day old = this.end;
/* 40:40 */     this.end = end;
/* 41:41 */     firePropertyChange("end", old, this.end);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Day getStart() {
/* 45:45 */     return start;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setStart(Day start) {
/* 49:49 */     Day old = this.start;
/* 50:50 */     this.start = start;
/* 51:51 */     firePropertyChange("start", old, this.start);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public double getWeight() {
/* 55:55 */     return weight;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setWeight(double weight) {
/* 59:59 */     double old = this.weight;
/* 60:60 */     this.weight = weight;
/* 61:61 */     firePropertyChange("weight", Double.valueOf(old), Double.valueOf(this.weight));
/* 62:   */   }
/* 63:   */   
/* 64:   */   public SpecialDayEvent toEvent() {
/* 65:65 */     SpecialDayEvent result = new SpecialDayEvent(toSpecialDay());
/* 66:66 */     result.setValidityPeriod((start == null) && (end == null) ? null : new ValidityPeriod(start == null ? Day.BEG : start, end == null ? Day.END : end));
/* 67:67 */     return result;
/* 68:   */   }
/* 69:   */   
/* 70:   */   protected abstract ISpecialDay toSpecialDay();
/* 71:   */ }
