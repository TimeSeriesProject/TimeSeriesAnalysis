/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Objects;
/*  4:   */ import com.google.common.base.Objects.ToStringHelper;
/*  5:   */ import ec.tstoolkit.timeseries.Day;
/*  6:   */ import ec.tstoolkit.timeseries.ValidityPeriod;
/*  7:   */ import ec.tstoolkit.timeseries.calendars.EasterRelatedDay;
/*  8:   */ import ec.tstoolkit.timeseries.calendars.ISpecialDay;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class EasterRelatedEventBean
/* 18:   */   extends AbstractEventBean
/* 19:   */ {
/* 20:   */   public static final String OFFSET_PROPERTY = "offset";
/* 21:   */   protected int offset;
/* 22:   */   
/* 23:   */   public EasterRelatedEventBean()
/* 24:   */   {
/* 25:25 */     this(1, null, null, 1.0D);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public EasterRelatedEventBean(EasterRelatedDay day, ValidityPeriod vp) {
/* 29:29 */     this(offset, vp != null ? vp.getStart() : null, vp != null ? vp.getEnd() : null, day.getWeight());
/* 30:   */   }
/* 31:   */   
/* 32:   */   public EasterRelatedEventBean(int offset, Day start, Day end, double weight) {
/* 33:33 */     super(start, end, weight);
/* 34:34 */     this.offset = offset;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public int getOffset() {
/* 38:38 */     return offset;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setOffset(int offset) {
/* 42:42 */     int old = this.offset;
/* 43:43 */     this.offset = offset;
/* 44:44 */     firePropertyChange("offset", Integer.valueOf(old), Integer.valueOf(this.offset));
/* 45:   */   }
/* 46:   */   
/* 47:   */   protected ISpecialDay toSpecialDay()
/* 48:   */   {
/* 49:49 */     return new EasterRelatedDay(offset, weight);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String toString()
/* 53:   */   {
/* 54:54 */     return Objects.toStringHelper(this).add("offset", offset).add("start", start).add("end", end).add("weigth", weight).toString();
/* 55:   */   }
/* 56:   */ }
