/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.tss.tsproviders.utils.IConstraint;
/*  4:   */ import java.beans.PropertyChangeListener;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import org.openide.DialogDescriptor;
/*  7:   */ import org.openide.NotificationLineSupport;
/*  8:   */ import org.openide.util.WeakListeners;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public abstract class CustomDialogDescriptor<T>
/* 16:   */   extends DialogDescriptor
/* 17:   */   implements PropertyChangeListener
/* 18:   */ {
/* 19:   */   protected final NotificationLineSupport nls;
/* 20:   */   protected final T constraintData;
/* 21:   */   
/* 22:   */   public CustomDialogDescriptor(JComponent p, String title, T constraintData)
/* 23:   */   {
/* 24:24 */     super(p, title);
/* 25:25 */     nls = createNotificationLineSupport();
/* 26:26 */     this.constraintData = constraintData;
/* 27:27 */     p.addPropertyChangeListener(WeakListeners.propertyChange(this, p));
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected final void validate(IConstraint<T>... list) {
/* 31:31 */     for (IConstraint<T> o : list) {
/* 32:32 */       String msg = o.check(constraintData);
/* 33:33 */       if (msg != null) {
/* 34:34 */         nls.setWarningMessage(msg);
/* 35:35 */         setValid(false);
/* 36:36 */         return;
/* 37:   */       }
/* 38:   */     }
/* 39:39 */     nls.clearMessages();
/* 40:40 */     setValid(true);
/* 41:   */   }
/* 42:   */ }
