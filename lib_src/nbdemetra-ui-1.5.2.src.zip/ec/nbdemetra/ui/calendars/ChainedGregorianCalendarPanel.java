/*   1:    */ package ec.nbdemetra.ui.calendars;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Lists;
/*   4:    */ import ec.nbdemetra.ui.awt.IDialogDescriptorProvider;
/*   5:    */ import ec.nbdemetra.ui.awt.JPanel2;
/*   6:    */ import ec.nbdemetra.ui.awt.JProperty;
/*   7:    */ import ec.nbdemetra.ui.awt.ListenerState;
/*   8:    */ import ec.nbdemetra.ui.properties.ComboBoxPropertyEditor;
/*   9:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  10:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  11:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  12:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  13:    */ import ec.tss.tsproviders.utils.IConstraint;
/*  14:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  15:    */ import ec.tstoolkit.timeseries.Day;
/*  16:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  17:    */ import java.beans.PropertyChangeEvent;
/*  18:    */ import java.beans.PropertyChangeListener;
/*  19:    */ import java.beans.PropertyVetoException;
/*  20:    */ import java.util.List;
/*  21:    */ import javax.swing.JLabel;
/*  22:    */ import javax.swing.JTextField;
/*  23:    */ import javax.swing.event.DocumentEvent;
/*  24:    */ import javax.swing.event.DocumentListener;
/*  25:    */ import javax.swing.text.Document;
/*  26:    */ import org.jdesktop.layout.GroupLayout;
/*  27:    */ import org.jdesktop.layout.GroupLayout.ParallelGroup;
/*  28:    */ import org.jdesktop.layout.GroupLayout.SequentialGroup;
/*  29:    */ import org.openide.explorer.ExplorerManager;
/*  30:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  31:    */ import org.openide.explorer.propertysheet.PropertySheetView;
/*  32:    */ import org.openide.nodes.AbstractNode;
/*  33:    */ import org.openide.nodes.Node;
/*  34:    */ import org.openide.nodes.Sheet;
/*  35:    */ import org.openide.util.Exceptions;
/*  36:    */ import org.openide.util.Lookup;
/*  37:    */ import org.openide.util.lookup.Lookups;
/*  38:    */ 
/*  39:    */ public class ChainedGregorianCalendarPanel extends JPanel2 implements ExplorerManager.Provider, IDialogDescriptorProvider
/*  40:    */ {
/*  41:    */   public static final String CALENDAR_NAME_PROPERTY = "calendarName";
/*  42:    */   public static final String FIRST_CALENDAR_PROPERTY = "firstCalendar";
/*  43:    */   public static final String SECOND_CALENDAR_PROPERTY = "secondCalendar";
/*  44:    */   public static final String DAY_BREAK_PROPERTY = "dayBreak";
/*  45:    */   protected final JProperty<String> calendarName;
/*  46:    */   protected final JProperty<String> firstCalendar;
/*  47:    */   protected final JProperty<String> secondCalendar;
/*  48:    */   protected final JProperty<Day> dayBreak;
/*  49:    */   final ExplorerManager em;
/*  50:    */   final NameTextFieldListener nameTextFieldListener;
/*  51:    */   private JLabel jLabel1;
/*  52:    */   private JTextField nameTextField;
/*  53:    */   private PropertySheetView propertySheetView1;
/*  54:    */   
/*  55:    */   public ChainedGregorianCalendarPanel()
/*  56:    */   {
/*  57: 57 */     calendarName = newProperty("calendarName", JProperty.nullTo(""), null);
/*  58: 58 */     firstCalendar = newProperty("firstCalendar", JProperty.nullTo(""), null);
/*  59: 59 */     secondCalendar = newProperty("secondCalendar", JProperty.nullTo(""), null);
/*  60: 60 */     dayBreak = newProperty("dayBreak", null);
/*  61:    */     
/*  62: 62 */     em = new ExplorerManager();
/*  63:    */     
/*  64: 64 */     initComponents();
/*  65:    */     
/*  66: 66 */     em.setRootContext(new ChainedCalendarNode(this));
/*  67:    */     try {
/*  68: 68 */       em.setSelectedNodes(new Node[] { em.getRootContext() });
/*  69:    */     } catch (PropertyVetoException ex) {
/*  70: 70 */       Exceptions.printStackTrace(ex);
/*  71:    */     }
/*  72:    */     
/*  73: 73 */     nameTextFieldListener = new NameTextFieldListener(null);
/*  74:    */     
/*  75: 75 */     nameTextField.getDocument().addDocumentListener(nameTextFieldListener);
/*  76:    */     
/*  77: 77 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  78:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  79:    */         String str;
/*  80: 80 */         switch ((str = evt.getPropertyName()).hashCode()) {case -352838935:  if (str.equals("calendarName")) break; break; case -189599790:  if (str.equals("secondCalendar")) {} break; case 1663205902:  if (str.equals("firstCalendar")) {} break; case 1904461507:  if (!str.equals("dayBreak"))
/*  81:    */           {
/*  82: 82 */             return;onCalendarNameChange();
/*  83: 83 */             return;
/*  84:    */             
/*  85: 85 */             onFirstCalendarChange();
/*  86: 86 */             return;
/*  87:    */             
/*  88: 88 */             onSecondCalendarChange();
/*  89:    */           }
/*  90:    */           else {
/*  91: 91 */             onDayBreakChange();
/*  92:    */           }
/*  93:    */           
/*  94:    */ 
/*  95:    */ 
/*  96:    */           break;
/*  97:    */         }
/*  98:    */         
/*  99:    */       }
/* 100:    */     });
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */ 
/* 105:    */   private void initComponents()
/* 106:    */   {
/* 107:107 */     jLabel1 = new JLabel();
/* 108:108 */     nameTextField = new JTextField();
/* 109:109 */     propertySheetView1 = new PropertySheetView();
/* 110:    */     
/* 111:111 */     jLabel1.setText("Name:");
/* 112:    */     
/* 113:113 */     GroupLayout layout = new GroupLayout(this);
/* 114:114 */     setLayout(layout);
/* 115:115 */     layout.setHorizontalGroup(
/* 116:116 */       layout.createParallelGroup(1)
/* 117:117 */       .add(2, layout.createSequentialGroup()
/* 118:118 */       .addContainerGap()
/* 119:119 */       .add(layout.createParallelGroup(2)
/* 120:120 */       .add(propertySheetView1, -2, 0, 32767)
/* 121:121 */       .add(1, nameTextField)
/* 122:122 */       .add(1, layout.createSequentialGroup()
/* 123:123 */       .add(jLabel1)
/* 124:124 */       .add(0, 260, 32767)))
/* 125:125 */       .addContainerGap()));
/* 126:    */     
/* 127:127 */     layout.setVerticalGroup(
/* 128:128 */       layout.createParallelGroup(1)
/* 129:129 */       .add(layout.createSequentialGroup()
/* 130:130 */       .add(4, 4, 4)
/* 131:131 */       .add(jLabel1)
/* 132:132 */       .addPreferredGap(0)
/* 133:133 */       .add(nameTextField, -2, -1, -2)
/* 134:134 */       .addPreferredGap(1)
/* 135:135 */       .add(propertySheetView1, -1, 161, 32767)
/* 136:136 */       .addContainerGap()));
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */   protected void onCalendarNameChange()
/* 146:    */   {
/* 147:147 */     if (nameTextFieldListener.state == ListenerState.READY) {
/* 148:148 */       nameTextFieldListener.state = ListenerState.SUSPENDED;
/* 149:149 */       nameTextField.setText((String)calendarName.get());
/* 150:150 */       nameTextFieldListener.state = ListenerState.READY;
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */   protected void onFirstCalendarChange() {}
/* 156:    */   
/* 157:    */ 
/* 158:    */   protected void onSecondCalendarChange() {}
/* 159:    */   
/* 160:    */ 
/* 161:    */   protected void onDayBreakChange() {}
/* 162:    */   
/* 163:    */ 
/* 164:    */   public String getCalendarName()
/* 165:    */   {
/* 166:166 */     return (String)calendarName.get();
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void setCalendarName(String calendarName) {
/* 170:170 */     this.calendarName.set(calendarName);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public String getFirstCalendar() {
/* 174:174 */     return (String)firstCalendar.get();
/* 175:    */   }
/* 176:    */   
/* 177:    */   public void setFirstCalendar(String firstCalendar) {
/* 178:178 */     this.firstCalendar.set(firstCalendar);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public String getSecondCalendar() {
/* 182:182 */     return (String)secondCalendar.get();
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setSecondCalendar(String secondCalendar) {
/* 186:186 */     this.secondCalendar.set(secondCalendar);
/* 187:    */   }
/* 188:    */   
/* 189:    */   public Day getDayBreak() {
/* 190:190 */     return (Day)dayBreak.get();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void setDayBreak(Day dayBreak) {
/* 194:194 */     this.dayBreak.set(dayBreak);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public ExplorerManager getExplorerManager()
/* 198:    */   {
/* 199:199 */     return em;
/* 200:    */   }
/* 201:    */   
/* 202:    */   static class ChainedCalendarNode extends AbstractNode
/* 203:    */   {
/* 204:    */     public ChainedCalendarNode(ChainedGregorianCalendarPanel bean)
/* 205:    */     {
/* 206:206 */       super(Lookups.singleton(bean));
/* 207:    */     }
/* 208:    */     
/* 209:    */     protected Sheet createSheet()
/* 210:    */     {
/* 211:211 */       ChainedGregorianCalendarPanel bean = (ChainedGregorianCalendarPanel)getLookup().lookup(ChainedGregorianCalendarPanel.class);
/* 212:    */       
/* 213:213 */       List<String> tmp = Lists.newArrayList(ProcessingContext.getActiveContext().getGregorianCalendars().getNames());
/* 214:214 */       tmp.remove(bean.getCalendarName());
/* 215:215 */       Object[] names = tmp.toArray();
/* 216:    */       
/* 217:217 */       Sheet result = super.createSheet();
/* 218:218 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 219:    */       
/* 220:220 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(bean, "firstCalendar"))
/* 221:221 */         .editor(ComboBoxPropertyEditor.class)
/* 222:222 */         .attribute("values", names)
/* 223:223 */         .display("First")
/* 224:224 */         .add();
/* 225:    */       
/* 226:226 */       ((NodePropertySetBuilder.DefaultStep)b.with(Day.class).select(bean, "dayBreak"))
/* 227:227 */         .display("Day break")
/* 228:228 */         .add();
/* 229:    */       
/* 230:230 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(bean, "secondCalendar"))
/* 231:231 */         .editor(ComboBoxPropertyEditor.class)
/* 232:232 */         .attribute("values", names)
/* 233:233 */         .display("Second")
/* 234:234 */         .add();
/* 235:235 */       result.put(b.build());
/* 236:236 */       return result;
/* 237:    */     }
/* 238:    */   }
/* 239:    */   
/* 240:    */   private class NameTextFieldListener implements DocumentListener { private NameTextFieldListener() {}
/* 241:    */     
/* 242:242 */     ListenerState state = ListenerState.READY;
/* 243:    */     
/* 244:    */     void update() {
/* 245:245 */       if (state == ListenerState.READY) {
/* 246:246 */         state = ListenerState.SENDING;
/* 247:247 */         setCalendarName(nameTextField.getText());
/* 248:248 */         state = ListenerState.READY;
/* 249:    */       }
/* 250:    */     }
/* 251:    */     
/* 252:    */     public void insertUpdate(DocumentEvent e)
/* 253:    */     {
/* 254:254 */       update();
/* 255:    */     }
/* 256:    */     
/* 257:    */     public void removeUpdate(DocumentEvent e)
/* 258:    */     {
/* 259:259 */       update();
/* 260:    */     }
/* 261:    */     
/* 262:    */ 
/* 263:    */     public void changedUpdate(DocumentEvent e) {}
/* 264:    */   }
/* 265:    */   
/* 266:    */ 
/* 267:    */   public org.openide.DialogDescriptor createDialogDescriptor(String title)
/* 268:    */   {
/* 269:269 */     return new ChainedDialogDescriptor(this, title);
/* 270:    */   }
/* 271:    */   
/* 272:    */   private static class ChainedDialogDescriptor extends CustomDialogDescriptor<ChainedGregorianCalendarPanel.ChainedConstraintData>
/* 273:    */   {
/* 274:    */     ChainedDialogDescriptor(ChainedGregorianCalendarPanel p, String title) {
/* 275:275 */       super(title, new ChainedGregorianCalendarPanel.ChainedConstraintData(p, p.getCalendarName()));
/* 276:276 */       validate(ChainedGregorianCalendarPanel.ChainedConstraints.values());
/* 277:    */     }
/* 278:    */     
/* 279:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 280:    */       String str;
/* 281:281 */       switch ((str = evt.getPropertyName()).hashCode()) {case -352838935:  if (str.equals("calendarName")) break; break; case -189599790:  if (str.equals("secondCalendar")) {} break; case 1663205902:  if (str.equals("firstCalendar")) {} break; case 1904461507:  if (!str.equals("dayBreak"))
/* 282:    */         {
/* 283:283 */           return;validate(new IConstraint[] { ChainedGregorianCalendarPanel.ChainedConstraints.CALENDAR_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.FIRST_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.DAY_BREAK, ChainedGregorianCalendarPanel.ChainedConstraints.SECOND_NAME });
/* 284:284 */           return;
/* 285:    */           
/* 286:286 */           validate(new IConstraint[] { ChainedGregorianCalendarPanel.ChainedConstraints.FIRST_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.CALENDAR_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.DAY_BREAK, ChainedGregorianCalendarPanel.ChainedConstraints.SECOND_NAME });
/* 287:    */         }
/* 288:    */         else {
/* 289:289 */           validate(new IConstraint[] { ChainedGregorianCalendarPanel.ChainedConstraints.DAY_BREAK, ChainedGregorianCalendarPanel.ChainedConstraints.CALENDAR_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.FIRST_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.SECOND_NAME });
/* 290:290 */           return;
/* 291:    */           
/* 292:292 */           validate(new IConstraint[] { ChainedGregorianCalendarPanel.ChainedConstraints.SECOND_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.CALENDAR_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.FIRST_NAME, ChainedGregorianCalendarPanel.ChainedConstraints.DAY_BREAK });
/* 293:    */         }
/* 294:    */         break;
/* 295:    */       }
/* 296:    */     }
/* 297:    */   }
/* 298:    */   
/* 299:    */   private static class ChainedConstraintData {
/* 300:    */     final ChainedGregorianCalendarPanel panel;
/* 301:    */     final String originalName;
/* 302:    */     final GregorianCalendarManager manager;
/* 303:    */     
/* 304:    */     ChainedConstraintData(ChainedGregorianCalendarPanel panel, String originalName) {
/* 305:305 */       this.panel = panel;
/* 306:306 */       this.originalName = originalName;
/* 307:307 */       manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/* 308:    */     }
/* 309:    */   }
/* 310:    */   
/* 311:    */   private static abstract enum ChainedConstraints implements IConstraint<ChainedGregorianCalendarPanel.ChainedConstraintData>
/* 312:    */   {
/* 313:313 */     CALENDAR_NAME, 
/* 314:    */     
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */ 
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:326 */     FIRST_NAME, 
/* 327:    */     
/* 328:    */ 
/* 329:    */ 
/* 330:    */ 
/* 331:    */ 
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:339 */     DAY_BREAK, 
/* 340:    */     
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:348 */     SECOND_NAME;
/* 349:    */   }
/* 350:    */ }
