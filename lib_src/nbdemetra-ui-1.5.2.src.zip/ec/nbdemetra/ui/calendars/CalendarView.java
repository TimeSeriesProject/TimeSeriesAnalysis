/*   1:    */ package ec.nbdemetra.ui.calendars;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Lists;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*   6:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*   7:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.EnumStep;
/*   8:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.IntStep;
/*   9:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  10:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  11:    */ import ec.tss.Ts;
/*  12:    */ import ec.tss.TsCollection;
/*  13:    */ import ec.tss.TsFactory;
/*  14:    */ import ec.tstoolkit.data.DataBlock;
/*  15:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  16:    */ import ec.tstoolkit.timeseries.calendars.LengthOfPeriodType;
/*  17:    */ import ec.tstoolkit.timeseries.calendars.TradingDaysType;
/*  18:    */ import ec.tstoolkit.timeseries.regression.LeapYearVariable;
/*  19:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  20:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  21:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  22:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  23:    */ import ec.ui.grid.JTsGrid;
/*  24:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  25:    */ import ec.ui.view.PeriodogramView;
/*  26:    */ import java.awt.BorderLayout;
/*  27:    */ import java.beans.PropertyChangeEvent;
/*  28:    */ import java.beans.PropertyChangeListener;
/*  29:    */ import java.util.List;
/*  30:    */ import javax.swing.JComponent;
/*  31:    */ import javax.swing.JSplitPane;
/*  32:    */ import org.openide.explorer.propertysheet.PropertySheet;
/*  33:    */ import org.openide.nodes.AbstractNode;
/*  34:    */ import org.openide.nodes.Children;
/*  35:    */ import org.openide.nodes.Node;
/*  36:    */ import org.openide.nodes.Sheet;
/*  37:    */ 
/*  38:    */ 
/*  39:    */ public class CalendarView
/*  40:    */   extends JComponent
/*  41:    */ {
/*  42: 42 */   private static String[] TD = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Leap Year" };
/*  43: 43 */   private static String[] WD = { "Working days", "Leap Year" };
/*  44:    */   
/*  45:    */   private IGregorianCalendarProvider calendarProvider;
/*  46:    */   private TsDomain domain;
/*  47:    */   private TradingDaysType dtype;
/*  48:    */   private LengthOfPeriodType ltype;
/*  49:    */   private final PropertySheet propertySheet;
/*  50:    */   private final PeriodogramView pView;
/*  51:    */   private final JTsGrid tsGrid;
/*  52:    */   
/*  53:    */   public CalendarView()
/*  54:    */   {
/*  55: 55 */     calendarProvider = null;
/*  56: 56 */     domain = newDomain(TsFrequency.Monthly, 1980, 140);
/*  57: 57 */     dtype = TradingDaysType.TradingDays;
/*  58: 58 */     ltype = LengthOfPeriodType.LeapYear;
/*  59:    */     
/*  60: 60 */     propertySheet = new PropertySheet();
/*  61: 61 */     propertySheet.setDescriptionAreaVisible(false);
/*  62: 62 */     propertySheet.setNodes(new Node[] { new CalendarViewNode() });
/*  63:    */     
/*  64: 64 */     pView = new PeriodogramView();
/*  65:    */     
/*  66: 66 */     tsGrid = new JTsGrid();
/*  67: 67 */     tsGrid.setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/*  68: 68 */     tsGrid.addPropertyChangeListener("selection", new PropertyChangeListener()
/*  69:    */     {
/*  70:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  71: 71 */         onTsGridSelectionChange();
/*  72:    */       }
/*  73:    */       
/*  74: 74 */     });
/*  75: 75 */     JSplitPane sp1 = NbComponents.newJSplitPane(1, propertySheet, pView);
/*  76: 76 */     sp1.setDividerLocation(0.3D);
/*  77: 77 */     sp1.setResizeWeight(0.3D);
/*  78: 78 */     JSplitPane sp2 = NbComponents.newJSplitPane(0, sp1, tsGrid);
/*  79: 79 */     sp2.setDividerLocation(0.3D);
/*  80: 80 */     sp2.setResizeWeight(0.3D);
/*  81: 81 */     setLayout(new BorderLayout());
/*  82: 82 */     add(sp2, "Center");
/*  83: 83 */     pView.setDifferencingOrder(0);
/*  84: 84 */     pView.setLimitVisible(false);
/*  85:    */   }
/*  86:    */   
/*  87:    */   protected void onTsGridSelectionChange()
/*  88:    */   {
/*  89: 89 */     Ts[] selection = tsGrid.getSelection();
/*  90: 90 */     pView.setTs(selection.length == 1 ? selection[0] : null);
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected void onCalendarProviderChange() {
/*  94: 94 */     if (calendarProvider == null) {
/*  95: 95 */       return;
/*  96:    */     }
/*  97: 97 */     int nx = getCmpsCount();
/*  98: 98 */     if (nx == 0) {
/*  99: 99 */       return;
/* 100:    */     }
/* 101:    */     
/* 102:102 */     List<DataBlock> buffer = Lists.newArrayListWithCapacity(nx);
/* 103:103 */     for (int i = 0; i < nx; i++) {
/* 104:104 */       buffer.add(new DataBlock(domain.getLength()));
/* 105:    */     }
/* 106:106 */     calendarProvider.calendarData(dtype, domain, buffer, 0);
/* 107:107 */     if (ltype != LengthOfPeriodType.None) {
/* 108:108 */       new LeapYearVariable(ltype).data(domain.getStart(), (DataBlock)buffer.get(nx - 1));
/* 109:    */     }
/* 110:    */     
/* 111:111 */     List<Ts> tss = Lists.newArrayListWithCapacity(nx);
/* 112:112 */     for (int i = 0; i < nx; i++) {
/* 113:113 */       TsData data = new TsData(domain.getStart(), ((DataBlock)buffer.get(i)).getData(), false);
/* 114:114 */       tss.add(TsFactory.instance.createTs(getCmpName(i), null, data));
/* 115:    */     }
/* 116:    */     
/* 117:117 */     tsGrid.getTsCollection().replace(tss);
/* 118:118 */     tsGrid.setSelection(new Ts[] { (Ts)tss.get(0) });
/* 119:    */   }
/* 120:    */   
/* 121:    */   protected void onConfigChange()
/* 122:    */   {
/* 123:123 */     onCalendarProviderChange();
/* 124:    */   }
/* 125:    */   
/* 126:    */   private String getCmpName(int idx) {
/* 127:127 */     if (dtype == TradingDaysType.TradingDays)
/* 128:128 */       return TD[idx];
/* 129:129 */     if (dtype == TradingDaysType.WorkingDays) {
/* 130:130 */       return WD[idx];
/* 131:    */     }
/* 132:132 */     return WD[1];
/* 133:    */   }
/* 134:    */   
/* 135:    */   private int getCmpsCount()
/* 136:    */   {
/* 137:137 */     int n = dtype.getVariablesCount();
/* 138:138 */     if (ltype != LengthOfPeriodType.None) {
/* 139:139 */       n++;
/* 140:    */     }
/* 141:141 */     return n;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public IGregorianCalendarProvider getCalendarProvider()
/* 145:    */   {
/* 146:146 */     return calendarProvider;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void setCalendarProvider(IGregorianCalendarProvider value) {
/* 150:150 */     calendarProvider = value;
/* 151:151 */     onCalendarProviderChange();
/* 152:    */   }
/* 153:    */   
/* 154:    */   public TsDomain getDomain() {
/* 155:155 */     return domain;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void setDomain(TsDomain domain) {
/* 159:159 */     this.domain = domain;
/* 160:160 */     onConfigChange();
/* 161:    */   }
/* 162:    */   
/* 163:    */   public TradingDaysType getDType() {
/* 164:164 */     return dtype;
/* 165:    */   }
/* 166:    */   
/* 167:    */   void setDType(TradingDaysType dtype) {
/* 168:168 */     this.dtype = dtype;
/* 169:169 */     onConfigChange();
/* 170:    */   }
/* 171:    */   
/* 172:    */   private static TsDomain newDomain(TsFrequency freq, int startYear, int yearCount)
/* 173:    */   {
/* 174:174 */     return new TsDomain(freq, startYear, 0, yearCount * freq.intValue());
/* 175:    */   }
/* 176:    */   
/* 177:    */   public class CalendarViewNode extends AbstractNode
/* 178:    */   {
/* 179:    */     public CalendarViewNode() {
/* 180:180 */       super();
/* 181:181 */       setDisplayName("Calendar view");
/* 182:    */     }
/* 183:    */     
/* 184:    */     protected Sheet createSheet()
/* 185:    */     {
/* 186:186 */       Sheet result = new Sheet();
/* 187:    */       
/* 188:188 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 189:    */       
/* 190:    */ 
/* 191:    */ 
/* 192:192 */       ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsFrequency.class).select(this, "freq")).noneOf(new TsFrequency[] {TsFrequency.Undefined }).display("Frequency"))
/* 193:193 */         .add();
/* 194:    */       
/* 195:195 */       ((NodePropertySetBuilder.DefaultStep)b.with(Integer.TYPE).select(this, "start"))
/* 196:196 */         .display("Start")
/* 197:197 */         .add();
/* 198:    */       
/* 199:    */ 
/* 200:    */ 
/* 201:201 */       ((NodePropertySetBuilder.IntStep)((NodePropertySetBuilder.IntStep)b.withInt().select(this, "length")).min(1).display("Length (in years)"))
/* 202:202 */         .add();
/* 203:    */       
/* 204:    */ 
/* 205:205 */       ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TradingDaysType.class).select(this, "type")).display("Variable type"))
/* 206:206 */         .add();
/* 207:207 */       result.put(b.build());
/* 208:    */       
/* 209:209 */       return result;
/* 210:    */     }
/* 211:    */     
/* 212:    */     public TsFrequency getFreq() {
/* 213:213 */       return domain.getFrequency();
/* 214:    */     }
/* 215:    */     
/* 216:    */     public void setFreq(TsFrequency freq) {
/* 217:217 */       setDomain(CalendarView.newDomain(freq, domain.getStart().getYear(), domain.getYearsCount()));
/* 218:    */     }
/* 219:    */     
/* 220:    */     public int getLength() {
/* 221:221 */       return domain.getYearsCount();
/* 222:    */     }
/* 223:    */     
/* 224:    */     public void setLength(int length) {
/* 225:225 */       setDomain(CalendarView.newDomain(domain.getFrequency(), domain.getStart().getYear(), length));
/* 226:    */     }
/* 227:    */     
/* 228:    */     public int getStart() {
/* 229:229 */       return domain.getStart().getYear();
/* 230:    */     }
/* 231:    */     
/* 232:    */     public void setStart(int start) {
/* 233:233 */       setDomain(CalendarView.newDomain(domain.getFrequency(), start, domain.getYearsCount()));
/* 234:    */     }
/* 235:    */     
/* 236:    */     public TradingDaysType getType() {
/* 237:237 */       return dtype;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public void setType(TradingDaysType type) {
/* 241:241 */       setDType(type);
/* 242:    */     }
/* 243:    */   }
/* 244:    */ }
