/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Objects;
/*  4:   */ import com.google.common.base.Objects.ToStringHelper;
/*  5:   */ import ec.tstoolkit.timeseries.Day;
/*  6:   */ import ec.tstoolkit.timeseries.DayOfWeek;
/*  7:   */ import ec.tstoolkit.timeseries.Month;
/*  8:   */ import ec.tstoolkit.timeseries.ValidityPeriod;
/*  9:   */ import ec.tstoolkit.timeseries.calendars.FixedWeekDay;
/* 10:   */ import ec.tstoolkit.timeseries.calendars.ISpecialDay;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class FixedWeekEventBean
/* 20:   */   extends AbstractEventBean
/* 21:   */ {
/* 22:   */   public static final String DAY_OF_WEEK_PROPERTY = "dayOfWeek";
/* 23:   */   public static final String WEEK_PROPERTY = "week";
/* 24:   */   public static final String MONTH_PROPERTY = "month";
/* 25:   */   protected DayOfWeek dayOfWeek;
/* 26:   */   protected int week;
/* 27:   */   protected Month month;
/* 28:   */   
/* 29:   */   public FixedWeekEventBean()
/* 30:   */   {
/* 31:31 */     this(DayOfWeek.Monday, 1, Month.January, null, null, 1.0D);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public FixedWeekEventBean(FixedWeekDay day, ValidityPeriod vp) {
/* 35:35 */     this(dayOfWeek, week, month, vp != null ? vp.getStart() : null, vp != null ? vp.getEnd() : null, day.getWeight());
/* 36:   */   }
/* 37:   */   
/* 38:   */   public FixedWeekEventBean(DayOfWeek dayOfWeek, int week, Month month, Day start, Day end, double weight) {
/* 39:39 */     super(start, end, weight);
/* 40:40 */     this.dayOfWeek = dayOfWeek;
/* 41:41 */     this.week = week;
/* 42:42 */     this.month = month;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public DayOfWeek getDayOfWeek() {
/* 46:46 */     return dayOfWeek;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setDayOfWeek(DayOfWeek dayOfWeek) {
/* 50:50 */     DayOfWeek old = this.dayOfWeek;
/* 51:51 */     this.dayOfWeek = dayOfWeek;
/* 52:52 */     firePropertyChange("dayOfWeek", old, this.dayOfWeek);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int getWeek() {
/* 56:56 */     return week;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setWeek(int week) {
/* 60:60 */     int old = this.week;
/* 61:61 */     this.week = week;
/* 62:62 */     firePropertyChange("week", Integer.valueOf(old), Integer.valueOf(this.week));
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Month getMonth() {
/* 66:66 */     return month;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setMonth(Month month) {
/* 70:70 */     Month old = this.month;
/* 71:71 */     this.month = month;
/* 72:72 */     firePropertyChange("month", old, this.month);
/* 73:   */   }
/* 74:   */   
/* 75:   */   protected ISpecialDay toSpecialDay()
/* 76:   */   {
/* 77:77 */     return new FixedWeekDay(week, dayOfWeek, month, weight);
/* 78:   */   }
/* 79:   */   
/* 80:   */   public String toString()
/* 81:   */   {
/* 82:82 */     return Objects.toStringHelper(this).add("dayOfWeek", dayOfWeek).add("week", week).add("month", month).add("start", start).add("end", end).add("weigth", weight).toString();
/* 83:   */   }
/* 84:   */ }
