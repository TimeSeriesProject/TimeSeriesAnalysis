/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  4:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.EnumStep;
/*  5:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.IntStep;
/*  6:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  7:   */ import ec.tstoolkit.timeseries.Month;
/*  8:   */ import org.openide.nodes.Sheet;
/*  9:   */ import org.openide.util.Lookup;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class FixedEventNode
/* 14:   */   extends AbstractEventNode
/* 15:   */ {
/* 16:   */   public FixedEventNode(FixedEventBean bean)
/* 17:   */   {
/* 18:18 */     super(bean);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getHtmlDisplayName()
/* 22:   */   {
/* 23:23 */     FixedEventBean bean = (FixedEventBean)getLookup().lookup(FixedEventBean.class);
/* 24:24 */     StringBuilder sb = new StringBuilder();
/* 25:25 */     sb.append("<b>Fixed</b> ");
/* 26:26 */     sb.append(month).append(", ").append(day);
/* 27:27 */     return sb.toString();
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected Sheet createSheet()
/* 31:   */   {
/* 32:32 */     FixedEventBean bean = (FixedEventBean)getLookup().lookup(FixedEventBean.class);
/* 33:33 */     Sheet result = super.createSheet();
/* 34:34 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Fixed Day");
/* 35:35 */     ((NodePropertySetBuilder.IntStep)((NodePropertySetBuilder.IntStep)b.withInt().select(bean, "day")).min(1).max(31).display("Day")).add();
/* 36:36 */     ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(Month.class).select(bean, "month")).display("Month")).add();
/* 37:37 */     result.put(b.build());
/* 38:38 */     return result;
/* 39:   */   }
/* 40:   */ }
