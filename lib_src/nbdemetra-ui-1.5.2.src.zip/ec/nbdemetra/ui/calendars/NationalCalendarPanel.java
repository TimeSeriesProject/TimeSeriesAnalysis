/*   1:    */ package ec.nbdemetra.ui.calendars;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ImmutableList;
/*   4:    */ import com.google.common.collect.ImmutableList.Builder;
/*   5:    */ import ec.nbdemetra.ui.awt.JProperty;
/*   6:    */ import ec.nbdemetra.ui.awt.ListenerState;
/*   7:    */ import ec.tss.tsproviders.utils.IConstraint;
/*   8:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*   9:    */ import ec.tstoolkit.timeseries.calendars.EasterRelatedDay;
/*  10:    */ import ec.tstoolkit.timeseries.calendars.FixedDay;
/*  11:    */ import ec.tstoolkit.timeseries.calendars.FixedWeekDay;
/*  12:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  13:    */ import ec.tstoolkit.timeseries.calendars.SpecialCalendarDay;
/*  14:    */ import ec.tstoolkit.timeseries.calendars.SpecialDayEvent;
/*  15:    */ import java.awt.event.ActionEvent;
/*  16:    */ import java.awt.event.ActionListener;
/*  17:    */ import java.beans.PropertyChangeEvent;
/*  18:    */ import java.beans.VetoableChangeListener;
/*  19:    */ import java.util.List;
/*  20:    */ import javax.swing.AbstractAction;
/*  21:    */ import javax.swing.Action;
/*  22:    */ import javax.swing.ImageIcon;
/*  23:    */ import javax.swing.JButton;
/*  24:    */ import javax.swing.JCheckBox;
/*  25:    */ import javax.swing.JLabel;
/*  26:    */ import javax.swing.JPopupMenu;
/*  27:    */ import javax.swing.JSplitPane;
/*  28:    */ import javax.swing.JTextField;
/*  29:    */ import javax.swing.JToolBar;
/*  30:    */ import javax.swing.event.DocumentEvent;
/*  31:    */ import javax.swing.event.DocumentListener;
/*  32:    */ import org.jdesktop.layout.GroupLayout;
/*  33:    */ import org.jdesktop.layout.GroupLayout.ParallelGroup;
/*  34:    */ import org.jdesktop.layout.GroupLayout.SequentialGroup;
/*  35:    */ import org.openide.awt.DropDownButtonFactory;
/*  36:    */ import org.openide.explorer.ExplorerManager;
/*  37:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  38:    */ import org.openide.explorer.propertysheet.PropertySheetView;
/*  39:    */ import org.openide.explorer.view.ListView;
/*  40:    */ import org.openide.nodes.ChildFactory;
/*  41:    */ import org.openide.nodes.Node;
/*  42:    */ import org.openide.nodes.NodeEvent;
/*  43:    */ import org.openide.nodes.NodeListener;
/*  44:    */ import org.openide.nodes.NodeMemberEvent;
/*  45:    */ import org.openide.nodes.NodeReorderEvent;
/*  46:    */ import org.openide.util.WeakListeners;
/*  47:    */ 
/*  48:    */ public class NationalCalendarPanel extends ec.nbdemetra.ui.awt.JPanel2 implements ExplorerManager.Provider, ec.nbdemetra.ui.awt.IDialogDescriptorProvider
/*  49:    */ {
/*  50:    */   public static final String CALENDAR_NAME_PROPERTY = "calendarName";
/*  51:    */   public static final String MEAN_CORRECTION_PROPERTY = "meanCorrection";
/*  52:    */   public static final String SPECIAL_DAY_EVENTS_PROPERTY = "specialDayEvents";
/*  53:    */   protected final JProperty<String> calendarName;
/*  54:    */   protected final JProperty<ImmutableList<SpecialDayEvent>> specialDayEvents;
/*  55:    */   protected final JProperty<Boolean> meanCorrection;
/*  56:    */   final ExplorerManager em;
/*  57:    */   final ListOfSpecialDayEvent childFactory;
/*  58:    */   final JPopupMenu addPopupMenu;
/*  59:    */   final NameTextFieldListener nameTextFieldListener;
/*  60:    */   final MeanCheckBoxListener meanListener;
/*  61:    */   Action lastUsedAction;
/*  62:    */   private JButton jButton1;
/*  63:    */   private JLabel jLabel1;
/*  64:    */   private JLabel jLabel2;
/*  65:    */   private JSplitPane jSplitPane1;
/*  66:    */   private JToolBar jToolBar1;
/*  67:    */   private ListView listView1;
/*  68:    */   private JCheckBox meanCB;
/*  69:    */   private JTextField nameTextField;
/*  70:    */   private PropertySheetView propertySheetView1;
/*  71:    */   private JButton removeButton;
/*  72:    */   
/*  73:    */   public NationalCalendarPanel()
/*  74:    */   {
/*  75: 75 */     calendarName = newProperty("calendarName", JProperty.nullTo(""), null);
/*  76: 76 */     specialDayEvents = newProperty("specialDayEvents", JProperty.nullTo(ImmutableList.of()), null);
/*  77: 77 */     meanCorrection = newProperty("meanCorrection", Boolean.valueOf(true));
/*  78:    */     
/*  79: 79 */     em = new ExplorerManager();
/*  80: 80 */     childFactory = new ListOfSpecialDayEvent();
/*  81:    */     
/*  82: 82 */     em.setRootContext(new org.openide.nodes.AbstractNode(org.openide.nodes.Children.create(childFactory, false)));
/*  83: 83 */     em.addVetoableChangeListener(new VetoableChangeListener()
/*  84:    */     {
/*  85:    */       public void vetoableChange(PropertyChangeEvent evt) throws java.beans.PropertyVetoException {
/*  86: 86 */         if ("selectedNodes".equals(evt.getPropertyName())) {
/*  87: 87 */           Node[] nodes = (Node[])evt.getNewValue();
/*  88: 88 */           removeButton.setEnabled(nodes.length > 0);
/*  89:    */         }
/*  90:    */         
/*  91:    */       }
/*  92: 92 */     });
/*  93: 93 */     addPopupMenu = new JPopupMenu();
/*  94: 94 */     addPopupMenu.add(new AbstractAction("Fixed")
/*  95:    */     {
/*  96:    */       public void actionPerformed(ActionEvent e) {
/*  97: 97 */         childFactory.beans.add(new FixedEventBean());
/*  98: 98 */         childFactory.refreshData();
/*  99: 99 */         lastUsedAction = this;
/* 100:    */       }
/* 101:101 */     });
/* 102:102 */     addPopupMenu.add(new AbstractAction("Easter Related")
/* 103:    */     {
/* 104:    */       public void actionPerformed(ActionEvent e) {
/* 105:105 */         childFactory.beans.add(new EasterRelatedEventBean());
/* 106:106 */         childFactory.refreshData();
/* 107:107 */         lastUsedAction = this;
/* 108:    */       }
/* 109:109 */     });
/* 110:110 */     addPopupMenu.add(new AbstractAction("Fixed Week")
/* 111:    */     {
/* 112:    */       public void actionPerformed(ActionEvent e) {
/* 113:113 */         childFactory.beans.add(new FixedWeekEventBean());
/* 114:114 */         childFactory.refreshData();
/* 115:115 */         lastUsedAction = this;
/* 116:    */       }
/* 117:117 */     });
/* 118:118 */     addPopupMenu.add(new AbstractAction("Special Day")
/* 119:    */     {
/* 120:    */       public void actionPerformed(ActionEvent e) {
/* 121:121 */         childFactory.beans.add(new SpecialEventBean());
/* 122:122 */         childFactory.refreshData();
/* 123:123 */         lastUsedAction = this;
/* 124:    */       }
/* 125:    */       
/* 126:126 */     });
/* 127:127 */     initComponents();
/* 128:    */     
/* 129:129 */     jButton1.addActionListener(new ActionListener()
/* 130:    */     {
/* 131:    */       public void actionPerformed(ActionEvent e) {
/* 132:132 */         if (lastUsedAction != null) {
/* 133:133 */           lastUsedAction.actionPerformed(e);
/* 134:    */         }
/* 135:    */         
/* 136:    */       }
/* 137:137 */     });
/* 138:138 */     nameTextFieldListener = new NameTextFieldListener(null);
/* 139:139 */     meanListener = new MeanCheckBoxListener(null);
/* 140:    */     
/* 141:141 */     listView1.setShowParentNode(false);
/* 142:142 */     listView1.setSelectionMode(2);
/* 143:143 */     nameTextField.getDocument().addDocumentListener(nameTextFieldListener);
/* 144:144 */     meanCB.addActionListener(meanListener);
/* 145:145 */     removeButton.setEnabled(false);
/* 146:    */     
/* 147:147 */     addPropertyChangeListener(new java.beans.PropertyChangeListener() {
/* 148:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 149:    */         String str;
/* 150:150 */         switch ((str = evt.getPropertyName()).hashCode()) {case -621819108:  if (str.equals("specialDayEvents")) break; break; case -446112509:  if (str.equals("meanCorrection")) {} case -352838935:  if ((goto 107) && (str.equals("calendarName")))
/* 151:    */           {
/* 152:152 */             onCalendarNameChange();
/* 153:153 */             return;
/* 154:    */             
/* 155:155 */             onSpecialDayEventsChange();
/* 156:156 */             return;
/* 157:    */             
/* 158:158 */             onMeanChange();
/* 159:    */           }
/* 160:    */           
/* 161:    */ 
/* 162:    */ 
/* 163:    */           break;
/* 164:    */         }
/* 165:    */         
/* 166:    */       }
/* 167:    */     });
/* 168:    */   }
/* 169:    */   
/* 170:    */ 
/* 171:    */ 
/* 172:    */   private void initComponents()
/* 173:    */   {
/* 174:174 */     jLabel1 = new JLabel();
/* 175:175 */     nameTextField = new JTextField();
/* 176:176 */     jToolBar1 = new JToolBar();
/* 177:177 */     jLabel2 = new JLabel();
/* 178:178 */     jButton1 = DropDownButtonFactory.createDropDownButton(ec.nbdemetra.ui.DemetraUiIcon.LIST_ADD_16, addPopupMenu);
/* 179:179 */     removeButton = new JButton();
/* 180:180 */     jSplitPane1 = new JSplitPane();
/* 181:181 */     listView1 = new ListView();
/* 182:182 */     propertySheetView1 = new PropertySheetView();
/* 183:183 */     meanCB = new JCheckBox();
/* 184:    */     
/* 185:185 */     jLabel1.setText("Name:");
/* 186:    */     
/* 187:187 */     jToolBar1.setFloatable(false);
/* 188:188 */     jToolBar1.setRollover(true);
/* 189:    */     
/* 190:190 */     jLabel2.setText("Special days:");
/* 191:191 */     jToolBar1.add(jLabel2);
/* 192:    */     
/* 193:193 */     jButton1.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/list-add_16x16.png")));
/* 194:194 */     jButton1.setToolTipText("");
/* 195:195 */     jButton1.setFocusable(false);
/* 196:196 */     jButton1.setHorizontalTextPosition(0);
/* 197:197 */     jButton1.setVerticalTextPosition(3);
/* 198:198 */     jToolBar1.add(jButton1);
/* 199:    */     
/* 200:200 */     removeButton.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/list-remove_16x16.png")));
/* 201:201 */     removeButton.setFocusable(false);
/* 202:202 */     removeButton.setHorizontalTextPosition(0);
/* 203:203 */     removeButton.setVerticalTextPosition(3);
/* 204:204 */     removeButton.addActionListener(new ActionListener() {
/* 205:    */       public void actionPerformed(ActionEvent evt) {
/* 206:206 */         NationalCalendarPanel.this.removeButtonActionPerformed(evt);
/* 207:    */       }
/* 208:208 */     });
/* 209:209 */     jToolBar1.add(removeButton);
/* 210:    */     
/* 211:211 */     jSplitPane1.setResizeWeight(0.5D);
/* 212:212 */     jSplitPane1.setLeftComponent(listView1);
/* 213:213 */     jSplitPane1.setRightComponent(propertySheetView1);
/* 214:    */     
/* 215:215 */     meanCB.setSelected(true);
/* 216:216 */     meanCB.setText("Long term mean correction");
/* 217:    */     
/* 218:218 */     GroupLayout layout = new GroupLayout(this);
/* 219:219 */     setLayout(layout);
/* 220:220 */     layout.setHorizontalGroup(
/* 221:221 */       layout.createParallelGroup(1)
/* 222:222 */       .add(2, layout.createSequentialGroup()
/* 223:223 */       .addContainerGap()
/* 224:224 */       .add(layout.createParallelGroup(1)
/* 225:225 */       .add(2, jSplitPane1, -1, 501, 32767)
/* 226:226 */       .add(jToolBar1, -1, -1, 32767)
/* 227:227 */       .add(layout.createSequentialGroup()
/* 228:228 */       .add(jLabel1)
/* 229:229 */       .add(0, 0, 32767))
/* 230:230 */       .add(layout.createSequentialGroup()
/* 231:231 */       .add(nameTextField, -2, 242, -2)
/* 232:232 */       .addPreferredGap(0, -1, 32767)
/* 233:233 */       .add(meanCB, -2, 163, -2)))
/* 234:234 */       .addContainerGap()));
/* 235:    */     
/* 236:236 */     layout.setVerticalGroup(
/* 237:237 */       layout.createParallelGroup(1)
/* 238:238 */       .add(layout.createSequentialGroup()
/* 239:239 */       .add(4, 4, 4)
/* 240:240 */       .add(jLabel1)
/* 241:241 */       .addPreferredGap(0)
/* 242:242 */       .add(layout.createParallelGroup(3)
/* 243:243 */       .add(nameTextField, -2, -1, -2)
/* 244:244 */       .add(meanCB))
/* 245:245 */       .addPreferredGap(1)
/* 246:246 */       .add(jToolBar1, -2, -1, -2)
/* 247:247 */       .addPreferredGap(0)
/* 248:248 */       .add(jSplitPane1, -1, 320, 32767)
/* 249:249 */       .addContainerGap()));
/* 250:    */   }
/* 251:    */   
/* 252:    */   private void removeButtonActionPerformed(ActionEvent evt)
/* 253:    */   {
/* 254:254 */     for (Node o : em.getSelectedNodes()) {
/* 255:255 */       childFactory.beans.remove(o.getLookup().lookup(AbstractEventBean.class));
/* 256:    */     }
/* 257:257 */     childFactory.refreshData();
/* 258:    */   }
/* 259:    */   
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */ 
/* 272:    */   protected void onCalendarNameChange()
/* 273:    */   {
/* 274:274 */     if (nameTextFieldListener.state == ListenerState.READY) {
/* 275:275 */       nameTextFieldListener.state = ListenerState.SUSPENDED;
/* 276:276 */       nameTextField.setText((String)calendarName.get());
/* 277:277 */       nameTextFieldListener.state = ListenerState.READY;
/* 278:    */     }
/* 279:    */   }
/* 280:    */   
/* 281:    */   protected void onMeanChange() {
/* 282:282 */     if (meanListener.state == ListenerState.READY) {
/* 283:283 */       meanListener.state = ListenerState.SUSPENDED;
/* 284:284 */       meanCB.setSelected(((Boolean)meanCorrection.get()).booleanValue());
/* 285:285 */       meanListener.state = ListenerState.READY;
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   protected void onSpecialDayEventsChange() {
/* 290:290 */     if (childFactory.state == ListenerState.READY) {
/* 291:291 */       childFactory.state = ListenerState.SUSPENDED;
/* 292:292 */       childFactory.beans.clear();
/* 293:293 */       for (SpecialDayEvent o : (ImmutableList)specialDayEvents.get()) {
/* 294:294 */         if ((day instanceof FixedDay)) {
/* 295:295 */           childFactory.beans.add(new FixedEventBean((FixedDay)day, o.getValidityPeriod()));
/* 296:296 */         } else if ((day instanceof EasterRelatedDay)) {
/* 297:297 */           childFactory.beans.add(new EasterRelatedEventBean((EasterRelatedDay)day, o.getValidityPeriod()));
/* 298:298 */         } else if ((day instanceof FixedWeekDay)) {
/* 299:299 */           childFactory.beans.add(new FixedWeekEventBean((FixedWeekDay)day, o.getValidityPeriod()));
/* 300:300 */         } else if ((day instanceof SpecialCalendarDay)) {
/* 301:301 */           childFactory.beans.add(new SpecialEventBean((SpecialCalendarDay)day, o.getValidityPeriod()));
/* 302:    */         }
/* 303:    */       }
/* 304:304 */       childFactory.refreshData();
/* 305:305 */       childFactory.state = ListenerState.READY;
/* 306:    */     }
/* 307:    */   }
/* 308:    */   
/* 309:    */ 
/* 310:    */   public String getCalendarName()
/* 311:    */   {
/* 312:312 */     return (String)calendarName.get();
/* 313:    */   }
/* 314:    */   
/* 315:    */   public void setCalendarName(String calendarName) {
/* 316:316 */     this.calendarName.set(calendarName);
/* 317:    */   }
/* 318:    */   
/* 319:    */   public boolean isMeanCorrection() {
/* 320:320 */     return ((Boolean)meanCorrection.get()).booleanValue();
/* 321:    */   }
/* 322:    */   
/* 323:    */   public void setMeanCorrection(boolean mean) {
/* 324:324 */     meanCorrection.set(Boolean.valueOf(mean));
/* 325:    */   }
/* 326:    */   
/* 327:    */   public ImmutableList<SpecialDayEvent> getSpecialDayEvents() {
/* 328:328 */     return (ImmutableList)specialDayEvents.get();
/* 329:    */   }
/* 330:    */   
/* 331:    */   public void setSpecialDayEvents(ImmutableList<SpecialDayEvent> events) {
/* 332:332 */     specialDayEvents.set(events);
/* 333:    */   }
/* 334:    */   
/* 335:    */   public ExplorerManager getExplorerManager()
/* 336:    */   {
/* 337:337 */     return em;
/* 338:    */   }
/* 339:    */   
/* 340:    */   class ListOfSpecialDayEvent extends ChildFactory<AbstractEventBean> implements NodeListener {
/* 341:    */     ListOfSpecialDayEvent() {}
/* 342:    */     
/* 343:343 */     public final List<AbstractEventBean> beans = new java.util.ArrayList();
/* 344:344 */     ListenerState state = ListenerState.READY;
/* 345:    */     
/* 346:    */     public void refreshData() {
/* 347:347 */       refresh(true);
/* 348:348 */       fireDataChange();
/* 349:    */     }
/* 350:    */     
/* 351:    */     void fireDataChange() {
/* 352:352 */       if (state == ListenerState.READY) {
/* 353:353 */         state = ListenerState.SENDING;
/* 354:354 */         ImmutableList.Builder<SpecialDayEvent> tmp = ImmutableList.builder();
/* 355:355 */         for (AbstractEventBean o : beans) {
/* 356:356 */           tmp.add(o.toEvent());
/* 357:    */         }
/* 358:358 */         setSpecialDayEvents(tmp.build());
/* 359:359 */         state = ListenerState.READY;
/* 360:    */       }
/* 361:    */     }
/* 362:    */     
/* 363:    */     protected boolean createKeys(List<AbstractEventBean> toPopulate)
/* 364:    */     {
/* 365:365 */       toPopulate.addAll(beans);
/* 366:366 */       return true;
/* 367:    */     }
/* 368:    */     
/* 369:    */     protected Node createNodeForKey(AbstractEventBean key)
/* 370:    */     {
/* 371:    */       Node result;
/* 372:372 */       if ((key instanceof FixedEventBean)) {
/* 373:373 */         result = new FixedEventNode((FixedEventBean)key); } else { Node result;
/* 374:374 */         if ((key instanceof EasterRelatedEventBean)) {
/* 375:375 */           result = new EasterRelatedEventNode((EasterRelatedEventBean)key); } else { Node result;
/* 376:376 */           if ((key instanceof FixedWeekEventBean)) {
/* 377:377 */             result = new FixedWeekEventNode((FixedWeekEventBean)key); } else { Node result;
/* 378:378 */             if ((key instanceof SpecialEventBean)) {
/* 379:379 */               result = new SpecialEventNode((SpecialEventBean)key);
/* 380:    */             } else
/* 381:381 */               throw new UnsupportedOperationException(); } } }
/* 382:    */       Node result;
/* 383:383 */       result.addNodeListener((NodeListener)WeakListeners.create(NodeListener.class, this, result));
/* 384:384 */       return result;
/* 385:    */     }
/* 386:    */     
/* 387:    */     public void propertyChange(PropertyChangeEvent evt)
/* 388:    */     {
/* 389:389 */       String p = evt.getPropertyName();
/* 390:390 */       if (p.equals("displayName")) {
/* 391:391 */         fireDataChange();
/* 392:    */       }
/* 393:    */     }
/* 394:    */     
/* 395:    */ 
/* 396:    */     public void childrenAdded(NodeMemberEvent ev) {}
/* 397:    */     
/* 398:    */ 
/* 399:    */     public void childrenRemoved(NodeMemberEvent ev) {}
/* 400:    */     
/* 401:    */ 
/* 402:    */     public void childrenReordered(NodeReorderEvent ev) {}
/* 403:    */     
/* 404:    */ 
/* 405:    */     public void nodeDestroyed(NodeEvent ev) {}
/* 406:    */   }
/* 407:    */   
/* 408:    */ 
/* 409:    */   private class NameTextFieldListener
/* 410:    */     implements DocumentListener
/* 411:    */   {
/* 412:    */     private NameTextFieldListener() {}
/* 413:    */     
/* 414:414 */     ListenerState state = ListenerState.READY;
/* 415:    */     
/* 416:    */     void update() {
/* 417:417 */       if (state == ListenerState.READY) {
/* 418:418 */         state = ListenerState.SENDING;
/* 419:419 */         setCalendarName(nameTextField.getText());
/* 420:420 */         state = ListenerState.READY;
/* 421:    */       }
/* 422:    */     }
/* 423:    */     
/* 424:    */     public void insertUpdate(DocumentEvent e)
/* 425:    */     {
/* 426:426 */       update();
/* 427:    */     }
/* 428:    */     
/* 429:    */     public void removeUpdate(DocumentEvent e)
/* 430:    */     {
/* 431:431 */       update();
/* 432:    */     }
/* 433:    */     
/* 434:    */     public void changedUpdate(DocumentEvent e) {}
/* 435:    */   }
/* 436:    */   
/* 437:    */   private class MeanCheckBoxListener implements ActionListener
/* 438:    */   {
/* 439:    */     private MeanCheckBoxListener() {}
/* 440:    */     
/* 441:441 */     ListenerState state = ListenerState.READY;
/* 442:    */     
/* 443:    */     void update() {
/* 444:444 */       if (state == ListenerState.READY) {
/* 445:445 */         state = ListenerState.SENDING;
/* 446:446 */         setMeanCorrection(meanCB.isSelected());
/* 447:447 */         state = ListenerState.READY;
/* 448:    */       }
/* 449:    */     }
/* 450:    */     
/* 451:    */     public void actionPerformed(ActionEvent e)
/* 452:    */     {
/* 453:453 */       update();
/* 454:    */     }
/* 455:    */   }
/* 456:    */   
/* 457:    */   public org.openide.DialogDescriptor createDialogDescriptor(String title)
/* 458:    */   {
/* 459:459 */     return new NationalDialogDescriptor(this, title);
/* 460:    */   }
/* 461:    */   
/* 462:    */   static class NationalDialogDescriptor extends CustomDialogDescriptor<NationalCalendarPanel.NationalConstraintData>
/* 463:    */   {
/* 464:    */     NationalDialogDescriptor(NationalCalendarPanel p, String title) {
/* 465:465 */       super(title, new NationalCalendarPanel.NationalConstraintData(p, p.getCalendarName()));
/* 466:466 */       validate(NationalCalendarPanel.NationalConstraints.values());
/* 467:    */     }
/* 468:    */     
/* 469:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 470:    */       String str;
/* 471:471 */       switch ((str = evt.getPropertyName()).hashCode()) {case -621819108:  if (str.equals("specialDayEvents")) break;  case -352838935:  if ((goto 103) && (str.equals("calendarName")))
/* 472:    */         {
/* 473:473 */           validate(new IConstraint[] { NationalCalendarPanel.NationalConstraints.CALENDAR_NAME, NationalCalendarPanel.NationalConstraints.SPECIAL_DAY_EVENTS });
/* 474:474 */           return;
/* 475:    */           
/* 476:476 */           validate(new IConstraint[] { NationalCalendarPanel.NationalConstraints.SPECIAL_DAY_EVENTS, NationalCalendarPanel.NationalConstraints.CALENDAR_NAME });
/* 477:    */         }
/* 478:    */         break;
/* 479:    */       }
/* 480:    */     }
/* 481:    */   }
/* 482:    */   
/* 483:    */   private static class NationalConstraintData {
/* 484:    */     final NationalCalendarPanel panel;
/* 485:    */     final String originalName;
/* 486:    */     final GregorianCalendarManager manager;
/* 487:    */     
/* 488:    */     NationalConstraintData(NationalCalendarPanel panel, String originalName) {
/* 489:489 */       this.panel = panel;
/* 490:490 */       this.originalName = originalName;
/* 491:491 */       manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/* 492:    */     }
/* 493:    */   }
/* 494:    */   
/* 495:    */   private static abstract enum NationalConstraints implements IConstraint<NationalCalendarPanel.NationalConstraintData>
/* 496:    */   {
/* 497:497 */     CALENDAR_NAME, 
/* 498:    */     
/* 499:    */ 
/* 500:    */ 
/* 501:    */ 
/* 502:    */ 
/* 503:    */ 
/* 504:    */ 
/* 505:    */ 
/* 506:    */ 
/* 507:    */ 
/* 508:    */ 
/* 509:    */ 
/* 510:510 */     SPECIAL_DAY_EVENTS;
/* 511:    */   }
/* 512:    */ }
