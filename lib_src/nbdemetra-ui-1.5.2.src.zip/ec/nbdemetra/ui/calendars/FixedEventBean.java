/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Objects;
/*  4:   */ import com.google.common.base.Objects.ToStringHelper;
/*  5:   */ import ec.tstoolkit.timeseries.Day;
/*  6:   */ import ec.tstoolkit.timeseries.Month;
/*  7:   */ import ec.tstoolkit.timeseries.ValidityPeriod;
/*  8:   */ import ec.tstoolkit.timeseries.calendars.FixedDay;
/*  9:   */ import ec.tstoolkit.timeseries.calendars.ISpecialDay;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class FixedEventBean
/* 19:   */   extends AbstractEventBean
/* 20:   */ {
/* 21:   */   public static final String DAY_PROPERTY = "day";
/* 22:   */   public static final String MONTH_PROPERTY = "month";
/* 23:   */   protected int day;
/* 24:   */   protected Month month;
/* 25:   */   
/* 26:   */   public FixedEventBean()
/* 27:   */   {
/* 28:28 */     this(1, Month.January, null, null, 1.0D);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public FixedEventBean(FixedDay day, ValidityPeriod vp) {
/* 32:32 */     this(day + 1, month, vp != null ? vp.getStart() : null, vp != null ? vp.getEnd() : null, day.getWeight());
/* 33:   */   }
/* 34:   */   
/* 35:   */   public FixedEventBean(int day, Month month, Day start, Day end, double weight) {
/* 36:36 */     super(start, end, weight);
/* 37:37 */     this.day = day;
/* 38:38 */     this.month = month;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public int getDay() {
/* 42:42 */     return day;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setDay(int day) {
/* 46:46 */     int old = this.day;
/* 47:47 */     this.day = day;
/* 48:48 */     firePropertyChange("day", Integer.valueOf(old), Integer.valueOf(this.day));
/* 49:   */   }
/* 50:   */   
/* 51:   */   public Month getMonth() {
/* 52:52 */     return month;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void setMonth(Month month) {
/* 56:56 */     Month old = this.month;
/* 57:57 */     this.month = month;
/* 58:58 */     firePropertyChange("month", old, this.month);
/* 59:   */   }
/* 60:   */   
/* 61:   */   protected ISpecialDay toSpecialDay()
/* 62:   */   {
/* 63:63 */     return new FixedDay(day - 1, month, weight);
/* 64:   */   }
/* 65:   */   
/* 66:   */   public String toString()
/* 67:   */   {
/* 68:68 */     return Objects.toStringHelper(this).add("day", day).add("month", month).add("start", start).add("end", end).add("weigth", weight).toString();
/* 69:   */   }
/* 70:   */ }
