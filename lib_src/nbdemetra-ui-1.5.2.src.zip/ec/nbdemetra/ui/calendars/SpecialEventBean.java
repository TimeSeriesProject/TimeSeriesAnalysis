/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.Day;
/*  4:   */ import ec.tstoolkit.timeseries.ValidityPeriod;
/*  5:   */ import ec.tstoolkit.timeseries.calendars.DayEvent;
/*  6:   */ import ec.tstoolkit.timeseries.calendars.SpecialCalendarDay;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class SpecialEventBean
/* 17:   */   extends AbstractEventBean
/* 18:   */ {
/* 19:   */   public static final String DAY_EVENT_PROPERTY = "dayEvent";
/* 20:   */   public static final String OFFSET_PROPERTY = "offset";
/* 21:   */   protected DayEvent dayEvent;
/* 22:   */   protected int offset;
/* 23:   */   
/* 24:   */   public SpecialEventBean()
/* 25:   */   {
/* 26:26 */     this(DayEvent.Christmas, 0, null, null, 1.0D);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public SpecialEventBean(SpecialCalendarDay day, ValidityPeriod vp) {
/* 30:30 */     this(event, offset, vp != null ? vp.getStart() : null, vp != null ? vp.getEnd() : null, day.getWeight());
/* 31:   */   }
/* 32:   */   
/* 33:   */   public SpecialEventBean(DayEvent dayEvent, int offset, Day start, Day end, double weight) {
/* 34:34 */     super(start, end, weight);
/* 35:35 */     this.dayEvent = dayEvent;
/* 36:36 */     this.offset = offset;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public DayEvent getDayEvent() {
/* 40:40 */     return dayEvent;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setDayEvent(DayEvent dayEvent) {
/* 44:44 */     DayEvent old = this.dayEvent;
/* 45:45 */     this.dayEvent = dayEvent;
/* 46:46 */     firePropertyChange("dayEvent", old, this.dayEvent);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public int getOffset() {
/* 50:50 */     return offset;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void setOffset(int offset) {
/* 54:54 */     int old = this.offset;
/* 55:55 */     this.offset = offset;
/* 56:56 */     firePropertyChange("offset", Integer.valueOf(old), Integer.valueOf(this.offset));
/* 57:   */   }
/* 58:   */   
/* 59:   */   protected SpecialCalendarDay toSpecialDay()
/* 60:   */   {
/* 61:61 */     return new SpecialCalendarDay(dayEvent, offset, weight);
/* 62:   */   }
/* 63:   */ }
