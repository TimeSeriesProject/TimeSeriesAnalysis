/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  4:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.EnumStep;
/*  5:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.IntStep;
/*  6:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  7:   */ import ec.tstoolkit.timeseries.DayOfWeek;
/*  8:   */ import ec.tstoolkit.timeseries.Month;
/*  9:   */ import org.openide.nodes.Sheet;
/* 10:   */ import org.openide.util.Lookup;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class FixedWeekEventNode
/* 15:   */   extends AbstractEventNode
/* 16:   */ {
/* 17:   */   public FixedWeekEventNode(FixedWeekEventBean bean)
/* 18:   */   {
/* 19:19 */     super(bean);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getHtmlDisplayName()
/* 23:   */   {
/* 24:24 */     FixedWeekEventBean bean = (FixedWeekEventBean)getLookup().lookup(FixedWeekEventBean.class);
/* 25:25 */     StringBuilder sb = new StringBuilder();
/* 26:26 */     sb.append("<b>Fixed Week</b> ");
/* 27:27 */     sb.append(dayOfWeek).append(", ").append(month).append(", ").append(week);
/* 28:28 */     return sb.toString();
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected Sheet createSheet()
/* 32:   */   {
/* 33:33 */     FixedWeekEventBean bean = (FixedWeekEventBean)getLookup().lookup(FixedWeekEventBean.class);
/* 34:34 */     Sheet result = super.createSheet();
/* 35:35 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Fixed Week Day");
/* 36:36 */     ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(DayOfWeek.class).select(bean, "dayOfWeek")).display("Day Of Week")).add();
/* 37:37 */     ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(Month.class).select(bean, "month")).display("Month")).add();
/* 38:38 */     ((NodePropertySetBuilder.IntStep)((NodePropertySetBuilder.IntStep)b.withInt().select(bean, "week")).min(1).max(5).display("Week")).add();
/* 39:39 */     result.put(b.build());
/* 40:40 */     return result;
/* 41:   */   }
/* 42:   */ }
