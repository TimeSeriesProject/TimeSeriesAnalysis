/*   1:    */ package ec.nbdemetra.ui.calendars;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   4:    */ import ec.nbdemetra.ws.AbstractWorkspaceItemManager;
/*   5:    */ import ec.nbdemetra.ws.IWorkspaceItemManager.ItemType;
/*   6:    */ import ec.nbdemetra.ws.IWorkspaceItemManager.Status;
/*   7:    */ import ec.nbdemetra.ws.Workspace;
/*   8:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   9:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*  10:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  11:    */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  12:    */ import ec.tstoolkit.timeseries.calendars.NationalCalendarProvider;
/*  13:    */ import ec.tstoolkit.utilities.Id;
/*  14:    */ import ec.tstoolkit.utilities.LinearId;
/*  15:    */ import java.awt.event.ActionEvent;
/*  16:    */ import java.util.ArrayList;
/*  17:    */ import java.util.List;
/*  18:    */ import javax.swing.AbstractAction;
/*  19:    */ import javax.swing.Action;
/*  20:    */ import javax.swing.Icon;
/*  21:    */ import org.openide.windows.TopComponent;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ public class CalendarDocumentManager
/*  27:    */   extends AbstractWorkspaceItemManager<IGregorianCalendarProvider>
/*  28:    */ {
/*  29: 29 */   public static final LinearId ID = new LinearId("Utilities", "Calendars");
/*  30:    */   public static final String PATH = "Calendars";
/*  31:    */   public static final String ITEMPATH = "Calendars.item";
/*  32:    */   
/*  33:    */   protected String getItemPrefix()
/*  34:    */   {
/*  35: 35 */     return "Calendars";
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Id getId()
/*  39:    */   {
/*  40: 40 */     return ID;
/*  41:    */   }
/*  42:    */   
/*  43:    */   protected IGregorianCalendarProvider createNewObject()
/*  44:    */   {
/*  45: 45 */     return new NationalCalendarProvider();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public IWorkspaceItemManager.ItemType getItemType()
/*  49:    */   {
/*  50: 50 */     return IWorkspaceItemManager.ItemType.Doc;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String getActionsPath()
/*  54:    */   {
/*  55: 55 */     return "Calendars";
/*  56:    */   }
/*  57:    */   
/*  58:    */   public IWorkspaceItemManager.Status getStatus()
/*  59:    */   {
/*  60: 60 */     return IWorkspaceItemManager.Status.Experimental;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Action getPreferredItemAction(final Id child)
/*  64:    */   {
/*  65: 65 */     new AbstractAction()
/*  66:    */     {
/*  67:    */       public void actionPerformed(ActionEvent e) {
/*  68: 68 */         WorkspaceItem<IGregorianCalendarProvider> doc = WorkspaceFactory.getInstance().getActiveWorkspace().searchDocument(child);
/*  69: 69 */         if (doc != null) {
/*  70: 70 */           openDocument(doc);
/*  71:    */         }
/*  72:    */       }
/*  73:    */     };
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void openDocument(WorkspaceItem<IGregorianCalendarProvider> doc) {
/*  77: 77 */     if (doc.isOpen()) {
/*  78: 78 */       doc.getView().requestActive();
/*  79:    */     } else {
/*  80: 80 */       CalendarTopComponent view = new CalendarTopComponent(doc);
/*  81: 81 */       view.open();
/*  82: 82 */       view.requestActive();
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public List<WorkspaceItem<IGregorianCalendarProvider>> getDefaultItems()
/*  87:    */   {
/*  88: 88 */     List<WorkspaceItem<IGregorianCalendarProvider>> result = new ArrayList();
/*  89: 89 */     String o = "Default";
/*  90: 90 */     result.add(systemItem(o, GregorianCalendarManager.getDefault(o)));
/*  91: 91 */     return result;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public Class<IGregorianCalendarProvider> getItemClass()
/*  95:    */   {
/*  96: 96 */     return IGregorianCalendarProvider.class;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Icon getManagerIcon()
/* 100:    */   {
/* 101:101 */     return DemetraUiIcon.CALENDAR_16;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Icon getItemIcon(WorkspaceItem<IGregorianCalendarProvider> doc)
/* 105:    */   {
/* 106:106 */     IGregorianCalendarProvider o = (IGregorianCalendarProvider)doc.getElement();
/* 107:107 */     if (((o instanceof NationalCalendarProvider)) && (((NationalCalendarProvider)o).isLocked())) {
/* 108:108 */       return DemetraUiIcon.PUZZLE_16;
/* 109:    */     }
/* 110:110 */     return super.getItemIcon(doc);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static WorkspaceItem<IGregorianCalendarProvider> systemItem(String name, IGregorianCalendarProvider p) {
/* 114:114 */     return WorkspaceItem.system(ID, name, p);
/* 115:    */   }
/* 116:    */ }
