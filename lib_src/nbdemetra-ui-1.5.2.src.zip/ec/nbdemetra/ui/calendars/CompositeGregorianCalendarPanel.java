/*   1:    */ package ec.nbdemetra.ui.calendars;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.ImmutableList;
/*   4:    */ import com.google.common.collect.ImmutableList.Builder;
/*   5:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   6:    */ import ec.nbdemetra.ui.awt.IDialogDescriptorProvider;
/*   7:    */ import ec.nbdemetra.ui.awt.JPanel2;
/*   8:    */ import ec.nbdemetra.ui.awt.JProperty;
/*   9:    */ import ec.nbdemetra.ui.awt.ListenableBean;
/*  10:    */ import ec.nbdemetra.ui.awt.ListenerState;
/*  11:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  12:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.BooleanStep;
/*  13:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DoubleStep;
/*  14:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  15:    */ import ec.tss.tsproviders.utils.IConstraint;
/*  16:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  17:    */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  18:    */ import ec.tstoolkit.utilities.WeightedItem;
/*  19:    */ import java.awt.Image;
/*  20:    */ import java.beans.PropertyChangeEvent;
/*  21:    */ import java.beans.PropertyChangeListener;
/*  22:    */ import java.util.List;
/*  23:    */ import java.util.Map;
/*  24:    */ import javax.swing.ImageIcon;
/*  25:    */ import javax.swing.JLabel;
/*  26:    */ import javax.swing.JTextField;
/*  27:    */ import javax.swing.event.DocumentEvent;
/*  28:    */ import javax.swing.event.DocumentListener;
/*  29:    */ import javax.swing.text.Document;
/*  30:    */ import org.jdesktop.layout.GroupLayout;
/*  31:    */ import org.jdesktop.layout.GroupLayout.ParallelGroup;
/*  32:    */ import org.jdesktop.layout.GroupLayout.SequentialGroup;
/*  33:    */ import org.openide.explorer.ExplorerManager;
/*  34:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  35:    */ import org.openide.explorer.view.TreeTableView;
/*  36:    */ import org.openide.nodes.AbstractNode;
/*  37:    */ import org.openide.nodes.ChildFactory;
/*  38:    */ import org.openide.nodes.Children;
/*  39:    */ import org.openide.nodes.Node;
/*  40:    */ import org.openide.nodes.Node.PropertySet;
/*  41:    */ import org.openide.nodes.NodeEvent;
/*  42:    */ import org.openide.nodes.NodeListener;
/*  43:    */ import org.openide.nodes.NodeMemberEvent;
/*  44:    */ import org.openide.nodes.NodeReorderEvent;
/*  45:    */ import org.openide.nodes.Sheet;
/*  46:    */ import org.openide.util.Lookup;
/*  47:    */ import org.openide.util.WeakListeners;
/*  48:    */ 
/*  49:    */ public class CompositeGregorianCalendarPanel extends JPanel2 implements ExplorerManager.Provider, IDialogDescriptorProvider
/*  50:    */ {
/*  51:    */   public static final String CALENDAR_NAME_PROPERTY = "calendarName";
/*  52:    */   public static final String WEIGHTED_ITEMS_PROPERTY = "weightedItems";
/*  53:    */   protected final JProperty<String> calendarName;
/*  54:    */   protected final JProperty<ImmutableList<WeightedItem<String>>> weightedItems;
/*  55:    */   final ExplorerManager em;
/*  56:    */   final NameTextFieldListener nameTextFieldListener;
/*  57:    */   final ListOfWeightedItem childFactory;
/*  58:    */   final String initialCalendarName;
/*  59:    */   private JLabel jLabel1;
/*  60:    */   private JTextField nameTextField;
/*  61:    */   private TreeTableView treeTableView1;
/*  62:    */   
/*  63:    */   public CompositeGregorianCalendarPanel(String initialCalendarName)
/*  64:    */   {
/*  65: 65 */     this.initialCalendarName = initialCalendarName;
/*  66: 66 */     calendarName = newProperty("calendarName", JProperty.nullTo(""), initialCalendarName);
/*  67: 67 */     weightedItems = newProperty("weightedItems", JProperty.nullTo(ImmutableList.of()), null);
/*  68:    */     
/*  69: 69 */     em = new ExplorerManager();
/*  70:    */     
/*  71: 71 */     initComponents();
/*  72:    */     
/*  73: 73 */     childFactory = new ListOfWeightedItem();
/*  74:    */     
/*  75: 75 */     em.setRootContext(new AbstractNode(Children.create(childFactory, false)));
/*  76:    */     
/*  77: 77 */     nameTextFieldListener = new NameTextFieldListener(null);
/*  78:    */     
/*  79: 79 */     treeTableView1.setRootVisible(false);
/*  80: 80 */     treeTableView1.setSelectionMode(2);
/*  81: 81 */     WeightedItemNode template = new WeightedItemNode(new WeightedItemBean(""));
/*  82: 82 */     treeTableView1.setProperties(template.getPropertySets()[0].getProperties());
/*  83:    */     
/*  84: 84 */     nameTextField.setText((String)calendarName.get());
/*  85: 85 */     nameTextField.getDocument().addDocumentListener(nameTextFieldListener);
/*  86:    */     
/*  87: 87 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  88:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  89:    */         String str;
/*  90: 90 */         switch ((str = evt.getPropertyName()).hashCode()) {case -352838935:  if (str.equals("calendarName")) break; break; case 518159593:  if (!str.equals("weightedItems"))
/*  91:    */           {
/*  92: 92 */             return;onCalendarNameChange();
/*  93:    */           }
/*  94:    */           else {
/*  95: 95 */             onWeightedItemsChange();
/*  96:    */           }
/*  97:    */           
/*  98:    */ 
/*  99:    */ 
/* 100:    */           break;
/* 101:    */         }
/* 102:    */         
/* 103:    */       }
/* 104:    */     });
/* 105:    */   }
/* 106:    */   
/* 107:    */ 
/* 108:    */ 
/* 109:    */   private void initComponents()
/* 110:    */   {
/* 111:111 */     jLabel1 = new JLabel();
/* 112:112 */     nameTextField = new JTextField();
/* 113:113 */     treeTableView1 = new TreeTableView();
/* 114:    */     
/* 115:115 */     jLabel1.setText("Name:");
/* 116:    */     
/* 117:117 */     GroupLayout layout = new GroupLayout(this);
/* 118:118 */     setLayout(layout);
/* 119:119 */     layout.setHorizontalGroup(
/* 120:120 */       layout.createParallelGroup(1)
/* 121:121 */       .add(2, layout.createSequentialGroup()
/* 122:122 */       .addContainerGap()
/* 123:123 */       .add(layout.createParallelGroup(2)
/* 124:124 */       .add(treeTableView1, -1, 502, 32767)
/* 125:125 */       .add(1, nameTextField)
/* 126:126 */       .add(1, layout.createSequentialGroup()
/* 127:127 */       .add(jLabel1)
/* 128:128 */       .add(0, 0, 32767)))
/* 129:129 */       .addContainerGap()));
/* 130:    */     
/* 131:131 */     layout.setVerticalGroup(
/* 132:132 */       layout.createParallelGroup(1)
/* 133:133 */       .add(layout.createSequentialGroup()
/* 134:134 */       .add(4, 4, 4)
/* 135:135 */       .add(jLabel1)
/* 136:136 */       .addPreferredGap(0)
/* 137:137 */       .add(nameTextField, -2, -1, -2)
/* 138:138 */       .addPreferredGap(1)
/* 139:139 */       .add(treeTableView1, -2, 270, -2)
/* 140:140 */       .addContainerGap(-1, 32767)));
/* 141:    */   }
/* 142:    */   
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */   protected void onCalendarNameChange()
/* 150:    */   {
/* 151:151 */     if (nameTextFieldListener.state == ListenerState.READY) {
/* 152:152 */       nameTextFieldListener.state = ListenerState.SUSPENDED;
/* 153:153 */       nameTextField.setText((String)calendarName.get());
/* 154:154 */       nameTextFieldListener.state = ListenerState.READY;
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   protected void onWeightedItemsChange() {
/* 159:159 */     if (childFactory.state == ListenerState.READY) {
/* 160:160 */       childFactory.state = ListenerState.SUSPENDED;
/* 161:161 */       Map<String, Double> tmp = new java.util.HashMap();
/* 162:162 */       for (WeightedItem<String> o : (ImmutableList)weightedItems.get()) {
/* 163:163 */         tmp.put((String)item, Double.valueOf(weight));
/* 164:    */       }
/* 165:165 */       for (WeightedItemBean o : childFactory.beans) {
/* 166:166 */         Double weight = (Double)tmp.get(o.getName());
/* 167:167 */         if (weight != null) {
/* 168:168 */           o.setUsed(true);
/* 169:169 */           o.setWeight(weight.doubleValue());
/* 170:    */         } else {
/* 171:171 */           o.setUsed(false);
/* 172:172 */           o.setWeight(0.0D);
/* 173:    */         }
/* 174:    */       }
/* 175:175 */       childFactory.refreshData();
/* 176:176 */       childFactory.state = ListenerState.READY;
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */ 
/* 181:    */   public String getCalendarName()
/* 182:    */   {
/* 183:183 */     return (String)calendarName.get();
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void setCalendarName(String calendarName) {
/* 187:187 */     this.calendarName.set(calendarName);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public ImmutableList<WeightedItem<String>> getWeightedItems() {
/* 191:191 */     return (ImmutableList)weightedItems.get();
/* 192:    */   }
/* 193:    */   
/* 194:    */   public void setWeightedItems(ImmutableList<WeightedItem<String>> weightedItems) {
/* 195:195 */     this.weightedItems.set(weightedItems);
/* 196:    */   }
/* 197:    */   
/* 198:    */ 
/* 199:    */   public ExplorerManager getExplorerManager()
/* 200:    */   {
/* 201:201 */     return em;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public static class WeightedItemBean
/* 205:    */     extends ListenableBean
/* 206:    */   {
/* 207:    */     public static final String NAME_PROPERTY = "name";
/* 208:    */     public static final String USED_PROPERTY = "used";
/* 209:    */     public static final String WEIGHT_PROPERTY = "weight";
/* 210:    */     protected final JProperty<String> name;
/* 211:    */     protected final JProperty<Boolean> used;
/* 212:    */     protected final JProperty<Double> weight;
/* 213:    */     
/* 214:    */     public WeightedItemBean(String name)
/* 215:    */     {
/* 216:216 */       this.name = newProperty("name", name);
/* 217:217 */       used = newProperty("used", Boolean.valueOf(false));
/* 218:218 */       weight = newProperty("weight", Double.valueOf(0.0D));
/* 219:    */     }
/* 220:    */     
/* 221:    */     public String getName()
/* 222:    */     {
/* 223:223 */       return (String)name.get();
/* 224:    */     }
/* 225:    */     
/* 226:    */     public void setName(String name) {
/* 227:227 */       this.name.set(name);
/* 228:    */     }
/* 229:    */     
/* 230:    */     public boolean isUsed() {
/* 231:231 */       return ((Boolean)used.get()).booleanValue();
/* 232:    */     }
/* 233:    */     
/* 234:    */     public void setUsed(boolean used) {
/* 235:235 */       this.used.set(Boolean.valueOf(used));
/* 236:    */     }
/* 237:    */     
/* 238:    */     public double getWeight() {
/* 239:239 */       return ((Double)weight.get()).doubleValue();
/* 240:    */     }
/* 241:    */     
/* 242:    */     public void setWeight(double weight) {
/* 243:243 */       this.weight.set(Double.valueOf(weight));
/* 244:    */     }
/* 245:    */     
/* 246:    */     public WeightedItem<String> toItem()
/* 247:    */     {
/* 248:248 */       return new WeightedItem((String)name.get(), ((Double)weight.get()).doubleValue());
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   static class WeightedItemNode extends AbstractNode implements PropertyChangeListener
/* 253:    */   {
/* 254:    */     public WeightedItemNode(CompositeGregorianCalendarPanel.WeightedItemBean bean) {
/* 255:255 */       super(org.openide.util.lookup.Lookups.singleton(bean));
/* 256:256 */       setName(bean.getName());
/* 257:257 */       bean.addPropertyChangeListener(WeakListeners.propertyChange(this, bean));
/* 258:    */     }
/* 259:    */     
/* 260:    */     public Image getIcon(int type)
/* 261:    */     {
/* 262:262 */       return DemetraUiIcon.CALENDAR_16.getImageIcon().getImage();
/* 263:    */     }
/* 264:    */     
/* 265:    */     public String getHtmlDisplayName()
/* 266:    */     {
/* 267:267 */       CompositeGregorianCalendarPanel.WeightedItemBean bean = (CompositeGregorianCalendarPanel.WeightedItemBean)getLookup().lookup(CompositeGregorianCalendarPanel.WeightedItemBean.class);
/* 268:268 */       return bean.isUsed() ? "<b>" + getDisplayName() + "</b>" : getDisplayName();
/* 269:    */     }
/* 270:    */     
/* 271:    */     public void propertyChange(PropertyChangeEvent evt)
/* 272:    */     {
/* 273:273 */       fireDisplayNameChange(null, getDisplayName());
/* 274:    */     }
/* 275:    */     
/* 276:    */     protected Sheet createSheet()
/* 277:    */     {
/* 278:278 */       CompositeGregorianCalendarPanel.WeightedItemBean bean = (CompositeGregorianCalendarPanel.WeightedItemBean)getLookup().lookup(CompositeGregorianCalendarPanel.WeightedItemBean.class);
/* 279:279 */       Sheet result = super.createSheet();
/* 280:280 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 281:    */       
/* 282:    */ 
/* 283:283 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().select(bean, "used")).display("Used"))
/* 284:284 */         .add();
/* 285:    */       
/* 286:    */ 
/* 287:    */ 
/* 288:288 */       ((NodePropertySetBuilder.DoubleStep)((NodePropertySetBuilder.DoubleStep)b.withDouble().select(bean, "weight")).min(0.0D).display("Weight"))
/* 289:289 */         .add();
/* 290:290 */       result.put(b.build());
/* 291:291 */       return result;
/* 292:    */     }
/* 293:    */   }
/* 294:    */   
/* 295:    */   class ListOfWeightedItem extends ChildFactory<CompositeGregorianCalendarPanel.WeightedItemBean> implements NodeListener
/* 296:    */   {
/* 297:297 */     public final List<CompositeGregorianCalendarPanel.WeightedItemBean> beans = new java.util.ArrayList();
/* 298:298 */     ListenerState state = ListenerState.READY;
/* 299:    */     
/* 300:    */     public ListOfWeightedItem() {
/* 301:301 */       for (String o : ProcessingContext.getActiveContext().getGregorianCalendars().getNames()) {
/* 302:302 */         if (!o.equals(initialCalendarName)) {
/* 303:303 */           beans.add(new CompositeGregorianCalendarPanel.WeightedItemBean(o));
/* 304:    */         }
/* 305:    */       }
/* 306:    */     }
/* 307:    */     
/* 308:    */     public void refreshData() {
/* 309:309 */       refresh(true);
/* 310:310 */       fireDataChange();
/* 311:    */     }
/* 312:    */     
/* 313:    */     void fireDataChange() {
/* 314:314 */       if (state == ListenerState.READY) {
/* 315:315 */         state = ListenerState.SENDING;
/* 316:316 */         ImmutableList.Builder<WeightedItem<String>> tmp = ImmutableList.builder();
/* 317:317 */         for (CompositeGregorianCalendarPanel.WeightedItemBean o : beans) {
/* 318:318 */           if (o.isUsed()) {
/* 319:319 */             tmp.add(o.toItem());
/* 320:    */           }
/* 321:    */         }
/* 322:322 */         setWeightedItems(tmp.build());
/* 323:323 */         state = ListenerState.READY;
/* 324:    */       }
/* 325:    */     }
/* 326:    */     
/* 327:    */     protected boolean createKeys(List<CompositeGregorianCalendarPanel.WeightedItemBean> toPopulate)
/* 328:    */     {
/* 329:329 */       toPopulate.addAll(beans);
/* 330:330 */       return true;
/* 331:    */     }
/* 332:    */     
/* 333:    */     protected Node createNodeForKey(CompositeGregorianCalendarPanel.WeightedItemBean key)
/* 334:    */     {
/* 335:335 */       Node result = new CompositeGregorianCalendarPanel.WeightedItemNode(key);
/* 336:336 */       result.addNodeListener((NodeListener)WeakListeners.create(NodeListener.class, this, result));
/* 337:337 */       return result;
/* 338:    */     }
/* 339:    */     
/* 340:    */     public void propertyChange(PropertyChangeEvent evt)
/* 341:    */     {
/* 342:342 */       String p = evt.getPropertyName();
/* 343:343 */       if (p.equals("displayName")) {
/* 344:344 */         fireDataChange();
/* 345:    */       }
/* 346:    */     }
/* 347:    */     
/* 348:    */ 
/* 349:    */     public void childrenAdded(NodeMemberEvent ev) {}
/* 350:    */     
/* 351:    */ 
/* 352:    */     public void childrenRemoved(NodeMemberEvent ev) {}
/* 353:    */     
/* 354:    */ 
/* 355:    */     public void childrenReordered(NodeReorderEvent ev) {}
/* 356:    */     
/* 357:    */ 
/* 358:    */     public void nodeDestroyed(NodeEvent ev) {}
/* 359:    */   }
/* 360:    */   
/* 361:    */ 
/* 362:    */   private class NameTextFieldListener
/* 363:    */     implements DocumentListener
/* 364:    */   {
/* 365:    */     private NameTextFieldListener() {}
/* 366:    */     
/* 367:367 */     ListenerState state = ListenerState.READY;
/* 368:    */     
/* 369:    */     void update() {
/* 370:370 */       if (state == ListenerState.READY) {
/* 371:371 */         state = ListenerState.SENDING;
/* 372:372 */         setCalendarName(nameTextField.getText());
/* 373:373 */         state = ListenerState.READY;
/* 374:    */       }
/* 375:    */     }
/* 376:    */     
/* 377:    */     public void insertUpdate(DocumentEvent e)
/* 378:    */     {
/* 379:379 */       update();
/* 380:    */     }
/* 381:    */     
/* 382:    */     public void removeUpdate(DocumentEvent e)
/* 383:    */     {
/* 384:384 */       update();
/* 385:    */     }
/* 386:    */     
/* 387:    */ 
/* 388:    */     public void changedUpdate(DocumentEvent e) {}
/* 389:    */   }
/* 390:    */   
/* 391:    */ 
/* 392:    */   public org.openide.DialogDescriptor createDialogDescriptor(String title)
/* 393:    */   {
/* 394:394 */     return new CompositeDialogDescriptor(this, title);
/* 395:    */   }
/* 396:    */   
/* 397:    */   private static class CompositeDialogDescriptor extends CustomDialogDescriptor<CompositeGregorianCalendarPanel.CompositeConstraintData>
/* 398:    */   {
/* 399:    */     CompositeDialogDescriptor(CompositeGregorianCalendarPanel p, String title) {
/* 400:400 */       super(title, new CompositeGregorianCalendarPanel.CompositeConstraintData(p, p.getCalendarName()));
/* 401:401 */       validate(CompositeGregorianCalendarPanel.CompositeConstraints.values());
/* 402:    */     }
/* 403:    */     
/* 404:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 405:    */       String str;
/* 406:406 */       switch ((str = evt.getPropertyName()).hashCode()) {case -352838935:  if (str.equals("calendarName")) break;  case 518159593:  if ((goto 74) && (!str.equals("weightedItems")))
/* 407:    */         {
/* 408:408 */           return;validate(new IConstraint[] { CompositeGregorianCalendarPanel.CompositeConstraints.CALENDAR_NAME });
/* 409:    */         }
/* 410:    */         break;
/* 411:    */       }
/* 412:    */     }
/* 413:    */   }
/* 414:    */   
/* 415:    */   private static class CompositeConstraintData
/* 416:    */   {
/* 417:    */     final CompositeGregorianCalendarPanel panel;
/* 418:    */     final String originalName;
/* 419:    */     final GregorianCalendarManager manager;
/* 420:    */     
/* 421:    */     CompositeConstraintData(CompositeGregorianCalendarPanel panel, String originalName)
/* 422:    */     {
/* 423:423 */       this.panel = panel;
/* 424:424 */       this.originalName = originalName;
/* 425:425 */       manager = ProcessingContext.getActiveContext().getGregorianCalendars();
/* 426:    */     }
/* 427:    */   }
/* 428:    */   
/* 429:    */   private static abstract enum CompositeConstraints implements IConstraint<CompositeGregorianCalendarPanel.CompositeConstraintData>
/* 430:    */   {
/* 431:431 */     CALENDAR_NAME;
/* 432:    */   }
/* 433:    */ }
