/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.DemetraUiIcon;
/*  4:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  5:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  6:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DoubleStep;
/*  7:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  8:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  9:   */ import ec.tstoolkit.timeseries.Day;
/* 10:   */ import java.awt.Image;
/* 11:   */ import java.beans.PropertyChangeEvent;
/* 12:   */ import java.beans.PropertyChangeListener;
/* 13:   */ import javax.swing.ImageIcon;
/* 14:   */ import org.openide.nodes.AbstractNode;
/* 15:   */ import org.openide.nodes.Children;
/* 16:   */ import org.openide.nodes.Sheet;
/* 17:   */ import org.openide.util.Lookup;
/* 18:   */ import org.openide.util.WeakListeners;
/* 19:   */ import org.openide.util.lookup.Lookups;
/* 20:   */ 
/* 21:   */ public class AbstractEventNode
/* 22:   */   extends AbstractNode implements PropertyChangeListener
/* 23:   */ {
/* 24:   */   public AbstractEventNode(AbstractEventBean bean)
/* 25:   */   {
/* 26:26 */     super(Children.LEAF, Lookups.singleton(bean));
/* 27:27 */     setName(bean.getClass().getSimpleName());
/* 28:28 */     bean.addPropertyChangeListener(WeakListeners.propertyChange(this, bean));
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void propertyChange(PropertyChangeEvent evt)
/* 32:   */   {
/* 33:33 */     fireDisplayNameChange(null, getDisplayName());
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Image getIcon(int type)
/* 37:   */   {
/* 38:38 */     return DemetraUiIcon.CALENDAR_16.getImageIcon().getImage();
/* 39:   */   }
/* 40:   */   
/* 41:   */   protected Sheet createSheet()
/* 42:   */   {
/* 43:43 */     AbstractEventBean bean = (AbstractEventBean)getLookup().lookup(AbstractEventBean.class);
/* 44:44 */     Sheet result = super.createSheet();
/* 45:45 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Event");
/* 46:46 */     ((NodePropertySetBuilder.DefaultStep)b.with(Day.class).select(bean, "start")).display("Start").add();
/* 47:47 */     ((NodePropertySetBuilder.DefaultStep)b.with(Day.class).select(bean, "end")).display("End").add();
/* 48:48 */     ((NodePropertySetBuilder.DoubleStep)((NodePropertySetBuilder.DoubleStep)b.withDouble().select(bean, "weight")).min(0.0D).max(1.0D).display("Weight")).add();
/* 49:49 */     result.put(b.build());
/* 50:50 */     return result;
/* 51:   */   }
/* 52:   */ }
