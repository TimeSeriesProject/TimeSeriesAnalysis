/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.Workspace;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  6:   */ import ec.tstoolkit.timeseries.calendars.IGregorianCalendarProvider;
/*  7:   */ import java.awt.BorderLayout;
/*  8:   */ import java.util.Properties;
/*  9:   */ import org.openide.windows.TopComponent;
/* 10:   */ import org.openide.windows.TopComponent.Description;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ @TopComponent.Description(preferredID="CalendarTopComponent", persistenceType=2)
/* 33:   */ public final class CalendarTopComponent
/* 34:   */   extends TopComponent
/* 35:   */ {
/* 36:   */   private final WorkspaceItem<IGregorianCalendarProvider> calendar;
/* 37:   */   
/* 38:   */   public CalendarTopComponent()
/* 39:   */   {
/* 40:40 */     this(WorkspaceFactory.getInstance().getActiveWorkspace().searchDocument(CalendarDocumentManager.ID, "Default"));
/* 41:   */   }
/* 42:   */   
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */   public CalendarTopComponent(WorkspaceItem<IGregorianCalendarProvider> paramWorkspaceItem) {}
/* 52:   */   
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */   private void initComponents()
/* 61:   */   {
/* 62:62 */     setLayout(new BorderLayout());
/* 63:   */   }
/* 64:   */   
/* 65:   */ 
/* 66:   */ 
/* 67:   */   public void componentOpened()
/* 68:   */   {
/* 69:69 */     calendar.setView(this);
/* 70:   */   }
/* 71:   */   
/* 72:   */ 
/* 73:   */   public void componentClosed()
/* 74:   */   {
/* 75:75 */     calendar.setView(null);
/* 76:   */   }
/* 77:   */   
/* 78:   */ 
/* 79:   */ 
/* 80:   */   void writeProperties(Properties p)
/* 81:   */   {
/* 82:82 */     p.setProperty("version", "1.0");
/* 83:   */   }
/* 84:   */   
/* 85:   */   void readProperties(Properties p)
/* 86:   */   {
/* 87:87 */     String version = p.getProperty("version");
/* 88:   */   }
/* 89:   */ }
