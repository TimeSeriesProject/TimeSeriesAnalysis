/*  1:   */ package ec.nbdemetra.ui.calendars;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  4:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.IntStep;
/*  5:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  6:   */ import java.text.DecimalFormat;
/*  7:   */ import org.openide.nodes.Sheet;
/*  8:   */ import org.openide.util.Lookup;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class EasterRelatedEventNode
/* 14:   */   extends AbstractEventNode
/* 15:   */ {
/* 16:   */   public EasterRelatedEventNode(EasterRelatedEventBean bean)
/* 17:   */   {
/* 18:18 */     super(bean);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getHtmlDisplayName()
/* 22:   */   {
/* 23:23 */     EasterRelatedEventBean bean = (EasterRelatedEventBean)getLookup().lookup(EasterRelatedEventBean.class);
/* 24:24 */     StringBuilder sb = new StringBuilder();
/* 25:25 */     sb.append("<b>Easter</b> ");
/* 26:26 */     DecimalFormat df = new DecimalFormat("+#;-#");
/* 27:27 */     sb.append(df.format(bean.getOffset()));
/* 28:28 */     return sb.toString();
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected Sheet createSheet()
/* 32:   */   {
/* 33:33 */     EasterRelatedEventBean bean = (EasterRelatedEventBean)getLookup().lookup(EasterRelatedEventBean.class);
/* 34:34 */     Sheet result = super.createSheet();
/* 35:35 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Easter Related Day");
/* 36:36 */     ((NodePropertySetBuilder.IntStep)((NodePropertySetBuilder.IntStep)b.withInt().select(bean, "offset")).min(-366).max(366).display("Offset")).add();
/* 37:37 */     result.put(b.build());
/* 38:38 */     return result;
/* 39:   */   }
/* 40:   */ }
