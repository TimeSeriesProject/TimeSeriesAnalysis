package ec.nbdemetra.ui;

public abstract interface IReloadable
{
  public abstract void reload();
}
