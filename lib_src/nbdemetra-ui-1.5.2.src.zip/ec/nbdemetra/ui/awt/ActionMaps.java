/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Function;
/*  4:   */ import com.google.common.collect.Iterators;
/*  5:   */ import com.google.common.collect.Maps;
/*  6:   */ import java.util.AbstractSet;
/*  7:   */ import java.util.Iterator;
/*  8:   */ import java.util.Map;
/*  9:   */ import java.util.Set;
/* 10:   */ import javax.annotation.Nonnull;
/* 11:   */ import javax.swing.Action;
/* 12:   */ import javax.swing.ActionMap;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public final class ActionMaps
/* 22:   */ {
/* 23:   */   @Nonnull
/* 24:   */   public static ActionMap getRoot(@Nonnull ActionMap actionMap)
/* 25:   */   {
/* 26:26 */     ActionMap result = actionMap;
/* 27:27 */     while (result.getParent() != null) {
/* 28:28 */       result = result.getParent();
/* 29:   */     }
/* 30:30 */     return result;
/* 31:   */   }
/* 32:   */   
/* 33:   */   @Nonnull
/* 34:   */   public static Map<Object, Action> asMap(@Nonnull ActionMap actionMap, boolean includeParentKeys) {
/* 35:35 */     return Maps.asMap(asKeySet(actionMap, includeParentKeys), asKeyToValueFunction(actionMap));
/* 36:   */   }
/* 37:   */   
/* 38:   */   @Nonnull
/* 39:   */   private static Set<Object> asKeySet(@Nonnull final ActionMap actionMap, boolean includeParentKeys) {
/* 40:40 */     new AbstractSet()
/* 41:   */     {
/* 42:   */       public Iterator<Object> iterator() {
/* 43:43 */         Object[] keys = val$includeParentKeys ? actionMap.allKeys() : actionMap.keys();
/* 44:44 */         return keys != null ? Iterators.forArray(keys) : Iterators.emptyIterator();
/* 45:   */       }
/* 46:   */       
/* 47:   */       public int size()
/* 48:   */       {
/* 49:49 */         int result = actionMap.size();
/* 50:50 */         if (val$includeParentKeys) {
/* 51:51 */           ActionMap cursor = actionMap;
/* 52:52 */           while ((cursor = cursor.getParent()) != null) {
/* 53:53 */             result += cursor.size();
/* 54:   */           }
/* 55:   */         }
/* 56:56 */         return result;
/* 57:   */       }
/* 58:   */     };
/* 59:   */   }
/* 60:   */   
/* 61:   */   @Nonnull
/* 62:   */   private static Function<Object, Action> asKeyToValueFunction(@Nonnull ActionMap actionMap) {
/* 63:63 */     new Function()
/* 64:   */     {
/* 65:   */       public Action apply(Object input) {
/* 66:66 */         return get(input);
/* 67:   */       }
/* 68:   */     };
/* 69:   */   }
/* 70:   */ }
