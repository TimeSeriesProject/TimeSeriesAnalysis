/*   1:    */ package ec.nbdemetra.ui.awt;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Predicates;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import com.google.common.collect.ImmutableList;
/*   6:    */ import com.google.common.collect.ImmutableListMultimap;
/*   7:    */ import com.google.common.collect.ImmutableListMultimap.Builder;
/*   8:    */ import com.google.common.collect.Maps;
/*   9:    */ import com.google.common.collect.Ordering;
/*  10:    */ import com.google.common.primitives.Ints;
/*  11:    */ import java.awt.Toolkit;
/*  12:    */ import java.awt.event.KeyEvent;
/*  13:    */ import java.util.Collection;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Set;
/*  16:    */ import javax.swing.InputMap;
/*  17:    */ import javax.swing.JList;
/*  18:    */ import javax.swing.JTextField;
/*  19:    */ import javax.swing.KeyStroke;
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ public final class KeyStrokes
/*  32:    */ {
/*  33:    */   public static final ImmutableList<KeyStroke> COPY;
/*  34:    */   public static final ImmutableList<KeyStroke> PASTE;
/*  35:    */   public static final ImmutableList<KeyStroke> SELECT_ALL;
/*  36:    */   public static final ImmutableList<KeyStroke> DELETE;
/*  37:    */   public static final ImmutableList<KeyStroke> OPEN;
/*  38:    */   public static final ImmutableList<KeyStroke> CLEAR;
/*  39:    */   
/*  40:    */   public static void putAll(InputMap im, Collection<? extends KeyStroke> keyStrokes, Object actionMapKey)
/*  41:    */   {
/*  42: 42 */     for (KeyStroke o : keyStrokes) {
/*  43: 43 */       im.put(o, actionMapKey);
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   private static enum ActionType
/*  48:    */   {
/*  49: 49 */     COPY,  PASTE,  SELECT_ALL,  DELETE,  OPEN,  CLEAR;
/*  50:    */   }
/*  51:    */   
/*  52:    */   static {
/*  53: 53 */     ImmutableListMultimap<ActionType, KeyStroke> keyStrokes = new TextFieldKeyStrokeSupplier(null).get();
/*  54: 54 */     COPY = keyStrokes.get(ActionType.COPY);
/*  55: 55 */     PASTE = keyStrokes.get(ActionType.PASTE);
/*  56: 56 */     SELECT_ALL = keyStrokes.get(ActionType.SELECT_ALL);
/*  57: 57 */     DELETE = keyStrokes.get(ActionType.DELETE);
/*  58: 58 */     OPEN = keyStrokes.get(ActionType.OPEN);
/*  59: 59 */     CLEAR = keyStrokes.get(ActionType.CLEAR);
/*  60:    */   }
/*  61:    */   
/*  62:    */   private static abstract class AbstractSupplier implements Supplier<ImmutableListMultimap<KeyStrokes.ActionType, KeyStroke>>
/*  63:    */   {
/*  64:    */     protected abstract InputMap getInputMap();
/*  65:    */     
/*  66:    */     protected abstract Object getActionMapKey(KeyStrokes.ActionType paramActionType);
/*  67:    */     
/*  68:    */     protected KeyStroke getFallback(KeyStrokes.ActionType key) {
/*  69: 69 */       int platformKeyMask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
/*  70: 70 */       switch (key) {
/*  71:    */       case CLEAR: 
/*  72: 72 */         return KeyStroke.getKeyStroke(67, platformKeyMask);
/*  73:    */       case OPEN: 
/*  74: 74 */         return KeyStroke.getKeyStroke(127, platformKeyMask);
/*  75:    */       case COPY: 
/*  76: 76 */         return KeyStroke.getKeyStroke(86, platformKeyMask);
/*  77:    */       case DELETE: 
/*  78: 78 */         return KeyStroke.getKeyStroke(65, platformKeyMask);
/*  79:    */       case PASTE: 
/*  80: 80 */         return KeyStroke.getKeyStroke(10, 0);
/*  81:    */       case SELECT_ALL: 
/*  82: 82 */         return KeyStroke.getKeyStroke(76, platformKeyMask);
/*  83:    */       }
/*  84: 84 */       return null;
/*  85:    */     }
/*  86:    */     
/*  87:    */     public ImmutableListMultimap<KeyStrokes.ActionType, KeyStroke> get()
/*  88:    */     {
/*  89: 89 */       Map<KeyStroke, Object> keyStrokes = InputMaps.asMap(getInputMap(), true);
/*  90: 90 */       ImmutableListMultimap.Builder<KeyStrokes.ActionType, KeyStroke> result = ImmutableListMultimap.builder();
/*  91: 91 */       for (KeyStrokes.ActionType o : KeyStrokes.ActionType.values()) {
/*  92: 92 */         Set<KeyStroke> tmp = Maps.filterValues(keyStrokes, Predicates.equalTo(getActionMapKey(o))).keySet();
/*  93: 93 */         if (!tmp.isEmpty()) {
/*  94: 94 */           result.putAll(o, tmp);
/*  95:    */         } else {
/*  96: 96 */           result.put(o, getFallback(o));
/*  97:    */         }
/*  98:    */       }
/*  99: 99 */       return result.orderValuesBy(KeyStrokes.access$0()).build();
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:103 */   private static class ListKeyStrokeSupplier extends KeyStrokes.AbstractSupplier { private ListKeyStrokeSupplier() { super(); }
/* 104:    */     
/* 105:    */     protected InputMap getInputMap()
/* 106:    */     {
/* 107:107 */       return new JList().getInputMap();
/* 108:    */     }
/* 109:    */     
/* 110:    */     protected Object getActionMapKey(KeyStrokes.ActionType type)
/* 111:    */     {
/* 112:112 */       switch (type) {
/* 113:    */       case CLEAR: 
/* 114:114 */         return "copy";
/* 115:    */       case COPY: 
/* 116:116 */         return "paste";
/* 117:    */       case DELETE: 
/* 118:118 */         return "selectAll";
/* 119:    */       }
/* 120:120 */       return null;
/* 121:    */     }
/* 122:    */   }
/* 123:    */   
/* 124:124 */   private static class TextFieldKeyStrokeSupplier extends KeyStrokes.AbstractSupplier { private TextFieldKeyStrokeSupplier() { super(); }
/* 125:    */     
/* 126:    */     protected InputMap getInputMap()
/* 127:    */     {
/* 128:128 */       return new JTextField().getInputMap();
/* 129:    */     }
/* 130:    */     
/* 131:    */     protected Object getActionMapKey(KeyStrokes.ActionType type)
/* 132:    */     {
/* 133:133 */       switch (type) {
/* 134:    */       case CLEAR: 
/* 135:135 */         return "copy-to-clipboard";
/* 136:    */       case OPEN: 
/* 137:137 */         return "delete-next";
/* 138:    */       case COPY: 
/* 139:139 */         return "paste-from-clipboard";
/* 140:    */       case DELETE: 
/* 141:141 */         return "select-all";
/* 142:    */       }
/* 143:143 */       return null;
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static Ordering<KeyStroke> orderingUsingKeyTextLength() {
/* 148:148 */     new Ordering()
/* 149:    */     {
/* 150:    */       public int compare(KeyStroke left, KeyStroke right) {
/* 151:151 */         return Ints.compare(KeyEvent.getKeyText(left.getKeyCode()).length(), KeyEvent.getKeyText(right.getKeyCode()).length());
/* 152:    */       }
/* 153:    */     };
/* 154:    */   }
/* 155:    */ }
