/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Container;
/*  5:   */ import java.awt.Image;
/*  6:   */ import java.awt.image.BufferedImage;
/*  7:   */ import javax.swing.CellRendererPane;
/*  8:   */ import javax.swing.TransferHandler;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public final class TransferHandlers
/* 22:   */ {
/* 23:   */   @Deprecated
/* 24:   */   public static boolean isSetDragImageMethodSupported()
/* 25:   */   {
/* 26:26 */     return true;
/* 27:   */   }
/* 28:   */   
/* 29:   */   @Deprecated
/* 30:   */   public static void setDragImage(TransferHandler handler, Image image) {
/* 31:31 */     handler.setDragImage(image);
/* 32:   */   }
/* 33:   */   
/* 34:   */ 
/* 35:   */ 
/* 36:   */   public static BufferedImage paintComponent(Component c)
/* 37:   */   {
/* 38:38 */     c.setSize(c.getPreferredSize());
/* 39:39 */     layoutComponent(c);
/* 40:   */     
/* 41:41 */     BufferedImage img = new BufferedImage(c.getWidth(), c.getHeight(), 2);
/* 42:   */     
/* 43:43 */     CellRendererPane crp = new CellRendererPane();
/* 44:44 */     crp.add(c);
/* 45:45 */     crp.paintComponent(img.createGraphics(), c, crp, c.getBounds());
/* 46:46 */     return img;
/* 47:   */   }
/* 48:   */   
/* 49:   */   private static void layoutComponent(Component c) {
/* 50:50 */     synchronized (c.getTreeLock()) {
/* 51:51 */       c.doLayout();
/* 52:52 */       if ((c instanceof Container)) {
/* 53:53 */         for (Component child : ((Container)c).getComponents()) {
/* 54:54 */           layoutComponent(child);
/* 55:   */         }
/* 56:   */       }
/* 57:   */     }
/* 58:   */   }
/* 59:   */ }
