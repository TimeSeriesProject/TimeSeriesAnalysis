/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Supplier;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public abstract class JProperty<T>
/* 13:   */ {
/* 14:   */   private final String name;
/* 15:   */   private final Setter<T> setter;
/* 16:   */   private T value;
/* 17:   */   
/* 18:   */   public JProperty(String name, T initialValue)
/* 19:   */   {
/* 20:20 */     this(name, identity(), initialValue);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public JProperty(String name, Setter<T> setter, T initialValue) {
/* 24:24 */     this.name = name;
/* 25:25 */     this.setter = setter;
/* 26:26 */     value = initialValue;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getName() {
/* 30:30 */     return name;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public T get() {
/* 34:34 */     return value;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void set(T value) {
/* 38:38 */     T old = this.value;
/* 39:39 */     this.value = setter.apply(old, value);
/* 40:40 */     firePropertyChange(old, this.value);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public T getAndSet(T value) {
/* 44:44 */     T result = get();
/* 45:45 */     set(value);
/* 46:46 */     return result;
/* 47:   */   }
/* 48:   */   
/* 49:   */ 
/* 50:   */ 
/* 51:   */   protected abstract void firePropertyChange(T paramT1, T paramT2);
/* 52:   */   
/* 53:   */ 
/* 54:   */ 
/* 55:   */   public static <T> Setter<T> nullTo(T defaultValue)
/* 56:   */   {
/* 57:57 */     new Setter()
/* 58:   */     {
/* 59:   */       public T apply(T oldValue, T newValue) {
/* 60:60 */         return newValue != null ? newValue : JProperty.this;
/* 61:   */       }
/* 62:   */     };
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static <T> Setter<T> nullTo(Supplier<T> defaultValue) {
/* 66:66 */     new Setter()
/* 67:   */     {
/* 68:   */       public T apply(T oldValue, T newValue) {
/* 69:69 */         return newValue != null ? newValue : get();
/* 70:   */       }
/* 71:   */     };
/* 72:   */   }
/* 73:   */   
/* 74:   */   public static <T extends Comparable<T>> Setter<T> min(T min) {
/* 75:75 */     new Setter()
/* 76:   */     {
/* 77:   */       public T apply(T oldValue, T newValue) {
/* 78:78 */         return (newValue != null) && (compareTo(newValue) <= 0) ? newValue : JProperty.this;
/* 79:   */       }
/* 80:   */     };
/* 81:   */   }
/* 82:   */   
/* 83:   */   public static <T> Setter<T> identity() {
/* 84:84 */     new Setter()
/* 85:   */     {
/* 86:   */       public T apply(T oldValue, T newValue) {
/* 87:87 */         return newValue;
/* 88:   */       }
/* 89:   */     };
/* 90:   */   }
/* 91:   */   
/* 92:   */   public static abstract interface Setter<X>
/* 93:   */   {
/* 94:   */     public abstract X apply(X paramX1, X paramX2);
/* 95:   */   }
/* 96:   */ }
