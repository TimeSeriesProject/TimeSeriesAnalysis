/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.utilities.Arrays2;
/*  4:   */ import javax.swing.JPanel;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ public class JPanel2
/* 12:   */   extends JPanel
/* 13:   */   implements IPropertyChangeSource
/* 14:   */ {
/* 15:   */   protected <T> JProperty<T> newProperty(String name, T initialValue)
/* 16:   */   {
/* 17:17 */     return newProperty(name, JProperty.identity(), initialValue);
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected <T> JProperty<T> newProperty(String name, JProperty.Setter<T> setter, T initialValue) {
/* 21:21 */     new JProperty(name, setter, setter.apply(null, initialValue))
/* 22:   */     {
/* 23:   */       protected void firePropertyChange(T oldValue, T newValue) {
/* 24:24 */         firePropertyChange(getName(), oldValue, newValue);
/* 25:   */       }
/* 26:   */     };
/* 27:   */   }
/* 28:   */   
/* 29:   */   protected void firePropertyChange(String propertyName, Object oldValue, Object newValue)
/* 30:   */   {
/* 31:31 */     if (!Arrays2.arrayEquals(oldValue, newValue)) {
/* 32:32 */       super.firePropertyChange(propertyName, oldValue, newValue);
/* 33:   */     }
/* 34:   */   }
/* 35:   */ }
