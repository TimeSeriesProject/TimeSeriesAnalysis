/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeEvent;
/*  4:   */ import java.beans.PropertyChangeListener;
/*  5:   */ import javax.swing.Action;
/*  6:   */ import org.openide.windows.IOProvider;
/*  7:   */ import org.openide.windows.InputOutput;
/*  8:   */ import org.openide.windows.OutputWriter;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class OuputPropertyChangeListener
/* 18:   */   implements PropertyChangeListener
/* 19:   */ {
/* 20:20 */   static final InputOutput IO = IOProvider.getDefault().getIO("PropertyChangeListener", new Action[0]);
/* 21:   */   
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */   public void propertyChange(PropertyChangeEvent evt)
/* 27:   */   {
/* 28:28 */     OutputWriter out = IO.getOut();
/* 29:29 */     out.println(evt.getSource().getClass().getName() + " -> " + evt.getPropertyName());
/* 30:   */   }
/* 31:   */ }
