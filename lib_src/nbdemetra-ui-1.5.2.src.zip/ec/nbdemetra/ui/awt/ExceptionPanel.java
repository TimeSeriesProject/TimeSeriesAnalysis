/*   1:    */ package ec.nbdemetra.ui.awt;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.tstoolkit.utilities.StackTracePrinter;
/*   5:    */ import java.awt.BorderLayout;
/*   6:    */ import java.beans.PropertyChangeEvent;
/*   7:    */ import java.beans.PropertyChangeListener;
/*   8:    */ import javax.swing.JComponent;
/*   9:    */ import javax.swing.JEditorPane;
/*  10:    */ import javax.swing.text.html.HTMLEditorKit;
/*  11:    */ import javax.swing.text.html.StyleSheet;
/*  12:    */ import org.openide.DialogDescriptor;
/*  13:    */ import org.openide.NotifyDescriptor;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public class ExceptionPanel
/*  33:    */   extends JComponent
/*  34:    */   implements IDialogDescriptorProvider
/*  35:    */ {
/*  36:    */   public static final String EXCEPTION_PROPERTY = "exception";
/*  37:    */   protected Exception exception;
/*  38:    */   private final JEditorPane editorPane;
/*  39:    */   
/*  40:    */   public static ExceptionPanel create(Exception ex)
/*  41:    */   {
/*  42: 42 */     ExceptionPanel result = new ExceptionPanel();
/*  43: 43 */     result.setException(ex);
/*  44: 44 */     return result;
/*  45:    */   }
/*  46:    */   
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */   public ExceptionPanel()
/*  53:    */   {
/*  54: 54 */     editorPane = new JEditorPane();
/*  55: 55 */     HTMLEditorKit editor = new HTMLEditorKit();
/*  56: 56 */     editor.setStyleSheet(createStyleSheet());
/*  57: 57 */     editorPane.setEditorKit(editor);
/*  58: 58 */     editorPane.setCaretPosition(0);
/*  59: 59 */     editorPane.setEditable(false);
/*  60:    */     
/*  61: 61 */     setLayout(new BorderLayout());
/*  62: 62 */     add(NbComponents.newJScrollPane(editorPane), "Center");
/*  63:    */     
/*  64: 64 */     addPropertyChangeListener(new PropertyChangeListener()
/*  65:    */     {
/*  66:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  67: 67 */         String p = evt.getPropertyName();
/*  68: 68 */         if (p.equals("exception")) {
/*  69: 69 */           onExceptionChange();
/*  70:    */         }
/*  71:    */       }
/*  72:    */     });
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void onExceptionChange()
/*  76:    */   {
/*  77: 77 */     if (exception != null) {
/*  78: 78 */       editorPane.setText(StackTracePrinter.htmlBuilder().toString(exception));
/*  79:    */     } else {
/*  80: 80 */       editorPane.setText("");
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */   public void setException(Exception exception)
/*  86:    */   {
/*  87: 87 */     Exception old = this.exception;
/*  88: 88 */     this.exception = exception;
/*  89: 89 */     firePropertyChange("exception", old, this.exception);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public Exception getException() {
/*  93: 93 */     return exception;
/*  94:    */   }
/*  95:    */   
/*  96:    */   private static StyleSheet createStyleSheet()
/*  97:    */   {
/*  98: 98 */     StyleSheet ss = new StyleSheet();
/*  99: 99 */     ss.addRule("body { font-family: Courier; font-size : 10px monaco;}");
/* 100:100 */     ss.addRule(createColorRule("name", 2116231));
/* 101:101 */     ss.addRule(createColorRule("message", 12680465));
/* 102:102 */     ss.addRule(createColorRule("keyword", 3028022));
/* 103:103 */     ss.addRule(createColorRule("elementName", 5592915));
/* 104:104 */     ss.addRule(createColorRule("elementSource", 12886016));
/* 105:105 */     return ss;
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static String createColorRule(String className, int color) {
/* 109:109 */     return "." + className + " {color: " + toHex(color) + ";}";
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static String toHex(int rgb) {
/* 113:113 */     return Integer.toHexString(rgb & 0xFFFFFF | 0x1000000).substring(1);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public DialogDescriptor createDialogDescriptor(String title)
/* 117:    */   {
/* 118:118 */     return new DialogDescriptor(this, title, true, -1, NotifyDescriptor.OK_OPTION, 0, null, null);
/* 119:    */   }
/* 120:    */ }
