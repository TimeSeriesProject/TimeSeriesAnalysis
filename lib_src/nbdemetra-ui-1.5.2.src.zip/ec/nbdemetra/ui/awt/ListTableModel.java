/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import javax.swing.table.AbstractTableModel;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public abstract class ListTableModel<T>
/* 14:   */   extends AbstractTableModel
/* 15:   */ {
/* 16:   */   protected abstract List<String> getColumnNames();
/* 17:   */   
/* 18:   */   protected abstract List<T> getValues();
/* 19:   */   
/* 20:   */   protected abstract Object getValueAt(T paramT, int paramInt);
/* 21:   */   
/* 22:   */   public int getColumnCount()
/* 23:   */   {
/* 24:24 */     return getColumnNames().size();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getColumnName(int column)
/* 28:   */   {
/* 29:29 */     return (String)getColumnNames().get(column);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public int getRowCount()
/* 33:   */   {
/* 34:34 */     return getValues().size();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Object getValueAt(int rowIndex, int columnIndex)
/* 38:   */   {
/* 39:39 */     return getValueAt(getValues().get(rowIndex), columnIndex);
/* 40:   */   }
/* 41:   */ }
