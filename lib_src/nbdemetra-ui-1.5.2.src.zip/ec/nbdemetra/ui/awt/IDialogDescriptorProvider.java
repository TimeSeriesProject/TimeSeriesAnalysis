package ec.nbdemetra.ui.awt;

import org.openide.DialogDescriptor;

public abstract interface IDialogDescriptorProvider
{
  public abstract DialogDescriptor createDialogDescriptor(String paramString);
}
