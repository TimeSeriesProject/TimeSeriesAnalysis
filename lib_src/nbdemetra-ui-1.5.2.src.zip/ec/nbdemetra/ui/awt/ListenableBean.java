/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.utilities.Arrays2;
/*  4:   */ import java.beans.PropertyChangeListener;
/*  5:   */ import java.beans.PropertyChangeSupport;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public abstract class ListenableBean
/* 15:   */   implements IPropertyChangeSource
/* 16:   */ {
/* 17:17 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/* 18:   */   
/* 19:   */   public void addPropertyChangeListener(PropertyChangeListener listener)
/* 20:   */   {
/* 21:21 */     support.addPropertyChangeListener(listener);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener)
/* 25:   */   {
/* 26:26 */     support.addPropertyChangeListener(propertyName, listener);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void removePropertyChangeListener(PropertyChangeListener listener)
/* 30:   */   {
/* 31:31 */     support.removePropertyChangeListener(listener);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener)
/* 35:   */   {
/* 36:36 */     support.removePropertyChangeListener(propertyName, listener);
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected <T> JProperty<T> newProperty(String name, T initialValue) {
/* 40:40 */     return newProperty(name, JProperty.identity(), initialValue);
/* 41:   */   }
/* 42:   */   
/* 43:   */   protected <T> JProperty<T> newProperty(String name, JProperty.Setter<T> setter, T initialValue) {
/* 44:44 */     new JProperty(name, setter, setter.apply(null, initialValue))
/* 45:   */     {
/* 46:   */       protected void firePropertyChange(T oldValue, T newValue) {
/* 47:47 */         firePropertyChange(getName(), oldValue, newValue);
/* 48:   */       }
/* 49:   */     };
/* 50:   */   }
/* 51:   */   
/* 52:   */   protected <T> void firePropertyChange(String propertyName, T oldValue, T newValue) {
/* 53:53 */     if (!Arrays2.arrayEquals(oldValue, newValue)) {
/* 54:54 */       support.firePropertyChange(propertyName, oldValue, newValue);
/* 55:   */     }
/* 56:   */   }
/* 57:   */ }
