/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import java.awt.event.MouseAdapter;
/*  4:   */ import java.awt.event.MouseEvent;
/*  5:   */ import javax.swing.JPopupMenu;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public abstract class PopupListener
/* 16:   */   extends MouseAdapter
/* 17:   */ {
/* 18:   */   public void mousePressed(MouseEvent e)
/* 19:   */   {
/* 20:20 */     maybeShowPopup(e);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void mouseReleased(MouseEvent e)
/* 24:   */   {
/* 25:25 */     maybeShowPopup(e);
/* 26:   */   }
/* 27:   */   
/* 28:   */   protected void maybeShowPopup(MouseEvent e) {
/* 29:29 */     if (e.isPopupTrigger()) {
/* 30:30 */       JPopupMenu popup = getPopup(e);
/* 31:31 */       if (popup != null) {
/* 32:32 */         popup.show(e.getComponent(), e.getX(), e.getY());
/* 33:   */       }
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */ 
/* 38:   */ 
/* 39:   */   protected abstract JPopupMenu getPopup(MouseEvent paramMouseEvent);
/* 40:   */   
/* 41:   */ 
/* 42:   */   public static class PopupAdapter
/* 43:   */     extends PopupListener
/* 44:   */   {
/* 45:   */     final JPopupMenu menu;
/* 46:   */     
/* 47:   */ 
/* 48:   */     public PopupAdapter(JPopupMenu menu)
/* 49:   */     {
/* 50:50 */       this.menu = menu;
/* 51:   */     }
/* 52:   */     
/* 53:   */     protected JPopupMenu getPopup(MouseEvent e)
/* 54:   */     {
/* 55:55 */       return menu;
/* 56:   */     }
/* 57:   */   }
/* 58:   */ }
