package ec.nbdemetra.ui.awt;

public enum ListenerState
{
  READY,  SENDING,  SUSPENDED;
}
