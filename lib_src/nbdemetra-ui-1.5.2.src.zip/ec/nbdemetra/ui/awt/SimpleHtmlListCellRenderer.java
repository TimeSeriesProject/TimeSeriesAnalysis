/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import javax.swing.JList;
/*  5:   */ import javax.swing.ListCellRenderer;
/*  6:   */ import org.openide.awt.HtmlRenderer;
/*  7:   */ import org.openide.awt.HtmlRenderer.Renderer;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class SimpleHtmlListCellRenderer<T>
/* 15:   */   implements ListCellRenderer
/* 16:   */ {
/* 17:   */   protected final HtmlProvider<T> htmlProvider;
/* 18:   */   protected final HtmlRenderer.Renderer htmlRenderer;
/* 19:   */   
/* 20:   */   public SimpleHtmlListCellRenderer(HtmlProvider<T> htmlProvider)
/* 21:   */   {
/* 22:22 */     this.htmlProvider = htmlProvider;
/* 23:23 */     htmlRenderer = HtmlRenderer.createRenderer();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 27:   */   {
/* 28:28 */     htmlRenderer.setHtml(true);
/* 29:29 */     return htmlRenderer.getListCellRendererComponent(list, htmlProvider.getHtmlDisplayName(value), index, isSelected, cellHasFocus);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static abstract interface HtmlProvider<T>
/* 33:   */   {
/* 34:   */     public abstract String getHtmlDisplayName(T paramT);
/* 35:   */   }
/* 36:   */ }
