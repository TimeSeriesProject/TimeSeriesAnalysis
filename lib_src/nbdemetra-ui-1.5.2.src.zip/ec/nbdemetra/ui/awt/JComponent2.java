/*  1:   */ package ec.nbdemetra.ui.awt;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.utilities.Arrays2;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public class JComponent2
/* 13:   */   extends JComponent
/* 14:   */   implements IPropertyChangeSource
/* 15:   */ {
/* 16:   */   protected <T> JProperty<T> newProperty(String name, T initialValue)
/* 17:   */   {
/* 18:18 */     return newProperty(name, JProperty.identity(), initialValue);
/* 19:   */   }
/* 20:   */   
/* 21:   */   protected <T> JProperty<T> newProperty(String name, JProperty.Setter<T> setter, T initialValue) {
/* 22:22 */     new JProperty(name, setter, setter.apply(null, initialValue))
/* 23:   */     {
/* 24:   */       protected void firePropertyChange(T oldValue, T newValue) {
/* 25:25 */         firePropertyChange(getName(), oldValue, newValue);
/* 26:   */       }
/* 27:   */     };
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected void firePropertyChange(String propertyName, Object oldValue, Object newValue)
/* 31:   */   {
/* 32:32 */     if (!Arrays2.arrayEquals(oldValue, newValue)) {
/* 33:33 */       super.firePropertyChange(propertyName, oldValue, newValue);
/* 34:   */     }
/* 35:   */   }
/* 36:   */ }
