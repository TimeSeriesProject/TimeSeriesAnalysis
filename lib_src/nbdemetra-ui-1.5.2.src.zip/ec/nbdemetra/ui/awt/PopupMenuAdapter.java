package ec.nbdemetra.ui.awt;

import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

public class PopupMenuAdapter
  implements PopupMenuListener
{
  public void popupMenuWillBecomeVisible(PopupMenuEvent e) {}
  
  public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {}
  
  public void popupMenuCanceled(PopupMenuEvent e) {}
}
