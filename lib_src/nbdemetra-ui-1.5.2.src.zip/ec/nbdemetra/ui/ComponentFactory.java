/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import ec.ui.AHtmlView;
/*  4:   */ import ec.ui.ATsChart;
/*  5:   */ import ec.ui.ATsGrid;
/*  6:   */ import ec.ui.ATsGrowthChart;
/*  7:   */ import ec.ui.ATsList;
/*  8:   */ import ec.ui.chart.JTsChart;
/*  9:   */ import ec.ui.chart.JTsGrowthChart;
/* 10:   */ import ec.ui.grid.JTsGrid;
/* 11:   */ import ec.ui.html.JHtmlView;
/* 12:   */ import ec.ui.list.JTsList;
/* 13:   */ import javax.annotation.Nonnull;
/* 14:   */ import org.openide.util.Lookup;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ public class ComponentFactory
/* 40:   */ {
/* 41:   */   @Nonnull
/* 42:   */   public static ComponentFactory getDefault()
/* 43:   */   {
/* 44:44 */     return (ComponentFactory)Lookup.getDefault().lookup(ComponentFactory.class);
/* 45:   */   }
/* 46:   */   
/* 47:   */   @Nonnull
/* 48:   */   public ATsChart newTsChart() {
/* 49:49 */     return new JTsChart();
/* 50:   */   }
/* 51:   */   
/* 52:   */   @Nonnull
/* 53:   */   public ATsGrid newTsGrid() {
/* 54:54 */     return new JTsGrid();
/* 55:   */   }
/* 56:   */   
/* 57:   */   @Nonnull
/* 58:   */   public ATsGrowthChart newTsGrowthChart() {
/* 59:59 */     return new JTsGrowthChart();
/* 60:   */   }
/* 61:   */   
/* 62:   */   @Nonnull
/* 63:   */   public ATsList newTsList() {
/* 64:64 */     return new JTsList();
/* 65:   */   }
/* 66:   */   
/* 67:   */   @Nonnull
/* 68:   */   public AHtmlView newHtmlView() {
/* 69:69 */     return new JHtmlView();
/* 70:   */   }
/* 71:   */ }
