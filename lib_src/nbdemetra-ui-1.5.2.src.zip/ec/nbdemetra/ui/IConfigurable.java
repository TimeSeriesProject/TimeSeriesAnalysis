package ec.nbdemetra.ui;

public abstract interface IConfigurable
{
  public abstract Config getConfig();
  
  public abstract void setConfig(Config paramConfig)
    throws IllegalArgumentException;
  
  public abstract Config editConfig(Config paramConfig)
    throws IllegalArgumentException;
}
