/*   1:    */ package ec.nbdemetra.ui.interchange;
/*   2:    */ 
/*   3:    */ import java.beans.PropertyChangeListener;
/*   4:    */ import java.beans.PropertyChangeSupport;
/*   5:    */ import javax.swing.JComponent;
/*   6:    */ import javax.swing.SwingUtilities;
/*   7:    */ import org.netbeans.spi.options.OptionsPanelController;
/*   8:    */ import org.openide.util.HelpCtx;
/*   9:    */ import org.openide.util.Lookup;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ public final class InterchangeOptionsPanelController
/*  34:    */   extends OptionsPanelController
/*  35:    */ {
/*  36:    */   private InterchangePanel panel;
/*  37: 37 */   private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
/*  38:    */   private boolean changed;
/*  39:    */   
/*  40:    */   public void update()
/*  41:    */   {
/*  42: 42 */     getPanel().load();
/*  43: 43 */     changed = false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void applyChanges()
/*  47:    */   {
/*  48: 48 */     SwingUtilities.invokeLater(new Runnable()
/*  49:    */     {
/*  50:    */       public void run() {
/*  51: 51 */         InterchangeOptionsPanelController.this.getPanel().store();
/*  52: 52 */         changed = false;
/*  53:    */       }
/*  54:    */     });
/*  55:    */   }
/*  56:    */   
/*  57:    */ 
/*  58:    */ 
/*  59:    */   public void cancel() {}
/*  60:    */   
/*  61:    */ 
/*  62:    */   public boolean isValid()
/*  63:    */   {
/*  64: 64 */     return getPanel().valid();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isChanged()
/*  68:    */   {
/*  69: 69 */     return changed;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public HelpCtx getHelpCtx()
/*  73:    */   {
/*  74: 74 */     return null;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public JComponent getComponent(Lookup masterLookup)
/*  78:    */   {
/*  79: 79 */     return getPanel();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void addPropertyChangeListener(PropertyChangeListener l)
/*  83:    */   {
/*  84: 84 */     pcs.addPropertyChangeListener(l);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void removePropertyChangeListener(PropertyChangeListener l)
/*  88:    */   {
/*  89: 89 */     pcs.removePropertyChangeListener(l);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private InterchangePanel getPanel() {
/*  93: 93 */     if (panel == null) {
/*  94: 94 */       panel = new InterchangePanel(this);
/*  95:    */     }
/*  96: 96 */     return panel;
/*  97:    */   }
/*  98:    */   
/*  99:    */   void changed() {
/* 100:100 */     if (!changed) {
/* 101:101 */       changed = true;
/* 102:102 */       pcs.firePropertyChange("changed", false, true);
/* 103:    */     }
/* 104:104 */     pcs.firePropertyChange("valid", null, null);
/* 105:    */   }
/* 106:    */ }
