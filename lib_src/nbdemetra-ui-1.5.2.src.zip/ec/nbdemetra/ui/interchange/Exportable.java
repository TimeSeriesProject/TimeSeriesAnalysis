package ec.nbdemetra.ui.interchange;

import ec.nbdemetra.ui.Config;
import ec.util.various.swing.OnEDT;
import javax.annotation.Nonnull;

public abstract interface Exportable
{
  @OnEDT
  @Nonnull
  public abstract Config exportConfig();
}
