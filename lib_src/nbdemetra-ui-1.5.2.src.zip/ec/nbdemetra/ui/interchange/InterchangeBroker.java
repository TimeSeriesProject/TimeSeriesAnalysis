/*  1:   */ package ec.nbdemetra.ui.interchange;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.DemetraUiIcon;
/*  4:   */ import ec.nbdemetra.ui.ns.INamedService;
/*  5:   */ import ec.util.various.swing.OnEDT;
/*  6:   */ import java.awt.Image;
/*  7:   */ import java.io.IOException;
/*  8:   */ import java.util.List;
/*  9:   */ import javax.annotation.Nonnull;
/* 10:   */ import org.openide.nodes.Sheet;
/* 11:   */ import org.openide.util.ImageUtilities;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public abstract class InterchangeBroker
/* 36:   */   implements INamedService
/* 37:   */ {
/* 38:   */   public String getDisplayName()
/* 39:   */   {
/* 40:40 */     return getName();
/* 41:   */   }
/* 42:   */   
/* 43:   */   public Image getIcon(int type, boolean opened)
/* 44:   */   {
/* 45:45 */     return ImageUtilities.icon2Image(DemetraUiIcon.CLIPBOARD_PASTE_DOCUMENT_TEXT_16);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public Sheet createSheet()
/* 49:   */   {
/* 50:50 */     Sheet result = new Sheet();
/* 51:51 */     return result;
/* 52:   */   }
/* 53:   */   
/* 54:   */   @OnEDT
/* 55:   */   public boolean canImport(@Nonnull List<? extends Importable> importables) {
/* 56:56 */     return false;
/* 57:   */   }
/* 58:   */   
/* 59:   */   @OnEDT
/* 60:   */   public void performImport(@Nonnull List<? extends Importable> importables) throws IOException, IllegalArgumentException {
/* 61:61 */     throw new UnsupportedOperationException();
/* 62:   */   }
/* 63:   */   
/* 64:   */   @OnEDT
/* 65:   */   public boolean canExport(@Nonnull List<? extends Exportable> exportables) {
/* 66:66 */     return false;
/* 67:   */   }
/* 68:   */   
/* 69:   */   @OnEDT
/* 70:   */   public void performExport(@Nonnull List<? extends Exportable> exportables) throws IOException {
/* 71:71 */     throw new UnsupportedOperationException();
/* 72:   */   }
/* 73:   */ }
