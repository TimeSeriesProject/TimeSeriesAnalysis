package ec.nbdemetra.ui.interchange;

import ec.nbdemetra.ui.Config;
import ec.util.various.swing.OnEDT;
import javax.annotation.Nonnull;

public abstract interface Importable
{
  @OnEDT
  @Nonnull
  public abstract String getDomain();
  
  @OnEDT
  public abstract void importConfig(@Nonnull Config paramConfig)
    throws IllegalArgumentException;
}
