/*   1:    */ package ec.nbdemetra.ui.interchange;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Predicates;
/*   4:    */ import com.google.common.collect.FluentIterable;
/*   5:    */ import ec.nbdemetra.ui.Jdk6Functions;
/*   6:    */ import ec.nbdemetra.ui.actions.AbilityAction;
/*   7:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.annotation.Nonnull;
/*  12:    */ import javax.swing.AbstractAction;
/*  13:    */ import javax.swing.JMenuItem;
/*  14:    */ import org.openide.nodes.Node;
/*  15:    */ import org.openide.util.Exceptions;
/*  16:    */ import org.openide.util.actions.Presenter.Popup;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ public final class ImportAction
/*  51:    */   extends AbilityAction<Importable>
/*  52:    */   implements Presenter.Popup
/*  53:    */ {
/*  54:    */   public ImportAction()
/*  55:    */   {
/*  56: 56 */     super(Importable.class);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public JMenuItem getPopupPresenter()
/*  60:    */   {
/*  61: 61 */     return getPopupPresenter(getImportables(getActivatedNodes()));
/*  62:    */   }
/*  63:    */   
/*  64:    */ 
/*  65:    */   protected void performAction(Iterable<Importable> items) {}
/*  66:    */   
/*  67:    */ 
/*  68:    */   public String getName()
/*  69:    */   {
/*  70: 70 */     return null;
/*  71:    */   }
/*  72:    */   
/*  73:    */   private static List<Importable> getImportables(Node[] activatedNodes) {
/*  74: 74 */     return 
/*  75:    */     
/*  76:    */ 
/*  77: 77 */       Nodes.asIterable(activatedNodes).transform(Jdk6Functions.lookupNode(Importable.class)).filter(Predicates.notNull()).toList();
/*  78:    */   }
/*  79:    */   
/*  80:    */   @Nonnull
/*  81:    */   public static JMenuItem getPopupPresenter(@Nonnull List<? extends Importable> paramList)
/*  82:    */   {
/*  83: 83 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  84:    */   }
/*  85:    */   
/*  86:    */ 
/*  87:    */ 
/*  88:    */   private static final class Import
/*  89:    */     extends AbstractAction
/*  90:    */   {
/*  91:    */     private final InterchangeBroker o;
/*  92:    */     
/*  93:    */     private final List<? extends Importable> importables;
/*  94:    */     
/*  95:    */ 
/*  96:    */     public Import(InterchangeBroker o, List<? extends Importable> importables)
/*  97:    */     {
/*  98: 98 */       super();
/*  99: 99 */       this.o = o;
/* 100:100 */       this.importables = importables;
/* 101:    */     }
/* 102:    */     
/* 103:    */     public void actionPerformed(ActionEvent e)
/* 104:    */     {
/* 105:    */       try {
/* 106:106 */         o.performImport(importables);
/* 107:    */       } catch (IOException|IllegalArgumentException ex) {
/* 108:108 */         Exceptions.printStackTrace(ex);
/* 109:    */       }
/* 110:    */     }
/* 111:    */   }
/* 112:    */ }
