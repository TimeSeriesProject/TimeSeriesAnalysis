/*   1:    */ package ec.nbdemetra.ui.interchange;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Predicates;
/*   4:    */ import com.google.common.collect.FluentIterable;
/*   5:    */ import ec.nbdemetra.ui.Jdk6Functions;
/*   6:    */ import ec.nbdemetra.ui.actions.AbilityAction;
/*   7:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.annotation.Nonnull;
/*  12:    */ import javax.swing.AbstractAction;
/*  13:    */ import javax.swing.JMenuItem;
/*  14:    */ import org.openide.nodes.Node;
/*  15:    */ import org.openide.util.Exceptions;
/*  16:    */ import org.openide.util.actions.Presenter.Popup;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ public final class ExportAction
/*  49:    */   extends AbilityAction<Exportable>
/*  50:    */   implements Presenter.Popup
/*  51:    */ {
/*  52:    */   public ExportAction()
/*  53:    */   {
/*  54: 54 */     super(Exportable.class);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public JMenuItem getPopupPresenter()
/*  58:    */   {
/*  59: 59 */     return getPopupPresenter(getExportables(getActivatedNodes()));
/*  60:    */   }
/*  61:    */   
/*  62:    */ 
/*  63:    */   protected void performAction(Iterable<Exportable> items) {}
/*  64:    */   
/*  65:    */ 
/*  66:    */   public String getName()
/*  67:    */   {
/*  68: 68 */     return null;
/*  69:    */   }
/*  70:    */   
/*  71:    */   private static List<Exportable> getExportables(Node[] activatedNodes) {
/*  72: 72 */     return 
/*  73:    */     
/*  74:    */ 
/*  75: 75 */       Nodes.asIterable(activatedNodes).transform(Jdk6Functions.lookupNode(Exportable.class)).filter(Predicates.notNull()).toList();
/*  76:    */   }
/*  77:    */   
/*  78:    */   @Nonnull
/*  79:    */   public static JMenuItem getPopupPresenter(@Nonnull List<? extends Exportable> paramList)
/*  80:    */   {
/*  81: 81 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */   private static final class Export
/*  87:    */     extends AbstractAction
/*  88:    */   {
/*  89:    */     private final InterchangeBroker o;
/*  90:    */     
/*  91:    */     private final List<? extends Exportable> exportables;
/*  92:    */     
/*  93:    */ 
/*  94:    */     public Export(InterchangeBroker o, List<? extends Exportable> exportables)
/*  95:    */     {
/*  96: 96 */       super();
/*  97: 97 */       this.o = o;
/*  98: 98 */       this.exportables = exportables;
/*  99:    */     }
/* 100:    */     
/* 101:    */     public void actionPerformed(ActionEvent e)
/* 102:    */     {
/* 103:    */       try {
/* 104:104 */         o.performExport(exportables);
/* 105:    */       } catch (IOException ex) {
/* 106:106 */         Exceptions.printStackTrace(ex);
/* 107:    */       }
/* 108:    */     }
/* 109:    */   }
/* 110:    */ }
