/*   1:    */ package ec.nbdemetra.ui.interchange;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Iterables;
/*   4:    */ import ec.nbdemetra.ui.IConfigurable;
/*   5:    */ import ec.nbdemetra.ui.Jdk6Functions;
/*   6:    */ import ec.nbdemetra.ui.nodes.AbstractNodeBuilder;
/*   7:    */ import ec.nbdemetra.ui.ns.NamedServiceNode;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyVetoException;
/*  11:    */ import java.beans.VetoableChangeListener;
/*  12:    */ import javax.swing.GroupLayout;
/*  13:    */ import javax.swing.GroupLayout.Alignment;
/*  14:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  15:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  16:    */ import javax.swing.ImageIcon;
/*  17:    */ import javax.swing.JButton;
/*  18:    */ import javax.swing.JToolBar;
/*  19:    */ import javax.swing.LayoutStyle.ComponentPlacement;
/*  20:    */ import org.openide.explorer.ExplorerManager;
/*  21:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  22:    */ import org.openide.explorer.view.OutlineView;
/*  23:    */ import org.openide.nodes.Node;
/*  24:    */ import org.openide.util.Lookup;
/*  25:    */ import org.openide.util.NbBundle;
/*  26:    */ 
/*  27:    */ final class InterchangePanel extends javax.swing.JPanel implements ExplorerManager.Provider
/*  28:    */ {
/*  29:    */   private final InterchangeOptionsPanelController controller;
/*  30:    */   private final ExplorerManager em;
/*  31:    */   private JButton editButton;
/*  32:    */   private JToolBar jToolBar1;
/*  33:    */   private OutlineView outlineView2;
/*  34:    */   
/*  35:    */   InterchangePanel(InterchangeOptionsPanelController controller)
/*  36:    */   {
/*  37: 37 */     this.controller = controller;
/*  38: 38 */     em = new ExplorerManager();
/*  39: 39 */     initComponents();
/*  40: 40 */     editButton.setEnabled(false);
/*  41: 41 */     em.addVetoableChangeListener(new VetoableChangeListener()
/*  42:    */     {
/*  43:    */       public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
/*  44: 44 */         if ("selectedNodes".equals(evt.getPropertyName())) {
/*  45: 45 */           Node[] nodes = (Node[])evt.getNewValue();
/*  46: 46 */           editButton.setEnabled((nodes.length == 1) && (nodes[0].getLookup().lookup(IConfigurable.class) != null));
/*  47:    */         }
/*  48:    */       }
/*  49: 49 */     });
/*  50: 50 */     outlineView2.getOutline().setRootVisible(false);
/*  51:    */   }
/*  52:    */   
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */   private void initComponents()
/*  60:    */   {
/*  61: 61 */     jToolBar1 = new JToolBar();
/*  62: 62 */     editButton = new JButton();
/*  63: 63 */     outlineView2 = new OutlineView("Interchange broker");
/*  64:    */     
/*  65: 65 */     jToolBar1.setFloatable(false);
/*  66: 66 */     jToolBar1.setOrientation(1);
/*  67: 67 */     jToolBar1.setRollover(true);
/*  68:    */     
/*  69: 69 */     editButton.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/preferences-system_16x16.png")));
/*  70: 70 */     org.openide.awt.Mnemonics.setLocalizedText(editButton, NbBundle.getMessage(InterchangePanel.class, "InterchangePanel.editButton.text"));
/*  71: 71 */     editButton.setToolTipText(NbBundle.getMessage(InterchangePanel.class, "InterchangePanel.editButton.toolTipText"));
/*  72: 72 */     editButton.addActionListener(new java.awt.event.ActionListener() {
/*  73:    */       public void actionPerformed(ActionEvent evt) {
/*  74: 74 */         InterchangePanel.this.editButtonActionPerformed(evt);
/*  75:    */       }
/*  76: 76 */     });
/*  77: 77 */     jToolBar1.add(editButton);
/*  78:    */     
/*  79: 79 */     GroupLayout layout = new GroupLayout(this);
/*  80: 80 */     setLayout(layout);
/*  81: 81 */     layout.setHorizontalGroup(
/*  82: 82 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  83: 83 */       .addGroup(layout.createSequentialGroup()
/*  84: 84 */       .addComponent(outlineView2, -1, 478, 32767)
/*  85: 85 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/*  86: 86 */       .addComponent(jToolBar1, -2, -1, -2)));
/*  87:    */     
/*  88: 88 */     layout.setVerticalGroup(
/*  89: 89 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  90: 90 */       .addGroup(layout.createSequentialGroup()
/*  91: 91 */       .addComponent(jToolBar1, -1, 33, 32767)
/*  92: 92 */       .addGap(112, 112, 112))
/*  93: 93 */       .addComponent(outlineView2, -2, 0, 32767));
/*  94:    */   }
/*  95:    */   
/*  96:    */   private void editButtonActionPerformed(ActionEvent evt)
/*  97:    */   {
/*  98: 98 */     em.getSelectedNodes()[0].getPreferredAction().actionPerformed(evt);
/*  99:    */   }
/* 100:    */   
/* 101:    */   void load() {
/* 102:102 */     Iterable<NamedServiceNode> nodes = Iterables.transform(Lookup.getDefault().lookupAll(InterchangeBroker.class), Jdk6Functions.namedServiceToNode());
/* 103:103 */     em.setRootContext(new AbstractNodeBuilder().add(nodes).name("Interchange broker").build());
/* 104:    */   }
/* 105:    */   
/* 106:    */   void store() {
/* 107:107 */     for (Node o : em.getRootContext().getChildren().getNodes()) {
/* 108:108 */       if ((o instanceof NamedServiceNode)) {
/* 109:109 */         ((NamedServiceNode)o).applyConfig();
/* 110:    */       }
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   boolean valid() {
/* 115:115 */     return true;
/* 116:    */   }
/* 117:    */   
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */   public ExplorerManager getExplorerManager()
/* 125:    */   {
/* 126:126 */     return em;
/* 127:    */   }
/* 128:    */ }
