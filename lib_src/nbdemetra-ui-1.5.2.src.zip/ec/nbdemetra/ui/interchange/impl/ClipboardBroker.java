/*   1:    */ package ec.nbdemetra.ui.interchange.impl;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Throwables;
/*   4:    */ import ec.nbdemetra.ui.interchange.Exportable;
/*   5:    */ import ec.nbdemetra.ui.interchange.Importable;
/*   6:    */ import ec.nbdemetra.ui.interchange.InterchangeBroker;
/*   7:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*   8:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*   9:    */ import java.awt.Toolkit;
/*  10:    */ import java.awt.datatransfer.Clipboard;
/*  11:    */ import java.awt.datatransfer.DataFlavor;
/*  12:    */ import java.awt.datatransfer.StringSelection;
/*  13:    */ import java.awt.datatransfer.Transferable;
/*  14:    */ import java.awt.datatransfer.UnsupportedFlavorException;
/*  15:    */ import java.io.IOException;
/*  16:    */ import java.util.List;
/*  17:    */ import javax.annotation.Nonnull;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ public class ClipboardBroker
/*  39:    */   extends InterchangeBroker
/*  40:    */ {
/*  41:    */   public String getName()
/*  42:    */   {
/*  43: 43 */     return "Clipboard";
/*  44:    */   }
/*  45:    */   
/*  46:    */   private Clipboard getClipboard() {
/*  47: 47 */     return Toolkit.getDefaultToolkit().getSystemClipboard();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean canImport(List<? extends Importable> importables)
/*  51:    */   {
/*  52:    */     try {
/*  53: 53 */       String xml = readString(getClipboard());
/*  54: 54 */       if (xml == null) {
/*  55: 55 */         return false;
/*  56:    */       }
/*  57: 57 */       Configs configs = (Configs)Configs.xmlParser().parse(xml);
/*  58: 58 */       return (configs != null) && (configs.canImport(importables));
/*  59:    */     } catch (IOException ex) {}
/*  60: 60 */     return false;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void performImport(List<? extends Importable> importables)
/*  64:    */     throws IOException, IllegalArgumentException
/*  65:    */   {
/*  66: 66 */     Configs configs = load(getClipboard());
/*  67: 67 */     configs.performImport(importables);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean canExport(List<? extends Exportable> exportables)
/*  71:    */   {
/*  72: 72 */     return !exportables.isEmpty();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void performExport(List<? extends Exportable> exportables) throws IOException
/*  76:    */   {
/*  77: 77 */     Configs configs = Configs.fromExportables(exportables);
/*  78: 78 */     store(getClipboard(), configs);
/*  79:    */   }
/*  80:    */   
/*  81:    */   @Nonnull
/*  82:    */   private static Configs load(@Nonnull Clipboard clipboard) throws IOException {
/*  83: 83 */     String xml = readString(clipboard);
/*  84: 84 */     if (xml == null) {
/*  85: 85 */       throw new IOException("Not string input");
/*  86:    */     }
/*  87: 87 */     Configs result = (Configs)Configs.xmlParser().parse(xml);
/*  88: 88 */     if (result == null) {
/*  89: 89 */       throw new IOException("Cannot parse configs");
/*  90:    */     }
/*  91: 91 */     return result;
/*  92:    */   }
/*  93:    */   
/*  94:    */   private static void store(@Nonnull Clipboard clipboard, @Nonnull Configs configs) throws IOException {
/*  95: 95 */     String xml = Configs.xmlFormatter(true).formatAsString(configs);
/*  96: 96 */     if (xml == null) {
/*  97: 97 */       throw new IOException("Cannot format configs");
/*  98:    */     }
/*  99: 99 */     clipboard.setContents(new StringSelection(xml), null);
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static String readString(@Nonnull Clipboard clipboard) throws IOException {
/* 103:103 */     Transferable t = clipboard.getContents(null);
/* 104:104 */     if ((t != null) && (t.isDataFlavorSupported(DataFlavor.stringFlavor))) {
/* 105:    */       try {
/* 106:106 */         return (String)t.getTransferData(DataFlavor.stringFlavor);
/* 107:    */       } catch (UnsupportedFlavorException ex) {
/* 108:108 */         throw Throwables.propagate(ex);
/* 109:    */       }
/* 110:    */     }
/* 111:111 */     return null;
/* 112:    */   }
/* 113:    */ }
