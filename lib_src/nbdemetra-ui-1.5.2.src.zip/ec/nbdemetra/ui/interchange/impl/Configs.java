/*   1:    */ package ec.nbdemetra.ui.interchange.impl;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.StandardSystemProperty;
/*   6:    */ import com.google.common.base.Strings;
/*   7:    */ import com.google.common.base.Throwables;
/*   8:    */ import com.google.common.collect.ImmutableList;
/*   9:    */ import com.google.common.collect.ImmutableList.Builder;
/*  10:    */ import com.google.common.collect.Iterables;
/*  11:    */ import ec.nbdemetra.ui.Config;
/*  12:    */ import ec.nbdemetra.ui.interchange.Exportable;
/*  13:    */ import ec.nbdemetra.ui.interchange.Importable;
/*  14:    */ import ec.tss.tsproviders.utils.Formatters;
/*  15:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  16:    */ import ec.tss.tsproviders.utils.Parsers;
/*  17:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  18:    */ import java.io.IOException;
/*  19:    */ import java.util.Iterator;
/*  20:    */ import java.util.List;
/*  21:    */ import javax.annotation.Nonnull;
/*  22:    */ import javax.xml.bind.JAXBContext;
/*  23:    */ import javax.xml.bind.JAXBException;
/*  24:    */ import javax.xml.bind.annotation.XmlAttribute;
/*  25:    */ import javax.xml.bind.annotation.XmlElement;
/*  26:    */ import javax.xml.bind.annotation.XmlRootElement;
/*  27:    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*  28:    */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ @XmlJavaTypeAdapter(XmlAdapter.class)
/*  47:    */ public final class Configs
/*  48:    */ {
/*  49:    */   private final String author;
/*  50:    */   private final long creationTime;
/*  51:    */   private final ImmutableList<Config> items;
/*  52:    */   
/*  53:    */   @VisibleForTesting
/*  54:    */   Configs(String author, long creationTime, ImmutableList<Config> items)
/*  55:    */   {
/*  56: 56 */     this.author = author;
/*  57: 57 */     this.creationTime = creationTime;
/*  58: 58 */     this.items = items;
/*  59:    */   }
/*  60:    */   
/*  61:    */   @Nonnull
/*  62:    */   public String getAuthor() {
/*  63: 63 */     return author;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public long getCreationTime() {
/*  67: 67 */     return creationTime;
/*  68:    */   }
/*  69:    */   
/*  70:    */   @Nonnull
/*  71:    */   public List<Config> getItems() {
/*  72: 72 */     return items;
/*  73:    */   }
/*  74:    */   
/*  75:    */   @VisibleForTesting
/*  76:    */   ConfigsBean toBean() {
/*  77: 77 */     ConfigsBean result = new ConfigsBean();
/*  78: 78 */     author = author;
/*  79: 79 */     creationTime = creationTime;
/*  80: 80 */     items = ((Config[])Iterables.toArray(items, Config.class));
/*  81: 81 */     return result;
/*  82:    */   }
/*  83:    */   
/*  84:    */   @Nonnull
/*  85:    */   public static Formatters.Formatter<Configs> xmlFormatter(boolean formattedOutput) {
/*  86: 86 */     return formattedOutput ? XMLget()formattedOutputFormatter : XMLget()defaultFormatter;
/*  87:    */   }
/*  88:    */   
/*  89:    */   @Nonnull
/*  90:    */   public static Parsers.Parser<Configs> xmlParser() {
/*  91: 91 */     return XMLget()defaultParser;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static class XmlAdapter extends XmlAdapter<Configs.ConfigsBean, Configs>
/*  95:    */   {
/*  96:    */     public Configs unmarshal(Configs.ConfigsBean v) throws Exception
/*  97:    */     {
/*  98: 98 */       return v.toId();
/*  99:    */     }
/* 100:    */     
/* 101:    */     public Configs.ConfigsBean marshal(Configs v) throws Exception
/* 102:    */     {
/* 103:103 */       return v.toBean();
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   @XmlRootElement(name="configs")
/* 108:    */   public static final class ConfigsBean
/* 109:    */   {
/* 110:    */     @XmlAttribute
/* 111:    */     public String author;
/* 112:    */     @XmlAttribute
/* 113:    */     public long creationTime;
/* 114:    */     @XmlElement(name="config")
/* 115:    */     public Config[] items;
/* 116:    */     
/* 117:    */     @VisibleForTesting
/* 118:    */     Configs toId() {
/* 119:119 */       return new Configs(Strings.nullToEmpty(author), creationTime, items != null ? ImmutableList.copyOf(items) : ImmutableList.of());
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static Configs fromExportables(List<? extends Exportable> exportables) {
/* 124:124 */     ImmutableList.Builder<Config> items = ImmutableList.builder();
/* 125:125 */     for (Exportable o : exportables) {
/* 126:126 */       items.add(o.exportConfig());
/* 127:    */     }
/* 128:128 */     return new Configs(StandardSystemProperty.USER_NAME.value(), System.currentTimeMillis(), items.build());
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void performImport(List<? extends Importable> importables) throws IOException, IllegalArgumentException {
/* 132:132 */     for (Config o : items) {
/* 133:133 */       for (Importable importable : importables)
/* 134:134 */         if (importable.getDomain().equals(o.getDomain())) {
/* 135:135 */           importable.importConfig(o);
/* 136:136 */           break;
/* 137:    */         }
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean canImport(List<? extends Importable> importables) {
/* 142:    */     Iterator localIterator2;
/* 143:143 */     for (Iterator localIterator1 = items.iterator(); localIterator1.hasNext(); 
/* 144:144 */         localIterator2.hasNext())
/* 145:    */     {
/* 146:143 */       Config o = (Config)localIterator1.next();
/* 147:144 */       localIterator2 = importables.iterator(); continue;Importable importable = (Importable)localIterator2.next();
/* 148:145 */       if (importable.getDomain().equals(o.getDomain())) {
/* 149:146 */         return true;
/* 150:    */       }
/* 151:    */     }
/* 152:    */     
/* 153:150 */     return false;
/* 154:    */   }
/* 155:    */   
/* 156:    */ 
/* 157:154 */   private static final ThreadLocal<Xml> XML = new ThreadLocal()
/* 158:    */   {
/* 159:    */     protected Configs.Xml initialValue() {
/* 160:157 */       return new Configs.Xml(null);
/* 161:    */     }
/* 162:    */   };
/* 163:    */   
/* 164:    */   private static final class Xml
/* 165:    */   {
/* 166:    */     static final JAXBContext BEAN_CONTEXT;
/* 167:    */     
/* 168:    */     static {
/* 169:    */       try {
/* 170:167 */         BEAN_CONTEXT = JAXBContext.newInstance(new Class[] { Configs.ConfigsBean.class });
/* 171:    */       } catch (JAXBException ex) {
/* 172:169 */         throw Throwables.propagate(ex);
/* 173:    */       } }
/* 174:    */     
/* 175:172 */     static final Function<Configs.ConfigsBean, Configs> FROM_BEAN = new Function()
/* 176:    */     {
/* 177:    */       public Configs apply(Configs.ConfigsBean input) {
/* 178:175 */         return input.toId();
/* 179:    */       }
/* 180:    */     };
/* 181:178 */     static final Function<Configs, Configs.ConfigsBean> TO_BEAN = new Function()
/* 182:    */     {
/* 183:    */       public Configs.ConfigsBean apply(Configs input) {
/* 184:181 */         return input.toBean();
/* 185:    */       }
/* 186:    */     };
/* 187:    */     
/* 188:185 */     final Parsers.Parser<Configs> defaultParser = Parsers.onJAXB(BEAN_CONTEXT).compose(FROM_BEAN);
/* 189:186 */     final Formatters.Formatter<Configs> defaultFormatter = Formatters.onJAXB(BEAN_CONTEXT, false).compose(TO_BEAN);
/* 190:187 */     final Formatters.Formatter<Configs> formattedOutputFormatter = Formatters.onJAXB(BEAN_CONTEXT, true).compose(TO_BEAN);
/* 191:    */   }
/* 192:    */ }
