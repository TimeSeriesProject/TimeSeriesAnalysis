/*   1:    */ package ec.nbdemetra.ui.interchange.impl;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.interchange.Exportable;
/*   4:    */ import ec.nbdemetra.ui.interchange.Importable;
/*   5:    */ import ec.nbdemetra.ui.interchange.InterchangeBroker;
/*   6:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*   7:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*   8:    */ import java.io.File;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.OutputStream;
/*  11:    */ import java.io.OutputStreamWriter;
/*  12:    */ import java.nio.file.Files;
/*  13:    */ import java.nio.file.OpenOption;
/*  14:    */ import java.nio.file.Path;
/*  15:    */ import java.nio.file.StandardOpenOption;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.Locale;
/*  18:    */ import java.util.zip.GZIPOutputStream;
/*  19:    */ import javax.annotation.Nonnull;
/*  20:    */ import javax.swing.JFileChooser;
/*  21:    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*  22:    */ import org.openide.filesystems.FileChooserBuilder;
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public class FileBroker
/*  47:    */   extends InterchangeBroker
/*  48:    */ {
/*  49:    */   private final JFileChooser fileChooser;
/*  50:    */   
/*  51:    */   public FileBroker()
/*  52:    */   {
/*  53: 53 */     fileChooser = new FileChooserBuilder(FileBroker.class)
/*  54: 54 */       .setAcceptAllFileFilterUsed(false)
/*  55: 55 */       .setFileFilter(new FileNameExtensionFilter("Configs files", new String[] { "cfgx" }))
/*  56: 56 */       .setFilesOnly(true)
/*  57: 57 */       .createFileChooser();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getName()
/*  61:    */   {
/*  62: 62 */     return "File";
/*  63:    */   }
/*  64:    */   
/*  65:    */   public String getDisplayName()
/*  66:    */   {
/*  67: 67 */     return "File...";
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean canImport(List<? extends Importable> importables)
/*  71:    */   {
/*  72: 72 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void performImport(List<? extends Importable> importables) throws IOException
/*  76:    */   {
/*  77: 77 */     if (fileChooser.showOpenDialog(null) == 0) {
/*  78: 78 */       Configs configs = load(fileChooser.getSelectedFile().toPath());
/*  79: 79 */       configs.performImport(importables);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean canExport(List<? extends Exportable> exportables)
/*  84:    */   {
/*  85: 85 */     return !exportables.isEmpty();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void performExport(List<? extends Exportable> exportables) throws IOException
/*  89:    */   {
/*  90: 90 */     if (fileChooser.showSaveDialog(null) == 0) {
/*  91: 91 */       Configs configs = Configs.fromExportables(exportables);
/*  92: 92 */       store(enforceExtension(fileChooser.getSelectedFile()).toPath(), configs);
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   private File enforceExtension(File input) {
/*  97: 97 */     int index = input.getPath().toLowerCase(Locale.ROOT).indexOf(".cfgx");
/*  98: 98 */     return index != -1 ? input : new File(input.getPath() + ".cfgx");
/*  99:    */   }
/* 100:    */   
/* 101:    */   @Nonnull
/* 102:    */   public static Configs load(@Nonnull Path file) throws IOException {
/* 103:103 */     CharSequence xml = readGZIP(file);
/* 104:104 */     Configs result = (Configs)Configs.xmlParser().parse(xml);
/* 105:105 */     if (result == null) {
/* 106:106 */       throw new IOException("Cannot parse configs");
/* 107:    */     }
/* 108:108 */     return result;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static void store(@Nonnull Path file, @Nonnull Configs configs) throws IOException {
/* 112:112 */     CharSequence xml = Configs.xmlFormatter(true).format(configs);
/* 113:113 */     if (xml == null) {
/* 114:114 */       throw new IOException("Cannot format configs");
/* 115:    */     }
/* 116:116 */     writeGZIP(file, xml);
/* 117:    */   }
/* 118:    */   
/* 119:    */   /* Error */
/* 120:    */   private static CharSequence readGZIP(Path file)
/* 121:    */     throws IOException
/* 122:    */   {
/* 123:    */     // Byte code:
/* 124:    */     //   0: aconst_null
/* 125:    */     //   1: astore_1
/* 126:    */     //   2: aconst_null
/* 127:    */     //   3: astore_2
/* 128:    */     //   4: aload_0
/* 129:    */     //   5: iconst_1
/* 130:    */     //   6: anewarray 207	java/nio/file/OpenOption
/* 131:    */     //   9: dup
/* 132:    */     //   10: iconst_0
/* 133:    */     //   11: getstatic 209	java/nio/file/StandardOpenOption:READ	Ljava/nio/file/StandardOpenOption;
/* 134:    */     //   14: aastore
/* 135:    */     //   15: invokestatic 215	java/nio/file/Files:newInputStream	(Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Ljava/io/InputStream;
/* 136:    */     //   18: astore_3
/* 137:    */     //   19: aconst_null
/* 138:    */     //   20: astore 4
/* 139:    */     //   22: aconst_null
/* 140:    */     //   23: astore 5
/* 141:    */     //   25: new 221	java/util/zip/GZIPInputStream
/* 142:    */     //   28: dup
/* 143:    */     //   29: aload_3
/* 144:    */     //   30: invokespecial 223	java/util/zip/GZIPInputStream:<init>	(Ljava/io/InputStream;)V
/* 145:    */     //   33: astore 6
/* 146:    */     //   35: aconst_null
/* 147:    */     //   36: astore 7
/* 148:    */     //   38: aconst_null
/* 149:    */     //   39: astore 8
/* 150:    */     //   41: new 226	java/io/InputStreamReader
/* 151:    */     //   44: dup
/* 152:    */     //   45: aload 6
/* 153:    */     //   47: getstatic 228	java/nio/charset/StandardCharsets:UTF_8	Ljava/nio/charset/Charset;
/* 154:    */     //   50: invokespecial 234	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
/* 155:    */     //   53: astore 9
/* 156:    */     //   55: new 143	java/lang/StringBuilder
/* 157:    */     //   58: dup
/* 158:    */     //   59: invokespecial 237	java/lang/StringBuilder:<init>	()V
/* 159:    */     //   62: astore 10
/* 160:    */     //   64: aconst_null
/* 161:    */     //   65: astore 11
/* 162:    */     //   67: aconst_null
/* 163:    */     //   68: astore 12
/* 164:    */     //   70: new 238	java/io/BufferedReader
/* 165:    */     //   73: dup
/* 166:    */     //   74: aload 9
/* 167:    */     //   76: invokespecial 240	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/* 168:    */     //   79: astore 13
/* 169:    */     //   81: goto +11 -> 92
/* 170:    */     //   84: aload 10
/* 171:    */     //   86: aload 14
/* 172:    */     //   88: invokevirtual 152	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/* 173:    */     //   91: pop
/* 174:    */     //   92: aload 13
/* 175:    */     //   94: invokevirtual 243	java/io/BufferedReader:readLine	()Ljava/lang/String;
/* 176:    */     //   97: dup
/* 177:    */     //   98: astore 14
/* 178:    */     //   100: ifnonnull -16 -> 84
/* 179:    */     //   103: aload 13
/* 180:    */     //   105: ifnull +57 -> 162
/* 181:    */     //   108: aload 13
/* 182:    */     //   110: invokevirtual 246	java/io/BufferedReader:close	()V
/* 183:    */     //   113: goto +49 -> 162
/* 184:    */     //   116: astore 11
/* 185:    */     //   118: aload 13
/* 186:    */     //   120: ifnull +8 -> 128
/* 187:    */     //   123: aload 13
/* 188:    */     //   125: invokevirtual 246	java/io/BufferedReader:close	()V
/* 189:    */     //   128: aload 11
/* 190:    */     //   130: athrow
/* 191:    */     //   131: astore 12
/* 192:    */     //   133: aload 11
/* 193:    */     //   135: ifnonnull +10 -> 145
/* 194:    */     //   138: aload 12
/* 195:    */     //   140: astore 11
/* 196:    */     //   142: goto +17 -> 159
/* 197:    */     //   145: aload 11
/* 198:    */     //   147: aload 12
/* 199:    */     //   149: if_acmpeq +10 -> 159
/* 200:    */     //   152: aload 11
/* 201:    */     //   154: aload 12
/* 202:    */     //   156: invokevirtual 249	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 203:    */     //   159: aload 11
/* 204:    */     //   161: athrow
/* 205:    */     //   162: aload 10
/* 206:    */     //   164: aload 9
/* 207:    */     //   166: ifnull +8 -> 174
/* 208:    */     //   169: aload 9
/* 209:    */     //   171: invokevirtual 255	java/io/InputStreamReader:close	()V
/* 210:    */     //   174: aload 6
/* 211:    */     //   176: ifnull +8 -> 184
/* 212:    */     //   179: aload 6
/* 213:    */     //   181: invokevirtual 256	java/util/zip/GZIPInputStream:close	()V
/* 214:    */     //   184: aload_3
/* 215:    */     //   185: ifnull +7 -> 192
/* 216:    */     //   188: aload_3
/* 217:    */     //   189: invokevirtual 257	java/io/InputStream:close	()V
/* 218:    */     //   192: areturn
/* 219:    */     //   193: astore 7
/* 220:    */     //   195: aload 9
/* 221:    */     //   197: ifnull +8 -> 205
/* 222:    */     //   200: aload 9
/* 223:    */     //   202: invokevirtual 255	java/io/InputStreamReader:close	()V
/* 224:    */     //   205: aload 7
/* 225:    */     //   207: athrow
/* 226:    */     //   208: astore 8
/* 227:    */     //   210: aload 7
/* 228:    */     //   212: ifnonnull +10 -> 222
/* 229:    */     //   215: aload 8
/* 230:    */     //   217: astore 7
/* 231:    */     //   219: goto +17 -> 236
/* 232:    */     //   222: aload 7
/* 233:    */     //   224: aload 8
/* 234:    */     //   226: if_acmpeq +10 -> 236
/* 235:    */     //   229: aload 7
/* 236:    */     //   231: aload 8
/* 237:    */     //   233: invokevirtual 249	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 238:    */     //   236: aload 7
/* 239:    */     //   238: athrow
/* 240:    */     //   239: astore 4
/* 241:    */     //   241: aload 6
/* 242:    */     //   243: ifnull +8 -> 251
/* 243:    */     //   246: aload 6
/* 244:    */     //   248: invokevirtual 256	java/util/zip/GZIPInputStream:close	()V
/* 245:    */     //   251: aload 4
/* 246:    */     //   253: athrow
/* 247:    */     //   254: astore 5
/* 248:    */     //   256: aload 4
/* 249:    */     //   258: ifnonnull +10 -> 268
/* 250:    */     //   261: aload 5
/* 251:    */     //   263: astore 4
/* 252:    */     //   265: goto +17 -> 282
/* 253:    */     //   268: aload 4
/* 254:    */     //   270: aload 5
/* 255:    */     //   272: if_acmpeq +10 -> 282
/* 256:    */     //   275: aload 4
/* 257:    */     //   277: aload 5
/* 258:    */     //   279: invokevirtual 249	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 259:    */     //   282: aload 4
/* 260:    */     //   284: athrow
/* 261:    */     //   285: astore_1
/* 262:    */     //   286: aload_3
/* 263:    */     //   287: ifnull +7 -> 294
/* 264:    */     //   290: aload_3
/* 265:    */     //   291: invokevirtual 257	java/io/InputStream:close	()V
/* 266:    */     //   294: aload_1
/* 267:    */     //   295: athrow
/* 268:    */     //   296: astore_2
/* 269:    */     //   297: aload_1
/* 270:    */     //   298: ifnonnull +8 -> 306
/* 271:    */     //   301: aload_2
/* 272:    */     //   302: astore_1
/* 273:    */     //   303: goto +13 -> 316
/* 274:    */     //   306: aload_1
/* 275:    */     //   307: aload_2
/* 276:    */     //   308: if_acmpeq +8 -> 316
/* 277:    */     //   311: aload_1
/* 278:    */     //   312: aload_2
/* 279:    */     //   313: invokevirtual 249	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 280:    */     //   316: aload_1
/* 281:    */     //   317: athrow
/* 282:    */     // Line number table:
/* 283:    */     //   Java source line #120	-> byte code offset #0
/* 284:    */     //   Java source line #121	-> byte code offset #19
/* 285:    */     //   Java source line #121	-> byte code offset #25
/* 286:    */     //   Java source line #122	-> byte code offset #35
/* 287:    */     //   Java source line #122	-> byte code offset #41
/* 288:    */     //   Java source line #123	-> byte code offset #55
/* 289:    */     //   Java source line #124	-> byte code offset #64
/* 290:    */     //   Java source line #124	-> byte code offset #70
/* 291:    */     //   Java source line #126	-> byte code offset #81
/* 292:    */     //   Java source line #127	-> byte code offset #84
/* 293:    */     //   Java source line #126	-> byte code offset #92
/* 294:    */     //   Java source line #129	-> byte code offset #103
/* 295:    */     //   Java source line #130	-> byte code offset #162
/* 296:    */     //   Java source line #131	-> byte code offset #164
/* 297:    */     //   Java source line #132	-> byte code offset #174
/* 298:    */     //   Java source line #133	-> byte code offset #184
/* 299:    */     //   Java source line #130	-> byte code offset #192
/* 300:    */     //   Java source line #131	-> byte code offset #195
/* 301:    */     //   Java source line #132	-> byte code offset #241
/* 302:    */     //   Java source line #133	-> byte code offset #286
/* 303:    */     // Local variable table:
/* 304:    */     //   start	length	slot	name	signature
/* 305:    */     //   0	318	0	file	Path
/* 306:    */     //   1	1	1	localObject1	Object
/* 307:    */     //   285	13	1	localObject2	Object
/* 308:    */     //   302	15	1	localObject3	Object
/* 309:    */     //   3	1	2	localObject4	Object
/* 310:    */     //   296	17	2	localThrowable1	Throwable
/* 311:    */     //   18	273	3	stream	java.io.InputStream
/* 312:    */     //   20	1	4	localObject5	Object
/* 313:    */     //   239	18	4	localObject6	Object
/* 314:    */     //   263	20	4	localObject7	Object
/* 315:    */     //   23	1	5	localObject8	Object
/* 316:    */     //   254	24	5	localThrowable2	Throwable
/* 317:    */     //   33	214	6	gz	java.util.zip.GZIPInputStream
/* 318:    */     //   36	1	7	localObject9	Object
/* 319:    */     //   193	18	7	localObject10	Object
/* 320:    */     //   217	20	7	localObject11	Object
/* 321:    */     //   39	1	8	localObject12	Object
/* 322:    */     //   208	24	8	localThrowable3	Throwable
/* 323:    */     //   53	148	9	reader	java.io.InputStreamReader
/* 324:    */     //   62	101	10	result	java.lang.StringBuilder
/* 325:    */     //   65	1	11	localObject13	Object
/* 326:    */     //   116	18	11	localObject14	Object
/* 327:    */     //   140	20	11	localObject15	Object
/* 328:    */     //   68	1	12	localObject16	Object
/* 329:    */     //   131	24	12	localThrowable4	Throwable
/* 330:    */     //   79	45	13	buff	java.io.BufferedReader
/* 331:    */     //   84	3	14	line	String
/* 332:    */     //   98	3	14	line	String
/* 333:    */     // Exception table:
/* 334:    */     //   from	to	target	type
/* 335:    */     //   81	103	116	finally
/* 336:    */     //   70	131	131	finally
/* 337:    */     //   55	164	193	finally
/* 338:    */     //   174	193	193	finally
/* 339:    */     //   41	208	208	finally
/* 340:    */     //   35	174	239	finally
/* 341:    */     //   184	239	239	finally
/* 342:    */     //   25	254	254	finally
/* 343:    */     //   19	184	285	finally
/* 344:    */     //   192	285	285	finally
/* 345:    */     //   4	296	296	finally
/* 346:    */   }
/* 347:    */   
/* 348:    */   private static void writeGZIP(Path file, CharSequence xml)
/* 349:    */     throws IOException
/* 350:    */   {
/* 351:137 */     Object localObject1 = null;Object localObject4 = null; Object localObject3; label228: try { stream = Files.newOutputStream(file, new OpenOption[] { StandardOpenOption.CREATE }); } finally { OutputStream stream;
/* 352:    */       Object localObject5;
/* 353:    */       Object localObject8;
/* 354:    */       GZIPOutputStream gz;
/* 355:    */       Object localObject9;
/* 356:    */       Object localObject12;
/* 357:143 */       OutputStreamWriter writer; Object localObject11; Object localObject7; localObject3 = localThrowable1; break label228; if (localObject3 != localThrowable1) localObject3.addSuppressed(localThrowable1);
/* 358:    */     }
/* 359:    */   }
/* 360:    */ }
