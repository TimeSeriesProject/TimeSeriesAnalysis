/*  1:   */ package ec.nbdemetra.ui.interchange.impl;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.Config;
/*  5:   */ import ec.nbdemetra.ui.interchange.Exportable;
/*  6:   */ import ec.nbdemetra.ui.interchange.InterchangeBroker;
/*  7:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  8:   */ import ec.util.desktop.Desktop;
/*  9:   */ import ec.util.desktop.Desktop.Action;
/* 10:   */ import ec.util.desktop.DesktopManager;
/* 11:   */ import ec.util.desktop.MailtoBuilder;
/* 12:   */ import java.io.IOException;
/* 13:   */ import java.util.List;
/* 14:   */ import javax.annotation.Nonnull;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ public class MailBroker
/* 34:   */   extends InterchangeBroker
/* 35:   */ {
/* 36:   */   public String getName()
/* 37:   */   {
/* 38:38 */     return "Mail";
/* 39:   */   }
/* 40:   */   
/* 41:   */   private Desktop getDesktop() {
/* 42:42 */     return DesktopManager.get();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public boolean canExport(List<? extends Exportable> exportables)
/* 46:   */   {
/* 47:47 */     return (!exportables.isEmpty()) && (getDesktop().isSupported(Desktop.Action.MAIL));
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void performExport(List<? extends Exportable> exportables) throws IOException
/* 51:   */   {
/* 52:52 */     Configs configs = Configs.fromExportables(exportables);
/* 53:53 */     store(getDesktop(), configs);
/* 54:   */   }
/* 55:   */   
/* 56:   */   private static void store(@Nonnull Desktop desktop, @Nonnull Configs configs) throws IOException {
/* 57:57 */     String subject = configs.getItems().size() == 1 ? ((Config)configs.getItems().get(0)).getName() : "Configs";
/* 58:58 */     String body = (String)Configs.xmlFormatter(true).tryFormatAsString(configs).get();
/* 59:59 */     desktop.mail(new MailtoBuilder().subject(subject).body(body).build());
/* 60:   */   }
/* 61:   */ }
