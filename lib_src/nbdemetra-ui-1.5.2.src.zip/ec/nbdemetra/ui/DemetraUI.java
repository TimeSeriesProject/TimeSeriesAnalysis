/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicates;
/*   7:    */ import com.google.common.collect.Iterables;
/*   8:    */ import com.google.common.collect.Ordering;
/*   9:    */ import ec.nbdemetra.ui.awt.ListenableBean;
/*  10:    */ import ec.nbdemetra.ui.tsaction.ITsAction;
/*  11:    */ import ec.satoolkit.ISaSpecification;
/*  12:    */ import ec.satoolkit.tramoseats.TramoSeatsSpecification;
/*  13:    */ import ec.satoolkit.x13.X13Specification;
/*  14:    */ import ec.tss.sa.EstimationPolicyType;
/*  15:    */ import ec.tss.tsproviders.utils.DataFormat;
/*  16:    */ import ec.tss.tsproviders.utils.IParam;
/*  17:    */ import ec.tss.tsproviders.utils.Params;
/*  18:    */ import ec.tstoolkit.utilities.ThreadPoolSize;
/*  19:    */ import ec.tstoolkit.utilities.ThreadPriority;
/*  20:    */ import ec.util.chart.ColorScheme;
/*  21:    */ import ec.util.various.swing.FontAwesome;
/*  22:    */ import java.awt.Color;
/*  23:    */ import java.util.Collection;
/*  24:    */ import java.util.List;
/*  25:    */ import javax.annotation.Nonnull;
/*  26:    */ import javax.swing.Icon;
/*  27:    */ import org.netbeans.api.options.OptionsDisplayer;
/*  28:    */ import org.openide.util.Lookup;
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ public class DemetraUI
/*  46:    */   extends ListenableBean
/*  47:    */   implements IConfigurable
/*  48:    */ {
/*  49:    */   public static final String COLOR_SCHEME_NAME_PROPERTY = "colorSchemeName";
/*  50:    */   public static final String DATA_FORMAT_PROPERTY = "dataFormat";
/*  51:    */   public static final String SHOW_UNAVAILABLE_TSPROVIDER_PROPERTY = "showUnavailableTsProviders";
/*  52:    */   public static final String TS_ACTION_NAME_PROPERTY = "tsActionName";
/*  53:    */   public static final String PERSIST_TOOLS_CONTENT_PROPERTY = "persistToolsContent";
/*  54:    */   public static final String PERSIST_OPENED_DATASOURCES_PROPERTY = "persistOpenDataSources";
/*  55:    */   public static final String BATCH_POOL_SIZE_PROPERTY = "batchPoolSize";
/*  56:    */   public static final String BATCH_PRIORITY_PROPERTY = "batchPriority";
/*  57:    */   public static final String GROWTH_CHART_LENGTH_PROPERTY = "growthChartLength";
/*  58:    */   public static final String SPECTRAL_YEARS_PROPERTY = "spectralLastYears";
/*  59:    */   public static final String STABILITY_YEARS_PROPERTY = "stabilityLastYears";
/*  60:    */   public static final String ESTIMATION_POLICY_PROPERTY = "estimationPolicyType";
/*  61:    */   public static final String DEFAULT_SA_SPEC_PROPERTY = "defaultSASpec";
/*  62:    */   public static final String POPUP_MENU_ICONS_VISIBLE_PROPERTY = "menuIconsVisibility";
/*  63:    */   
/*  64:    */   @Nonnull
/*  65:    */   public static DemetraUI getDefault()
/*  66:    */   {
/*  67: 67 */     return (DemetraUI)Lookup.getDefault().lookup(DemetraUI.class);
/*  68:    */   }
/*  69:    */   
/*  70:    */   @Nonnull
/*  71:    */   @Deprecated
/*  72:    */   public static DemetraUI getInstance() {
/*  73: 73 */     return getDefault();
/*  74:    */   }
/*  75:    */   
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93: 93 */   static final IParam<Config, String> COLOR_SCHEME_NAME = Params.onString("Smart", "colorSchemeName");
/*  94: 94 */   static final IParam<Config, DataFormat> DATA_FORMAT = Params.onDataFormat(new DataFormat(null, "yyyy-MM", null), "locale", "datePattern", "numberPattern");
/*  95: 95 */   static final IParam<Config, Boolean> SHOW_UNAVAILABLE = Params.onBoolean(Boolean.valueOf(false), "showUnavailableTsProviders");
/*  96: 96 */   static final IParam<Config, String> TS_ACTION_NAME = Params.onString("ChartGridTsAction", "tsActionName");
/*  97: 97 */   static final IParam<Config, Boolean> PERSIST_TOOLS_CONTENT = Params.onBoolean(Boolean.valueOf(false), "persistToolsContent");
/*  98: 98 */   static final IParam<Config, Boolean> PERSIST_OPENED_DATASOURCES = Params.onBoolean(Boolean.valueOf(false), "persistOpenDataSources");
/*  99: 99 */   static final IParam<Config, ThreadPoolSize> BATCH_POOL_SIZE = Params.onEnum(ThreadPoolSize.ALL_BUT_ONE, "batchPoolSize");
/* 100:100 */   static final IParam<Config, ThreadPriority> BATCH_PRIORITY = Params.onEnum(ThreadPriority.NORMAL, "batchPriority");
/* 101:101 */   static final IParam<Config, Integer> GROWTH_LAST_YEARS = Params.onInteger(Integer.valueOf(4), "growthChartLength");
/* 102:102 */   static final IParam<Config, Integer> SPECTRAL_LAST_YEARS = Params.onInteger(Integer.valueOf(0), "spectralLastYears");
/* 103:103 */   static final IParam<Config, Integer> STABILITY_LENGTH = Params.onInteger(Integer.valueOf(8), "stabilityLastYears");
/* 104:104 */   static final IParam<Config, EstimationPolicyType> ESTIMATION_POLICY_TYPE = Params.onEnum(EstimationPolicyType.FreeParameters, "estimationPolicyType");
/* 105:105 */   static final IParam<Config, String> DEFAULT_SA_SPEC = Params.onString("tramoseats." + TramoSeatsSpecification.RSAfull.toString(), "defaultSASpec");
/* 106:106 */   static final IParam<Config, Boolean> POPUP_MENU_ICONS_VISIBLE = Params.onBoolean(Boolean.valueOf(false), "menuIconsVisibility");
/* 107:    */   
/* 108:108 */   private static final Ordering<ColorScheme> COLOR_SCHEME_ORDERING = Ordering.natural().onResultOf(Jdk6Functions.colorSchemeDisplayName());
/* 109:109 */   private static final Ordering<? super ITsAction> TS_ACTION_ORDERING = Ordering.natural().onResultOf(Jdk6Functions.namedServiceDisplayName());
/* 110:    */   private final ConfigBean properties;
/* 111:    */   
/* 112:    */   public DemetraUI()
/* 113:    */   {
/* 114:114 */     properties = new ConfigBean();
/* 115:    */   }
/* 116:    */   
/* 117:    */   public String getColorSchemeName()
/* 118:    */   {
/* 119:119 */     return properties.colorSchemeName;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setColorSchemeName(String colorSchemeName) {
/* 123:123 */     String old = properties.colorSchemeName;
/* 124:124 */     properties.colorSchemeName = (colorSchemeName != null ? colorSchemeName : (String)COLOR_SCHEME_NAME.defaultValue());
/* 125:125 */     firePropertyChange("colorSchemeName", old, properties.colorSchemeName);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public DataFormat getDataFormat() {
/* 129:129 */     return properties.dataFormat;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setDataFormat(DataFormat dataFormat) {
/* 133:133 */     DataFormat old = properties.dataFormat;
/* 134:134 */     properties.dataFormat = (dataFormat != null ? dataFormat : (DataFormat)DATA_FORMAT.defaultValue());
/* 135:135 */     firePropertyChange("dataFormat", old, properties.dataFormat);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public boolean isShowUnavailableTsProviders() {
/* 139:139 */     return properties.showUnavailableTsProviders.booleanValue();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setShowUnavailableTsProviders(boolean show) {
/* 143:143 */     boolean old = properties.showUnavailableTsProviders.booleanValue();
/* 144:144 */     properties.showUnavailableTsProviders = Boolean.valueOf(show);
/* 145:145 */     firePropertyChange("showUnavailableTsProviders", Boolean.valueOf(old), properties.showUnavailableTsProviders);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public String getTsActionName() {
/* 149:149 */     return properties.tsActionName;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setTsActionName(String tsActionName) {
/* 153:153 */     String old = properties.tsActionName;
/* 154:154 */     properties.tsActionName = (tsActionName != null ? tsActionName : (String)TS_ACTION_NAME.defaultValue());
/* 155:155 */     firePropertyChange("tsActionName", old, properties.tsActionName);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public boolean isPersistToolsContent() {
/* 159:159 */     return properties.persistToolsContent;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setPersistToolsContent(boolean persistToolsContent) {
/* 163:163 */     boolean old = properties.persistToolsContent;
/* 164:164 */     properties.persistToolsContent = persistToolsContent;
/* 165:165 */     firePropertyChange("persistToolsContent", Boolean.valueOf(old), Boolean.valueOf(properties.persistToolsContent));
/* 166:    */   }
/* 167:    */   
/* 168:    */   public boolean isPersistOpenedDataSources() {
/* 169:169 */     return properties.persistOpenedDataSources;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setPersistOpenedDataSources(boolean persistOpenedDataSources) {
/* 173:173 */     boolean old = properties.persistOpenedDataSources;
/* 174:174 */     properties.persistOpenedDataSources = persistOpenedDataSources;
/* 175:175 */     firePropertyChange("persistOpenDataSources", Boolean.valueOf(old), Boolean.valueOf(properties.persistOpenedDataSources));
/* 176:    */   }
/* 177:    */   
/* 178:    */   public ThreadPoolSize getBatchPoolSize() {
/* 179:179 */     return properties.batchPoolSize;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setBatchPoolSize(ThreadPoolSize batchPoolSize) {
/* 183:183 */     ThreadPoolSize old = properties.batchPoolSize;
/* 184:184 */     properties.batchPoolSize = (batchPoolSize != null ? batchPoolSize : (ThreadPoolSize)BATCH_POOL_SIZE.defaultValue());
/* 185:185 */     firePropertyChange("batchPoolSize", old, properties.batchPoolSize);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public ThreadPriority getBatchPriority() {
/* 189:189 */     return properties.batchPriority;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void setBatchPriority(ThreadPriority batchPriority) {
/* 193:193 */     ThreadPriority old = properties.batchPriority;
/* 194:194 */     properties.batchPriority = (batchPriority != null ? batchPriority : (ThreadPriority)BATCH_PRIORITY.defaultValue());
/* 195:195 */     firePropertyChange("batchPriority", old, properties.batchPriority);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public Integer getGrowthLastYears() {
/* 199:199 */     return properties.growthLastYears;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setGrowthLastYears(Integer lastYears) {
/* 203:203 */     Integer old = properties.growthLastYears;
/* 204:204 */     properties.growthLastYears = (GROWTH_LAST_YEARS != null ? lastYears : (Integer)GROWTH_LAST_YEARS.defaultValue());
/* 205:205 */     firePropertyChange("growthChartLength", old, properties.growthLastYears);
/* 206:    */   }
/* 207:    */   
/* 208:    */   public Integer getSpectralLastYears() {
/* 209:209 */     return properties.spectralLastYears;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void setSpectralLastYears(Integer lastYears) {
/* 213:213 */     Integer old = properties.spectralLastYears;
/* 214:214 */     properties.spectralLastYears = (SPECTRAL_LAST_YEARS != null ? lastYears : (Integer)SPECTRAL_LAST_YEARS.defaultValue());
/* 215:215 */     firePropertyChange("spectralLastYears", old, properties.spectralLastYears);
/* 216:    */   }
/* 217:    */   
/* 218:    */   public Integer getStabilityLength() {
/* 219:219 */     return properties.stabilityLength;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public void setStabilityLength(Integer length) {
/* 223:223 */     Integer old = properties.stabilityLength;
/* 224:224 */     properties.stabilityLength = (STABILITY_LENGTH != null ? length : (Integer)STABILITY_LENGTH.defaultValue());
/* 225:225 */     firePropertyChange("stabilityLastYears", old, properties.stabilityLength);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public EstimationPolicyType getEstimationPolicyType() {
/* 229:229 */     return properties.estimationPolicyType;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public void setEstimationPolicyType(EstimationPolicyType type) {
/* 233:233 */     EstimationPolicyType old = properties.estimationPolicyType;
/* 234:234 */     properties.estimationPolicyType = (type != null ? type : (EstimationPolicyType)ESTIMATION_POLICY_TYPE.defaultValue());
/* 235:235 */     firePropertyChange("estimationPolicyType", old, properties.estimationPolicyType);
/* 236:    */   }
/* 237:    */   
/* 238:    */   public ISaSpecification getDefaultSASpec() { String str;
/* 239:239 */     switch ((str = properties.defaultSASpec).hashCode()) {case -1177193622:  if (str.equals("tramoseats.RSAfull")) {} break; case -651111115:  if (str.equals("tramoseats.RSA0")) break; break; case -651111114:  if (str.equals("tramoseats.RSA1")) {} break; case -651111113:  if (str.equals("tramoseats.RSA2")) {} break; case -651111112:  if (str.equals("tramoseats.RSA3")) {} break; case -651111111:  if (str.equals("tramoseats.RSA4")) {} break; case -651111110:  if (str.equals("tramoseats.RSA5")) {} break; case 577643812:  if (str.equals("x13.X11")) {} break; case 726943460:  if (str.equals("x13.RSA0")) {} break; case 726943461:  if (str.equals("x13.RSA1")) {} break; case 726943463:  if (str.equals("x13.RSA3")) {} break; case 1060410941:  if (str.equals("x13.RSA2c")) {} break; case 1060411003:  if (str.equals("x13.RSA4c")) {} break; case 1060411034:  if (!str.equals("x13.RSA5c")) {
/* 240:    */         break label374;
/* 241:241 */         return TramoSeatsSpecification.RSA0;
/* 242:    */         
/* 243:243 */         return TramoSeatsSpecification.RSA1;
/* 244:    */         
/* 245:245 */         return TramoSeatsSpecification.RSA2;
/* 246:    */         
/* 247:247 */         return TramoSeatsSpecification.RSA3;
/* 248:    */         
/* 249:249 */         return TramoSeatsSpecification.RSA4;
/* 250:    */         
/* 251:251 */         return TramoSeatsSpecification.RSA5;
/* 252:    */         
/* 253:253 */         return TramoSeatsSpecification.RSAfull;
/* 254:    */         
/* 255:255 */         return X13Specification.RSAX11;
/* 256:    */         
/* 257:257 */         return X13Specification.RSA0;
/* 258:    */         
/* 259:259 */         return X13Specification.RSA1;
/* 260:    */         
/* 261:261 */         return X13Specification.RSA2;
/* 262:    */         
/* 263:263 */         return X13Specification.RSA3;
/* 264:    */         
/* 265:265 */         return X13Specification.RSA4;
/* 266:    */       } else {
/* 267:267 */         return X13Specification.RSA5; }
/* 268:    */       break; }
/* 269:269 */     label374: return null;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public void setDefaultSASpec(String spec) {
/* 273:273 */     String old = properties.defaultSASpec;
/* 274:274 */     properties.defaultSASpec = (spec != null ? spec : (String)DEFAULT_SA_SPEC.defaultValue());
/* 275:275 */     firePropertyChange("defaultSASpec", old, properties.defaultSASpec);
/* 276:    */   }
/* 277:    */   
/* 278:    */   public boolean getPopupMenuIconsVisible() {
/* 279:279 */     return properties.popupMenuIconsVisible;
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void setPopupMenuIconsVisible(boolean visible) {
/* 283:283 */     boolean old = properties.popupMenuIconsVisible;
/* 284:284 */     properties.popupMenuIconsVisible = visible;
/* 285:285 */     firePropertyChange("menuIconsVisibility", Boolean.valueOf(old), Boolean.valueOf(properties.popupMenuIconsVisible));
/* 286:    */   }
/* 287:    */   
/* 288:    */ 
/* 289:    */   public ITsAction getTsAction()
/* 290:    */   {
/* 291:291 */     return (ITsAction)find(ITsAction.class, Jdk6Functions.namedServiceName(), new String[] { properties.tsActionName, (String)TS_ACTION_NAME.defaultValue() });
/* 292:    */   }
/* 293:    */   
/* 294:    */   public List<? extends ITsAction> getTsActions() {
/* 295:295 */     return TS_ACTION_ORDERING.sortedCopy(Lookup.getDefault().lookupAll(ITsAction.class));
/* 296:    */   }
/* 297:    */   
/* 298:    */   public ColorScheme getColorScheme() {
/* 299:299 */     return (ColorScheme)find(ColorScheme.class, Jdk6Functions.colorSchemeName(), new String[] { properties.colorSchemeName, (String)COLOR_SCHEME_NAME.defaultValue() });
/* 300:    */   }
/* 301:    */   
/* 302:    */   public List<? extends ColorScheme> getColorSchemes() {
/* 303:303 */     return COLOR_SCHEME_ORDERING.sortedCopy(Lookup.getDefault().lookupAll(ColorScheme.class));
/* 304:    */   }
/* 305:    */   
/* 306:    */   public Icon getPopupMenuIcon(Icon icon) {
/* 307:307 */     return properties.popupMenuIconsVisible ? icon : null;
/* 308:    */   }
/* 309:    */   
/* 310:    */   public Icon getPopupMenuIcon(FontAwesome icon) {
/* 311:311 */     return properties.popupMenuIconsVisible ? icon.getIcon(Color.BLACK, 13.0F) : null;
/* 312:    */   }
/* 313:    */   
/* 314:    */   private static <X, Y> X find(Class<X> clazz, Function<? super X, Y> toName, Y... names) {
/* 315:315 */     Collection<? extends X> items = Lookup.getDefault().lookupAll(clazz);
/* 316:316 */     for (Y o : names) {
/* 317:317 */       Optional<? extends X> result = Iterables.tryFind(items, Predicates.compose(Predicates.equalTo(o), toName));
/* 318:318 */       if (result.isPresent()) {
/* 319:319 */         return result.get();
/* 320:    */       }
/* 321:    */     }
/* 322:322 */     return null;
/* 323:    */   }
/* 324:    */   
/* 325:    */ 
/* 326:    */ 
/* 327:    */   public Config getConfig()
/* 328:    */   {
/* 329:329 */     return properties.toConfig();
/* 330:    */   }
/* 331:    */   
/* 332:    */   public void setConfig(Config config)
/* 333:    */   {
/* 334:334 */     ConfigBean bean = new ConfigBean(config);
/* 335:335 */     setColorSchemeName(colorSchemeName);
/* 336:336 */     setDataFormat(dataFormat);
/* 337:337 */     setShowUnavailableTsProviders(showUnavailableTsProviders.booleanValue());
/* 338:338 */     setTsActionName(tsActionName);
/* 339:339 */     setPersistToolsContent(persistToolsContent);
/* 340:340 */     setPersistOpenedDataSources(persistOpenedDataSources);
/* 341:341 */     setBatchPoolSize(batchPoolSize);
/* 342:342 */     setBatchPriority(batchPriority);
/* 343:343 */     setGrowthLastYears(growthLastYears);
/* 344:344 */     setSpectralLastYears(spectralLastYears);
/* 345:345 */     setEstimationPolicyType(estimationPolicyType);
/* 346:346 */     setStabilityLength(stabilityLength);
/* 347:347 */     setDefaultSASpec(defaultSASpec);
/* 348:348 */     setPopupMenuIconsVisible(popupMenuIconsVisible);
/* 349:    */   }
/* 350:    */   
/* 351:    */   public Config editConfig(Config config)
/* 352:    */   {
/* 353:353 */     OptionsDisplayer.getDefault().open("Demetra/DemetraUI");
/* 354:354 */     return getConfig();
/* 355:    */   }
/* 356:    */   
/* 357:    */   private static class ConfigBean
/* 358:    */   {
/* 359:359 */     static final String DOMAIN = DemetraUI.class.getName();
/* 360:    */     
/* 361:    */     static final String NAME = "INSTANCE";
/* 362:    */     
/* 363:    */     static final String VERSION = "";
/* 364:    */     
/* 365:    */     String colorSchemeName;
/* 366:    */     
/* 367:    */     DataFormat dataFormat;
/* 368:    */     
/* 369:    */     Boolean showUnavailableTsProviders;
/* 370:    */     String tsActionName;
/* 371:    */     boolean persistToolsContent;
/* 372:    */     boolean persistOpenedDataSources;
/* 373:    */     
/* 374:    */     ConfigBean()
/* 375:    */     {
/* 376:376 */       colorSchemeName = ((String)DemetraUI.COLOR_SCHEME_NAME.defaultValue());
/* 377:377 */       dataFormat = ((DataFormat)DemetraUI.DATA_FORMAT.defaultValue());
/* 378:378 */       showUnavailableTsProviders = ((Boolean)DemetraUI.SHOW_UNAVAILABLE.defaultValue());
/* 379:379 */       tsActionName = ((String)DemetraUI.TS_ACTION_NAME.defaultValue());
/* 380:380 */       persistToolsContent = ((Boolean)DemetraUI.PERSIST_TOOLS_CONTENT.defaultValue()).booleanValue();
/* 381:381 */       persistOpenedDataSources = ((Boolean)DemetraUI.PERSIST_OPENED_DATASOURCES.defaultValue()).booleanValue();
/* 382:382 */       batchPoolSize = ((ThreadPoolSize)DemetraUI.BATCH_POOL_SIZE.defaultValue());
/* 383:383 */       batchPriority = ((ThreadPriority)DemetraUI.BATCH_PRIORITY.defaultValue());
/* 384:384 */       growthLastYears = ((Integer)DemetraUI.GROWTH_LAST_YEARS.defaultValue());
/* 385:385 */       spectralLastYears = ((Integer)DemetraUI.SPECTRAL_LAST_YEARS.defaultValue());
/* 386:386 */       estimationPolicyType = ((EstimationPolicyType)DemetraUI.ESTIMATION_POLICY_TYPE.defaultValue());
/* 387:387 */       stabilityLength = ((Integer)DemetraUI.STABILITY_LENGTH.defaultValue());
/* 388:388 */       defaultSASpec = ((String)DemetraUI.DEFAULT_SA_SPEC.defaultValue());
/* 389:389 */       popupMenuIconsVisible = ((Boolean)DemetraUI.POPUP_MENU_ICONS_VISIBLE.defaultValue()).booleanValue(); }
/* 390:    */     
/* 391:    */     ThreadPoolSize batchPoolSize;
/* 392:    */     
/* 393:393 */     ConfigBean(Config config) { Preconditions.checkArgument(DOMAIN.equals(config.getDomain()), "Not produced here");
/* 394:394 */       colorSchemeName = ((String)DemetraUI.COLOR_SCHEME_NAME.get(config));
/* 395:395 */       dataFormat = ((DataFormat)DemetraUI.DATA_FORMAT.get(config));
/* 396:396 */       showUnavailableTsProviders = ((Boolean)DemetraUI.SHOW_UNAVAILABLE.get(config));
/* 397:397 */       tsActionName = ((String)DemetraUI.TS_ACTION_NAME.get(config));
/* 398:398 */       persistToolsContent = ((Boolean)DemetraUI.PERSIST_TOOLS_CONTENT.get(config)).booleanValue();
/* 399:399 */       persistOpenedDataSources = ((Boolean)DemetraUI.PERSIST_OPENED_DATASOURCES.get(config)).booleanValue();
/* 400:400 */       batchPoolSize = ((ThreadPoolSize)DemetraUI.BATCH_POOL_SIZE.get(config));
/* 401:401 */       batchPriority = ((ThreadPriority)DemetraUI.BATCH_PRIORITY.get(config));
/* 402:402 */       growthLastYears = ((Integer)DemetraUI.GROWTH_LAST_YEARS.get(config));
/* 403:403 */       spectralLastYears = ((Integer)DemetraUI.SPECTRAL_LAST_YEARS.get(config));
/* 404:404 */       estimationPolicyType = ((EstimationPolicyType)DemetraUI.ESTIMATION_POLICY_TYPE.get(config));
/* 405:405 */       stabilityLength = ((Integer)DemetraUI.STABILITY_LENGTH.get(config));
/* 406:406 */       defaultSASpec = ((String)DemetraUI.DEFAULT_SA_SPEC.get(config));
/* 407:407 */       popupMenuIconsVisible = ((Boolean)DemetraUI.POPUP_MENU_ICONS_VISIBLE.get(config)).booleanValue(); }
/* 408:    */     
/* 409:    */     ThreadPriority batchPriority;
/* 410:    */     
/* 411:411 */     Config toConfig() { Config.Builder b = Config.builder(DOMAIN, "INSTANCE", "");
/* 412:412 */       DemetraUI.COLOR_SCHEME_NAME.set(b, colorSchemeName);
/* 413:413 */       DemetraUI.DATA_FORMAT.set(b, dataFormat);
/* 414:414 */       DemetraUI.SHOW_UNAVAILABLE.set(b, showUnavailableTsProviders);
/* 415:415 */       DemetraUI.TS_ACTION_NAME.set(b, tsActionName);
/* 416:416 */       DemetraUI.PERSIST_TOOLS_CONTENT.set(b, Boolean.valueOf(persistToolsContent));
/* 417:417 */       DemetraUI.PERSIST_OPENED_DATASOURCES.set(b, Boolean.valueOf(persistOpenedDataSources));
/* 418:418 */       DemetraUI.BATCH_POOL_SIZE.set(b, batchPoolSize);
/* 419:419 */       DemetraUI.BATCH_PRIORITY.set(b, batchPriority);
/* 420:420 */       DemetraUI.GROWTH_LAST_YEARS.set(b, growthLastYears);
/* 421:421 */       DemetraUI.SPECTRAL_LAST_YEARS.set(b, spectralLastYears);
/* 422:422 */       DemetraUI.ESTIMATION_POLICY_TYPE.set(b, estimationPolicyType);
/* 423:423 */       DemetraUI.STABILITY_LENGTH.set(b, stabilityLength);
/* 424:424 */       DemetraUI.DEFAULT_SA_SPEC.set(b, defaultSASpec);
/* 425:425 */       DemetraUI.POPUP_MENU_ICONS_VISIBLE.set(b, Boolean.valueOf(popupMenuIconsVisible));
/* 426:426 */       return b.build();
/* 427:    */     }
/* 428:    */     
/* 429:    */     Integer growthLastYears;
/* 430:    */     Integer spectralLastYears;
/* 431:    */     EstimationPolicyType estimationPolicyType;
/* 432:    */     Integer stabilityLength;
/* 433:    */     String defaultSASpec;
/* 434:    */     boolean popupMenuIconsVisible;
/* 435:    */   }
/* 436:    */ }
