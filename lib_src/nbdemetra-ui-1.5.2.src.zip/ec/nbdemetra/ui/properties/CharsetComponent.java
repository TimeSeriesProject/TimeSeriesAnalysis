/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.util.completion.AutoCompletionSources;
/*  4:   */ import java.nio.charset.Charset;
/*  5:   */ import java.nio.charset.StandardCharsets;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import javax.swing.text.JTextComponent;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ @Deprecated
/* 15:   */ public class CharsetComponent
/* 16:   */   extends AutoCompletedComboBox<Charset>
/* 17:   */ {
/* 18:   */   public CharsetComponent()
/* 19:   */   {
/* 20:20 */     setAutoCompletion(AutoCompletionSources.of(false, charsets()));
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Charset getValue()
/* 24:   */   {
/* 25:25 */     return Charset.forName(textComponent.getText());
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setValue(Charset value)
/* 29:   */   {
/* 30:30 */     textComponent.setText(value.name());
/* 31:   */   }
/* 32:   */   
/* 33:   */   static String[] charsets() {
/* 34:34 */     Charset[] charsets = { StandardCharsets.ISO_8859_1, StandardCharsets.US_ASCII, StandardCharsets.UTF_16, StandardCharsets.UTF_16BE, StandardCharsets.UTF_16LE, StandardCharsets.UTF_8 };
/* 35:   */     
/* 36:36 */     String[] result = new String[charsets.length + 1];
/* 37:37 */     for (int i = 0; i < result.length - 1; i++) {
/* 38:38 */       result[i] = charsets[i].name();
/* 39:   */     }
/* 40:40 */     result[(result.length - 1)] = Charset.defaultCharset().name();
/* 41:41 */     Arrays.sort(result);
/* 42:42 */     return result;
/* 43:   */   }
/* 44:   */ }
