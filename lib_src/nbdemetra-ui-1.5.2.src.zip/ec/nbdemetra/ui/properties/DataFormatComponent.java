/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Strings;
/*   4:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   5:    */ import ec.util.completion.AutoCompletionSources;
/*   6:    */ import java.awt.GridLayout;
/*   7:    */ import java.beans.PropertyChangeEvent;
/*   8:    */ import java.beans.PropertyChangeListener;
/*   9:    */ import java.text.DateFormat;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.Date;
/*  12:    */ import java.util.Locale;
/*  13:    */ import javax.swing.JLabel;
/*  14:    */ import javax.swing.JTextField;
/*  15:    */ import javax.swing.event.DocumentEvent;
/*  16:    */ import javax.swing.event.DocumentListener;
/*  17:    */ import javax.swing.text.Document;
/*  18:    */ import javax.swing.text.JTextComponent;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ @Deprecated
/*  26:    */ public class DataFormatComponent
/*  27:    */   extends AutoCompletedComboBox<DataFormat>
/*  28:    */ {
/*  29:    */   public static final String PREVIEW_PROPERTY = "preview";
/*  30:    */   final JTextComponent datePattern;
/*  31:    */   final JLabel preview;
/*  32:    */   
/*  33:    */   public DataFormatComponent()
/*  34:    */   {
/*  35: 35 */     setAutoCompletion(AutoCompletionSources.of(false, locales()));
/*  36:    */     
/*  37: 37 */     setLayout(new GridLayout(1, 3));
/*  38:    */     
/*  39: 39 */     datePattern = ((JTextField)add(new JTextField()));
/*  40: 40 */     preview = ((JLabel)add(new JLabel()));
/*  41: 41 */     preview.addPropertyChangeListener("text", new PropertyChangeListener()
/*  42:    */     {
/*  43:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  44: 44 */         firePropertyChange("preview", DataFormatComponent.access$3((String)evt.getOldValue()), DataFormatComponent.access$3((String)evt.getNewValue()));
/*  45:    */       }
/*  46:    */       
/*  47: 47 */     });
/*  48: 48 */     Previewer previewer = new Previewer();
/*  49: 49 */     textComponent.getDocument().addDocumentListener(previewer);
/*  50: 50 */     datePattern.getDocument().addDocumentListener(previewer);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public DataFormat getValue()
/*  54:    */   {
/*  55: 55 */     return DataFormat.create(textComponent.getText(), datePattern.getText(), null);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setValue(DataFormat value)
/*  59:    */   {
/*  60: 60 */     DataFormat data = value;
/*  61: 61 */     textComponent.setText(data.getLocaleString());
/*  62: 62 */     datePattern.setText(data.getDatePattern());
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static String addPrefix(String previewDate) {
/*  66: 66 */     return previewDate != null ? " » " + previewDate : " ‼ ";
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70: 70 */   private static String removePrefix(String previewDate) { return Strings.emptyToNull((previewDate != null) && (previewDate.length() >= 3) ? previewDate.substring(3) : previewDate); }
/*  71:    */   
/*  72:    */   class Previewer implements DocumentListener {
/*  73:    */     Previewer() {}
/*  74:    */     
/*  75:    */     String previewDate() {
/*  76:    */       try {
/*  77: 77 */         return getValue().newDateFormat().format(new Date());
/*  78:    */       } catch (IllegalArgumentException ex) {}
/*  79: 79 */       return null;
/*  80:    */     }
/*  81:    */     
/*  82:    */     void preview()
/*  83:    */     {
/*  84: 84 */       preview.setText(DataFormatComponent.addPrefix(previewDate()));
/*  85:    */     }
/*  86:    */     
/*  87:    */     public void removeUpdate(DocumentEvent e)
/*  88:    */     {
/*  89: 89 */       preview();
/*  90:    */     }
/*  91:    */     
/*  92:    */     public void insertUpdate(DocumentEvent e)
/*  93:    */     {
/*  94: 94 */       preview();
/*  95:    */     }
/*  96:    */     
/*  97:    */     public void changedUpdate(DocumentEvent e)
/*  98:    */     {
/*  99: 99 */       preview();
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   static String[] locales() {
/* 104:104 */     Locale[] locales = Locale.getAvailableLocales();
/* 105:105 */     String[] result = new String[locales.length];
/* 106:106 */     for (int i = 0; i < result.length; i++) {
/* 107:107 */       result[i] = locales[i].toString();
/* 108:    */     }
/* 109:109 */     Arrays.sort(result);
/* 110:110 */     return result;
/* 111:    */   }
/* 112:    */ }
