/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import java.nio.charset.Charset;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/*  6:   */ import org.openide.nodes.PropertyEditorRegistration;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ @PropertyEditorRegistration(targetType={Charset.class})
/* 16:   */ public class CharsetPropertyEditor
/* 17:   */   extends AbstractExPropertyEditor
/* 18:   */ {
/* 19:   */   public InplaceEditor createInplaceEditor()
/* 20:   */   {
/* 21:21 */     new AbstractInplaceEditor() {
/* 22:22 */       final CharsetComponent2 component = new CharsetComponent2();
/* 23:   */       
/* 24:   */       public JComponent getComponent()
/* 25:   */       {
/* 26:26 */         return component;
/* 27:   */       }
/* 28:   */       
/* 29:   */       public Object getValue()
/* 30:   */       {
/* 31:31 */         return component.getCharset();
/* 32:   */       }
/* 33:   */       
/* 34:   */       public void setValue(Object o)
/* 35:   */       {
/* 36:36 */         component.setCharset((Charset)o);
/* 37:   */       }
/* 38:   */     };
/* 39:   */   }
/* 40:   */ }
