/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.beans.PropertyChangeEvent;
/*  6:   */ import java.beans.PropertyChangeListener;
/*  7:   */ import java.beans.PropertyEditorSupport;
/*  8:   */ import org.openide.explorer.propertysheet.ExPropertyEditor;
/*  9:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/* 10:   */ import org.openide.nodes.PropertyEditorRegistration;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ @PropertyEditorRegistration(targetType={TsPeriodSelector.class})
/* 31:   */ public final class TsPeriodSelectorPropertyEditor
/* 32:   */   extends PropertyEditorSupport
/* 33:   */   implements ExPropertyEditor
/* 34:   */ {
/* 35:35 */   private PropertyEnv env = null;
/* 36:   */   
/* 37:   */   public void attachEnv(PropertyEnv env)
/* 38:   */   {
/* 39:39 */     this.env = env;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean supportsCustomEditor()
/* 43:   */   {
/* 44:44 */     return true;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public Component getCustomEditor()
/* 48:   */   {
/* 49:49 */     TsPeriodSelectorComponent result = new TsPeriodSelectorComponent();
/* 50:50 */     result.setTsPeriodSelector((TsPeriodSelector)getValue());
/* 51:51 */     applyMagicGlue(result);
/* 52:52 */     return result;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public String getAsText()
/* 56:   */   {
/* 57:57 */     TsPeriodSelector value = (TsPeriodSelector)getValue();
/* 58:58 */     return value != null ? value.toString() : "null";
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setAsText(String text)
/* 62:   */     throws IllegalArgumentException
/* 63:   */   {}
/* 64:   */   
/* 65:   */   private void applyMagicGlue(final TsPeriodSelectorComponent c)
/* 66:   */   {
/* 67:67 */     env.setState(PropertyEnv.STATE_NEEDS_VALIDATION);
/* 68:68 */     env.addPropertyChangeListener(new PropertyChangeListener()
/* 69:   */     {
/* 70:   */       public void propertyChange(PropertyChangeEvent evt) {
/* 71:71 */         if (("state".equals(evt.getPropertyName())) && (evt.getNewValue() == PropertyEnv.STATE_VALID)) {
/* 72:72 */           setValue(c.getTsPeriodSelector());
/* 73:   */         }
/* 74:   */       }
/* 75:   */     });
/* 76:   */   }
/* 77:   */ }
