/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import com.toedter.calendar.JDateChooser;
/*   4:    */ import com.toedter.components.JSpinField;
/*   5:    */ import ec.tstoolkit.timeseries.TsPeriodSelector;
/*   6:    */ import javax.swing.GroupLayout.ParallelGroup;
/*   7:    */ import javax.swing.GroupLayout.SequentialGroup;
/*   8:    */ 
/*   9:    */ public final class TsPeriodSelectorComponent extends javax.swing.JPanel
/*  10:    */ {
/*  11:    */   private JSpinField first;
/*  12:    */   private javax.swing.JLabel firstLabel;
/*  13:    */   private JDateChooser from;
/*  14:    */   private javax.swing.JLabel fromLabel;
/*  15:    */   private javax.swing.JLabel jLabel1;
/*  16:    */   private JSpinField last;
/*  17:    */   private javax.swing.JLabel lastLabel;
/*  18:    */   private JDateChooser to;
/*  19:    */   private javax.swing.JLabel toLabel;
/*  20:    */   private javax.swing.JComboBox type;
/*  21:    */   
/*  22:    */   public TsPeriodSelectorComponent()
/*  23:    */   {
/*  24: 24 */     initComponents();
/*  25:    */     
/*  26: 26 */     type.addItemListener(new java.awt.event.ItemListener()
/*  27:    */     {
/*  28:    */       public void itemStateChanged(java.awt.event.ItemEvent e) {
/*  29: 29 */         TsPeriodSelectorComponent.this.updateType((ec.tstoolkit.timeseries.PeriodSelectorType)e.getItem());
/*  30:    */       }
/*  31:    */       
/*  32: 32 */     });
/*  33: 33 */     type.setSelectedItem(ec.tstoolkit.timeseries.PeriodSelectorType.All);
/*  34:    */   }
/*  35:    */   
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */   private void initComponents()
/*  44:    */   {
/*  45: 45 */     type = new javax.swing.JComboBox();
/*  46: 46 */     from = new JDateChooser();
/*  47: 47 */     to = new JDateChooser();
/*  48: 48 */     fromLabel = new javax.swing.JLabel();
/*  49: 49 */     toLabel = new javax.swing.JLabel();
/*  50: 50 */     first = new JSpinField();
/*  51: 51 */     firstLabel = new javax.swing.JLabel();
/*  52: 52 */     lastLabel = new javax.swing.JLabel();
/*  53: 53 */     last = new JSpinField();
/*  54: 54 */     jLabel1 = new javax.swing.JLabel();
/*  55:    */     
/*  56: 56 */     type.setModel(new javax.swing.DefaultComboBoxModel(ec.tstoolkit.timeseries.PeriodSelectorType.values()));
/*  57:    */     
/*  58: 58 */     fromLabel.setLabelFor(from);
/*  59: 59 */     org.openide.awt.Mnemonics.setLocalizedText(fromLabel, org.openide.util.NbBundle.getMessage(TsPeriodSelectorComponent.class, "TsPeriodSelectorComponent.fromLabel.text"));
/*  60:    */     
/*  61: 61 */     org.openide.awt.Mnemonics.setLocalizedText(toLabel, org.openide.util.NbBundle.getMessage(TsPeriodSelectorComponent.class, "TsPeriodSelectorComponent.toLabel.text"));
/*  62:    */     
/*  63: 63 */     org.openide.awt.Mnemonics.setLocalizedText(firstLabel, org.openide.util.NbBundle.getMessage(TsPeriodSelectorComponent.class, "TsPeriodSelectorComponent.firstLabel.text"));
/*  64:    */     
/*  65: 65 */     org.openide.awt.Mnemonics.setLocalizedText(lastLabel, org.openide.util.NbBundle.getMessage(TsPeriodSelectorComponent.class, "TsPeriodSelectorComponent.lastLabel.text"));
/*  66:    */     
/*  67: 67 */     org.openide.awt.Mnemonics.setLocalizedText(jLabel1, org.openide.util.NbBundle.getMessage(TsPeriodSelectorComponent.class, "TsPeriodSelectorComponent.jLabel1.text"));
/*  68:    */     
/*  69: 69 */     javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
/*  70: 70 */     setLayout(layout);
/*  71: 71 */     layout.setHorizontalGroup(
/*  72: 72 */       layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/*  73: 73 */       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/*  74: 74 */       .addContainerGap()
/*  75: 75 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
/*  76: 76 */       .addGroup(layout.createSequentialGroup()
/*  77: 77 */       .addComponent(jLabel1)
/*  78: 78 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
/*  79: 79 */       .addComponent(type, 0, -1, 32767))
/*  80: 80 */       .addGroup(layout.createSequentialGroup()
/*  81: 81 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/*  82: 82 */       .addComponent(fromLabel)
/*  83: 83 */       .addComponent(firstLabel))
/*  84: 84 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
/*  85: 85 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
/*  86: 86 */       .addComponent(from, -1, 130, 32767)
/*  87: 87 */       .addComponent(first, -1, -1, 32767))
/*  88: 88 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, 32767)
/*  89: 89 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/*  90: 90 */       .addComponent(toLabel, javax.swing.GroupLayout.Alignment.TRAILING)
/*  91: 91 */       .addComponent(lastLabel, javax.swing.GroupLayout.Alignment.TRAILING))
/*  92: 92 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
/*  93: 93 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
/*  94: 94 */       .addComponent(last, -1, -1, 32767)
/*  95: 95 */       .addComponent(to, -1, 130, 32767))))
/*  96: 96 */       .addContainerGap()));
/*  97:    */     
/*  98: 98 */     layout.setVerticalGroup(
/*  99: 99 */       layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/* 100:100 */       .addGroup(layout.createSequentialGroup()
/* 101:101 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/* 102:102 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
/* 103:103 */       .addGroup(layout.createSequentialGroup()
/* 104:104 */       .addGap(50, 50, 50)
/* 105:105 */       .addComponent(fromLabel))
/* 106:106 */       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 107:107 */       .addContainerGap()
/* 108:108 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
/* 109:109 */       .addComponent(type, -2, -1, -2)
/* 110:110 */       .addComponent(jLabel1))
/* 111:111 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 112:112 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/* 113:113 */       .addComponent(toLabel, javax.swing.GroupLayout.Alignment.TRAILING)
/* 114:114 */       .addComponent(to, javax.swing.GroupLayout.Alignment.TRAILING, -2, -1, -2))))
/* 115:115 */       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 116:116 */       .addGap(33, 33, 33)
/* 117:117 */       .addComponent(from, -2, -1, -2)))
/* 118:118 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
/* 119:119 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
/* 120:120 */       .addComponent(first, -2, -1, -2)
/* 121:121 */       .addComponent(firstLabel)
/* 122:122 */       .addComponent(lastLabel)
/* 123:123 */       .addComponent(last, -2, -1, -2))
/* 124:124 */       .addContainerGap(-1, 32767)));
/* 125:    */   }
/* 126:    */   
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */   private void updateType(ec.tstoolkit.timeseries.PeriodSelectorType val)
/* 142:    */   {
/* 143:143 */     switch (val) {
/* 144:    */     case All: 
/* 145:    */     case Between: 
/* 146:146 */       from.setEnabled(false);
/* 147:147 */       to.setEnabled(false);
/* 148:148 */       first.setEnabled(false);
/* 149:149 */       last.setEnabled(false);
/* 150:150 */       break;
/* 151:    */     case Excluding: 
/* 152:152 */       from.setEnabled(true);
/* 153:153 */       to.setEnabled(false);
/* 154:154 */       first.setEnabled(false);
/* 155:155 */       last.setEnabled(false);
/* 156:156 */       break;
/* 157:    */     case First: 
/* 158:158 */       from.setEnabled(false);
/* 159:159 */       to.setEnabled(true);
/* 160:160 */       first.setEnabled(false);
/* 161:161 */       last.setEnabled(false);
/* 162:162 */       break;
/* 163:    */     case From: 
/* 164:164 */       from.setEnabled(true);
/* 165:165 */       to.setEnabled(true);
/* 166:166 */       first.setEnabled(false);
/* 167:167 */       last.setEnabled(false);
/* 168:168 */       break;
/* 169:    */     case Last: 
/* 170:170 */       from.setEnabled(false);
/* 171:171 */       to.setEnabled(false);
/* 172:172 */       first.setEnabled(false);
/* 173:173 */       last.setEnabled(true);
/* 174:174 */       break;
/* 175:    */     case None: 
/* 176:176 */       from.setEnabled(false);
/* 177:177 */       to.setEnabled(false);
/* 178:178 */       first.setEnabled(true);
/* 179:179 */       last.setEnabled(false);
/* 180:180 */       break;
/* 181:    */     case To: 
/* 182:182 */       from.setEnabled(false);
/* 183:183 */       to.setEnabled(false);
/* 184:184 */       first.setEnabled(true);
/* 185:185 */       last.setEnabled(true);
/* 186:    */     }
/* 187:    */     
/* 188:188 */     fromLabel.setEnabled(from.isEnabled());
/* 189:189 */     toLabel.setEnabled(to.isEnabled());
/* 190:190 */     firstLabel.setEnabled(first.isEnabled());
/* 191:191 */     lastLabel.setEnabled(last.isEnabled());
/* 192:    */   }
/* 193:    */   
/* 194:    */   public TsPeriodSelector getTsPeriodSelector() {
/* 195:195 */     TsPeriodSelector result = new TsPeriodSelector();
/* 196:196 */     switch ((ec.tstoolkit.timeseries.PeriodSelectorType)type.getSelectedItem()) {
/* 197:    */     case Between: 
/* 198:198 */       result.all();
/* 199:199 */       break;
/* 200:    */     case All: 
/* 201:201 */       result.none();
/* 202:202 */       break;
/* 203:    */     case Excluding: 
/* 204:204 */       result.from(from.getDate() != null ? new ec.tstoolkit.timeseries.Day(from.getDate()) : TsPeriodSelector.DEF_BEG);
/* 205:205 */       break;
/* 206:    */     case First: 
/* 207:207 */       result.to(to.getDate() != null ? new ec.tstoolkit.timeseries.Day(to.getDate()) : TsPeriodSelector.DEF_END);
/* 208:208 */       break;
/* 209:    */     case From: 
/* 210:210 */       ec.tstoolkit.timeseries.Day d0 = from.getDate() != null ? new ec.tstoolkit.timeseries.Day(from.getDate()) : TsPeriodSelector.DEF_BEG;
/* 211:211 */       ec.tstoolkit.timeseries.Day d1 = to.getDate() != null ? new ec.tstoolkit.timeseries.Day(to.getDate()) : TsPeriodSelector.DEF_END;
/* 212:212 */       result.between(d0, d1);
/* 213:213 */       break;
/* 214:    */     case Last: 
/* 215:215 */       result.last(last.getValue());
/* 216:216 */       break;
/* 217:    */     case None: 
/* 218:218 */       result.first(first.getValue());
/* 219:219 */       break;
/* 220:    */     case To: 
/* 221:221 */       result.excluding(first.getValue(), last.getValue());
/* 222:    */     }
/* 223:    */     
/* 224:224 */     return result;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void setTsPeriodSelector(TsPeriodSelector value) {
/* 228:228 */     type.setSelectedItem(value.getType());
/* 229:229 */     switch (value.getType()) {
/* 230:    */     case All: 
/* 231:    */     case Between: 
/* 232:232 */       from.setDate(null);
/* 233:233 */       to.setDate(null);
/* 234:234 */       first.setValue(0);
/* 235:235 */       last.setValue(0);
/* 236:236 */       break;
/* 237:    */     case Excluding: 
/* 238:238 */       from.setDate(value.getD0().getTime());
/* 239:239 */       to.setDate(null);
/* 240:240 */       first.setValue(0);
/* 241:241 */       last.setValue(0);
/* 242:242 */       break;
/* 243:    */     case First: 
/* 244:244 */       from.setDate(null);
/* 245:245 */       to.setDate(value.getD1().getTime());
/* 246:246 */       first.setValue(0);
/* 247:247 */       last.setValue(0);
/* 248:248 */       break;
/* 249:    */     case From: 
/* 250:250 */       from.setDate(value.getD0().getTime());
/* 251:251 */       to.setDate(value.getD1().getTime());
/* 252:252 */       first.setValue(0);last.setValue(0);
/* 253:    */       
/* 254:254 */       break;
/* 255:    */     case Last: 
/* 256:256 */       from.setDate(null);
/* 257:257 */       to.setDate(null);
/* 258:258 */       first.setValue(0);
/* 259:259 */       last.setValue(value.getN1());
/* 260:260 */       break;
/* 261:    */     case None: 
/* 262:262 */       from.setDate(null);
/* 263:263 */       to.setDate(null);
/* 264:264 */       first.setValue(value.getN0());
/* 265:265 */       last.setValue(0);
/* 266:266 */       break;
/* 267:    */     case To: 
/* 268:268 */       from.setDate(null);
/* 269:269 */       to.setDate(null);
/* 270:270 */       first.setValue(value.getN0());
/* 271:271 */       last.setValue(value.getN1());
/* 272:    */     }
/* 273:    */   }
/* 274:    */ }
