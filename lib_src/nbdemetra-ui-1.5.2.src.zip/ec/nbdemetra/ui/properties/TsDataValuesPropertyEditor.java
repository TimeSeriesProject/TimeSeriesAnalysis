/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.DemetraUI;
/*  4:   */ import ec.tss.tsproviders.utils.DataFormat;
/*  5:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  6:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  7:   */ import ec.ui.chart.TsCharts;
/*  8:   */ import ec.util.chart.swing.Charts;
/*  9:   */ import java.awt.Color;
/* 10:   */ import java.awt.Graphics;
/* 11:   */ import java.awt.Graphics2D;
/* 12:   */ import java.awt.Rectangle;
/* 13:   */ import java.beans.PropertyEditorSupport;
/* 14:   */ import javax.swing.BorderFactory;
/* 15:   */ import javax.swing.JLabel;
/* 16:   */ import javax.swing.JTextField;
/* 17:   */ import org.jfree.chart.JFreeChart;
/* 18:   */ import org.jfree.chart.plot.XYPlot;
/* 19:   */ import org.jfree.chart.renderer.xy.XYItemRenderer;
/* 20:   */ import org.jfree.ui.RectangleInsets;
/* 21:   */ import org.openide.nodes.PropertyEditorRegistration;
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ @PropertyEditorRegistration(targetType={TsData.class})
/* 28:   */ public class TsDataValuesPropertyEditor
/* 29:   */   extends PropertyEditorSupport
/* 30:   */ {
/* 31:31 */   static final RectangleInsets PADDING = new RectangleInsets(2.0D, 2.0D, 2.0D, 2.0D);
/* 32:   */   final JFreeChart sparkLinePainter;
/* 33:   */   final JLabel singleValuePainter;
/* 34:   */   
/* 35:   */   public TsDataValuesPropertyEditor() {
/* 36:36 */     Color disabledTextColor = new JTextField().getDisabledTextColor();
/* 37:37 */     sparkLinePainter = Charts.createSparkLineChart(null);
/* 38:38 */     sparkLinePainter.getXYPlot().getRenderer().setBasePaint(disabledTextColor);
/* 39:39 */     sparkLinePainter.setPadding(PADDING);
/* 40:40 */     singleValuePainter = new JLabel();
/* 41:41 */     singleValuePainter.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
/* 42:42 */     singleValuePainter.setForeground(disabledTextColor);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public boolean isPaintable()
/* 46:   */   {
/* 47:47 */     return true;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void paintValue(Graphics gfx, Rectangle box)
/* 51:   */   {
/* 52:52 */     TsData data = (TsData)getValue();
/* 53:53 */     if (data.getObsCount() > 1) {
/* 54:54 */       sparkLinePainter.getXYPlot().setDataset(TsCharts.newSparklineDataset(data));
/* 55:55 */       sparkLinePainter.draw((Graphics2D)gfx, box);
/* 56:   */     } else {
/* 57:57 */       DataFormat dataFormat = DemetraUI.getDefault().getDataFormat();
/* 58:58 */       String str = "Single: " + dataFormat.numberFormatter().formatAsString(Double.valueOf(data.get(0)));
/* 59:59 */       singleValuePainter.setText(str);
/* 60:60 */       singleValuePainter.setBounds(box);
/* 61:61 */       singleValuePainter.paint(gfx);
/* 62:   */     }
/* 63:   */   }
/* 64:   */ }
