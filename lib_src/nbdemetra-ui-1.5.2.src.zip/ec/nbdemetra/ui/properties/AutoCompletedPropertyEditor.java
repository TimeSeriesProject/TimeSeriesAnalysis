/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.util.completion.AutoCompletionSource;
/*  4:   */ import java.beans.PropertyEditor;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import javax.swing.text.JTextComponent;
/*  7:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/*  8:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ @Deprecated
/* 17:   */ public class AutoCompletedPropertyEditor
/* 18:   */   extends AbstractExPropertyEditor
/* 19:   */ {
/* 20:   */   public static final String VALUES_ATTRIBUTE = "source";
/* 21:   */   public static final String SEPARATOR_ATTRIBUTE = "separator";
/* 22:   */   
/* 23:   */   protected InplaceEditor createInplaceEditor()
/* 24:   */   {
/* 25:25 */     new AbstractInplaceEditor() {
/* 26:26 */       final AutoCompletedComboBox<String> component = new AutoCompletedComboBox()
/* 27:   */       {
/* 28:   */         public String getValue() {
/* 29:29 */           return textComponent.getText();
/* 30:   */         }
/* 31:   */         
/* 32:   */         public void setValue(String value)
/* 33:   */         {
/* 34:34 */           textComponent.setText(value);
/* 35:   */         }
/* 36:   */       };
/* 37:   */       
/* 38:   */       public void connect(PropertyEditor propertyEditor, PropertyEnv env)
/* 39:   */       {
/* 40:40 */         component.setAutoCompletion((AutoCompletionSource)getAttribute(env, "source", AutoCompletionSource.class, null));
/* 41:41 */         component.setSeparator((String)getAttribute(env, "separator", String.class, null));
/* 42:42 */         super.connect(propertyEditor, env);
/* 43:   */       }
/* 44:   */       
/* 45:   */       public JComponent getComponent()
/* 46:   */       {
/* 47:47 */         return component;
/* 48:   */       }
/* 49:   */       
/* 50:   */       public Object getValue()
/* 51:   */       {
/* 52:52 */         return component.getValue();
/* 53:   */       }
/* 54:   */       
/* 55:   */       public void setValue(Object o)
/* 56:   */       {
/* 57:57 */         component.setValue((String)o);
/* 58:   */       }
/* 59:   */     };
/* 60:   */   }
/* 61:   */ }
