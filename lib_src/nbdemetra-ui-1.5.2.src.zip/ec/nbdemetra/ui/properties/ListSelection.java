/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.util.various.swing.FontAwesome;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.awt.event.MouseAdapter;
/*   9:    */ import java.awt.event.MouseEvent;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.List;
/*  13:    */ import javax.swing.BoxLayout;
/*  14:    */ import javax.swing.DefaultListModel;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JList;
/*  17:    */ import javax.swing.JPanel;
/*  18:    */ import javax.swing.JScrollPane;
/*  19:    */ import javax.swing.JToolBar;
/*  20:    */ import javax.swing.ListModel;
/*  21:    */ import javax.swing.event.ListSelectionEvent;
/*  22:    */ import javax.swing.event.ListSelectionListener;
/*  23:    */ import org.openide.awt.MouseUtils;
/*  24:    */ import org.openide.util.ImageUtilities;
/*  25:    */ import org.openide.util.NbBundle;
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ public class ListSelection<T>
/*  30:    */   extends JPanel
/*  31:    */ {
/*  32:    */   public static final String SEL_CHANGED = "SelectionChanged";
/*  33: 33 */   private final List<T> im = new ArrayList();
/*  34: 34 */   private final List<T> sm = new ArrayList();
/*  35:    */   private JButton addButton;
/*  36:    */   private JList inputList;
/*  37:    */   private JPanel jPanel1;
/*  38:    */   private JScrollPane jScrollPane1;
/*  39:    */   
/*  40: 40 */   public ListSelection() { initComponents();
/*  41: 41 */     withIcon(addButton, FontAwesome.FA_ARROW_CIRCLE_RIGHT);
/*  42: 42 */     withIcon(removeButton, FontAwesome.FA_ARROW_CIRCLE_LEFT);
/*  43:    */   }
/*  44:    */   
/*  45:    */   private static void withIcon(JButton button, FontAwesome fontAwesome) {
/*  46: 46 */     button.setText("");
/*  47: 47 */     button.setIcon(fontAwesome.getIcon(button.getForeground(), 16.0F));
/*  48: 48 */     button.setDisabledIcon(ImageUtilities.createDisabledIcon(button.getIcon()));
/*  49:    */   }
/*  50:    */   
/*  51:    */   private ListModel convert(List<T> list) {
/*  52: 52 */     DefaultListModel model = new DefaultListModel();
/*  53: 53 */     for (T t : list) {
/*  54: 54 */       model.addElement(t);
/*  55:    */     }
/*  56: 56 */     return model;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public List<T> getSelection() {
/*  60: 60 */     return Collections.unmodifiableList(sm);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void set(List<T> input) {
/*  64: 64 */     set(input, Collections.emptyList());
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void set(List<T> input, List<T> sel) {
/*  68: 68 */     im.clear();
/*  69: 69 */     sm.clear();
/*  70: 70 */     im.addAll(input);
/*  71: 71 */     sm.addAll(sel);
/*  72: 72 */     inputList.setModel(convert(im));
/*  73: 73 */     selectionList.setModel(convert(sm));
/*  74:    */   }
/*  75:    */   
/*  76:    */ 
/*  77:    */   private JScrollPane jScrollPane2;
/*  78:    */   
/*  79:    */   private JToolBar jToolBar1;
/*  80:    */   
/*  81:    */   private JButton removeButton;
/*  82:    */   private JList selectionList;
/*  83:    */   private void initComponents()
/*  84:    */   {
/*  85: 85 */     jScrollPane1 = NbComponents.newJScrollPane();
/*  86: 86 */     inputList = new JList();
/*  87: 87 */     jPanel1 = new JPanel();
/*  88: 88 */     jToolBar1 = new JToolBar();
/*  89: 89 */     addButton = new JButton();
/*  90: 90 */     removeButton = new JButton();
/*  91: 91 */     jScrollPane2 = NbComponents.newJScrollPane();
/*  92: 92 */     selectionList = new JList();
/*  93:    */     
/*  94: 94 */     setLayout(new BoxLayout(this, 2));
/*  95:    */     
/*  96: 96 */     jScrollPane1.setPreferredSize(new Dimension(200, 138));
/*  97:    */     
/*  98: 98 */     inputList.setMaximumSize(new Dimension(80, 120));
/*  99: 99 */     inputList.setMinimumSize(new Dimension(80, 120));
/* 100:100 */     inputList.addMouseListener(new MouseAdapter() {
/* 101:    */       public void mouseClicked(MouseEvent evt) {
/* 102:102 */         ListSelection.this.inputListMouseClicked(evt);
/* 103:    */       }
/* 104:104 */     });
/* 105:105 */     inputList.addListSelectionListener(new ListSelectionListener() {
/* 106:    */       public void valueChanged(ListSelectionEvent evt) {
/* 107:107 */         ListSelection.this.inputListValueChanged(evt);
/* 108:    */       }
/* 109:109 */     });
/* 110:110 */     jScrollPane1.setViewportView(inputList);
/* 111:    */     
/* 112:112 */     add(jScrollPane1);
/* 113:    */     
/* 114:114 */     jPanel1.setMaximumSize(new Dimension(50, 32767));
/* 115:115 */     jPanel1.setMinimumSize(new Dimension(50, 33));
/* 116:116 */     jPanel1.setPreferredSize(new Dimension(50, 300));
/* 117:    */     
/* 118:118 */     jToolBar1.setFloatable(false);
/* 119:119 */     jToolBar1.setOrientation(1);
/* 120:120 */     jToolBar1.setRollover(true);
/* 121:    */     
/* 122:122 */     addButton.setText(NbBundle.getMessage(ListSelection.class, "ListSelection.addButton.text"));
/* 123:123 */     addButton.setEnabled(false);
/* 124:124 */     addButton.setFocusable(false);
/* 125:125 */     addButton.setHorizontalTextPosition(0);
/* 126:126 */     addButton.setVerticalTextPosition(3);
/* 127:127 */     addButton.addActionListener(new ActionListener() {
/* 128:    */       public void actionPerformed(ActionEvent evt) {
/* 129:129 */         ListSelection.this.addButtonActionPerformed(evt);
/* 130:    */       }
/* 131:131 */     });
/* 132:132 */     jToolBar1.add(addButton);
/* 133:    */     
/* 134:134 */     removeButton.setText(NbBundle.getMessage(ListSelection.class, "ListSelection.removeButton.text"));
/* 135:135 */     removeButton.setEnabled(false);
/* 136:136 */     removeButton.setFocusable(false);
/* 137:137 */     removeButton.setHorizontalTextPosition(0);
/* 138:138 */     removeButton.setVerticalTextPosition(3);
/* 139:139 */     removeButton.addActionListener(new ActionListener() {
/* 140:    */       public void actionPerformed(ActionEvent evt) {
/* 141:141 */         ListSelection.this.removeButtonActionPerformed(evt);
/* 142:    */       }
/* 143:143 */     });
/* 144:144 */     jToolBar1.add(removeButton);
/* 145:    */     
/* 146:146 */     jPanel1.add(jToolBar1);
/* 147:    */     
/* 148:148 */     add(jPanel1);
/* 149:    */     
/* 150:150 */     jScrollPane2.setPreferredSize(new Dimension(200, 138));
/* 151:    */     
/* 152:152 */     selectionList.setMinimumSize(new Dimension(80, 1203));
/* 153:153 */     selectionList.addMouseListener(new MouseAdapter() {
/* 154:    */       public void mouseClicked(MouseEvent evt) {
/* 155:155 */         ListSelection.this.selectionListMouseClicked(evt);
/* 156:    */       }
/* 157:157 */     });
/* 158:158 */     selectionList.addListSelectionListener(new ListSelectionListener() {
/* 159:    */       public void valueChanged(ListSelectionEvent evt) {
/* 160:160 */         ListSelection.this.selectionListValueChanged(evt);
/* 161:    */       }
/* 162:162 */     });
/* 163:163 */     jScrollPane2.setViewportView(selectionList);
/* 164:    */     
/* 165:165 */     add(jScrollPane2);
/* 166:    */   }
/* 167:    */   
/* 168:    */   private void addButtonActionPerformed(ActionEvent evt) {
/* 169:169 */     List isel = inputList.getSelectedValuesList();
/* 170:170 */     im.removeAll(isel);
/* 171:171 */     sm.addAll(isel);
/* 172:172 */     inputList.setModel(convert(im));
/* 173:173 */     selectionList.setModel(convert(sm));
/* 174:174 */     validate();
/* 175:175 */     firePropertyChange("SelectionChanged", null, getSelection());
/* 176:    */   }
/* 177:    */   
/* 178:    */   private void removeButtonActionPerformed(ActionEvent evt) {
/* 179:179 */     List ssel = selectionList.getSelectedValuesList();
/* 180:180 */     im.addAll(ssel);
/* 181:181 */     sm.removeAll(ssel);
/* 182:182 */     inputList.setModel(convert(im));
/* 183:183 */     selectionList.setModel(convert(sm));
/* 184:184 */     validate();
/* 185:185 */     firePropertyChange("SelectionChanged", null, getSelection());
/* 186:    */   }
/* 187:    */   
/* 188:    */   private void inputListValueChanged(ListSelectionEvent evt) {
/* 189:189 */     addButton.setEnabled(!inputList.isSelectionEmpty());
/* 190:    */   }
/* 191:    */   
/* 192:    */   private void selectionListValueChanged(ListSelectionEvent evt) {
/* 193:193 */     removeButton.setEnabled(!selectionList.isSelectionEmpty());
/* 194:    */   }
/* 195:    */   
/* 196:    */   private void inputListMouseClicked(MouseEvent evt) {
/* 197:197 */     if (MouseUtils.isDoubleClick(evt)) {
/* 198:198 */       addButtonActionPerformed(null);
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */   private void selectionListMouseClicked(MouseEvent evt) {
/* 203:203 */     if (MouseUtils.isDoubleClick(evt)) {
/* 204:204 */       removeButtonActionPerformed(null);
/* 205:    */     }
/* 206:    */   }
/* 207:    */ }
