/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.completion.JAutoCompletionService;
/*  5:   */ import ec.util.completion.AutoCompletionSource;
/*  6:   */ import ec.util.completion.swing.JAutoCompletion;
/*  7:   */ import ec.util.various.swing.TextPrompt;
/*  8:   */ import java.beans.PropertyEditor;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.JList;
/* 11:   */ import javax.swing.JTextField;
/* 12:   */ import javax.swing.ListCellRenderer;
/* 13:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/* 14:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class AutoCompletedPropertyEditor3
/* 23:   */   extends AbstractExPropertyEditor
/* 24:   */ {
/* 25:   */   public static final String SERVICE_PATH_ATTRIBUTE = "servicePath";
/* 26:   */   public static final String AUTO_FOCUS_ATTRIBUTE = "autoFocus";
/* 27:   */   public static final String DELAY_ATTRIBUTE = "delay";
/* 28:   */   public static final String MIN_LENGTH_ATTRIBUTE = "minLength";
/* 29:   */   public static final String SEPARATOR_ATTRIBUTE = "separator";
/* 30:   */   public static final String SOURCE_ATTRIBUTE = "source";
/* 31:   */   public static final String CELL_RENDERER_ATTRIBUTE = "cellRenderer";
/* 32:   */   public static final String PROMPT_TEXT_ATTRIBUTE = "promptText";
/* 33:   */   
/* 34:   */   protected InplaceEditor createInplaceEditor()
/* 35:   */   {
/* 36:36 */     new AbstractInplaceEditor()
/* 37:   */     {
/* 38:   */       JTextField component;
/* 39:   */       
/* 40:   */       public void connect(PropertyEditor propertyEditor, PropertyEnv env) {
/* 41:41 */         component = new JTextField();
/* 42:42 */         Optional<String> servicePath = getAttribute(env, "servicePath", String.class);
/* 43:43 */         JAutoCompletion completion = servicePath.isPresent() ? JAutoCompletionService.forPathBind((String)servicePath.get(), component) : new JAutoCompletion(component);
/* 44:44 */         Optional<Boolean> autoFocus = getAttribute(env, "autoFocus", Boolean.class);
/* 45:45 */         if (autoFocus.isPresent()) {
/* 46:46 */           completion.setAutoFocus(((Boolean)autoFocus.get()).booleanValue());
/* 47:   */         }
/* 48:48 */         Optional<Integer> delay = getAttribute(env, "delay", Integer.class);
/* 49:49 */         if (delay.isPresent()) {
/* 50:50 */           completion.setDelay(((Integer)delay.get()).intValue());
/* 51:   */         }
/* 52:52 */         Optional<Integer> minLength = getAttribute(env, "minLength", Integer.class);
/* 53:53 */         if (minLength.isPresent()) {
/* 54:54 */           completion.setMinLength(((Integer)minLength.get()).intValue());
/* 55:   */         }
/* 56:56 */         Optional<String> separator = getAttribute(env, "separator", String.class);
/* 57:57 */         if (separator.isPresent()) {
/* 58:58 */           completion.setSeparator((String)separator.get());
/* 59:   */         }
/* 60:60 */         Optional<AutoCompletionSource> source = getAttribute(env, "source", AutoCompletionSource.class);
/* 61:61 */         if (source.isPresent()) {
/* 62:62 */           completion.setSource((AutoCompletionSource)source.get());
/* 63:   */         }
/* 64:64 */         Optional<ListCellRenderer> cellRenderer = getAttribute(env, "cellRenderer", ListCellRenderer.class);
/* 65:65 */         if (cellRenderer.isPresent()) {
/* 66:66 */           completion.getList().setCellRenderer((ListCellRenderer)cellRenderer.get());
/* 67:   */         }
/* 68:68 */         Optional<String> promptText = getAttribute(env, "promptText", String.class);
/* 69:69 */         if (promptText.isPresent()) {
/* 70:70 */           new TextPrompt((String)promptText.get(), component).setEnabled(false);
/* 71:   */         }
/* 72:72 */         super.connect(propertyEditor, env);
/* 73:   */       }
/* 74:   */       
/* 75:   */       public JComponent getComponent()
/* 76:   */       {
/* 77:77 */         return component;
/* 78:   */       }
/* 79:   */       
/* 80:   */       public Object getValue()
/* 81:   */       {
/* 82:82 */         return component.getText();
/* 83:   */       }
/* 84:   */       
/* 85:   */       public void setValue(Object o)
/* 86:   */       {
/* 87:87 */         component.setText((String)o);
/* 88:   */       }
/* 89:   */     };
/* 90:   */   }
/* 91:   */ }
