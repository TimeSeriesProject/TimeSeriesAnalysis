package ec.nbdemetra.ui.properties;

import java.beans.IntrospectionException;

public abstract interface IBeanEditor
{
  public abstract boolean editBean(Object paramObject)
    throws IntrospectionException;
}
