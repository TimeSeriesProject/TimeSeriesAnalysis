/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ 
/*  6:   */ public class UserVariables
/*  7:   */ {
/*  8:   */   private final String[] vars_;
/*  9:   */   
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */   public UserVariables(String... name)
/* 14:   */   {
/* 15:15 */     if (name != null) {
/* 16:16 */       vars_ = name;
/* 17:   */     }
/* 18:   */     else {
/* 19:19 */       vars_ = new String[0];
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String[] getNames() {
/* 24:24 */     return vars_;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String toString()
/* 28:   */   {
/* 29:29 */     return vars_.length + " vars";
/* 30:   */   }
/* 31:   */ }
