/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.propertysheet.PropertyRendererFactory;
/*  4:   */ import com.l2fprod.common.propertysheet.PropertyRendererRegistry;
/*  5:   */ import ec.satoolkit.x11.SeasonalFilterOption;
/*  6:   */ import ec.tstoolkit.Parameter;
/*  7:   */ import ec.tstoolkit.modelling.TsVariableDescriptor;
/*  8:   */ import ec.tstoolkit.timeseries.regression.InterventionVariable;
/*  9:   */ import ec.tstoolkit.timeseries.regression.OutlierDefinition;
/* 10:   */ import ec.tstoolkit.timeseries.regression.Ramp;
/* 11:   */ import ec.tstoolkit.timeseries.regression.Sequence;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public enum CustomPropertyRendererFactory
/* 19:   */ {
/* 20:20 */   INSTANCE;
/* 21:   */   
/* 22:   */   private PropertyRendererRegistry registry_;
/* 23:   */   
/* 24:24 */   private CustomPropertyRendererFactory() { registry_ = new PropertyRendererRegistry();
/* 25:25 */     registry_.registerRenderer([Lec.tstoolkit.Parameter.class, new ArrayRenderer());
/* 26:26 */     registry_.registerRenderer([Lec.tstoolkit.timeseries.regression.Ramp.class, new ArrayRenderer());
/* 27:27 */     registry_.registerRenderer([Lec.tstoolkit.modelling.TsVariableDescriptor.class, new ArrayRenderer());
/* 28:28 */     registry_.registerRenderer([Lec.tstoolkit.timeseries.regression.InterventionVariable.class, new ArrayRenderer());
/* 29:29 */     registry_.registerRenderer([Lec.tstoolkit.timeseries.regression.Sequence.class, new ArrayRenderer());
/* 30:30 */     registry_.registerRenderer([Lec.tstoolkit.timeseries.regression.OutlierDefinition.class, new ArrayRenderer());
/* 31:31 */     registry_.registerRenderer([Lec.satoolkit.x11.SeasonalFilterOption.class, new ArrayRenderer());
/* 32:   */   }
/* 33:   */   
/* 34:   */   public PropertyRendererFactory getRegistry() {
/* 35:35 */     return registry_;
/* 36:   */   }
/* 37:   */ }
