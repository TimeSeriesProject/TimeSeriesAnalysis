/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ import ec.tstoolkit.timeseries.regression.InterventionVariable;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.util.List;
/*  7:   */ import javax.swing.AbstractAction;
/*  8:   */ import javax.swing.JButton;
/*  9:   */ import javax.swing.SwingUtilities;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class InterventionVariablesEditor
/* 14:   */   extends AbstractPropertyEditor
/* 15:   */ {
/* 16:   */   private InterventionVariable[] vars_;
/* 17:   */   
/* 18:   */   public InterventionVariablesEditor()
/* 19:   */   {
/* 20:20 */     editor = new JButton(new AbstractAction("...")
/* 21:   */     {
/* 22:   */       public void actionPerformed(ActionEvent e)
/* 23:   */       {
/* 24:24 */         ArrayEditorDialog<InterventionVariableDescriptor> dialog = new ArrayEditorDialog(SwingUtilities.getWindowAncestor(editor), 
/* 25:25 */           vars_ != null ? InterventionVariablesEditor.this.getDescriptors() : new InterventionVariableDescriptor[0], InterventionVariableDescriptor.class);
/* 26:26 */         dialog.setTitle("Intervention variables");
/* 27:27 */         dialog.setVisible(true);
/* 28:28 */         if (dialog.isDirty()) {
/* 29:29 */           InterventionVariablesEditor.this.setDescriptors(dialog.getElements());
/* 30:   */         }
/* 31:   */       }
/* 32:   */     });
/* 33:   */   }
/* 34:   */   
/* 35:   */   private InterventionVariableDescriptor[] getDescriptors() {
/* 36:36 */     InterventionVariableDescriptor[] descs = new InterventionVariableDescriptor[vars_.length];
/* 37:37 */     for (int i = 0; i < descs.length; i++) {
/* 38:38 */       descs[i] = new InterventionVariableDescriptor(vars_[i]);
/* 39:   */     }
/* 40:40 */     return descs;
/* 41:   */   }
/* 42:   */   
/* 43:   */   private void setDescriptors(List<InterventionVariableDescriptor> elements) {
/* 44:44 */     InterventionVariable[] old = vars_;
/* 45:45 */     vars_ = new InterventionVariable[elements.size()];
/* 46:46 */     for (int i = 0; i < vars_.length; i++) {
/* 47:47 */       vars_[i] = ((InterventionVariableDescriptor)elements.get(i)).getCore();
/* 48:   */     }
/* 49:49 */     firePropertyChange(old, vars_);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public Object getValue()
/* 53:   */   {
/* 54:54 */     return vars_;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setValue(Object value)
/* 58:   */   {
/* 59:59 */     if ((value != null) && ((value instanceof InterventionVariable[]))) {
/* 60:60 */       InterventionVariable[] val = (InterventionVariable[])value;
/* 61:61 */       vars_ = new InterventionVariable[val.length];
/* 62:62 */       for (int i = 0; i < val.length; i++) {
/* 63:63 */         vars_[i] = val[i].clone();
/* 64:   */       }
/* 65:   */     }
/* 66:   */     else {
/* 67:67 */       vars_ = new InterventionVariable[0];
/* 68:   */     }
/* 69:   */   }
/* 70:   */ }
