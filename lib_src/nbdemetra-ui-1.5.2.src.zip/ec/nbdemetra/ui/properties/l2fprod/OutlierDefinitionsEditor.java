/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.timeseries.regression.OutlierDefinition;
/*   4:    */ import ec.tstoolkit.timeseries.regression.OutlierType;
/*   5:    */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*   6:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*   7:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ItemEvent;
/*  10:    */ import java.awt.event.WindowEvent;
/*  11:    */ import java.util.Arrays;
/*  12:    */ import java.util.Collections;
/*  13:    */ import java.util.GregorianCalendar;
/*  14:    */ import javax.swing.AbstractAction;
/*  15:    */ import javax.swing.BorderFactory;
/*  16:    */ import javax.swing.Box;
/*  17:    */ import javax.swing.BoxLayout;
/*  18:    */ import javax.swing.JButton;
/*  19:    */ import javax.swing.JComboBox;
/*  20:    */ import javax.swing.JDialog;
/*  21:    */ import javax.swing.JLabel;
/*  22:    */ import javax.swing.JPanel;
/*  23:    */ import javax.swing.JSpinner;
/*  24:    */ import javax.swing.JSpinner.NumberEditor;
/*  25:    */ import javax.swing.JTable;
/*  26:    */ import javax.swing.SpinnerNumberModel;
/*  27:    */ import javax.swing.event.ChangeEvent;
/*  28:    */ import javax.swing.event.ChangeListener;
/*  29:    */ import javax.swing.table.TableCellEditor;
/*  30:    */ 
/*  31:    */ public class OutlierDefinitionsEditor extends com.l2fprod.common.beans.editor.AbstractPropertyEditor
/*  32:    */ {
/*  33:    */   private OutlierDefinition[] definitions_;
/*  34:    */   
/*  35:    */   public OutlierDefinitionsEditor()
/*  36:    */   {
/*  37: 37 */     editor = new JButton(new AbstractAction("...") { public void actionPerformed(ActionEvent e) { int frequency;
/*  38:    */         int first;
/*  39:    */         int last;
/*  40:    */         int frequency;
/*  41: 41 */         if (UserInterfaceContext.INSTANCE.getDomain() != null) {
/*  42: 42 */           int first = UserInterfaceContext.INSTANCE.getDomain().getStart().getYear();
/*  43: 43 */           int last = UserInterfaceContext.INSTANCE.getDomain().getEnd().getYear();
/*  44: 44 */           frequency = UserInterfaceContext.INSTANCE.getDomain().getFrequency().intValue();
/*  45:    */         } else {
/*  46: 46 */           first = 1980;
/*  47: 47 */           last = GregorianCalendar.getInstance().get(1);
/*  48: 48 */           frequency = 12;
/*  49:    */         }
/*  50:    */         
/*  51: 51 */         JPanel pane = new JPanel(new java.awt.BorderLayout());
/*  52: 52 */         pane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/*  53:    */         
/*  54: 54 */         OutliersModel model = new OutliersModel(first, last, frequency, 
/*  55: 55 */           definitions_ != null ? Arrays.asList(definitions_) : Collections.emptyList());
/*  56: 56 */         final JTable table = new JTable(model);
/*  57: 57 */         table.setSelectionMode(0);
/*  58: 58 */         table.setCellSelectionEnabled(true);
/*  59: 59 */         table.setDefaultEditor(OutlierType.class, new OutlierTypeEditor());
/*  60: 60 */         table.setDefaultRenderer(OutlierType.class, new OutlierTypeRenderer());
/*  61:    */         
/*  62: 62 */         pane.add(ec.nbdemetra.ui.NbComponents.newJScrollPane(table), "Center");
/*  63:    */         
/*  64: 64 */         JPanel subPane = new JPanel();
/*  65: 65 */         BoxLayout subLayout = new BoxLayout(subPane, 2);
/*  66: 66 */         subPane.setLayout(subLayout);
/*  67: 67 */         subPane.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));
/*  68: 68 */         subPane.add(Box.createHorizontalGlue());
/*  69: 69 */         subPane.add(new JButton(new AbstractAction("Clear")
/*  70:    */         {
/*  71:    */           public void actionPerformed(ActionEvent e) {
/*  72: 72 */             OutliersModel model = (OutliersModel)table.getModel();
/*  73: 73 */             table.setModel(new OutliersModel(model.getFirstYear(), model.getLastYear(), model.getFreq(), 
/*  74: 74 */               Collections.emptyList()));
/*  75:    */           }
/*  76: 76 */         }));
/*  77: 77 */         pane.add(subPane, "South");
/*  78:    */         
/*  79: 79 */         if (UserInterfaceContext.INSTANCE.getDomain() == null) {
/*  80: 80 */           JPanel topPane = new JPanel();
/*  81: 81 */           BoxLayout topLayout = new BoxLayout(topPane, 2);
/*  82: 82 */           topPane.setLayout(topLayout);
/*  83: 83 */           topPane.setBorder(BorderFactory.createEmptyBorder(0, 0, 3, 0));
/*  84:    */           
/*  85: 85 */           topPane.add(new JLabel("First year:"));
/*  86: 86 */           topPane.add(Box.createHorizontalStrut(10));
/*  87: 87 */           final JSpinner spinnerFirst = new JSpinner(new SpinnerNumberModel(first, 1950, last, 1));
/*  88: 88 */           spinnerFirst.setEditor(new JSpinner.NumberEditor(spinnerFirst, "#"));
/*  89: 89 */           topPane.add(spinnerFirst);
/*  90: 90 */           topPane.add(Box.createHorizontalStrut(20));
/*  91: 91 */           topPane.add(new JLabel("Last year:"));
/*  92: 92 */           topPane.add(Box.createHorizontalStrut(10));
/*  93: 93 */           final JSpinner spinnerLast = new JSpinner(new SpinnerNumberModel(last, 1950, last, 1));
/*  94: 94 */           spinnerLast.setEditor(new JSpinner.NumberEditor(spinnerLast, "#"));
/*  95: 95 */           topPane.add(spinnerLast);
/*  96: 96 */           topPane.add(Box.createHorizontalStrut(20));
/*  97: 97 */           topPane.add(new JLabel("Frequency:"));
/*  98: 98 */           topPane.add(Box.createHorizontalStrut(10));
/*  99: 99 */           final JComboBox comboFreq = new JComboBox(new Integer[] { Integer.valueOf(1), Integer.valueOf(4), Integer.valueOf(12) });
/* 100:100 */           comboFreq.setSelectedItem(Integer.valueOf(frequency));
/* 101:101 */           topPane.add(comboFreq);
/* 102:    */           
/* 103:103 */           spinnerFirst.addChangeListener(new ChangeListener()
/* 104:    */           {
/* 105:    */             public void stateChanged(ChangeEvent e) {
/* 106:106 */               if (((Integer)spinnerFirst.getValue()).intValue() > ((Integer)spinnerLast.getValue()).intValue()) {
/* 107:107 */                 spinnerLast.setValue(spinnerFirst.getValue());
/* 108:    */               } else {
/* 109:109 */                 table.setModel(new OutliersModel(((Integer)spinnerFirst.getValue()).intValue(), 
/* 110:110 */                   ((Integer)spinnerLast.getValue()).intValue(), 
/* 111:111 */                   ((Integer)comboFreq.getSelectedItem()).intValue(), 
/* 112:112 */                   definitions_ != null ? Arrays.asList(definitions_) : Collections.emptyList()));
/* 113:    */               }
/* 114:    */               
/* 115:    */             }
/* 116:116 */           });
/* 117:117 */           spinnerLast.addChangeListener(new ChangeListener()
/* 118:    */           {
/* 119:    */             public void stateChanged(ChangeEvent e) {
/* 120:120 */               if (((Integer)spinnerFirst.getValue()).intValue() > ((Integer)spinnerLast.getValue()).intValue()) {
/* 121:121 */                 spinnerFirst.setValue(spinnerLast.getValue());
/* 122:    */               } else {
/* 123:123 */                 table.setModel(new OutliersModel(((Integer)spinnerFirst.getValue()).intValue(), 
/* 124:124 */                   ((Integer)spinnerLast.getValue()).intValue(), 
/* 125:125 */                   ((Integer)comboFreq.getSelectedItem()).intValue(), 
/* 126:126 */                   definitions_ != null ? Arrays.asList(definitions_) : Collections.emptyList()));
/* 127:    */               }
/* 128:    */               
/* 129:    */             }
/* 130:130 */           });
/* 131:131 */           comboFreq.addItemListener(new java.awt.event.ItemListener()
/* 132:    */           {
/* 133:    */             public void itemStateChanged(ItemEvent e) {
/* 134:134 */               if (e.getStateChange() == 1) {
/* 135:135 */                 table.setModel(new OutliersModel(((Integer)spinnerFirst.getValue()).intValue(), 
/* 136:136 */                   ((Integer)spinnerLast.getValue()).intValue(), 
/* 137:137 */                   ((Integer)comboFreq.getSelectedItem()).intValue(), 
/* 138:138 */                   definitions_ != null ? Arrays.asList(definitions_) : Collections.emptyList()));
/* 139:    */               }
/* 140:    */               
/* 141:    */             }
/* 142:142 */           });
/* 143:143 */           pane.add(topPane, "North");
/* 144:    */         }
/* 145:    */         
/* 146:146 */         JDialog dialog = new JDialog(javax.swing.SwingUtilities.getWindowAncestor(editor));
/* 147:147 */         dialog.setContentPane(pane);
/* 148:148 */         dialog.addWindowListener(new java.awt.event.WindowAdapter()
/* 149:    */         {
/* 150:    */           public void windowClosing(WindowEvent e) {
/* 151:151 */             TableCellEditor cellEditor = table.getCellEditor();
/* 152:152 */             if (cellEditor != null) {
/* 153:153 */               cellEditor.stopCellEditing();
/* 154:    */             }
/* 155:155 */             OutlierDefinition[] old = definitions_;
/* 156:156 */             setValue(com.google.common.collect.Iterables.toArray(((OutliersModel)table.getModel()).getDefinitions(), OutlierDefinition.class));
/* 157:157 */             firePropertyChange(old, definitions_);
/* 158:    */           }
/* 159:159 */         });
/* 160:160 */         dialog.pack();
/* 161:161 */         dialog.setModal(true);
/* 162:162 */         dialog.setVisible(true);
/* 163:    */       }
/* 164:    */     });
/* 165:    */   }
/* 166:    */   
/* 167:    */ 
/* 168:    */   public void setValue(Object value)
/* 169:    */   {
/* 170:170 */     if (value == null) {
/* 171:171 */       definitions_ = new OutlierDefinition[0];
/* 172:172 */     } else if ((value instanceof OutlierDefinition[])) {
/* 173:173 */       definitions_ = ((OutlierDefinition[])value);
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   public Object getValue()
/* 178:    */   {
/* 179:179 */     return definitions_;
/* 180:    */   }
/* 181:    */ }
