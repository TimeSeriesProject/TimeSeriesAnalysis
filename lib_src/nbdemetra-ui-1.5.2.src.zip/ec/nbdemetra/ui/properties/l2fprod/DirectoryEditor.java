/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ import ec.tstoolkit.utilities.Directory;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.io.File;
/*  7:   */ import javax.swing.AbstractAction;
/*  8:   */ import javax.swing.JButton;
/*  9:   */ import javax.swing.JFileChooser;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class DirectoryEditor
/* 18:   */   extends AbstractPropertyEditor
/* 19:   */ {
/* 20:   */   private Directory directory_;
/* 21:   */   
/* 22:   */   public DirectoryEditor()
/* 23:   */   {
/* 24:24 */     editor = new JButton(new AbstractAction("...")
/* 25:   */     {
/* 26:   */       public void actionPerformed(ActionEvent e)
/* 27:   */       {
/* 28:28 */         JFileChooser comp = new JFileChooser();
/* 29:29 */         comp.setCurrentDirectory(new File("."));
/* 30:30 */         comp.setDialogTitle("Choose Folder");
/* 31:31 */         comp.setFileSelectionMode(1);
/* 32:32 */         comp.setAcceptAllFileFilterUsed(false);
/* 33:33 */         if (comp.showOpenDialog(null) == 0) {
/* 34:34 */           setValue(new Directory(comp.getCurrentDirectory().getPath()));
/* 35:   */         }
/* 36:   */       }
/* 37:   */     });
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setValue(Object value) {
/* 41:41 */     if ((value != null) && ((value instanceof Directory))) {
/* 42:42 */       Directory old = directory_;
/* 43:43 */       directory_ = ((Directory)value);
/* 44:44 */       firePropertyChange(old, directory_);
/* 45:   */     }
/* 46:   */   }
/* 47:   */   
/* 48:   */   public Object getValue()
/* 49:   */   {
/* 50:50 */     return directory_;
/* 51:   */   }
/* 52:   */ }
