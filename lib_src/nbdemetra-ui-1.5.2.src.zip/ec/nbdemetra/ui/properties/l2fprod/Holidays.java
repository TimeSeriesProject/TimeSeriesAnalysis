/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ public class Holidays
/*  9:   */ {
/* 10:   */   private final String name_;
/* 11:   */   
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */   public Holidays(String name)
/* 17:   */   {
/* 18:18 */     if (name != null) {
/* 19:19 */       name_ = name;
/* 20:   */     }
/* 21:   */     else {
/* 22:22 */       name_ = "Default";
/* 23:   */     }
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getName() {
/* 27:27 */     return name_;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String toString()
/* 31:   */   {
/* 32:32 */     return name_;
/* 33:   */   }
/* 34:   */ }
