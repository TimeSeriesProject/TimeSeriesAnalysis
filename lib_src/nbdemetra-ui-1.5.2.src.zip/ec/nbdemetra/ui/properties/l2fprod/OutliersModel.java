/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Lists;
/*   4:    */ import ec.tstoolkit.timeseries.Day;
/*   5:    */ import ec.tstoolkit.timeseries.regression.OutlierDefinition;
/*   6:    */ import ec.tstoolkit.timeseries.regression.OutlierType;
/*   7:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*   9:    */ import java.util.HashMap;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.swing.table.DefaultTableModel;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ class OutliersModel
/* 182:    */   extends DefaultTableModel
/* 183:    */ {
/* 184:    */   private final int firstYear_;
/* 185:    */   private final int lastYear_;
/* 186:    */   private final int freq_;
/* 187:    */   private final HashMap<Day, OutlierDefinition> defs_;
/* 188:    */   
/* 189:    */   public List<OutlierDefinition> getDefinitions()
/* 190:    */   {
/* 191:191 */     return Lists.newArrayList(defs_.values());
/* 192:    */   }
/* 193:    */   
/* 194:    */   public int getFirstYear() {
/* 195:195 */     return firstYear_;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public int getLastYear() {
/* 199:199 */     return lastYear_;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public int getFreq() {
/* 203:203 */     return freq_;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public OutliersModel(int first, int last, int freq, List<OutlierDefinition> defs) {
/* 207:207 */     firstYear_ = first;
/* 208:208 */     lastYear_ = last;
/* 209:209 */     freq_ = freq;
/* 210:210 */     defs_ = new HashMap();
/* 211:211 */     for (OutlierDefinition def : defs) {
/* 212:212 */       defs_.put(position, def);
/* 213:    */     }
/* 214:    */   }
/* 215:    */   
/* 216:    */   public int getColumnCount()
/* 217:    */   {
/* 218:218 */     return freq_ + 1;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public String getColumnName(int column)
/* 222:    */   {
/* 223:223 */     switch (freq_) {
/* 224:    */     case 12: 
/* 225:225 */       switch (column) {
/* 226:    */       case 1: 
/* 227:227 */         return "January";
/* 228:    */       case 2: 
/* 229:229 */         return "February";
/* 230:    */       case 3: 
/* 231:231 */         return "March";
/* 232:    */       case 4: 
/* 233:233 */         return "April";
/* 234:    */       case 5: 
/* 235:235 */         return "May";
/* 236:    */       case 6: 
/* 237:237 */         return "June";
/* 238:    */       case 7: 
/* 239:239 */         return "July";
/* 240:    */       case 8: 
/* 241:241 */         return "August";
/* 242:    */       case 9: 
/* 243:243 */         return "September";
/* 244:    */       case 10: 
/* 245:245 */         return "October";
/* 246:    */       case 11: 
/* 247:247 */         return "November";
/* 248:    */       case 12: 
/* 249:249 */         return "December";
/* 250:    */       }
/* 251:251 */       return "";
/* 252:    */     
/* 253:    */     case 4: 
/* 254:254 */       switch (column) {
/* 255:    */       case 1: 
/* 256:256 */         return "I";
/* 257:    */       case 2: 
/* 258:258 */         return "II";
/* 259:    */       case 3: 
/* 260:260 */         return "III";
/* 261:    */       case 4: 
/* 262:262 */         return "IV";
/* 263:    */       }
/* 264:264 */       return "";
/* 265:    */     }
/* 266:    */     
/* 267:267 */     return "";
/* 268:    */   }
/* 269:    */   
/* 270:    */ 
/* 271:    */   public Class<?> getColumnClass(int columnIndex)
/* 272:    */   {
/* 273:273 */     if (columnIndex == 0) {
/* 274:274 */       return Integer.class;
/* 275:    */     }
/* 276:276 */     return OutlierType.class;
/* 277:    */   }
/* 278:    */   
/* 279:    */ 
/* 280:    */   public boolean isCellEditable(int row, int column)
/* 281:    */   {
/* 282:282 */     return column != 0;
/* 283:    */   }
/* 284:    */   
/* 285:    */   public int getRowCount()
/* 286:    */   {
/* 287:287 */     return 1 + lastYear_ - firstYear_;
/* 288:    */   }
/* 289:    */   
/* 290:    */   public Object getValueAt(int row, int column)
/* 291:    */   {
/* 292:292 */     if (column == 0) {
/* 293:293 */       return Integer.valueOf(firstYear_ + row);
/* 294:    */     }
/* 295:    */     
/* 296:296 */     Day day = new TsPeriod(TsFrequency.valueOf(freq_), firstYear_ + row, column - 1).firstday();
/* 297:297 */     if (defs_.containsKey(day)) {
/* 298:298 */       return defs_.get(day)).type;
/* 299:    */     }
/* 300:300 */     return null;
/* 301:    */   }
/* 302:    */   
/* 303:    */ 
/* 304:    */   public void setValueAt(Object aValue, int row, int column)
/* 305:    */   {
/* 306:306 */     Day day = new TsPeriod(TsFrequency.valueOf(freq_), firstYear_ + row, column - 1).firstday();
/* 307:307 */     if (aValue != null) {
/* 308:308 */       defs_.put(day, new OutlierDefinition(day, (OutlierType)aValue, true));
/* 309:    */     } else {
/* 310:310 */       defs_.remove(day);
/* 311:    */     }
/* 312:    */   }
/* 313:    */ }
