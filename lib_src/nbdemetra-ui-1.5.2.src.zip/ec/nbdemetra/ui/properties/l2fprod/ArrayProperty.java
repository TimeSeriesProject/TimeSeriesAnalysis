package ec.nbdemetra.ui.properties.l2fprod;

import com.l2fprod.common.propertysheet.DefaultProperty;

class ArrayProperty
  extends DefaultProperty
{
  public void readFromObject(Object object) {}
}
