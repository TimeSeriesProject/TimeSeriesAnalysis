/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.properties.ListSelection;
/*  4:   */ import java.awt.BorderLayout;
/*  5:   */ import java.awt.Dimension;
/*  6:   */ import java.awt.Window;
/*  7:   */ import java.awt.event.ActionEvent;
/*  8:   */ import java.awt.event.ActionListener;
/*  9:   */ import java.util.List;
/* 10:   */ import javax.swing.BorderFactory;
/* 11:   */ import javax.swing.Box;
/* 12:   */ import javax.swing.BoxLayout;
/* 13:   */ import javax.swing.JButton;
/* 14:   */ import javax.swing.JDialog;
/* 15:   */ import javax.swing.JPanel;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ public class ListSelectionDialog<T>
/* 24:   */   extends JDialog
/* 25:   */ {
/* 26:   */   private ListSelection<T> list;
/* 27:   */   
/* 28:   */   public ListSelectionDialog(Window owner)
/* 29:   */   {
/* 30:30 */     super(owner);
/* 31:   */     
/* 32:32 */     JPanel pane = new JPanel(new BorderLayout());
/* 33:33 */     pane.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
/* 34:   */     
/* 35:35 */     list = new ListSelection();
/* 36:36 */     list.setPreferredSize(new Dimension(150, 200));
/* 37:37 */     pane.add(list, "North");
/* 38:   */     
/* 39:39 */     JPanel buttonPane = new JPanel();
/* 40:40 */     BoxLayout layout = new BoxLayout(buttonPane, 2);
/* 41:41 */     buttonPane.setLayout(layout);
/* 42:42 */     buttonPane.add(Box.createGlue());
/* 43:43 */     JButton okButton = new JButton("Done");
/* 44:44 */     okButton.setPreferredSize(new Dimension(60, 27));
/* 45:45 */     okButton.setFocusPainted(false);
/* 46:46 */     okButton.addActionListener(new ActionListener()
/* 47:   */     {
/* 48:   */       public void actionPerformed(ActionEvent e) {
/* 49:49 */         setVisible(false);
/* 50:   */       }
/* 51:51 */     });
/* 52:52 */     buttonPane.add(okButton);
/* 53:53 */     buttonPane.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));
/* 54:54 */     pane.add(buttonPane, "South");
/* 55:55 */     pane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/* 56:   */     
/* 57:57 */     setMinimumSize(new Dimension(400, 200));
/* 58:58 */     setContentPane(pane);
/* 59:59 */     pack();
/* 60:60 */     setModal(true);
/* 61:   */   }
/* 62:   */   
/* 63:   */   public List<T> getSelection() {
/* 64:64 */     return list.getSelection();
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void set(List<T> input) {
/* 68:68 */     list.set(input);
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void set(List<T> input, List<T> sel) {
/* 72:72 */     list.set(input, sel);
/* 73:   */   }
/* 74:   */ }
