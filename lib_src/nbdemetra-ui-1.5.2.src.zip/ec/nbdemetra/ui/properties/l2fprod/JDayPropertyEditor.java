/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ import com.toedter.calendar.JTextFieldDateEditor;
/*  5:   */ import ec.tstoolkit.timeseries.Day;
/*  6:   */ import java.beans.PropertyChangeEvent;
/*  7:   */ import java.beans.PropertyChangeListener;
/*  8:   */ import java.util.Date;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class JDayPropertyEditor
/* 14:   */   extends AbstractPropertyEditor
/* 15:   */ {
/* 16:16 */   private final JTextFieldDateEditor component = new JTextFieldDateEditor("yyyy-MM-dd", "####-##-##", '_');
/* 17:   */   
/* 18:   */   public JDayPropertyEditor() {
/* 19:19 */     component.addPropertyChangeListener("date", new PropertyChangeListener()
/* 20:   */     {
/* 21:   */       public void propertyChange(PropertyChangeEvent evt)
/* 22:   */       {
/* 23:23 */         Day oday = null;Day nday = null;
/* 24:24 */         if ((evt.getOldValue() instanceof Date)) {
/* 25:25 */           oday = new Day((Date)evt.getOldValue());
/* 26:   */         }
/* 27:27 */         if ((evt.getNewValue() instanceof Date)) {
/* 28:28 */           nday = new Day((Date)evt.getNewValue());
/* 29:   */         }
/* 30:30 */         firePropertyChange(oday, nday);
/* 31:   */       }
/* 32:32 */     });
/* 33:33 */     editor = component;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Object getValue()
/* 37:   */   {
/* 38:38 */     Date date = component.getDate();
/* 39:39 */     return date != null ? new Day(date) : Day.BEG;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void setValue(Object o)
/* 43:   */   {
/* 44:44 */     Day day = (Day)o;
/* 45:45 */     component.setDate(o != null ? day.getTime() : Day.toDay().getTime());
/* 46:   */   }
/* 47:   */ }
