/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor;
/*  4:   */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor.Value;
/*  5:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  6:   */ import java.awt.Component;
/*  7:   */ import java.util.List;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class UserVariableSelector
/* 19:   */   extends ComboBoxPropertyEditor
/* 20:   */ {
/* 21:   */   public Component getCustomEditor()
/* 22:   */   {
/* 23:23 */     List<String> dic = ProcessingContext.getActiveContext().getTsVariableDictionary();
/* 24:24 */     ComboBoxPropertyEditor.Value[] values = new ComboBoxPropertyEditor.Value[dic.size()];
/* 25:25 */     for (int i = 0; i < values.length; i++) {
/* 26:26 */       values[i] = new ComboBoxPropertyEditor.Value(new UserVariable((String)dic.get(i)), dic.get(i));
/* 27:   */     }
/* 28:28 */     setAvailableValues(values);
/* 29:29 */     return super.getCustomEditor();
/* 30:   */   }
/* 31:   */ }
