/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ import ec.tstoolkit.timeseries.regression.Ramp;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.util.List;
/*  7:   */ import javax.swing.AbstractAction;
/*  8:   */ import javax.swing.JButton;
/*  9:   */ import javax.swing.SwingUtilities;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class RampsEditor
/* 18:   */   extends AbstractPropertyEditor
/* 19:   */ {
/* 20:   */   private Ramp[] ramps_;
/* 21:   */   
/* 22:   */   public RampsEditor()
/* 23:   */   {
/* 24:24 */     editor = new JButton(new AbstractAction("...")
/* 25:   */     {
/* 26:   */       public void actionPerformed(ActionEvent e)
/* 27:   */       {
/* 28:28 */         ArrayEditorDialog<RampDescriptor> dialog = new ArrayEditorDialog(SwingUtilities.getWindowAncestor(editor), 
/* 29:29 */           ramps_ != null ? RampsEditor.this.getDescriptors() : new RampDescriptor[0], RampDescriptor.class);
/* 30:30 */         dialog.setTitle("Ramps");
/* 31:31 */         dialog.setVisible(true);
/* 32:32 */         if (dialog.isDirty()) {
/* 33:33 */           RampsEditor.this.setDescriptors(dialog.getElements());
/* 34:   */         }
/* 35:   */       }
/* 36:   */     });
/* 37:   */   }
/* 38:   */   
/* 39:   */   private RampDescriptor[] getDescriptors() {
/* 40:40 */     RampDescriptor[] descs = new RampDescriptor[ramps_.length];
/* 41:41 */     for (int i = 0; i < descs.length; i++) {
/* 42:42 */       descs[i] = new RampDescriptor(ramps_[i]);
/* 43:   */     }
/* 44:44 */     return descs;
/* 45:   */   }
/* 46:   */   
/* 47:   */   private void setDescriptors(List<RampDescriptor> elements) {
/* 48:48 */     Ramp[] old = ramps_;
/* 49:49 */     ramps_ = new Ramp[elements.size()];
/* 50:50 */     for (int i = 0; i < ramps_.length; i++) {
/* 51:51 */       ramps_[i] = ((RampDescriptor)elements.get(i)).getCore();
/* 52:   */     }
/* 53:53 */     firePropertyChange(old, ramps_);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public Object getValue()
/* 57:   */   {
/* 58:58 */     return ramps_;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setValue(Object value)
/* 62:   */   {
/* 63:63 */     if ((value != null) && ((value instanceof Ramp[]))) {
/* 64:64 */       Ramp[] val = (Ramp[])value;
/* 65:65 */       ramps_ = new Ramp[val.length];
/* 66:66 */       for (int i = 0; i < val.length; i++) {
/* 67:67 */         ramps_[i] = val[i].clone();
/* 68:   */       }
/* 69:   */     }
/* 70:   */     else {
/* 71:71 */       ramps_ = new Ramp[0];
/* 72:   */     }
/* 73:   */   }
/* 74:   */ }
