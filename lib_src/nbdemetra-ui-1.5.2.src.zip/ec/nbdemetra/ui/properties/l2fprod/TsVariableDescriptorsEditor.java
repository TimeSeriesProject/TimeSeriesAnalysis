/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ import ec.tstoolkit.modelling.TsVariableDescriptor;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.util.List;
/*  7:   */ import javax.swing.AbstractAction;
/*  8:   */ import javax.swing.JButton;
/*  9:   */ import javax.swing.SwingUtilities;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class TsVariableDescriptorsEditor
/* 18:   */   extends AbstractPropertyEditor
/* 19:   */ {
/* 20:   */   private TsVariableDescriptor[] descriptors_;
/* 21:   */   
/* 22:   */   public TsVariableDescriptorsEditor()
/* 23:   */   {
/* 24:24 */     editor = new JButton(new AbstractAction("...")
/* 25:   */     {
/* 26:   */       public void actionPerformed(ActionEvent e) {
/* 27:27 */         ArrayEditorDialog<TsVariableDescriptorUI> dialog = new ArrayEditorDialog(SwingUtilities.getWindowAncestor(editor), 
/* 28:28 */           descriptors_ != null ? TsVariableDescriptorsEditor.this.getDescriptors() : new TsVariableDescriptorUI[0], TsVariableDescriptorUI.class);
/* 29:29 */         dialog.setTitle("Variables");
/* 30:30 */         dialog.setVisible(true);
/* 31:31 */         if (dialog.isDirty()) {
/* 32:32 */           TsVariableDescriptorsEditor.this.setDescriptors(dialog.getElements());
/* 33:   */         }
/* 34:   */       }
/* 35:   */     });
/* 36:   */   }
/* 37:   */   
/* 38:   */   private TsVariableDescriptorUI[] getDescriptors() {
/* 39:39 */     TsVariableDescriptorUI[] descs = new TsVariableDescriptorUI[descriptors_.length];
/* 40:40 */     for (int i = 0; i < descs.length; i++) {
/* 41:41 */       descs[i] = new TsVariableDescriptorUI(descriptors_[i]);
/* 42:   */     }
/* 43:43 */     return descs;
/* 44:   */   }
/* 45:   */   
/* 46:   */   private void setDescriptors(List<TsVariableDescriptorUI> elements) {
/* 47:47 */     TsVariableDescriptor[] old = descriptors_;
/* 48:48 */     descriptors_ = new TsVariableDescriptor[elements.size()];
/* 49:49 */     for (int i = 0; i < descriptors_.length; i++) {
/* 50:50 */       descriptors_[i] = ((TsVariableDescriptorUI)elements.get(i)).getCore();
/* 51:   */     }
/* 52:52 */     firePropertyChange(old, descriptors_);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public Object getValue()
/* 56:   */   {
/* 57:57 */     return descriptors_;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void setValue(Object value)
/* 61:   */   {
/* 62:62 */     if ((value != null) && ((value instanceof TsVariableDescriptor[]))) {
/* 63:63 */       TsVariableDescriptor[] old = descriptors_;
/* 64:64 */       TsVariableDescriptor[] ndesc = (TsVariableDescriptor[])value;
/* 65:65 */       descriptors_ = new TsVariableDescriptor[ndesc.length];
/* 66:66 */       for (int i = 0; i < ndesc.length; i++) {
/* 67:67 */         descriptors_[i] = ndesc[i].clone();
/* 68:   */       }
/* 69:69 */       firePropertyChange(old, descriptors_);
/* 70:   */     }
/* 71:   */   }
/* 72:   */ }
