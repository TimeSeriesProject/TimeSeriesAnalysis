/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.descriptors.EnhancedPropertyDescriptor;
/*   4:    */ import ec.tstoolkit.modelling.TsVariableDescriptor;
/*   5:    */ import java.beans.PropertyDescriptor;
/*   6:    */ 
/*   7:    */ public class TsVariableDescriptorUI implements ec.tstoolkit.descriptors.IObjectDescriptor<TsVariableDescriptor>
/*   8:    */ {
/*   9:    */   public static final String DISPLAYNAME = "Ts variable";
/*  10:    */   private final TsVariableDescriptor core;
/*  11:    */   private static final int NAME_ID = 0;
/*  12:    */   private static final int START_ID = 1;
/*  13:    */   private static final int END_ID = 2;
/*  14:    */   private static final int TYPE_ID = 3;
/*  15:    */   private static final String NAME = "Name";
/*  16:    */   private static final String START = "First lag";
/*  17:    */   private static final String END = "Last lag";
/*  18:    */   private static final String TYPE = "Component type";
/*  19:    */   private static final String NAME_DESC = "Name";
/*  20:    */   private static final String START_DESC = "First lag";
/*  21:    */   private static final String END_DESC = "Last lag";
/*  22:    */   private static final String TYPE_DESC = "Component type";
/*  23:    */   
/*  24:    */   public String toString()
/*  25:    */   {
/*  26: 26 */     return core.toString();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public TsVariableDescriptorUI() {
/*  30: 30 */     core = new TsVariableDescriptor();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public TsVariableDescriptorUI(TsVariableDescriptor desc) {
/*  34: 34 */     core = desc;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public UserVariable getName() {
/*  38: 38 */     return new UserVariable(core.getName());
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setName(UserVariable name) {
/*  42: 42 */     core.setName(name == null ? null : name.getName());
/*  43:    */   }
/*  44:    */   
/*  45:    */   public int getFirstLag() {
/*  46: 46 */     return core.getFirstLag();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setFirstLag(int lag) {
/*  50: 50 */     core.setFirstLag(lag);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int getLastLag() {
/*  54: 54 */     return core.getLastLag();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setLastLag(int lag) {
/*  58: 58 */     core.setLastLag(lag);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public ec.tstoolkit.modelling.ComponentType getComponent() {
/*  62: 62 */     return core.getEffect();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setComponent(ec.tstoolkit.modelling.ComponentType cmp) {
/*  66: 66 */     core.setEffect(cmp);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public TsVariableDescriptor getCore()
/*  70:    */   {
/*  71: 71 */     return core;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public java.util.List<EnhancedPropertyDescriptor> getProperties()
/*  75:    */   {
/*  76: 76 */     java.util.ArrayList<EnhancedPropertyDescriptor> descs = new java.util.ArrayList();
/*  77: 77 */     EnhancedPropertyDescriptor desc = nameDesc();
/*  78: 78 */     if (desc != null) {
/*  79: 79 */       descs.add(desc);
/*  80:    */     }
/*  81: 81 */     desc = flagDesc();
/*  82: 82 */     if (desc != null) {
/*  83: 83 */       descs.add(desc);
/*  84:    */     }
/*  85: 85 */     desc = llagDesc();
/*  86: 86 */     if (desc != null) {
/*  87: 87 */       descs.add(desc);
/*  88:    */     }
/*  89: 89 */     desc = typeDesc();
/*  90: 90 */     if (desc != null) {
/*  91: 91 */       descs.add(desc);
/*  92:    */     }
/*  93: 93 */     return descs;
/*  94:    */   }
/*  95:    */   
/*  96:    */ 
/*  97:    */ 
/*  98:    */   private EnhancedPropertyDescriptor flagDesc()
/*  99:    */   {
/* 100:    */     try
/* 101:    */     {
/* 102:102 */       PropertyDescriptor desc = new PropertyDescriptor("firstLag", getClass());
/* 103:103 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/* 104:104 */       desc.setDisplayName("First lag");
/* 105:105 */       desc.setShortDescription("First lag");
/* 106:    */       
/* 107:107 */       return edesc;
/* 108:    */     } catch (java.beans.IntrospectionException ex) {}
/* 109:109 */     return null;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private EnhancedPropertyDescriptor llagDesc()
/* 113:    */   {
/* 114:    */     try {
/* 115:115 */       PropertyDescriptor desc = new PropertyDescriptor("lastLag", getClass());
/* 116:116 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 2);
/* 117:117 */       desc.setDisplayName("Last lag");
/* 118:118 */       desc.setShortDescription("Last lag");
/* 119:    */       
/* 120:120 */       return edesc;
/* 121:    */     } catch (java.beans.IntrospectionException ex) {}
/* 122:122 */     return null;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private EnhancedPropertyDescriptor typeDesc()
/* 126:    */   {
/* 127:    */     try {
/* 128:128 */       PropertyDescriptor desc = new PropertyDescriptor("component", getClass());
/* 129:129 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 3);
/* 130:130 */       desc.setDisplayName("Component type");
/* 131:131 */       desc.setShortDescription("Component type");
/* 132:    */       
/* 133:133 */       return edesc;
/* 134:    */     } catch (java.beans.IntrospectionException ex) {}
/* 135:135 */     return null;
/* 136:    */   }
/* 137:    */   
/* 138:    */   private EnhancedPropertyDescriptor nameDesc()
/* 139:    */   {
/* 140:    */     try {
/* 141:141 */       PropertyDescriptor desc = new PropertyDescriptor("name", getClass());
/* 142:142 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 0);
/* 143:143 */       desc.setDisplayName("Name");
/* 144:144 */       desc.setShortDescription("Name");
/* 145:    */       
/* 146:146 */       return edesc;
/* 147:    */     } catch (java.beans.IntrospectionException ex) {}
/* 148:148 */     return null;
/* 149:    */   }
/* 150:    */   
/* 151:    */ 
/* 152:    */   public String getDisplayName()
/* 153:    */   {
/* 154:154 */     return "Ts variable";
/* 155:    */   }
/* 156:    */ }
