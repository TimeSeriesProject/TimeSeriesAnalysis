/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor;
/*   4:    */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor.Value;
/*   5:    */ import com.l2fprod.common.propertysheet.PropertyEditorRegistry;
/*   6:    */ import ec.satoolkit.DecompositionMode;
/*   7:    */ import ec.satoolkit.benchmarking.SaBenchmarkingSpec.Target;
/*   8:    */ import ec.satoolkit.x11.SeasonalFilterOption;
/*   9:    */ import ec.tss.sa.output.CsvLayout;
/*  10:    */ import ec.tstoolkit.Parameter;
/*  11:    */ import ec.tstoolkit.modelling.ComponentType;
/*  12:    */ import ec.tstoolkit.modelling.DefaultTransformationType;
/*  13:    */ import ec.tstoolkit.modelling.RegressionTestSpec;
/*  14:    */ import ec.tstoolkit.modelling.TradingDaysSpecType;
/*  15:    */ import ec.tstoolkit.modelling.TsVariableDescriptor;
/*  16:    */ import ec.tstoolkit.modelling.arima.Method;
/*  17:    */ import ec.tstoolkit.modelling.arima.tramo.EasterSpec.Type;
/*  18:    */ import ec.tstoolkit.modelling.arima.tramo.TramoChoice;
/*  19:    */ import ec.tstoolkit.structural.ComponentUse;
/*  20:    */ import ec.tstoolkit.structural.SeasonalModel;
/*  21:    */ import ec.tstoolkit.timeseries.Day;
/*  22:    */ import ec.tstoolkit.timeseries.PeriodSelectorType;
/*  23:    */ import ec.tstoolkit.timeseries.calendars.LengthOfPeriodType;
/*  24:    */ import ec.tstoolkit.timeseries.calendars.TradingDaysType;
/*  25:    */ import ec.tstoolkit.timeseries.regression.InterventionVariable;
/*  26:    */ import ec.tstoolkit.timeseries.regression.OutlierDefinition;
/*  27:    */ import ec.tstoolkit.timeseries.regression.Ramp;
/*  28:    */ import ec.tstoolkit.timeseries.regression.Sequence;
/*  29:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  30:    */ import ec.tstoolkit.utilities.Directory;
/*  31:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  32:    */ import ec.ui.interfaces.ITsControl.TooltipType;
/*  33:    */ import ec.ui.interfaces.ITsGrid.Chronology;
/*  34:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*  35:    */ import ec.ui.interfaces.ITsGrid.Orientation;
/*  36:    */ import ec.ui.interfaces.ITsList.InfoType;
/*  37:    */ import java.beans.PropertyEditor;
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public enum CustomPropertyEditorRegistry
/*  41:    */ {
/*  42: 42 */   INSTANCE;
/*  43:    */   
/*  44:    */   private final PropertyEditorRegistry m_registry;
/*  45:    */   
/*  46: 46 */   private CustomPropertyEditorRegistry() { m_registry = new PropertyEditorRegistry();
/*  47:    */     
/*  48: 48 */     registerEnumEditor(ITsGrid.Chronology.class);
/*  49: 49 */     registerEnumEditor(ITsGrid.Orientation.class);
/*  50: 50 */     registerEnumEditor(ITsGrid.Mode.class);
/*  51: 51 */     registerEnumEditor(ITsList.InfoType.class);
/*  52: 52 */     registerEnumEditor(ITsControl.TooltipType.class);
/*  53: 53 */     registerEnumEditor(ITsCollectionView.TsUpdateMode.class);
/*  54: 54 */     registerEnumEditor(ComponentType.class);
/*  55: 55 */     registerEnumEditor(PeriodSelectorType.class);
/*  56: 56 */     registerEnumEditor(DefaultTransformationType.class);
/*  57: 57 */     registerEnumEditor(TradingDaysType.class);
/*  58: 58 */     registerEnumEditor(TramoChoice.class);
/*  59: 59 */     registerEnumEditor(TradingDaysSpecType.class);
/*  60: 60 */     registerEnumEditor(LengthOfPeriodType.class);
/*  61: 61 */     registerEnumEditor(RegressionTestSpec.class);
/*  62: 62 */     registerEnumEditor(SeasonalFilterOption.class);
/*  63: 63 */     registerEnumEditor(ComponentUse.class);
/*  64: 64 */     registerEnumEditor(SeasonalModel.class);
/*  65: 65 */     registerEnumEditor(Method.class);
/*  66: 66 */     registerEnumEditor(DecompositionMode.class);
/*  67: 67 */     registerEnumEditor(CsvLayout.class);
/*  68: 68 */     registerEnumEditor(SaBenchmarkingSpec.Target.class);
/*  69: 69 */     registerEnumEditor(EasterSpec.Type.class);
/*  70: 70 */     registerEnumEditor(TsFrequency.class);
/*  71:    */     
/*  72:    */ 
/*  73:    */ 
/*  74: 74 */     register(Directory.class, new DirectoryEditor());
/*  75: 75 */     register(Day.class, new JDayPropertyEditor());
/*  76: 76 */     register([Lec.tstoolkit.Parameter.class, new ParametersPropertyEditor());
/*  77: 77 */     register([Lec.satoolkit.x11.SeasonalFilterOption.class, new SeasonalFilterPropertyEditor());
/*  78: 78 */     register([Lec.tstoolkit.timeseries.regression.Ramp.class, new RampsEditor());
/*  79: 79 */     register([Lec.tstoolkit.modelling.TsVariableDescriptor.class, new TsVariableDescriptorsEditor());
/*  80: 80 */     register([Lec.tstoolkit.timeseries.regression.InterventionVariable.class, new InterventionVariablesEditor());
/*  81: 81 */     register([Lec.tstoolkit.timeseries.regression.Sequence.class, new SequencesEditor());
/*  82: 82 */     register([Lec.tstoolkit.timeseries.regression.OutlierDefinition.class, new OutlierDefinitionsEditor());
/*  83: 83 */     register([Ljava.lang.String.class, new StringCollectionEditor());
/*  84: 84 */     register(Holidays.class, new HolidaysSelector());
/*  85: 85 */     register(UserVariable.class, new UserVariableSelector());
/*  86: 86 */     register(UserVariables.class, new UserVariablesEditor());
/*  87:    */   }
/*  88:    */   
/*  89:    */   public PropertyEditorRegistry getRegistry() {
/*  90: 90 */     return m_registry;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void registerEnumEditor(Class<? extends Enum<?>> type) {
/*  94: 94 */     if (m_registry.getEditor(type) == null) {
/*  95: 95 */       Enum[] enumConstants = (Enum[])type.getEnumConstants();
/*  96: 96 */       ComboBoxPropertyEditor.Value[] values = new ComboBoxPropertyEditor.Value[enumConstants.length];
/*  97: 97 */       for (int i = 0; i < values.length; i++) {
/*  98: 98 */         values[i] = new ComboBoxPropertyEditor.Value(enumConstants[i], enumConstants[i].name());
/*  99:    */       }
/* 100:    */       
/* 101:101 */       ComboBoxPropertyEditor editor = new ComboBoxPropertyEditor();
/* 102:102 */       editor.setAvailableValues(values);
/* 103:103 */       m_registry.registerEditor(type, editor);
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void registerCompositeEditor(Class type) {
/* 108:108 */     if ((m_registry.getEditor(type) == null) && (type.isArray()) && (type.getComponentType().isEnum())) {
/* 109:109 */       MultiEnumPropertyEditor editor = new MultiEnumPropertyEditor(type.getComponentType());
/* 110:110 */       m_registry.registerEditor(type, editor);
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void register(Class c, PropertyEditor editor) {
/* 115:115 */     if (m_registry.getEditor(c) == null) {
/* 116:116 */       m_registry.registerEditor(c, editor);
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void unregister(Class c) {
/* 121:121 */     if (m_registry.getEditor(c) != null) {
/* 122:122 */       m_registry.unregisterEditor(c);
/* 123:    */     }
/* 124:    */   }
/* 125:    */ }
