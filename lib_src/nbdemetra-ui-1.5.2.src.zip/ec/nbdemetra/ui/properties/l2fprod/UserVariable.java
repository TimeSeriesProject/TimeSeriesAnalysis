/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ 
/*  6:   */ public class UserVariable
/*  7:   */ {
/*  8:   */   private final String var_;
/*  9:   */   
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */   public UserVariable(String name)
/* 14:   */   {
/* 15:15 */     var_ = name;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public String getName() {
/* 19:19 */     return var_;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String toString()
/* 23:   */   {
/* 24:24 */     return var_ == null ? "Unused" : var_;
/* 25:   */   }
/* 26:   */ }
