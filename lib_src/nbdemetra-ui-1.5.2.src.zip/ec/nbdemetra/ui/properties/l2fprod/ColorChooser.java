/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.regression.OutlierType;
/*  4:   */ import java.awt.Color;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ public class ColorChooser
/* 31:   */ {
/* 32:32 */   private static Color CUSTOMGREEN = new Color(191, 255, 25);
/* 33:33 */   private static Color CUSTOMRED = new Color(255, 77, 61);
/* 34:34 */   private static Color CUSTOMBLUE = new Color(87, 155, 204);
/* 35:35 */   private static Color CUSTOMPINK = new Color(255, 204, 204);
/* 36:36 */   private static Color DARK = new Color(50, 50, 50);
/* 37:37 */   private static Color LIGHT = new Color(230, 230, 230);
/* 38:   */   
/* 39:   */   public static Color getColor(OutlierType type) {
/* 40:40 */     switch (type) {
/* 41:   */     case IO: 
/* 42:42 */       return CUSTOMGREEN;
/* 43:   */     case LS: 
/* 44:44 */       return CUSTOMRED;
/* 45:   */     case SLS: 
/* 46:46 */       return CUSTOMBLUE;
/* 47:   */     case SO: 
/* 48:48 */       return CUSTOMPINK;
/* 49:   */     }
/* 50:50 */     return Color.white;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public static Color getForeColor(OutlierType type)
/* 54:   */   {
/* 55:55 */     switch (type) {
/* 56:   */     case IO: 
/* 57:57 */       return DARK;
/* 58:   */     case LS: 
/* 59:   */     case SLS: 
/* 60:60 */       return LIGHT;
/* 61:   */     }
/* 62:62 */     return Color.black;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static String getBgHexColor(OutlierType type)
/* 66:   */   {
/* 67:67 */     return "#" + Integer.toHexString(getColor(type).getRGB() & 0xFFFFFF);
/* 68:   */   }
/* 69:   */ }
