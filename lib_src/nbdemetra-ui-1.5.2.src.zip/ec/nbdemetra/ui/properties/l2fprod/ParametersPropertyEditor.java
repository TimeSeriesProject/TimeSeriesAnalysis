/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.tstoolkit.Parameter;
/*   6:    */ import ec.tstoolkit.ParameterType;
/*   7:    */ import java.awt.BorderLayout;
/*   8:    */ import java.awt.Dialog.ModalityType;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.ActionListener;
/*  12:    */ import java.awt.event.WindowAdapter;
/*  13:    */ import java.awt.event.WindowEvent;
/*  14:    */ import javax.swing.DefaultCellEditor;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JComboBox;
/*  17:    */ import javax.swing.JDialog;
/*  18:    */ import javax.swing.JPanel;
/*  19:    */ import javax.swing.JTable;
/*  20:    */ import javax.swing.SwingUtilities;
/*  21:    */ import javax.swing.table.DefaultTableModel;
/*  22:    */ import javax.swing.table.TableCellEditor;
/*  23:    */ import javax.swing.table.TableColumn;
/*  24:    */ import javax.swing.table.TableColumnModel;
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ public class ParametersPropertyEditor
/*  30:    */   extends AbstractPropertyEditor
/*  31:    */ {
/*  32:    */   private Parameter[] parameters_;
/*  33:    */   
/*  34:    */   public static enum Type
/*  35:    */   {
/*  36: 36 */     Undefined,  Initial,  Fixed;
/*  37:    */   }
/*  38:    */   
/*  39: 39 */   private static ParameterType convert(String val) { Type t = Type.valueOf(val);
/*  40: 40 */     if (t == Type.Initial)
/*  41: 41 */       return ParameterType.Initial;
/*  42: 42 */     if (t == Type.Fixed) {
/*  43: 43 */       return ParameterType.Fixed;
/*  44:    */     }
/*  45: 45 */     return ParameterType.Undefined;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static Type convert(ParameterType t) {
/*  49: 49 */     if (t == ParameterType.Initial)
/*  50: 50 */       return Type.Initial;
/*  51: 51 */     if (t == ParameterType.Fixed) {
/*  52: 52 */       return Type.Fixed;
/*  53:    */     }
/*  54: 54 */     return Type.Undefined;
/*  55:    */   }
/*  56:    */   
/*  57:    */ 
/*  58:    */   public ParametersPropertyEditor()
/*  59:    */   {
/*  60: 60 */     editor = new ParametersEditor();
/*  61:    */   }
/*  62:    */   
/*  63:    */   void fireChanged(Parameter[] parameters) {
/*  64: 64 */     Parameter[] old = parameters_;
/*  65: 65 */     parameters_ = parameters;
/*  66: 66 */     firePropertyChange(old, parameters);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Object getValue()
/*  70:    */   {
/*  71: 71 */     return parameters_;
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */   public void setValue(Object value)
/*  76:    */   {
/*  77: 77 */     if ((value != null) && ((value instanceof Parameter[]))) {
/*  78: 78 */       parameters_ = ((Parameter[])value);
/*  79: 79 */       ((ParametersEditor)editor).setParameters(parameters_);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   class ParametersEditor extends JPanel
/*  84:    */   {
/*  85:    */     private Parameter[] nparameters_;
/*  86:    */     
/*  87:    */     public ParametersEditor() {
/*  88: 88 */       final JButton button = new JButton("...");
/*  89: 89 */       button.addActionListener(new ActionListener()
/*  90:    */       {
/*  91:    */         public void actionPerformed(ActionEvent e)
/*  92:    */         {
/*  93: 93 */           JPanel pane = new JPanel(new BorderLayout());
/*  94: 94 */           final JTable table = new JTable(
/*  95: 95 */             new DefaultTableModel()
/*  96:    */             {
/*  97:    */               public int getColumnCount()
/*  98:    */               {
/*  99: 99 */                 return 2;
/* 100:    */               }
/* 101:    */               
/* 102:    */               public String getColumnName(int column)
/* 103:    */               {
/* 104:104 */                 switch (column) {
/* 105:    */                 case 0: 
/* 106:106 */                   return "Value";
/* 107:    */                 case 1: 
/* 108:108 */                   return "Fixed";
/* 109:    */                 }
/* 110:110 */                 return "";
/* 111:    */               }
/* 112:    */               
/* 113:    */ 
/* 114:    */               public Class<?> getColumnClass(int columnIndex)
/* 115:    */               {
/* 116:116 */                 if (columnIndex == 0) {
/* 117:117 */                   return Double.class;
/* 118:    */                 }
/* 119:119 */                 return ParametersPropertyEditor.Type.class;
/* 120:    */               }
/* 121:    */               
/* 122:    */               public boolean isCellEditable(int row, int column)
/* 123:    */               {
/* 124:124 */                 return true;
/* 125:    */               }
/* 126:    */               
/* 127:    */               public int getRowCount()
/* 128:    */               {
/* 129:129 */                 return nparameters_.length;
/* 130:    */               }
/* 131:    */               
/* 132:    */               public Object getValueAt(int row, int column)
/* 133:    */               {
/* 134:134 */                 Parameter param = nparameters_[row];
/* 135:    */                 
/* 136:136 */                 switch (column) {
/* 137:    */                 case 0: 
/* 138:138 */                   return Double.valueOf(param.getValue());
/* 139:    */                 case 1: 
/* 140:140 */                   return ParametersPropertyEditor.convert(param.getType());
/* 141:    */                 }
/* 142:142 */                 return null;
/* 143:    */               }
/* 144:    */               
/* 145:    */ 
/* 146:    */               public void setValueAt(Object aValue, int row, int column)
/* 147:    */               {
/* 148:148 */                 Parameter param = nparameters_[row];
/* 149:    */                 
/* 150:150 */                 switch (column) {
/* 151:    */                 case 0: 
/* 152:152 */                   double val = Double.parseDouble(aValue.toString());
/* 153:153 */                   param.setValue(val);
/* 154:154 */                   break;
/* 155:    */                 case 1: 
/* 156:156 */                   param.setType(ParametersPropertyEditor.convert(aValue.toString()));
/* 157:    */                 }
/* 158:    */                 
/* 159:    */                 
/* 160:    */ 
/* 161:    */ 
/* 162:162 */                 fireTableCellUpdated(row, column);
/* 163:    */               }
/* 164:    */               
/* 165:    */ 
/* 166:166 */             });
/* 167:167 */           JComboBox cb = new JComboBox(ParametersPropertyEditor.Type.values());
/* 168:168 */           table.getColumnModel().getColumn(1).setCellEditor(new DefaultCellEditor(cb));
/* 169:169 */           table.setFillsViewportHeight(true);
/* 170:170 */           pane.add(NbComponents.newJScrollPane(table), "Center");
/* 171:    */           
/* 172:172 */           final JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(button), Dialog.ModalityType.TOOLKIT_MODAL);
/* 173:173 */           dlg.setContentPane(pane);
/* 174:174 */           dlg.addWindowListener(new WindowAdapter()
/* 175:    */           {
/* 176:    */             public void windowClosing(WindowEvent e)
/* 177:    */             {
/* 178:178 */               if (table.getCellEditor() != null) {
/* 179:179 */                 table.getCellEditor().stopCellEditing();
/* 180:    */               }
/* 181:181 */               fireChanged(nparameters_);
/* 182:    */             }
/* 183:183 */           });
/* 184:184 */           dlg.setMinimumSize(new Dimension(300, 300));
/* 185:185 */           dlg.setModal(true);
/* 186:186 */           SwingUtilities.invokeLater(new Runnable()
/* 187:    */           {
/* 188:    */             public void run()
/* 189:    */             {
/* 190:190 */               dlg.setVisible(true);
/* 191:    */             }
/* 192:    */             
/* 193:    */ 
/* 194:    */           });
/* 195:    */         }
/* 196:196 */       });
/* 197:197 */       setLayout(new BorderLayout());
/* 198:198 */       add(button, "Center");
/* 199:    */     }
/* 200:    */     
/* 201:    */     public void setParameters(Parameter[] param) {
/* 202:202 */       nparameters_ = Parameter.clone(param);
/* 203:    */     }
/* 204:    */     
/* 205:    */     public Parameter[] getParameters() {
/* 206:206 */       return nparameters_;
/* 207:    */     }
/* 208:    */   }
/* 209:    */ }
