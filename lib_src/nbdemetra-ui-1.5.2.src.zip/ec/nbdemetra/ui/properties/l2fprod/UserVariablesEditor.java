/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import java.util.List;
/*  8:   */ import javax.swing.AbstractAction;
/*  9:   */ import javax.swing.JButton;
/* 10:   */ import javax.swing.SwingUtilities;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class UserVariablesEditor
/* 18:   */   extends AbstractPropertyEditor
/* 19:   */ {
/* 20:   */   private String[] vars_;
/* 21:   */   
/* 22:   */   public UserVariablesEditor()
/* 23:   */   {
/* 24:24 */     editor = new JButton(new AbstractAction("...")
/* 25:   */     {
/* 26:   */       public void actionPerformed(ActionEvent e)
/* 27:   */       {
/* 28:28 */         ListSelectionDialog<String> dialog = new ListSelectionDialog(SwingUtilities.getWindowAncestor(editor));
/* 29:29 */         dialog.set(ProcessingContext.getActiveContext().getTsVariableDictionary(), Arrays.asList(vars_));
/* 30:30 */         dialog.setVisible(true);
/* 31:31 */         UserVariablesEditor.this.setVariables(dialog.getSelection());
/* 32:   */       }
/* 33:   */     });
/* 34:   */   }
/* 35:   */   
/* 36:   */   private void setVariables(List<String> elements) {
/* 37:37 */     String[] old = vars_;
/* 38:38 */     vars_ = new String[elements.size()];
/* 39:39 */     for (int i = 0; i < vars_.length; i++) {
/* 40:40 */       vars_[i] = ((String)elements.get(i));
/* 41:   */     }
/* 42:42 */     firePropertyChange(old, vars_);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Object getValue()
/* 46:   */   {
/* 47:47 */     return new UserVariables(vars_);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void setValue(Object value)
/* 51:   */   {
/* 52:52 */     if ((value != null) && ((value instanceof UserVariables))) {
/* 53:53 */       UserVariables val = (UserVariables)value;
/* 54:54 */       vars_ = ((String[])val.getNames().clone());
/* 55:   */     }
/* 56:   */     else {
/* 57:57 */       vars_ = new String[0];
/* 58:   */     }
/* 59:   */   }
/* 60:   */ }
