/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class MultiEnumPropertyEditor<T extends Class>
/* 21:   */   extends AbstractPropertyEditor
/* 22:   */ {
/* 23:   */   public MultiEnumPropertyEditor(T clazz)
/* 24:   */   {
/* 25:25 */     editor = new MultiEnumEditor(clazz);
/* 26:   */   }
/* 27:   */   
/* 28:   */ 
/* 29:   */   public Object getValue()
/* 30:   */   {
/* 31:31 */     MultiEnumEditor mee = (MultiEnumEditor)editor;
/* 32:32 */     return mee.getValue();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setValue(Object value)
/* 36:   */   {
/* 37:37 */     if (value != null) {
/* 38:38 */       MultiEnumEditor mee = (MultiEnumEditor)editor;
/* 39:39 */       mee.setValue(value);
/* 40:   */     }
/* 41:   */   }
/* 42:   */ }
