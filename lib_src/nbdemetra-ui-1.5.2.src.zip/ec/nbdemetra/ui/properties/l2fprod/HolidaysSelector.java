/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor;
/*  4:   */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor.Value;
/*  5:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  6:   */ import ec.tstoolkit.timeseries.calendars.GregorianCalendarManager;
/*  7:   */ import java.awt.Component;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class HolidaysSelector
/* 19:   */   extends ComboBoxPropertyEditor
/* 20:   */ {
/* 21:   */   public Component getCustomEditor()
/* 22:   */   {
/* 23:23 */     GregorianCalendarManager mgr = ProcessingContext.getActiveContext().getGregorianCalendars();
/* 24:24 */     String[] names = mgr.getNames();
/* 25:25 */     ComboBoxPropertyEditor.Value[] values = new ComboBoxPropertyEditor.Value[mgr.getCount()];
/* 26:26 */     for (int i = 0; i < values.length; i++) {
/* 27:27 */       values[i] = new ComboBoxPropertyEditor.Value(new Holidays(names[i]), names[i]);
/* 28:   */     }
/* 29:29 */     setAvailableValues(values);
/* 30:30 */     return super.getCustomEditor();
/* 31:   */   }
/* 32:   */ }
