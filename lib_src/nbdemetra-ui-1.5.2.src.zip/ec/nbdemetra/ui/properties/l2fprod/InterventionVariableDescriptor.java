/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.descriptors.EnhancedPropertyDescriptor;
/*   4:    */ import ec.tstoolkit.descriptors.IObjectDescriptor;
/*   5:    */ import ec.tstoolkit.timeseries.regression.InterventionVariable;
/*   6:    */ import ec.tstoolkit.timeseries.regression.Sequence;
/*   7:    */ import java.beans.IntrospectionException;
/*   8:    */ import java.beans.PropertyDescriptor;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ public class InterventionVariableDescriptor
/*  16:    */   implements IObjectDescriptor<InterventionVariable>
/*  17:    */ {
/*  18:    */   private final InterventionVariable core_;
/*  19:    */   private static final int SEQ_ID = 1;
/*  20:    */   private static final int DELTA_ID = 2;
/*  21:    */   private static final int DELTAS_ID = 3;
/*  22:    */   private static final int D1DS_ID = 4;
/*  23:    */   
/*  24:    */   public String toString()
/*  25:    */   {
/*  26: 26 */     return core_.toString();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public InterventionVariableDescriptor() {
/*  30: 30 */     core_ = new InterventionVariable();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public InterventionVariableDescriptor(InterventionVariable var)
/*  34:    */   {
/*  35: 35 */     core_ = var;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public InterventionVariable getCore()
/*  39:    */   {
/*  40: 40 */     return core_;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public List<EnhancedPropertyDescriptor> getProperties()
/*  44:    */   {
/*  45: 45 */     ArrayList<EnhancedPropertyDescriptor> descs = new ArrayList();
/*  46: 46 */     EnhancedPropertyDescriptor desc = seqDesc();
/*  47: 47 */     if (desc != null) {
/*  48: 48 */       descs.add(desc);
/*  49:    */     }
/*  50: 50 */     desc = deltaDesc();
/*  51: 51 */     if (desc != null) {
/*  52: 52 */       descs.add(desc);
/*  53:    */     }
/*  54: 54 */     desc = deltaSDesc();
/*  55: 55 */     if (desc != null) {
/*  56: 56 */       descs.add(desc);
/*  57:    */     }
/*  58: 58 */     desc = d1dSDesc();
/*  59: 59 */     if (desc != null) {
/*  60: 60 */       descs.add(desc);
/*  61:    */     }
/*  62: 62 */     return descs;
/*  63:    */   }
/*  64:    */   
/*  65:    */ 
/*  66:    */   private EnhancedPropertyDescriptor seqDesc()
/*  67:    */   {
/*  68:    */     try
/*  69:    */     {
/*  70: 70 */       PropertyDescriptor desc = new PropertyDescriptor("sequences", getClass());
/*  71: 71 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/*  72: 72 */       desc.setDisplayName("Sequences");
/*  73:    */       
/*  74: 74 */       return edesc;
/*  75:    */     } catch (IntrospectionException ex) {}
/*  76: 76 */     return null;
/*  77:    */   }
/*  78:    */   
/*  79:    */   private EnhancedPropertyDescriptor deltaDesc()
/*  80:    */   {
/*  81:    */     try {
/*  82: 82 */       PropertyDescriptor desc = new PropertyDescriptor("delta", getClass());
/*  83: 83 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 2);
/*  84: 84 */       desc.setDisplayName("Delta");
/*  85:    */       
/*  86: 86 */       return edesc;
/*  87:    */     } catch (IntrospectionException ex) {}
/*  88: 88 */     return null;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private EnhancedPropertyDescriptor deltaSDesc()
/*  92:    */   {
/*  93:    */     try {
/*  94: 94 */       PropertyDescriptor desc = new PropertyDescriptor("deltaS", getClass());
/*  95: 95 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 3);
/*  96: 96 */       desc.setDisplayName("Seasonal delta");
/*  97:    */       
/*  98: 98 */       return edesc;
/*  99:    */     } catch (IntrospectionException ex) {}
/* 100:100 */     return null;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private EnhancedPropertyDescriptor d1dSDesc()
/* 104:    */   {
/* 105:    */     try {
/* 106:106 */       PropertyDescriptor desc = new PropertyDescriptor("D1DS", getClass());
/* 107:107 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 4);
/* 108:108 */       desc.setDisplayName("D1 DS");
/* 109:    */       
/* 110:110 */       return edesc;
/* 111:    */     } catch (IntrospectionException ex) {}
/* 112:112 */     return null;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Sequence[] getSequences()
/* 116:    */   {
/* 117:117 */     return core_.getSequences();
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void setSequences(Sequence[] val) {
/* 121:121 */     core_.setSequences(val);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public double getDelta() {
/* 125:125 */     return core_.getDelta();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setDelta(double val) {
/* 129:129 */     core_.setDelta(val);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public double getDeltaS() {
/* 133:133 */     return core_.getDeltaS();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public void setDeltaS(double val) {
/* 137:137 */     core_.setDeltaS(val);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public boolean isD1DS() {
/* 141:141 */     return core_.getD1DS();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setD1DS(boolean val) {
/* 145:145 */     core_.setD1DS(val);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public String getDisplayName()
/* 149:    */   {
/* 150:150 */     return "Intervention variable";
/* 151:    */   }
/* 152:    */ }
