/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ public enum UserInterfaceContext
/*  9:   */ {
/* 10:10 */   INSTANCE;
/* 11:   */   
/* 12:   */   private TsDomain domain_;
/* 13:   */   
/* 14:   */   public TsDomain getDomain() {
/* 15:15 */     return domain_;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setDomain(TsDomain domain) {
/* 19:19 */     domain_ = domain;
/* 20:   */   }
/* 21:   */ }
