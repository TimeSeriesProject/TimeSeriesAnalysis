/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Iterables;
/*  4:   */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import javax.swing.AbstractAction;
/*  7:   */ import javax.swing.JButton;
/*  8:   */ import javax.swing.SwingUtilities;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public class StringCollectionEditor
/* 17:   */   extends AbstractPropertyEditor
/* 18:   */ {
/* 19:   */   private String[] strings_;
/* 20:   */   
/* 21:   */   public StringCollectionEditor()
/* 22:   */   {
/* 23:23 */     editor = new JButton(new AbstractAction("...")
/* 24:   */     {
/* 25:   */       public void actionPerformed(ActionEvent e)
/* 26:   */       {
/* 27:27 */         ArrayEditorDialog<String> dialog = new ArrayEditorDialog(SwingUtilities.getWindowAncestor(editor), 
/* 28:28 */           strings_ != null ? strings_ : new String[0], String.class);
/* 29:29 */         dialog.setVisible(true);
/* 30:30 */         setValue(Iterables.toArray(dialog.getElements(), String.class));
/* 31:   */       }
/* 32:   */     });
/* 33:   */   }
/* 34:   */   
/* 35:   */   public Object getValue()
/* 36:   */   {
/* 37:37 */     return strings_;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setValue(Object value)
/* 41:   */   {
/* 42:42 */     if ((value != null) && ((value instanceof String[]))) {
/* 43:43 */       String[] old = strings_;
/* 44:44 */       strings_ = ((String[])value);
/* 45:45 */       firePropertyChange(old, strings_);
/* 46:   */     }
/* 47:   */   }
/* 48:   */ }
