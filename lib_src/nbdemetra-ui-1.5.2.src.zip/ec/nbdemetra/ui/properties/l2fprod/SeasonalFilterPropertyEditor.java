/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.editor.AbstractPropertyEditor;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.satoolkit.x11.SeasonalFilterOption;
/*   6:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*   7:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*   8:    */ import java.awt.BorderLayout;
/*   9:    */ import java.awt.Dialog.ModalityType;
/*  10:    */ import java.awt.Dimension;
/*  11:    */ import java.awt.event.ActionEvent;
/*  12:    */ import java.awt.event.ActionListener;
/*  13:    */ import java.awt.event.WindowAdapter;
/*  14:    */ import java.awt.event.WindowEvent;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JDialog;
/*  17:    */ import javax.swing.JPanel;
/*  18:    */ import javax.swing.JTable;
/*  19:    */ import javax.swing.SwingUtilities;
/*  20:    */ import javax.swing.table.DefaultTableModel;
/*  21:    */ import javax.swing.table.TableCellEditor;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ public class SeasonalFilterPropertyEditor
/*  34:    */   extends AbstractPropertyEditor
/*  35:    */ {
/*  36:    */   private SeasonalFilterOption[] filters_;
/*  37:    */   
/*  38:    */   public SeasonalFilterPropertyEditor()
/*  39:    */   {
/*  40: 40 */     editor = new SeasonalFilterEditor();
/*  41:    */   }
/*  42:    */   
/*  43:    */   void fireChanged(SeasonalFilterOption[] filters) {
/*  44: 44 */     SeasonalFilterOption[] old = filters_;
/*  45: 45 */     filters_ = filters;
/*  46: 46 */     firePropertyChange(old, filters_);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Object getValue()
/*  50:    */   {
/*  51: 51 */     return filters_;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setValue(Object value)
/*  55:    */   {
/*  56: 56 */     if ((value != null) && ((value instanceof SeasonalFilterOption[]))) {
/*  57: 57 */       filters_ = ((SeasonalFilterOption[])value);
/*  58: 58 */       ((SeasonalFilterEditor)editor).setFilters(filters_);
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   class SeasonalFilterEditor extends JPanel
/*  63:    */   {
/*  64:    */     private SeasonalFilterOption[] nfilters_;
/*  65:    */     
/*  66:    */     public SeasonalFilterEditor() {
/*  67: 67 */       final JButton button = new JButton("...");
/*  68: 68 */       button.addActionListener(new ActionListener()
/*  69:    */       {
/*  70:    */         public void actionPerformed(ActionEvent e)
/*  71:    */         {
/*  72: 72 */           JPanel pane = new JPanel(new BorderLayout());
/*  73: 73 */           final JTable table = new JTable(
/*  74: 74 */             new DefaultTableModel()
/*  75:    */             {
/*  76:    */               public int getColumnCount()
/*  77:    */               {
/*  78: 78 */                 return 2;
/*  79:    */               }
/*  80:    */               
/*  81:    */               public String getColumnName(int column)
/*  82:    */               {
/*  83: 83 */                 if (column == 0) {
/*  84: 84 */                   return "Period";
/*  85:    */                 }
/*  86: 86 */                 return "Filter";
/*  87:    */               }
/*  88:    */               
/*  89:    */ 
/*  90:    */               public Class<?> getColumnClass(int columnIndex)
/*  91:    */               {
/*  92: 92 */                 if (columnIndex == 0) {
/*  93: 93 */                   return String.class;
/*  94:    */                 }
/*  95: 95 */                 return SeasonalFilterOption.class;
/*  96:    */               }
/*  97:    */               
/*  98:    */ 
/*  99:    */               public boolean isCellEditable(int row, int column)
/* 100:    */               {
/* 101:101 */                 return column == 1;
/* 102:    */               }
/* 103:    */               
/* 104:    */               public int getRowCount()
/* 105:    */               {
/* 106:106 */                 return nfilters_.length;
/* 107:    */               }
/* 108:    */               
/* 109:    */               public Object getValueAt(int row, int column)
/* 110:    */               {
/* 111:111 */                 if (column == 0) {
/* 112:112 */                   return TsPeriod.formatPeriod(TsFrequency.valueOf(nfilters_.length), row);
/* 113:    */                 }
/* 114:114 */                 return nfilters_[row];
/* 115:    */               }
/* 116:    */               
/* 117:    */ 
/* 118:    */               public void setValueAt(Object aValue, int row, int column)
/* 119:    */               {
/* 120:120 */                 if (column == 1) {
/* 121:121 */                   nfilters_[row] = ((SeasonalFilterOption)aValue);
/* 122:    */                 }
/* 123:123 */                 fireTableCellUpdated(row, column);
/* 124:    */               }
/* 125:    */               
/* 126:126 */             });
/* 127:127 */           table.setDefaultEditor(SeasonalFilterOption.class, new CustomFilterEditor());
/* 128:128 */           table.setFillsViewportHeight(true);
/* 129:129 */           pane.add(NbComponents.newJScrollPane(table), "Center");
/* 130:    */           
/* 131:131 */           JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(button), Dialog.ModalityType.TOOLKIT_MODAL);
/* 132:132 */           dlg.setContentPane(pane);
/* 133:133 */           dlg.addWindowListener(new WindowAdapter()
/* 134:    */           {
/* 135:    */             public void windowClosing(WindowEvent e)
/* 136:    */             {
/* 137:137 */               if (table.getCellEditor() != null) {
/* 138:138 */                 table.getCellEditor().stopCellEditing();
/* 139:    */               }
/* 140:140 */               fireChanged(nfilters_);
/* 141:    */             }
/* 142:142 */           });
/* 143:143 */           dlg.setMinimumSize(new Dimension(300, 300));
/* 144:144 */           dlg.setModal(true);
/* 145:145 */           dlg.setVisible(true);
/* 146:146 */           if (table.getCellEditor() != null) {
/* 147:147 */             table.getCellEditor().stopCellEditing();
/* 148:    */           }
/* 149:    */           
/* 150:    */         }
/* 151:151 */       });
/* 152:152 */       setLayout(new BorderLayout());
/* 153:153 */       add(button, "Center");
/* 154:    */     }
/* 155:    */     
/* 156:    */     public void setFilters(SeasonalFilterOption[] param) {
/* 157:157 */       nfilters_ = ((SeasonalFilterOption[])param.clone());
/* 158:    */     }
/* 159:    */   }
/* 160:    */ }
