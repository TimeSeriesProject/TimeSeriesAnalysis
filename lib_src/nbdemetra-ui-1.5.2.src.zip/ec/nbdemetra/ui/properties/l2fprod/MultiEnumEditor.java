/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.event.ActionEvent;
/*   5:    */ import java.awt.event.ActionListener;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.List;
/*   8:    */ import javax.swing.AbstractAction;
/*   9:    */ import javax.swing.BoxLayout;
/*  10:    */ import javax.swing.JButton;
/*  11:    */ import javax.swing.JCheckBox;
/*  12:    */ import javax.swing.JDialog;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.JTextField;
/*  15:    */ import javax.swing.SwingUtilities;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ class MultiEnumEditor<T extends Class>
/*  43:    */   extends JPanel
/*  44:    */ {
/*  45:    */   private List<Object> selection_;
/*  46:    */   private Object[] enumValues_;
/*  47:    */   private JCheckBox[] checkBoxes_;
/*  48:    */   
/*  49:    */   public Object getValue()
/*  50:    */   {
/*  51: 51 */     return selection_;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setValue(Object value) {
/*  55: 55 */     if ((value instanceof ArrayList)) {
/*  56: 56 */       selection_ = ((List)value);
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public MultiEnumEditor(final T clazz) {
/*  61: 61 */     setLayout(new BorderLayout());
/*  62:    */     
/*  63: 63 */     JTextField textField = new JTextField();
/*  64: 64 */     textField.setEditable(false);
/*  65: 65 */     textField.setText(getValue() != null ? getValue().toString() : "");
/*  66: 66 */     add(textField, "Center");
/*  67:    */     
/*  68: 68 */     final JButton button = new JButton("...");
/*  69: 69 */     button.addActionListener(new ActionListener()
/*  70:    */     {
/*  71:    */       public void actionPerformed(ActionEvent e)
/*  72:    */       {
/*  73: 73 */         final JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(button));
/*  74: 74 */         JPanel panel = new JPanel(new BorderLayout());
/*  75: 75 */         JPanel choicesPanel = new JPanel();
/*  76: 76 */         BoxLayout layout = new BoxLayout(choicesPanel, 3);
/*  77: 77 */         choicesPanel.setLayout(layout);
/*  78:    */         
/*  79: 79 */         enumValues_ = clazz.getEnumConstants();
/*  80: 80 */         if (enumValues_ != null) {
/*  81: 81 */           checkBoxes_ = new JCheckBox[enumValues_.length];
/*  82:    */           
/*  83: 83 */           for (int i = 0; i < enumValues_.length; i++) {
/*  84: 84 */             checkBoxes_[i] = new JCheckBox(enumValues_[i].toString());
/*  85: 85 */             choicesPanel.add(checkBoxes_[i]);
/*  86: 86 */             if ((selection_ != null) && (selection_.contains(enumValues_[i]))) {
/*  87: 87 */               checkBoxes_[i].setSelected(true);
/*  88:    */             }
/*  89:    */           }
/*  90:    */           
/*  91: 91 */           JButton applyButton = new JButton(new AbstractAction("OK")
/*  92:    */           {
/*  93:    */             public void actionPerformed(ActionEvent e)
/*  94:    */             {
/*  95: 95 */               selection_ = new ArrayList();
/*  96: 96 */               for (int j = 0; j < checkBoxes_.length; j++) {
/*  97: 97 */                 if (checkBoxes_[j].isSelected()) {
/*  98: 98 */                   selection_.add(enumValues_[j]);
/*  99:    */                 }
/* 100:    */               }
/* 101:101 */               dialog.setVisible(false);
/* 102:    */             }
/* 103:    */             
/* 104:104 */           });
/* 105:105 */           panel.add(choicesPanel, "Center");
/* 106:106 */           panel.add(applyButton, "South");
/* 107:    */           
/* 108:108 */           dialog.setContentPane(panel);
/* 109:109 */           dialog.setModal(true);
/* 110:110 */           dialog.pack();
/* 111:111 */           dialog.setVisible(true);
/* 112:    */         }
/* 113:    */       }
/* 114:114 */     });
/* 115:115 */     add(button, "East");
/* 116:    */   }
/* 117:    */ }
