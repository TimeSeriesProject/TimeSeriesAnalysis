/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.descriptors.EnhancedPropertyDescriptor;
/*   4:    */ import ec.tstoolkit.descriptors.IObjectDescriptor;
/*   5:    */ import ec.tstoolkit.timeseries.Day;
/*   6:    */ import ec.tstoolkit.timeseries.regression.Sequence;
/*   7:    */ import java.beans.IntrospectionException;
/*   8:    */ import java.beans.PropertyDescriptor;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ public class SequenceDescriptor
/*  18:    */   implements IObjectDescriptor<Sequence>
/*  19:    */ {
/*  20:    */   private final Sequence seq_;
/*  21:    */   private static final int START_ID = 1;
/*  22:    */   private static final int END_ID = 2;
/*  23:    */   
/*  24:    */   public String toString()
/*  25:    */   {
/*  26: 26 */     return seq_.toString();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public SequenceDescriptor() {
/*  30: 30 */     seq_ = new Sequence();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public SequenceDescriptor(Sequence seq) {
/*  34: 34 */     seq_ = seq;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Sequence getCore()
/*  38:    */   {
/*  39: 39 */     return seq_;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Day getStart() {
/*  43: 43 */     return seq_.getStart();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setStart(Day day) {
/*  47: 47 */     seq_.setStart(day);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Day getEnd() {
/*  51: 51 */     return seq_.getEnd();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setEnd(Day day) {
/*  55: 55 */     seq_.setEnd(day);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public List<EnhancedPropertyDescriptor> getProperties()
/*  59:    */   {
/*  60: 60 */     ArrayList<EnhancedPropertyDescriptor> descs = new ArrayList();
/*  61: 61 */     EnhancedPropertyDescriptor desc = startDesc();
/*  62: 62 */     if (desc != null) {
/*  63: 63 */       descs.add(desc);
/*  64:    */     }
/*  65: 65 */     desc = endDesc();
/*  66: 66 */     if (desc != null) {
/*  67: 67 */       descs.add(desc);
/*  68:    */     }
/*  69: 69 */     return descs;
/*  70:    */   }
/*  71:    */   
/*  72:    */   private EnhancedPropertyDescriptor startDesc()
/*  73:    */   {
/*  74:    */     try
/*  75:    */     {
/*  76: 76 */       PropertyDescriptor desc = new PropertyDescriptor("start", getClass());
/*  77: 77 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 1);
/*  78: 78 */       desc.setDisplayName("Start");
/*  79:    */       
/*  80: 80 */       return edesc;
/*  81:    */     } catch (IntrospectionException ex) {}
/*  82: 82 */     return null;
/*  83:    */   }
/*  84:    */   
/*  85:    */   private EnhancedPropertyDescriptor endDesc()
/*  86:    */   {
/*  87:    */     try {
/*  88: 88 */       PropertyDescriptor desc = new PropertyDescriptor("end", getClass());
/*  89: 89 */       EnhancedPropertyDescriptor edesc = new EnhancedPropertyDescriptor(desc, 2);
/*  90: 90 */       desc.setDisplayName("End");
/*  91:    */       
/*  92: 92 */       return edesc;
/*  93:    */     } catch (IntrospectionException ex) {}
/*  94: 94 */     return null;
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */   public String getDisplayName()
/*  99:    */   {
/* 100:100 */     return "Sequence";
/* 101:    */   }
/* 102:    */ }
