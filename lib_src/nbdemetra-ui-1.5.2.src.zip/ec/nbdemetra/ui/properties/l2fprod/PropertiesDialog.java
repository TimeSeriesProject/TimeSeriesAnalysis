/*  1:   */ package ec.nbdemetra.ui.properties.l2fprod;
/*  2:   */ 
/*  3:   */ import ec.ui.view.tsprocessing.ApplyAction;
/*  4:   */ import ec.ui.view.tsprocessing.IApplyAction;
/*  5:   */ import java.awt.BorderLayout;
/*  6:   */ import java.awt.Frame;
/*  7:   */ import java.awt.event.ActionEvent;
/*  8:   */ import java.awt.event.ActionListener;
/*  9:   */ import javax.swing.AbstractAction;
/* 10:   */ import javax.swing.Action;
/* 11:   */ import javax.swing.BorderFactory;
/* 12:   */ import javax.swing.Box;
/* 13:   */ import javax.swing.BoxLayout;
/* 14:   */ import javax.swing.JButton;
/* 15:   */ import javax.swing.JDialog;
/* 16:   */ import javax.swing.JPanel;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class PropertiesDialog
/* 21:   */   extends JDialog
/* 22:   */ {
/* 23:   */   private JButton bApply_;
/* 24:   */   private JButton bCancel_;
/* 25:   */   private Object clone_;
/* 26:   */   private Action applyAction_;
/* 27:   */   
/* 28:   */   @Deprecated
/* 29:   */   public PropertiesDialog(Frame owner, boolean modal, Object clone, IApplyAction change)
/* 30:   */   {
/* 31:31 */     this(owner, modal, clone, ApplyAction.toSwingAction(change));
/* 32:   */   }
/* 33:   */   
/* 34:   */   public PropertiesDialog(Frame owner, boolean modal, Object clone, Action applyAction) {
/* 35:35 */     super(owner, modal);
/* 36:   */     
/* 37:37 */     clone_ = clone;
/* 38:38 */     applyAction_ = applyAction;
/* 39:39 */     buildUI();
/* 40:40 */     pack();
/* 41:   */   }
/* 42:   */   
/* 43:   */   private void buildUI() {
/* 44:44 */     setLocationByPlatform(true);
/* 45:45 */     setLayout(new BorderLayout());
/* 46:   */     
/* 47:47 */     add(PropertiesPanelFactory.INSTANCE.createPanel(clone_), "Center");
/* 48:   */     
/* 49:49 */     bApply_ = new JButton(applyAction_);
/* 50:50 */     bApply_.addActionListener(new ActionListener()
/* 51:   */     {
/* 52:   */       public void actionPerformed(ActionEvent e) {
/* 53:53 */         setVisible(false);
/* 54:   */       }
/* 55:   */       
/* 56:56 */     });
/* 57:57 */     bCancel_ = new JButton(new AbstractAction(isModal() ? "Cancel" : "Close")
/* 58:   */     {
/* 59:   */       public void actionPerformed(ActionEvent e) {
/* 60:60 */         setVisible(false);
/* 61:   */       }
/* 62:   */       
/* 63:63 */     });
/* 64:64 */     JPanel buttonsPane = new JPanel();
/* 65:65 */     BoxLayout boxes = new BoxLayout(buttonsPane, 2);
/* 66:66 */     buttonsPane.setLayout(boxes);
/* 67:67 */     buttonsPane.add(Box.createHorizontalGlue());
/* 68:68 */     buttonsPane.add(bApply_);
/* 69:69 */     buttonsPane.add(bCancel_);
/* 70:70 */     buttonsPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/* 71:   */     
/* 72:72 */     add(buttonsPane, "South");
/* 73:   */   }
/* 74:   */ }
