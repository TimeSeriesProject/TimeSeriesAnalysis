/*   1:    */ package ec.nbdemetra.ui.properties.l2fprod;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.Lists;
/*   4:    */ import com.l2fprod.common.propertysheet.PropertySheetPanel;
/*   5:    */ import com.l2fprod.common.propertysheet.PropertySheetTableModel;
/*   6:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.Window;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import java.awt.event.ActionListener;
/*  11:    */ import java.awt.event.FocusEvent;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.io.PrintStream;
/*  14:    */ import java.lang.reflect.Constructor;
/*  15:    */ import java.lang.reflect.InvocationTargetException;
/*  16:    */ import java.util.ArrayList;
/*  17:    */ import javax.swing.BorderFactory;
/*  18:    */ import javax.swing.Box;
/*  19:    */ import javax.swing.BoxLayout;
/*  20:    */ import javax.swing.JButton;
/*  21:    */ import javax.swing.JDialog;
/*  22:    */ import javax.swing.JList;
/*  23:    */ import javax.swing.JPanel;
/*  24:    */ import javax.swing.SwingUtilities;
/*  25:    */ import javax.swing.event.ListSelectionEvent;
/*  26:    */ 
/*  27:    */ public class ArrayEditorDialog<T> extends JDialog
/*  28:    */ {
/*  29:    */   private Class<T> c_;
/*  30:    */   private ArrayList<T> elementsList_;
/*  31:    */   private T cur_;
/*  32:    */   private boolean dirty_;
/*  33:    */   
/*  34:    */   public java.util.List<T> getElements()
/*  35:    */   {
/*  36: 36 */     return elementsList_;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean isDirty() {
/*  40: 40 */     return dirty_;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public ArrayEditorDialog(Window owner, T[] elements, Class<T> c) {
/*  44: 44 */     super(owner);
/*  45: 45 */     c_ = c;
/*  46: 46 */     elementsList_ = Lists.newArrayList(elements);
/*  47:    */     
/*  48:    */ 
/*  49: 49 */     JPanel pane = new JPanel(new java.awt.BorderLayout());
/*  50: 50 */     pane.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
/*  51:    */     
/*  52: 52 */     final JList list = new JList(new ArrayEditorListModel(elementsList_));
/*  53: 53 */     list.setSelectionMode(0);
/*  54: 54 */     list.setPreferredSize(new Dimension(150, 200));
/*  55: 55 */     pane.add(ec.nbdemetra.ui.NbComponents.newJScrollPane(list), "West");
/*  56:    */     
/*  57: 57 */     final PropertySheetTableModel model = new PropertySheetTableModel();
/*  58: 58 */     PropertySheetPanel psp = new PropertySheetPanel(new com.l2fprod.common.propertysheet.PropertySheetTable(model));
/*  59: 59 */     psp.setToolBarVisible(false);
/*  60: 60 */     psp.setEditorFactory(CustomPropertyEditorRegistry.INSTANCE.getRegistry());
/*  61: 61 */     psp.setRendererFactory(CustomPropertyRendererFactory.INSTANCE.getRegistry());
/*  62: 62 */     psp.setDescriptionVisible(true);
/*  63: 63 */     psp.setMode(1);
/*  64: 64 */     pane.add(psp, "Center");
/*  65: 65 */     psp.setPreferredSize(new Dimension(250, 200));
/*  66: 66 */     psp.setBorder(BorderFactory.createEtchedBorder());
/*  67:    */     
/*  68: 68 */     list.addListSelectionListener(new javax.swing.event.ListSelectionListener()
/*  69:    */     {
/*  70:    */       public void valueChanged(ListSelectionEvent e)
/*  71:    */       {
/*  72: 72 */         if (list.getSelectedValue() != null) {
/*  73: 73 */           model.setProperties(PropertiesPanelFactory.INSTANCE.createProperties(list.getSelectedValue()));
/*  74: 74 */           cur_ = list.getSelectedValue();
/*  75:    */         }
/*  76:    */         else {
/*  77: 77 */           cur_ = null;
/*  78: 78 */           model.setProperties(new com.l2fprod.common.propertysheet.Property[0]);
/*  79:    */         }
/*  80:    */         
/*  81:    */       }
/*  82: 82 */     });
/*  83: 83 */     psp.addFocusListener(new java.awt.event.FocusListener()
/*  84:    */     {
/*  85:    */       public void focusGained(FocusEvent e) {}
/*  86:    */       
/*  87:    */ 
/*  88:    */ 
/*  89:    */       public void focusLost(FocusEvent e)
/*  90:    */       {
/*  91: 91 */         if (dirty_) {
/*  92: 92 */           list.setModel(new ArrayEditorListModel(elementsList_));
/*  93: 93 */           list.invalidate();
/*  94:    */         }
/*  95:    */         
/*  96:    */       }
/*  97: 97 */     });
/*  98: 98 */     model.addPropertyChangeListener(new java.beans.PropertyChangeListener()
/*  99:    */     {
/* 100:    */       public void propertyChange(PropertyChangeEvent evt)
/* 101:    */       {
/* 102:102 */         dirty_ = true;
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */       }
/* 108:    */       
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:113 */     });
/* 114:114 */     JPanel buttonPane = new JPanel();
/* 115:115 */     BoxLayout layout = new BoxLayout(buttonPane, 2);
/* 116:116 */     buttonPane.setLayout(layout);
/* 117:117 */     JButton addButton = new JButton(DemetraUiIcon.LIST_ADD_16);
/* 118:118 */     addButton.setPreferredSize(new Dimension(30, 30));
/* 119:119 */     addButton.setFocusPainted(false);
/* 120:120 */     addButton.addActionListener(new ActionListener()
/* 121:    */     {
/* 122:    */       public void actionPerformed(ActionEvent e)
/* 123:    */       {
/* 124:124 */         dirty_ = true;
/* 125:    */         try {
/* 126:126 */           Constructor<T> constructor = c_.getConstructor(new Class[0]);
/* 127:127 */           final T o = constructor.newInstance(new Object[0]);
/* 128:128 */           elementsList_.add(o);
/* 129:129 */           SwingUtilities.invokeLater(new Runnable()
/* 130:    */           {
/* 131:    */             public void run()
/* 132:    */             {
/* 133:133 */               val$list.setModel(new ArrayEditorListModel(elementsList_));
/* 134:134 */               val$list.setSelectedValue(o, true);
/* 135:135 */               val$list.invalidate();
/* 136:    */             }
/* 137:    */           });
/* 138:    */         }
/* 139:    */         catch (NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|IllegalArgumentException|InvocationTargetException ex)
/* 140:    */         {
/* 141:141 */           System.err.println(ex.getMessage());
/* 142:    */         }
/* 143:    */       }
/* 144:144 */     });
/* 145:145 */     buttonPane.add(addButton);
/* 146:146 */     JButton deleteButton = new JButton(DemetraUiIcon.LIST_REMOVE_16);
/* 147:147 */     deleteButton.setPreferredSize(new Dimension(30, 30));
/* 148:148 */     deleteButton.setFocusPainted(false);
/* 149:149 */     deleteButton.addActionListener(new ActionListener()
/* 150:    */     {
/* 151:    */       public void actionPerformed(ActionEvent e)
/* 152:    */       {
/* 153:    */         try {
/* 154:154 */           if (cur_ == null) {
/* 155:155 */             return;
/* 156:    */           }
/* 157:157 */           dirty_ = true;
/* 158:158 */           elementsList_.remove(cur_);
/* 159:159 */           SwingUtilities.invokeLater(new Runnable()
/* 160:    */           {
/* 161:    */             public void run()
/* 162:    */             {
/* 163:163 */               val$list.setModel(new ArrayEditorListModel(elementsList_));
/* 164:164 */               val$list.invalidate();
/* 165:    */             }
/* 166:    */           });
/* 167:    */         }
/* 168:    */         catch (Exception ex)
/* 169:    */         {
/* 170:170 */           System.err.println(ex.getMessage());
/* 171:    */         }
/* 172:    */       }
/* 173:173 */     });
/* 174:174 */     buttonPane.add(deleteButton);
/* 175:175 */     buttonPane.add(Box.createGlue());
/* 176:176 */     JButton okButton = new JButton("Done");
/* 177:177 */     okButton.setPreferredSize(new Dimension(60, 27));
/* 178:178 */     okButton.setFocusPainted(false);
/* 179:179 */     okButton.addActionListener(new ActionListener()
/* 180:    */     {
/* 181:    */       public void actionPerformed(ActionEvent e)
/* 182:    */       {
/* 183:183 */         setVisible(false);
/* 184:    */       }
/* 185:185 */     });
/* 186:186 */     buttonPane.add(okButton);
/* 187:187 */     buttonPane.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));
/* 188:188 */     pane.add(buttonPane, "South");
/* 189:189 */     pane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/* 190:    */     
/* 191:191 */     setMinimumSize(new Dimension(400, 200));
/* 192:192 */     setContentPane(pane);
/* 193:193 */     pack();
/* 194:194 */     setModal(true);
/* 195:    */   }
/* 196:    */ }
