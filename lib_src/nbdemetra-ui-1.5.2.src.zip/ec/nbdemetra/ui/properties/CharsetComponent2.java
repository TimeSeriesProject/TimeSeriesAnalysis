/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.completion.JAutoCompletionService;
/*   4:    */ import ec.tss.tsproviders.utils.Parsers;
/*   5:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*   6:    */ import ec.util.various.swing.TextPrompt;
/*   7:    */ import java.awt.BorderLayout;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import java.nio.charset.Charset;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ import javax.swing.JComponent;
/*  13:    */ import javax.swing.JTextField;
/*  14:    */ import javax.swing.border.Border;
/*  15:    */ import javax.swing.event.DocumentEvent;
/*  16:    */ import javax.swing.event.DocumentListener;
/*  17:    */ import javax.swing.text.Document;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ public class CharsetComponent2
/*  38:    */   extends JComponent
/*  39:    */ {
/*  40:    */   public static final String CHARSET_PROPERTY = "charset";
/*  41:    */   private final JTextField textField;
/*  42:    */   private final Listener listener;
/*  43:    */   private Charset charset;
/*  44:    */   
/*  45:    */   public CharsetComponent2()
/*  46:    */   {
/*  47: 47 */     textField = new JTextField();
/*  48: 48 */     listener = new Listener(null);
/*  49: 49 */     charset = null;
/*  50:    */     
/*  51: 51 */     JAutoCompletionService.forPathBind("JAutoCompletionService/Charset", textField);
/*  52:    */     
/*  53: 53 */     new TextPrompt(Charset.defaultCharset().name(), textField).setEnabled(false);
/*  54:    */     
/*  55: 55 */     onCharsetChange();
/*  56:    */     
/*  57: 57 */     textField.getDocument().addDocumentListener(listener);
/*  58:    */     
/*  59: 59 */     addPropertyChangeListener(new PropertyChangeListener()
/*  60:    */     {
/*  61:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  62: 62 */         String p = evt.getPropertyName();
/*  63: 63 */         if (p.equals("charset")) {
/*  64: 64 */           CharsetComponent2.this.onCharsetChange();
/*  65:    */         }
/*  66:    */         
/*  67:    */       }
/*  68: 68 */     });
/*  69: 69 */     setLayout(new BorderLayout());
/*  70: 70 */     add(textField);
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void onCharsetChange() {
/*  74: 74 */     if (listener.enabled) {
/*  75: 75 */       listener.enabled = false;
/*  76: 76 */       textField.setText(charset != null ? charset.name() : "");
/*  77: 77 */       listener.enabled = true;
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   @Nullable
/*  82:    */   public Charset getCharset() {
/*  83: 83 */     return charset;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setCharset(@Nullable Charset value) {
/*  87: 87 */     Charset old = charset;
/*  88: 88 */     charset = value;
/*  89: 89 */     firePropertyChange("charset", old, charset);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private class Listener implements DocumentListener
/*  93:    */   {
/*  94: 94 */     boolean enabled = true;
/*  95:    */     
/*  96:    */     private Listener() {}
/*  97:    */     
/*  98: 98 */     public void removeUpdate(DocumentEvent e) { changedUpdate(e); }
/*  99:    */     
/* 100:    */ 
/* 101:    */     public void insertUpdate(DocumentEvent e)
/* 102:    */     {
/* 103:103 */       changedUpdate(e);
/* 104:    */     }
/* 105:    */     
/* 106:    */     public void changedUpdate(DocumentEvent e)
/* 107:    */     {
/* 108:108 */       if (enabled) {
/* 109:109 */         enabled = false;
/* 110:110 */         if (textField.getText().isEmpty()) {
/* 111:111 */           setCharset(null);
/* 112:    */         } else {
/* 113:113 */           Charset charset = (Charset)Parsers.charsetParser().parse(textField.getText());
/* 114:114 */           if (charset != null) {
/* 115:115 */             setCharset(charset);
/* 116:    */           }
/* 117:    */         }
/* 118:118 */         enabled = true;
/* 119:    */       }
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void requestFocus()
/* 124:    */   {
/* 125:125 */     textField.requestFocus();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setBorder(Border border)
/* 129:    */   {
/* 130:130 */     textField.setBorder(border);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public Border getBorder()
/* 134:    */   {
/* 135:135 */     return textField.getBorder();
/* 136:    */   }
/* 137:    */ }
