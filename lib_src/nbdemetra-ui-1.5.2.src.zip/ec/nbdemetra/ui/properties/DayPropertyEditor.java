/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import com.toedter.calendar.JDateChooser;
/*  4:   */ import ec.tstoolkit.timeseries.Day;
/*  5:   */ import java.beans.PropertyChangeEvent;
/*  6:   */ import java.beans.PropertyChangeListener;
/*  7:   */ import java.util.Date;
/*  8:   */ import javax.swing.JComponent;
/*  9:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/* 10:   */ import org.openide.nodes.PropertyEditorRegistration;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ @PropertyEditorRegistration(targetType={Day.class})
/* 20:   */ public class DayPropertyEditor
/* 21:   */   extends AbstractExPropertyEditor
/* 22:   */ {
/* 23:   */   protected InplaceEditor createInplaceEditor()
/* 24:   */   {
/* 25:25 */     new AbstractInplaceEditor()
/* 26:   */     {
/* 27:   */       final JDateChooser component;
/* 28:   */       
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */       public JComponent getComponent()
/* 38:   */       {
/* 39:39 */         return component;
/* 40:   */       }
/* 41:   */       
/* 42:   */       public Object getValue()
/* 43:   */       {
/* 44:44 */         Date date = component.getDate();
/* 45:45 */         return date != null ? new Day(date) : null;
/* 46:   */       }
/* 47:   */       
/* 48:   */       public void setValue(Object o)
/* 49:   */       {
/* 50:50 */         Day day = (Day)o;
/* 51:51 */         component.setDate(o != null ? day.getTime() : null);
/* 52:   */       }
/* 53:   */     };
/* 54:   */   }
/* 55:   */ }
