/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.util.completion.AutoCompletionSource;
/*  4:   */ import javax.swing.text.JTextComponent;
/*  5:   */ 
/*  6:   */ @Deprecated
/*  7:   */ public class AutoCompleteDocument extends javax.swing.text.PlainDocument
/*  8:   */ {
/*  9:   */   final JTextComponent textComponent;
/* 10:   */   AutoCompletionSource autoCompletion;
/* 11:   */   String separator;
/* 12:   */   
/* 13:   */   public static AutoCompleteDocument on(JTextComponent textComponent, AutoCompletionSource autoCompletion, String separator)
/* 14:   */   {
/* 15:15 */     AutoCompleteDocument doc = new AutoCompleteDocument(textComponent, autoCompletion, separator);
/* 16:16 */     textComponent.setDocument(doc);
/* 17:17 */     return doc;
/* 18:   */   }
/* 19:   */   
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */   public AutoCompleteDocument(JTextComponent textComponent, AutoCompletionSource autoCompletion, String separator)
/* 24:   */   {
/* 25:25 */     this.textComponent = textComponent;
/* 26:26 */     this.autoCompletion = autoCompletion;
/* 27:27 */     this.separator = separator;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setAutoCompletion(AutoCompletionSource autoCompletion) {
/* 31:31 */     this.autoCompletion = autoCompletion;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setSeparator(String separator) {
/* 35:35 */     this.separator = separator;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void insertString(int offs, String str, javax.swing.text.AttributeSet a) throws javax.swing.text.BadLocationException
/* 39:   */   {
/* 40:40 */     super.insertString(offs, str, a);
/* 41:   */     
/* 42:42 */     String all = getText(0, getLength());
/* 43:   */     
/* 44:44 */     int start = com.google.common.base.Strings.isNullOrEmpty(separator) ? 0 : all.lastIndexOf(separator) + separator.length();
/* 45:   */     
/* 46:   */ 
/* 47:47 */     String target = all.substring(start);
/* 48:   */     try {
/* 49:49 */       java.util.List<?> values = autoCompletion.getValues(target);
/* 50:50 */       for (Object o : values) {
/* 51:51 */         String tmp = autoCompletion.toString(o);
/* 52:52 */         if (tmp.startsWith(target)) {
/* 53:53 */           String word = tmp.substring(target.length());
/* 54:54 */           super.insertString(offs + str.length(), word, a);
/* 55:55 */           textComponent.setCaretPosition(offs + str.length());
/* 56:56 */           textComponent.moveCaretPosition(getLength());
/* 57:57 */           break;
/* 58:   */         }
/* 59:   */       }
/* 60:   */     }
/* 61:   */     catch (Exception localException) {}
/* 62:   */   }
/* 63:   */ }
