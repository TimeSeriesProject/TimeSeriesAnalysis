/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import java.awt.event.ActionListener;
/*  5:   */ import java.beans.FeatureDescriptor;
/*  6:   */ import java.beans.PropertyEditor;
/*  7:   */ import javax.swing.DefaultComboBoxModel;
/*  8:   */ import javax.swing.JComboBox;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.KeyStroke;
/* 11:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/* 12:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class ComboBoxPropertyEditor
/* 22:   */   extends AbstractExPropertyEditor
/* 23:   */ {
/* 24:   */   public static final String VALUES_ATTRIBUTE = "values";
/* 25:   */   
/* 26:   */   public InplaceEditor createInplaceEditor()
/* 27:   */   {
/* 28:28 */     new AbstractInplaceEditor()
/* 29:   */     {
/* 30:   */       final JComboBox component;
/* 31:   */       
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */       final KeyStroke[] keyStrokes;
/* 41:   */       
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */       public void connect(PropertyEditor propertyEditor, PropertyEnv env)
/* 51:   */       {
/* 52:52 */         Object values = env.getFeatureDescriptor().getValue("values");
/* 53:53 */         DefaultComboBoxModel cbModel = (DefaultComboBoxModel)component.getModel();
/* 54:54 */         cbModel.removeAllElements();
/* 55:55 */         if ((values instanceof Object[])) {
/* 56:56 */           for (Object o : (Object[])values) {
/* 57:57 */             cbModel.addElement(o);
/* 58:   */           }
/* 59:   */         }
/* 60:60 */         super.connect(propertyEditor, env);
/* 61:   */       }
/* 62:   */       
/* 63:   */       public JComponent getComponent()
/* 64:   */       {
/* 65:65 */         return component;
/* 66:   */       }
/* 67:   */       
/* 68:   */       public Object getValue()
/* 69:   */       {
/* 70:70 */         return component.getSelectedItem();
/* 71:   */       }
/* 72:   */       
/* 73:   */       public void setValue(Object o)
/* 74:   */       {
/* 75:75 */         component.setSelectedItem(o);
/* 76:   */       }
/* 77:   */       
/* 78:   */       public KeyStroke[] getKeyStrokes()
/* 79:   */       {
/* 80:80 */         return keyStrokes;
/* 81:   */       }
/* 82:   */     };
/* 83:   */   }
/* 84:   */ }
