/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import java.beans.PropertyEditor;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import org.openide.nodes.Node.Property;
/*   6:    */ import org.openide.nodes.PropertySupport.ReadOnly;
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ public abstract class ForwardingNodeProperty<T>
/*  15:    */   extends Node.Property<T>
/*  16:    */ {
/*  17:    */   final Node.Property<T> p;
/*  18:    */   
/*  19:    */   public ForwardingNodeProperty(Node.Property<T> p)
/*  20:    */   {
/*  21: 21 */     super(p.getValueType());
/*  22: 22 */     this.p = p;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public String getDisplayName()
/*  26:    */   {
/*  27: 27 */     return p.getDisplayName();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setDisplayName(String displayName)
/*  31:    */   {
/*  32: 32 */     p.setDisplayName(displayName);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public String getHtmlDisplayName()
/*  36:    */   {
/*  37: 37 */     return p.getHtmlDisplayName();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String getName()
/*  41:    */   {
/*  42: 42 */     return p.getName();
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setName(String name)
/*  46:    */   {
/*  47: 47 */     p.setName(name);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getShortDescription()
/*  51:    */   {
/*  52: 52 */     return p.getShortDescription();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setShortDescription(String text)
/*  56:    */   {
/*  57: 57 */     p.setShortDescription(text);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public PropertyEditor getPropertyEditor()
/*  61:    */   {
/*  62: 62 */     return p.getPropertyEditor();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean canRead()
/*  66:    */   {
/*  67: 67 */     return p.canRead();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean canWrite()
/*  71:    */   {
/*  72: 72 */     return p.canWrite();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public T getValue() throws IllegalAccessException, InvocationTargetException
/*  76:    */   {
/*  77: 77 */     return p.getValue();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setValue(T val) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*  81:    */   {
/*  82: 82 */     p.setValue(val);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Object getValue(String attributeName)
/*  86:    */   {
/*  87: 87 */     return p.getValue(attributeName);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setValue(String attributeName, Object value)
/*  91:    */   {
/*  92: 92 */     p.setValue(attributeName, value);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public boolean isDefaultValue()
/*  96:    */   {
/*  97: 97 */     return p.isDefaultValue();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean supportsDefaultValue()
/* 101:    */   {
/* 102:102 */     return p.supportsDefaultValue();
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void restoreDefaultValue() throws IllegalAccessException, InvocationTargetException
/* 106:    */   {
/* 107:107 */     p.restoreDefaultValue();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static <T> Node.Property<T> readOnly(Node.Property<T> p) {
/* 111:111 */     return ((p instanceof PropertySupport.ReadOnly)) || ((p instanceof ReadOnly)) ? p : new ReadOnly(p);
/* 112:    */   }
/* 113:    */   
/* 114:    */   private static class ReadOnly<T> extends ForwardingNodeProperty<T>
/* 115:    */   {
/* 116:    */     ReadOnly(Node.Property<T> p) {
/* 117:117 */       super();
/* 118:    */     }
/* 119:    */     
/* 120:    */     public boolean canWrite()
/* 121:    */     {
/* 122:122 */       return false;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public void setValue(Object val) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 126:    */     {
/* 127:127 */       throw new UnsupportedOperationException("Not supported yet.");
/* 128:    */     }
/* 129:    */   }
/* 130:    */ }
