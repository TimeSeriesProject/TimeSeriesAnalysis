/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.tss.TsMoniker;
/*  4:   */ import java.beans.PropertyEditorSupport;
/*  5:   */ import org.openide.nodes.PropertyEditorRegistration;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ @PropertyEditorRegistration(targetType={TsMoniker.class})
/* 15:   */ public class TsMonikerPropertyEditor
/* 16:   */   extends PropertyEditorSupport
/* 17:   */ {
/* 18:   */   public String getAsText()
/* 19:   */   {
/* 20:20 */     TsMoniker moniker = (TsMoniker)getValue();
/* 21:21 */     return moniker != null ? moniker.toString() : "";
/* 22:   */   }
/* 23:   */ }
