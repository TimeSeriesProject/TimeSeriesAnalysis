/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.tss.tsproviders.IFileLoader;
/*  4:   */ import java.io.File;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ public class FileLoaderFileFilter
/* 12:   */   extends javax.swing.filechooser.FileFilter
/* 13:   */   implements java.io.FileFilter
/* 14:   */ {
/* 15:   */   final IFileLoader loader;
/* 16:   */   
/* 17:   */   public FileLoaderFileFilter(IFileLoader loader)
/* 18:   */   {
/* 19:19 */     this.loader = loader;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean accept(File file)
/* 23:   */   {
/* 24:24 */     return (file.isDirectory()) || (loader.accept(file));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getDescription()
/* 28:   */   {
/* 29:29 */     return loader.getFileDescription();
/* 30:   */   }
/* 31:   */ }
