/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.beans.PropertyChangeEvent;
/*  5:   */ import java.beans.PropertyChangeListener;
/*  6:   */ import java.beans.PropertyEditorSupport;
/*  7:   */ import java.util.ArrayList;
/*  8:   */ import java.util.List;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class ListSelectionEditor<T>
/* 18:   */   extends PropertyEditorSupport
/* 19:   */ {
/* 20:   */   private final List<T> all;
/* 21:21 */   private final ListSelection<T> component = new ListSelection();
/* 22:   */   
/* 23:   */   public ListSelectionEditor(List<T> allValues)
/* 24:   */   {
/* 25:25 */     all = allValues;
/* 26:26 */     component.addPropertyChangeListener(new PropertyChangeListener()
/* 27:   */     {
/* 28:   */       public void propertyChange(PropertyChangeEvent evt)
/* 29:   */       {
/* 30:30 */         if (evt.getPropertyName().equals("SelectionChanged")) {
/* 31:31 */           setValue(evt.getNewValue());
/* 32:   */         }
/* 33:   */       }
/* 34:   */     });
/* 35:   */   }
/* 36:   */   
/* 37:   */   public boolean supportsCustomEditor()
/* 38:   */   {
/* 39:39 */     return true;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Component getCustomEditor()
/* 43:   */   {
/* 44:44 */     List<T> sel = (List)getValue();
/* 45:45 */     ArrayList<T> tmpAll = new ArrayList(all);
/* 46:46 */     ArrayList<T> tmpSel = sel != null ? new ArrayList(sel) : new ArrayList();
/* 47:47 */     tmpAll.removeAll(tmpSel);
/* 48:48 */     component.set(tmpAll, tmpSel);
/* 49:49 */     return component;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String getAsText()
/* 53:   */   {
/* 54:54 */     return super.getAsText();
/* 55:   */   }
/* 56:   */ }
