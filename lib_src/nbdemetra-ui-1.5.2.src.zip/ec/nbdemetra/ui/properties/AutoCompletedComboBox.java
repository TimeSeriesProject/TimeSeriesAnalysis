/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.util.completion.AutoCompletionSource;
/*  4:   */ import ec.util.completion.AutoCompletionSources;
/*  5:   */ import javax.swing.BorderFactory;
/*  6:   */ import javax.swing.ComboBoxEditor;
/*  7:   */ import javax.swing.DefaultComboBoxModel;
/*  8:   */ import javax.swing.JComboBox;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.text.JTextComponent;
/* 11:   */ 
/* 12:   */ @Deprecated
/* 13:   */ public abstract class AutoCompletedComboBox<T> extends JComponent
/* 14:   */ {
/* 15:   */   protected final JTextComponent textComponent;
/* 16:   */   protected final DefaultComboBoxModel model;
/* 17:   */   protected final AutoCompleteDocument autoCompleteDocument;
/* 18:   */   
/* 19:   */   public AutoCompletedComboBox()
/* 20:   */   {
/* 21:21 */     model = new DefaultComboBoxModel();
/* 22:   */     
/* 23:23 */     JComboBox comboBox = new JComboBox(model);
/* 24:24 */     comboBox.setBorder(BorderFactory.createEmptyBorder());
/* 25:25 */     comboBox.setEditable(true);
/* 26:26 */     comboBox.setSelectedIndex(-1);
/* 27:   */     
/* 28:28 */     textComponent = ((JTextComponent)comboBox.getEditor().getEditorComponent());
/* 29:29 */     autoCompleteDocument = AutoCompleteDocument.on(textComponent, AutoCompletionSources.empty(), null);
/* 30:   */     
/* 31:31 */     setLayout(new java.awt.BorderLayout());
/* 32:32 */     add(comboBox, "Center");
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setAutoCompletion(AutoCompletionSource autoCompletion) {
/* 36:36 */     model.removeAllElements();
/* 37:   */     try {
/* 38:38 */       for (Object o : autoCompletion.getValues("")) {
/* 39:39 */         model.addElement(o);
/* 40:   */       }
/* 41:   */     }
/* 42:   */     catch (Exception localException) {}
/* 43:   */     
/* 44:44 */     autoCompleteDocument.setAutoCompletion(autoCompletion);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setSeparator(String separator) {
/* 48:48 */     autoCompleteDocument.setSeparator(separator);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public abstract T getValue();
/* 52:   */   
/* 53:   */   public abstract void setValue(T paramT);
/* 54:   */ }
