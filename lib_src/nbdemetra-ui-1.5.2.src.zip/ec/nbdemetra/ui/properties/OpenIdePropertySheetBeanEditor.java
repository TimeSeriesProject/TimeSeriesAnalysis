/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.AbstractNodeBuilder;
/*  4:   */ import java.awt.Dialog;
/*  5:   */ import java.awt.Image;
/*  6:   */ import java.beans.IntrospectionException;
/*  7:   */ import javax.annotation.Nonnull;
/*  8:   */ import javax.annotation.Nullable;
/*  9:   */ import org.openide.DialogDescriptor;
/* 10:   */ import org.openide.DialogDisplayer;
/* 11:   */ import org.openide.explorer.propertysheet.PropertySheet;
/* 12:   */ import org.openide.nodes.BeanNode;
/* 13:   */ import org.openide.nodes.Node;
/* 14:   */ import org.openide.nodes.Sheet;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ public class OpenIdePropertySheetBeanEditor
/* 35:   */   implements IBeanEditor
/* 36:   */ {
/* 37:   */   final String title;
/* 38:   */   final Image image;
/* 39:   */   
/* 40:   */   public OpenIdePropertySheetBeanEditor(String title, Image image)
/* 41:   */   {
/* 42:42 */     this.title = title;
/* 43:43 */     this.image = image;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public boolean editBean(Object bean) throws IntrospectionException
/* 47:   */   {
/* 48:48 */     return editNode(new BeanNode(bean), title, image);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public static boolean editNode(@Nonnull Node node, @Nullable String title, @Nullable Image image) {
/* 52:52 */     PropertySheet v = new PropertySheet();
/* 53:53 */     v.setNodes(new Node[] { node });
/* 54:   */     
/* 55:55 */     DialogDescriptor d = new DialogDescriptor(v, title);
/* 56:56 */     Dialog dialog = DialogDisplayer.getDefault().createDialog(d);
/* 57:57 */     if (image != null) {
/* 58:58 */       dialog.setIconImage(image);
/* 59:   */     }
/* 60:60 */     dialog.setVisible(true);
/* 61:   */     
/* 62:62 */     return d.getValue() == DialogDescriptor.OK_OPTION;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static boolean editSheet(@Nonnull Sheet sheet, @Nullable String title, @Nullable Image image) {
/* 66:66 */     Node node = new AbstractNodeBuilder().sheet(sheet).build();
/* 67:67 */     return editNode(node, title, image);
/* 68:   */   }
/* 69:   */ }
