/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import java.awt.AWTEvent;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.EventQueue;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.awt.event.ActionListener;
/*   9:    */ import java.awt.event.InputEvent;
/*  10:    */ import java.beans.FeatureDescriptor;
/*  11:    */ import java.beans.PropertyEditor;
/*  12:    */ import javax.swing.JComponent;
/*  13:    */ import javax.swing.KeyStroke;
/*  14:    */ import javax.swing.event.EventListenerList;
/*  15:    */ import org.openide.explorer.propertysheet.InplaceEditor;
/*  16:    */ import org.openide.explorer.propertysheet.PropertyEnv;
/*  17:    */ import org.openide.explorer.propertysheet.PropertyModel;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ public abstract class AbstractInplaceEditor
/*  25:    */   implements InplaceEditor
/*  26:    */ {
/*  27:    */   protected final EventListenerList listenerList;
/*  28:    */   protected PropertyEditor editor;
/*  29:    */   protected PropertyModel model;
/*  30:    */   
/*  31:    */   protected AbstractInplaceEditor()
/*  32:    */   {
/*  33: 33 */     listenerList = new EventListenerList();
/*  34: 34 */     editor = null;
/*  35: 35 */     model = null;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void connect(PropertyEditor propertyEditor, PropertyEnv env)
/*  39:    */   {
/*  40: 40 */     editor = propertyEditor;
/*  41: 41 */     reset();
/*  42:    */   }
/*  43:    */   
/*  44:    */ 
/*  45:    */   public void clear()
/*  46:    */   {
/*  47: 47 */     editor = null;
/*  48: 48 */     model = null;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean supportsTextEntry()
/*  52:    */   {
/*  53: 53 */     return true;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void reset()
/*  57:    */   {
/*  58: 58 */     Object d = editor.getValue();
/*  59: 59 */     if (d != null) {
/*  60: 60 */       setValue(d);
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   public KeyStroke[] getKeyStrokes()
/*  65:    */   {
/*  66: 66 */     return new KeyStroke[0];
/*  67:    */   }
/*  68:    */   
/*  69:    */   public PropertyEditor getPropertyEditor()
/*  70:    */   {
/*  71: 71 */     return editor;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public PropertyModel getPropertyModel()
/*  75:    */   {
/*  76: 76 */     return model;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setPropertyModel(PropertyModel propertyModel)
/*  80:    */   {
/*  81: 81 */     model = propertyModel;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isKnownComponent(Component component)
/*  85:    */   {
/*  86: 86 */     return (component == getComponent()) || (getComponent().isAncestorOf(component));
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   protected void fireActionPerformed(String command)
/*  93:    */   {
/*  94: 94 */     Object[] listeners = listenerList.getListenerList();
/*  95:    */     
/*  96: 96 */     ActionEvent e = new ActionEvent(this, 1001, command, 
/*  97: 97 */       EventQueue.getMostRecentEventTime(), getModifiers());
/*  98:    */     
/*  99:    */ 
/* 100:    */ 
/* 101:101 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 102:102 */       if (listeners[i] == ActionListener.class) {
/* 103:103 */         ((ActionListener)listeners[(i + 1)]).actionPerformed(e);
/* 104:    */       }
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   protected int getModifiers() {
/* 109:109 */     AWTEvent currentEvent = EventQueue.getCurrentEvent();
/* 110:110 */     if ((currentEvent instanceof InputEvent)) {
/* 111:111 */       return ((InputEvent)currentEvent).getModifiers();
/* 112:    */     }
/* 113:113 */     if ((currentEvent instanceof ActionEvent)) {
/* 114:114 */       return ((ActionEvent)currentEvent).getModifiers();
/* 115:    */     }
/* 116:116 */     return 0;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void addActionListener(ActionListener actionListener)
/* 120:    */   {
/* 121:121 */     listenerList.add(ActionListener.class, actionListener);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void removeActionListener(ActionListener actionListener)
/* 125:    */   {
/* 126:126 */     listenerList.remove(ActionListener.class, actionListener);
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected static <T> T getAttribute(PropertyEnv env, String attrName, Class<T> attrType, T defaultValue) {
/* 130:130 */     Object value = env.getFeatureDescriptor().getValue(attrName);
/* 131:131 */     return attrType.isInstance(value) ? attrType.cast(value) : defaultValue;
/* 132:    */   }
/* 133:    */   
/* 134:    */   protected <T> Optional<T> getAttribute(PropertyEnv env, String attrName, Class<T> attrType) {
/* 135:135 */     Object value = env.getFeatureDescriptor().getValue(attrName);
/* 136:136 */     return attrType.isInstance(value) ? Optional.of(attrType.cast(value)) : Optional.absent();
/* 137:    */   }
/* 138:    */ }
