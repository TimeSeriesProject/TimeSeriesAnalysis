/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import java.awt.Graphics;
/*   4:    */ import java.awt.Rectangle;
/*   5:    */ import java.beans.PropertyEditorSupport;
/*   6:    */ import java.util.regex.Matcher;
/*   7:    */ import java.util.regex.Pattern;
/*   8:    */ import javax.swing.JLabel;
/*   9:    */ import javax.swing.border.EmptyBorder;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ public class DhmsPropertyEditor
/*  14:    */   extends PropertyEditorSupport
/*  15:    */ {
/*  16:    */   final JLabel painter;
/*  17:    */   private static final long ONE_SECOND = 1000L;
/*  18:    */   private static final long SECONDS = 60L;
/*  19:    */   private static final long MINUTES = 60L;
/*  20:    */   private static final long HOURS = 24L;
/*  21:    */   
/*  22:    */   public DhmsPropertyEditor()
/*  23:    */   {
/*  24: 24 */     painter = new JLabel();
/*  25:    */     
/*  26: 26 */     painter.setBorder(new EmptyBorder(0, 3, 0, 0));
/*  27:    */   }
/*  28:    */   
/*  29:    */   public String getAsText()
/*  30:    */   {
/*  31: 31 */     Object value = getValue();
/*  32: 32 */     return (value instanceof Long) ? millisToShortDhms(((Long)value).longValue()) : super.getAsText();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setAsText(String text) throws IllegalArgumentException
/*  36:    */   {
/*  37: 37 */     setValue(Long.valueOf(shortDhmsToMillis(text)));
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isPaintable()
/*  41:    */   {
/*  42: 42 */     return true;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void paintValue(Graphics gfx, Rectangle box)
/*  46:    */   {
/*  47: 47 */     painter.setText(millisToLongDhms(((Long)getValue()).longValue()));
/*  48: 48 */     painter.setBounds(box);
/*  49: 49 */     painter.paint(gfx);
/*  50:    */   }
/*  51:    */   
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */   private static int[] millisToDHMS(long duration)
/*  57:    */   {
/*  58: 58 */     duration /= 1000L;
/*  59: 59 */     int seconds = (int)(duration % 60L);
/*  60: 60 */     duration /= 60L;
/*  61: 61 */     int minutes = (int)(duration % 60L);
/*  62: 62 */     duration /= 60L;
/*  63: 63 */     int hours = (int)(duration % 24L);
/*  64: 64 */     int days = (int)(duration / 24L);
/*  65: 65 */     return new int[] { days, hours, minutes, seconds };
/*  66:    */   }
/*  67:    */   
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */   public static String millisToLongDhms(long duration)
/*  74:    */   {
/*  75: 75 */     if (duration < 1000L) {
/*  76: 76 */       return "0 second";
/*  77:    */     }
/*  78: 78 */     int[] items = millisToDHMS(duration);
/*  79: 79 */     StringBuilder res = new StringBuilder();
/*  80: 80 */     if (items[0] > 0)
/*  81:    */     {
/*  82: 82 */       res.append(items[0]).append(" day").append(items[0] > 1 ? "s" : "").append(items[1] > 0 ? ", " : "");
/*  83:    */     }
/*  84: 84 */     if (items[1] > 0)
/*  85:    */     {
/*  86: 86 */       res.append(items[1]).append(" hour").append(items[1] > 1 ? "s" : "").append(items[2] > 0 ? ", " : "");
/*  87:    */     }
/*  88: 88 */     if (items[2] > 0) {
/*  89: 89 */       res.append(items[2]).append(" minute").append(items[2] > 1 ? "s" : "");
/*  90:    */     }
/*  91: 91 */     if ((res.length() > 0) && (items[3] > 0)) {
/*  92: 92 */       res.append(" and ");
/*  93:    */     }
/*  94: 94 */     if (items[3] > 0) {
/*  95: 95 */       res.append(items[3]).append(" second").append(items[3] > 1 ? "s" : "");
/*  96:    */     }
/*  97: 97 */     return res.toString();
/*  98:    */   }
/*  99:    */   
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */   public static String millisToShortDhms(long duration)
/* 105:    */   {
/* 106:106 */     int[] items = millisToDHMS(duration);
/* 107:107 */     return items[0] == 0 ? 
/* 108:108 */       String.format("%02d:%02d:%02d", new Object[] { Integer.valueOf(items[1]), Integer.valueOf(items[2]), Integer.valueOf(items[3]) }) : 
/* 109:109 */       String.format("%dd%02d:%02d:%02d", new Object[] { Integer.valueOf(items[0]), Integer.valueOf(items[1]), Integer.valueOf(items[2]), Integer.valueOf(items[3]) });
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static long shortDhmsToMillis(String text) throws IllegalArgumentException {
/* 113:113 */     Pattern p = Pattern.compile("^(?:(\\d+)d)?(\\d{2}):(\\d{2}):(\\d{2})$");
/* 114:114 */     Matcher m = p.matcher(text);
/* 115:115 */     if (!m.matches()) {
/* 116:116 */       throw new IllegalArgumentException(text);
/* 117:    */     }
/* 118:118 */     int days = m.group(1) != null ? Integer.parseInt(m.group(1)) : 0;
/* 119:119 */     int hours = Integer.parseInt(m.group(2));
/* 120:120 */     int minutes = Integer.parseInt(m.group(3));
/* 121:121 */     int seconds = Integer.parseInt(m.group(4));
/* 122:122 */     return (((days * 24 + hours) * 60 + minutes) * 60 + seconds) * 1000;
/* 123:    */   }
/* 124:    */ }
