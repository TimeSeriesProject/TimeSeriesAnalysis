/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Supplier;
/*  4:   */ import com.google.common.base.Suppliers;
/*  5:   */ import java.beans.PropertyEditorSupport;
/*  6:   */ import org.openide.explorer.propertysheet.ExPropertyEditor;
/*  7:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/*  8:   */ import org.openide.explorer.propertysheet.InplaceEditor.Factory;
/*  9:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ public abstract class AbstractExPropertyEditor
/* 17:   */   extends PropertyEditorSupport
/* 18:   */   implements ExPropertyEditor, InplaceEditor.Factory
/* 19:   */ {
/* 20:20 */   final Supplier<InplaceEditor> supplier = Suppliers.memoize(new Supplier()
/* 21:   */   {
/* 22:   */     public InplaceEditor get() {
/* 23:23 */       return createInplaceEditor();
/* 24:   */     }
/* 25:20 */   });
/* 26:   */   
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */   public void attachEnv(PropertyEnv env)
/* 33:   */   {
/* 34:29 */     env.registerInplaceEditorFactory(this);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public InplaceEditor getInplaceEditor()
/* 38:   */   {
/* 39:34 */     return (InplaceEditor)supplier.get();
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected abstract InplaceEditor createInplaceEditor();
/* 43:   */ }
