/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import com.google.common.util.concurrent.ThreadFactoryBuilder;
/*   4:    */ import ec.util.completion.ext.DesktopFileAutoCompletionSource;
/*   5:    */ import ec.util.completion.swing.FileListCellRenderer;
/*   6:    */ import ec.util.completion.swing.JAutoCompletion;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Rectangle;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import java.beans.PropertyEditor;
/*  12:    */ import java.beans.PropertyEditorManager;
/*  13:    */ import java.io.File;
/*  14:    */ import java.io.FilenameFilter;
/*  15:    */ import java.util.concurrent.ExecutorService;
/*  16:    */ import java.util.concurrent.Executors;
/*  17:    */ import javax.swing.JComponent;
/*  18:    */ import javax.swing.JList;
/*  19:    */ import javax.swing.JTextField;
/*  20:    */ import org.openide.explorer.propertysheet.ExPropertyEditor;
/*  21:    */ import org.openide.explorer.propertysheet.InplaceEditor;
/*  22:    */ import org.openide.explorer.propertysheet.PropertyEnv;
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public class DesktopFilePropertyEditor
/*  31:    */   extends AbstractExPropertyEditor
/*  32:    */ {
/*  33:    */   public static final String FILTER_ATTRIBUTE = "filter";
/*  34:    */   public static final String PATHS_ATTRIBUTE = "paths";
/*  35: 35 */   private static final ExecutorService ICON_EXECUTOR = Executors.newSingleThreadExecutor(new ThreadFactoryBuilder().setDaemon(true).build());
/*  36:    */   
/*  37:    */ 
/*  38: 38 */   final PropertyEditor fileEditor = PropertyEditorManager.findEditor(File.class);
/*  39:    */   
/*  40:    */   public void setValue(Object value)
/*  41:    */   {
/*  42: 42 */     fileEditor.setValue(value);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Object getValue()
/*  46:    */   {
/*  47: 47 */     return fileEditor.getValue();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean isPaintable()
/*  51:    */   {
/*  52: 52 */     return fileEditor.isPaintable();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void paintValue(Graphics gfx, Rectangle box)
/*  56:    */   {
/*  57: 57 */     fileEditor.paintValue(gfx, box);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*  61:    */   {
/*  62: 62 */     fileEditor.addPropertyChangeListener(listener);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*  66:    */   {
/*  67: 67 */     fileEditor.removePropertyChangeListener(listener);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void attachEnv(PropertyEnv env)
/*  71:    */   {
/*  72: 72 */     super.attachEnv(env);
/*  73: 73 */     if ((fileEditor instanceof ExPropertyEditor)) {
/*  74: 74 */       ((ExPropertyEditor)fileEditor).attachEnv(env);
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public String getAsText()
/*  79:    */   {
/*  80: 80 */     return fileEditor.getAsText();
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setAsText(String text) throws IllegalArgumentException
/*  84:    */   {
/*  85: 85 */     fileEditor.setAsText(text);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Component getCustomEditor()
/*  89:    */   {
/*  90: 90 */     return fileEditor.getCustomEditor();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public boolean supportsCustomEditor()
/*  94:    */   {
/*  95: 95 */     return fileEditor.supportsCustomEditor();
/*  96:    */   }
/*  97:    */   
/*  98:    */   public String getJavaInitializationString()
/*  99:    */   {
/* 100:100 */     return fileEditor.getJavaInitializationString();
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected InplaceEditor createInplaceEditor()
/* 104:    */   {
/* 105:105 */     new AbstractInplaceEditor() {
/* 106:106 */       final JTextField component = new JTextField();
/* 107:107 */       final JAutoCompletion autoCompletion = new JAutoCompletion(component);
/* 108:    */       
/* 109:    */       public void connect(PropertyEditor propertyEditor, PropertyEnv env)
/* 110:    */       {
/* 111:111 */         Object tmp = getAttribute(env, "filter", Object.class, null);
/* 112:112 */         File[] paths = (File[])getAttribute(env, "paths", [Ljava.io.File.class, new File[0]);
/* 113:113 */         java.io.FileFilter filter = null;
/* 114:114 */         if ((tmp instanceof java.io.FileFilter)) {
/* 115:115 */           filter = (java.io.FileFilter)tmp;
/* 116:116 */         } else if ((tmp instanceof javax.swing.filechooser.FileFilter)) {
/* 117:117 */           filter = DesktopFilePropertyEditor.toFileFilter((javax.swing.filechooser.FileFilter)tmp);
/* 118:118 */         } else if ((tmp instanceof FilenameFilter)) {
/* 119:119 */           filter = DesktopFilePropertyEditor.toFileFilter((FilenameFilter)tmp);
/* 120:    */         }
/* 121:121 */         autoCompletion.setSource(new DesktopFileAutoCompletionSource(filter, paths));
/* 122:122 */         autoCompletion.getList().setCellRenderer(new FileListCellRenderer(null, DesktopFilePropertyEditor.ICON_EXECUTOR, paths));
/* 123:123 */         super.connect(propertyEditor, env);
/* 124:    */       }
/* 125:    */       
/* 126:    */       public JComponent getComponent()
/* 127:    */       {
/* 128:128 */         return component;
/* 129:    */       }
/* 130:    */       
/* 131:    */       public Object getValue()
/* 132:    */       {
/* 133:133 */         return new File(component.getText());
/* 134:    */       }
/* 135:    */       
/* 136:    */       public void setValue(Object o)
/* 137:    */       {
/* 138:138 */         component.setText(((File)o).getPath());
/* 139:    */       }
/* 140:    */     };
/* 141:    */   }
/* 142:    */   
/* 143:    */   static java.io.FileFilter toFileFilter(javax.swing.filechooser.FileFilter o) {
/* 144:144 */     new java.io.FileFilter()
/* 145:    */     {
/* 146:    */       public boolean accept(File pathname) {
/* 147:147 */         return DesktopFilePropertyEditor.this.accept(pathname);
/* 148:    */       }
/* 149:    */     };
/* 150:    */   }
/* 151:    */   
/* 152:    */   static java.io.FileFilter toFileFilter(FilenameFilter o) {
/* 153:153 */     new java.io.FileFilter()
/* 154:    */     {
/* 155:    */       public boolean accept(File pathname) {
/* 156:156 */         return accept(pathname.getParentFile(), pathname.getName());
/* 157:    */       }
/* 158:    */     };
/* 159:    */   }
/* 160:    */ }
