/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.tss.tsproviders.utils.DataFormat;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/*  6:   */ import org.openide.nodes.PropertyEditorRegistration;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ @PropertyEditorRegistration(targetType={DataFormat.class})
/* 16:   */ public class DataFormatPropertyEditor
/* 17:   */   extends AbstractExPropertyEditor
/* 18:   */ {
/* 19:   */   public InplaceEditor createInplaceEditor()
/* 20:   */   {
/* 21:21 */     new AbstractInplaceEditor() {
/* 22:22 */       final DataFormatComponent2 component = new DataFormatComponent2();
/* 23:   */       
/* 24:   */       public JComponent getComponent()
/* 25:   */       {
/* 26:26 */         return component;
/* 27:   */       }
/* 28:   */       
/* 29:   */       public Object getValue()
/* 30:   */       {
/* 31:31 */         return component.getDataFormat();
/* 32:   */       }
/* 33:   */       
/* 34:   */       public void setValue(Object o)
/* 35:   */       {
/* 36:36 */         component.setDataFormat((DataFormat)o);
/* 37:   */       }
/* 38:   */     };
/* 39:   */   }
/* 40:   */ }
