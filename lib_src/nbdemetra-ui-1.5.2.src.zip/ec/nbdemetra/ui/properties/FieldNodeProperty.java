/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import com.google.common.base.Throwables;
/*  5:   */ import java.lang.reflect.Field;
/*  6:   */ import java.lang.reflect.InvocationTargetException;
/*  7:   */ import java.lang.reflect.Modifier;
/*  8:   */ import org.openide.nodes.Node.Property;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public class FieldNodeProperty<T>
/* 13:   */   extends Node.Property<T>
/* 14:   */ {
/* 15:   */   protected final Object instance;
/* 16:   */   protected final Field field;
/* 17:   */   
/* 18:   */   public static <X> FieldNodeProperty<X> create(Object instance, Class<X> valueType, String fieldName)
/* 19:   */   {
/* 20:   */     try
/* 21:   */     {
/* 22:22 */       return new FieldNodeProperty(instance, valueType, instance.getClass().getField(fieldName));
/* 23:   */     } catch (NoSuchFieldException|SecurityException ex) {
/* 24:24 */       throw Throwables.propagate(ex);
/* 25:   */     }
/* 26:   */   }
/* 27:   */   
/* 28:   */ 
/* 29:   */ 
/* 30:   */   public FieldNodeProperty(Object instance, Class<T> valueType, Field field)
/* 31:   */   {
/* 32:32 */     super(valueType);
/* 33:33 */     Preconditions.checkArgument(field.getType().equals(valueType));
/* 34:34 */     this.instance = instance;
/* 35:35 */     this.field = field;
/* 36:36 */     setName(field.getName());
/* 37:   */   }
/* 38:   */   
/* 39:   */   public boolean canRead()
/* 40:   */   {
/* 41:41 */     return true;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public T getValue() throws IllegalAccessException, InvocationTargetException
/* 45:   */   {
/* 46:46 */     return field.get(instance);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public boolean canWrite()
/* 50:   */   {
/* 51:51 */     return !Modifier.isFinal(field.getModifiers());
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void setValue(T val) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 55:   */   {
/* 56:56 */     field.set(instance, val);
/* 57:   */   }
/* 58:   */ }
