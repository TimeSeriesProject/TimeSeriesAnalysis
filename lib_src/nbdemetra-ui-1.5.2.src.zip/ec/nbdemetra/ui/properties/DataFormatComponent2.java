/*   1:    */ package ec.nbdemetra.ui.properties;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.nbdemetra.ui.completion.JAutoCompletionService;
/*   5:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   6:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*   7:    */ import ec.util.completion.swing.XPopup;
/*   8:    */ import ec.util.completion.swing.XPopup.Anchor;
/*   9:    */ import ec.util.various.swing.TextPrompt;
/*  10:    */ import java.awt.Dimension;
/*  11:    */ import java.awt.GridLayout;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.beans.PropertyChangeListener;
/*  14:    */ import java.util.Date;
/*  15:    */ import javax.swing.JComponent;
/*  16:    */ import javax.swing.JLabel;
/*  17:    */ import javax.swing.JTextField;
/*  18:    */ import javax.swing.event.AncestorEvent;
/*  19:    */ import javax.swing.event.AncestorListener;
/*  20:    */ import javax.swing.event.DocumentEvent;
/*  21:    */ import javax.swing.event.DocumentListener;
/*  22:    */ import javax.swing.text.Document;
/*  23:    */ import javax.swing.text.JTextComponent;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ public final class DataFormatComponent2
/*  42:    */   extends JComponent
/*  43:    */ {
/*  44:    */   public static final String DATA_FORMAT_PROPERTY = "dataFormat";
/*  45:    */   public static final String PREVIEW_VISIBLE_PROPERTY = "previewVisible";
/*  46: 46 */   private static final DataFormat DEFAULT_DATA_FORMAT = DataFormat.DEFAULT;
/*  47:    */   private static final boolean DEFAULT_PREVIEW_VISIBLE = true;
/*  48:    */   private final JTextComponent locale;
/*  49:    */   private final JTextComponent datePattern;
/*  50:    */   private final JTextComponent numberPattern;
/*  51:    */   private final Listener listener;
/*  52:    */   private final Date dateSample;
/*  53:    */   private final CustomPreview datePatternPreview;
/*  54:    */   private final Number numberSample;
/*  55:    */   private final CustomPreview numberPatternPreview;
/*  56:    */   private DataFormat dataFormat;
/*  57:    */   private boolean previewVisible;
/*  58:    */   
/*  59:    */   public DataFormatComponent2()
/*  60:    */   {
/*  61: 61 */     locale = new JTextField();
/*  62: 62 */     datePattern = new JTextField();
/*  63: 63 */     numberPattern = new JTextField();
/*  64: 64 */     listener = new Listener(null);
/*  65:    */     
/*  66: 66 */     dateSample = new Date();
/*  67: 67 */     datePatternPreview = new CustomPreview(datePattern);
/*  68: 68 */     numberSample = Double.valueOf(1234.5D);
/*  69: 69 */     numberPatternPreview = new CustomPreview(numberPattern);
/*  70:    */     
/*  71: 71 */     dataFormat = DEFAULT_DATA_FORMAT;
/*  72: 72 */     previewVisible = true;
/*  73:    */     
/*  74: 74 */     JAutoCompletionService.forPathBind("JAutoCompletionService/Locale", locale);
/*  75: 75 */     JAutoCompletionService.forPathBind("JAutoCompletionService/DatePattern", datePattern);
/*  76:    */     
/*  77: 77 */     new TextPrompt("locale", locale).setEnabled(false);
/*  78: 78 */     new TextPrompt("date pattern", datePattern).setEnabled(false);
/*  79: 79 */     new TextPrompt("number pattern", numberPattern).setEnabled(false);
/*  80:    */     
/*  81: 81 */     onDataFormatChange();
/*  82:    */     
/*  83: 83 */     locale.getDocument().addDocumentListener(listener);
/*  84: 84 */     datePattern.getDocument().addDocumentListener(listener);
/*  85: 85 */     numberPattern.getDocument().addDocumentListener(listener);
/*  86:    */     
/*  87: 87 */     addPropertyChangeListener(new PropertyChangeListener() {
/*  88:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  89:    */         String str;
/*  90: 90 */         switch ((str = evt.getPropertyName()).hashCode()) {case 733434762:  if (str.equals("previewVisible")) break;  case 900197441:  if ((goto 77) && (str.equals("dataFormat")))
/*  91:    */           {
/*  92: 92 */             DataFormatComponent2.this.onDataFormatChange();
/*  93: 93 */             return;
/*  94:    */             
/*  95: 95 */             DataFormatComponent2.this.onPreviewVisibleChange();
/*  96:    */           }
/*  97:    */           break; }
/*  98:    */       }
/*  99: 99 */     });
/* 100:100 */     addAncestorListener(new AncestorListener()
/* 101:    */     {
/* 102:    */       public void ancestorAdded(AncestorEvent event) {
/* 103:103 */         DataFormatComponent2.this.refreshPreviews();
/* 104:    */       }
/* 105:    */       
/* 106:    */       public void ancestorRemoved(AncestorEvent event)
/* 107:    */       {
/* 108:108 */         DataFormatComponent2.this.refreshPreviews();
/* 109:    */       }
/* 110:    */       
/* 111:    */       public void ancestorMoved(AncestorEvent event)
/* 112:    */       {
/* 113:113 */         DataFormatComponent2.this.refreshPreviews();
/* 114:    */       }
/* 115:    */       
/* 116:116 */     });
/* 117:117 */     GridLayout layout = new GridLayout(1, 3);
/* 118:118 */     layout.setHgap(3);
/* 119:119 */     setLayout(layout);
/* 120:120 */     add(locale);
/* 121:121 */     add(datePattern);
/* 122:122 */     add(numberPattern);
/* 123:    */   }
/* 124:    */   
/* 125:    */   private void refreshPreviews() {
/* 126:126 */     datePatternPreview.setText((String)dataFormat.dateFormatter().tryFormatAsString(dateSample).or("‼ "));
/* 127:127 */     numberPatternPreview.setText((String)dataFormat.numberFormatter().tryFormatAsString(numberSample).or("‼ "));
/* 128:    */   }
/* 129:    */   
/* 130:    */   private void onDataFormatChange() {
/* 131:131 */     if (listener.enabled) {
/* 132:132 */       listener.enabled = false;
/* 133:133 */       locale.setText(dataFormat.getLocaleString());
/* 134:134 */       datePattern.setText(dataFormat.getDatePattern());
/* 135:135 */       numberPattern.setText(dataFormat.getNumberPattern());
/* 136:136 */       listener.enabled = true;
/* 137:    */     }
/* 138:138 */     refreshPreviews();
/* 139:    */   }
/* 140:    */   
/* 141:    */   private void onPreviewVisibleChange() {
/* 142:142 */     datePatternPreview.setVisible(previewVisible);
/* 143:143 */     numberPatternPreview.setVisible(previewVisible);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public DataFormat getDataFormat() {
/* 147:147 */     return dataFormat;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void setDataFormat(DataFormat dataFormat) {
/* 151:151 */     DataFormat old = this.dataFormat;
/* 152:152 */     this.dataFormat = (dataFormat != null ? dataFormat : DEFAULT_DATA_FORMAT);
/* 153:153 */     firePropertyChange("dataFormat", old, this.dataFormat);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public boolean isPreviewVisible() {
/* 157:157 */     return previewVisible;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void setPreviewVisible(boolean previewVisible) {
/* 161:161 */     boolean old = this.previewVisible;
/* 162:162 */     this.previewVisible = previewVisible;
/* 163:163 */     firePropertyChange("previewVisible", old, this.previewVisible);
/* 164:    */   }
/* 165:    */   
/* 166:    */   private class Listener implements DocumentListener
/* 167:    */   {
/* 168:168 */     boolean enabled = true;
/* 169:    */     
/* 170:    */     private Listener() {}
/* 171:    */     
/* 172:172 */     public void removeUpdate(DocumentEvent e) { changedUpdate(e); }
/* 173:    */     
/* 174:    */ 
/* 175:    */     public void insertUpdate(DocumentEvent e)
/* 176:    */     {
/* 177:177 */       changedUpdate(e);
/* 178:    */     }
/* 179:    */     
/* 180:    */     public void changedUpdate(DocumentEvent e)
/* 181:    */     {
/* 182:182 */       if (enabled) {
/* 183:183 */         enabled = false;
/* 184:184 */         setDataFormat(DataFormat.create(locale.getText(), datePattern.getText(), numberPattern.getText()));
/* 185:185 */         enabled = true;
/* 186:    */       }
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   private static class CustomPreview
/* 191:    */   {
/* 192:    */     final JTextComponent target;
/* 193:    */     final XPopup popup;
/* 194:    */     final JLabel label;
/* 195:    */     boolean visible;
/* 196:    */     
/* 197:    */     public CustomPreview(JTextComponent target) {
/* 198:198 */       this.target = target;
/* 199:199 */       popup = new XPopup();
/* 200:200 */       label = new JLabel();
/* 201:201 */       visible = true;
/* 202:    */     }
/* 203:    */     
/* 204:    */     public void setText(String value) {
/* 205:205 */       popup.hide();
/* 206:206 */       label.setText(value);
/* 207:207 */       if (visible) {
/* 208:208 */         popup.show(target, label, XPopup.Anchor.TOP_LEADING, new Dimension());
/* 209:    */       }
/* 210:    */     }
/* 211:    */     
/* 212:    */     private void setVisible(boolean visible) {
/* 213:213 */       this.visible = visible;
/* 214:214 */       if (!visible) {
/* 215:215 */         popup.hide();
/* 216:    */       }
/* 217:    */     }
/* 218:    */   }
/* 219:    */ }
