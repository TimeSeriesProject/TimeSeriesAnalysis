/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import com.toedter.components.JSpinField;
/*  4:   */ import java.awt.event.ActionEvent;
/*  5:   */ import java.beans.PropertyEditor;
/*  6:   */ import javax.swing.AbstractAction;
/*  7:   */ import javax.swing.ActionMap;
/*  8:   */ import javax.swing.InputMap;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.JSpinner;
/* 11:   */ import javax.swing.JTextField;
/* 12:   */ import javax.swing.KeyStroke;
/* 13:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/* 14:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ public class JSpinFieldPropertyEditor
/* 33:   */   extends AbstractExPropertyEditor
/* 34:   */ {
/* 35:   */   public static final String MAX_ATTRIBUTE = "max";
/* 36:   */   public static final String MIN_ATTRIBUTE = "min";
/* 37:   */   
/* 38:   */   protected InplaceEditor createInplaceEditor()
/* 39:   */   {
/* 40:40 */     new AbstractInplaceEditor() {
/* 41:41 */       final JSpinField component = new JSpinField() {};
/* 42:   */       
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */       public void connect(PropertyEditor propertyEditor, PropertyEnv env)
/* 57:   */       {
/* 58:58 */         component.setMaximum(((Integer)getAttribute(env, "max", Integer.class, Integer.valueOf(2147483647))).intValue());
/* 59:59 */         component.setMinimum(((Integer)getAttribute(env, "min", Integer.class, Integer.valueOf(-2147483648))).intValue());
/* 60:60 */         super.connect(propertyEditor, env);
/* 61:   */       }
/* 62:   */       
/* 63:   */       public JComponent getComponent()
/* 64:   */       {
/* 65:65 */         return component;
/* 66:   */       }
/* 67:   */       
/* 68:   */       public Object getValue()
/* 69:   */       {
/* 70:70 */         return Integer.valueOf(component.getValue());
/* 71:   */       }
/* 72:   */       
/* 73:   */       public void setValue(Object o)
/* 74:   */       {
/* 75:75 */         component.setValue(((Integer)o).intValue());
/* 76:   */       }
/* 77:   */     };
/* 78:   */   }
/* 79:   */ }
