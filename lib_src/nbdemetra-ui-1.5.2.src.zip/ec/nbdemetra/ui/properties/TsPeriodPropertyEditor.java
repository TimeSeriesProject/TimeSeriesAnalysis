/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  4:   */ import java.beans.PropertyEditorSupport;
/*  5:   */ import org.openide.nodes.PropertyEditorRegistration;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ @PropertyEditorRegistration(targetType={TsPeriod.class})
/* 15:   */ public class TsPeriodPropertyEditor
/* 16:   */   extends PropertyEditorSupport
/* 17:   */ {
/* 18:   */   public String getAsText()
/* 19:   */   {
/* 20:20 */     TsPeriod value = (TsPeriod)getValue();
/* 21:21 */     return value != null ? value.toString() : "";
/* 22:   */   }
/* 23:   */ }
