/*  1:   */ package ec.nbdemetra.ui.properties;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.event.ActionEvent;
/*  5:   */ import java.beans.FeatureDescriptor;
/*  6:   */ import java.beans.PropertyEditor;
/*  7:   */ import java.text.ParseException;
/*  8:   */ import java.util.Arrays;
/*  9:   */ import javax.swing.AbstractAction;
/* 10:   */ import javax.swing.ActionMap;
/* 11:   */ import javax.swing.InputMap;
/* 12:   */ import javax.swing.JComponent;
/* 13:   */ import javax.swing.JFormattedTextField;
/* 14:   */ import javax.swing.JFormattedTextField.AbstractFormatter;
/* 15:   */ import javax.swing.JFormattedTextField.AbstractFormatterFactory;
/* 16:   */ import javax.swing.KeyStroke;
/* 17:   */ import javax.swing.event.DocumentEvent;
/* 18:   */ import javax.swing.event.DocumentListener;
/* 19:   */ import javax.swing.text.Document;
/* 20:   */ import org.openide.explorer.propertysheet.InplaceEditor;
/* 21:   */ import org.openide.explorer.propertysheet.PropertyEnv;
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public class FormattedPropertyEditor
/* 27:   */   extends AbstractExPropertyEditor
/* 28:   */ {
/* 29:   */   public static final String FORMATTER_ATTRIBUTE = "formatter";
/* 30:   */   
/* 31:   */   public String getAsText()
/* 32:   */   {
/* 33:33 */     Object value = getValue();
/* 34:34 */     if ((value instanceof double[]))
/* 35:35 */       return Arrays.toString((double[])value);
/* 36:36 */     if ((value instanceof int[])) {
/* 37:37 */       return Arrays.toString((int[])value);
/* 38:   */     }
/* 39:39 */     return super.getAsText();
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected InplaceEditor createInplaceEditor()
/* 43:   */   {
/* 44:44 */     new AbstractInplaceEditor()
/* 45:   */     {
/* 46:   */       final JFormattedTextField component;
/* 47:   */       
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */ 
/* 62:   */ 
/* 63:   */ 
/* 64:   */ 
/* 65:   */ 
/* 66:   */ 
/* 67:   */ 
/* 68:   */ 
/* 69:   */ 
/* 70:   */ 
/* 71:   */ 
/* 72:   */ 
/* 73:   */ 
/* 74:   */ 
/* 75:   */ 
/* 76:   */       Object getValueFromText()
/* 77:   */       {
/* 78:   */         try
/* 79:   */         {
/* 80:80 */           return component.getFormatter().stringToValue(component.getText());
/* 81:   */         } catch (ParseException ex) {}
/* 82:82 */         return null;
/* 83:   */       }
/* 84:   */       
/* 85:   */ 
/* 86:   */       public void connect(PropertyEditor propertyEditor, PropertyEnv env)
/* 87:   */       {
/* 88:88 */         final JFormattedTextField.AbstractFormatter format = (JFormattedTextField.AbstractFormatter)env.getFeatureDescriptor().getValue("formatter");
/* 89:89 */         component.setFormatterFactory(new JFormattedTextField.AbstractFormatterFactory()
/* 90:   */         {
/* 91:   */           public JFormattedTextField.AbstractFormatter getFormatter(JFormattedTextField tf) {
/* 92:92 */             return format;
/* 93:   */           }
/* 94:94 */         });
/* 95:95 */         super.connect(propertyEditor, env);
/* 96:   */       }
/* 97:   */       
/* 98:   */       public JComponent getComponent()
/* 99:   */       {
/* :0::0 */         return component;
/* :1:   */       }
/* :2:   */       
/* :3:   */ 
/* :4:   */ 
/* :5:   */       public Object getValue()
/* :6:   */       {
/* :7::7 */         Object result = getValueFromText();
/* :8::8 */         return result != null ? result : component.getValue();
/* :9:   */       }
/* ;0:   */       
/* ;1:   */       public void setValue(Object o)
/* ;2:   */       {
/* ;3:;3 */         component.setValue(o);
/* ;4:   */       }
/* ;5:   */     };
/* ;6:   */   }
/* ;7:   */ }
