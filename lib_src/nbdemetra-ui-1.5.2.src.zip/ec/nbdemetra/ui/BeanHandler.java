/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Converter;
/*  4:   */ import ec.nbdemetra.ui.properties.IBeanEditor;
/*  5:   */ import ec.nbdemetra.ui.properties.OpenIdePropertySheetBeanEditor;
/*  6:   */ import java.beans.IntrospectionException;
/*  7:   */ import javax.annotation.Nonnull;
/*  8:   */ import org.openide.util.Exceptions;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ public abstract class BeanHandler<B, R>
/* 32:   */ {
/* 33:   */   @Nonnull
/* 34:   */   public abstract B loadBean(@Nonnull R paramR);
/* 35:   */   
/* 36:   */   public abstract void storeBean(@Nonnull R paramR, @Nonnull B paramB);
/* 37:   */   
/* 38:   */   @Nonnull
/* 39:   */   public Configurator<R> toConfigurator(@Nonnull Converter<B, Config> converter)
/* 40:   */   {
/* 41:41 */     return new ConfiguratorImpl(this, converter, DEFAULT_EDITOR);
/* 42:   */   }
/* 43:   */   
/* 44:   */   @Nonnull
/* 45:   */   public Configurator<R> toConfigurator(@Nonnull Converter<B, Config> converter, @Nonnull IBeanEditor editor) {
/* 46:46 */     return new ConfiguratorImpl(this, converter, editor);
/* 47:   */   }
/* 48:   */   
/* 49:   */ 
/* 50:50 */   private static final IBeanEditor DEFAULT_EDITOR = new OpenIdePropertySheetBeanEditor(null, null);
/* 51:   */   
/* 52:   */   private static final class ConfiguratorImpl<B, R> extends Configurator<R>
/* 53:   */   {
/* 54:   */     private final BeanHandler<B, R> beanHandler;
/* 55:   */     private final Converter<B, Config> converter;
/* 56:   */     private final IBeanEditor editor;
/* 57:   */     
/* 58:   */     public ConfiguratorImpl(BeanHandler<B, R> beanHandler, Converter<B, Config> converter, IBeanEditor editor) {
/* 59:59 */       this.beanHandler = beanHandler;
/* 60:60 */       this.converter = converter;
/* 61:61 */       this.editor = editor;
/* 62:   */     }
/* 63:   */     
/* 64:   */     public Config getConfig(R resource)
/* 65:   */     {
/* 66:66 */       return (Config)converter.convert(beanHandler.loadBean(resource));
/* 67:   */     }
/* 68:   */     
/* 69:   */     public void setConfig(R resource, Config config) throws IllegalArgumentException
/* 70:   */     {
/* 71:71 */       beanHandler.storeBean(resource, converter.reverse().convert(config));
/* 72:   */     }
/* 73:   */     
/* 74:   */     public Config editConfig(Config config) throws IllegalArgumentException
/* 75:   */     {
/* 76:76 */       B bean = converter.reverse().convert(config);
/* 77:   */       try {
/* 78:78 */         if (editor.editBean(bean)) {
/* 79:79 */           return (Config)converter.convert(bean);
/* 80:   */         }
/* 81:   */       } catch (IntrospectionException ex) {
/* 82:82 */         Exceptions.printStackTrace(ex);
/* 83:   */       }
/* 84:84 */       return config;
/* 85:   */     }
/* 86:   */   }
/* 87:   */ }
