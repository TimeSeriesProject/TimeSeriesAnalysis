/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import javax.annotation.Nonnull;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public abstract class AbstractConfigurable<B>
/* 25:   */   implements IConfigurable
/* 26:   */ {
/* 27:   */   @Nonnull
/* 28:   */   protected abstract B loadBean();
/* 29:   */   
/* 30:   */   protected abstract void storeBean(@Nonnull B paramB);
/* 31:   */   
/* 32:   */   protected abstract boolean editBean(@Nonnull B paramB);
/* 33:   */   
/* 34:   */   @Nonnull
/* 35:   */   protected abstract Config toConfig(@Nonnull B paramB);
/* 36:   */   
/* 37:   */   @Nonnull
/* 38:   */   protected abstract B fromConfig(@Nonnull Config paramConfig)
/* 39:   */     throws IllegalArgumentException;
/* 40:   */   
/* 41:   */   public final Config getConfig()
/* 42:   */   {
/* 43:43 */     return toConfig(loadBean());
/* 44:   */   }
/* 45:   */   
/* 46:   */   public final void setConfig(Config config) throws IllegalArgumentException
/* 47:   */   {
/* 48:48 */     storeBean(fromConfig(config));
/* 49:   */   }
/* 50:   */   
/* 51:   */   public final Config editConfig(Config config) throws IllegalArgumentException
/* 52:   */   {
/* 53:53 */     B bean = fromConfig(config);
/* 54:54 */     if (editBean(bean)) {
/* 55:55 */       return toConfig(bean);
/* 56:   */     }
/* 57:57 */     return config;
/* 58:   */   }
/* 59:   */ }
