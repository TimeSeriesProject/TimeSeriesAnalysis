package ec.nbdemetra.ui.chart3d;

import java.awt.Color;

public abstract interface SurfaceColor
{
  public abstract Color getBackgroundColor();
  
  public abstract Color getLineBoxColor();
  
  public abstract Color getBoxColor();
  
  public abstract Color getLineColor();
  
  public abstract Color getTextColor();
  
  public abstract Color getLineColor(int paramInt, float paramFloat);
  
  public abstract Color getPolygonColor(int paramInt, float paramFloat);
  
  public abstract Color getFirstPolygonColor(float paramFloat);
  
  public abstract Color getSecondPolygonColor(float paramFloat);
}
