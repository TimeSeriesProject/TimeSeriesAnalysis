/*   1:    */ package ec.nbdemetra.ui.chart3d;
/*   2:    */ 
/*   3:    */ import java.awt.Point;
/*   4:    */ import java.awt.Rectangle;
/*   5:    */ 
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ public final class Projector
/*  16:    */ {
/*  17:    */   private float scale_x;
/*  18:    */   private float scale_y;
/*  19:    */   private float scale_z;
/*  20:    */   private float distance;
/*  21:    */   private float _2D_scale;
/*  22:    */   private float rotation;
/*  23:    */   private float elevation;
/*  24:    */   private float sin_rotation;
/*  25:    */   private float cos_rotation;
/*  26:    */   private float sin_elevation;
/*  27:    */   private float cos_elevation;
/*  28:    */   private int _2D_trans_x;
/*  29:    */   private int _2D_trans_y;
/*  30:    */   private int x1;
/*  31:    */   private int x2;
/*  32:    */   private int y1;
/*  33:    */   private int y2;
/*  34:    */   private int center_x;
/*  35:    */   private int center_y;
/*  36:    */   private int trans_x;
/*  37:    */   private int trans_y;
/*  38:    */   private float factor;
/*  39:    */   private float sx_cos;
/*  40:    */   private float sy_cos;
/*  41:    */   private float sz_cos;
/*  42:    */   private float sx_sin;
/*  43:    */   private float sy_sin;
/*  44:    */   private float sz_sin;
/*  45: 45 */   private final float DEGTORAD = 0.01745329F;
/*  46:    */   
/*  47:    */   float zmin;
/*  48:    */   
/*  49:    */   float zmax;
/*  50:    */   
/*  51:    */   float zfactor;
/*  52:    */   
/*  53:    */   public Projector()
/*  54:    */   {
/*  55: 55 */     setScaling(1.0F);
/*  56: 56 */     setRotationAngle(0.0F);
/*  57: 57 */     setElevationAngle(0.0F);
/*  58: 58 */     setDistance(10.0F);
/*  59: 59 */     set2DScaling(1.0F);
/*  60: 60 */     set2DTranslation(0, 0);
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */   public void setProjectionArea(Rectangle r)
/*  68:    */   {
/*  69: 69 */     x1 = x;
/*  70: 70 */     x2 = (x1 + width);
/*  71: 71 */     y1 = y;
/*  72: 72 */     y2 = (y1 + height);
/*  73: 73 */     center_x = ((x1 + x2) / 2);
/*  74: 74 */     center_y = ((y1 + y2) / 2);
/*  75:    */     
/*  76: 76 */     trans_x = (center_x + _2D_trans_x);
/*  77: 77 */     trans_y = (center_y + _2D_trans_y);
/*  78:    */   }
/*  79:    */   
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */   public void setRotationAngle(float angle)
/*  85:    */   {
/*  86: 86 */     rotation = angle;
/*  87: 87 */     sin_rotation = ((float)Math.sin(angle * 0.01745329F));
/*  88: 88 */     cos_rotation = ((float)Math.cos(angle * 0.01745329F));
/*  89:    */     
/*  90: 90 */     sx_cos = (-scale_x * cos_rotation);
/*  91: 91 */     sx_sin = (-scale_x * sin_rotation);
/*  92: 92 */     sy_cos = (-scale_y * cos_rotation);
/*  93: 93 */     sy_sin = (scale_y * sin_rotation);
/*  94:    */   }
/*  95:    */   
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */   public float getRotationAngle()
/* 101:    */   {
/* 102:102 */     return rotation;
/* 103:    */   }
/* 104:    */   
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */   public float getSinRotationAngle()
/* 110:    */   {
/* 111:111 */     return sin_rotation;
/* 112:    */   }
/* 113:    */   
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */   public float getCosRotationAngle()
/* 119:    */   {
/* 120:120 */     return cos_rotation;
/* 121:    */   }
/* 122:    */   
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */   public void setElevationAngle(float angle)
/* 128:    */   {
/* 129:129 */     elevation = angle;
/* 130:130 */     sin_elevation = ((float)Math.sin(angle * 0.01745329F));
/* 131:131 */     cos_elevation = ((float)Math.cos(angle * 0.01745329F));
/* 132:132 */     sz_cos = (scale_z * cos_elevation);
/* 133:133 */     sz_sin = (scale_z * sin_elevation);
/* 134:    */   }
/* 135:    */   
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */   public float getElevationAngle()
/* 141:    */   {
/* 142:142 */     return elevation;
/* 143:    */   }
/* 144:    */   
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */   public float getSinElevationAngle()
/* 150:    */   {
/* 151:151 */     return sin_elevation;
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */   public float getCosElevationAngle()
/* 159:    */   {
/* 160:160 */     return cos_elevation;
/* 161:    */   }
/* 162:    */   
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */   public void setDistance(float new_distance)
/* 168:    */   {
/* 169:169 */     distance = new_distance;
/* 170:170 */     factor = (distance * _2D_scale);
/* 171:    */   }
/* 172:    */   
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */   public float getDistance()
/* 178:    */   {
/* 179:179 */     return distance;
/* 180:    */   }
/* 181:    */   
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */   public void setXScaling(float scaling)
/* 187:    */   {
/* 188:188 */     scale_x = scaling;
/* 189:189 */     sx_cos = (-scale_x * cos_rotation);
/* 190:190 */     sx_sin = (-scale_x * sin_rotation);
/* 191:    */   }
/* 192:    */   
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */ 
/* 197:    */   public float getXScaling()
/* 198:    */   {
/* 199:199 */     return scale_x;
/* 200:    */   }
/* 201:    */   
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */   public void setYScaling(float scaling)
/* 207:    */   {
/* 208:208 */     scale_y = scaling;
/* 209:209 */     sy_cos = (-scale_y * cos_rotation);
/* 210:210 */     sy_sin = (scale_y * sin_rotation);
/* 211:    */   }
/* 212:    */   
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */   public float getYScaling()
/* 218:    */   {
/* 219:219 */     return scale_y;
/* 220:    */   }
/* 221:    */   
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */   public void setZScaling(float scaling)
/* 227:    */   {
/* 228:228 */     scale_z = scaling;
/* 229:229 */     sz_cos = (scale_z * cos_elevation);
/* 230:230 */     sz_sin = (scale_z * sin_elevation);
/* 231:    */   }
/* 232:    */   
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */   public float getZScaling()
/* 238:    */   {
/* 239:239 */     return scale_z;
/* 240:    */   }
/* 241:    */   
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:    */ 
/* 247:    */ 
/* 248:    */   public void setScaling(float x, float y, float z)
/* 249:    */   {
/* 250:250 */     scale_x = x;
/* 251:251 */     scale_y = y;
/* 252:252 */     scale_z = z;
/* 253:    */     
/* 254:254 */     sx_cos = (-scale_x * cos_rotation);
/* 255:255 */     sx_sin = (-scale_x * sin_rotation);
/* 256:256 */     sy_cos = (-scale_y * cos_rotation);
/* 257:257 */     sy_sin = (scale_y * sin_rotation);
/* 258:258 */     sz_cos = (scale_z * cos_elevation);
/* 259:259 */     sz_sin = (scale_z * sin_elevation);
/* 260:    */   }
/* 261:    */   
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */   public void setScaling(float scaling)
/* 267:    */   {
/* 268:268 */     scale_x = (this.scale_y = this.scale_z = scaling);
/* 269:    */     
/* 270:270 */     sx_cos = (-scale_x * cos_rotation);
/* 271:271 */     sx_sin = (-scale_x * sin_rotation);
/* 272:272 */     sy_cos = (-scale_y * cos_rotation);
/* 273:273 */     sy_sin = (scale_y * sin_rotation);
/* 274:274 */     sz_cos = (scale_z * cos_elevation);
/* 275:275 */     sz_sin = (scale_z * sin_elevation);
/* 276:    */   }
/* 277:    */   
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */   public void set2DScaling(float scaling)
/* 283:    */   {
/* 284:284 */     _2D_scale = scaling;
/* 285:285 */     factor = (distance * _2D_scale);
/* 286:    */   }
/* 287:    */   
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */   public float get2DScaling()
/* 293:    */   {
/* 294:294 */     return _2D_scale;
/* 295:    */   }
/* 296:    */   
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */   public void set2DTranslation(int x, int y)
/* 303:    */   {
/* 304:304 */     _2D_trans_x = x;
/* 305:305 */     _2D_trans_y = y;
/* 306:    */     
/* 307:307 */     trans_x = (center_x + _2D_trans_x);
/* 308:308 */     trans_y = (center_y + _2D_trans_y);
/* 309:    */   }
/* 310:    */   
/* 311:    */ 
/* 312:    */ 
/* 313:    */ 
/* 314:    */ 
/* 315:    */   public void set2D_xTranslation(int x)
/* 316:    */   {
/* 317:317 */     _2D_trans_x = x;
/* 318:318 */     trans_x = (center_x + _2D_trans_x);
/* 319:    */   }
/* 320:    */   
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */   public int get2D_xTranslation()
/* 326:    */   {
/* 327:327 */     return _2D_trans_x;
/* 328:    */   }
/* 329:    */   
/* 330:    */ 
/* 331:    */ 
/* 332:    */ 
/* 333:    */ 
/* 334:    */   public void set2D_yTranslation(int y)
/* 335:    */   {
/* 336:336 */     _2D_trans_y = y;
/* 337:337 */     trans_y = (center_y + _2D_trans_y);
/* 338:    */   }
/* 339:    */   
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */   public int get2D_yTranslation()
/* 345:    */   {
/* 346:346 */     return _2D_trans_y;
/* 347:    */   }
/* 348:    */   
/* 349:    */ 
/* 350:    */ 
/* 351:    */ 
/* 352:    */ 
/* 353:    */ 
/* 354:    */ 
/* 355:    */ 
/* 356:    */ 
/* 357:    */ 
/* 358:    */   public final Point project(float x, float y, float z)
/* 359:    */   {
/* 360:360 */     float temp = x;
/* 361:361 */     x = x * sx_cos + y * sy_sin;
/* 362:362 */     y = temp * sx_sin + y * sy_cos;
/* 363:    */     
/* 364:    */ 
/* 365:365 */     temp = factor / (y * cos_elevation - z * sz_sin + distance);
/* 366:366 */     return new Point(Math.round(x * temp) + trans_x, 
/* 367:367 */       Math.round((y * sin_elevation + z * sz_cos) * -temp) + trans_y);
/* 368:    */   }
/* 369:    */   
/* 370:    */   public void setZRange(float zmin, float zmax) {
/* 371:371 */     this.zmin = zmin;
/* 372:372 */     this.zmax = zmax;
/* 373:373 */     zfactor = (20.0F / (zmax - zmin));
/* 374:    */   }
/* 375:    */ }
