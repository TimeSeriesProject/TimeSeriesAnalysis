/*   1:    */ package ec.nbdemetra.ui.chart3d;
/*   2:    */ 
/*   3:    */ import java.awt.Point;
/*   4:    */ 
/*   5:    */ 
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ public final class SurfaceVertex
/*  30:    */ {
/*  31:    */   private Point projection;
/*  32:    */   private int project_index;
/*  33: 33 */   private static int master_project_index = 0;
/*  34:    */   
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */   public float x;
/*  40:    */   
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */   public float y;
/*  45:    */   
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */   public float z;
/*  50:    */   
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */   public SurfaceVertex(float ix, float iy, float iz)
/*  56:    */   {
/*  57: 57 */     x = ix;
/*  58: 58 */     y = iy;
/*  59: 59 */     z = iz;
/*  60: 60 */     project_index = (master_project_index - 1);
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */   public final boolean isInvalid()
/*  69:    */   {
/*  70: 70 */     return Float.isNaN(z);
/*  71:    */   }
/*  72:    */   
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */   public final Point projection(Projector projector)
/*  78:    */   {
/*  79: 79 */     if (project_index != master_project_index) {
/*  80: 80 */       projection = projector.project(x, y, (z - zmin) * zfactor - 10.0F);
/*  81: 81 */       project_index = master_project_index;
/*  82:    */     }
/*  83: 83 */     return projection;
/*  84:    */   }
/*  85:    */   
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */   public final void transform(Projector projector)
/*  91:    */   {
/*  92: 92 */     x /= projector.getXScaling();
/*  93: 93 */     y /= projector.getYScaling();
/*  94: 94 */     z = ((zmax - zmin) * (z / projector.getZScaling() + 10.0F) / 20.0F + zmin);
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */   public static void invalidate()
/* 101:    */   {
/* 102:102 */     master_project_index += 1;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String toString()
/* 106:    */   {
/* 107:107 */     return "SurfaceVertex{" + x + ", " + y + ", " + z + '}';
/* 108:    */   }
/* 109:    */ }
