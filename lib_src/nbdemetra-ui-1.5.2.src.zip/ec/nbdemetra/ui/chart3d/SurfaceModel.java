/*  1:   */ package ec.nbdemetra.ui.chart3d;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeListener;
/*  4:   */ import javax.swing.event.ChangeListener;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ public abstract interface SurfaceModel
/* 11:   */ {
/* 12:   */   public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
/* 13:   */   
/* 14:   */   public abstract void addPropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
/* 15:   */   
/* 16:   */   public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
/* 17:   */   
/* 18:   */   public abstract void removePropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
/* 19:   */   
/* 20:   */   public abstract void addChangeListener(ChangeListener paramChangeListener);
/* 21:   */   
/* 22:   */   public abstract void removeChangeListener(ChangeListener paramChangeListener);
/* 23:   */   
/* 24:   */   public abstract SurfaceVertex[] getSurfaceVertex();
/* 25:   */   
/* 26:   */   public abstract Projector getProjector();
/* 27:   */   
/* 28:   */   public static enum PlotType
/* 29:   */   {
/* 30:30 */     SURFACE("3D Surface"), 
/* 31:31 */     WIREFRAME("3D Wireframe"), 
/* 32:32 */     DENSITY("2D Density"), 
/* 33:33 */     CONTOUR("2D Contour");
/* 34:   */     
/* 35:   */     final String att;
/* 36:   */     
/* 37:   */     private PlotType(String att) {
/* 38:38 */       this.att = att;
/* 39:   */     }
/* 40:   */     
/* 41:   */ 
/* 42:42 */     public String getPropertyName() { return att; }
/* 43:   */   }
/* 44:   */   
/* 45:   */   public abstract boolean isAutoScaleZ();
/* 46:   */   
/* 47:   */   public static enum PlotColor {
/* 48:48 */     OPAQUE("Hidden Surface"), 
/* 49:49 */     SPECTRUM("Color Spectrum"), 
/* 50:50 */     DUALSHADE("Dual Shade"), 
/* 51:51 */     GRAYSCALE("Gray Scale"), 
/* 52:52 */     FOG("Fog");
/* 53:   */     
/* 54:   */     final String att;
/* 55:   */     
/* 56:56 */     private PlotColor(String att) { this.att = att; }
/* 57:   */     
/* 58:   */     public String getPropertyName()
/* 59:   */     {
/* 60:60 */       return att;
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public abstract PlotType getPlotType();
/* 65:   */   
/* 66:   */   public abstract PlotColor getPlotColor();
/* 67:   */   
/* 68:   */   public abstract int getCalcDivisions();
/* 69:   */   
/* 70:   */   public abstract int getContourLines();
/* 71:   */   
/* 72:   */   public abstract int getDispDivisions();
/* 73:   */   
/* 74:   */   public abstract float getXMin();
/* 75:   */   
/* 76:   */   public abstract float getYMin();
/* 77:   */   
/* 78:   */   public abstract float getZMin();
/* 79:   */   
/* 80:   */   public abstract float getXMax();
/* 81:   */   
/* 82:   */   public abstract float getYMax();
/* 83:   */   
/* 84:   */   public abstract float getZMax();
/* 85:   */   
/* 86:   */   public abstract SurfaceColor getColorModel();
/* 87:   */   
/* 88:   */   public abstract boolean isExpectDelay();
/* 89:   */   
/* 90:   */   public abstract boolean isBoxed();
/* 91:   */   
/* 92:   */   public abstract boolean isMesh();
/* 93:   */   
/* 94:   */   public abstract boolean isScaleBox();
/* 95:   */   
/* 96:   */   public abstract boolean isDisplayXY();
/* 97:   */   
/* 98:   */   public abstract boolean isDisplayZ();
/* 99:   */   
/* :0:   */   public abstract boolean isDisplayGrids();
/* :1:   */   
/* :2:   */   public abstract boolean isPlotFunction1();
/* :3:   */   
/* :4:   */   public abstract boolean isPlotFunction2();
/* :5:   */   
/* :6:   */   public abstract boolean isDataAvailable();
/* :7:   */   
/* :8:   */   public abstract int getNbDecimals();
/* :9:   */   
/* ;0:   */   public abstract void setNbDecimals(int paramInt);
/* ;1:   */ }
