/*  1:   */ package ec.nbdemetra.ui.chart3d;
/*  2:   */ 
/*  3:   */ import ec.ui.ExtAction;
/*  4:   */ import java.awt.BorderLayout;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.io.File;
/*  7:   */ import java.io.IOException;
/*  8:   */ import javax.swing.AbstractAction;
/*  9:   */ import javax.swing.JFileChooser;
/* 10:   */ import javax.swing.JMenu;
/* 11:   */ import javax.swing.JMenuItem;
/* 12:   */ import javax.swing.JPanel;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ public class JSurfacePanel
/* 34:   */   extends JPanel
/* 35:   */ {
/* 36:   */   private JSurface surface;
/* 37:   */   public static final String EXPORT_ACTION = "export_image";
/* 38:   */   
/* 39:   */   public JSurfacePanel()
/* 40:   */   {
/* 41:41 */     initComponents();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public JSurfacePanel(SurfaceModel model) {
/* 45:45 */     super(new BorderLayout());
/* 46:46 */     initComponents();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setModel(SurfaceModel model) {
/* 50:50 */     surface.setModel(model);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public JSurface getSurface() {
/* 54:54 */     return surface;
/* 55:   */   }
/* 56:   */   
/* 57:   */   private void initComponents() {
/* 58:58 */     surface = new JSurface();
/* 59:59 */     setLayout(new BorderLayout());
/* 60:60 */     add(surface, "Center");
/* 61:   */     
/* 62:62 */     getSurface().setComponentPopupMenu(buildMenu().getPopupMenu());
/* 63:   */   }
/* 64:   */   
/* 65:   */   private JMenu buildMenu() {
/* 66:66 */     JMenu result = new JMenu();
/* 67:   */     
/* 68:68 */     JMenuItem item = new JMenuItem(new ExportJPGAction());
/* 69:69 */     item.setText("Save as image");
/* 70:70 */     ExtAction.hideWhenDisabled(item);
/* 71:71 */     result.add(item);
/* 72:72 */     return result;
/* 73:   */   }
/* 74:   */   
/* 75:   */   private class ExportJPGAction extends AbstractAction
/* 76:   */   {
/* 77:   */     public ExportJPGAction() {
/* 78:78 */       super();
/* 79:   */     }
/* 80:   */     
/* 81:   */     public void actionPerformed(ActionEvent e)
/* 82:   */     {
/* 83:83 */       JFileChooser jfc = new JFileChooser();
/* 84:84 */       int retVal = jfc.showSaveDialog(null);
/* 85:85 */       if (retVal == 0) {
/* 86:   */         try {
/* 87:87 */           File f = jfc.getSelectedFile();
/* 88:88 */           surface.doExportJPG(f);
/* 89:   */         }
/* 90:   */         catch (IOException localIOException) {}
/* 91:   */       }
/* 92:   */     }
/* 93:   */   }
/* 94:   */ }
