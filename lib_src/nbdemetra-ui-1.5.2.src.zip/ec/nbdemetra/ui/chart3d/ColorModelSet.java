/*   1:    */ package ec.nbdemetra.ui.chart3d;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ 
/*   5:    */ 
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ public class ColorModelSet
/*  32:    */   implements SurfaceColor
/*  33:    */ {
/*  34: 34 */   public static float RED_H = 0.941896F;
/*  35: 35 */   public static float RED_S = 0.7517241F;
/*  36: 36 */   public static float RED_B = 0.5686275F;
/*  37: 37 */   public static float GOLD_H = 0.1F;
/*  38: 38 */   public static float GOLD_S = 0.9497207F;
/*  39: 39 */   public static float GOLD_B = 0.701961F;
/*  40:    */   protected ColorModel dualshade;
/*  41:    */   protected ColorModel grayscale;
/*  42:    */   protected ColorModel spectrum;
/*  43:    */   protected ColorModel fog;
/*  44:    */   protected ColorModel opaque;
/*  45:    */   protected ColorModel alt_dualshade;
/*  46:    */   protected ColorModel alt_grayscale;
/*  47:    */   protected ColorModel alt_spectrum;
/*  48:    */   protected ColorModel alt_fog;
/*  49:    */   protected ColorModel alt_opaque;
/*  50: 50 */   protected Color lineColor = Color.DARK_GRAY;
/*  51: 51 */   protected Color lineboxColor = Color.getHSBColor(0.0F, 0.0F, 0.5F);
/*  52: 52 */   protected Color lightColor = Color.WHITE;
/*  53: 53 */   protected Color boxColor = Color.getHSBColor(0.0F, 0.0F, 0.95F);
/*  54:    */   
/*  55:    */   public ColorModelSet() {
/*  56: 56 */     dualshade = new ColorModel((byte)0, RED_H, RED_S, RED_B, 0.4F, 1.0F);
/*  57: 57 */     grayscale = new ColorModel((byte)0, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*  58: 58 */     spectrum = new ColorModel((byte)1, 0.0F, 1.0F, 1.0F, 0.0F, 0.6666F);
/*  59: 59 */     fog = new ColorModel((byte)2, RED_H, RED_S, RED_B, 0.0F, 1.0F);
/*  60: 60 */     opaque = new ColorModel((byte)3, RED_H, 0.1F, 1.0F, 0.0F, 0.0F);
/*  61:    */     
/*  62: 62 */     alt_dualshade = new ColorModel((byte)0, GOLD_H, GOLD_S, GOLD_B, 0.4F, 1.0F);
/*  63: 63 */     alt_grayscale = new ColorModel((byte)0, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*  64: 64 */     alt_spectrum = new ColorModel((byte)1, 0.0F, 1.0F, 0.8F, 0.0F, 0.6666F);
/*  65: 65 */     alt_fog = new ColorModel((byte)2, GOLD_H, 0.0F, GOLD_B, 0.0F, 1.0F);
/*  66: 66 */     alt_opaque = new ColorModel((byte)3, GOLD_H, 0.1F, 1.0F, 0.0F, 0.0F);
/*  67:    */   }
/*  68:    */   
/*  69: 69 */   protected SurfaceModel.PlotColor color_mode = SurfaceModel.PlotColor.SPECTRUM;
/*  70:    */   
/*  71:    */ 
/*  72: 72 */   public void setPlotColor(SurfaceModel.PlotColor v) { color_mode = v; }
/*  73:    */   
/*  74: 74 */   protected SurfaceModel.PlotType plot_mode = SurfaceModel.PlotType.CONTOUR;
/*  75:    */   
/*  76:    */   public void setPlotType(SurfaceModel.PlotType type) {
/*  77: 77 */     plot_mode = type;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public Color getBackgroundColor()
/*  81:    */   {
/*  82: 82 */     return lightColor;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Color getLineBoxColor()
/*  86:    */   {
/*  87: 87 */     return lineboxColor;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Color getBoxColor()
/*  91:    */   {
/*  92: 92 */     return boxColor;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Color getLineColor()
/*  96:    */   {
/*  97: 97 */     return lineColor;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Color getTextColor()
/* 101:    */   {
/* 102:102 */     return lineColor;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Color getLineColor(int curve, float z)
/* 106:    */   {
/* 107:107 */     return Color.BLACK;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Color getPolygonColor(int curve, float z)
/* 111:    */   {
/* 112:112 */     if (curve == 1) {
/* 113:113 */       return getFirstPolygonColor(z);
/* 114:    */     }
/* 115:115 */     if (curve == 2) {
/* 116:116 */       return getSecondPolygonColor(z);
/* 117:    */     }
/* 118:118 */     return Color.blue;
/* 119:    */   }
/* 120:    */   
/* 121:    */ 
/* 122:    */   public Color getFirstPolygonColor(float z)
/* 123:    */   {
/* 124:124 */     if (((plot_mode == SurfaceModel.PlotType.CONTOUR) || (plot_mode == SurfaceModel.PlotType.DENSITY)) && 
/* 125:125 */       (color_mode == SurfaceModel.PlotColor.OPAQUE)) {
/* 126:126 */       return dualshade.getPolygonColor(z);
/* 127:    */     }
/* 128:    */     
/* 129:    */ 
/* 130:130 */     switch (color_mode) {
/* 131:    */     case DUALSHADE: 
/* 132:132 */       return opaque.getPolygonColor(z);
/* 133:    */     case OPAQUE: 
/* 134:134 */       return grayscale.getPolygonColor(z);
/* 135:    */     case FOG: 
/* 136:136 */       return spectrum.getPolygonColor(z);
/* 137:    */     case GRAYSCALE: 
/* 138:138 */       return dualshade.getPolygonColor(z);
/* 139:    */     case SPECTRUM: 
/* 140:140 */       return fog.getPolygonColor(z);
/* 141:    */     }
/* 142:142 */     return Color.blue;
/* 143:    */   }
/* 144:    */   
/* 145:    */ 
/* 146:    */ 
/* 147:    */   public Color getSecondPolygonColor(float z)
/* 148:    */   {
/* 149:149 */     if (((plot_mode == SurfaceModel.PlotType.CONTOUR) || (plot_mode == SurfaceModel.PlotType.DENSITY)) && 
/* 150:150 */       (color_mode == SurfaceModel.PlotColor.OPAQUE)) {
/* 151:151 */       return alt_dualshade.getPolygonColor(z);
/* 152:    */     }
/* 153:    */     
/* 154:154 */     switch (color_mode) {
/* 155:    */     case DUALSHADE: 
/* 156:156 */       return alt_opaque.getPolygonColor(z);
/* 157:    */     case OPAQUE: 
/* 158:158 */       return alt_grayscale.getPolygonColor(z);
/* 159:    */     case FOG: 
/* 160:160 */       return alt_spectrum.getPolygonColor(z);
/* 161:    */     case GRAYSCALE: 
/* 162:162 */       return alt_dualshade.getPolygonColor(z);
/* 163:    */     case SPECTRUM: 
/* 164:164 */       return alt_fog.getPolygonColor(z);
/* 165:    */     }
/* 166:166 */     return Color.blue;
/* 167:    */   }
/* 168:    */ }
