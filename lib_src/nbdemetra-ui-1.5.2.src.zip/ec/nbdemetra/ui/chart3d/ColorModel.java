/*  1:   */ package ec.nbdemetra.ui.chart3d;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class ColorModel
/* 29:   */ {
/* 30:   */   public static final byte DUALSHADE = 0;
/* 31:   */   public static final byte SPECTRUM = 1;
/* 32:   */   public static final byte FOG = 2;
/* 33:   */   public static final byte OPAQUE = 3;
/* 34:   */   float hue;
/* 35:   */   float sat;
/* 36:   */   float bright;
/* 37:   */   float min;
/* 38:   */   float max;
/* 39:39 */   byte mode = 0;
/* 40:   */   Color ocolor;
/* 41:   */   
/* 42:   */   public ColorModel(byte mode, float hue, float sat, float bright, float min, float max) {
/* 43:43 */     this.mode = mode;
/* 44:44 */     this.hue = hue;
/* 45:45 */     this.sat = sat;
/* 46:46 */     this.bright = bright;
/* 47:47 */     this.min = min;
/* 48:48 */     this.max = max;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public Color getPolygonColor(float z) {
/* 52:52 */     if ((z < 0.0F) || (z > 1.0F)) {
/* 53:53 */       return Color.WHITE;
/* 54:   */     }
/* 55:55 */     switch (mode) {
/* 56:   */     case 0: 
/* 57:57 */       return color(hue, sat, norm(z));
/* 58:   */     
/* 59:   */     case 1: 
/* 60:60 */       return color(norm(1.0F - z), sat, bright);
/* 61:   */     
/* 62:   */     case 2: 
/* 63:63 */       return color(hue, norm(z), bright);
/* 64:   */     
/* 65:   */     case 3: 
/* 66:66 */       if (ocolor == null) {
/* 67:67 */         ocolor = color(hue, sat, bright);
/* 68:   */       }
/* 69:69 */       return ocolor;
/* 70:   */     }
/* 71:   */     
/* 72:72 */     return Color.WHITE;
/* 73:   */   }
/* 74:   */   
/* 75:   */   private Color color(float hue, float sat, float bright) {
/* 76:76 */     return Color.getHSBColor(hue, sat, bright);
/* 77:   */   }
/* 78:   */   
/* 79:   */   private float norm(float z) {
/* 80:80 */     if (min == max) {
/* 81:81 */       return min;
/* 82:   */     }
/* 83:83 */     return min + z * (max - min);
/* 84:   */   }
/* 85:   */ }
