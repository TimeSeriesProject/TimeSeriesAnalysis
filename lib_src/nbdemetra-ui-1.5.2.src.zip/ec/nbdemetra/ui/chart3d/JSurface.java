/*    1:     */ package ec.nbdemetra.ui.chart3d;
/*    2:     */ 
/*    3:     */ import java.awt.Color;
/*    4:     */ import java.awt.Dimension;
/*    5:     */ import java.awt.Font;
/*    6:     */ import java.awt.FontMetrics;
/*    7:     */ import java.awt.Graphics;
/*    8:     */ import java.awt.Graphics2D;
/*    9:     */ import java.awt.Point;
/*   10:     */ import java.awt.PrintGraphics;
/*   11:     */ import java.awt.PrintJob;
/*   12:     */ import java.awt.Rectangle;
/*   13:     */ import java.awt.event.FocusAdapter;
/*   14:     */ import java.awt.event.FocusEvent;
/*   15:     */ import java.awt.event.MouseAdapter;
/*   16:     */ import java.awt.event.MouseEvent;
/*   17:     */ import java.awt.event.MouseMotionListener;
/*   18:     */ import java.awt.event.MouseWheelEvent;
/*   19:     */ import java.awt.event.MouseWheelListener;
/*   20:     */ import java.awt.image.BufferedImage;
/*   21:     */ import java.beans.PropertyChangeEvent;
/*   22:     */ import java.beans.PropertyChangeListener;
/*   23:     */ import java.io.File;
/*   24:     */ import java.io.IOException;
/*   25:     */ import java.io.PrintStream;
/*   26:     */ import javax.imageio.ImageIO;
/*   27:     */ import javax.swing.JComponent;
/*   28:     */ import javax.swing.event.ChangeEvent;
/*   29:     */ import javax.swing.event.ChangeListener;
/*   30:     */ 
/*   31:     */ 
/*   32:     */ 
/*   33:     */ 
/*   34:     */ 
/*   35:     */ 
/*   36:     */ 
/*   37:     */ 
/*   38:     */ 
/*   39:     */ 
/*   40:     */ 
/*   41:     */ 
/*   42:     */ 
/*   43:     */ 
/*   44:     */ 
/*   45:     */ 
/*   46:     */ 
/*   47:     */ public class JSurface
/*   48:     */   extends JComponent
/*   49:     */ {
/*   50:     */   private SurfaceModel model;
/*   51:     */   private Projector projector;
/*   52:     */   private SurfaceVertex[] surfaceVertex;
/*   53:     */   private boolean data_available;
/*   54:     */   private boolean interrupted;
/*   55:     */   private boolean critical;
/*   56:     */   private boolean printing;
/*   57:     */   private int prevwidth;
/*   58:     */   private int prevheight;
/*   59:     */   private int printwidth;
/*   60:     */   private int printheight;
/*   61:     */   private SurfaceVertex cop;
/*   62:  62 */   private int curve = 0;
/*   63:     */   private Graphics graphics;
/*   64:     */   private SurfaceModel.PlotType plot_type;
/*   65:     */   private int calc_divisions;
/*   66:     */   private boolean plotfunc1;
/*   67:     */   private boolean isBoxed;
/*   68:     */   private boolean isMesh;
/*   69:     */   private boolean isScaleBox;
/*   70:     */   private boolean isDisplayXY;
/*   71:     */   private boolean isDisplayZ;
/*   72:     */   private boolean isDisplayGrids;
/*   73:  73 */   private float xmin; private float xmax; private float ymin; private float ymax; private float zmin; private float zmax; private String xLabel = "X";
/*   74:  74 */   private String yLabel = "Y";
/*   75:     */   
/*   76:     */   private static final int TOP = 0;
/*   77:     */   
/*   78:     */   private static final int CENTER = 1;
/*   79:     */   
/*   80:     */   private static final int UPPER = 1;
/*   81:     */   
/*   82:     */   private static final int COINCIDE = 0;
/*   83:     */   
/*   84:     */   private static final int LOWER = -1;
/*   85:     */   
/*   86:     */   SurfaceColor colors;
/*   87:     */   
/*   88:     */   private JSurfaceChangesListener surfaceChangesListener;
/*   89:     */   private static JSurface lastFocused;
/*   90:     */   private SurfaceVertex optimum;
/*   91:     */   private boolean is_data_available;
/*   92:     */   
/*   93:     */   public JSurface()
/*   94:     */   {
/*   95:  95 */     surfaceChangesListener = new JSurfaceChangesListener();
/*   96:  96 */     JSurfaceMouseListener my = new JSurfaceMouseListener();
/*   97:  97 */     addMouseListener(my);
/*   98:  98 */     addMouseMotionListener(my);
/*   99:  99 */     addMouseWheelListener(my);
/*  100: 100 */     addFocusListener(new FocusAdapter()
/*  101:     */     {
/*  102:     */       public void focusGained(FocusEvent e)
/*  103:     */       {
/*  104: 104 */         JSurface.lastFocused = JSurface.this;
/*  105:     */       }
/*  106:     */     });
/*  107:     */   }
/*  108:     */   
/*  109:     */   public SurfaceVertex getOptimum() {
/*  110: 110 */     return optimum;
/*  111:     */   }
/*  112:     */   
/*  113:     */   public void setOptimum(SurfaceVertex optimum) {
/*  114: 114 */     this.optimum = optimum;
/*  115:     */   }
/*  116:     */   
/*  117:     */ 
/*  118:     */ 
/*  119:     */ 
/*  120:     */ 
/*  121:     */ 
/*  122:     */   public static JSurface getFocusedComponent()
/*  123:     */   {
/*  124: 124 */     return lastFocused;
/*  125:     */   }
/*  126:     */   
/*  127:     */   public SurfaceModel getModel() {
/*  128: 128 */     return model;
/*  129:     */   }
/*  130:     */   
/*  131:     */   public void setModel(SurfaceModel model)
/*  132:     */   {
/*  133: 133 */     if (this.model != null) {
/*  134: 134 */       model.removePropertyChangeListener(surfaceChangesListener);
/*  135:     */     }
/*  136: 136 */     if (this.model != null) {
/*  137: 137 */       model.removeChangeListener(surfaceChangesListener);
/*  138:     */     }
/*  139:     */     
/*  140: 140 */     if (model == null) {
/*  141: 141 */       throw new NullPointerException("Given surface model is null");
/*  142:     */     }
/*  143:     */     
/*  144: 144 */     this.model = model;
/*  145: 145 */     interrupted = false;
/*  146: 146 */     data_available = false;
/*  147: 147 */     printing = false;
/*  148: 148 */     prevwidth = (this.prevheight = -1);
/*  149: 149 */     projector = model.getProjector();
/*  150:     */     
/*  151:     */ 
/*  152: 152 */     model.addPropertyChangeListener(surfaceChangesListener);
/*  153: 153 */     model.addChangeListener(surfaceChangesListener);
/*  154: 154 */     init();
/*  155:     */   }
/*  156:     */   
/*  157:     */   class JSurfaceMouseListener extends MouseAdapter implements MouseMotionListener, MouseWheelListener
/*  158:     */   {
/*  159: 159 */     int i = 0;
/*  160:     */     
/*  161:     */     JSurfaceMouseListener() {}
/*  162:     */     
/*  163: 163 */     public void mouseWheelMoved(MouseWheelEvent e) { float new_value = 0.0F;
/*  164: 164 */       float old_value = projector.get2DScaling();
/*  165: 165 */       new_value = old_value * (1.0F - e.getScrollAmount() * e.getWheelRotation() / 10.0F);
/*  166: 166 */       if (new_value > 60.0F) {
/*  167: 167 */         new_value = 60.0F;
/*  168:     */       }
/*  169: 169 */       if (new_value < 2.0F) {
/*  170: 170 */         new_value = 2.0F;
/*  171:     */       }
/*  172: 172 */       if (new_value != old_value) {
/*  173: 173 */         projector.set2DScaling(new_value);
/*  174: 174 */         repaint();
/*  175:     */       }
/*  176:     */     }
/*  177:     */     
/*  178:     */     public void mousePressed(MouseEvent e)
/*  179:     */     {
/*  180: 180 */       int x = e.getX();
/*  181: 181 */       int y = e.getY();
/*  182:     */       
/*  183: 183 */       click_x = x;
/*  184: 184 */       click_y = y;
/*  185:     */     }
/*  186:     */     
/*  187:     */ 
/*  188:     */ 
/*  189:     */ 
/*  190:     */ 
/*  191:     */ 
/*  192:     */ 
/*  193:     */ 
/*  194:     */ 
/*  195:     */ 
/*  196:     */     public void mouseReleased(MouseEvent e)
/*  197:     */     {
/*  198: 198 */       int x = e.getX();
/*  199: 199 */       int y = e.getY();
/*  200:     */       
/*  201: 201 */       if (!JSurface.this.is3D()) {
/*  202: 202 */         return;
/*  203:     */       }
/*  204: 204 */       if ((model.isExpectDelay()) && (dragged)) {
/*  205: 205 */         destroyImage();
/*  206: 206 */         data_available = is_data_available;
/*  207: 207 */         repaint();
/*  208: 208 */         dragged = false;
/*  209:     */       }
/*  210:     */     }
/*  211:     */     
/*  212:     */ 
/*  213:     */ 
/*  214:     */ 
/*  215:     */ 
/*  216:     */ 
/*  217:     */ 
/*  218:     */     public void mouseMoved(MouseEvent e) {}
/*  219:     */     
/*  220:     */ 
/*  221:     */ 
/*  222:     */ 
/*  223:     */ 
/*  224:     */ 
/*  225:     */ 
/*  226:     */     public void mouseDragged(MouseEvent e)
/*  227:     */     {
/*  228: 228 */       int x = e.getX();
/*  229: 229 */       int y = e.getY();
/*  230:     */       
/*  231:     */ 
/*  232: 232 */       float new_value = 0.0F;
/*  233:     */       
/*  234: 234 */       if (!JSurface.this.is3D()) {
/*  235: 235 */         return;
/*  236:     */       }
/*  237:     */       
/*  238: 238 */       if (e.isControlDown()) {
/*  239: 239 */         projector.set2D_xTranslation(projector.get2D_xTranslation() + (x - click_x));
/*  240: 240 */         projector.set2D_yTranslation(projector.get2D_yTranslation() + (y - click_y));
/*  241: 241 */       } else if (e.isShiftDown()) {
/*  242: 242 */         new_value = projector.get2DScaling() + (y - click_y) * 0.5F;
/*  243: 243 */         if (new_value > 60.0F) {
/*  244: 244 */           new_value = 60.0F;
/*  245:     */         }
/*  246: 246 */         if (new_value < 2.0F) {
/*  247: 247 */           new_value = 2.0F;
/*  248:     */         }
/*  249: 249 */         projector.set2DScaling(new_value);
/*  250:     */       } else {
/*  251: 251 */         new_value = projector.getRotationAngle() + (x - click_x);
/*  252: 252 */         while (new_value > 360.0F) {
/*  253: 253 */           new_value -= 360.0F;
/*  254:     */         }
/*  255: 255 */         while (new_value < 0.0F) {
/*  256: 256 */           new_value += 360.0F;
/*  257:     */         }
/*  258: 258 */         projector.setRotationAngle(new_value);
/*  259: 259 */         new_value = projector.getElevationAngle() + (y - click_y);
/*  260: 260 */         if (new_value > 90.0F) {
/*  261: 261 */           new_value = 90.0F;
/*  262: 262 */         } else if (new_value < 0.0F) {
/*  263: 263 */           new_value = 0.0F;
/*  264:     */         }
/*  265: 265 */         projector.setElevationAngle(new_value);
/*  266:     */       }
/*  267: 267 */       if (!model.isExpectDelay()) {
/*  268: 268 */         repaint();
/*  269:     */       } else {
/*  270: 270 */         if (!dragged) {
/*  271: 271 */           is_data_available = data_available;
/*  272: 272 */           dragged = true;
/*  273:     */         }
/*  274: 274 */         data_available = false;
/*  275: 275 */         repaint();
/*  276:     */       }
/*  277:     */       
/*  278: 278 */       click_x = x;
/*  279: 279 */       click_y = y;
/*  280:     */     }
/*  281:     */   }
/*  282:     */   
/*  283:     */   class JSurfaceChangesListener implements PropertyChangeListener, ChangeListener {
/*  284:     */     JSurfaceChangesListener() {}
/*  285:     */     
/*  286:     */     public void stateChanged(ChangeEvent e) {
/*  287: 287 */       destroyImage();
/*  288:     */     }
/*  289:     */     
/*  290:     */     public void propertyChange(PropertyChangeEvent pe)
/*  291:     */     {
/*  292: 292 */       JSurface.this.init();
/*  293: 293 */       destroyImage();
/*  294:     */     }
/*  295:     */   }
/*  296:     */   
/*  297:     */   private String format(float f) {
/*  298: 298 */     return String.format("%." + model.getNbDecimals() + "G", new Object[] { Float.valueOf(f) });
/*  299:     */   }
/*  300:     */   
/*  301:     */   private void init() {
/*  302: 302 */     colors = model.getColorModel();
/*  303: 303 */     setRanges(model.getXMin(), model.getXMax(), model.getYMin(), model.getYMax());
/*  304:     */     
/*  305: 305 */     data_available = model.isDataAvailable();
/*  306: 306 */     if (data_available) {
/*  307: 307 */       setValuesArray(model.getSurfaceVertex());
/*  308:     */     }
/*  309:     */     
/*  310: 310 */     plot_type = model.getPlotType();
/*  311:     */     
/*  312: 312 */     isBoxed = model.isBoxed();
/*  313: 313 */     isMesh = model.isMesh();
/*  314: 314 */     isScaleBox = model.isScaleBox();
/*  315: 315 */     isDisplayXY = model.isDisplayXY();
/*  316: 316 */     isDisplayZ = model.isDisplayZ();
/*  317: 317 */     isDisplayGrids = model.isDisplayGrids();
/*  318: 318 */     calc_divisions = model.getCalcDivisions();
/*  319: 319 */     plotfunc1 = model.isPlotFunction1();
/*  320:     */   }
/*  321:     */   
/*  322:     */ 
/*  323:     */ 
/*  324:     */ 
/*  325:     */ 
/*  326:     */   public void destroyImage()
/*  327:     */   {
/*  328: 328 */     repaint();
/*  329:     */   }
/*  330:     */   
/*  331:     */ 
/*  332:     */ 
/*  333:     */ 
/*  334:     */ 
/*  335:     */ 
/*  336:     */ 
/*  337:     */ 
/*  338:     */ 
/*  339:     */   public void setRanges(float xmin, float xmax, float ymin, float ymax)
/*  340:     */   {
/*  341: 341 */     this.xmin = xmin;
/*  342: 342 */     this.xmax = xmax;
/*  343: 343 */     this.ymin = ymin;
/*  344: 344 */     this.ymax = ymax;
/*  345:     */   }
/*  346:     */   
/*  347:     */ 
/*  348:     */ 
/*  349:     */ 
/*  350:     */ 
/*  351:     */ 
/*  352:     */   public float[] getRanges()
/*  353:     */   {
/*  354: 354 */     float[] ranges = new float[6];
/*  355:     */     
/*  356: 356 */     ranges[0] = xmin;
/*  357: 357 */     ranges[1] = xmax;
/*  358: 358 */     ranges[2] = ymin;
/*  359: 359 */     ranges[3] = ymax;
/*  360: 360 */     ranges[4] = zmin;
/*  361: 361 */     ranges[5] = zmax;
/*  362:     */     
/*  363: 363 */     return ranges;
/*  364:     */   }
/*  365:     */   
/*  366:     */ 
/*  367:     */ 
/*  368:     */ 
/*  369:     */ 
/*  370:     */ 
/*  371:     */ 
/*  372:     */ 
/*  373:     */ 
/*  374:     */ 
/*  375:     */   public void setDataAvailability(boolean avail)
/*  376:     */   {
/*  377: 377 */     data_available = avail;
/*  378: 378 */     is_data_available = avail;
/*  379:     */   }
/*  380:     */   
/*  381:     */ 
/*  382:     */ 
/*  383:     */ 
/*  384:     */ 
/*  385:     */ 
/*  386:     */ 
/*  387:     */   public void setValuesArray(SurfaceVertex[] vertex)
/*  388:     */   {
/*  389: 389 */     surfaceVertex = vertex;
/*  390:     */   }
/*  391:     */   
/*  392:     */ 
/*  393:     */ 
/*  394:     */ 
/*  395:     */ 
/*  396:     */ 
/*  397:     */   public SurfaceVertex[] getValuesArray()
/*  398:     */   {
/*  399: 399 */     if (!data_available) {
/*  400: 400 */       return null;
/*  401:     */     }
/*  402: 402 */     return surfaceVertex;
/*  403:     */   }
/*  404:     */   
/*  405:     */ 
/*  406:     */ 
/*  407:     */ 
/*  408:     */ 
/*  409:     */ 
/*  410:     */ 
/*  411:     */ 
/*  412:     */ 
/*  413:     */ 
/*  414:     */ 
/*  415:     */   public void doExportJPG(File file)
/*  416:     */     throws IOException
/*  417:     */   {
/*  418: 418 */     if (file == null) {
/*  419: 419 */       return;
/*  420:     */     }
/*  421: 421 */     BufferedImage bf = new BufferedImage(getWidth(), getHeight(), 1);
/*  422: 422 */     Graphics2D g2d = bf.createGraphics();
/*  423:     */     
/*  424: 424 */     export(g2d);
/*  425: 425 */     printAll(g2d);
/*  426: 426 */     ImageIO.write(bf, "JPG", file);
/*  427:     */   }
/*  428:     */   
/*  429:     */   private boolean dragged;
/*  430:     */   private int click_x;
/*  431:     */   private int click_y;
/*  432:     */   private int factor_x;
/*  433:     */   private int factor_y;
/*  434:     */   private int t_x;
/*  435:     */   private int t_y;
/*  436:     */   private int t_z;
/*  437:     */   private float color_factor;
/*  438:     */   private Point projection;
/*  439:     */   private Color line_color;
/*  440:     */   public void paintComponent(Graphics g)
/*  441:     */   {
/*  442: 442 */     if ((getBounds()width <= 0) || (getBounds()height <= 0)) {
/*  443: 443 */       return;
/*  444:     */     }
/*  445:     */     
/*  446:     */ 
/*  447: 447 */     if ((getBounds()width != prevwidth) || (getBounds()height != prevheight)) {
/*  448: 448 */       projector.setProjectionArea(new Rectangle(0, 0, getBounds()width, getBounds()height));
/*  449: 449 */       prevwidth = getBounds()width;
/*  450: 450 */       prevheight = getBounds()height;
/*  451:     */     }
/*  452:     */     
/*  453: 453 */     printing = (g instanceof PrintGraphics);
/*  454:     */     
/*  455:     */ 
/*  456: 456 */     if (printing) {
/*  457: 457 */       printing(g);
/*  458:     */     }
/*  459:     */     
/*  460:     */ 
/*  461: 461 */     if ((data_available) && (!interrupted))
/*  462:     */     {
/*  463:     */ 
/*  464:     */ 
/*  465:     */ 
/*  466:     */ 
/*  467: 467 */       draw(g);
/*  468:     */     }
/*  469:     */     else
/*  470:     */     {
/*  471: 471 */       g.setColor(colors.getBackgroundColor());
/*  472: 472 */       g.fillRect(0, 0, getBounds()width, getBounds()height);
/*  473: 473 */       if (is3D()) {
/*  474: 474 */         drawBoxGridsTicksLabels(g, true);
/*  475:     */       }
/*  476:     */     }
/*  477: 477 */     interrupted = false;
/*  478:     */   }
/*  479:     */   
/*  480:     */   private boolean is3D() {
/*  481: 481 */     return (plot_type == SurfaceModel.PlotType.WIREFRAME) || (plot_type == SurfaceModel.PlotType.SURFACE);
/*  482:     */   }
/*  483:     */   
/*  484:     */   private void printing(Graphics graphics)
/*  485:     */   {
/*  486: 486 */     Dimension pagedimension = ((PrintGraphics)graphics).getPrintJob().getPageDimension();
/*  487:     */     
/*  488: 488 */     printwidth = width;
/*  489: 489 */     printheight = (prevheight * printwidth / prevwidth);
/*  490:     */     
/*  491: 491 */     if (printheight > height) {
/*  492: 492 */       printheight = height;
/*  493: 493 */       printwidth = (prevwidth * printheight / prevheight);
/*  494:     */     }
/*  495:     */     
/*  496: 496 */     float savedscalingfactor = projector.get2DScaling();
/*  497: 497 */     projector.setProjectionArea(new Rectangle(0, 0, printwidth, printheight));
/*  498: 498 */     projector.set2DScaling(savedscalingfactor * printwidth / prevwidth);
/*  499:     */     
/*  500: 500 */     graphics.clipRect(0, 0, printwidth, printheight);
/*  501:     */     
/*  502: 502 */     if (!data_available) {
/*  503: 503 */       drawBoxGridsTicksLabels(graphics, true);
/*  504:     */     }
/*  505: 505 */     graphics.drawRect(0, 0, printwidth - 1, printheight - 1);
/*  506:     */     
/*  507:     */ 
/*  508:     */ 
/*  509: 509 */     projector.set2DScaling(savedscalingfactor);
/*  510: 510 */     projector.setProjectionArea(new Rectangle(0, 0, getBounds()width, getBounds()height));
/*  511:     */   }
/*  512:     */   
/*  513:     */ 
/*  514:     */ 
/*  515:     */ 
/*  516:     */ 
/*  517:     */ 
/*  518:     */ 
/*  519:     */ 
/*  520:     */   public void update(Graphics g)
/*  521:     */   {
/*  522: 522 */     paintComponent(g);
/*  523:     */   }
/*  524:     */   
/*  525:     */   private void export(Graphics g) {
/*  526: 526 */     if ((data_available) && (!interrupted)) {
/*  527: 527 */       boolean old = printing;
/*  528: 528 */       printing = true;
/*  529:     */       
/*  530: 530 */       draw(g);
/*  531:     */       
/*  532: 532 */       printing = old;
/*  533:     */     }
/*  534:     */     else {
/*  535: 535 */       System.out.println("empty plot");
/*  536: 536 */       g.setColor(colors.getBackgroundColor());
/*  537: 537 */       g.fillRect(0, 0, getBounds()width, getBounds()height);
/*  538: 538 */       if (is3D()) {
/*  539: 539 */         drawBoxGridsTicksLabels(g, true);
/*  540:     */       }
/*  541:     */     }
/*  542:     */   }
/*  543:     */   
/*  544:     */ 
/*  545:     */ 
/*  546:     */   private synchronized void draw(Graphics graphics)
/*  547:     */   {
/*  548: 548 */     this.graphics = graphics;
/*  549:     */     
/*  550: 550 */     int fontsize = (int)Math.round(projector.get2DScaling() * 0.5D);
/*  551:     */     
/*  552:     */ 
/*  553: 553 */     SurfaceVertex.invalidate();
/*  554:     */     
/*  555:     */ 
/*  556: 556 */     switch (plot_type) {
/*  557:     */     case WIREFRAME: 
/*  558: 558 */       plotContour();
/*  559: 559 */       break;
/*  560:     */     case SURFACE: 
/*  561: 561 */       plotDensity();
/*  562: 562 */       break;
/*  563:     */     case DENSITY: 
/*  564: 564 */       plotWireframe();
/*  565: 565 */       if (optimum != null) {
/*  566: 566 */         Point tickpos = projector.project(optimum.x, optimum.y, -10.0F);
/*  567: 567 */         outPoint(graphics, x, y);
/*  568:     */       }
/*  569: 569 */       break;
/*  570:     */     case CONTOUR: 
/*  571: 571 */       plotSurface();
/*  572: 572 */       if (optimum != null) {
/*  573: 573 */         Point tickpos = projector.project(optimum.x, optimum.y, -10.0F);
/*  574: 574 */         outPoint(graphics, x, y);
/*  575:     */       }
/*  576:     */       break;
/*  577:     */     }
/*  578:     */     
/*  579: 579 */     cleanUpMemory();
/*  580:     */   }
/*  581:     */   
/*  582:     */   public String getXLabel() {
/*  583: 583 */     return xLabel;
/*  584:     */   }
/*  585:     */   
/*  586:     */   public void setXLabel(String xLabel) {
/*  587: 587 */     firePropertyChange("xLabel", this.xLabel, this.xLabel = xLabel);
/*  588:     */   }
/*  589:     */   
/*  590:     */   public String getYLabel() {
/*  591: 591 */     return yLabel;
/*  592:     */   }
/*  593:     */   
/*  594:     */   public void setYLabel(String yLabel) {
/*  595: 595 */     firePropertyChange("yLabel", this.yLabel, this.yLabel = yLabel);
/*  596:     */   }
/*  597:     */   
/*  598:     */ 
/*  599:     */ 
/*  600:     */ 
/*  601:     */ 
/*  602:     */ 
/*  603:     */ 
/*  604:     */ 
/*  605:     */ 
/*  606:     */ 
/*  607:     */   private void drawBoundingBox()
/*  608:     */   {
/*  609: 609 */     Point startingpoint = projector.project(factor_x * 10, factor_y * 10, 10.0F);
/*  610: 610 */     graphics.setColor(colors.getLineBoxColor());
/*  611: 611 */     Point projection = projector.project(-factor_x * 10, factor_y * 10, 10.0F);
/*  612: 612 */     graphics.drawLine(x, y, x, y);
/*  613: 613 */     projection = projector.project(factor_x * 10, -factor_y * 10, 10.0F);
/*  614: 614 */     graphics.drawLine(x, y, x, y);
/*  615: 615 */     projection = projector.project(factor_x * 10, factor_y * 10, -10.0F);
/*  616: 616 */     graphics.drawLine(x, y, x, y);
/*  617:     */   }
/*  618:     */   
/*  619:     */ 
/*  620:     */ 
/*  621:     */ 
/*  622:     */ 
/*  623:     */ 
/*  624:     */ 
/*  625:     */   private void drawBase(Graphics g, int[] x, int[] y)
/*  626:     */   {
/*  627: 627 */     Point projection = projector.project(-10.0F, -10.0F, -10.0F);
/*  628: 628 */     x[0] = x;
/*  629: 629 */     y[0] = y;
/*  630: 630 */     projection = projector.project(-10.0F, 10.0F, -10.0F);
/*  631: 631 */     x[1] = x;
/*  632: 632 */     y[1] = y;
/*  633: 633 */     projection = projector.project(10.0F, 10.0F, -10.0F);
/*  634: 634 */     x[2] = x;
/*  635: 635 */     y[2] = y;
/*  636: 636 */     projection = projector.project(10.0F, -10.0F, -10.0F);
/*  637: 637 */     x[3] = x;
/*  638: 638 */     y[3] = y;
/*  639: 639 */     x[4] = x[0];
/*  640: 640 */     y[4] = y[0];
/*  641:     */     
/*  642: 642 */     g.setColor(colors.getBoxColor());
/*  643: 643 */     g.fillPolygon(x, y, 4);
/*  644:     */     
/*  645: 645 */     g.setColor(colors.getLineBoxColor());
/*  646: 646 */     g.drawPolygon(x, y, 5);
/*  647:     */   }
/*  648:     */   
/*  649:     */ 
/*  650:     */ 
/*  651:     */ 
/*  652:     */ 
/*  653:     */ 
/*  654:     */ 
/*  655:     */ 
/*  656:     */   private void drawBoxGridsTicksLabels(Graphics g, boolean draw_axes)
/*  657:     */   {
/*  658: 658 */     boolean x_left = false;boolean y_left = false;
/*  659:     */     
/*  660:     */ 
/*  661: 661 */     int[] x = new int[5];
/*  662: 662 */     int[] y = new int[5];
/*  663: 663 */     if (projector == null) {
/*  664: 664 */       return;
/*  665:     */     }
/*  666:     */     
/*  667: 667 */     if (draw_axes) {
/*  668: 668 */       drawBase(g, x, y);
/*  669: 669 */       Point projection = projector.project(0.0F, 0.0F, -10.0F);
/*  670: 670 */       x[0] = x;
/*  671: 671 */       y[0] = y;
/*  672: 672 */       projection = projector.project(10.5F, 0.0F, -10.0F);
/*  673: 673 */       g.drawLine(x[0], y[0], x, y);
/*  674:     */       
/*  675: 675 */       if (x < x[0]) {
/*  676: 676 */         outString(g, (int)(1.05D * (x - x[0])) + x[0], (int)(1.05D * (y - y[0])) + y[0], "x", 2, 0);
/*  677:     */       } else {
/*  678: 678 */         outString(g, (int)(1.05D * (x - x[0])) + x[0], (int)(1.05D * (y - y[0])) + y[0], "x", 0, 0);
/*  679:     */       }
/*  680: 680 */       projection = projector.project(0.0F, 11.5F, -10.0F);
/*  681: 681 */       g.drawLine(x[0], y[0], x, y);
/*  682: 682 */       if (x < x[0]) {
/*  683: 683 */         outString(g, (int)(1.05D * (x - x[0])) + x[0], (int)(1.05D * (y - y[0])) + y[0], "y", 2, 0);
/*  684:     */       } else {
/*  685: 685 */         outString(g, (int)(1.05D * (x - x[0])) + x[0], (int)(1.05D * (y - y[0])) + y[0], "y", 0, 0);
/*  686:     */       }
/*  687: 687 */       projection = projector.project(0.0F, 0.0F, 10.5F);
/*  688: 688 */       g.drawLine(x[0], y[0], x, y);
/*  689: 689 */       outString(g, (int)(1.05D * (x - x[0])) + x[0], (int)(1.05D * (y - y[0])) + y[0], "z", 1, 1);
/*  690:     */     } else {
/*  691: 691 */       factor_x = (this.factor_y = 1);
/*  692: 692 */       Point projection = projector.project(0.0F, 0.0F, -10.0F);
/*  693: 693 */       x[0] = x;
/*  694: 694 */       projection = projector.project(10.5F, 0.0F, -10.0F);
/*  695: 695 */       y_left = x > x[0];
/*  696: 696 */       int i = y;
/*  697: 697 */       projection = projector.project(-10.5F, 0.0F, -10.0F);
/*  698: 698 */       if (y > i) {
/*  699: 699 */         factor_x = -1;
/*  700: 700 */         y_left = x > x[0];
/*  701:     */       }
/*  702: 702 */       projection = projector.project(0.0F, 10.5F, -10.0F);
/*  703: 703 */       x_left = x > x[0];
/*  704: 704 */       i = y;
/*  705: 705 */       projection = projector.project(0.0F, -10.5F, -10.0F);
/*  706: 706 */       if (y > i) {
/*  707: 707 */         factor_y = -1;
/*  708: 708 */         x_left = x > x[0];
/*  709:     */       }
/*  710: 710 */       setAxesScale();
/*  711: 711 */       drawBase(g, x, y);
/*  712:     */       
/*  713: 713 */       if (isBoxed) {
/*  714: 714 */         projection = projector.project(-factor_x * 10, -factor_y * 10, -10.0F);
/*  715: 715 */         x[0] = x;
/*  716: 716 */         y[0] = y;
/*  717: 717 */         projection = projector.project(-factor_x * 10, -factor_y * 10, 10.0F);
/*  718: 718 */         x[1] = x;
/*  719: 719 */         y[1] = y;
/*  720: 720 */         projection = projector.project(factor_x * 10, -factor_y * 10, 10.0F);
/*  721: 721 */         x[2] = x;
/*  722: 722 */         y[2] = y;
/*  723: 723 */         projection = projector.project(factor_x * 10, -factor_y * 10, -10.0F);
/*  724: 724 */         x[3] = x;
/*  725: 725 */         y[3] = y;
/*  726: 726 */         x[4] = x[0];
/*  727: 727 */         y[4] = y[0];
/*  728:     */         
/*  729: 729 */         g.setColor(colors.getBoxColor());
/*  730: 730 */         g.fillPolygon(x, y, 4);
/*  731:     */         
/*  732: 732 */         g.setColor(colors.getLineBoxColor());
/*  733: 733 */         g.drawPolygon(x, y, 5);
/*  734:     */         
/*  735: 735 */         projection = projector.project(-factor_x * 10, factor_y * 10, 10.0F);
/*  736: 736 */         x[2] = x;
/*  737: 737 */         y[2] = y;
/*  738: 738 */         projection = projector.project(-factor_x * 10, factor_y * 10, -10.0F);
/*  739: 739 */         x[3] = x;
/*  740: 740 */         y[3] = y;
/*  741: 741 */         x[4] = x[0];
/*  742: 742 */         y[4] = y[0];
/*  743:     */         
/*  744: 744 */         g.setColor(colors.getBoxColor());
/*  745: 745 */         g.fillPolygon(x, y, 4);
/*  746:     */         
/*  747: 747 */         g.setColor(colors.getLineBoxColor());
/*  748: 748 */         g.drawPolygon(x, y, 5);
/*  749: 749 */       } else if (isDisplayZ) {
/*  750: 750 */         projection = projector.project(factor_x * 10, -factor_y * 10, -10.0F);
/*  751: 751 */         x[0] = x;
/*  752: 752 */         y[0] = y;
/*  753: 753 */         projection = projector.project(factor_x * 10, -factor_y * 10, 10.0F);
/*  754: 754 */         g.drawLine(x[0], y[0], x, y);
/*  755:     */         
/*  756: 756 */         projection = projector.project(-factor_x * 10, factor_y * 10, -10.0F);
/*  757: 757 */         x[0] = x;
/*  758: 758 */         y[0] = y;
/*  759: 759 */         projection = projector.project(-factor_x * 10, factor_y * 10, 10.0F);
/*  760: 760 */         g.drawLine(x[0], y[0], x, y);
/*  761:     */       }
/*  762:     */       
/*  763: 763 */       for (i = -9; i <= 9; i++) {
/*  764: 764 */         if ((isDisplayXY) || (isDisplayGrids)) {
/*  765: 765 */           if ((!isDisplayGrids) || (i % (t_y / 2) == 0) || (isDisplayXY)) {
/*  766: 766 */             if ((isDisplayGrids) && (i % t_y == 0)) {
/*  767: 767 */               projection = projector.project(-factor_x * 10, i, -10.0F);
/*  768:     */             }
/*  769: 769 */             else if (i % t_y != 0) {
/*  770: 770 */               projection = projector.project(factor_x * 9.8F, i, -10.0F);
/*  771:     */             } else {
/*  772: 772 */               projection = projector.project(factor_x * 9.5F, i, -10.0F);
/*  773:     */             }
/*  774:     */             
/*  775: 775 */             Point tickpos = projector.project(factor_x * 10, i, -10.0F);
/*  776: 776 */             g.drawLine(x, y, x, y);
/*  777: 777 */             if ((i % t_y == 0) && (isDisplayXY)) {
/*  778: 778 */               tickpos = projector.project(factor_x * 10.5F, i, -10.0F);
/*  779: 779 */               if (y_left) {
/*  780: 780 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (ymax - ymin) + ymin), 0, 0);
/*  781:     */               } else {
/*  782: 782 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (ymax - ymin) + ymin), 2, 0);
/*  783:     */               }
/*  784:     */             }
/*  785:     */           }
/*  786: 786 */           if ((!isDisplayGrids) || (i % (t_x / 2) == 0) || (isDisplayXY)) {
/*  787: 787 */             if ((isDisplayGrids) && (i % t_x == 0)) {
/*  788: 788 */               projection = projector.project(i, -factor_y * 10, -10.0F);
/*  789:     */             }
/*  790: 790 */             else if (i % t_x != 0) {
/*  791: 791 */               projection = projector.project(i, factor_y * 9.8F, -10.0F);
/*  792:     */             } else {
/*  793: 793 */               projection = projector.project(i, factor_y * 9.5F, -10.0F);
/*  794:     */             }
/*  795:     */             
/*  796: 796 */             Point tickpos = projector.project(i, factor_y * 10, -10.0F);
/*  797: 797 */             g.drawLine(x, y, x, y);
/*  798: 798 */             if ((i % t_x == 0) && (isDisplayXY)) {
/*  799: 799 */               tickpos = projector.project(i, factor_y * 10.5F, -10.0F);
/*  800: 800 */               if (x_left) {
/*  801: 801 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (xmax - xmin) + xmin), 0, 0);
/*  802:     */               } else {
/*  803: 803 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (xmax - xmin) + xmin), 2, 0);
/*  804:     */               }
/*  805:     */             }
/*  806:     */           }
/*  807:     */         }
/*  808:     */         
/*  809: 809 */         if (isDisplayXY) {
/*  810: 810 */           Point tickpos = projector.project(0.0F, factor_y * 14, -10.0F);
/*  811: 811 */           outString(g, x, y, xLabel, 1, 0);
/*  812: 812 */           tickpos = projector.project(factor_x * 14, 0.0F, -10.0F);
/*  813: 813 */           outString(g, x, y, yLabel, 1, 0);
/*  814:     */         }
/*  815:     */         
/*  816:     */ 
/*  817:     */ 
/*  818: 818 */         if (((isDisplayZ) || ((isDisplayGrids) && (isBoxed))) && (
/*  819: 819 */           (!isDisplayGrids) || (i % (t_z / 2) == 0) || (isDisplayZ))) { Point tickpos;
/*  820: 820 */           Point tickpos; if ((isBoxed) && (isDisplayGrids) && (i % t_z == 0)) {
/*  821: 821 */             projection = projector.project(-factor_x * 10, -factor_y * 10, i);
/*  822: 822 */             tickpos = projector.project(-factor_x * 10, factor_y * 10, i);
/*  823:     */           } else {
/*  824: 824 */             if (i % t_z == 0) {
/*  825: 825 */               projection = projector.project(-factor_x * 10, factor_y * 9.5F, i);
/*  826:     */             } else {
/*  827: 827 */               projection = projector.project(-factor_x * 10, factor_y * 9.8F, i);
/*  828:     */             }
/*  829: 829 */             tickpos = projector.project(-factor_x * 10, factor_y * 10, i);
/*  830:     */           }
/*  831: 831 */           g.drawLine(x, y, x, y);
/*  832: 832 */           if (isDisplayZ) {
/*  833: 833 */             tickpos = projector.project(-factor_x * 10, factor_y * 10.5F, i);
/*  834: 834 */             if (i % t_z == 0) {
/*  835: 835 */               if (x_left) {
/*  836: 836 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (zmax - zmin) + zmin), 0, 1);
/*  837:     */               } else {
/*  838: 838 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (zmax - zmin) + zmin), 2, 1);
/*  839:     */               }
/*  840:     */             }
/*  841:     */           }
/*  842: 842 */           if ((isDisplayGrids) && (isBoxed) && (i % t_z == 0)) {
/*  843: 843 */             projection = projector.project(-factor_x * 10, -factor_y * 10, i);
/*  844: 844 */             tickpos = projector.project(factor_x * 10, -factor_y * 10, i);
/*  845:     */           } else {
/*  846: 846 */             if (i % t_z == 0) {
/*  847: 847 */               projection = projector.project(factor_x * 9.5F, -factor_y * 10, i);
/*  848:     */             } else {
/*  849: 849 */               projection = projector.project(factor_x * 9.8F, -factor_y * 10, i);
/*  850:     */             }
/*  851: 851 */             tickpos = projector.project(factor_x * 10, -factor_y * 10, i);
/*  852:     */           }
/*  853: 853 */           g.drawLine(x, y, x, y);
/*  854: 854 */           if (isDisplayZ) {
/*  855: 855 */             tickpos = projector.project(factor_x * 10.5F, -factor_y * 10, i);
/*  856: 856 */             if (i % t_z == 0) {
/*  857: 857 */               if (y_left) {
/*  858: 858 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (zmax - zmin) + zmin), 0, 1);
/*  859:     */               } else {
/*  860: 860 */                 outFloat(g, x, y, (float)((i + 10) / 20.0D * (zmax - zmin) + zmin), 2, 1);
/*  861:     */               }
/*  862:     */             }
/*  863:     */           }
/*  864: 864 */           if ((isDisplayGrids) && (isBoxed)) {
/*  865: 865 */             if (i % t_y == 0) {
/*  866: 866 */               projection = projector.project(-factor_x * 10, i, -10.0F);
/*  867: 867 */               tickpos = projector.project(-factor_x * 10, i, 10.0F);
/*  868: 868 */               g.drawLine(x, y, x, y);
/*  869:     */             }
/*  870: 870 */             if (i % t_x == 0) {
/*  871: 871 */               projection = projector.project(i, -factor_y * 10, -10.0F);
/*  872: 872 */               tickpos = projector.project(i, -factor_y * 10, 10.0F);
/*  873: 873 */               g.drawLine(x, y, x, y);
/*  874:     */             }
/*  875:     */           }
/*  876:     */         }
/*  877:     */       }
/*  878:     */     }
/*  879:     */   }
/*  880:     */   
/*  881:     */ 
/*  882:     */ 
/*  883:     */ 
/*  884:     */ 
/*  885:     */ 
/*  886:     */ 
/*  887:     */ 
/*  888:     */ 
/*  889:     */   private void setAxesScale()
/*  890:     */   {
/*  891: 891 */     if (!isScaleBox) {
/*  892: 892 */       projector.setScaling(1.0F);
/*  893: 893 */       t_x = (this.t_y = this.t_z = 4);
/*  894: 894 */       return;
/*  895:     */     }
/*  896:     */     
/*  897: 897 */     float scale_x = xmax - xmin;
/*  898: 898 */     float scale_y = ymax - ymin;
/*  899: 899 */     float scale_z = zmax - zmin;
/*  900:     */     float divisor;
/*  901: 901 */     int longest; float divisor; if (scale_x < scale_y) { float divisor;
/*  902: 902 */       if (scale_y < scale_z) {
/*  903: 903 */         int longest = 3;
/*  904: 904 */         divisor = scale_z;
/*  905:     */       } else {
/*  906: 906 */         int longest = 2;
/*  907: 907 */         divisor = scale_y;
/*  908:     */       }
/*  909:     */     } else { float divisor;
/*  910: 910 */       if (scale_x < scale_z) {
/*  911: 911 */         int longest = 3;
/*  912: 912 */         divisor = scale_z;
/*  913:     */       } else {
/*  914: 914 */         longest = 1;
/*  915: 915 */         divisor = scale_x;
/*  916:     */       }
/*  917:     */     }
/*  918: 918 */     scale_x /= divisor;
/*  919: 919 */     scale_y /= divisor;
/*  920: 920 */     scale_z /= divisor;
/*  921:     */     
/*  922: 922 */     if ((scale_x < 0.2F) || ((scale_y < 0.2F) && (scale_z < 0.2F))) {
/*  923: 923 */       switch (longest) {
/*  924:     */       case 1: 
/*  925: 925 */         if (scale_y < scale_z) {
/*  926: 926 */           scale_y /= scale_z;
/*  927: 927 */           scale_z = 1.0F;
/*  928:     */         } else {
/*  929: 929 */           scale_z /= scale_y;
/*  930: 930 */           scale_y = 1.0F;
/*  931:     */         }
/*  932: 932 */         break;
/*  933:     */       case 2: 
/*  934: 934 */         if (scale_x < scale_z) {
/*  935: 935 */           scale_x /= scale_z;
/*  936: 936 */           scale_z = 1.0F;
/*  937:     */         } else {
/*  938: 938 */           scale_z /= scale_x;
/*  939: 939 */           scale_x = 1.0F;
/*  940:     */         }
/*  941: 941 */         break;
/*  942:     */       case 3: 
/*  943: 943 */         if (scale_y < scale_x) {
/*  944: 944 */           scale_y /= scale_x;
/*  945: 945 */           scale_x = 1.0F;
/*  946:     */         } else {
/*  947: 947 */           scale_x /= scale_y;
/*  948: 948 */           scale_y = 1.0F;
/*  949:     */         }
/*  950:     */         break;
/*  951:     */       }
/*  952:     */     }
/*  953: 953 */     if (scale_x < 0.2F) {
/*  954: 954 */       scale_x = 1.0F;
/*  955:     */     }
/*  956: 956 */     projector.setXScaling(scale_x);
/*  957: 957 */     if (scale_y < 0.2F) {
/*  958: 958 */       scale_y = 1.0F;
/*  959:     */     }
/*  960: 960 */     projector.setYScaling(scale_y);
/*  961: 961 */     if (scale_z < 0.2F) {
/*  962: 962 */       scale_z = 1.0F;
/*  963:     */     }
/*  964: 964 */     projector.setZScaling(scale_z);
/*  965:     */     
/*  966: 966 */     if (scale_x < 0.5F) {
/*  967: 967 */       t_x = 8;
/*  968:     */     } else {
/*  969: 969 */       t_x = 4;
/*  970:     */     }
/*  971: 971 */     if (scale_y < 0.5F) {
/*  972: 972 */       t_y = 8;
/*  973:     */     } else {
/*  974: 974 */       t_y = 4;
/*  975:     */     }
/*  976: 976 */     if (scale_z < 0.5F) {
/*  977: 977 */       t_z = 8;
/*  978:     */     } else {
/*  979: 979 */       t_z = 4;
/*  980:     */     }
/*  981:     */   }
/*  982:     */   
/*  983:     */ 
/*  984:     */ 
/*  985:     */ 
/*  986:     */ 
/*  987:     */ 
/*  988:     */ 
/*  989:     */ 
/*  990:     */ 
/*  991:     */ 
/*  992:     */   private void outString(Graphics g, int x, int y, String s, int x_align, int y_align)
/*  993:     */   {
/*  994: 994 */     switch (y_align) {
/*  995:     */     case 0: 
/*  996: 996 */       y += g.getFontMetrics(g.getFont()).getAscent();
/*  997: 997 */       break;
/*  998:     */     case 1: 
/*  999: 999 */       y += g.getFontMetrics(g.getFont()).getAscent() / 2;
/* 1000:     */     }
/* 1001:     */     
/* 1002:1002 */     switch (x_align) {
/* 1003:     */     case 0: 
/* 1004:1004 */       g.drawString(s, x, y);
/* 1005:1005 */       break;
/* 1006:     */     case 2: 
/* 1007:1007 */       g.drawString(s, x - g.getFontMetrics(g.getFont()).stringWidth(s), y);
/* 1008:1008 */       break;
/* 1009:     */     case 1: 
/* 1010:1010 */       g.drawString(s, x - g.getFontMetrics(g.getFont()).stringWidth(s) / 2, y);
/* 1011:     */     }
/* 1012:     */   }
/* 1013:     */   
/* 1014:     */   private void outPoint(Graphics g, int x, int y)
/* 1015:     */   {
/* 1016:1016 */     g.setColor(Color.RED);
/* 1017:1017 */     g.drawOval(x - 3, y - 3, 6, 6);
/* 1018:1018 */     g.fillOval(x - 3, y - 3, 6, 6);
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */ 
/* 1022:     */ 
/* 1023:     */ 
/* 1024:     */ 
/* 1025:     */ 
/* 1026:     */ 
/* 1027:     */ 
/* 1028:     */ 
/* 1029:     */ 
/* 1030:     */ 
/* 1031:     */   private void outFloat(Graphics g, int x, int y, float f, int x_align, int y_align)
/* 1032:     */   {
/* 1033:1033 */     String s = format(f);
/* 1034:1034 */     outString(g, x, y, s, x_align, y_align);
/* 1035:     */   }
/* 1036:     */   
/* 1037:     */ 
/* 1038:     */ 
/* 1039:     */ 
/* 1040:     */ 
/* 1041:     */ 
/* 1042:     */ 
/* 1043:1043 */   private final int[] poly_x = new int[9];
/* 1044:1044 */   private final int[] poly_y = new int[9];
/* 1045:     */   
/* 1046:     */ 
/* 1047:     */ 
/* 1048:     */ 
/* 1049:     */ 
/* 1050:     */ 
/* 1051:     */ 
/* 1052:     */ 
/* 1053:     */ 
/* 1054:     */ 
/* 1055:     */   private void plotPlane(SurfaceVertex[] vertex, int verticescount)
/* 1056:     */   {
/* 1057:1057 */     if (verticescount < 3) {
/* 1058:1058 */       return;
/* 1059:     */     }
/* 1060:1060 */     int count = 0;
/* 1061:1061 */     float z = 0.0F;
/* 1062:     */     
/* 1063:1063 */     boolean low1 = 0z < zmin;
/* 1064:1064 */     boolean valid1 = (!low1) && (0z <= zmax);
/* 1065:1065 */     int index = 1;
/* 1066:1066 */     for (int loop = 0; loop < verticescount; loop++) {
/* 1067:1067 */       boolean low2 = z < zmin;
/* 1068:1068 */       boolean valid2 = (!low2) && (z <= zmax);
/* 1069:1069 */       if ((valid1) || (valid2) || ((low1 ^ low2))) {
/* 1070:1070 */         if (!valid1) { float result;
/* 1071:1071 */           float result; if (low1) {
/* 1072:1072 */             result = zmin;
/* 1073:     */           } else {
/* 1074:1074 */             result = zmax;
/* 1075:     */           }
/* 1076:1076 */           float ratio = (result - z) / (z - z);
/* 1077:1077 */           float new_x = ratio * (x - x) + x;
/* 1078:1078 */           float new_y = ratio * (y - y) + y;
/* 1079:1079 */           if (low1) {
/* 1080:1080 */             projection = projector.project(new_x, new_y, -10.0F);
/* 1081:     */           } else {
/* 1082:1082 */             projection = projector.project(new_x, new_y, 10.0F);
/* 1083:     */           }
/* 1084:1084 */           poly_x[count] = projection.x;
/* 1085:1085 */           poly_y[count] = projection.y;
/* 1086:1086 */           count++;
/* 1087:1087 */           z += result;
/* 1088:     */         }
/* 1089:1089 */         if (valid2) {
/* 1090:1090 */           projection = vertex[index].projection(projector);
/* 1091:1091 */           poly_x[count] = projection.x;
/* 1092:1092 */           poly_y[count] = projection.y;
/* 1093:1093 */           count++;
/* 1094:1094 */           z += z; } else { float result;
/* 1095:     */           float result;
/* 1096:1096 */           if (low2) {
/* 1097:1097 */             result = zmin;
/* 1098:     */           } else {
/* 1099:1099 */             result = zmax;
/* 1100:     */           }
/* 1101:1101 */           float ratio = (result - z) / (z - z);
/* 1102:1102 */           float new_x = ratio * (x - x) + x;
/* 1103:1103 */           float new_y = ratio * (y - y) + y;
/* 1104:1104 */           if (low2) {
/* 1105:1105 */             projection = projector.project(new_x, new_y, -10.0F);
/* 1106:     */           } else {
/* 1107:1107 */             projection = projector.project(new_x, new_y, 10.0F);
/* 1108:     */           }
/* 1109:1109 */           poly_x[count] = projection.x;
/* 1110:1110 */           poly_y[count] = projection.y;
/* 1111:1111 */           count++;
/* 1112:1112 */           z += result;
/* 1113:     */         }
/* 1114:     */       }
/* 1115:1115 */       index++; if (index == verticescount) {
/* 1116:1116 */         index = 0;
/* 1117:     */       }
/* 1118:1118 */       valid1 = valid2;
/* 1119:1119 */       low1 = low2;
/* 1120:     */     }
/* 1121:1121 */     if (count > 0) {
/* 1122:1122 */       z = (z / count - zmin) * color_factor;
/* 1123:1123 */       graphics.setColor(colors.getPolygonColor(curve, z));
/* 1124:1124 */       graphics.fillPolygon(poly_x, poly_y, count);
/* 1125:1125 */       graphics.setColor(colors.getLineColor(1, z));
/* 1126:1126 */       if (isMesh)
/* 1127:     */       {
/* 1128:1128 */         poly_x[count] = poly_x[0];
/* 1129:1129 */         poly_y[count] = poly_y[0];
/* 1130:1130 */         count++;
/* 1131:1131 */         graphics.drawPolygon(poly_x, poly_y, count);
/* 1132:     */       }
/* 1133:     */     } }
/* 1134:     */   
/* 1135:1135 */   private final SurfaceVertex[] upperpart = new SurfaceVertex[8];
/* 1136:1136 */   private final SurfaceVertex[] lowerpart = new SurfaceVertex[8];
/* 1137:     */   
/* 1138:     */ 
/* 1139:     */ 
/* 1140:     */ 
/* 1141:     */ 
/* 1142:     */ 
/* 1143:     */ 
/* 1144:     */   private void splitPlotPlane(SurfaceVertex[] values1, SurfaceVertex[] values2)
/* 1145:     */   {
/* 1146:1146 */     int trackposition = 0;
/* 1147:1147 */     int uppercount = 0;int lowercount = 0;
/* 1148:1148 */     boolean coincide = true;
/* 1149:1149 */     boolean upper_first = false;
/* 1150:     */     
/* 1151:1151 */     int i = 0;int j = 0;
/* 1152:     */     
/* 1153:1153 */     for (int counter = 0; counter <= 4; counter++) {
/* 1154:1154 */       if (z < z) {
/* 1155:1155 */         coincide = false;
/* 1156:1156 */         if (trackposition == 0) {
/* 1157:1157 */           trackposition = 1;
/* 1158:1158 */           upperpart[(uppercount++)] = values2[i];
/* 1159:1159 */         } else if (trackposition != 1)
/* 1160:     */         {
/* 1161:     */ 
/* 1162:     */ 
/* 1163:1163 */           float factor = (z - z) / (z - z + z - z);
/* 1164:1164 */           float xi; float xi; float yi; if (x == x)
/* 1165:     */           {
/* 1166:     */ 
/* 1167:     */ 
/* 1168:1168 */             float yi = factor * (y - y) + y;
/* 1169:1169 */             xi = x;
/* 1170:     */ 
/* 1171:     */           }
/* 1172:     */           else
/* 1173:     */           {
/* 1174:1174 */             xi = factor * (x - x) + x;
/* 1175:1175 */             yi = y;
/* 1176:     */           }
/* 1177:1177 */           float zi = factor * (z - z) + z; void 
/* 1178:     */           
/* 1179:1179 */             tmp278_275 = new SurfaceVertex(xi, yi, zi);lowerpart[(lowercount++)] = tmp278_275;upperpart[(uppercount++)] = tmp278_275;
/* 1180:1180 */           upperpart[(uppercount++)] = values2[i];
/* 1181:     */           
/* 1182:1182 */           trackposition = 1;
/* 1183:     */         } else {
/* 1184:1184 */           upperpart[(uppercount++)] = values2[i];
/* 1185:     */         }
/* 1186:     */       }
/* 1187:1187 */       else if (z > z) {
/* 1188:1188 */         coincide = false;
/* 1189:1189 */         if (trackposition == 0) {
/* 1190:1190 */           trackposition = -1;
/* 1191:1191 */           lowerpart[(lowercount++)] = values2[i];
/* 1192:1192 */         } else if (trackposition != -1)
/* 1193:     */         {
/* 1194:     */ 
/* 1195:     */ 
/* 1196:1196 */           float factor = (z - z) / (z - z + z - z);
/* 1197:1197 */           float xi; float xi; float yi; if (x == x)
/* 1198:     */           {
/* 1199:     */ 
/* 1200:     */ 
/* 1201:1201 */             float yi = factor * (y - y) + y;
/* 1202:1202 */             xi = x;
/* 1203:     */ 
/* 1204:     */           }
/* 1205:     */           else
/* 1206:     */           {
/* 1207:1207 */             xi = factor * (x - x) + x;
/* 1208:1208 */             yi = y;
/* 1209:     */           }
/* 1210:1210 */           float zi = factor * (z - z) + z; void 
/* 1211:     */           
/* 1212:1212 */             tmp569_566 = new SurfaceVertex(xi, yi, zi);upperpart[(uppercount++)] = tmp569_566;lowerpart[(lowercount++)] = tmp569_566;
/* 1213:1213 */           lowerpart[(lowercount++)] = values2[i];
/* 1214:     */           
/* 1215:1215 */           trackposition = -1;
/* 1216:     */         } else {
/* 1217:1217 */           lowerpart[(lowercount++)] = values2[i];
/* 1218:     */         }
/* 1219:     */       } else {
/* 1220:1220 */         upperpart[(uppercount++)] = values2[i];
/* 1221:1221 */         lowerpart[(lowercount++)] = values2[i];
/* 1222:1222 */         trackposition = 0;
/* 1223:     */       }
/* 1224:     */       
/* 1225:1225 */       j = i;
/* 1226:1226 */       i = (i + 1) % 4;
/* 1227:     */     }
/* 1228:     */     
/* 1229:1229 */     if (coincide) {
/* 1230:1230 */       plotPlane(values1, 4);
/* 1231:     */     } else {
/* 1232:1232 */       if (critical) {
/* 1233:1233 */         upper_first = false;
/* 1234:     */ 
/* 1235:     */ 
/* 1236:     */ 
/* 1237:     */ 
/* 1238:     */ 
/* 1239:     */ 
/* 1240:     */ 
/* 1241:     */ 
/* 1242:     */ 
/* 1243:     */ 
/* 1244:     */ 
/* 1245:     */ 
/* 1246:     */ 
/* 1247:     */ 
/* 1248:     */ 
/* 1249:     */ 
/* 1250:     */ 
/* 1251:     */ 
/* 1252:     */ 
/* 1253:     */ 
/* 1254:     */ 
/* 1255:     */ 
/* 1256:     */ 
/* 1257:     */ 
/* 1258:     */ 
/* 1259:     */ 
/* 1260:     */ 
/* 1261:     */ 
/* 1262:     */ 
/* 1263:     */ 
/* 1264:     */ 
/* 1265:     */ 
/* 1266:     */ 
/* 1267:     */ 
/* 1268:     */ 
/* 1269:     */ 
/* 1270:     */ 
/* 1271:     */ 
/* 1272:     */ 
/* 1273:     */ 
/* 1274:     */ 
/* 1275:     */ 
/* 1276:     */ 
/* 1277:     */ 
/* 1278:     */ 
/* 1279:     */ 
/* 1280:     */ 
/* 1281:     */ 
/* 1282:     */ 
/* 1283:     */ 
/* 1284:     */ 
/* 1285:     */ 
/* 1286:     */ 
/* 1287:     */ 
/* 1288:     */ 
/* 1289:     */ 
/* 1290:     */ 
/* 1291:     */ 
/* 1292:     */       }
/* 1293:1293 */       else if (1x == 2x) {
/* 1294:1294 */         upper_first = (2z - 3z) * (cop.x - 3x) / (2x - 3x) + 3z + (2z - 1z) * (cop.y - 1y) / (2y - 1y) + 1z - 2z > cop.z;
/* 1295:     */       } else {
/* 1296:1296 */         upper_first = (2z - 1z) * (cop.x - 1x) / (2x - 1x) + 1z + (2z - 3z) * (cop.y - 3y) / (2y - 3y) + 3z - 2z > cop.z;
/* 1297:     */       }
/* 1298:     */       
/* 1299:     */ 
/* 1300:     */ 
/* 1301:     */ 
/* 1302:     */ 
/* 1303:     */ 
/* 1304:     */ 
/* 1305:1305 */       if (lowercount < 3) {
/* 1306:1306 */         if (upper_first) {
/* 1307:1307 */           curve = 2;
/* 1308:1308 */           plotPlane(upperpart, uppercount);
/* 1309:1309 */           curve = 1;
/* 1310:1310 */           plotPlane(values1, 4);
/* 1311:     */         } else {
/* 1312:1312 */           curve = 1;
/* 1313:1313 */           plotPlane(values1, 4);
/* 1314:1314 */           curve = 2;
/* 1315:1315 */           plotPlane(upperpart, uppercount);
/* 1316:     */         }
/* 1317:1317 */       } else if (uppercount < 3) {
/* 1318:1318 */         if (upper_first) {
/* 1319:1319 */           curve = 1;
/* 1320:1320 */           plotPlane(values1, 4);
/* 1321:1321 */           curve = 2;
/* 1322:1322 */           plotPlane(lowerpart, lowercount);
/* 1323:     */         } else {
/* 1324:1324 */           curve = 2;
/* 1325:1325 */           plotPlane(lowerpart, lowercount);
/* 1326:1326 */           curve = 1;
/* 1327:1327 */           plotPlane(values1, 4);
/* 1328:     */         }
/* 1329:     */       }
/* 1330:1330 */       else if (upper_first) {
/* 1331:1331 */         curve = 2;
/* 1332:1332 */         plotPlane(upperpart, uppercount);
/* 1333:1333 */         curve = 1;
/* 1334:1334 */         plotPlane(values1, 4);
/* 1335:1335 */         curve = 2;
/* 1336:1336 */         plotPlane(lowerpart, lowercount);
/* 1337:     */       } else {
/* 1338:1338 */         curve = 2;
/* 1339:1339 */         plotPlane(lowerpart, lowercount);
/* 1340:1340 */         curve = 1;
/* 1341:1341 */         plotPlane(values1, 4);
/* 1342:1342 */         curve = 2;
/* 1343:1343 */         plotPlane(upperpart, uppercount);
/* 1344:     */       }
/* 1345:     */     }
/* 1346:     */   }
/* 1347:     */   
/* 1348:     */ 
/* 1349:     */ 
/* 1350:     */ 
/* 1351:     */ 
/* 1352:     */ 
/* 1353:     */ 
/* 1354:     */ 
/* 1355:     */ 
/* 1356:     */ 
/* 1357:     */ 
/* 1358:1358 */   private boolean plotTable(SurfaceVertex[] values) { return (!values[0].isInvalid()) && (!values[1].isInvalid()) && (!values[2].isInvalid()) && (!values[3].isInvalid()); }
/* 1359:     */   
/* 1360:1360 */   private final SurfaceVertex[] values1 = new SurfaceVertex[4];
/* 1361:1361 */   private final SurfaceVertex[] values2 = new SurfaceVertex[4];
/* 1362:     */   
/* 1363:     */ 
/* 1364:     */ 
/* 1365:     */ 
/* 1366:     */ 
/* 1367:     */ 
/* 1368:     */ 
/* 1369:     */ 
/* 1370:     */ 
/* 1371:     */ 
/* 1372:     */ 
/* 1373:     */   private void plotArea(int start_lx, int start_ly, int end_lx, int end_ly, int sx, int sy)
/* 1374:     */   {
/* 1375:1375 */     start_lx *= (calc_divisions + 1);
/* 1376:1376 */     sx *= (calc_divisions + 1);
/* 1377:1377 */     end_lx *= (calc_divisions + 1);
/* 1378:     */     
/* 1379:1379 */     int lx = start_lx;
/* 1380:1380 */     int ly = start_ly;
/* 1381:     */     
/* 1382:1382 */     while (ly != end_ly) {
/* 1383:1383 */       if (plotfunc1) {
/* 1384:1384 */         values1[1] = surfaceVertex[(lx + ly)];
/* 1385:1385 */         values1[2] = surfaceVertex[(lx + ly + sy)];
/* 1386:     */       }
/* 1387:     */       
/* 1388:1388 */       while (lx != end_lx) {
/* 1389:1389 */         Thread.yield();
/* 1390:1390 */         if (plotfunc1) {
/* 1391:1391 */           values1[0] = values1[1];
/* 1392:1392 */           values1[1] = surfaceVertex[(lx + sx + ly)];
/* 1393:1393 */           values1[3] = values1[2];
/* 1394:1394 */           values1[2] = surfaceVertex[(lx + sx + ly + sy)];
/* 1395:     */         }
/* 1396:1396 */         if (plotfunc1) {
/* 1397:1397 */           curve = 1;
/* 1398:1398 */           if (plotTable(values1)) {
/* 1399:1399 */             plotPlane(values1, 4);
/* 1400:     */           }
/* 1401:     */         }
/* 1402:1402 */         lx += sx;
/* 1403:     */       }
/* 1404:1404 */       ly += sy;
/* 1405:1405 */       lx = start_lx;
/* 1406:     */     }
/* 1407:     */   }
/* 1408:     */   
/* 1409:     */ 
/* 1410:     */ 
/* 1411:     */ 
/* 1412:     */ 
/* 1413:     */ 
/* 1414:     */ 
/* 1415:     */   private void plotSurface()
/* 1416:     */   {
/* 1417:     */     try
/* 1418:     */     {
/* 1419:1419 */       float zi = model.getZMin();
/* 1420:1420 */       float zx = model.getZMax();
/* 1421:1421 */       if (zi >= zx)
/* 1422:1422 */         throw new NumberFormatException();
/* 1423:     */     } catch (NumberFormatException e) {
/* 1424:     */       return;
/* 1425:     */     }
/* 1426:     */     float zx;
/* 1427:     */     float zi;
/* 1428:1428 */     int plot_density = model.getDispDivisions();
/* 1429:1429 */     int multiple_factor = calc_divisions / plot_density;
/* 1430:     */     
/* 1431:     */ 
/* 1432:1432 */     Thread.yield();
/* 1433:1433 */     zmin = zi;
/* 1434:1434 */     zmax = zx;
/* 1435:1435 */     color_factor = (1.0F / (zmax - zmin));
/* 1436:     */     
/* 1437:1437 */     if (!printing) {
/* 1438:1438 */       graphics.setColor(colors.getBackgroundColor());
/* 1439:1439 */       graphics.fillRect(0, 0, getBounds()width, getBounds()height);
/* 1440:     */     }
/* 1441:     */     
/* 1442:1442 */     drawBoxGridsTicksLabels(graphics, false);
/* 1443:     */     
/* 1444:1444 */     if (!plotfunc1) {
/* 1445:1445 */       if (isBoxed) {
/* 1446:1446 */         drawBoundingBox();
/* 1447:     */       }
/* 1448:1448 */       return;
/* 1449:     */     }
/* 1450:     */     
/* 1451:1451 */     projector.setZRange(zmin, zmax);
/* 1452:     */     
/* 1453:     */ 
/* 1454:     */ 
/* 1455:1455 */     float distance = projector.getDistance() * projector.getCosElevationAngle();
/* 1456:     */     
/* 1457:     */ 
/* 1458:     */ 
/* 1459:1459 */     cop = new SurfaceVertex(distance * projector.getSinRotationAngle(), distance * projector.getCosRotationAngle(), projector.getDistance() * projector.getSinElevationAngle());
/* 1460:1460 */     cop.transform(projector);
/* 1461:     */     
/* 1462:1462 */     boolean inc_x = cop.x > 0.0F;
/* 1463:1463 */     boolean inc_y = cop.y > 0.0F;
/* 1464:     */     
/* 1465:1465 */     critical = false;
/* 1466:     */     int sx;
/* 1467:1467 */     int start_lx; int end_lx; int sx; if (inc_x) {
/* 1468:1468 */       int start_lx = 0;
/* 1469:1469 */       int end_lx = calc_divisions;
/* 1470:1470 */       sx = multiple_factor;
/* 1471:     */     } else {
/* 1472:1472 */       start_lx = calc_divisions;
/* 1473:1473 */       end_lx = 0;
/* 1474:1474 */       sx = -multiple_factor; }
/* 1475:     */     int sy;
/* 1476:1476 */     int start_ly; int end_ly; int sy; if (inc_y) {
/* 1477:1477 */       int start_ly = 0;
/* 1478:1478 */       int end_ly = calc_divisions;
/* 1479:1479 */       sy = multiple_factor;
/* 1480:     */     } else {
/* 1481:1481 */       start_ly = calc_divisions;
/* 1482:1482 */       end_ly = 0;
/* 1483:1483 */       sy = -multiple_factor;
/* 1484:     */     }
/* 1485:     */     
/* 1486:1486 */     if ((cop.x > 10.0F) || (cop.x < -10.0F)) {
/* 1487:1487 */       if ((cop.y > 10.0F) || (cop.y < -10.0F)) {
/* 1488:1488 */         plotArea(start_lx, start_ly, end_lx, end_ly, sx, sy);
/* 1489:     */       } else {
/* 1490:1490 */         int split_y = (int)((cop.y + 10.0F) * plot_density / 20.0F) * multiple_factor;
/* 1491:1491 */         plotArea(start_lx, 0, end_lx, split_y, sx, multiple_factor);
/* 1492:1492 */         plotArea(start_lx, calc_divisions, end_lx, split_y, sx, -multiple_factor);
/* 1493:     */       }
/* 1494:     */     }
/* 1495:1495 */     else if ((cop.y > 10.0F) || (cop.y < -10.0F)) {
/* 1496:1496 */       int split_x = (int)((cop.x + 10.0F) * plot_density / 20.0F) * multiple_factor;
/* 1497:1497 */       plotArea(0, start_ly, split_x, end_ly, multiple_factor, sy);
/* 1498:1498 */       plotArea(calc_divisions, start_ly, split_x, end_ly, -multiple_factor, sy);
/* 1499:     */     } else {
/* 1500:1500 */       int split_x = (int)((cop.x + 10.0F) * plot_density / 20.0F) * multiple_factor;
/* 1501:1501 */       int split_y = (int)((cop.y + 10.0F) * plot_density / 20.0F) * multiple_factor;
/* 1502:1502 */       critical = true;
/* 1503:1503 */       plotArea(0, 0, split_x, split_y, multiple_factor, multiple_factor);
/* 1504:1504 */       plotArea(0, calc_divisions, split_x, split_y, multiple_factor, -multiple_factor);
/* 1505:1505 */       plotArea(calc_divisions, 0, split_x, split_y, -multiple_factor, multiple_factor);
/* 1506:1506 */       plotArea(calc_divisions, calc_divisions, split_x, split_y, -multiple_factor, -multiple_factor);
/* 1507:     */     }
/* 1508:     */     
/* 1509:     */ 
/* 1510:1510 */     if (isBoxed)
/* 1511:1511 */       drawBoundingBox();
/* 1512:     */   }
/* 1513:     */   
/* 1514:1514 */   private int contour_center_x = 0;
/* 1515:1515 */   private int contour_center_y = 0;
/* 1516:1516 */   private int contour_space_x = 0;
/* 1517:1517 */   private int legend_width = 0;
/* 1518:1518 */   private int legend_space = 0;
/* 1519:1519 */   private int legend_length = 0;
/* 1520:1520 */   private String[] legend_label = null;
/* 1521:1521 */   private float contour_width_x = 0.0F;
/* 1522:1522 */   private float contour_width_y = 0.0F;
/* 1523:1523 */   private Color[] contour_color = null;
/* 1524:1524 */   private String[] ylabels = null;
/* 1525:1525 */   private int[] xpoints = new int[8];
/* 1526:1526 */   private int[] ypoints = new int[8];
/* 1527:1527 */   private int[] contour_x = new int[8];
/* 1528:1528 */   private int[] contour_y = new int[8];
/* 1529:1529 */   private int contour_n = 0;
/* 1530:1530 */   private int contour_lines = 10;
/* 1531:1531 */   private float[] delta = new float[4];
/* 1532:1532 */   private float[] intersection = new float[4];
/* 1533:     */   private float contour_stepz;
/* 1534:1534 */   private SurfaceVertex[] contour_vertex = new SurfaceVertex[4];
/* 1535:1535 */   private LineAccumulator accumulator = new LineAccumulator();
/* 1536:     */   
/* 1537:     */ 
/* 1538:     */ 
/* 1539:     */ 
/* 1540:     */ 
/* 1541:     */ 
/* 1542:     */   private int contourConvertX(float x)
/* 1543:     */   {
/* 1544:1544 */     return Math.round(x * contour_width_x + contour_center_x);
/* 1545:     */   }
/* 1546:     */   
/* 1547:     */ 
/* 1548:     */ 
/* 1549:     */ 
/* 1550:     */ 
/* 1551:     */ 
/* 1552:     */   private int contourConvertY(float y)
/* 1553:     */   {
/* 1554:1554 */     return Math.round(-y * contour_width_y + contour_center_y);
/* 1555:     */   }
/* 1556:     */   
/* 1557:     */ 
/* 1558:     */ 
/* 1559:     */   private void drawBoundingRect()
/* 1560:     */   {
/* 1561:1561 */     graphics.setColor(colors.getLineBoxColor());
/* 1562:1562 */     int x1 = contourConvertX(-10.0F);
/* 1563:1563 */     int y1 = contourConvertY(10.0F);
/* 1564:1564 */     int x2 = contourConvertX(10.0F);
/* 1565:1565 */     int y2 = contourConvertY(-10.0F);
/* 1566:1566 */     graphics.drawRect(x1, y1, x2 - x1, y2 - y1);
/* 1567:     */     
/* 1568:1568 */     if ((isDisplayXY) || (isDisplayGrids))
/* 1569:     */     {
/* 1570:1570 */       if (isDisplayXY) {
/* 1571:1571 */         x1 = contourConvertX(-10.5F);
/* 1572:1572 */         y1 = contourConvertY(10.5F);
/* 1573:1573 */         x2 = contourConvertX(10.5F);
/* 1574:1574 */         y2 = contourConvertY(-10.5F);
/* 1575:1575 */         graphics.drawRect(x1, y1, x2 - x1, y2 - y1);
/* 1576:     */       }
/* 1577:     */       
/* 1578:1578 */       int labelindex = 0;
/* 1579:     */       
/* 1580:1580 */       for (int i = -10; i <= 10; i++) {
/* 1581:1581 */         if ((!isDisplayGrids) || (i % (t_y / 2) == 0) || (isDisplayXY)) {
/* 1582:1582 */           int yc = contourConvertY(i);
/* 1583:1583 */           if ((isDisplayGrids) && (i % t_y == 0)) {
/* 1584:1584 */             graphics.drawLine(contourConvertX(-10.0F), yc, contourConvertX(10.0F), yc);
/* 1585:     */           }
/* 1586:1586 */           if (isDisplayXY) {
/* 1587:1587 */             if (i % t_y != 0) {
/* 1588:1588 */               graphics.drawLine(contourConvertX(10.3F), yc, x2, yc);
/* 1589:1589 */               graphics.drawLine(contourConvertX(-10.3F), yc, x1, yc);
/* 1590:     */             } else {
/* 1591:1591 */               graphics.drawLine(contourConvertX(10.0F), yc, x2, yc);
/* 1592:1592 */               graphics.drawLine(contourConvertX(-10.0F), yc, x1, yc);
/* 1593:     */             }
/* 1594:     */           }
/* 1595:1595 */           if ((i % t_y == 0) && (isDisplayXY)) {
/* 1596:1596 */             outString(graphics, contourConvertX(10.7F), yc, ylabels[(labelindex++)], 0, 1);
/* 1597:     */           }
/* 1598:     */         }
/* 1599:1599 */         if ((!isDisplayGrids) || (i % (t_x / 2) == 0) || (isDisplayXY)) {
/* 1600:1600 */           int xc = contourConvertX(i);
/* 1601:1601 */           if ((isDisplayGrids) && (i % t_x == 0)) {
/* 1602:1602 */             graphics.drawLine(xc, contourConvertY(-10.0F), xc, contourConvertY(10.0F));
/* 1603:     */           }
/* 1604:1604 */           if (isDisplayXY) {
/* 1605:1605 */             if (i % t_x != 0) {
/* 1606:1606 */               graphics.drawLine(xc, contourConvertY(-10.3F), xc, y2);
/* 1607:1607 */               graphics.drawLine(xc, contourConvertY(10.3F), xc, y1);
/* 1608:     */             } else {
/* 1609:1609 */               graphics.drawLine(xc, contourConvertY(-10.0F), xc, y2);
/* 1610:1610 */               graphics.drawLine(xc, contourConvertY(10.0F), xc, y1);
/* 1611:     */             }
/* 1612:     */           }
/* 1613:1613 */           if ((i % t_x == 0) && (isDisplayXY)) {
/* 1614:1614 */             outFloat(graphics, xc, contourConvertY(-10.7F), (float)((i + 10) / 20.0D * (xmax - xmin) + xmin), 1, 0);
/* 1615:     */           }
/* 1616:     */         }
/* 1617:1617 */         if (isDisplayXY) {
/* 1618:1618 */           outString(graphics, (x1 + x2) / 2, contourConvertY(-11.4F), xLabel, 1, 0);
/* 1619:1619 */           outString(graphics, contourConvertX(10.7F), contourConvertY(-1.0F), yLabel, 0, 1);
/* 1620:     */         }
/* 1621:     */       }
/* 1622:     */     }
/* 1623:     */     
/* 1624:1624 */     if (isDisplayZ) {
/* 1625:1625 */       int lasty = y2;int height = y2 - y1;
/* 1626:1626 */       int divisions = contour_lines;
/* 1627:     */       
/* 1628:1628 */       x2 += contour_space_x;
/* 1629:1629 */       x1 = x2 - (legend_space + legend_width + legend_length);
/* 1630:1630 */       x2 -= legend_length;
/* 1631:     */       
/* 1632:1632 */       graphics.setColor(colors.getTextColor());
/* 1633:1633 */       outString(graphics, x2, y2, legend_label[0], 0, 1);
/* 1634:     */       
/* 1635:1635 */       for (int i = 1; i <= divisions + 1; i++) {
/* 1636:1636 */         int y = y2 - i * height / (divisions + 1);
/* 1637:1637 */         graphics.setColor(contour_color[(i - 1)]);
/* 1638:1638 */         graphics.fillRect(x1, y, legend_width, lasty - y);
/* 1639:1639 */         graphics.setColor(colors.getLineColor());
/* 1640:1640 */         graphics.drawRect(x1, y, legend_width, lasty - y);
/* 1641:1641 */         outString(graphics, x2, y, legend_label[i], 0, 1);
/* 1642:1642 */         lasty = y;
/* 1643:     */       }
/* 1644:     */     }
/* 1645:     */   }
/* 1646:     */   
/* 1647:     */ 
/* 1648:     */ 
/* 1649:     */ 
/* 1650:     */ 
/* 1651:     */ 
/* 1652:     */ 
/* 1653:     */   private void cleanUpMemory()
/* 1654:     */   {
/* 1655:1655 */     legend_label = null;
/* 1656:1656 */     contour_color = null;
/* 1657:1657 */     ylabels = null;
/* 1658:1658 */     accumulator.clearAccumulator();
/* 1659:     */   }
/* 1660:     */   
/* 1661:     */ 
/* 1662:     */ 
/* 1663:     */ 
/* 1664:     */   private void computePlotArea()
/* 1665:     */   {
/* 1666:1666 */     setAxesScale();
/* 1667:1667 */     contour_lines = model.getContourLines();
/* 1668:     */     
/* 1669:1669 */     float ratio = projector.getYScaling() / projector.getXScaling();
/* 1670:     */     
/* 1671:1671 */     float width = 0.0F;
/* 1672:1672 */     float height = 0.0F;
/* 1673:     */     
/* 1674:1674 */     if (printing) {
/* 1675:1675 */       width = printwidth;
/* 1676:1676 */       height = printheight;
/* 1677:     */     } else {
/* 1678:1678 */       width = getBounds()width;
/* 1679:1679 */       height = getBounds()height;
/* 1680:     */     }
/* 1681:     */     
/* 1682:1682 */     int fontsize = 0;
/* 1683:     */     
/* 1684:1684 */     if (width < height) {
/* 1685:1685 */       fontsize = (int)(width / 48.0F);
/* 1686:     */     } else {
/* 1687:1687 */       fontsize = (int)(height / 48.0F);
/* 1688:     */     }
/* 1689:1689 */     graphics.setFont(new Font("Helvetica", 0, fontsize));
/* 1690:     */     
/* 1691:1691 */     FontMetrics fm = graphics.getFontMetrics();
/* 1692:     */     
/* 1693:     */ 
/* 1694:     */ 
/* 1695:1695 */     width *= 0.9F;
/* 1696:1696 */     height *= 0.9F;
/* 1697:     */     
/* 1698:1698 */     int spacex = 0;
/* 1699:1699 */     int spacey = 0;
/* 1700:     */     
/* 1701:1701 */     if (isDisplayXY)
/* 1702:     */     {
/* 1703:     */ 
/* 1704:     */ 
/* 1705:1705 */       int labelscount = 0;int index = 0;int maxwidth = 0;
/* 1706:1706 */       for (int i = -10; i < 10; i++) {
/* 1707:1707 */         if (i % t_y == 0) {
/* 1708:1708 */           labelscount++;
/* 1709:     */         }
/* 1710:     */       }
/* 1711:1711 */       ylabels = new String[labelscount];
/* 1712:     */       
/* 1713:1713 */       for (int i = -10; i < 10; i++) {
/* 1714:1714 */         if (i % t_y == 0) {
/* 1715:1715 */           ylabels[index] = 
/* 1716:     */           
/* 1717:1717 */             format((float)((i + 10) / 20.0D * (ymax - ymin) + ymin));
/* 1718:1718 */           int strwidth = fm.stringWidth(ylabels[(index++)]);
/* 1719:1719 */           if (strwidth > maxwidth) {
/* 1720:1720 */             maxwidth = strwidth;
/* 1721:     */           }
/* 1722:     */         }
/* 1723:     */       }
/* 1724:     */       
/* 1725:1725 */       spacex += maxwidth;
/* 1726:1726 */       spacey += fm.getMaxAscent();
/* 1727:     */     }
/* 1728:     */     
/* 1729:1729 */     if (isDisplayZ) {
/* 1730:1730 */       legend_width = ((int)(width * 0.05D));
/* 1731:1731 */       spacex += legend_width * 2;
/* 1732:1732 */       legend_space = fontsize;
/* 1733:     */       
/* 1734:     */ 
/* 1735:     */ 
/* 1736:1736 */       int counts = contour_lines;
/* 1737:1737 */       legend_length = 0;
/* 1738:1738 */       counts += 2;
/* 1739:     */       
/* 1740:1740 */       legend_label = new String[counts];
/* 1741:1741 */       for (int i = 0; i < counts; i++) {
/* 1742:1742 */         float label = (float)(i / (counts - 1) * (zmax - zmin) + zmin);
/* 1743:1743 */         legend_label[i] = format(label);
/* 1744:1744 */         int labelwidth = fm.stringWidth(legend_label[i]);
/* 1745:1745 */         if (labelwidth > legend_length) {
/* 1746:1746 */           legend_length = labelwidth;
/* 1747:     */         }
/* 1748:     */       }
/* 1749:     */       
/* 1750:1750 */       spacex += legend_length + legend_space;
/* 1751:     */     }
/* 1752:     */     
/* 1753:1753 */     width -= spacex;
/* 1754:1754 */     height -= spacey;
/* 1755:     */     
/* 1756:1756 */     contour_width_x = width;
/* 1757:1757 */     contour_width_y = (width * ratio);
/* 1758:     */     
/* 1759:1759 */     if (contour_width_y > height) {
/* 1760:1760 */       contour_width_y = height;
/* 1761:1761 */       contour_width_x = (height / ratio);
/* 1762:     */     }
/* 1763:     */     
/* 1764:1764 */     float scaling_factor = 10.0F;
/* 1765:1765 */     if (isDisplayXY) {
/* 1766:1766 */       scaling_factor = 10.7F;
/* 1767:     */     }
/* 1768:1768 */     contour_width_x = (contour_width_x / scaling_factor / 2.0F);
/* 1769:1769 */     contour_width_y = (contour_width_y / scaling_factor / 2.0F);
/* 1770:     */     
/* 1771:1771 */     contour_center_x = 0;
/* 1772:1772 */     contour_center_y = 0;
/* 1773:     */     
/* 1774:1774 */     int x1 = contourConvertX(-scaling_factor);
/* 1775:1775 */     int y1 = contourConvertY(scaling_factor);
/* 1776:1776 */     int x2 = contourConvertX(scaling_factor) + spacex;
/* 1777:1777 */     int y2 = contourConvertY(-scaling_factor) + spacey;
/* 1778:     */     
/* 1779:     */ 
/* 1780:     */ 
/* 1781:1781 */     contour_center_x = ((getBounds()width - (x1 + x2)) / 2);
/* 1782:1782 */     contour_center_y = ((getBounds()height - (y1 + y2)) / 2);
/* 1783:     */     
/* 1784:1784 */     contour_space_x = spacex;
/* 1785:     */     
/* 1786:     */ 
/* 1787:     */ 
/* 1788:1788 */     contour_color = new Color[contour_lines + 1];
/* 1789:1789 */     for (int i = 0; i <= contour_lines; i++) {
/* 1790:1790 */       float level = i / contour_lines;
/* 1791:1791 */       contour_color[i] = colors.getPolygonColor(curve, level);
/* 1792:     */     }
/* 1793:     */   }
/* 1794:     */   
/* 1795:     */ 
/* 1796:     */ 
/* 1797:     */ 
/* 1798:     */ 
/* 1799:     */ 
/* 1800:     */   private void createContour()
/* 1801:     */   {
/* 1802:1802 */     float z = zmin;
/* 1803:     */     
/* 1804:1804 */     int xmin = xpoints[0] = contourConvertX(contour_vertex[0].x);
/* 1805:1805 */     int xmax = xpoints[4] = contourConvertX(contour_vertex[2].x);
/* 1806:     */     
/* 1807:1807 */     ypoints[0] = contourConvertY(contour_vertex[0].y);
/* 1808:1808 */     xpoints[2] = contourConvertX(contour_vertex[1].x);
/* 1809:1809 */     ypoints[4] = contourConvertY(contour_vertex[2].y);
/* 1810:1810 */     xpoints[6] = contourConvertX(contour_vertex[3].x); int 
/* 1811:     */     
/* 1812:1812 */       tmp147_144 = contourConvertY(contour_vertex[1].y);ypoints[3] = tmp147_144;ypoints[2] = tmp147_144; int 
/* 1813:1813 */       tmp175_172 = contourConvertY(contour_vertex[3].y);ypoints[7] = tmp175_172;ypoints[6] = tmp175_172; byte 
/* 1814:     */     
/* 1815:1815 */       tmp204_203 = (xpoints[5] = xpoints[7] = -1);xpoints[3] = tmp204_203;xpoints[1] = tmp204_203;
/* 1816:     */     
/* 1817:1817 */     for (int counter = 0; counter <= contour_lines + 1; counter++)
/* 1818:     */     {
/* 1819:     */ 
/* 1820:1820 */       for (int edge = 0; edge < 4; edge++) {
/* 1821:1821 */         int index = (edge << 1) + 1;
/* 1822:1822 */         int nextedge = edge + 1 & 0x3;
/* 1823:     */         
/* 1824:1824 */         if (z > contour_vertex[edge].z) {
/* 1825:1825 */           xpoints[(index - 1)] = -2;
/* 1826:1826 */           if (z > contour_vertex[nextedge].z) {
/* 1827:1827 */             xpoints[(index + 1 & 0x7)] = -2;
/* 1828:1828 */             xpoints[index] = -2;
/* 1829:     */           }
/* 1830:1830 */         } else if (z > contour_vertex[nextedge].z) {
/* 1831:1831 */           xpoints[(index + 1 & 0x7)] = -2;
/* 1832:     */         }
/* 1833:     */         
/* 1834:1834 */         if (xpoints[index] != -2) {
/* 1835:1835 */           if (xpoints[index] != -1) {
/* 1836:1836 */             intersection[edge] += delta[edge];
/* 1837:1837 */             if ((index == 1) || (index == 5)) {
/* 1838:1838 */               ypoints[index] = contourConvertY(intersection[edge]);
/* 1839:     */             } else {
/* 1840:1840 */               xpoints[index] = contourConvertX(intersection[edge]);
/* 1841:     */             }
/* 1842:     */           }
/* 1843:1843 */           else if ((z > contour_vertex[edge].z) || (z > contour_vertex[nextedge].z)) {
/* 1844:1844 */             switch (index) {
/* 1845:     */             case 1: 
/* 1846:1846 */               delta[edge] = ((contour_vertex[nextedge].y - contour_vertex[edge].y) * contour_stepz / (contour_vertex[nextedge].z - contour_vertex[edge].z));
/* 1847:     */               
/* 1848:1848 */               intersection[edge] = ((contour_vertex[nextedge].y * (z - contour_vertex[edge].z) + contour_vertex[edge].y * (contour_vertex[nextedge].z - z)) / (contour_vertex[nextedge].z - contour_vertex[edge].z));
/* 1849:     */               
/* 1850:1850 */               xpoints[index] = xmin;
/* 1851:1851 */               ypoints[index] = contourConvertY(intersection[edge]);
/* 1852:1852 */               break;
/* 1853:     */             case 3: 
/* 1854:1854 */               delta[edge] = ((contour_vertex[nextedge].x - contour_vertex[edge].x) * contour_stepz / (contour_vertex[nextedge].z - contour_vertex[edge].z));
/* 1855:     */               
/* 1856:1856 */               intersection[edge] = ((contour_vertex[nextedge].x * (z - contour_vertex[edge].z) + contour_vertex[edge].x * (contour_vertex[nextedge].z - z)) / (contour_vertex[nextedge].z - contour_vertex[edge].z));
/* 1857:     */               
/* 1858:1858 */               xpoints[index] = contourConvertX(intersection[edge]);
/* 1859:1859 */               break;
/* 1860:     */             case 5: 
/* 1861:1861 */               delta[edge] = ((contour_vertex[edge].y - contour_vertex[nextedge].y) * contour_stepz / (contour_vertex[edge].z - contour_vertex[nextedge].z));
/* 1862:     */               
/* 1863:1863 */               intersection[edge] = ((contour_vertex[edge].y * (z - contour_vertex[nextedge].z) + contour_vertex[nextedge].y * (contour_vertex[edge].z - z)) / (contour_vertex[edge].z - contour_vertex[nextedge].z));
/* 1864:     */               
/* 1865:1865 */               xpoints[index] = xmax;
/* 1866:1866 */               ypoints[index] = contourConvertY(intersection[edge]);
/* 1867:1867 */               break;
/* 1868:     */             case 7: 
/* 1869:1869 */               delta[edge] = ((contour_vertex[edge].x - contour_vertex[nextedge].x) * contour_stepz / (contour_vertex[edge].z - contour_vertex[nextedge].z));
/* 1870:     */               
/* 1871:1871 */               intersection[edge] = ((contour_vertex[edge].x * (z - contour_vertex[nextedge].z) + contour_vertex[nextedge].x * (contour_vertex[edge].z - z)) / (contour_vertex[edge].z - contour_vertex[nextedge].z));
/* 1872:     */               
/* 1873:1873 */               xpoints[index] = contourConvertX(intersection[edge]);
/* 1874:     */             }
/* 1875:     */             
/* 1876:     */           }
/* 1877:     */         }
/* 1878:     */       }
/* 1879:     */       
/* 1880:     */ 
/* 1881:     */ 
/* 1882:1882 */       contour_n = 0;
/* 1883:     */       
/* 1884:1884 */       for (int index = 0; index < 8; index++) {
/* 1885:1885 */         if (xpoints[index] >= 0) {
/* 1886:1886 */           contour_x[contour_n] = xpoints[index];
/* 1887:1887 */           contour_y[contour_n] = ypoints[index];
/* 1888:1888 */           contour_n += 1;
/* 1889:     */         }
/* 1890:     */       }
/* 1891:1891 */       if (counter > contour_lines) {
/* 1892:1892 */         if (printing) {
/* 1893:1893 */           graphics.setColor(Color.white);
/* 1894:     */         } else {
/* 1895:1895 */           graphics.setColor(colors.getBackgroundColor());
/* 1896:     */         }
/* 1897:     */       } else {
/* 1898:1898 */         graphics.setColor(contour_color[counter]);
/* 1899:     */       }
/* 1900:1900 */       if ((ok(contour_x, contour_n)) && (ok(contour_y, contour_n))) {
/* 1901:1901 */         graphics.fillPolygon(contour_x, contour_y, contour_n);
/* 1902:     */       }
/* 1903:     */       
/* 1904:     */ 
/* 1905:1905 */       if (isMesh) {
/* 1906:1906 */         int x = -1;
/* 1907:1907 */         int y = -1;
/* 1908:     */         
/* 1909:1909 */         for (int index = 1; index < 8; index += 2) {
/* 1910:1910 */           if (xpoints[index] >= 0) {
/* 1911:1911 */             if (x != -1) {
/* 1912:1912 */               accumulator.addLine(x, y, xpoints[index], ypoints[index]);
/* 1913:     */             }
/* 1914:1914 */             x = xpoints[index];
/* 1915:1915 */             y = ypoints[index];
/* 1916:     */           }
/* 1917:     */         }
/* 1918:1918 */         if ((xpoints[1] > 0) && (x != -1)) {
/* 1919:1919 */           accumulator.addLine(x, y, xpoints[1], ypoints[1]);
/* 1920:     */         }
/* 1921:     */       }
/* 1922:     */       
/* 1923:1923 */       if (contour_n < 3) {
/* 1924:     */         break;
/* 1925:     */       }
/* 1926:1926 */       z += contour_stepz;
/* 1927:     */     }
/* 1928:     */   }
/* 1929:     */   
/* 1930:     */   private boolean ok(int[] f, int x) {
/* 1931:1931 */     for (int i = 0; i < x; i++) {
/* 1932:1932 */       if (f[i] <= 0) {
/* 1933:1933 */         return false;
/* 1934:     */       }
/* 1935:     */     }
/* 1936:1936 */     return true;
/* 1937:     */   }
/* 1938:     */   
/* 1939:     */ 
/* 1940:     */ 
/* 1941:     */ 
/* 1942:     */ 
/* 1943:     */   private void plotContour()
/* 1944:     */   {
/* 1945:1945 */     accumulator.clearAccumulator();
/* 1946:     */     try
/* 1947:     */     {
/* 1948:1948 */       float zi = model.getZMin();
/* 1949:1949 */       float zx = model.getZMax();
/* 1950:1950 */       if (zi >= zx) {
/* 1951:1951 */         throw new NumberFormatException();
/* 1952:     */       }
/* 1953:     */     } catch (NumberFormatException e) {
/* 1954:1954 */       System.out.println("plotContour:Error in ranges"); return;
/* 1955:     */     }
/* 1956:     */     float zx;
/* 1957:     */     float zi;
/* 1958:1958 */     zmin = zi;
/* 1959:1959 */     zmax = zx;
/* 1960:1960 */     curve = 1;
/* 1961:     */     
/* 1962:1962 */     computePlotArea();
/* 1963:     */     
/* 1964:1964 */     int plot_density = model.getDispDivisions();
/* 1965:1965 */     int multiple_factor = calc_divisions / plot_density;
/* 1966:     */     
/* 1967:     */ 
/* 1968:1968 */     Thread.yield();
/* 1969:1969 */     contour_stepz = ((zx - zi) / (contour_lines + 1));
/* 1970:     */     
/* 1971:     */ 
/* 1972:     */ 
/* 1973:1973 */     if (!printing) {
/* 1974:1974 */       graphics.setColor(colors.getBackgroundColor());
/* 1975:1975 */       graphics.fillRect(0, 0, getBounds()width, getBounds()height);
/* 1976:     */     }
/* 1977:     */     
/* 1978:1978 */     if (plotfunc1) {
/* 1979:1979 */       int index = 0;
/* 1980:1980 */       int func = 0;
/* 1981:1981 */       curve = (func + 1);
/* 1982:     */       
/* 1983:1983 */       int delta = (calc_divisions + 1) * multiple_factor;
/* 1984:1984 */       for (int i = 0; i < calc_divisions; i += multiple_factor) {
/* 1985:1985 */         index = i * (calc_divisions + 1);
/* 1986:1986 */         for (int j = 0; j < calc_divisions; j += multiple_factor) {
/* 1987:1987 */           contour_vertex[0] = surfaceVertex[index];
/* 1988:1988 */           contour_vertex[1] = surfaceVertex[(index + multiple_factor)];
/* 1989:1989 */           contour_vertex[2] = surfaceVertex[(index + delta + multiple_factor)];
/* 1990:1990 */           contour_vertex[3] = surfaceVertex[(index + delta)];
/* 1991:1991 */           createContour();
/* 1992:1992 */           index += multiple_factor;
/* 1993:     */         }
/* 1994:     */       }
/* 1995:     */     }
/* 1996:     */     
/* 1997:     */ 
/* 1998:1998 */     graphics.setColor(colors.getLineColor());
/* 1999:1999 */     accumulator.drawAll(graphics);
/* 2000:     */     
/* 2001:2001 */     if (optimum != null) {
/* 2002:2002 */       outPoint(graphics, contour_center_x, contour_center_y);
/* 2003:     */     }
/* 2004:     */     
/* 2005:     */ 
/* 2006:2006 */     drawBoundingRect();
/* 2007:     */   }
/* 2008:     */   
/* 2009:     */ 
/* 2010:     */ 
/* 2011:     */ 
/* 2012:     */   private void plotDensity()
/* 2013:     */   {
/* 2014:     */     try
/* 2015:     */     {
/* 2016:2016 */       float zi = model.getZMin();
/* 2017:2017 */       float zx = model.getZMax();
/* 2018:2018 */       if (zi >= zx) {
/* 2019:2019 */         throw new NumberFormatException();
/* 2020:     */       }
/* 2021:     */     } catch (NumberFormatException e) {
/* 2022:2022 */       System.out.println("Error in ranges"); return;
/* 2023:     */     }
/* 2024:     */     float zx;
/* 2025:     */     float zi;
/* 2026:2026 */     zmin = zi;
/* 2027:2027 */     zmax = zx;
/* 2028:     */     
/* 2029:2029 */     curve = 1;
/* 2030:     */     
/* 2031:2031 */     computePlotArea();
/* 2032:2032 */     int plot_density = model.getDispDivisions();
/* 2033:2033 */     int multiple_factor = calc_divisions / plot_density;
/* 2034:     */     
/* 2035:2035 */     color_factor = (1.0F / (zx - zi));
/* 2036:     */     
/* 2037:     */ 
/* 2038:2038 */     if (!printing) {
/* 2039:2039 */       graphics.setColor(colors.getBackgroundColor());
/* 2040:2040 */       graphics.fillRect(0, 0, getBounds()width, getBounds()height);
/* 2041:     */     }
/* 2042:     */     
/* 2043:2043 */     if (plotfunc1) {
/* 2044:2044 */       int index = 0;
/* 2045:2045 */       int func = 0;
/* 2046:2046 */       curve = (func + 1);
/* 2047:2047 */       int delta = (calc_divisions + 1) * multiple_factor;
/* 2048:2048 */       for (int i = 0; i < calc_divisions; i += multiple_factor) {
/* 2049:2049 */         index = i * (calc_divisions + 1);
/* 2050:2050 */         for (int j = 0; j < calc_divisions; j += multiple_factor) {
/* 2051:2051 */           contour_vertex[0] = surfaceVertex[index];
/* 2052:2052 */           contour_vertex[1] = surfaceVertex[(index + multiple_factor)];
/* 2053:2053 */           contour_vertex[2] = surfaceVertex[(index + delta + multiple_factor)];
/* 2054:2054 */           contour_vertex[3] = surfaceVertex[(index + delta)];
/* 2055:     */           
/* 2056:2056 */           int x = contourConvertX(contour_vertex[1].x);
/* 2057:2057 */           int y = contourConvertY(contour_vertex[1].y);
/* 2058:2058 */           int w = contourConvertX(contour_vertex[3].x) - x;
/* 2059:2059 */           int h = contourConvertY(contour_vertex[3].y) - y;
/* 2060:     */           
/* 2061:2061 */           float z = 0.0F;
/* 2062:2062 */           boolean error = false;
/* 2063:2063 */           for (int loop = 0; loop < 4; loop++) {
/* 2064:2064 */             if (Float.isNaN(contour_vertex[loop].z)) {
/* 2065:2065 */               error = true;
/* 2066:2066 */               break;
/* 2067:     */             }
/* 2068:2068 */             z += contour_vertex[loop].z;
/* 2069:     */           }
/* 2070:2070 */           if (error) {
/* 2071:2071 */             index += multiple_factor;
/* 2072:     */           }
/* 2073:     */           else
/* 2074:     */           {
/* 2075:2075 */             z /= 4.0F;
/* 2076:2076 */             z = (z - zi) * color_factor;
/* 2077:2077 */             graphics.setColor(colors.getPolygonColor(curve, z));
/* 2078:     */             
/* 2079:     */ 
/* 2080:2080 */             graphics.fillRect(x, y, w, h);
/* 2081:2081 */             if (isMesh) {
/* 2082:2082 */               graphics.setColor(colors.getLineColor(curve, z));
/* 2083:2083 */               graphics.drawRect(x, y, w, h);
/* 2084:     */             }
/* 2085:2085 */             index += multiple_factor;
/* 2086:     */           }
/* 2087:     */         }
/* 2088:     */       }
/* 2089:2089 */       if (optimum != null) {
/* 2090:2090 */         outPoint(graphics, contour_center_x, contour_center_y);
/* 2091:     */       }
/* 2092:     */     }
/* 2093:     */     
/* 2094:     */ 
/* 2095:2095 */     drawBoundingRect();
/* 2096:     */   }
/* 2097:     */   
/* 2098:     */ 
/* 2099:     */ 
/* 2100:     */ 
/* 2101:     */ 
/* 2102:     */ 
/* 2103:     */ 
/* 2104:     */ 
/* 2105:     */   private void plotWireframe()
/* 2106:     */   {
/* 2107:2107 */     float lx = 0.0F;float ly = 0.0F;float lastz = 0.0F;
/* 2108:2108 */     Point lastproj = new Point(0, 0);
/* 2109:     */     
/* 2110:     */ 
/* 2111:2111 */     projection = new Point(0, 0);
/* 2112:     */     try {
/* 2113:2113 */       float zi = model.getZMin();
/* 2114:2114 */       float zx = model.getZMax();
/* 2115:2115 */       if (zi >= zx) {
/* 2116:2116 */         throw new NumberFormatException();
/* 2117:     */       }
/* 2118:     */     } catch (NumberFormatException e) {
/* 2119:2119 */       System.out.println("Error in ranges"); return;
/* 2120:     */     }
/* 2121:     */     float zx;
/* 2122:     */     float zi;
/* 2123:2123 */     int plot_density = model.getDispDivisions();
/* 2124:2124 */     int multiple_factor = calc_divisions / plot_density;
/* 2125:     */     
/* 2126:2126 */     zmin = zi;
/* 2127:2127 */     zmax = zx;
/* 2128:     */     
/* 2129:2129 */     if (!printing) {
/* 2130:2130 */       graphics.setColor(colors.getBackgroundColor());
/* 2131:2131 */       graphics.fillRect(0, 0, getBounds()width, getBounds()height);
/* 2132:     */     }
/* 2133:     */     
/* 2134:2134 */     Thread.yield();
/* 2135:2135 */     drawBoxGridsTicksLabels(graphics, false);
/* 2136:     */     
/* 2137:2137 */     projector.setZRange(zmin, zmax);
/* 2138:     */     
/* 2139:2139 */     for (int func = 0; func < 2; func++)
/* 2140:2140 */       if ((func != 0) || (plotfunc1))
/* 2141:     */       {
/* 2142:     */ 
/* 2143:2143 */         if (func != 1)
/* 2144:     */         {
/* 2145:     */ 
/* 2146:     */ 
/* 2147:2147 */           int i = 0;
/* 2148:2148 */           int j = 0;
/* 2149:2149 */           int k = 0;
/* 2150:2150 */           int counter = 0;
/* 2151:     */           
/* 2152:     */ 
/* 2153:2153 */           while (i <= calc_divisions) {
/* 2154:2154 */             boolean lasterror = true;
/* 2155:2155 */             if (counter == 0) {
/* 2156:2156 */               while (j <= calc_divisions) {
/* 2157:2157 */                 Thread.yield();
/* 2158:2158 */                 float z = surfaceVertex[k].z;
/* 2159:2159 */                 boolean invalid = Float.isNaN(z);
/* 2160:2160 */                 boolean error; if (!invalid) {
/* 2161:2161 */                   graphics.setColor(colors.getLineColor(curve, z));
/* 2162:     */                   boolean error;
/* 2163:2163 */                   if (z < zmin) {
/* 2164:2164 */                     boolean error = true;
/* 2165:2165 */                     float ratio = (zmin - lastz) / (z - lastz);
/* 2166:2166 */                     projection = projector.project(ratio * (surfaceVertex[k].x - lx) + lx, ratio * (surfaceVertex[k].y - ly) + ly, -10.0F);
/* 2167:2167 */                   } else if (z > zmax) {
/* 2168:2168 */                     boolean error = true;
/* 2169:2169 */                     float ratio = (zmax - lastz) / (z - lastz);
/* 2170:2170 */                     projection = projector.project(ratio * (surfaceVertex[k].x - lx) + lx, ratio * (surfaceVertex[k].y - ly) + ly, 10.0F);
/* 2171:     */                   } else {
/* 2172:2172 */                     error = false;
/* 2173:2173 */                     projection = surfaceVertex[k].projection(projector);
/* 2174:     */                   }
/* 2175:2175 */                   if ((lasterror) && (!error) && (j != 0)) {
/* 2176:2176 */                     if (lastz > zmax) {
/* 2177:2177 */                       float ratio = (zmax - z) / (lastz - z);
/* 2178:2178 */                       lastproj = projector.project(ratio * (lx - surfaceVertex[k].x) + surfaceVertex[k].x, ratio * (ly - surfaceVertex[k].y) + surfaceVertex[k].y, 10.0F);
/* 2179:2179 */                     } else if (lastz < zmin) {
/* 2180:2180 */                       float ratio = (zmin - z) / (lastz - z);
/* 2181:2181 */                       lastproj = projector.project(ratio * (lx - surfaceVertex[k].x) + surfaceVertex[k].x, ratio * (ly - surfaceVertex[k].y) + surfaceVertex[k].y, -10.0F);
/* 2182:     */                     }
/* 2183:     */                   } else {
/* 2184:2184 */                     invalid = (error) && (lasterror);
/* 2185:     */                   }
/* 2186:     */                 } else {
/* 2187:2187 */                   error = true;
/* 2188:     */                 }
/* 2189:2189 */                 if ((!invalid) && (j != 0)) {
/* 2190:2190 */                   graphics.drawLine(x, y, projection.x, projection.y);
/* 2191:     */                 }
/* 2192:2192 */                 lastproj = projection;
/* 2193:2193 */                 lasterror = error;
/* 2194:2194 */                 lx = surfaceVertex[k].x;
/* 2195:2195 */                 ly = surfaceVertex[k].y;
/* 2196:2196 */                 lastz = z;
/* 2197:2197 */                 j++;
/* 2198:2198 */                 k++;
/* 2199:     */               }
/* 2200:     */             } else {
/* 2201:2201 */               k += calc_divisions + 1;
/* 2202:     */             }
/* 2203:2203 */             j = 0;
/* 2204:2204 */             i++;
/* 2205:2205 */             counter = (counter + 1) % multiple_factor;
/* 2206:     */           }
/* 2207:     */           
/* 2208:     */ 
/* 2209:2209 */           i = 0;
/* 2210:2210 */           j = 0;
/* 2211:2211 */           k = 0;
/* 2212:2212 */           counter = 0;
/* 2213:     */           
/* 2214:2214 */           while (j <= calc_divisions) {
/* 2215:2215 */             boolean lasterror = true;
/* 2216:2216 */             if (counter == 0) {
/* 2217:2217 */               while (i <= calc_divisions) {
/* 2218:2218 */                 Thread.yield();
/* 2219:2219 */                 float z = surfaceVertex[k].z;
/* 2220:2220 */                 boolean invalid = Float.isNaN(z);
/* 2221:2221 */                 boolean error; if (!invalid) { boolean error;
/* 2222:2222 */                   if (z < zmin) {
/* 2223:2223 */                     boolean error = true;
/* 2224:2224 */                     float ratio = (zmin - lastz) / (z - lastz);
/* 2225:2225 */                     projection = projector.project(ratio * (surfaceVertex[k].x - lx) + lx, ratio * (surfaceVertex[k].y - ly) + ly, -10.0F);
/* 2226:2226 */                   } else if (z > zmax) {
/* 2227:2227 */                     boolean error = true;
/* 2228:2228 */                     float ratio = (zmax - lastz) / (z - lastz);
/* 2229:2229 */                     projection = projector.project(ratio * (surfaceVertex[k].x - lx) + lx, ratio * (surfaceVertex[k].y - ly) + ly, 10.0F);
/* 2230:     */                   } else {
/* 2231:2231 */                     error = false;
/* 2232:2232 */                     projection = surfaceVertex[k].projection(projector);
/* 2233:     */                   }
/* 2234:2234 */                   if ((lasterror) && (!error) && (i != 0)) {
/* 2235:2235 */                     if (lastz > zmax) {
/* 2236:2236 */                       float ratio = (zmax - z) / (lastz - z);
/* 2237:2237 */                       lastproj = projector.project(ratio * (lx - surfaceVertex[k].x) + surfaceVertex[k].x, ratio * (ly - surfaceVertex[k].y) + surfaceVertex[k].y, 10.0F);
/* 2238:2238 */                     } else if (lastz < zmin) {
/* 2239:2239 */                       float ratio = (zmin - z) / (lastz - z);
/* 2240:2240 */                       lastproj = projector.project(ratio * (lx - surfaceVertex[k].x) + surfaceVertex[k].x, ratio * (ly - surfaceVertex[k].y) + surfaceVertex[k].y, -10.0F);
/* 2241:     */                     }
/* 2242:     */                   } else {
/* 2243:2243 */                     invalid = (error) && (lasterror);
/* 2244:     */                   }
/* 2245:     */                 } else {
/* 2246:2246 */                   error = true;
/* 2247:     */                 }
/* 2248:2248 */                 if ((!invalid) && (i != 0)) {
/* 2249:2249 */                   graphics.drawLine(x, y, projection.x, projection.y);
/* 2250:     */                 }
/* 2251:2251 */                 lastproj = projection;
/* 2252:2252 */                 lasterror = error;
/* 2253:2253 */                 lx = surfaceVertex[k].x;
/* 2254:2254 */                 ly = surfaceVertex[k].y;
/* 2255:2255 */                 lastz = z;
/* 2256:2256 */                 i++;
/* 2257:2257 */                 k += calc_divisions + 1;
/* 2258:     */               }
/* 2259:     */             }
/* 2260:2260 */             i = 0;
/* 2261:2261 */             j++;k = j;
/* 2262:2262 */             counter = (counter + 1) % multiple_factor;
/* 2263:     */           }
/* 2264:     */         } }
/* 2265:2265 */     if (isBoxed) {
/* 2266:2266 */       drawBoundingBox();
/* 2267:     */     }
/* 2268:     */   }
/* 2269:     */ }
