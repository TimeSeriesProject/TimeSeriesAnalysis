/*  1:   */ package ec.nbdemetra.ui.chart3d;
/*  2:   */ 
/*  3:   */ import java.awt.Graphics;
/*  4:   */ import java.util.LinkedList;
/*  5:   */ import java.util.List;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ public class LineAccumulator
/* 38:   */ {
/* 39:   */   private List<LineRecord> accumulator;
/* 40:   */   
/* 41:   */   LineAccumulator()
/* 42:   */   {
/* 43:43 */     accumulator = new LinkedList();
/* 44:   */   }
/* 45:   */   
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */   public void addLine(int x1, int y1, int x2, int y2)
/* 54:   */   {
/* 55:55 */     if ((x1 <= 0) || (y1 <= 0) || (x2 <= 0) || (y2 <= 0)) {
/* 56:56 */       return;
/* 57:   */     }
/* 58:58 */     accumulator.add(new LineRecord(x1, y1, x2, y2));
/* 59:   */   }
/* 60:   */   
/* 61:   */ 
/* 62:   */ 
/* 63:   */   public void clearAccumulator()
/* 64:   */   {
/* 65:65 */     accumulator.clear();
/* 66:   */   }
/* 67:   */   
/* 68:   */ 
/* 69:   */ 
/* 70:   */ 
/* 71:   */ 
/* 72:   */   public void drawAll(Graphics g)
/* 73:   */   {
/* 74:74 */     for (LineRecord line : accumulator) {
/* 75:75 */       g.drawLine(x1, y1, x2, y2);
/* 76:   */     }
/* 77:   */   }
/* 78:   */ }
