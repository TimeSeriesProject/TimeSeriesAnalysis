/*   1:    */ package ec.nbdemetra.ui.chart3d.functions;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.awt.ExceptionPanel;
/*   4:    */ import ec.nbdemetra.ui.chart3d.JSurface;
/*   5:    */ import ec.nbdemetra.ui.chart3d.JSurfacePanel;
/*   6:    */ import ec.nbdemetra.ui.chart3d.SurfaceModel.PlotColor;
/*   7:    */ import ec.nbdemetra.ui.chart3d.SurfaceModel.PlotType;
/*   8:    */ import ec.tstoolkit.data.DataBlock;
/*   9:    */ import ec.tstoolkit.data.IReadDataBlock;
/*  10:    */ import ec.tstoolkit.maths.realfunctions.IFunction;
/*  11:    */ import ec.tstoolkit.maths.realfunctions.IFunctionInstance;
/*  12:    */ import ec.tstoolkit.maths.realfunctions.IParametersDomain;
/*  13:    */ import java.awt.BorderLayout;
/*  14:    */ import java.beans.PropertyChangeEvent;
/*  15:    */ import java.beans.PropertyChangeListener;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class SurfacePlotterView
/*  37:    */   extends JPanel
/*  38:    */ {
/*  39:    */   private JSurfacePanel panel;
/*  40:    */   private ConfigurationToolBar config;
/*  41:    */   private String[] elements;
/*  42:    */   private FunctionsSurfaceModel m;
/*  43:    */   private Functions2DChart chart;
/*  44:    */   
/*  45:    */   public SurfacePlotterView()
/*  46:    */   {
/*  47: 47 */     setLayout(new BorderLayout());
/*  48: 48 */     elements = new String[] { "", "" };
/*  49: 49 */     panel = new JSurfacePanel();
/*  50:    */   }
/*  51:    */   
/*  52:    */   private void setParameters(int index1, int index2) {
/*  53: 53 */     m.setP1Index(index1);
/*  54: 54 */     m.setP2Index(index2);
/*  55: 55 */     m.generateData();
/*  56: 56 */     panel.setModel(m);
/*  57: 57 */     panel.getSurface().setOptimum(m.getOptimum());
/*  58: 58 */     panel.getSurface().setXLabel(elements[index1]);
/*  59: 59 */     panel.getSurface().setYLabel(elements[index2]);
/*  60: 60 */     panel.getSurface().repaint();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setFunctions(IFunction f, IFunctionInstance maxF, int steps) {
/*  64: 64 */     if ((f == null) || (maxF == null)) {
/*  65: 65 */       throw new IllegalArgumentException("The functions can't be null !");
/*  66:    */     }
/*  67: 67 */     int nbParams = 0;
/*  68: 68 */     if (maxF.getParameters() != null) {
/*  69: 69 */       nbParams = maxF.getParameters().getLength();
/*  70:    */     }
/*  71:    */     try
/*  72:    */     {
/*  73: 73 */       removeAll();
/*  74: 74 */       switch (nbParams) {
/*  75:    */       case 0: 
/*  76: 76 */         throw new IllegalArgumentException("The given function doesn't contain any parameters");
/*  77:    */       case 1: 
/*  78: 78 */         chart = new Functions2DChart(f, maxF, 100);
/*  79: 79 */         chart.generateData();
/*  80: 80 */         config = new ConfigurationToolBar(elements, false);
/*  81: 81 */         config.addPropertyChangeListener(new PropertyChangeListener() {
/*  82:    */           public void propertyChange(PropertyChangeEvent evt) {
/*  83:    */             String str;
/*  84: 84 */             switch ((str = evt.getPropertyName()).hashCode()) {case 80208647:  if (str.equals("Steps")) break; break; case 129149770:  if (!str.equals("Epsilon"))
/*  85:    */               {
/*  86: 86 */                 return;chart.setSteps(((Integer)evt.getNewValue()).intValue());
/*  87:    */               }
/*  88:    */               else {
/*  89: 89 */                 chart.setEpsilon(new Float(((Double)evt.getNewValue()).doubleValue()).floatValue());
/*  90:    */               }
/*  91:    */               break;
/*  92:    */             }
/*  93:    */           }
/*  94: 94 */         });
/*  95: 95 */         add(chart, "Center");
/*  96: 96 */         add(config, "North");
/*  97: 97 */         break;
/*  98:    */       default: 
/*  99: 99 */         config = new ConfigurationToolBar(elements, true);
/* 100:    */         
/* 101:101 */         config.addPropertyChangeListener(new PropertyChangeListener()
/* 102:    */         {
/* 103:    */           public void propertyChange(PropertyChangeEvent evt) {
/* 104:104 */             if ((panel.getSurface().getModel() != null) && 
/* 105:105 */               ((panel.getSurface().getModel() instanceof FunctionsSurfaceModel))) {
/* 106:106 */               FunctionsSurfaceModel m = (FunctionsSurfaceModel)panel.getSurface().getModel();
/* 107:107 */               String str; switch ((str = evt.getPropertyName()).hashCode()) {case -2037662533:  if (str.equals("Box Grid")) {} break; case -1282175617:  if (str.equals("Painting Mode")) {} break; case -924112948:  if (str.equals("XY Mesh")) {} break; case -763830033:  if (str.equals("Draw Box")) {} break; case -732112112:  if (str.equals("Z Ticks")) break; break; case -535663847:  if (str.equals("Plot Type")) {} break; case -339637634:  if (str.equals("Parameters Changed")) {} break; case 80208647:  if (str.equals("Steps")) {} break; case 129149770:  if (str.equals("Epsilon")) {} break; case 876501527:  if (str.equals("Hide On Drag")) {} case 1423838327:  if ((goto 499) && (str.equals("XY Ticks")))
/* 108:    */                 {
/* 109:109 */                   m.setDisplayXY(((Boolean)evt.getNewValue()).booleanValue());
/* 110:110 */                   return;
/* 111:    */                   
/* 112:112 */                   m.setDisplayZ(((Boolean)evt.getNewValue()).booleanValue());
/* 113:113 */                   return;
/* 114:    */                   
/* 115:115 */                   m.setDisplayGrids(((Boolean)evt.getNewValue()).booleanValue());
/* 116:116 */                   return;
/* 117:    */                   
/* 118:118 */                   m.setMesh(((Boolean)evt.getNewValue()).booleanValue());
/* 119:119 */                   return;
/* 120:    */                   
/* 121:121 */                   m.setBoxed(((Boolean)evt.getNewValue()).booleanValue());
/* 122:122 */                   return;
/* 123:    */                   
/* 124:124 */                   m.setExpectDelay(((Boolean)evt.getNewValue()).booleanValue());
/* 125:125 */                   return;
/* 126:    */                   
/* 127:127 */                   m.setPlotType((SurfaceModel.PlotType)evt.getNewValue());
/* 128:128 */                   return;
/* 129:    */                   
/* 130:130 */                   m.setPlotColor((SurfaceModel.PlotColor)evt.getNewValue());
/* 131:131 */                   return;
/* 132:    */                   
/* 133:133 */                   m.setSteps(((Integer)evt.getNewValue()).intValue());
/* 134:134 */                   return;
/* 135:    */                   
/* 136:136 */                   m.setEps(new Float(((Double)evt.getNewValue()).doubleValue()).floatValue());
/* 137:137 */                   return;
/* 138:    */                   
/* 139:139 */                   SurfacePlotterView.this.setParameters(config.getParametersComboBoxes().getSelectedIndex1(), config.getParametersComboBoxes().getSelectedIndex2());
/* 140:    */                 }
/* 141:    */                 break; }
/* 142:    */             }
/* 143:    */           }
/* 144:144 */         });
/* 145:145 */         m = new FunctionsSurfaceModel(f, maxF, steps);
/* 146:    */         
/* 147:147 */         IReadDataBlock parameters = maxF.getParameters();
/* 148:148 */         DataBlock p = new DataBlock(parameters);
/* 149:149 */         IParametersDomain d = f.getDomain();
/* 150:    */         
/* 151:151 */         elements = new String[p.getLength()];
/* 152:152 */         for (int i = 0; i < p.getLength(); i++) {
/* 153:153 */           elements[i] = d.getDescription(i);
/* 154:    */         }
/* 155:    */         
/* 156:156 */         config.setElements(elements);
/* 157:157 */         m.generateData();
/* 158:158 */         panel.setModel(m);
/* 159:159 */         panel.getSurface().setOptimum(m.getOptimum());
/* 160:160 */         panel.getSurface().setXLabel(elements[0]);
/* 161:161 */         panel.getSurface().setYLabel(elements[1]);
/* 162:    */         
/* 163:163 */         add(panel, "Center");
/* 164:164 */         add(config, "North");
/* 165:    */       }
/* 166:    */     } catch (IllegalArgumentException e) {
/* 167:167 */       add(ExceptionPanel.create(e), "Center");
/* 168:    */     }
/* 169:    */   }
/* 170:    */ }
