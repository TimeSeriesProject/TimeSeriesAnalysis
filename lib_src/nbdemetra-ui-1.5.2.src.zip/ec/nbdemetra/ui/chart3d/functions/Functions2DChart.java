/*   1:    */ package ec.nbdemetra.ui.chart3d.functions;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ThemeSupport;
/*   4:    */ import ec.tstoolkit.data.DataBlock;
/*   5:    */ import ec.tstoolkit.data.IReadDataBlock;
/*   6:    */ import ec.tstoolkit.maths.realfunctions.IFunction;
/*   7:    */ import ec.tstoolkit.maths.realfunctions.IFunctionInstance;
/*   8:    */ import ec.tstoolkit.maths.realfunctions.IParametersDomain;
/*   9:    */ import ec.ui.ATsView;
/*  10:    */ import ec.ui.chart.BasicXYDataset;
/*  11:    */ import ec.ui.chart.BasicXYDataset.Series;
/*  12:    */ import ec.ui.chart.TsCharts;
/*  13:    */ import ec.ui.view.JChartPanel;
/*  14:    */ import ec.util.chart.ColorScheme.KnownColor;
/*  15:    */ import ec.util.chart.swing.Charts;
/*  16:    */ import java.awt.BorderLayout;
/*  17:    */ import java.awt.Color;
/*  18:    */ import java.awt.Paint;
/*  19:    */ import java.awt.geom.Ellipse2D.Double;
/*  20:    */ import org.jfree.chart.JFreeChart;
/*  21:    */ import org.jfree.chart.axis.NumberAxis;
/*  22:    */ import org.jfree.chart.block.LineBorder;
/*  23:    */ import org.jfree.chart.plot.DatasetRenderingOrder;
/*  24:    */ import org.jfree.chart.plot.XYPlot;
/*  25:    */ import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
/*  26:    */ import org.jfree.chart.title.LegendTitle;
/*  27:    */ import org.jfree.ui.RectangleEdge;
/*  28:    */ import org.jfree.ui.RectangleInsets;
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ public class Functions2DChart
/*  49:    */   extends ATsView
/*  50:    */ {
/*  51:    */   private JChartPanel panel;
/*  52:    */   private JFreeChart chart;
/*  53:    */   private IFunction function;
/*  54:    */   private IFunctionInstance maxFunction;
/*  55: 55 */   private float epsilon = 0.2F;
/*  56:    */   private int steps;
/*  57:    */   private final XYLineAndShapeRenderer functionRenderer;
/*  58:    */   private final XYLineAndShapeRenderer optimumRenderer;
/*  59:    */   
/*  60:    */   public Functions2DChart(IFunction f, IFunctionInstance maxF, int steps)
/*  61:    */   {
/*  62: 62 */     setLayout(new BorderLayout());
/*  63:    */     
/*  64: 64 */     function = f;
/*  65: 65 */     maxFunction = maxF;
/*  66:    */     
/*  67: 67 */     if ((steps < 20) || (steps > 200)) {
/*  68: 68 */       throw new IllegalArgumentException("Number of steps must be between 20 and 200 !");
/*  69:    */     }
/*  70:    */     
/*  71:    */ 
/*  72: 72 */     this.steps = steps;
/*  73:    */     
/*  74: 74 */     functionRenderer = new XYLineAndShapeRenderer(true, false);
/*  75: 75 */     functionRenderer.setAutoPopulateSeriesPaint(false);
/*  76: 76 */     functionRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/*  77:    */     
/*  78: 78 */     optimumRenderer = new XYLineAndShapeRenderer(false, true);
/*  79: 79 */     optimumRenderer.setAutoPopulateSeriesPaint(false);
/*  80: 80 */     optimumRenderer.setAutoPopulateSeriesShape(false);
/*  81: 81 */     optimumRenderer.setBaseShape(new Ellipse2D.Double(-2.0D, -2.0D, 4.0D, 4.0D));
/*  82: 82 */     optimumRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/*  83: 83 */     optimumRenderer.setBaseShapesFilled(true);
/*  84:    */     
/*  85: 85 */     panel = new JChartPanel(null);
/*  86: 86 */     chart = createChart();
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   public void generateData()
/*  93:    */   {
/*  94: 94 */     if ((function == null) || (maxFunction == null)) {
/*  95: 95 */       throw new IllegalArgumentException("The given functions can't be null !");
/*  96:    */     }
/*  97:    */     
/*  98: 98 */     BasicXYDataset dataset = new BasicXYDataset();
/*  99: 99 */     BasicXYDataset optimumDataset = new BasicXYDataset();
/* 100:100 */     double[] dataX = new double[steps];
/* 101:101 */     double[] dataY = new double[steps];
/* 102:    */     
/* 103:103 */     IReadDataBlock parameters = maxFunction.getParameters();
/* 104:104 */     DataBlock p = new DataBlock(parameters);
/* 105:105 */     IParametersDomain d = function.getDomain();
/* 106:    */     
/* 107:107 */     float xMin = (float)p.get(0) - epsilon;
/* 108:108 */     float xMax = (float)p.get(0) + epsilon;
/* 109:109 */     float stepX = (xMax - xMin) / steps;
/* 110:    */     
/* 111:    */ 
/* 112:112 */     double optiX = parameters.get(0);
/* 113:113 */     double optiY = maxFunction.getValue();
/* 114:    */     
/* 115:115 */     for (int i = 0; i < steps; i++)
/* 116:    */     {
/* 117:117 */       float x = xMin + i * stepX;
/* 118:118 */       float y = (0.0F / 0.0F);
/* 119:119 */       p.set(0, x);
/* 120:    */       
/* 121:    */       try
/* 122:    */       {
/* 123:123 */         if (d.checkBoundaries(p)) {
/* 124:124 */           y = (float)function.evaluate(p).getValue();
/* 125:    */         }
/* 126:    */       } catch (Exception err) {
/* 127:127 */         y = (0.0F / 0.0F);
/* 128:    */       }
/* 129:    */       
/* 130:130 */       if (Float.isInfinite(y)) {
/* 131:131 */         y = (0.0F / 0.0F);
/* 132:    */       }
/* 133:    */       
/* 134:134 */       dataX[i] = x;
/* 135:135 */       dataY[i] = y;
/* 136:    */     }
/* 137:    */     
/* 138:    */ 
/* 139:139 */     BasicXYDataset.Series serie = BasicXYDataset.Series.of("f(" + d.getDescription(0) + ")", dataX, dataY);
/* 140:140 */     BasicXYDataset.Series optimum = BasicXYDataset.Series.of("Optimum", new double[] { optiX }, new double[] { optiY });
/* 141:141 */     dataset.addSeries(serie);
/* 142:142 */     optimumDataset.addSeries(optimum);
/* 143:    */     
/* 144:144 */     XYPlot plot = chart.getXYPlot();
/* 145:145 */     configureAxis(plot);
/* 146:146 */     plot.setDataset(0, dataset);
/* 147:147 */     plot.setDataset(1, optimumDataset);
/* 148:    */     
/* 149:149 */     panel.setChart(chart);
/* 150:150 */     add(panel, "Center");
/* 151:    */     
/* 152:152 */     onColorSchemeChange();
/* 153:    */   }
/* 154:    */   
/* 155:    */   private void configureAxis(XYPlot plot) {
/* 156:156 */     NumberAxis xAxis = new NumberAxis();
/* 157:157 */     xAxis.setAutoRange(true);
/* 158:158 */     xAxis.setAutoRangeIncludesZero(false);
/* 159:159 */     plot.setDomainAxis(xAxis);
/* 160:    */     
/* 161:161 */     NumberAxis yAxis = new NumberAxis();
/* 162:162 */     yAxis.setAutoRange(true);
/* 163:163 */     yAxis.setAutoRangeIncludesZero(false);
/* 164:164 */     plot.setRangeAxis(yAxis);
/* 165:    */   }
/* 166:    */   
/* 167:    */   private JFreeChart createChart() {
/* 168:168 */     XYPlot plot = new XYPlot();
/* 169:    */     
/* 170:170 */     plot.setDataset(0, Charts.emptyXYDataset());
/* 171:171 */     plot.setRenderer(0, functionRenderer);
/* 172:172 */     plot.mapDatasetToDomainAxis(0, 0);
/* 173:173 */     plot.mapDatasetToRangeAxis(0, 0);
/* 174:    */     
/* 175:175 */     plot.setDataset(1, Charts.emptyXYDataset());
/* 176:176 */     plot.setRenderer(1, optimumRenderer);
/* 177:177 */     plot.mapDatasetToDomainAxis(1, 0);
/* 178:178 */     plot.mapDatasetToRangeAxis(1, 0);
/* 179:    */     
/* 180:180 */     plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
/* 181:    */     
/* 182:182 */     JFreeChart result = new JFreeChart("", TsCharts.CHART_TITLE_FONT, plot, false);
/* 183:    */     
/* 184:184 */     LegendTitle legend = new LegendTitle(result.getPlot());
/* 185:185 */     legend.setMargin(new RectangleInsets(1.0D, 1.0D, 1.0D, 1.0D));
/* 186:186 */     legend.setFrame(new LineBorder());
/* 187:187 */     legend.setBackgroundPaint(Color.white);
/* 188:188 */     legend.setPosition(RectangleEdge.BOTTOM);
/* 189:189 */     result.addLegend(legend);
/* 190:    */     
/* 191:191 */     result.setPadding(TsCharts.CHART_PADDING);
/* 192:192 */     return result;
/* 193:    */   }
/* 194:    */   
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */   public void setEpsilon(float eps)
/* 201:    */   {
/* 202:202 */     if ((eps < 0.005F) || (eps > 1.0F)) {
/* 203:203 */       throw new IllegalArgumentException("Epsilon must be between 0.005 and 1.0 !");
/* 204:    */     }
/* 205:    */     
/* 206:206 */     epsilon = eps;
/* 207:207 */     generateData();
/* 208:    */   }
/* 209:    */   
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */   public void setSteps(int steps)
/* 215:    */   {
/* 216:216 */     if ((steps < 20) || (steps > 200)) {
/* 217:217 */       throw new IllegalArgumentException("Number of steps must be between 20 and 200 !");
/* 218:    */     }
/* 219:    */     
/* 220:220 */     this.steps = steps;
/* 221:221 */     generateData();
/* 222:    */   }
/* 223:    */   
/* 224:    */ 
/* 225:    */ 
/* 226:    */   protected void onTsChange() {}
/* 227:    */   
/* 228:    */ 
/* 229:    */ 
/* 230:    */   protected void onDataFormatChange() {}
/* 231:    */   
/* 232:    */ 
/* 233:    */ 
/* 234:    */   protected void onColorSchemeChange()
/* 235:    */   {
/* 236:236 */     functionRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.BLUE));
/* 237:237 */     optimumRenderer.setBasePaint((Paint)themeSupport.getLineColor(ColorScheme.KnownColor.RED));
/* 238:    */     
/* 239:239 */     XYPlot mainPlot = chart.getXYPlot();
/* 240:240 */     mainPlot.setBackgroundPaint((Paint)themeSupport.getPlotColor());
/* 241:241 */     mainPlot.setDomainGridlinePaint((Paint)themeSupport.getGridColor());
/* 242:242 */     mainPlot.setRangeGridlinePaint((Paint)themeSupport.getGridColor());
/* 243:243 */     chart.setBackgroundPaint((Paint)themeSupport.getBackColor());
/* 244:    */   }
/* 245:    */ }
