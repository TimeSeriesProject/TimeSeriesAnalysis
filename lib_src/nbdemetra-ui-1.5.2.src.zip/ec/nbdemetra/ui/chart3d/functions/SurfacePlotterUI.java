/*  1:   */ package ec.nbdemetra.ui.chart3d.functions;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.maths.realfunctions.IFunction;
/*  4:   */ import ec.tstoolkit.maths.realfunctions.IFunctionInstance;
/*  5:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  6:   */ import ec.ui.view.tsprocessing.PooledItemUI;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class SurfacePlotterUI<V extends IProcDocumentView<?>>
/* 28:   */   extends PooledItemUI<V, Functions, SurfacePlotterView>
/* 29:   */ {
/* 30:   */   public SurfacePlotterUI()
/* 31:   */   {
/* 32:32 */     super(SurfacePlotterView.class);
/* 33:   */   }
/* 34:   */   
/* 35:   */   protected void init(SurfacePlotterView c, V host, Functions information)
/* 36:   */   {
/* 37:37 */     c.setFunctions(function, maxFunction, 100);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public static class Functions {
/* 41:   */     public IFunction function;
/* 42:   */     public IFunctionInstance maxFunction;
/* 43:   */     
/* 44:   */     public static Functions create(IFunction f, IFunctionInstance max) {
/* 45:45 */       return new Functions(f, max);
/* 46:   */     }
/* 47:   */     
/* 48:   */     private Functions(IFunction f, IFunctionInstance maxF) {
/* 49:49 */       function = f;
/* 50:50 */       maxFunction = maxF;
/* 51:   */     }
/* 52:   */   }
/* 53:   */ }
