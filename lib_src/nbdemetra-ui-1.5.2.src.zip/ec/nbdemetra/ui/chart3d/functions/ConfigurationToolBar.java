/*   1:    */ package ec.nbdemetra.ui.chart3d.functions;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.chart3d.SurfaceModel.PlotColor;
/*   4:    */ import ec.nbdemetra.ui.chart3d.SurfaceModel.PlotType;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import javax.swing.Box;
/*  11:    */ import javax.swing.Box.Filler;
/*  12:    */ import javax.swing.BoxLayout;
/*  13:    */ import javax.swing.ButtonGroup;
/*  14:    */ import javax.swing.JButton;
/*  15:    */ import javax.swing.JCheckBoxMenuItem;
/*  16:    */ import javax.swing.JLabel;
/*  17:    */ import javax.swing.JMenu;
/*  18:    */ import javax.swing.JMenuBar;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.JPopupMenu;
/*  21:    */ import javax.swing.JSpinner;
/*  22:    */ import javax.swing.SpinnerNumberModel;
/*  23:    */ import javax.swing.border.EmptyBorder;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ public class ConfigurationToolBar
/*  46:    */   extends JMenuBar
/*  47:    */ {
/*  48:    */   public static final String XY_TICKS = "XY Ticks";
/*  49:    */   public static final String Z_TICKS = "Z Ticks";
/*  50:    */   public static final String BOX_GRID = "Box Grid";
/*  51:    */   public static final String XY_MESH = "XY Mesh";
/*  52:    */   public static final String DRAW_BOX = "Draw Box";
/*  53:    */   public static final String HIDE_ON_DRAG = "Hide On Drag";
/*  54:    */   public static final String PLOT_TYPE = "Plot Type";
/*  55:    */   public static final String PAINTING_MODE = "Painting Mode";
/*  56:    */   public static final String STEPS = "Steps";
/*  57:    */   public static final String EPSILON = "Epsilon";
/*  58: 58 */   private String[] params = { "XY Ticks", "Z Ticks", "Box Grid", "XY Mesh", "Draw Box", "Hide On Drag" };
/*  59:    */   
/*  60:    */   public static final int MAX_STEPS = 200;
/*  61:    */   
/*  62:    */   public static final int MIN_STEPS = 20;
/*  63:    */   public static final float MAX_EPS = 1.0F;
/*  64:    */   public static final float MIN_EPS = 0.005F;
/*  65:    */   private JMenu plotTypeMenu;
/*  66:    */   private JMenu plotColorMenu;
/*  67:    */   private JMenu parameters;
/*  68:    */   private JMenu viewParams;
/*  69:    */   private String[] fnParams;
/*  70:    */   private ParameterComboBox comboboxes;
/*  71:    */   
/*  72:    */   public ConfigurationToolBar(String[] elements, boolean full)
/*  73:    */   {
/*  74: 74 */     fnParams = elements;
/*  75: 75 */     initComponents(full);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public ParameterComboBox getParametersComboBoxes() {
/*  79: 79 */     return comboboxes;
/*  80:    */   }
/*  81:    */   
/*  82:    */   private void initComponents(boolean full) {
/*  83: 83 */     plotTypeMenu = new JMenu("Plot Type");
/*  84: 84 */     plotColorMenu = new JMenu("Painting Mode");
/*  85: 85 */     parameters = new JMenu("Parameters");
/*  86: 86 */     viewParams = new JMenu("View");
/*  87:    */     
/*  88: 88 */     if (full) {
/*  89: 89 */       createPlotType();
/*  90: 90 */       createPlotColor();
/*  91: 91 */       createViewParams();
/*  92:    */     }
/*  93: 93 */     createParameters();
/*  94:    */     
/*  95: 95 */     if (full) {
/*  96: 96 */       createParamSelection();
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   private void createPlotType()
/* 101:    */   {
/* 102:102 */     ButtonGroup group = new ButtonGroup();
/* 103:103 */     SurfaceModel.PlotType[] types = SurfaceModel.PlotType.values();
/* 104:104 */     for (final SurfaceModel.PlotType t : types) {
/* 105:105 */       JCheckBoxMenuItem item = new JCheckBoxMenuItem(t.getPropertyName());
/* 106:106 */       if (t.getPropertyName().equals(SurfaceModel.PlotType.SURFACE.getPropertyName())) {
/* 107:107 */         item.setSelected(true);
/* 108:    */       }
/* 109:    */       
/* 110:110 */       item.addActionListener(new ActionListener()
/* 111:    */       {
/* 112:    */         public void actionPerformed(ActionEvent e) {
/* 113:113 */           firePropertyChange("Plot Type", null, t);
/* 114:    */         }
/* 115:    */         
/* 116:116 */       });
/* 117:117 */       group.add(item);
/* 118:118 */       plotTypeMenu.add(item);
/* 119:    */     }
/* 120:120 */     add(plotTypeMenu);
/* 121:    */   }
/* 122:    */   
/* 123:    */   private void createPlotColor() {
/* 124:124 */     ButtonGroup group = new ButtonGroup();
/* 125:125 */     SurfaceModel.PlotColor[] colors = SurfaceModel.PlotColor.values();
/* 126:126 */     for (final SurfaceModel.PlotColor c : colors) {
/* 127:127 */       JCheckBoxMenuItem item = new JCheckBoxMenuItem(c.getPropertyName());
/* 128:128 */       if (c.getPropertyName().equals(SurfaceModel.PlotColor.SPECTRUM.getPropertyName())) {
/* 129:129 */         item.setSelected(true);
/* 130:    */       }
/* 131:    */       
/* 132:132 */       item.addActionListener(new ActionListener()
/* 133:    */       {
/* 134:    */         public void actionPerformed(ActionEvent e) {
/* 135:135 */           firePropertyChange("Painting Mode", null, c);
/* 136:    */         }
/* 137:    */         
/* 138:138 */       });
/* 139:139 */       group.add(item);
/* 140:140 */       plotColorMenu.add(item);
/* 141:    */     }
/* 142:    */     
/* 143:143 */     add(plotColorMenu);
/* 144:    */   }
/* 145:    */   
/* 146:    */   private void createViewParams() {
/* 147:147 */     for (final String s : params) {
/* 148:148 */       JCheckBoxMenuItem item = new JCheckBoxMenuItem(s);
/* 149:149 */       item.addActionListener(new ActionListener()
/* 150:    */       {
/* 151:    */         public void actionPerformed(ActionEvent e) {
/* 152:152 */           if ((e.getSource() != null) && ((e.getSource() instanceof JCheckBoxMenuItem))) {
/* 153:153 */             JCheckBoxMenuItem i = (JCheckBoxMenuItem)e.getSource();
/* 154:154 */             firePropertyChange(s, !i.isSelected(), i.isSelected());
/* 155:    */           }
/* 156:    */         }
/* 157:157 */       });
/* 158:158 */       item.setSelected((!s.equals("XY Mesh")) && (!s.equals("Hide On Drag")));
/* 159:    */       
/* 160:160 */       viewParams.add(item);
/* 161:    */     }
/* 162:    */     
/* 163:163 */     add(viewParams);
/* 164:    */   }
/* 165:    */   
/* 166:    */   private void createParameters() {
/* 167:167 */     createSteps();
/* 168:168 */     createEpsilon();
/* 169:    */     
/* 170:170 */     add(parameters);
/* 171:    */   }
/* 172:    */   
/* 173:    */   private void createParamSelection() {
/* 174:174 */     add(Box.createHorizontalGlue());
/* 175:175 */     comboboxes = new ParameterComboBox(fnParams);
/* 176:176 */     comboboxes.addPropertyChangeListener("Parameters Changed", new PropertyChangeListener()
/* 177:    */     {
/* 178:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 179:179 */         firePropertyChange("Parameters Changed", null, null);
/* 180:    */       }
/* 181:181 */     });
/* 182:182 */     add(comboboxes);
/* 183:    */   }
/* 184:    */   
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */   public void setElements(String[] elements)
/* 190:    */   {
/* 191:191 */     fnParams = elements;
/* 192:192 */     comboboxes.setElements(elements);
/* 193:    */   }
/* 194:    */   
/* 195:    */   private void createSteps() {
/* 196:196 */     Box.Filler filler = new Box.Filler(new Dimension(50, 0), new Dimension(50, 0), new Dimension(32767, 0));
/* 197:197 */     JPanel comp = new JPanel();
/* 198:198 */     comp.setLayout(new BoxLayout(comp, 2));
/* 199:    */     
/* 200:    */ 
/* 201:201 */     JLabel label = new JLabel("Steps");
/* 202:202 */     label.setMaximumSize(new Dimension(50, 18));
/* 203:    */     
/* 204:    */ 
/* 205:205 */     SpinnerNumberModel spinnerModel = new SpinnerNumberModel(100, 20, 200, 5);
/* 206:206 */     final JSpinner spinner = new JSpinner(spinnerModel);
/* 207:207 */     spinner.setMaximumSize(new Dimension(50, 18));
/* 208:208 */     spinner.setPreferredSize(new Dimension(50, 18));
/* 209:    */     
/* 210:    */ 
/* 211:211 */     JButton save = new JButton("OK");
/* 212:212 */     save.setMaximumSize(new Dimension(50, 18));
/* 213:    */     
/* 214:214 */     save.addActionListener(new ActionListener()
/* 215:    */     {
/* 216:    */       public void actionPerformed(ActionEvent e) {
/* 217:217 */         parameters.getPopupMenu().setVisible(false);
/* 218:218 */         parameters.setSelected(false);
/* 219:219 */         firePropertyChange("Steps", null, (Integer)spinner.getValue());
/* 220:    */       }
/* 221:    */       
/* 222:222 */     });
/* 223:223 */     comp.add(label);
/* 224:224 */     comp.add(filler);
/* 225:225 */     comp.add(spinner);
/* 226:226 */     comp.add(save);
/* 227:    */     
/* 228:228 */     comp.setBorder(new EmptyBorder(1, 5, 1, 5));
/* 229:    */     
/* 230:230 */     parameters.add(comp);
/* 231:    */   }
/* 232:    */   
/* 233:    */   private void createEpsilon() {
/* 234:234 */     Box.Filler filler = new Box.Filler(new Dimension(50, 0), new Dimension(50, 0), new Dimension(32767, 0));
/* 235:235 */     JPanel comp = new JPanel();
/* 236:236 */     comp.setLayout(new BoxLayout(comp, 2));
/* 237:    */     
/* 238:    */ 
/* 239:239 */     JLabel label = new JLabel("Epsilon");
/* 240:240 */     label.setMaximumSize(new Dimension(50, 18));
/* 241:    */     
/* 242:    */ 
/* 243:243 */     SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0.2D, 0.00499999988824129D, 1.0D, 0.05D);
/* 244:244 */     final JSpinner spinner = new JSpinner(spinnerModel);
/* 245:245 */     spinner.setMaximumSize(new Dimension(50, 18));
/* 246:246 */     spinner.setPreferredSize(new Dimension(50, 18));
/* 247:    */     
/* 248:    */ 
/* 249:249 */     JButton save = new JButton("OK");
/* 250:250 */     save.setMaximumSize(new Dimension(50, 18));
/* 251:251 */     save.addActionListener(new ActionListener()
/* 252:    */     {
/* 253:    */       public void actionPerformed(ActionEvent e) {
/* 254:254 */         parameters.getPopupMenu().setVisible(false);
/* 255:255 */         parameters.setSelected(false);
/* 256:256 */         firePropertyChange("Epsilon", null, (Double)spinner.getValue());
/* 257:    */       }
/* 258:    */       
/* 259:259 */     });
/* 260:260 */     comp.add(label);
/* 261:261 */     comp.add(filler);
/* 262:262 */     comp.add(spinner);
/* 263:263 */     comp.add(save);
/* 264:    */     
/* 265:265 */     comp.setBorder(new EmptyBorder(1, 5, 1, 5));
/* 266:    */     
/* 267:267 */     parameters.add(comp);
/* 268:    */   }
/* 269:    */ }
