/*   1:    */ package ec.nbdemetra.ui.chart3d.functions;
/*   2:    */ 
/*   3:    */ import com.google.common.util.concurrent.ThreadFactoryBuilder;
/*   4:    */ import ec.nbdemetra.ui.DemetraUI;
/*   5:    */ import ec.nbdemetra.ui.chart3d.AbstractSurfaceModel;
/*   6:    */ import ec.nbdemetra.ui.chart3d.SurfaceModel.PlotType;
/*   7:    */ import ec.nbdemetra.ui.chart3d.SurfaceVertex;
/*   8:    */ import ec.tstoolkit.data.DataBlock;
/*   9:    */ import ec.tstoolkit.data.IReadDataBlock;
/*  10:    */ import ec.tstoolkit.maths.realfunctions.IFunction;
/*  11:    */ import ec.tstoolkit.maths.realfunctions.IFunctionInstance;
/*  12:    */ import ec.tstoolkit.maths.realfunctions.IParametersDomain;
/*  13:    */ import ec.tstoolkit.utilities.ThreadPoolSize;
/*  14:    */ import ec.tstoolkit.utilities.ThreadPriority;
/*  15:    */ import java.util.ArrayList;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.concurrent.Callable;
/*  18:    */ import java.util.concurrent.ExecutorService;
/*  19:    */ import java.util.concurrent.Executors;
/*  20:    */ import javax.swing.SwingWorker;
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ public class FunctionsSurfaceModel
/*  40:    */   extends AbstractSurfaceModel
/*  41:    */ {
/*  42:    */   private SurfaceVertex[] surfaceVertex;
/*  43:    */   private final IFunction function;
/*  44:    */   private IFunctionInstance maxFunction;
/*  45:    */   private int p1_index;
/*  46:    */   private int p2_index;
/*  47:    */   private int steps;
/*  48:    */   private SurfaceVertex optimum;
/*  49:    */   private float eps;
/*  50:    */   private SwingWorker<Void, Void> worker;
/*  51:    */   public static final String PROGRESS_PROPERTY = "progress changed";
/*  52:    */   
/*  53:    */   public FunctionsSurfaceModel(IFunction f, IFunctionInstance maxF, int steps)
/*  54:    */   {
/*  55: 55 */     function = f;
/*  56: 56 */     maxFunction = maxF;
/*  57: 57 */     p1_index = 0;
/*  58: 58 */     p2_index = 1;
/*  59:    */     
/*  60: 60 */     if ((steps < 20) || (steps > 200)) {
/*  61: 61 */       throw new IllegalArgumentException("Number of steps must be between 20 and 200 !");
/*  62:    */     }
/*  63:    */     
/*  64:    */ 
/*  65: 65 */     this.steps = steps;
/*  66: 66 */     eps = 0.2F;
/*  67:    */     
/*  68:    */ 
/*  69: 69 */     setBoxed(true);
/*  70: 70 */     setDisplayXY(true);
/*  71: 71 */     setExpectDelay(false);
/*  72: 72 */     setAutoScaleZ(true);
/*  73: 73 */     setDisplayZ(true);
/*  74: 74 */     setMesh(false);
/*  75: 75 */     setBoxed(true);
/*  76: 76 */     setDisplayGrids(true);
/*  77: 77 */     setPlotType(SurfaceModel.PlotType.SURFACE);
/*  78: 78 */     setFirstFunctionOnly(true);
/*  79:    */   }
/*  80:    */   
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */   public SurfaceVertex getOptimum()
/*  86:    */   {
/*  87: 87 */     return optimum;
/*  88:    */   }
/*  89:    */   
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */   public void generateData()
/*  95:    */   {
/*  96: 96 */     if ((function == null) || (maxFunction == null)) {
/*  97: 97 */       throw new IllegalArgumentException("The given functions can't be null !");
/*  98:    */     }
/*  99:    */     
/* 100:100 */     IReadDataBlock parameters = maxFunction.getParameters();
/* 101:101 */     final DataBlock p = new DataBlock(parameters);
/* 102:102 */     final IParametersDomain d = function.getDomain();
/* 103:    */     
/* 104:104 */     if ((p1_index >= parameters.getLength()) || (p2_index >= parameters.getLength())) {
/* 105:105 */       throw new IllegalArgumentException("One or more parameters' indexes are out of limits");
/* 106:    */     }
/* 107:    */     
/* 108:108 */     setDataAvailable(false);
/* 109:    */     
/* 110:110 */     setXMin((float)p.get(p1_index) - eps);
/* 111:111 */     setXMax((float)p.get(p1_index) + eps);
/* 112:112 */     setYMin((float)p.get(p2_index) - eps);
/* 113:113 */     setYMax((float)p.get(p2_index) + eps);
/* 114:114 */     setCalcDivisions(steps - 1);
/* 115:    */     
/* 116:116 */     final float stepx = (xMax - xMin) / steps;
/* 117:117 */     final float stepy = (yMax - yMin) / steps;
/* 118:118 */     final float xfactor = 20.0F / (xMax - xMin);
/* 119:119 */     final float yfactor = 20.0F / (yMax - yMin);
/* 120:    */     
/* 121:121 */     int total = steps * steps;
/* 122:122 */     surfaceVertex = new SurfaceVertex[total];
/* 123:123 */     final float[] fnPts = new float[total];
/* 124:124 */     for (int i = 0; i < fnPts.length; i++) {
/* 125:125 */       fnPts[i] = (0.0F / 0.0F);
/* 126:    */     }
/* 127:    */     
/* 128:128 */     float p1 = (float)parameters.get(p1_index);
/* 129:129 */     float p2 = (float)parameters.get(p2_index);
/* 130:130 */     optimum = new SurfaceVertex((p1 - xMin) * xfactor - 10.0F, (p2 - yMin) * yfactor - 10.0F, (float)maxFunction.getValue());
/* 131:    */     
/* 132:132 */     worker = new SwingWorker()
/* 133:    */     {
/* 134:    */       protected Void doInBackground() throws Exception
/* 135:    */       {
/* 136:136 */         List<Callable<Void>> tasks = createTasks();
/* 137:137 */         if (tasks == null) {
/* 138:138 */           return null;
/* 139:    */         }
/* 140:    */         
/* 141:141 */         DemetraUI config = DemetraUI.getDefault();
/* 142:142 */         int nThread = config.getBatchPoolSize().intValue();
/* 143:143 */         int priority = config.getBatchPriority().intValue();
/* 144:    */         
/* 145:145 */         ExecutorService executorService = Executors.newFixedThreadPool(nThread, new ThreadFactoryBuilder().setDaemon(true).setPriority(priority).build());
/* 146:    */         try {
/* 147:147 */           executorService.invokeAll(tasks);
/* 148:    */         } catch (InterruptedException ex) {
/* 149:149 */           Thread.currentThread().interrupt();
/* 150:    */         }
/* 151:151 */         executorService.shutdown();
/* 152:152 */         return null;
/* 153:    */       }
/* 154:    */       
/* 155:    */       Callable<Void> createFn(final int i, final int j) {
/* 156:156 */         new Callable()
/* 157:    */         {
/* 158:    */           public Void call() throws Exception {
/* 159:159 */             DataBlock p2 = val$p.deepClone();
/* 160:160 */             float xv = xMin + i * val$stepx;
/* 161:161 */             p2.set(p1_index, xv);
/* 162:    */             
/* 163:163 */             float yv = yMin + j * val$stepy;
/* 164:164 */             p2.set(p2_index, yv);
/* 165:    */             
/* 166:166 */             float z = (0.0F / 0.0F);
/* 167:    */             try {
/* 168:168 */               if (val$d.checkBoundaries(p2))
/* 169:    */               {
/* 170:170 */                 z = (float)function.evaluate(p2).getValue();
/* 171:    */               }
/* 172:    */             }
/* 173:    */             catch (Exception localException) {}
/* 174:    */             
/* 175:175 */             if (Float.isInfinite(z)) {
/* 176:176 */               z = (0.0F / 0.0F);
/* 177:    */             }
/* 178:    */             
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:184 */             int k = i * steps + j;
/* 185:185 */             val$fnPts[k] = z;
/* 186:186 */             return null;
/* 187:    */           }
/* 188:    */         };
/* 189:    */       }
/* 190:    */       
/* 191:    */       List<Callable<Void>> createTasks() {
/* 192:192 */         List<Callable<Void>> list = new ArrayList();
/* 193:193 */         for (int i = 0; i < steps; i++) {
/* 194:194 */           for (int j = 0; j < steps; j++) {
/* 195:195 */             list.add(createFn(i, j));
/* 196:    */           }
/* 197:    */         }
/* 198:198 */         return list;
/* 199:    */       }
/* 200:    */       
/* 201:    */       protected void done()
/* 202:    */       {
/* 203:203 */         int q = 0;
/* 204:204 */         while ((q < fnPts.length) && (Float.isNaN(fnPts[q]))) {
/* 205:205 */           q++;
/* 206:    */         }
/* 207:207 */         if (q == fnPts.length) {
/* 208:208 */           return;
/* 209:    */         }
/* 210:210 */         z1Min = fnPts[q];
/* 211:211 */         z1Max = fnPts[q];
/* 212:212 */         for (int i = q + 1; i < fnPts.length; i++) {
/* 213:213 */           float z = fnPts[i];
/* 214:    */           
/* 215:    */ 
/* 216:216 */           if (!Float.isNaN(z)) {
/* 217:217 */             if (z > z1Max) {
/* 218:218 */               z1Max = z;
/* 219:219 */             } else if (z < z1Min) {
/* 220:220 */               z1Min = z;
/* 221:    */             }
/* 222:    */           }
/* 223:    */         }
/* 224:    */         
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:229 */         for (int i = 0; i < steps; i++) {
/* 230:230 */           for (int j = 0; j < steps; j++) {
/* 231:231 */             int k = i * steps + j;
/* 232:232 */             float z = fnPts[k];
/* 233:233 */             float xv = xMin + i * stepx;
/* 234:234 */             float yv = yMin + j * stepy;
/* 235:235 */             surfaceVertex[k] = new SurfaceVertex((xv - xMin) * xfactor - 10.0F, (yv - yMin) * yfactor - 10.0F, z);
/* 236:    */           }
/* 237:    */         }
/* 238:    */         
/* 239:239 */         autoScale();
/* 240:240 */         setDataAvailable(true);
/* 241:241 */         fireStateChanged();
/* 242:    */       }
/* 243:243 */     };
/* 244:244 */     worker.execute();
/* 245:    */   }
/* 246:    */   
/* 247:    */ 
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:    */   public void setEps(float eps)
/* 253:    */   {
/* 254:254 */     this.eps = eps;
/* 255:255 */     generateData();
/* 256:    */   }
/* 257:    */   
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */   public void setSteps(int steps)
/* 264:    */   {
/* 265:265 */     if ((steps < 20) || (steps > 200)) {
/* 266:266 */       throw new IllegalArgumentException("Number of steps must be between 20 and 200 !");
/* 267:    */     }
/* 268:    */     
/* 269:269 */     this.steps = steps;
/* 270:270 */     generateData();
/* 271:    */   }
/* 272:    */   
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */   public SurfaceVertex[] getSurfaceVertex()
/* 281:    */   {
/* 282:282 */     return surfaceVertex;
/* 283:    */   }
/* 284:    */   
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */   public void setP1Index(int p1_index)
/* 290:    */   {
/* 291:291 */     if (p1_index < 0) {
/* 292:292 */       throw new IllegalArgumentException("The index can't be < 0 !");
/* 293:    */     }
/* 294:294 */     this.p1_index = p1_index;
/* 295:    */   }
/* 296:    */   
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */   public void setP2Index(int p2_index)
/* 302:    */   {
/* 303:303 */     if (p2_index < 0) {
/* 304:304 */       throw new IllegalArgumentException("The index can't be < 0 !");
/* 305:    */     }
/* 306:306 */     this.p2_index = p2_index;
/* 307:    */   }
/* 308:    */ }
