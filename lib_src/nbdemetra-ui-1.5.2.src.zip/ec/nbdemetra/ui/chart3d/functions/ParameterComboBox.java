/*   1:    */ package ec.nbdemetra.ui.chart3d.functions;
/*   2:    */ 
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.event.ActionEvent;
/*   5:    */ import java.awt.event.ActionListener;
/*   6:    */ import java.awt.event.ItemEvent;
/*   7:    */ import java.awt.event.ItemListener;
/*   8:    */ import javax.swing.BoxLayout;
/*   9:    */ import javax.swing.JButton;
/*  10:    */ import javax.swing.JComboBox;
/*  11:    */ import javax.swing.JLabel;
/*  12:    */ import javax.swing.JPanel;
/*  13:    */ import javax.swing.border.EmptyBorder;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ public class ParameterComboBox
/*  35:    */   extends JPanel
/*  36:    */ {
/*  37:    */   private Object selected1;
/*  38:    */   private Object selected2;
/*  39:    */   private JComboBox combo1;
/*  40:    */   private JComboBox combo2;
/*  41:    */   private String[] elements;
/*  42:    */   public static final String PARAMETERS_CHANGED = "Parameters Changed";
/*  43: 43 */   private JLabel param1Label = new JLabel("X Parameter : ");
/*  44: 44 */   private JLabel param2Label = new JLabel("Y Parameter : ");
/*  45:    */   private ItemListener l1;
/*  46:    */   private ItemListener l2;
/*  47:    */   private JButton button;
/*  48:    */   
/*  49:    */   public ParameterComboBox(String[] elements) {
/*  50: 50 */     this.elements = elements;
/*  51: 51 */     setLayout(new BoxLayout(this, 2));
/*  52: 52 */     setOpaque(false);
/*  53: 53 */     initComboBoxes();
/*  54: 54 */     initPanels();
/*  55:    */   }
/*  56:    */   
/*  57:    */   private void initPanels() {
/*  58: 58 */     JPanel mainPanel = new JPanel();
/*  59: 59 */     mainPanel.setOpaque(false);
/*  60: 60 */     mainPanel.setLayout(new BoxLayout(mainPanel, 3));
/*  61: 61 */     JPanel p1 = new JPanel();
/*  62: 62 */     p1.setOpaque(false);
/*  63: 63 */     p1.setBorder(new EmptyBorder(1, 5, 1, 5));
/*  64: 64 */     p1.setLayout(new BoxLayout(p1, 2));
/*  65: 65 */     p1.add(param1Label);
/*  66: 66 */     p1.add(combo1);
/*  67:    */     
/*  68: 68 */     JPanel p2 = new JPanel();
/*  69: 69 */     p2.setOpaque(false);
/*  70: 70 */     p2.setBorder(new EmptyBorder(1, 5, 1, 5));
/*  71: 71 */     p2.setLayout(new BoxLayout(p2, 2));
/*  72: 72 */     p2.add(param2Label);
/*  73: 73 */     p2.add(combo2);
/*  74:    */     
/*  75: 75 */     param1Label.setMaximumSize(new Dimension(50, 18));
/*  76: 76 */     param2Label.setMaximumSize(new Dimension(50, 18));
/*  77:    */     
/*  78: 78 */     mainPanel.add(p1);
/*  79: 79 */     mainPanel.add(p2);
/*  80:    */     
/*  81: 81 */     button = new JButton("OK");
/*  82: 82 */     button.setMaximumSize(new Dimension(50, 18));
/*  83:    */     
/*  84: 84 */     button.addActionListener(new ActionListener()
/*  85:    */     {
/*  86:    */       public void actionPerformed(ActionEvent e) {
/*  87: 87 */         firePropertyChange("Parameters Changed", null, null);
/*  88:    */       }
/*  89:    */       
/*  90: 90 */     });
/*  91: 91 */     add(mainPanel);
/*  92: 92 */     add(button);
/*  93:    */   }
/*  94:    */   
/*  95:    */   private void initComboBoxes() {
/*  96: 96 */     selected1 = elements[0];
/*  97: 97 */     selected2 = elements[1];
/*  98:    */     
/*  99: 99 */     combo1 = new JComboBox(elements);
/* 100:100 */     combo1.setOpaque(false);
/* 101:101 */     combo1.setSelectedItem(selected1);
/* 102:102 */     combo1.setMaximumSize(new Dimension(100, 18));
/* 103:103 */     combo1.setPreferredSize(new Dimension(100, 18));
/* 104:    */     
/* 105:105 */     combo2 = new JComboBox(elements);
/* 106:106 */     combo2.setOpaque(false);
/* 107:107 */     combo2.setSelectedItem(selected2);
/* 108:108 */     combo2.setMaximumSize(new Dimension(100, 18));
/* 109:109 */     combo2.setPreferredSize(new Dimension(100, 18));
/* 110:    */     
/* 111:111 */     combo2.removeItem(selected1);
/* 112:112 */     combo1.removeItem(selected2);
/* 113:    */     
/* 114:114 */     l1 = new ItemListener()
/* 115:    */     {
/* 116:    */       public void itemStateChanged(ItemEvent e) {
/* 117:117 */         if (e.getStateChange() == 1) {
/* 118:118 */           selected1 = e.getItem();
/* 119:119 */           resetElements();
/* 120:    */         }
/* 121:    */         
/* 122:    */       }
/* 123:123 */     };
/* 124:124 */     l2 = new ItemListener()
/* 125:    */     {
/* 126:    */       public void itemStateChanged(ItemEvent e) {
/* 127:127 */         if (e.getStateChange() == 1) {
/* 128:128 */           selected2 = e.getItem();
/* 129:129 */           resetElements();
/* 130:    */         }
/* 131:    */         
/* 132:    */       }
/* 133:133 */     };
/* 134:134 */     combo1.addItemListener(l1);
/* 135:135 */     combo2.addItemListener(l2);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setElements(String[] elements) {
/* 139:139 */     this.elements = elements;
/* 140:140 */     selected1 = this.elements[0];
/* 141:141 */     selected2 = this.elements[1];
/* 142:    */     
/* 143:143 */     resetElements();
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void resetElements() {
/* 147:147 */     combo1.removeItemListener(l1);
/* 148:148 */     combo2.removeItemListener(l2);
/* 149:    */     
/* 150:150 */     combo1.removeAllItems();
/* 151:151 */     combo2.removeAllItems();
/* 152:152 */     for (String s : elements) {
/* 153:153 */       combo1.addItem(s);
/* 154:154 */       combo2.addItem(s);
/* 155:    */     }
/* 156:    */     
/* 157:157 */     combo2.removeItem(selected1);
/* 158:158 */     combo1.removeItem(selected2);
/* 159:    */     
/* 160:160 */     combo1.setSelectedItem(selected1);
/* 161:161 */     combo2.setSelectedItem(selected2);
/* 162:    */     
/* 163:163 */     combo1.addItemListener(l1);
/* 164:164 */     combo2.addItemListener(l2);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public int getSelectedIndex1() {
/* 168:168 */     for (int i = 0; i < elements.length; i++) {
/* 169:169 */       if (elements[i].equals(String.valueOf(selected1))) {
/* 170:170 */         return i;
/* 171:    */       }
/* 172:    */     }
/* 173:173 */     return -1;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public int getSelectedIndex2() {
/* 177:177 */     for (int i = 0; i < elements.length; i++) {
/* 178:178 */       if (elements[i].equals(String.valueOf(selected2))) {
/* 179:179 */         return i;
/* 180:    */       }
/* 181:    */     }
/* 182:182 */     return -1;
/* 183:    */   }
/* 184:    */ }
