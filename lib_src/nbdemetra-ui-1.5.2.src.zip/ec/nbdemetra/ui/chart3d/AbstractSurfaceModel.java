/*   1:    */ package ec.nbdemetra.ui.chart3d;
/*   2:    */ 
/*   3:    */ import java.beans.PropertyChangeListener;
/*   4:    */ import java.beans.PropertyChangeSupport;
/*   5:    */ import javax.swing.event.ChangeEvent;
/*   6:    */ import javax.swing.event.ChangeListener;
/*   7:    */ import javax.swing.event.EventListenerList;
/*   8:    */ import javax.swing.event.SwingPropertyChangeSupport;
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public abstract class AbstractSurfaceModel
/*  47:    */   implements SurfaceModel
/*  48:    */ {
/*  49:    */   private static final int INIT_CALC_DIV = 20;
/*  50:    */   private static final int INIT_DISP_DIV = 20;
/*  51:    */   
/*  52:    */   public static synchronized double ceil(double d, int digits)
/*  53:    */   {
/*  54: 54 */     if (d == 0.0D) {
/*  55: 55 */       return d;
/*  56:    */     }
/*  57: 57 */     long og = Math.ceil(Math.log(Math.abs(d)) / Math.log(10.0D));
/*  58: 58 */     double factor = Math.pow(10.0D, digits - og);
/*  59: 59 */     double res = Math.ceil(d * factor) / factor;
/*  60: 60 */     return res;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static synchronized double floor(double d, int digits) {
/*  64: 64 */     if (d == 0.0D) {
/*  65: 65 */       return d;
/*  66:    */     }
/*  67:    */     
/*  68: 68 */     long og = Math.ceil(Math.log(Math.abs(d)) / Math.log(10.0D));
/*  69:    */     
/*  70: 70 */     double factor = Math.pow(10.0D, digits - og);
/*  71:    */     
/*  72: 72 */     double res = Math.floor(d * factor) / factor;
/*  73:    */     
/*  74: 74 */     return res;
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78: 78 */   protected boolean autoScaleZ = true;
/*  79:    */   protected boolean boxed;
/*  80: 80 */   protected int calcDivisions = 20;
/*  81:    */   protected ColorModelSet colorModel;
/*  82:    */   protected int contourLines;
/*  83:    */   protected boolean dataAvailable;
/*  84: 84 */   protected int dispDivisions = 20;
/*  85:    */   protected boolean displayGrids;
/*  86:    */   protected boolean displayXY;
/*  87:    */   protected boolean displayZ;
/*  88: 88 */   protected boolean expectDelay = false;
/*  89: 89 */   protected boolean hasFunction1 = true;
/*  90: 90 */   protected boolean hasFunction2 = true;
/*  91: 91 */   protected EventListenerList listenerList = new EventListenerList();
/*  92:    */   protected boolean mesh;
/*  93:    */   protected SurfaceModel.PlotColor plotColor;
/*  94: 94 */   protected boolean plotFunction1 = hasFunction1;
/*  95: 95 */   protected boolean plotFunction2 = hasFunction2;
/*  96: 96 */   protected SurfaceModel.PlotType plotType = SurfaceModel.PlotType.SURFACE;
/*  97:    */   private Projector projector;
/*  98:    */   protected PropertyChangeSupport property;
/*  99:    */   protected boolean scaleBox;
/* 100:100 */   protected float xMax = 1.0F;
/* 101:    */   protected float xMin;
/* 102:102 */   protected float yMax = 1.0F;
/* 103:    */   
/* 104:    */   protected float yMin;
/* 105:    */   
/* 106:    */   protected float z1Max;
/* 107:    */   
/* 108:    */   protected float z1Min;
/* 109:    */   
/* 110:    */   protected float z2Max;
/* 111:    */   protected float z2Min;
/* 112:    */   protected float zMax;
/* 113:    */   protected float zMin;
/* 114:    */   protected int nbDecimals;
/* 115:    */   
/* 116:    */   public AbstractSurfaceModel()
/* 117:    */   {
/* 118:118 */     property = new SwingPropertyChangeSupport(this);
/* 119:119 */     setColorModel(new ColorModelSet());
/* 120:    */     
/* 121:121 */     setCalcDivisions(50);
/* 122:122 */     setDispDivisions(50);
/* 123:123 */     setContourLines(10);
/* 124:    */     
/* 125:125 */     setXMin(-3.0F);
/* 126:126 */     setXMax(3.0F);
/* 127:127 */     setYMin(-3.0F);
/* 128:128 */     setYMax(3.0F);
/* 129:    */     
/* 130:130 */     setBoxed(false);
/* 131:131 */     setDisplayXY(false);
/* 132:132 */     setExpectDelay(false);
/* 133:133 */     setAutoScaleZ(true);
/* 134:134 */     setDisplayZ(false);
/* 135:135 */     setMesh(true);
/* 136:136 */     setPlotType(SurfaceModel.PlotType.SURFACE);
/* 137:137 */     setFirstFunctionOnly(true);
/* 138:138 */     setPlotColor(SurfaceModel.PlotColor.SPECTRUM);
/* 139:    */     
/* 140:140 */     setNbDecimals(3);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void addChangeListener(ChangeListener ol)
/* 144:    */   {
/* 145:145 */     listenerList.add(ChangeListener.class, ol);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void addPropertyChangeListener(PropertyChangeListener listener)
/* 149:    */   {
/* 150:150 */     property.addPropertyChangeListener(listener);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener)
/* 154:    */   {
/* 155:155 */     property.addPropertyChangeListener(propertyName, listener);
/* 156:    */   }
/* 157:    */   
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */   public void autoScale()
/* 162:    */   {
/* 163:163 */     if (!autoScaleZ) {
/* 164:164 */       return;
/* 165:    */     }
/* 166:166 */     if (plotFunction1) {
/* 167:167 */       setZMin(z1Min);
/* 168:168 */       setZMax(z1Max);
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   private void fireAllFunction(boolean oldHas1, boolean oldHas2) {
/* 173:173 */     property.firePropertyChange("firstFunctionOnly", (!oldHas2) && (oldHas1), (!plotFunction2) && (plotFunction1));
/* 174:174 */     property.firePropertyChange("secondFunctionOnly", (!oldHas1) && (oldHas2), (!plotFunction1) && (plotFunction2));
/* 175:175 */     property.firePropertyChange("bothFunction", (oldHas1) && (oldHas2), (plotFunction1) && (plotFunction2));
/* 176:176 */     autoScale();
/* 177:    */   }
/* 178:    */   
/* 179:    */   private void fireAllMode(SurfaceModel.PlotColor oldValue, SurfaceModel.PlotColor newValue)
/* 180:    */   {
/* 181:181 */     for (SurfaceModel.PlotColor c : ) {
/* 182:182 */       property.firePropertyChange(c.getPropertyName(), oldValue == c, newValue == c);
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   private void fireAllType(SurfaceModel.PlotType oldValue, SurfaceModel.PlotType newValue) {
/* 187:187 */     for (SurfaceModel.PlotType c : ) {
/* 188:188 */       property.firePropertyChange(c.getPropertyName(), oldValue == c, newValue == c);
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   protected void fireStateChanged()
/* 193:    */   {
/* 194:194 */     Object[] listeners = listenerList.getListenerList();
/* 195:    */     
/* 196:    */ 
/* 197:197 */     ChangeEvent e = null;
/* 198:198 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/* 199:199 */       if (listeners[i] == ChangeListener.class)
/* 200:    */       {
/* 201:201 */         if (e == null) {
/* 202:202 */           e = new ChangeEvent(this);
/* 203:    */         }
/* 204:204 */         ((ChangeListener)listeners[(i + 1)]).stateChanged(e);
/* 205:    */       }
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   public int getCalcDivisions()
/* 210:    */   {
/* 211:211 */     return calcDivisions;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public SurfaceColor getColorModel()
/* 215:    */   {
/* 216:216 */     return colorModel;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public int getContourLines()
/* 220:    */   {
/* 221:221 */     return contourLines;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public int getDispDivisions()
/* 225:    */   {
/* 226:226 */     if (dispDivisions > calcDivisions) {
/* 227:227 */       dispDivisions = calcDivisions;
/* 228:    */     }
/* 229:229 */     while (calcDivisions % dispDivisions != 0) {
/* 230:230 */       dispDivisions += 1;
/* 231:    */     }
/* 232:232 */     return dispDivisions;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public SurfaceModel.PlotColor getPlotColor()
/* 236:    */   {
/* 237:237 */     return plotColor;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public SurfaceModel.PlotType getPlotType()
/* 241:    */   {
/* 242:242 */     return plotType;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public Projector getProjector()
/* 246:    */   {
/* 247:247 */     if (projector == null) {
/* 248:248 */       projector = new Projector();
/* 249:249 */       projector.setDistance(70.0F);
/* 250:250 */       projector.set2DScaling(15.0F);
/* 251:251 */       projector.setRotationAngle(125.0F);
/* 252:252 */       projector.setElevationAngle(10.0F);
/* 253:    */     }
/* 254:254 */     return projector;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public PropertyChangeSupport getPropertyChangeSupport() {
/* 258:258 */     if (property == null) {
/* 259:259 */       property = new SwingPropertyChangeSupport(this);
/* 260:    */     }
/* 261:261 */     return property;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public float getXMax()
/* 265:    */   {
/* 266:266 */     return xMax;
/* 267:    */   }
/* 268:    */   
/* 269:    */   public float getXMin()
/* 270:    */   {
/* 271:271 */     return xMin;
/* 272:    */   }
/* 273:    */   
/* 274:    */   public float getYMax()
/* 275:    */   {
/* 276:276 */     return yMax;
/* 277:    */   }
/* 278:    */   
/* 279:    */   public float getYMin()
/* 280:    */   {
/* 281:281 */     return yMin;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public float getZMax()
/* 285:    */   {
/* 286:286 */     return zMax;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public float getZMin()
/* 290:    */   {
/* 291:291 */     return zMin;
/* 292:    */   }
/* 293:    */   
/* 294:    */   public boolean isAutoScaleZ()
/* 295:    */   {
/* 296:296 */     return autoScaleZ;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public boolean isBothFunction() {
/* 300:300 */     return (plotFunction1) && (plotFunction2);
/* 301:    */   }
/* 302:    */   
/* 303:    */   public boolean isBoxed()
/* 304:    */   {
/* 305:305 */     return boxed;
/* 306:    */   }
/* 307:    */   
/* 308:    */   public boolean isContourType() {
/* 309:309 */     return plotType == SurfaceModel.PlotType.CONTOUR;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public boolean isDataAvailable()
/* 313:    */   {
/* 314:314 */     return dataAvailable;
/* 315:    */   }
/* 316:    */   
/* 317:    */   public boolean isDensityType() {
/* 318:318 */     return plotType == SurfaceModel.PlotType.DENSITY;
/* 319:    */   }
/* 320:    */   
/* 321:    */   public boolean isDisplayGrids()
/* 322:    */   {
/* 323:323 */     return displayGrids;
/* 324:    */   }
/* 325:    */   
/* 326:    */   public boolean isDisplayXY()
/* 327:    */   {
/* 328:328 */     return displayXY;
/* 329:    */   }
/* 330:    */   
/* 331:    */   public boolean isDisplayZ()
/* 332:    */   {
/* 333:333 */     return displayZ;
/* 334:    */   }
/* 335:    */   
/* 336:    */   public boolean isDualShadeMode() {
/* 337:337 */     return plotColor == SurfaceModel.PlotColor.DUALSHADE;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public boolean isExpectDelay()
/* 341:    */   {
/* 342:342 */     return expectDelay;
/* 343:    */   }
/* 344:    */   
/* 345:    */   public boolean isFirstFunctionOnly() {
/* 346:346 */     return (plotFunction1) && (!plotFunction2);
/* 347:    */   }
/* 348:    */   
/* 349:    */   public boolean isFogMode() {
/* 350:350 */     return plotColor == SurfaceModel.PlotColor.FOG;
/* 351:    */   }
/* 352:    */   
/* 353:    */   public boolean isGrayScaleMode() {
/* 354:354 */     return plotColor == SurfaceModel.PlotColor.GRAYSCALE;
/* 355:    */   }
/* 356:    */   
/* 357:    */   public boolean isHiddenMode() {
/* 358:358 */     return plotColor == SurfaceModel.PlotColor.OPAQUE;
/* 359:    */   }
/* 360:    */   
/* 361:    */   public boolean isMesh()
/* 362:    */   {
/* 363:363 */     return mesh;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public boolean isPlotFunction1()
/* 367:    */   {
/* 368:368 */     return plotFunction1;
/* 369:    */   }
/* 370:    */   
/* 371:    */   public boolean isPlotFunction2()
/* 372:    */   {
/* 373:373 */     return plotFunction2;
/* 374:    */   }
/* 375:    */   
/* 376:    */   public boolean isScaleBox()
/* 377:    */   {
/* 378:378 */     return scaleBox;
/* 379:    */   }
/* 380:    */   
/* 381:    */   public boolean isSecondFunctionOnly() {
/* 382:382 */     return (!plotFunction1) && (plotFunction2);
/* 383:    */   }
/* 384:    */   
/* 385:    */   public boolean isSpectrumMode() {
/* 386:386 */     return plotColor == SurfaceModel.PlotColor.SPECTRUM;
/* 387:    */   }
/* 388:    */   
/* 389:    */   public boolean isSurfaceType() {
/* 390:390 */     return plotType == SurfaceModel.PlotType.SURFACE;
/* 391:    */   }
/* 392:    */   
/* 393:    */   public boolean isWireframeType() {
/* 394:394 */     return plotType == SurfaceModel.PlotType.WIREFRAME;
/* 395:    */   }
/* 396:    */   
/* 397:    */   public int getNbDecimals()
/* 398:    */   {
/* 399:399 */     return nbDecimals;
/* 400:    */   }
/* 401:    */   
/* 402:    */   public void removeChangeListener(ChangeListener ol)
/* 403:    */   {
/* 404:404 */     listenerList.remove(ChangeListener.class, ol);
/* 405:    */   }
/* 406:    */   
/* 407:    */   public void removePropertyChangeListener(PropertyChangeListener listener)
/* 408:    */   {
/* 409:409 */     property.removePropertyChangeListener(listener);
/* 410:    */   }
/* 411:    */   
/* 412:    */   public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener)
/* 413:    */   {
/* 414:414 */     property.removePropertyChangeListener(propertyName, listener);
/* 415:    */   }
/* 416:    */   
/* 417:    */ 
/* 418:    */   public void rotationStops() {}
/* 419:    */   
/* 420:    */   public void setNbDecimals(int nb)
/* 421:    */   {
/* 422:422 */     getPropertyChangeSupport().firePropertyChange("nbDecimals", nbDecimals, this.nbDecimals = nb);
/* 423:    */   }
/* 424:    */   
/* 425:    */   public void setAutoScaleZ(boolean autoScaleZ) {
/* 426:426 */     getPropertyChangeSupport().firePropertyChange("this.autoScaleZ", this.autoScaleZ, this.autoScaleZ = autoScaleZ);
/* 427:427 */     autoScale();
/* 428:    */   }
/* 429:    */   
/* 430:    */   public void setBothFunction(boolean val) {
/* 431:431 */     setPlotFunction12(val, val);
/* 432:    */   }
/* 433:    */   
/* 434:    */   public void setBoxed(boolean boxed) {
/* 435:435 */     getPropertyChangeSupport().firePropertyChange("boxed", this.boxed, this.boxed = boxed);
/* 436:    */   }
/* 437:    */   
/* 438:    */   protected void setColorModel(ColorModelSet colorModel) {
/* 439:439 */     getPropertyChangeSupport().firePropertyChange("colorModel", this.colorModel, this.colorModel = colorModel);
/* 440:440 */     if (colorModel != null) {
/* 441:441 */       colorModel.setPlotColor(plotColor);
/* 442:442 */       colorModel.setPlotType(plotType);
/* 443:    */     }
/* 444:    */   }
/* 445:    */   
/* 446:    */   public void setContourLines(int contourLines) {
/* 447:447 */     getPropertyChangeSupport().firePropertyChange("contourLines", this.contourLines, this.contourLines = contourLines);
/* 448:    */   }
/* 449:    */   
/* 450:    */   public void setContourType(boolean val) {
/* 451:451 */     setPlotType(val ? SurfaceModel.PlotType.CONTOUR : SurfaceModel.PlotType.SURFACE);
/* 452:    */   }
/* 453:    */   
/* 454:    */   public void setDataAvailable(boolean dataAvailable) {
/* 455:455 */     getPropertyChangeSupport().firePropertyChange("dataAvailable", this.dataAvailable, this.dataAvailable = dataAvailable);
/* 456:    */   }
/* 457:    */   
/* 458:    */   public void setDensityType(boolean val) {
/* 459:459 */     setPlotType(val ? SurfaceModel.PlotType.DENSITY : SurfaceModel.PlotType.SURFACE);
/* 460:    */   }
/* 461:    */   
/* 462:    */   public void setDispDivisions(int dispDivisions) {
/* 463:463 */     getPropertyChangeSupport().firePropertyChange("dispDivisions", this.dispDivisions, this.dispDivisions = dispDivisions);
/* 464:    */   }
/* 465:    */   
/* 466:    */   public void setDualShadeMode(boolean val) {
/* 467:467 */     setPlotColor(val ? SurfaceModel.PlotColor.DUALSHADE : SurfaceModel.PlotColor.SPECTRUM);
/* 468:    */   }
/* 469:    */   
/* 470:    */   public void setFirstFunctionOnly(boolean val) {
/* 471:471 */     setPlotFunction12(val, !val);
/* 472:    */   }
/* 473:    */   
/* 474:    */   public void setFogMode(boolean val) {
/* 475:475 */     setPlotColor(val ? SurfaceModel.PlotColor.FOG : SurfaceModel.PlotColor.SPECTRUM);
/* 476:    */   }
/* 477:    */   
/* 478:    */   public void setGrayScaleMode(boolean val) {
/* 479:479 */     setPlotColor(val ? SurfaceModel.PlotColor.GRAYSCALE : SurfaceModel.PlotColor.SPECTRUM);
/* 480:    */   }
/* 481:    */   
/* 482:    */   public void setHiddenMode(boolean val) {
/* 483:483 */     setPlotColor(val ? SurfaceModel.PlotColor.OPAQUE : SurfaceModel.PlotColor.SPECTRUM);
/* 484:    */   }
/* 485:    */   
/* 486:    */   public void setPlotFunction1(boolean plotFunction1) {
/* 487:487 */     setPlotFunction12(plotFunction1, plotFunction2);
/* 488:    */   }
/* 489:    */   
/* 490:    */   public void setPlotColor(SurfaceModel.PlotColor plotColor) {
/* 491:491 */     SurfaceModel.PlotColor old = this.plotColor;
/* 492:492 */     getPropertyChangeSupport().firePropertyChange("plotColor", this.plotColor, this.plotColor = plotColor);
/* 493:493 */     fireAllMode(old, this.plotColor);
/* 494:494 */     if (colorModel != null) {
/* 495:495 */       colorModel.setPlotColor(plotColor);
/* 496:    */     }
/* 497:    */   }
/* 498:    */   
/* 499:    */   public void setPlotFunction12(boolean p1, boolean p2) {
/* 500:500 */     boolean o1 = plotFunction1;
/* 501:501 */     boolean o2 = plotFunction2;
/* 502:    */     
/* 503:503 */     plotFunction1 = ((hasFunction1) && (p1));
/* 504:504 */     property.firePropertyChange("plotFunction1", o1, p1);
/* 505:    */     
/* 506:506 */     plotFunction2 = ((hasFunction2) && (p2));
/* 507:507 */     property.firePropertyChange("plotFunction1", o2, p2);
/* 508:508 */     fireAllFunction(o1, o2);
/* 509:    */   }
/* 510:    */   
/* 511:    */   public void setPlotFunction2(boolean v) {
/* 512:512 */     setPlotFunction12(plotFunction1, plotFunction2);
/* 513:    */   }
/* 514:    */   
/* 515:    */   public void setPlotType(SurfaceModel.PlotType plotType) {
/* 516:516 */     SurfaceModel.PlotType o = this.plotType;
/* 517:517 */     this.plotType = plotType;
/* 518:518 */     if (colorModel != null) {
/* 519:519 */       colorModel.setPlotType(plotType);
/* 520:    */     }
/* 521:521 */     property.firePropertyChange("plotType", o, this.plotType);
/* 522:522 */     fireAllType(o, this.plotType);
/* 523:    */   }
/* 524:    */   
/* 525:    */   public void setSecondFunctionOnly(boolean val) {
/* 526:526 */     setPlotFunction12(!val, val);
/* 527:    */   }
/* 528:    */   
/* 529:    */   public void setSpectrumMode(boolean val) {
/* 530:530 */     setPlotColor(val ? SurfaceModel.PlotColor.SPECTRUM : SurfaceModel.PlotColor.GRAYSCALE);
/* 531:    */   }
/* 532:    */   
/* 533:    */   public void setSurfaceType(boolean val) {
/* 534:534 */     setPlotType(val ? SurfaceModel.PlotType.SURFACE : SurfaceModel.PlotType.WIREFRAME);
/* 535:    */   }
/* 536:    */   
/* 537:    */   public void setWireframeType(boolean val) {
/* 538:538 */     if (val) {
/* 539:539 */       setPlotType(SurfaceModel.PlotType.WIREFRAME);
/* 540:    */     } else {
/* 541:541 */       setPlotType(SurfaceModel.PlotType.SURFACE);
/* 542:    */     }
/* 543:    */   }
/* 544:    */   
/* 545:    */   public void setXMax(float xMax) {
/* 546:546 */     getPropertyChangeSupport().firePropertyChange("xMax", Float.valueOf(this.xMax), Float.valueOf(this.xMax = xMax));
/* 547:    */   }
/* 548:    */   
/* 549:    */   public void setXMin(float xMin) {
/* 550:550 */     getPropertyChangeSupport().firePropertyChange("xMin", Float.valueOf(this.xMin), Float.valueOf(this.xMin = xMin));
/* 551:    */   }
/* 552:    */   
/* 553:    */   public void setYMax(float yMax) {
/* 554:554 */     getPropertyChangeSupport().firePropertyChange("yMax", Float.valueOf(this.yMax), Float.valueOf(this.yMax = yMax));
/* 555:    */   }
/* 556:    */   
/* 557:    */   public void setYMin(float yMin) {
/* 558:558 */     getPropertyChangeSupport().firePropertyChange("yMin", Float.valueOf(this.yMin), Float.valueOf(this.yMin = yMin));
/* 559:    */   }
/* 560:    */   
/* 561:    */   public void setZMax(float zMax) {
/* 562:562 */     getPropertyChangeSupport().firePropertyChange("zMax", Float.valueOf(this.zMax), Float.valueOf(this.zMax = zMax));
/* 563:    */   }
/* 564:    */   
/* 565:    */   public void setZMin(float zMin) {
/* 566:566 */     getPropertyChangeSupport().firePropertyChange("zMin", Float.valueOf(this.zMin), Float.valueOf(this.zMin = zMin));
/* 567:    */   }
/* 568:    */   
/* 569:    */   public void setDisplayGrids(boolean displayGrids) {
/* 570:570 */     getPropertyChangeSupport().firePropertyChange("displayGrids", this.displayGrids, this.displayGrids = displayGrids);
/* 571:    */   }
/* 572:    */   
/* 573:    */   public void setDisplayXY(boolean displayXY) {
/* 574:574 */     getPropertyChangeSupport().firePropertyChange("displayXY", this.displayXY, this.displayXY = displayXY);
/* 575:    */   }
/* 576:    */   
/* 577:    */   public void setDisplayZ(boolean displayZ) {
/* 578:578 */     getPropertyChangeSupport().firePropertyChange("displayZ", this.displayZ, this.displayZ = displayZ);
/* 579:    */   }
/* 580:    */   
/* 581:    */   public void setExpectDelay(boolean expectDelay) {
/* 582:582 */     getPropertyChangeSupport().firePropertyChange("expectDelay", this.expectDelay, this.expectDelay = expectDelay);
/* 583:    */   }
/* 584:    */   
/* 585:    */   public void setMesh(boolean mesh) {
/* 586:586 */     getPropertyChangeSupport().firePropertyChange("mesh", this.mesh, this.mesh = mesh);
/* 587:    */   }
/* 588:    */   
/* 589:    */   public void setScaleBox(boolean scaleBox) {
/* 590:590 */     getPropertyChangeSupport().firePropertyChange("scaleBox", this.scaleBox, this.scaleBox = scaleBox);
/* 591:    */   }
/* 592:    */   
/* 593:    */   public void toggleAutoScaleZ() {
/* 594:594 */     setAutoScaleZ(!isAutoScaleZ());
/* 595:    */   }
/* 596:    */   
/* 597:    */   public void toggleBoxed() {
/* 598:598 */     setBoxed(!isBoxed());
/* 599:    */   }
/* 600:    */   
/* 601:    */   public void setCalcDivisions(int calcDivisions) {
/* 602:602 */     getPropertyChangeSupport().firePropertyChange("calcDivisions", this.calcDivisions, this.calcDivisions = calcDivisions);
/* 603:    */   }
/* 604:    */   
/* 605:    */   public void toggleDisplayGrids() {
/* 606:606 */     setDisplayGrids(!isDisplayGrids());
/* 607:    */   }
/* 608:    */   
/* 609:    */   public void toggleDisplayXY() {
/* 610:610 */     setDisplayXY(!isDisplayXY());
/* 611:    */   }
/* 612:    */   
/* 613:    */   public void toggleDisplayZ() {
/* 614:614 */     setDisplayZ(!isDisplayZ());
/* 615:    */   }
/* 616:    */   
/* 617:    */   public void toggleExpectDelay() {
/* 618:618 */     setExpectDelay(!isExpectDelay());
/* 619:    */   }
/* 620:    */   
/* 621:    */   public void toggleMesh() {
/* 622:622 */     setMesh(!isMesh());
/* 623:    */   }
/* 624:    */   
/* 625:    */   public void togglePlotFunction1() {
/* 626:626 */     setPlotFunction1(!isPlotFunction1());
/* 627:    */   }
/* 628:    */   
/* 629:    */   public void togglePlotFunction2()
/* 630:    */   {
/* 631:631 */     setPlotFunction2(!isPlotFunction2());
/* 632:    */   }
/* 633:    */   
/* 634:    */   public void toggleScaleBox()
/* 635:    */   {
/* 636:636 */     setScaleBox(!isScaleBox());
/* 637:    */   }
/* 638:    */   
/* 639:    */   public static abstract interface Plotter
/* 640:    */   {
/* 641:    */     public abstract int getHeight();
/* 642:    */     
/* 643:    */     public abstract int getWidth();
/* 644:    */     
/* 645:    */     public abstract float getX(int paramInt);
/* 646:    */     
/* 647:    */     public abstract float getY(int paramInt);
/* 648:    */     
/* 649:    */     public abstract void setValue(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2);
/* 650:    */   }
/* 651:    */ }
