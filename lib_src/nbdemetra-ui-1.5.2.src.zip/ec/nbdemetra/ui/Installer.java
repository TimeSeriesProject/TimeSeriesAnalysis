/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import com.google.common.collect.FluentIterable;
/*   5:    */ import com.google.common.collect.Iterables;
/*   6:    */ import com.google.common.collect.Iterators;
/*   7:    */ import ec.nbdemetra.core.InstallerStep;
/*   8:    */ import ec.nbdemetra.core.InstallerStep.LookupStep;
/*   9:    */ import ec.nbdemetra.ui.interchange.InterchangeBroker;
/*  10:    */ import ec.nbdemetra.ui.mru.MruProvidersStep;
/*  11:    */ import ec.nbdemetra.ui.mru.MruWorkspacesStep;
/*  12:    */ import ec.nbdemetra.ui.star.StarHelper;
/*  13:    */ import ec.nbdemetra.ui.tsproviders.IDataSourceProviderBuddy;
/*  14:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  15:    */ import ec.tss.datatransfer.TssTransferHandler;
/*  16:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  17:    */ import ec.tss.tsproviders.DataSource;
/*  18:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*  19:    */ import ec.tss.tsproviders.TsProviders;
/*  20:    */ import ec.tss.tsproviders.utils.Formatters;
/*  21:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  22:    */ import ec.tss.tsproviders.utils.Parsers;
/*  23:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  24:    */ import java.util.Collection;
/*  25:    */ import java.util.Collections;
/*  26:    */ import java.util.Iterator;
/*  27:    */ import java.util.List;
/*  28:    */ import java.util.prefs.BackingStoreException;
/*  29:    */ import java.util.prefs.Preferences;
/*  30:    */ import javax.xml.bind.annotation.XmlElement;
/*  31:    */ import javax.xml.bind.annotation.XmlRootElement;
/*  32:    */ import org.jfree.chart.ChartFactory;
/*  33:    */ import org.jfree.chart.StandardChartTheme;
/*  34:    */ import org.jfree.chart.renderer.category.BarRenderer;
/*  35:    */ import org.jfree.chart.renderer.category.StandardBarPainter;
/*  36:    */ import org.openide.modules.ModuleInstall;
/*  37:    */ import org.openide.util.Lookup;
/*  38:    */ import org.openide.util.Lookup.Result;
/*  39:    */ import org.slf4j.Logger;
/*  40:    */ import org.slf4j.LoggerFactory;
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ public final class Installer
/*  53:    */   extends ModuleInstall
/*  54:    */ {
/*  55: 55 */   private static final Logger LOGGER = LoggerFactory.getLogger(Installer.class);
/*  56:    */   
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66: 66 */   private final InstallerStep step = InstallerStep.all(new InstallerStep[] {new JFreeChartStep(null), new FormattersStep(), new MruProvidersStep(), new MruWorkspacesStep(), new StarHelper(), new DemetraUIStep(null), new PersistOpenedDataSourcesStep(null), new InterchangeStep(), new ProviderBuddiesStep() });
/*  67:    */   
/*  68:    */   public void restored()
/*  69:    */   {
/*  70: 70 */     super.restored();
/*  71: 71 */     step.restore();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void close()
/*  75:    */   {
/*  76: 76 */     step.close();
/*  77: 77 */     super.close();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean closing()
/*  81:    */   {
/*  82: 82 */     return WorkspaceFactory.getInstance().closeWorkspace(true);
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static final class JFreeChartStep
/*  86:    */     extends InstallerStep
/*  87:    */   {
/*  88:    */     public void restore()
/*  89:    */     {
/*  90: 90 */       ChartFactory.setChartTheme(StandardChartTheme.createLegacyTheme());
/*  91: 91 */       BarRenderer.setDefaultBarPainter(new StandardBarPainter());
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static final class FormattersStep extends InstallerStep.LookupStep<TssTransferHandler>
/*  96:    */   {
/*  97:    */     FormattersStep() {
/*  98: 98 */       super();
/*  99:    */     }
/* 100:    */     
/* 101:    */ 
/* 102:    */ 
/* 103:    */     protected void onResultChanged(Lookup.Result<TssTransferHandler> lookup) {}
/* 104:    */     
/* 105:    */ 
/* 106:    */     protected void onRestore(Lookup.Result<TssTransferHandler> lookup)
/* 107:    */     {
/* 108:108 */       Installer.loadConfig(lookup.allInstances(), prefs());
/* 109:    */     }
/* 110:    */     
/* 111:    */     protected void onClose(Lookup.Result<TssTransferHandler> lookup)
/* 112:    */     {
/* 113:113 */       Installer.storeConfig(TssTransferSupport.getDefault().all().toList(), prefs());
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static final class DemetraUIStep extends InstallerStep
/* 118:    */   {
/* 119:    */     public void restore()
/* 120:    */     {
/* 121:121 */       DemetraUI ui = DemetraUI.getDefault();
/* 122:122 */       Installer.loadConfig(Collections.singleton(ui), prefs());
/* 123:    */     }
/* 124:    */     
/* 125:    */     public void close()
/* 126:    */     {
/* 127:127 */       DemetraUI ui = DemetraUI.getDefault();
/* 128:128 */       Installer.storeConfig(Collections.singleton(ui), prefs());
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   private static final class PersistOpenedDataSourcesStep extends InstallerStep
/* 133:    */   {
/* 134:    */     public void restore()
/* 135:    */     {
/* 136:136 */       if (DemetraUI.getDefault().isPersistOpenedDataSources()) {
/* 137:137 */         Preferences prefs = prefs();
/* 138:138 */         Parsers.Parser<DataSourcesBean> parser = Parsers.onJAXB(DataSourcesBean.class);
/* 139:139 */         for (IDataSourceLoader o : TsProviders.all().filter(IDataSourceLoader.class)) {
/* 140:140 */           Optional<DataSourcesBean> value = tryGet(prefs, o.getSource(), parser);
/* 141:141 */           if (value.isPresent()) {
/* 142:142 */             for (DataSource dataSource : (DataSourcesBean)value.get()) {
/* 143:143 */               o.open(dataSource);
/* 144:    */             }
/* 145:    */           }
/* 146:    */         }
/* 147:    */       }
/* 148:    */     }
/* 149:    */     
/* 150:    */     public void close()
/* 151:    */     {
/* 152:152 */       if (DemetraUI.getDefault().isPersistOpenedDataSources()) {
/* 153:153 */         Preferences prefs = prefs();
/* 154:154 */         Formatters.Formatter<DataSourcesBean> formatter = Formatters.onJAXB(DataSourcesBean.class, false);
/* 155:155 */         for (IDataSourceLoader o : TsProviders.all().filter(IDataSourceLoader.class)) {
/* 156:156 */           DataSourcesBean value = new DataSourcesBean();
/* 157:157 */           dataSources = o.getDataSources();
/* 158:158 */           tryPut(prefs, o.getSource(), formatter, value);
/* 159:    */         }
/* 160:    */         try {
/* 161:161 */           prefs.flush();
/* 162:    */         } catch (BackingStoreException ex) {
/* 163:163 */           Installer.LOGGER.warn("Can't flush storage", ex);
/* 164:    */         }
/* 165:    */       }
/* 166:    */     }
/* 167:    */     
/* 168:    */     @XmlRootElement(name="dataSources")
/* 169:    */     static class DataSourcesBean implements Iterable<DataSource>
/* 170:    */     {
/* 171:    */       @XmlElement(name="dataSource")
/* 172:    */       public List<DataSource> dataSources;
/* 173:    */       
/* 174:    */       public Iterator<DataSource> iterator()
/* 175:    */       {
/* 176:176 */         return dataSources != null ? dataSources.iterator() : Iterators.emptyIterator();
/* 177:    */       }
/* 178:    */     }
/* 179:    */   }
/* 180:    */   
/* 181:    */   private static final class InterchangeStep extends Installer.ConfigStep<InterchangeBroker>
/* 182:    */   {
/* 183:    */     InterchangeStep() {
/* 184:184 */       super();
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   private static final class ProviderBuddiesStep extends Installer.ConfigStep<IDataSourceProviderBuddy>
/* 189:    */   {
/* 190:    */     ProviderBuddiesStep() {
/* 191:191 */       super();
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   private static class ConfigStep<T> extends InstallerStep.LookupStep<T>
/* 196:    */   {
/* 197:    */     public ConfigStep(Class<T> clazz) {
/* 198:198 */       super();
/* 199:    */     }
/* 200:    */     
/* 201:    */ 
/* 202:    */ 
/* 203:    */     protected void onResultChanged(Lookup.Result<T> lookup) {}
/* 204:    */     
/* 205:    */ 
/* 206:    */     protected void onRestore(Lookup.Result<T> lookup)
/* 207:    */     {
/* 208:208 */       Installer.loadConfig(lookup.allInstances(), prefs());
/* 209:    */     }
/* 210:    */     
/* 211:    */     protected void onClose(Lookup.Result<T> lookup)
/* 212:    */     {
/* 213:213 */       Collection<? extends T> instances = lookup != null ? lookup.allInstances() : Lookup.getDefault().lookupAll(getLookupClass());
/* 214:214 */       Installer.storeConfig(instances, prefs());
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   public static void loadConfig(Collection<?> list, Preferences root)
/* 219:    */   {
/* 220:220 */     Parsers.Parser<Config> parser = Config.xmlParser();
/* 221:221 */     for (IConfigurable o : Iterables.filter(list, IConfigurable.class)) {
/* 222:222 */       Config current = o.getConfig();
/* 223:    */       try {
/* 224:224 */         if (root.nodeExists(current.getDomain())) {
/* 225:225 */           Preferences domain = root.node(current.getDomain());
/* 226:226 */           Optional<Config> config = InstallerStep.tryGet(domain, current.getName(), parser);
/* 227:227 */           if (config.isPresent()) {
/* 228:228 */             o.setConfig((Config)config.get());
/* 229:    */           }
/* 230:    */         }
/* 231:    */       }
/* 232:    */       catch (BackingStoreException localBackingStoreException) {}
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   public static void storeConfig(Collection<?> list, Preferences root)
/* 237:    */   {
/* 238:238 */     Formatters.Formatter<Config> formatter = Config.xmlFormatter(false);
/* 239:239 */     for (IConfigurable o : Iterables.filter(list, IConfigurable.class)) {
/* 240:240 */       Config current = o.getConfig();
/* 241:241 */       Preferences domain = root.node(current.getDomain());
/* 242:242 */       InstallerStep.tryPut(domain, current.getName(), formatter, current);
/* 243:    */     }
/* 244:    */     try {
/* 245:245 */       root.flush();
/* 246:    */     } catch (BackingStoreException ex) {
/* 247:247 */       LOGGER.warn("Can't flush storage", ex);
/* 248:    */     }
/* 249:    */   }
/* 250:    */ }
