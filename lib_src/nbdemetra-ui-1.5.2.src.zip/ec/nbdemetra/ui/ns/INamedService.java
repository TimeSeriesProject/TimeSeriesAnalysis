package ec.nbdemetra.ui.ns;

import java.awt.Image;
import org.openide.nodes.Sheet;

public abstract interface INamedService
{
  public abstract String getName();
  
  public abstract String getDisplayName();
  
  public abstract Image getIcon(int paramInt, boolean paramBoolean);
  
  public abstract Sheet createSheet();
}
