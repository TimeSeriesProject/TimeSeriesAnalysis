/*  1:   */ package ec.nbdemetra.ui.ns;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import ec.nbdemetra.ui.Config;
/*  5:   */ import ec.nbdemetra.ui.Config.Builder;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class NamedServiceSupport
/* 14:   */ {
/* 15:   */   protected final Class<? extends INamedService> service;
/* 16:   */   protected final String name;
/* 17:   */   
/* 18:   */   public NamedServiceSupport(Class<? extends INamedService> service, String name)
/* 19:   */   {
/* 20:20 */     this.service = service;
/* 21:21 */     this.name = name;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Class<? extends INamedService> getService() {
/* 25:25 */     return service;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getName() {
/* 29:29 */     return name;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void check(Config config) {
/* 33:33 */     Preconditions.checkArgument(config.getDomain().equals(service.getName()));
/* 34:34 */     Preconditions.checkArgument(config.getName().equals(name));
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Config.Builder newBuilder() {
/* 38:38 */     return Config.builder(service.getName(), name, "");
/* 39:   */   }
/* 40:   */ }
