/*  1:   */ package ec.nbdemetra.ui.ns;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.DemetraUiIcon;
/*  4:   */ import java.awt.Image;
/*  5:   */ import org.openide.nodes.Sheet;
/*  6:   */ import org.openide.util.ImageUtilities;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public abstract class AbstractNamedService
/* 15:   */   implements INamedService
/* 16:   */ {
/* 17:   */   protected final NamedServiceSupport support;
/* 18:   */   
/* 19:   */   protected AbstractNamedService(Class<? extends INamedService> service, String name)
/* 20:   */   {
/* 21:21 */     support = new NamedServiceSupport(service, name);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getName()
/* 25:   */   {
/* 26:26 */     return support.getName();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getDisplayName()
/* 30:   */   {
/* 31:31 */     return getName();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Image getIcon(int type, boolean opened)
/* 35:   */   {
/* 36:36 */     return ImageUtilities.icon2Image(DemetraUiIcon.PUZZLE_16);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public Sheet createSheet()
/* 40:   */   {
/* 41:41 */     return new Sheet();
/* 42:   */   }
/* 43:   */ }
