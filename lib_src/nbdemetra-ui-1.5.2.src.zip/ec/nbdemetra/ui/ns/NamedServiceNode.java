/*  1:   */ package ec.nbdemetra.ui.ns;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.Config;
/*  4:   */ import ec.nbdemetra.ui.IConfigurable;
/*  5:   */ import java.awt.Image;
/*  6:   */ import java.awt.event.ActionEvent;
/*  7:   */ import javax.swing.AbstractAction;
/*  8:   */ import javax.swing.Action;
/*  9:   */ import org.openide.nodes.AbstractNode;
/* 10:   */ import org.openide.nodes.Children;
/* 11:   */ import org.openide.nodes.Sheet;
/* 12:   */ import org.openide.util.Lookup;
/* 13:   */ import org.openide.util.lookup.Lookups;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class NamedServiceNode
/* 19:   */   extends AbstractNode
/* 20:   */ {
/* 21:   */   Config latestConfig;
/* 22:   */   
/* 23:   */   public NamedServiceNode(INamedService namedService)
/* 24:   */   {
/* 25:25 */     super(Children.LEAF, Lookups.singleton(namedService));
/* 26:26 */     setName(namedService.getName());
/* 27:27 */     setDisplayName(namedService.getDisplayName());
/* 28:   */   }
/* 29:   */   
/* 30:   */   protected INamedService getNamedService() {
/* 31:31 */     return (INamedService)getLookup().lookup(INamedService.class);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Image getIcon(int type)
/* 35:   */   {
/* 36:36 */     Image image = getNamedService().getIcon(type, false);
/* 37:37 */     return image != null ? image : super.getIcon(type);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Image getOpenedIcon(int type)
/* 41:   */   {
/* 42:42 */     Image image = getNamedService().getIcon(type, true);
/* 43:43 */     return image != null ? image : super.getIcon(type);
/* 44:   */   }
/* 45:   */   
/* 46:   */   protected Sheet createSheet()
/* 47:   */   {
/* 48:48 */     return getNamedService().createSheet();
/* 49:   */   }
/* 50:   */   
/* 51:   */ 
/* 52:   */   public void applyConfig()
/* 53:   */   {
/* 54:54 */     if (latestConfig != null) {
/* 55:55 */       ((IConfigurable)getLookup().lookup(IConfigurable.class)).setConfig(latestConfig);
/* 56:56 */       latestConfig = null;
/* 57:   */     }
/* 58:   */   }
/* 59:   */   
/* 60:   */   public Action getPreferredAction()
/* 61:   */   {
/* 62:62 */     final IConfigurable service = (IConfigurable)getLookup().lookup(IConfigurable.class);
/* 63:63 */     service != null ? new AbstractAction()
/* 64:   */     {
/* 65:   */       public void actionPerformed(ActionEvent e) {
/* 66:66 */         latestConfig = service.editConfig(latestConfig != null ? latestConfig : service.getConfig());
/* 67:   */       }
/* 68:68 */     } : super.getPreferredAction();
/* 69:   */   }
/* 70:   */ }
