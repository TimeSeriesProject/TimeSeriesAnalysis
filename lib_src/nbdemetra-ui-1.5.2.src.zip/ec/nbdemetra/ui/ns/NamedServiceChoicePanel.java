/*  1:   */ package ec.nbdemetra.ui.ns;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Iterables;
/*  4:   */ import ec.nbdemetra.ui.Jdk6Functions;
/*  5:   */ import ec.nbdemetra.ui.nodes.AbstractNodeBuilder;
/*  6:   */ import java.awt.BorderLayout;
/*  7:   */ import java.awt.Dimension;
/*  8:   */ import java.beans.PropertyVetoException;
/*  9:   */ import javax.swing.JComboBox;
/* 10:   */ import javax.swing.JPanel;
/* 11:   */ import org.openide.explorer.ExplorerManager;
/* 12:   */ import org.openide.explorer.ExplorerManager.Provider;
/* 13:   */ import org.openide.explorer.view.ChoiceView;
/* 14:   */ import org.openide.nodes.Children;
/* 15:   */ import org.openide.nodes.Node;
/* 16:   */ import org.openide.util.Exceptions;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class NamedServiceChoicePanel
/* 22:   */   extends JPanel
/* 23:   */   implements ExplorerManager.Provider
/* 24:   */ {
/* 25:   */   final ExplorerManager em;
/* 26:   */   private JComboBox jComboBox1;
/* 27:   */   
/* 28:   */   public NamedServiceChoicePanel()
/* 29:   */   {
/* 30:30 */     initComponents();
/* 31:   */     
/* 32:32 */     em = new ExplorerManager();
/* 33:33 */     jComboBox1.setPreferredSize(new Dimension(200, 24));
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void setContent(Iterable<? extends INamedService> namedServices) {
/* 37:37 */     Iterable<NamedServiceNode> nodes = Iterables.transform(namedServices, Jdk6Functions.namedServiceToNode());
/* 38:38 */     em.setRootContext(new AbstractNodeBuilder().add(nodes).orderable(false).build());
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String getSelectedServiceName() {
/* 42:42 */     Node[] nodes = em.getSelectedNodes();
/* 43:43 */     return nodes.length == 0 ? null : nodes[0].getName();
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setSelectedServiceName(String name) {
/* 47:47 */     Node node = em.getRootContext().getChildren().findChild(name);
/* 48:48 */     if (node != null) {
/* 49:   */       try {
/* 50:50 */         em.setSelectedNodes(new Node[] { node });
/* 51:   */       } catch (PropertyVetoException ex) {
/* 52:52 */         Exceptions.printStackTrace(ex);
/* 53:   */       }
/* 54:   */     }
/* 55:   */   }
/* 56:   */   
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */ 
/* 62:   */ 
/* 63:   */ 
/* 64:   */   private void initComponents()
/* 65:   */   {
/* 66:66 */     jComboBox1 = new ChoiceView();
/* 67:   */     
/* 68:68 */     setLayout(new BorderLayout());
/* 69:   */     
/* 70:70 */     jComboBox1.setModel(jComboBox1.getModel());
/* 71:71 */     jComboBox1.setMinimumSize(new Dimension(100, 20));
/* 72:72 */     jComboBox1.setPreferredSize(new Dimension(100, 20));
/* 73:73 */     add(jComboBox1, "Center");
/* 74:   */   }
/* 75:   */   
/* 76:   */ 
/* 77:   */ 
/* 78:   */ 
/* 79:   */   public ExplorerManager getExplorerManager()
/* 80:   */   {
/* 81:81 */     return em;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public JComboBox getComboBox() {
/* 85:85 */     return jComboBox1;
/* 86:   */   }
/* 87:   */ }
