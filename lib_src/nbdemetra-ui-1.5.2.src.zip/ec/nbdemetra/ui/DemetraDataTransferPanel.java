/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ns.NamedServiceNode;
/*   4:    */ import java.beans.PropertyChangeEvent;
/*   5:    */ import javax.swing.GroupLayout;
/*   6:    */ import javax.swing.GroupLayout.ParallelGroup;
/*   7:    */ import javax.swing.GroupLayout.SequentialGroup;
/*   8:    */ import javax.swing.JButton;
/*   9:    */ import javax.swing.JToolBar;
/*  10:    */ import org.openide.explorer.ExplorerManager;
/*  11:    */ import org.openide.nodes.Node;
/*  12:    */ 
/*  13:    */ final class DemetraDataTransferPanel extends javax.swing.JPanel implements org.openide.explorer.ExplorerManager.Provider
/*  14:    */ {
/*  15:    */   private final DemetraDataTransferOptionsPanelController controller;
/*  16:    */   final ExplorerManager em;
/*  17:    */   private JButton editButton;
/*  18:    */   private JToolBar jToolBar1;
/*  19:    */   private org.openide.explorer.view.TreeTableView treeTableView1;
/*  20:    */   
/*  21:    */   DemetraDataTransferPanel(DemetraDataTransferOptionsPanelController controller)
/*  22:    */   {
/*  23: 23 */     this.controller = controller;
/*  24: 24 */     em = new ExplorerManager();
/*  25: 25 */     initComponents();
/*  26:    */     
/*  27: 27 */     editButton.setEnabled(false);
/*  28: 28 */     em.addVetoableChangeListener(new java.beans.VetoableChangeListener()
/*  29:    */     {
/*  30:    */       public void vetoableChange(PropertyChangeEvent evt) throws java.beans.PropertyVetoException {
/*  31: 31 */         if ("selectedNodes".equals(evt.getPropertyName())) {
/*  32: 32 */           Node[] nodes = (Node[])evt.getNewValue();
/*  33: 33 */           editButton.setEnabled((nodes.length == 1) && (nodes[0].getLookup().lookup(IConfigurable.class) != null));
/*  34:    */         }
/*  35:    */       }
/*  36:    */     });
/*  37:    */   }
/*  38:    */   
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */   private void initComponents()
/*  46:    */   {
/*  47: 47 */     treeTableView1 = new org.openide.explorer.view.TreeTableView();
/*  48: 48 */     jToolBar1 = new JToolBar();
/*  49: 49 */     editButton = new JButton();
/*  50:    */     
/*  51: 51 */     treeTableView1.setRootVisible(false);
/*  52:    */     
/*  53: 53 */     jToolBar1.setFloatable(false);
/*  54: 54 */     jToolBar1.setOrientation(1);
/*  55: 55 */     jToolBar1.setRollover(true);
/*  56:    */     
/*  57: 57 */     editButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ec/nbdemetra/ui/preferences-system_16x16.png")));
/*  58: 58 */     org.openide.awt.Mnemonics.setLocalizedText(editButton, org.openide.util.NbBundle.getMessage(DemetraDataTransferPanel.class, "DemetraDataTransferPanel.editButton.text"));
/*  59: 59 */     editButton.setToolTipText(org.openide.util.NbBundle.getMessage(DemetraDataTransferPanel.class, "DemetraDataTransferPanel.editButton.toolTipText"));
/*  60: 60 */     editButton.addActionListener(new java.awt.event.ActionListener() {
/*  61:    */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/*  62: 62 */         DemetraDataTransferPanel.this.editButtonActionPerformed(evt);
/*  63:    */       }
/*  64: 64 */     });
/*  65: 65 */     jToolBar1.add(editButton);
/*  66:    */     
/*  67: 67 */     GroupLayout layout = new GroupLayout(this);
/*  68: 68 */     setLayout(layout);
/*  69: 69 */     layout.setHorizontalGroup(
/*  70: 70 */       layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/*  71: 71 */       .addGroup(layout.createSequentialGroup()
/*  72: 72 */       .addComponent(treeTableView1, -1, 411, 32767)
/*  73: 73 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
/*  74: 74 */       .addComponent(jToolBar1, -2, -1, -2)));
/*  75:    */     
/*  76: 76 */     layout.setVerticalGroup(
/*  77: 77 */       layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
/*  78: 78 */       .addGroup(layout.createSequentialGroup()
/*  79: 79 */       .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
/*  80: 80 */       .addComponent(treeTableView1, -1, 186, 32767)
/*  81: 81 */       .addComponent(jToolBar1, -1, -1, 32767))
/*  82: 82 */       .addGap(0, 216, 32767)));
/*  83:    */   }
/*  84:    */   
/*  85:    */   private void editButtonActionPerformed(java.awt.event.ActionEvent evt)
/*  86:    */   {
/*  87: 87 */     em.getSelectedNodes()[0].getPreferredAction().actionPerformed(evt);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public ExplorerManager getExplorerManager()
/*  91:    */   {
/*  92: 92 */     return em;
/*  93:    */   }
/*  94:    */   
/*  95:    */   void load() {
/*  96: 96 */     Iterable<NamedServiceNode> nodes = ec.tss.datatransfer.TssTransferSupport.getDefault().all().transform(Jdk6Functions.namedServiceToNode());
/*  97: 97 */     em.setRootContext(new ec.nbdemetra.ui.nodes.AbstractNodeBuilder().add(nodes).name("Data Transfer handler").build());
/*  98:    */   }
/*  99:    */   
/* 100:    */   void store() {
/* 101:101 */     for (Node o : em.getRootContext().getChildren().getNodes()) {
/* 102:102 */       if ((o instanceof NamedServiceNode)) {
/* 103:103 */         ((NamedServiceNode)o).applyConfig();
/* 104:    */       }
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   boolean valid() {
/* 109:109 */     return true;
/* 110:    */   }
/* 111:    */ }
