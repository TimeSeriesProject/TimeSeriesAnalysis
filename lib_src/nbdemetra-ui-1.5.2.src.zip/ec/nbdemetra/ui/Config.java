/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Objects.ToStringHelper;
/*   5:    */ import com.google.common.base.Strings;
/*   6:    */ import com.google.common.base.Throwables;
/*   7:    */ import com.google.common.collect.ImmutableSortedMap;
/*   8:    */ import ec.tss.tsproviders.utils.AbstractConfigBuilder;
/*   9:    */ import ec.tss.tsproviders.utils.Formatters;
/*  10:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  11:    */ import ec.tss.tsproviders.utils.IConfig;
/*  12:    */ import ec.tss.tsproviders.utils.ParamBean;
/*  13:    */ import ec.tss.tsproviders.utils.Parsers;
/*  14:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  15:    */ import ec.tstoolkit.design.VisibleForTesting;
/*  16:    */ import java.io.Serializable;
/*  17:    */ import java.util.Map;
/*  18:    */ import java.util.Map.Entry;
/*  19:    */ import java.util.SortedMap;
/*  20:    */ import javax.xml.bind.JAXBContext;
/*  21:    */ import javax.xml.bind.JAXBException;
/*  22:    */ import javax.xml.bind.annotation.XmlAttribute;
/*  23:    */ import javax.xml.bind.annotation.XmlElement;
/*  24:    */ import javax.xml.bind.annotation.XmlRootElement;
/*  25:    */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*  26:    */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ @XmlJavaTypeAdapter(XmlAdapter.class)
/*  45:    */ public final class Config
/*  46:    */   implements IConfig, Serializable
/*  47:    */ {
/*  48:    */   private final String domain;
/*  49:    */   private final String name;
/*  50:    */   private final String version;
/*  51:    */   private final ImmutableSortedMap<String, String> params;
/*  52:    */   
/*  53:    */   @VisibleForTesting
/*  54:    */   Config(String domain, String name, String version, ImmutableSortedMap<String, String> params)
/*  55:    */   {
/*  56: 56 */     this.domain = domain;
/*  57: 57 */     this.name = name;
/*  58: 58 */     this.version = version;
/*  59: 59 */     this.params = params;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public String getDomain() {
/*  63: 63 */     return domain;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String getName() {
/*  67: 67 */     return name;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String getVersion() {
/*  71: 71 */     return version;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String get(String key)
/*  75:    */   {
/*  76: 76 */     return (String)params.get(key);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public SortedMap<String, String> getParams()
/*  80:    */   {
/*  81: 81 */     return params;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean equals(Object obj)
/*  85:    */   {
/*  86: 86 */     return (this == obj) || (((obj instanceof Config)) && (equals((Config)obj)));
/*  87:    */   }
/*  88:    */   
/*  89:    */   private boolean equals(Config that) {
/*  90: 90 */     return (domain.equals(domain)) && 
/*  91: 91 */       (name.equals(name)) && 
/*  92: 92 */       (version.equals(version)) && 
/*  93: 93 */       (params.equals(params));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public int hashCode()
/*  97:    */   {
/*  98: 98 */     return java.util.Objects.hash(new Object[] { domain, name, version, params });
/*  99:    */   }
/* 100:    */   
/* 101:    */   public String toString()
/* 102:    */   {
/* 103:103 */     Objects.ToStringHelper helper = com.google.common.base.Objects.toStringHelper(domain + "/" + name + "(" + version + ")");
/* 104:104 */     for (Map.Entry<String, String> o : params.entrySet()) {
/* 105:105 */       helper.add((String)o.getKey(), o.getValue());
/* 106:    */     }
/* 107:107 */     return helper.toString();
/* 108:    */   }
/* 109:    */   
/* 110:    */   @VisibleForTesting
/* 111:    */   ConfigBean toBean() {
/* 112:112 */     ConfigBean bean = new ConfigBean();
/* 113:113 */     domain = domain;
/* 114:114 */     name = name;
/* 115:115 */     version = version;
/* 116:116 */     params = ParamBean.fromSortedMap(params);
/* 117:117 */     return bean;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static Config deepCopyOf(String domain, String name, String version, Map<String, String> params) {
/* 121:121 */     java.util.Objects.requireNonNull(domain, "domain");
/* 122:122 */     java.util.Objects.requireNonNull(name, "name");
/* 123:123 */     java.util.Objects.requireNonNull(params, "params");
/* 124:124 */     return new Config(domain, name, version, ImmutableSortedMap.copyOf(params));
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static Builder builder(String domain, String name, String version) {
/* 128:128 */     java.util.Objects.requireNonNull(domain, "domain");
/* 129:129 */     java.util.Objects.requireNonNull(name, "name");
/* 130:130 */     java.util.Objects.requireNonNull(version, "version");
/* 131:131 */     return new Builder(domain, name, version);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static Builder builder(Config config) {
/* 135:135 */     java.util.Objects.requireNonNull(config, "config");
/* 136:136 */     return (Builder)new Builder(config.getDomain(), config.getName(), config.getVersion()).putAll(config.getParams());
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */   public static Formatters.Formatter<Config> xmlFormatter(boolean formattedOutput)
/* 150:    */   {
/* 151:151 */     return formattedOutput ? XMLget()formattedOutputFormatter : XMLget()defaultFormatter;
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */   public static Parsers.Parser<Config> xmlParser()
/* 164:    */   {
/* 165:165 */     return XMLget()defaultParser;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static class Builder extends AbstractConfigBuilder<Builder, Config>
/* 169:    */   {
/* 170:    */     final String service;
/* 171:    */     final String name;
/* 172:    */     final String version;
/* 173:    */     
/* 174:    */     @VisibleForTesting
/* 175:    */     Builder(String service, String name, String version) {
/* 176:176 */       this.service = service;
/* 177:177 */       this.name = name;
/* 178:178 */       this.version = version;
/* 179:    */     }
/* 180:    */     
/* 181:    */     public Config build()
/* 182:    */     {
/* 183:183 */       return Config.deepCopyOf(service, name, version, params);
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static class XmlAdapter extends XmlAdapter<Config.ConfigBean, Config>
/* 188:    */   {
/* 189:    */     public Config unmarshal(Config.ConfigBean v) throws Exception
/* 190:    */     {
/* 191:191 */       return v.toId();
/* 192:    */     }
/* 193:    */     
/* 194:    */     public Config.ConfigBean marshal(Config v) throws Exception
/* 195:    */     {
/* 196:196 */       return v.toBean();
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   @XmlRootElement(name="config")
/* 201:    */   public static class ConfigBean
/* 202:    */   {
/* 203:    */     @XmlAttribute(name="domain")
/* 204:    */     public String domain;
/* 205:    */     @XmlAttribute(name="name")
/* 206:    */     public String name;
/* 207:    */     @XmlAttribute(name="version")
/* 208:    */     public String version;
/* 209:    */     @XmlElement(name="param")
/* 210:    */     public ParamBean[] params;
/* 211:    */     
/* 212:    */     Config toId() {
/* 213:213 */       return new Config(
/* 214:214 */         Strings.nullToEmpty(domain), 
/* 215:215 */         Strings.nullToEmpty(name), 
/* 216:216 */         Strings.nullToEmpty(version), 
/* 217:217 */         ParamBean.toSortedMap(params));
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */ 
/* 222:222 */   private static final ThreadLocal<Xml> XML = new ThreadLocal()
/* 223:    */   {
/* 224:    */     protected Config.Xml initialValue() {
/* 225:225 */       return new Config.Xml(null);
/* 226:    */     }
/* 227:    */   };
/* 228:    */   
/* 229:    */   private static final class Xml
/* 230:    */   {
/* 231:    */     static final JAXBContext BEAN_CONTEXT;
/* 232:    */     
/* 233:    */     static {
/* 234:    */       try {
/* 235:235 */         BEAN_CONTEXT = JAXBContext.newInstance(new Class[] { Config.ConfigBean.class });
/* 236:    */       } catch (JAXBException ex) {
/* 237:237 */         throw Throwables.propagate(ex);
/* 238:    */       } }
/* 239:    */     
/* 240:240 */     static final Function<Config.ConfigBean, Config> FROM_BEAN = new Function()
/* 241:    */     {
/* 242:    */       public Config apply(Config.ConfigBean input) {
/* 243:243 */         return input.toId();
/* 244:    */       }
/* 245:    */     };
/* 246:246 */     static final Function<Config, Config.ConfigBean> TO_BEAN = new Function()
/* 247:    */     {
/* 248:    */       public Config.ConfigBean apply(Config input) {
/* 249:249 */         return input.toBean();
/* 250:    */       }
/* 251:    */     };
/* 252:    */     
/* 253:253 */     final Parsers.Parser<Config> defaultParser = Parsers.onJAXB(BEAN_CONTEXT).compose(FROM_BEAN);
/* 254:254 */     final Formatters.Formatter<Config> defaultFormatter = Formatters.onJAXB(BEAN_CONTEXT, false).compose(TO_BEAN);
/* 255:255 */     final Formatters.Formatter<Config> formattedOutputFormatter = Formatters.onJAXB(BEAN_CONTEXT, true).compose(TO_BEAN);
/* 256:    */   }
/* 257:    */ }
