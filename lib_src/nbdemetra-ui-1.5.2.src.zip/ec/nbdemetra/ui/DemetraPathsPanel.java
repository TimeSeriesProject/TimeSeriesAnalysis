/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.nodes.AbstractNodeBuilder;
/*   4:    */ import ec.nbdemetra.ui.tsproviders.DataSourceProviderBuddySupport;
/*   5:    */ import ec.tss.tsproviders.IFileLoader;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.io.File;
/*  10:    */ import javax.swing.GroupLayout;
/*  11:    */ import javax.swing.GroupLayout.Alignment;
/*  12:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  13:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  14:    */ import javax.swing.ImageIcon;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JToolBar;
/*  17:    */ import org.openide.awt.Mnemonics;
/*  18:    */ import org.openide.explorer.ExplorerManager;
/*  19:    */ import org.openide.explorer.view.TreeTableView;
/*  20:    */ import org.openide.filesystems.FileChooserBuilder;
/*  21:    */ import org.openide.nodes.AbstractNode;
/*  22:    */ import org.openide.nodes.Children;
/*  23:    */ import org.openide.nodes.Index.ArrayChildren;
/*  24:    */ import org.openide.nodes.Node;
/*  25:    */ import org.openide.util.Lookup;
/*  26:    */ 
/*  27:    */ final class DemetraPathsPanel extends javax.swing.JPanel implements org.openide.explorer.ExplorerManager.Provider
/*  28:    */ {
/*  29:    */   final DemetraPathsOptionsPanelController controller;
/*  30:    */   final ExplorerManager em;
/*  31:    */   final FileChooserBuilder folderChooserBuilder;
/*  32:    */   private JButton addButton;
/*  33:    */   private JToolBar jToolBar1;
/*  34:    */   private JButton moveDownButton;
/*  35:    */   private JButton moveUpButton;
/*  36:    */   private TreeTableView pathView;
/*  37:    */   private JButton removeButton;
/*  38:    */   
/*  39:    */   DemetraPathsPanel(DemetraPathsOptionsPanelController controller)
/*  40:    */   {
/*  41: 41 */     this.controller = controller;
/*  42: 42 */     em = new ExplorerManager();
/*  43: 43 */     folderChooserBuilder = new FileChooserBuilder(DemetraPathsPanel.class);
/*  44:    */     
/*  45: 45 */     initComponents();
/*  46:    */     
/*  47: 47 */     em.addVetoableChangeListener(new java.beans.VetoableChangeListener()
/*  48:    */     {
/*  49:    */       public void vetoableChange(PropertyChangeEvent evt) throws java.beans.PropertyVetoException {
/*  50: 50 */         if ("selectedNodes".equals(evt.getPropertyName())) {
/*  51: 51 */           Node[] nodes = (Node[])evt.getNewValue();
/*  52: 52 */           boolean empty = nodes.length == 0;
/*  53: 53 */           boolean loader = (!empty) && (nodes[0].getLookup().lookup(IFileLoader.class) != null);
/*  54: 54 */           boolean file = (!empty) && (nodes[0].getLookup().lookup(File.class) != null);
/*  55: 55 */           int index = !empty ? ((Index.ArrayChildren)nodes[0].getParentNode().getChildren()).indexOf(nodes[0]) : -1;
/*  56: 56 */           addButton.setEnabled(loader);
/*  57: 57 */           removeButton.setEnabled((file) && (index != -1));
/*  58: 58 */           moveUpButton.setEnabled((file) && (index > 0));
/*  59: 59 */           moveDownButton.setEnabled((file) && (index < nodes[0].getParentNode().getChildren().getNodesCount() - 1));
/*  60:    */         }
/*  61:    */       }
/*  62: 62 */     });
/*  63: 63 */     folderChooserBuilder.setDirectoriesOnly(true);
/*  64: 64 */     pathView.setRootVisible(false);
/*  65: 65 */     pathView.setSelectionMode(1);
/*  66:    */   }
/*  67:    */   
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */   private void initComponents()
/*  75:    */   {
/*  76: 76 */     jToolBar1 = new JToolBar();
/*  77: 77 */     addButton = new JButton();
/*  78: 78 */     removeButton = new JButton();
/*  79: 79 */     moveUpButton = new JButton();
/*  80: 80 */     moveDownButton = new JButton();
/*  81: 81 */     pathView = new TreeTableView();
/*  82:    */     
/*  83: 83 */     jToolBar1.setFloatable(false);
/*  84: 84 */     jToolBar1.setOrientation(1);
/*  85: 85 */     jToolBar1.setRollover(true);
/*  86:    */     
/*  87: 87 */     addButton.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/list-add_16x16.png")));
/*  88: 88 */     Mnemonics.setLocalizedText(addButton, org.openide.util.NbBundle.getMessage(DemetraPathsPanel.class, "DemetraPathsPanel.addButton.text"));
/*  89: 89 */     addButton.setEnabled(false);
/*  90: 90 */     addButton.setFocusable(false);
/*  91: 91 */     addButton.setHorizontalTextPosition(0);
/*  92: 92 */     addButton.setVerticalTextPosition(3);
/*  93: 93 */     addButton.addActionListener(new ActionListener() {
/*  94:    */       public void actionPerformed(ActionEvent evt) {
/*  95: 95 */         DemetraPathsPanel.this.addButtonActionPerformed(evt);
/*  96:    */       }
/*  97: 97 */     });
/*  98: 98 */     jToolBar1.add(addButton);
/*  99:    */     
/* 100:100 */     removeButton.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/list-remove_16x16.png")));
/* 101:101 */     Mnemonics.setLocalizedText(removeButton, org.openide.util.NbBundle.getMessage(DemetraPathsPanel.class, "DemetraPathsPanel.removeButton.text"));
/* 102:102 */     removeButton.setEnabled(false);
/* 103:103 */     removeButton.setFocusable(false);
/* 104:104 */     removeButton.setHorizontalTextPosition(0);
/* 105:105 */     removeButton.setVerticalTextPosition(3);
/* 106:106 */     removeButton.addActionListener(new ActionListener() {
/* 107:    */       public void actionPerformed(ActionEvent evt) {
/* 108:108 */         DemetraPathsPanel.this.removeButtonActionPerformed(evt);
/* 109:    */       }
/* 110:110 */     });
/* 111:111 */     jToolBar1.add(removeButton);
/* 112:    */     
/* 113:113 */     moveUpButton.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/go-up_16x16.png")));
/* 114:114 */     Mnemonics.setLocalizedText(moveUpButton, org.openide.util.NbBundle.getMessage(DemetraPathsPanel.class, "DemetraPathsPanel.moveUpButton.text"));
/* 115:115 */     moveUpButton.setEnabled(false);
/* 116:116 */     moveUpButton.setFocusable(false);
/* 117:117 */     moveUpButton.setHorizontalTextPosition(0);
/* 118:118 */     moveUpButton.setVerticalTextPosition(3);
/* 119:119 */     moveUpButton.addActionListener(new ActionListener() {
/* 120:    */       public void actionPerformed(ActionEvent evt) {
/* 121:121 */         DemetraPathsPanel.this.moveUpButtonActionPerformed(evt);
/* 122:    */       }
/* 123:123 */     });
/* 124:124 */     jToolBar1.add(moveUpButton);
/* 125:    */     
/* 126:126 */     moveDownButton.setIcon(new ImageIcon(getClass().getResource("/ec/nbdemetra/ui/go-down_16x16.png")));
/* 127:127 */     Mnemonics.setLocalizedText(moveDownButton, org.openide.util.NbBundle.getMessage(DemetraPathsPanel.class, "DemetraPathsPanel.moveDownButton.text"));
/* 128:128 */     moveDownButton.setEnabled(false);
/* 129:129 */     moveDownButton.setFocusable(false);
/* 130:130 */     moveDownButton.setHorizontalTextPosition(0);
/* 131:131 */     moveDownButton.setVerticalTextPosition(3);
/* 132:132 */     moveDownButton.addActionListener(new ActionListener() {
/* 133:    */       public void actionPerformed(ActionEvent evt) {
/* 134:134 */         DemetraPathsPanel.this.moveDownButtonActionPerformed(evt);
/* 135:    */       }
/* 136:136 */     });
/* 137:137 */     jToolBar1.add(moveDownButton);
/* 138:    */     
/* 139:139 */     GroupLayout layout = new GroupLayout(this);
/* 140:140 */     setLayout(layout);
/* 141:141 */     layout.setHorizontalGroup(
/* 142:142 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 143:143 */       .addGroup(layout.createSequentialGroup()
/* 144:144 */       .addComponent(pathView, -1, 426, 32767)
/* 145:145 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
/* 146:146 */       .addComponent(jToolBar1, -2, -1, -2)));
/* 147:    */     
/* 148:148 */     layout.setVerticalGroup(
/* 149:149 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 150:150 */       .addGroup(layout.createSequentialGroup()
/* 151:151 */       .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 152:152 */       .addComponent(jToolBar1, GroupLayout.Alignment.LEADING, -1, 266, 32767)
/* 153:153 */       .addComponent(pathView, GroupLayout.Alignment.LEADING, -2, 0, 32767))
/* 154:154 */       .addGap(0, 11, 32767)));
/* 155:    */   }
/* 156:    */   
/* 157:    */   private void addButtonActionPerformed(ActionEvent evt)
/* 158:    */   {
/* 159:159 */     File folder = folderChooserBuilder.showOpenDialog();
/* 160:160 */     if (folder != null) {
/* 161:161 */       em.getSelectedNodes()[0].getChildren().add(new Node[] { new PathNode(folder) });
/* 162:    */     }
/* 163:    */   }
/* 164:    */   
/* 165:    */   private void removeButtonActionPerformed(ActionEvent evt) {
/* 166:166 */     Node[] nodes = em.getSelectedNodes();
/* 167:167 */     nodes[0].getParentNode().getChildren().remove(nodes);
/* 168:    */   }
/* 169:    */   
/* 170:    */   private void moveUpButtonActionPerformed(ActionEvent evt) {
/* 171:171 */     Node node = em.getSelectedNodes()[0];
/* 172:172 */     Index.ArrayChildren children = (Index.ArrayChildren)node.getParentNode().getChildren();
/* 173:173 */     children.moveUp(children.indexOf(node));
/* 174:    */   }
/* 175:    */   
/* 176:    */   private void moveDownButtonActionPerformed(ActionEvent evt) {
/* 177:177 */     Node node = em.getSelectedNodes()[0];
/* 178:178 */     Index.ArrayChildren children = (Index.ArrayChildren)node.getParentNode().getChildren();
/* 179:179 */     children.moveDown(children.indexOf(node));
/* 180:    */   }
/* 181:    */   
/* 182:    */   public ExplorerManager getExplorerManager() {
/* 183:183 */     return em;
/* 184:    */   }
/* 185:    */   
/* 186:    */   static class FileLoaderNode extends AbstractNode
/* 187:    */   {
/* 188:    */     public FileLoaderNode(Children children, IFileLoader loader) {
/* 189:189 */       super(org.openide.util.lookup.Lookups.singleton(loader));
/* 190:190 */       setName(loader.getSource());
/* 191:191 */       setDisplayName(loader.getDisplayName());
/* 192:    */     }
/* 193:    */     
/* 194:    */     public java.awt.Image getIcon(int type)
/* 195:    */     {
/* 196:196 */       IFileLoader loader = (IFileLoader)getLookup().lookup(IFileLoader.class);
/* 197:197 */       return DataSourceProviderBuddySupport.getDefault().get(loader).getIcon(type, false);
/* 198:    */     }
/* 199:    */     
/* 200:    */     public java.awt.Image getOpenedIcon(int type)
/* 201:    */     {
/* 202:202 */       IFileLoader loader = (IFileLoader)getLookup().lookup(IFileLoader.class);
/* 203:203 */       return DataSourceProviderBuddySupport.getDefault().get(loader).getIcon(type, true);
/* 204:    */     }
/* 205:    */   }
/* 206:    */   
/* 207:    */   static class PathNode extends AbstractNode
/* 208:    */   {
/* 209:209 */     static final javax.swing.JFileChooser FILE_CHOOSER = new javax.swing.JFileChooser();
/* 210:    */     
/* 211:    */     public PathNode(File file) {
/* 212:212 */       super(org.openide.util.lookup.Lookups.singleton(file));
/* 213:213 */       setName(file.getPath());
/* 214:    */     }
/* 215:    */     
/* 216:    */     public String getHtmlDisplayName()
/* 217:    */     {
/* 218:218 */       File file = (File)getLookup().lookup(File.class);
/* 219:219 */       return "<i>" + file.toString() + "</i>";
/* 220:    */     }
/* 221:    */     
/* 222:    */     public java.awt.Image getIcon(int type)
/* 223:    */     {
/* 224:224 */       return org.openide.util.ImageUtilities.icon2Image(FILE_CHOOSER.getIcon((File)getLookup().lookup(File.class)));
/* 225:    */     }
/* 226:    */     
/* 227:    */     public javax.swing.Action getPreferredAction()
/* 228:    */     {
/* 229:229 */       return getActions(true)[0];
/* 230:    */     }
/* 231:    */     
/* 232:    */     public javax.swing.Action[] getActions(boolean context)
/* 233:    */     {
/* 234:234 */       return new javax.swing.Action[] { new ShowInFolderAction("Show in folder") };
/* 235:    */     }
/* 236:    */     
/* 237:    */     class ShowInFolderAction extends javax.swing.AbstractAction
/* 238:    */     {
/* 239:    */       public ShowInFolderAction(String name) {
/* 240:240 */         super();
/* 241:    */       }
/* 242:    */       
/* 243:    */       public void actionPerformed(ActionEvent e)
/* 244:    */       {
/* 245:    */         try {
/* 246:246 */           ec.util.desktop.DesktopManager.get().showInFolder((File)getLookup().lookup(File.class));
/* 247:    */         } catch (java.io.IOException ex) {
/* 248:248 */           org.openide.util.Exceptions.printStackTrace(ex);
/* 249:    */         }
/* 250:    */       }
/* 251:    */     }
/* 252:    */   }
/* 253:    */   
/* 254:    */   static Index.ArrayChildren newArray(Node[] nodes) {
/* 255:255 */     Index.ArrayChildren result = new Index.ArrayChildren();
/* 256:256 */     result.add(nodes);
/* 257:257 */     return result;
/* 258:    */   }
/* 259:    */   
/* 260:    */   void load() {
/* 261:261 */     java.util.List<IFileLoader> loaders = ec.tss.tsproviders.TsProviders.all().filter(IFileLoader.class).toList();
/* 262:262 */     Node[] fileLoaderNodes = new Node[loaders.size()];
/* 263:263 */     for (int i = 0; i < fileLoaderNodes.length; i++) {
/* 264:264 */       IFileLoader loader = (IFileLoader)loaders.get(i);
/* 265:265 */       File[] paths = loader.getPaths();
/* 266:266 */       Node[] pathNodes = new Node[paths.length];
/* 267:267 */       for (int j = 0; j < pathNodes.length; j++) {
/* 268:268 */         pathNodes[j] = new PathNode(paths[j]);
/* 269:    */       }
/* 270:270 */       fileLoaderNodes[i] = new FileLoaderNode(newArray(pathNodes), loader);
/* 271:    */     }
/* 272:    */     
/* 273:273 */     em.setRootContext(new AbstractNodeBuilder().add(fileLoaderNodes).name("File Loader").build());
/* 274:274 */     pathView.expandAll();
/* 275:    */   }
/* 276:    */   
/* 277:    */   void store() {
/* 278:278 */     Node root = em.getRootContext();
/* 279:279 */     for (Node o : root.getChildren().getNodes()) {
/* 280:280 */       Node[] pathNodes = o.getChildren().getNodes();
/* 281:281 */       File[] paths = new File[pathNodes.length];
/* 282:282 */       for (int i = 0; i < paths.length; i++) {
/* 283:283 */         paths[i] = ((File)pathNodes[i].getLookup().lookup(File.class));
/* 284:    */       }
/* 285:285 */       ((IFileLoader)o.getLookup().lookup(IFileLoader.class)).setPaths(paths);
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   boolean valid() {
/* 290:290 */     return true;
/* 291:    */   }
/* 292:    */ }
