/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import java.beans.PropertyChangeListener;
/*   4:    */ import java.beans.PropertyChangeSupport;
/*   5:    */ import javax.swing.JComponent;
/*   6:    */ import org.netbeans.spi.options.OptionsPanelController;
/*   7:    */ import org.openide.util.HelpCtx;
/*   8:    */ import org.openide.util.Lookup;
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public final class DemetraStatsOptionsPanelController
/*  37:    */   extends OptionsPanelController
/*  38:    */ {
/*  39:    */   public static final String ID = "Demetra/DemetraStats";
/*  40:    */   private DemetraStatsPanel panel;
/*  41: 41 */   private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
/*  42:    */   private boolean changed;
/*  43:    */   
/*  44:    */   public void update()
/*  45:    */   {
/*  46: 46 */     getPanel().load();
/*  47: 47 */     changed = false;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void applyChanges()
/*  51:    */   {
/*  52: 52 */     getPanel().store();
/*  53: 53 */     changed = false;
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */   public void cancel() {}
/*  59:    */   
/*  60:    */ 
/*  61:    */   public boolean isValid()
/*  62:    */   {
/*  63: 63 */     return getPanel().valid();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean isChanged()
/*  67:    */   {
/*  68: 68 */     return changed;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public JComponent getComponent(Lookup lkp)
/*  72:    */   {
/*  73: 73 */     return getPanel();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public HelpCtx getHelpCtx()
/*  77:    */   {
/*  78: 78 */     return null;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void addPropertyChangeListener(PropertyChangeListener l)
/*  82:    */   {
/*  83: 83 */     pcs.addPropertyChangeListener(l);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void removePropertyChangeListener(PropertyChangeListener l)
/*  87:    */   {
/*  88: 88 */     pcs.removePropertyChangeListener(l);
/*  89:    */   }
/*  90:    */   
/*  91:    */   private DemetraStatsPanel getPanel() {
/*  92: 92 */     if (panel == null) {
/*  93: 93 */       panel = new DemetraStatsPanel(this);
/*  94:    */     }
/*  95: 95 */     return panel;
/*  96:    */   }
/*  97:    */   
/*  98:    */   void changed() {
/*  99: 99 */     if (!changed) {
/* 100:100 */       changed = true;
/* 101:101 */       pcs.firePropertyChange("changed", false, true);
/* 102:    */     }
/* 103:103 */     pcs.firePropertyChange("valid", null, null);
/* 104:    */   }
/* 105:    */ }
