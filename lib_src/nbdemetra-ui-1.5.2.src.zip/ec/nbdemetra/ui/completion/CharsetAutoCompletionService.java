/*  1:   */ package ec.nbdemetra.ui.completion;
/*  2:   */ 
/*  3:   */ import ec.util.completion.AbstractAutoCompletionSource.TermMatcher;
/*  4:   */ import ec.util.completion.AutoCompletionSource;
/*  5:   */ import ec.util.completion.ext.QuickAutoCompletionSource;
/*  6:   */ import ec.util.completion.swing.CustomListCellRenderer;
/*  7:   */ import ec.util.completion.swing.JAutoCompletion;
/*  8:   */ import java.nio.charset.Charset;
/*  9:   */ import java.util.Collection;
/* 10:   */ import java.util.SortedMap;
/* 11:   */ import javax.swing.JList;
/* 12:   */ import javax.swing.ListCellRenderer;
/* 13:   */ import javax.swing.text.JTextComponent;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ public class CharsetAutoCompletionService
/* 35:   */   extends JAutoCompletionService
/* 36:   */ {
/* 37:37 */   private final AutoCompletionSource source = new LocaleSource(null);
/* 38:38 */   private final ListCellRenderer renderer = new LocaleRenderer(null);
/* 39:   */   
/* 40:   */   public JAutoCompletion bind(JTextComponent textComponent)
/* 41:   */   {
/* 42:42 */     JAutoCompletion result = new JAutoCompletion(textComponent);
/* 43:43 */     result.setMinLength(0);
/* 44:44 */     result.setSource(source);
/* 45:45 */     result.getList().setCellRenderer(renderer);
/* 46:46 */     return result;
/* 47:   */   }
/* 48:   */   
/* 49:   */   private static class LocaleSource
/* 50:   */     extends QuickAutoCompletionSource<Charset>
/* 51:   */   {
/* 52:52 */     final Collection<Charset> charsets = Charset.availableCharsets().values();
/* 53:   */     
/* 54:   */     protected Iterable<Charset> getAllValues() throws Exception
/* 55:   */     {
/* 56:56 */       return charsets;
/* 57:   */     }
/* 58:   */     
/* 59:   */     protected boolean matches(AbstractAutoCompletionSource.TermMatcher termMatcher, Charset input)
/* 60:   */     {
/* 61:61 */       return termMatcher.matches(input.name());
/* 62:   */     }
/* 63:   */   }
/* 64:   */   
/* 65:   */   private static class LocaleRenderer extends CustomListCellRenderer<Charset>
/* 66:   */   {
/* 67:   */     protected String getValueAsString(Charset value)
/* 68:   */     {
/* 69:69 */       return value.name();
/* 70:   */     }
/* 71:   */   }
/* 72:   */ }
