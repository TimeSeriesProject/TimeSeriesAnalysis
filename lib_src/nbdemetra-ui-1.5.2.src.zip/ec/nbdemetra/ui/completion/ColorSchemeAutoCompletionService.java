/*  1:   */ package ec.nbdemetra.ui.completion;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.DemetraUI;
/*  4:   */ import ec.util.chart.ColorScheme;
/*  5:   */ import ec.util.chart.swing.ColorSchemeIcon;
/*  6:   */ import ec.util.completion.AbstractAutoCompletionSource.TermMatcher;
/*  7:   */ import ec.util.completion.AutoCompletionSource;
/*  8:   */ import ec.util.completion.ext.QuickAutoCompletionSource;
/*  9:   */ import ec.util.completion.swing.CustomListCellRenderer;
/* 10:   */ import ec.util.completion.swing.JAutoCompletion;
/* 11:   */ import javax.swing.Icon;
/* 12:   */ import javax.swing.JList;
/* 13:   */ import javax.swing.ListCellRenderer;
/* 14:   */ import javax.swing.text.JTextComponent;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ public class ColorSchemeAutoCompletionService
/* 38:   */   extends JAutoCompletionService
/* 39:   */ {
/* 40:40 */   private final AutoCompletionSource source = new ColorSchemeSource(null);
/* 41:41 */   private final ListCellRenderer renderer = new ColorSchemeRenderer(null);
/* 42:   */   
/* 43:   */   public JAutoCompletion bind(JTextComponent textComponent)
/* 44:   */   {
/* 45:45 */     JAutoCompletion result = new JAutoCompletion(textComponent);
/* 46:46 */     result.setMinLength(0);
/* 47:47 */     result.setSeparator(" ");
/* 48:48 */     result.setSource(source);
/* 49:49 */     result.getList().setCellRenderer(renderer);
/* 50:50 */     return result;
/* 51:   */   }
/* 52:   */   
/* 53:   */   private static class ColorSchemeSource extends QuickAutoCompletionSource<ColorScheme>
/* 54:   */   {
/* 55:   */     protected Iterable<ColorScheme> getAllValues() throws Exception
/* 56:   */     {
/* 57:57 */       return DemetraUI.getDefault().getColorSchemes();
/* 58:   */     }
/* 59:   */     
/* 60:   */     protected String getValueAsString(ColorScheme value)
/* 61:   */     {
/* 62:62 */       return value.getName();
/* 63:   */     }
/* 64:   */     
/* 65:   */     protected boolean matches(AbstractAutoCompletionSource.TermMatcher termMatcher, ColorScheme input)
/* 66:   */     {
/* 67:67 */       return (termMatcher.matches(input.getName())) || (termMatcher.matches(input.getDisplayName()));
/* 68:   */     }
/* 69:   */   }
/* 70:   */   
/* 71:   */   private static class ColorSchemeRenderer extends CustomListCellRenderer<ColorScheme>
/* 72:   */   {
/* 73:   */     protected String getValueAsString(ColorScheme value)
/* 74:   */     {
/* 75:75 */       return value.getDisplayName();
/* 76:   */     }
/* 77:   */     
/* 78:   */     protected Icon toIcon(String term, JList list, ColorScheme value, int index, boolean isSelected, boolean cellHasFocus)
/* 79:   */     {
/* 80:80 */       return new ColorSchemeIcon(value);
/* 81:   */     }
/* 82:   */   }
/* 83:   */ }
