/*  1:   */ package ec.nbdemetra.ui.completion;
/*  2:   */ 
/*  3:   */ import ec.util.completion.swing.JAutoCompletion;
/*  4:   */ import javax.annotation.Nonnull;
/*  5:   */ import javax.swing.text.JTextComponent;
/*  6:   */ import org.openide.util.Lookup;
/*  7:   */ import org.openide.util.lookup.Lookups;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ public abstract class JAutoCompletionService
/* 31:   */ {
/* 32:   */   public static final String LOCALE_PATH = "JAutoCompletionService/Locale";
/* 33:   */   public static final String DATE_PATTERN_PATH = "JAutoCompletionService/DatePattern";
/* 34:   */   public static final String COLOR_SCHEME_PATH = "JAutoCompletionService/ColorScheme";
/* 35:   */   public static final String CHARSET_PATH = "JAutoCompletionService/Charset";
/* 36:   */   
/* 37:   */   @Nonnull
/* 38:   */   public abstract JAutoCompletion bind(@Nonnull JTextComponent paramJTextComponent);
/* 39:   */   
/* 40:   */   @Nonnull
/* 41:   */   public static JAutoCompletion forPathBind(@Nonnull String path, @Nonnull JTextComponent textComponent)
/* 42:   */   {
/* 43:43 */     JAutoCompletionService o = (JAutoCompletionService)Lookups.forPath(path).lookup(JAutoCompletionService.class);
/* 44:44 */     return o != null ? o.bind(textComponent) : new JAutoCompletion(textComponent);
/* 45:   */   }
/* 46:   */ }
