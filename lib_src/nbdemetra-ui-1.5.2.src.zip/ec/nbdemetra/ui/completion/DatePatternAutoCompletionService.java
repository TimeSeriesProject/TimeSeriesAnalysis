/*   1:    */ package ec.nbdemetra.ui.completion;
/*   2:    */ 
/*   3:    */ import ec.util.completion.AbstractAutoCompletionSource.TermMatcher;
/*   4:    */ import ec.util.completion.AutoCompletionSource;
/*   5:    */ import ec.util.completion.ext.QuickAutoCompletionSource;
/*   6:    */ import ec.util.completion.swing.CustomListCellRenderer;
/*   7:    */ import ec.util.completion.swing.JAutoCompletion;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.List;
/*  10:    */ import javax.swing.JList;
/*  11:    */ import javax.swing.ListCellRenderer;
/*  12:    */ import javax.swing.text.JTextComponent;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ public class DatePatternAutoCompletionService
/*  36:    */   extends JAutoCompletionService
/*  37:    */ {
/*  38: 38 */   private final AutoCompletionSource source = new DatePatternLetterSource(null);
/*  39: 39 */   private final ListCellRenderer renderer = new DatePatternLetterRenderer(null);
/*  40:    */   
/*  41:    */   public JAutoCompletion bind(JTextComponent textComponent)
/*  42:    */   {
/*  43: 43 */     JAutoCompletion result = new JAutoCompletion(textComponent);
/*  44: 44 */     result.setMinLength(0);
/*  45: 45 */     result.setSeparator(" ");
/*  46: 46 */     result.setSource(source);
/*  47: 47 */     result.getList().setCellRenderer(renderer);
/*  48: 48 */     return result;
/*  49:    */   }
/*  50:    */   
/*  51:    */ 
/*  52:    */   private static enum DatePatternLetter
/*  53:    */   {
/*  54: 54 */     G("Era designator", DatePatternAutoCompletionService.DatePatternPresentation.TEXT), 
/*  55: 55 */     y("Year", DatePatternAutoCompletionService.DatePatternPresentation.YEAR), 
/*  56: 56 */     M("Month in year", DatePatternAutoCompletionService.DatePatternPresentation.MONTH), 
/*  57: 57 */     w("Week in year", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  58: 58 */     W("Week in month", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  59: 59 */     D("Day in year", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  60: 60 */     d("Day in month", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  61: 61 */     F("Day of week in month", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  62: 62 */     E("Day in week", DatePatternAutoCompletionService.DatePatternPresentation.TEXT), 
/*  63: 63 */     a("Am/pm marker", DatePatternAutoCompletionService.DatePatternPresentation.TEXT), 
/*  64: 64 */     H("Hour in day (0-23)", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  65: 65 */     k("Hour in day (1-24)", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  66: 66 */     K("Hour in am/pm (0-11)", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  67: 67 */     h("Hour in am/pm (1-12)", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  68: 68 */     m("Minute in hour", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  69: 69 */     s("Second in minute", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  70: 70 */     S("Millisecond", DatePatternAutoCompletionService.DatePatternPresentation.NUMBER), 
/*  71: 71 */     z("Time zone", DatePatternAutoCompletionService.DatePatternPresentation.OTHER), 
/*  72: 72 */     Z("Time zone", DatePatternAutoCompletionService.DatePatternPresentation.OTHER);
/*  73:    */     
/*  74:    */     final String dateComponent;
/*  75:    */     final DatePatternAutoCompletionService.DatePatternPresentation presentation;
/*  76:    */     
/*  77:    */     private DatePatternLetter(String dateComponent, DatePatternAutoCompletionService.DatePatternPresentation presentation) {
/*  78: 78 */       this.dateComponent = dateComponent;
/*  79: 79 */       this.presentation = presentation;
/*  80:    */     }
/*  81:    */     
/*  82:    */     public String toString()
/*  83:    */     {
/*  84: 84 */       return name();
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static enum DatePatternPresentation
/*  89:    */   {
/*  90: 90 */     TEXT("<html>For <b>formatting</b>, if the number of pattern letters is 4 or more, the full form is used; otherwise a short or abbreviated form is used if available.<br>For <b>parsing</b>, both forms are accepted, independent of the number of pattern letters."), 
/*  91: 91 */     YEAR("<html>For <b>formatting</b>, if the number of pattern letters is 2, the year is truncated to 2 digits; otherwise it is interpreted as a <b>number</b>.<br>For <b>parsing</b>, if the number of pattern letters is more than 2, the year is interpreted literally, regardless of the number of digits."), 
/*  92: 92 */     MONTH("<html>If the number of pattern letters is 3 or more, the month is interpreted as <b>text</b>; otherwise, it is interpreted as a <b>number</b>."), 
/*  93: 93 */     NUMBER("<html>For <b>formatting</b>, the number of pattern letters is the minimum number of digits, and shorter numbers are zero-padded to this amount.<br>For <b>parsing</b>, the number of pattern letters is ignored unless it's needed to separate two adjacent fields."), 
/*  94: 94 */     OTHER("");
/*  95:    */     
/*  96:    */     final String description;
/*  97:    */     
/*  98: 98 */     private DatePatternPresentation(String description) { this.description = description; }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static class DatePatternLetterSource
/* 102:    */     extends QuickAutoCompletionSource<DatePatternAutoCompletionService.DatePatternLetter>
/* 103:    */   {
/* 104:104 */     final List<DatePatternAutoCompletionService.DatePatternLetter> locales = Arrays.asList(DatePatternAutoCompletionService.DatePatternLetter.values());
/* 105:    */     
/* 106:    */     protected Iterable<DatePatternAutoCompletionService.DatePatternLetter> getAllValues() throws Exception
/* 107:    */     {
/* 108:108 */       return locales;
/* 109:    */     }
/* 110:    */     
/* 111:    */     protected boolean matches(AbstractAutoCompletionSource.TermMatcher termMatcher, DatePatternAutoCompletionService.DatePatternLetter input)
/* 112:    */     {
/* 113:113 */       return (termMatcher.matches(input.name())) || (termMatcher.matches(dateComponent));
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static class DatePatternLetterRenderer extends CustomListCellRenderer<DatePatternAutoCompletionService.DatePatternLetter>
/* 118:    */   {
/* 119:    */     protected String getValueAsString(DatePatternAutoCompletionService.DatePatternLetter value)
/* 120:    */     {
/* 121:121 */       return "(" + String.valueOf(value.name()) + ") " + dateComponent;
/* 122:    */     }
/* 123:    */     
/* 124:    */     protected String toToolTipText(String term, JList list, DatePatternAutoCompletionService.DatePatternLetter value, int index, boolean isSelected, boolean cellHasFocus)
/* 125:    */     {
/* 126:126 */       return presentation.description;
/* 127:    */     }
/* 128:    */   }
/* 129:    */ }
