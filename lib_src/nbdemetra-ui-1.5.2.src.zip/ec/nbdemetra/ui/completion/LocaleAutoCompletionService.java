/*  1:   */ package ec.nbdemetra.ui.completion;
/*  2:   */ 
/*  3:   */ import ec.util.completion.AbstractAutoCompletionSource.TermMatcher;
/*  4:   */ import ec.util.completion.AutoCompletionSource;
/*  5:   */ import ec.util.completion.ext.QuickAutoCompletionSource;
/*  6:   */ import ec.util.completion.swing.CustomListCellRenderer;
/*  7:   */ import ec.util.completion.swing.JAutoCompletion;
/*  8:   */ import java.util.Arrays;
/*  9:   */ import java.util.List;
/* 10:   */ import java.util.Locale;
/* 11:   */ import javax.swing.JList;
/* 12:   */ import javax.swing.ListCellRenderer;
/* 13:   */ import javax.swing.text.JTextComponent;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public class LocaleAutoCompletionService
/* 36:   */   extends JAutoCompletionService
/* 37:   */ {
/* 38:38 */   private final AutoCompletionSource source = new LocaleSource(null);
/* 39:39 */   private final ListCellRenderer renderer = new LocaleRenderer(null);
/* 40:   */   
/* 41:   */   public JAutoCompletion bind(JTextComponent textComponent)
/* 42:   */   {
/* 43:43 */     JAutoCompletion result = new JAutoCompletion(textComponent);
/* 44:44 */     result.setMinLength(0);
/* 45:45 */     result.setSource(source);
/* 46:46 */     result.getList().setCellRenderer(renderer);
/* 47:47 */     return result;
/* 48:   */   }
/* 49:   */   
/* 50:   */   private static class LocaleSource extends QuickAutoCompletionSource<Locale>
/* 51:   */   {
/* 52:52 */     final List<Locale> locales = Arrays.asList(Locale.getAvailableLocales());
/* 53:   */     
/* 54:   */     protected Iterable<Locale> getAllValues() throws Exception
/* 55:   */     {
/* 56:56 */       return locales;
/* 57:   */     }
/* 58:   */     
/* 59:   */     protected boolean matches(AbstractAutoCompletionSource.TermMatcher termMatcher, Locale input)
/* 60:   */     {
/* 61:61 */       return (termMatcher.matches(input.toString())) || (termMatcher.matches(input.getDisplayName()));
/* 62:   */     }
/* 63:   */   }
/* 64:   */   
/* 65:   */   private static class LocaleRenderer extends CustomListCellRenderer<Locale>
/* 66:   */   {
/* 67:   */     protected String getValueAsString(Locale value)
/* 68:   */     {
/* 69:69 */       return "(" + value.toString() + ") " + value.getDisplayName();
/* 70:   */     }
/* 71:   */   }
/* 72:   */ }
