/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Objects;
/*   4:    */ import ec.tss.tsproviders.utils.DataFormat;
/*   5:    */ import ec.ui.interfaces.IDisposable;
/*   6:    */ import ec.util.chart.ColorScheme;
/*   7:    */ import ec.util.chart.ColorScheme.KnownColor;
/*   8:    */ import ec.util.chart.swing.SwingColorSchemeSupport;
/*   9:    */ import java.awt.Color;
/*  10:    */ import java.beans.PropertyChangeEvent;
/*  11:    */ import java.beans.PropertyChangeListener;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.Map;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ public abstract class ThemeSupport
/*  21:    */   extends SwingColorSchemeSupport
/*  22:    */   implements IDisposable
/*  23:    */ {
/*  24:    */   final PropertyChangeListener listener;
/*  25:    */   final Map<Integer, ColorScheme.KnownColor> forcedLineColors;
/*  26:    */   ColorScheme localColorScheme;
/*  27:    */   DataFormat localDataFormat;
/*  28:    */   
/*  29:    */   public ThemeSupport()
/*  30:    */   {
/*  31: 31 */     listener = new Listener(null);
/*  32: 32 */     forcedLineColors = new HashMap();
/*  33: 33 */     localColorScheme = null;
/*  34:    */   }
/*  35:    */   
/*  36:    */ 
/*  37:    */   protected void colorSchemeChanged() {}
/*  38:    */   
/*  39:    */ 
/*  40:    */   protected void dataFormatChanged() {}
/*  41:    */   
/*  42:    */ 
/*  43:    */   public void setLocalColorScheme(ColorScheme localColorScheme)
/*  44:    */   {
/*  45: 45 */     if (!Objects.equal(this.localColorScheme, localColorScheme)) {
/*  46: 46 */       this.localColorScheme = localColorScheme;
/*  47: 47 */       colorSchemeChanged();
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public ColorScheme getLocalColorScheme() {
/*  52: 52 */     return localColorScheme;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public ColorScheme getColorScheme()
/*  56:    */   {
/*  57: 57 */     return localColorScheme != null ? localColorScheme : DemetraUI.getDefault().getColorScheme();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public DataFormat getLocalDataFormat() {
/*  61: 61 */     return localDataFormat;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setLocalDataFormat(DataFormat localDataFormat) {
/*  65: 65 */     if (!Objects.equal(this.localDataFormat, localDataFormat)) {
/*  66: 66 */       this.localDataFormat = localDataFormat;
/*  67: 67 */       dataFormatChanged();
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public DataFormat getDataFormat() {
/*  72: 72 */     return localDataFormat != null ? localDataFormat : DemetraUI.getDefault().getDataFormat();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void clearLineColors() {
/*  76: 76 */     forcedLineColors.clear();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setLineColor(int index, ColorScheme.KnownColor color) {
/*  80: 80 */     forcedLineColors.put(Integer.valueOf(index), color);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Color getLineColor(int index)
/*  84:    */   {
/*  85: 85 */     ColorScheme.KnownColor kc = (ColorScheme.KnownColor)forcedLineColors.get(Integer.valueOf(index));
/*  86: 86 */     return kc != null ? (Color)super.getLineColor(kc) : (Color)super.getLineColor(index);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void register() {
/*  90: 90 */     DemetraUI.getDefault().addPropertyChangeListener(listener);
/*  91:    */   }
/*  92:    */   
/*  93:    */ 
/*  94:    */ 
/*  95: 95 */   public void dispose() { DemetraUI.getDefault().removePropertyChangeListener(listener); }
/*  96:    */   
/*  97:    */   private class Listener implements PropertyChangeListener {
/*  98:    */     private Listener() {}
/*  99:    */     
/* 100:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 101:    */       String str;
/* 102:102 */       switch ((str = evt.getPropertyName()).hashCode()) {case 900197441:  if (str.equals("dataFormat")) break;  case 1316238739:  if ((goto 97) && (str.equals("colorSchemeName")))
/* 103:    */         {
/* 104:104 */           if (localColorScheme == null) {
/* 105:105 */             colorSchemeChanged();
/* 106:    */             
/* 107:107 */             return;
/* 108:    */             
/* 109:109 */             if (localDataFormat == null) {
/* 110:110 */               dataFormatChanged();
/* 111:    */             }
/* 112:    */           }
/* 113:    */         }
/* 114:    */         break;
/* 115:    */       }
/* 116:    */     }
/* 117:    */   }
/* 118:    */ }
