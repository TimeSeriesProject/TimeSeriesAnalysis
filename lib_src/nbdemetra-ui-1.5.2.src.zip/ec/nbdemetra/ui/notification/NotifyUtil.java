/*   1:    */ package ec.nbdemetra.ui.notification;
/*   2:    */ 
/*   3:    */ import java.awt.event.ActionEvent;
/*   4:    */ import java.awt.event.ActionListener;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ import javax.swing.JComponent;
/*   7:    */ import javax.swing.JLabel;
/*   8:    */ import org.openide.ErrorManager;
/*   9:    */ import org.openide.awt.NotificationDisplayer;
/*  10:    */ import org.openide.awt.NotificationDisplayer.Category;
/*  11:    */ import org.openide.awt.NotificationDisplayer.Priority;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ public class NotifyUtil
/*  45:    */ {
/*  46:    */   public static void show(String title, String message, MessageType type, ActionListener actionListener, @Nullable JComponent balloon, @Nullable JComponent popup)
/*  47:    */   {
/*  48: 48 */     if ((balloon == null) && (popup == null)) {
/*  49: 49 */       NotificationDisplayer.getDefault().notify(title, type.getIcon(), message, actionListener);
/*  50:    */     } else {
/*  51: 51 */       NotificationDisplayer.getDefault().notify(title, 
/*  52: 52 */         type.getIcon(), 
/*  53: 53 */         balloon == null ? new JLabel(message) : balloon, 
/*  54: 54 */         popup == null ? new JLabel(message) : popup, 
/*  55: 55 */         NotificationDisplayer.Priority.NORMAL, 
/*  56: 56 */         NotificationDisplayer.Category.INFO);
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */   public static void show(String title, String message, final MessageType type)
/*  69:    */   {
/*  70: 70 */     ActionListener actionListener = new ActionListener()
/*  71:    */     {
/*  72:    */       public void actionPerformed(ActionEvent e) {
/*  73: 73 */         MessageUtil.show(NotifyUtil.this, type);
/*  74:    */       }
/*  75: 75 */     };
/*  76: 76 */     show(title, message, type, actionListener, null, null);
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */   public static void info(String title, String message)
/*  85:    */   {
/*  86: 86 */     show(title, message, MessageType.INFO);
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */   public static void error(String title, String message)
/*  95:    */   {
/*  96: 96 */     show(title, message, MessageType.ERROR);
/*  97:    */   }
/*  98:    */   
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */   public static void error(String title, String message, Throwable exception)
/* 106:    */   {
/* 107:107 */     ActionListener actionListener = new ActionListener()
/* 108:    */     {
/* 109:    */       public void actionPerformed(ActionEvent e) {
/* 110:110 */         ErrorManager.getDefault().notify(NotifyUtil.this);
/* 111:    */       }
/* 112:112 */     };
/* 113:113 */     show(title, message, MessageType.ERROR, actionListener, null, null);
/* 114:    */   }
/* 115:    */   
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */   public static void warn(String title, String message)
/* 122:    */   {
/* 123:123 */     show(title, message, MessageType.WARNING);
/* 124:    */   }
/* 125:    */   
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */   public static void plain(String title, String message)
/* 132:    */   {
/* 133:133 */     show(title, message, MessageType.PLAIN);
/* 134:    */   }
/* 135:    */ }
