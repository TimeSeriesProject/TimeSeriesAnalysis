/*   1:    */ package ec.nbdemetra.ui.notification;
/*   2:    */ 
/*   3:    */ import org.openide.DialogDisplayer;
/*   4:    */ import org.openide.NotifyDescriptor.Exception;
/*   5:    */ import org.openide.NotifyDescriptor.Message;
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public class MessageUtil
/*  33:    */ {
/*  34:    */   public static DialogDisplayer getDialogDisplayer()
/*  35:    */   {
/*  36: 36 */     return DialogDisplayer.getDefault();
/*  37:    */   }
/*  38:    */   
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */   public static void show(String message, MessageType messageType)
/*  45:    */   {
/*  46: 46 */     getDialogDisplayer().notify(new NotifyDescriptor.Message(message, messageType.getNotifyDescriptorType()));
/*  47:    */   }
/*  48:    */   
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */   public static void showException(String message, Throwable exception)
/*  54:    */   {
/*  55: 55 */     getDialogDisplayer().notify(new NotifyDescriptor.Exception(exception, message));
/*  56:    */   }
/*  57:    */   
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */   public static void info(String message)
/*  62:    */   {
/*  63: 63 */     show(message, MessageType.INFO);
/*  64:    */   }
/*  65:    */   
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */   public static void error(String message)
/*  70:    */   {
/*  71: 71 */     show(message, MessageType.ERROR);
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */   public static void error(String message, Throwable exception)
/*  79:    */   {
/*  80: 80 */     showException(message, exception);
/*  81:    */   }
/*  82:    */   
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */   public static void question(String message)
/*  87:    */   {
/*  88: 88 */     show(message, MessageType.QUESTION);
/*  89:    */   }
/*  90:    */   
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */   public static void warn(String message)
/*  95:    */   {
/*  96: 96 */     show(message, MessageType.WARNING);
/*  97:    */   }
/*  98:    */   
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */   public static void plain(String message)
/* 103:    */   {
/* 104:104 */     show(message, MessageType.PLAIN);
/* 105:    */   }
/* 106:    */ }
