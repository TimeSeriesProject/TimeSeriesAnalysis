/*  1:   */ package ec.nbdemetra.ui.notification;
/*  2:   */ 
/*  3:   */ import ec.util.various.swing.FontAwesome;
/*  4:   */ import java.awt.Color;
/*  5:   */ import javax.swing.Icon;
/*  6:   */ import javax.swing.ImageIcon;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public enum MessageType
/* 30:   */ {
/* 31:31 */   PLAIN(-1, new ImageIcon()), 
/* 32:32 */   INFO(1, FontAwesome.FA_INFO_CIRCLE.getIcon(Color.BLUE, 20.0F)), 
/* 33:33 */   SUCCESS(1, FontAwesome.FA_CHECK_CIRCLE.getIcon(new Color(0, 166, 6), 20.0F)), 
/* 34:34 */   QUESTION(3, FontAwesome.FA_QUESTION_CIRCLE.getIcon(Color.BLUE, 20.0F)), 
/* 35:35 */   ERROR(0, FontAwesome.FA_TIMES_CIRCLE.getIcon(Color.RED, 20.0F)), 
/* 36:36 */   WARNING(2, FontAwesome.FA_EXCLAMATION_TRIANGLE.getIcon(Color.ORANGE, 20.0F));
/* 37:   */   
/* 38:   */   private final int notifyDescriptorType;
/* 39:   */   private final Icon icon;
/* 40:   */   
/* 41:   */   private MessageType(int notifyDescriptorType, Icon icon) {
/* 42:42 */     this.notifyDescriptorType = notifyDescriptorType;
/* 43:43 */     this.icon = icon;
/* 44:   */   }
/* 45:   */   
/* 46:   */   int getNotifyDescriptorType() {
/* 47:47 */     return notifyDescriptorType;
/* 48:   */   }
/* 49:   */   
/* 50:   */   Icon getIcon() {
/* 51:51 */     return icon;
/* 52:   */   }
/* 53:   */ }
