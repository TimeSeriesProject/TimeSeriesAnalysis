/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.tss.tsproviders.DataSet;
/*   6:    */ import ec.tss.tsproviders.DataSource;
/*   7:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*   8:    */ import java.util.Properties;
/*   9:    */ import javax.swing.GroupLayout;
/*  10:    */ import javax.swing.GroupLayout.Alignment;
/*  11:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  12:    */ import javax.swing.JScrollPane;
/*  13:    */ import javax.swing.JTextPane;
/*  14:    */ import org.openide.nodes.AbstractNode;
/*  15:    */ import org.openide.util.Lookup;
/*  16:    */ import org.openide.util.Lookup.Result;
/*  17:    */ import org.openide.util.LookupEvent;
/*  18:    */ import org.openide.util.LookupListener;
/*  19:    */ import org.openide.util.Utilities;
/*  20:    */ import org.openide.windows.TopComponent;
/*  21:    */ import org.openide.windows.TopComponent.Description;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ @TopComponent.Description(preferredID="DebugTopComponent", persistenceType=0)
/*  48:    */ public final class DebugTopComponent
/*  49:    */   extends TopComponent
/*  50:    */   implements LookupListener
/*  51:    */ {
/*  52:    */   private Lookup.Result<AbstractNode> lookupResult;
/*  53:    */   private JScrollPane jScrollPane1;
/*  54:    */   private JTextPane jTextPane1;
/*  55:    */   
/*  56:    */   private void initComponents()
/*  57:    */   {
/*  58: 58 */     jScrollPane1 = NbComponents.newJScrollPane();
/*  59: 59 */     jTextPane1 = new JTextPane();
/*  60:    */     
/*  61: 61 */     jTextPane1.setEditable(false);
/*  62: 62 */     jScrollPane1.setViewportView(jTextPane1);
/*  63:    */     
/*  64: 64 */     GroupLayout layout = new GroupLayout(this);
/*  65: 65 */     setLayout(layout);
/*  66: 66 */     layout.setHorizontalGroup(
/*  67: 67 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  68: 68 */       .addComponent(jScrollPane1, -1, 680, 32767));
/*  69:    */     
/*  70: 70 */     layout.setVerticalGroup(
/*  71: 71 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  72: 72 */       .addComponent(jScrollPane1, -1, 420, 32767));
/*  73:    */   }
/*  74:    */   
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */   public void componentOpened()
/*  81:    */   {
/*  82: 82 */     lookupResult = Utilities.actionsGlobalContext().lookupResult(AbstractNode.class);
/*  83: 83 */     lookupResult.addLookupListener(this);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void componentClosed()
/*  87:    */   {
/*  88: 88 */     lookupResult.removeLookupListener(this);
/*  89: 89 */     lookupResult = null;
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */   void writeProperties(Properties p)
/*  94:    */   {
/*  95: 95 */     p.setProperty("version", "1.0");
/*  96:    */   }
/*  97:    */   
/*  98:    */   void readProperties(Properties p)
/*  99:    */   {
/* 100:100 */     String version = p.getProperty("version");
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */   public void resultChanged(LookupEvent le)
/* 105:    */   {
/* 106:106 */     if (!le.getSource().equals(lookupResult)) {
/* 107:107 */       return;
/* 108:    */     }
/* 109:109 */     StringBuilder sb = new StringBuilder();
/* 110:110 */     for (AbstractNode o : lookupResult.allInstances()) {
/* 111:111 */       if ((o instanceof DataSourceNode)) {
/* 112:112 */         sb.append((CharSequence)DataSource.xmlFormatter(true).tryFormat((DataSource)o.getLookup().lookup(DataSource.class)).get());
/* 113:113 */       } else if ((o instanceof DataSetNode)) {
/* 114:114 */         sb.append((CharSequence)DataSet.xmlFormatter(true).tryFormat((DataSet)o.getLookup().lookup(DataSet.class)).get());
/* 115:    */       }
/* 116:    */     }
/* 117:117 */     jTextPane1.setText(sb.toString());
/* 118:    */   }
/* 119:    */ }
