/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.util.Properties;
/*   5:    */ import javax.swing.JScrollPane;
/*   6:    */ import org.openide.explorer.ExplorerManager;
/*   7:    */ import org.openide.explorer.ExplorerManager.Provider;
/*   8:    */ import org.openide.explorer.view.BeanTreeView;
/*   9:    */ import org.openide.nodes.AbstractNode;
/*  10:    */ import org.openide.nodes.Children;
/*  11:    */ import org.openide.util.HelpCtx;
/*  12:    */ import org.openide.util.lookup.InstanceContent;
/*  13:    */ import org.openide.windows.TopComponent;
/*  14:    */ import org.openide.windows.TopComponent.Description;
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ @TopComponent.Description(preferredID="ProvidersTopComponent", iconBase="ec/nbdemetra/ui/table.png", persistenceType=0)
/*  55:    */ public final class ProvidersTopComponent
/*  56:    */   extends TopComponent
/*  57:    */   implements ExplorerManager.Provider
/*  58:    */ {
/*  59:    */   private final ExplorerManager mgr;
/*  60:    */   private final InstanceContent content;
/*  61:    */   private JScrollPane jScrollPane1;
/*  62:    */   
/*  63:    */   private void initComponents()
/*  64:    */   {
/*  65: 65 */     jScrollPane1 = new BeanTreeView();
/*  66:    */     
/*  67: 67 */     setLayout(new BorderLayout());
/*  68: 68 */     add(jScrollPane1, "Center");
/*  69:    */   }
/*  70:    */   
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */   public void componentOpened()
/*  75:    */   {
/*  76: 76 */     mgr.setRootContext(new ProvidersNode());
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void componentClosed()
/*  80:    */   {
/*  81: 81 */     mgr.setRootContext(new AbstractNode(Children.LEAF));
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */   void writeProperties(Properties p)
/*  86:    */   {
/*  87: 87 */     p.setProperty("version", "1.0");
/*  88:    */   }
/*  89:    */   
/*  90:    */   void readProperties(Properties p)
/*  91:    */   {
/*  92: 92 */     String version = p.getProperty("version");
/*  93:    */   }
/*  94:    */   
/*  95:    */ 
/*  96:    */   public ExplorerManager getExplorerManager()
/*  97:    */   {
/*  98: 98 */     return mgr;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public HelpCtx getHelpCtx()
/* 102:    */   {
/* 103:103 */     return new HelpCtx("ec.nbdemetra.ui.datasources");
/* 104:    */   }
/* 105:    */ }
