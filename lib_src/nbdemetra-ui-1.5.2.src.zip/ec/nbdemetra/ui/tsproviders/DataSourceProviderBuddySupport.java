/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Strings;
/*   4:    */ import com.google.common.cache.CacheBuilder;
/*   5:    */ import com.google.common.cache.CacheLoader;
/*   6:    */ import com.google.common.cache.LoadingCache;
/*   7:    */ import ec.tss.tsproviders.DataSet;
/*   8:    */ import ec.tss.tsproviders.DataSource;
/*   9:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  10:    */ import javax.annotation.Nonnull;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ import org.openide.util.Lookup;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ public class DataSourceProviderBuddySupport
/*  36:    */ {
/*  37:    */   private final LoadingCache<String, IDataSourceProviderBuddy> fallback;
/*  38:    */   
/*  39:    */   @Nonnull
/*  40:    */   public static DataSourceProviderBuddySupport getDefault()
/*  41:    */   {
/*  42: 42 */     return (DataSourceProviderBuddySupport)Lookup.getDefault().lookup(DataSourceProviderBuddySupport.class);
/*  43:    */   }
/*  44:    */   
/*  45:    */   @Nonnull
/*  46:    */   @Deprecated
/*  47:    */   public static DataSourceProviderBuddySupport getInstance() {
/*  48: 48 */     return getDefault();
/*  49:    */   }
/*  50:    */   
/*  51:    */ 
/*  52:    */   public DataSourceProviderBuddySupport()
/*  53:    */   {
/*  54: 54 */     fallback = CacheBuilder.newBuilder().build(new CacheLoaderImpl(null));
/*  55:    */   }
/*  56:    */   
/*  57:    */   @Nonnull
/*  58:    */   protected IDataSourceProviderBuddy getFallback(@Nonnull String providerName) {
/*  59: 59 */     return (IDataSourceProviderBuddy)fallback.getUnchecked(providerName);
/*  60:    */   }
/*  61:    */   
/*  62:    */   @Nonnull
/*  63:    */   public IDataSourceProviderBuddy get(@Nullable String providerName) {
/*  64: 64 */     String tmp = Strings.nullToEmpty(providerName);
/*  65: 65 */     for (IDataSourceProviderBuddy o : Lookup.getDefault().lookupAll(IDataSourceProviderBuddy.class)) {
/*  66: 66 */       if (o.getProviderName().equals(tmp)) {
/*  67: 67 */         return o;
/*  68:    */       }
/*  69:    */     }
/*  70: 70 */     return getFallback(tmp);
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Nonnull
/*  74:    */   public IDataSourceProviderBuddy get(@Nonnull IDataSourceProvider provider) {
/*  75: 75 */     return get(provider.getSource());
/*  76:    */   }
/*  77:    */   
/*  78:    */   @Nonnull
/*  79:    */   public IDataSourceProviderBuddy get(@Nonnull DataSource dataSource) {
/*  80: 80 */     return get(dataSource.getProviderName());
/*  81:    */   }
/*  82:    */   
/*  83:    */   @Nonnull
/*  84:    */   public IDataSourceProviderBuddy get(@Nonnull DataSet dataSet) {
/*  85: 85 */     return get(dataSet.getDataSource());
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static final class CacheLoaderImpl extends CacheLoader<String, IDataSourceProviderBuddy>
/*  89:    */   {
/*  90:    */     public IDataSourceProviderBuddy load(String key)
/*  91:    */     {
/*  92: 92 */       return new DataSourceProviderBuddyImpl(key);
/*  93:    */     }
/*  94:    */     
/*  95:    */     private static final class DataSourceProviderBuddyImpl extends AbstractDataSourceProviderBuddy
/*  96:    */     {
/*  97:    */       private final String providerName;
/*  98:    */       
/*  99:    */       public DataSourceProviderBuddyImpl(String providerName) {
/* 100:100 */         this.providerName = providerName;
/* 101:    */       }
/* 102:    */       
/* 103:    */       public String getProviderName()
/* 104:    */       {
/* 105:105 */         return providerName;
/* 106:    */       }
/* 107:    */     }
/* 108:    */   }
/* 109:    */ }
