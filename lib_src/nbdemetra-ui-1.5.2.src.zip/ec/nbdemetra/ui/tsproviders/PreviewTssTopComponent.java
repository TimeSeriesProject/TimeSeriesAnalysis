/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.tss.Ts;
/*   5:    */ import ec.tss.TsCollection;
/*   6:    */ import ec.tss.TsInformationType;
/*   7:    */ import ec.tss.tsproviders.DataSet;
/*   8:    */ import ec.tss.tsproviders.TsProviders;
/*   9:    */ import ec.ui.chart.JTsChart;
/*  10:    */ import java.util.Properties;
/*  11:    */ import javax.swing.GroupLayout;
/*  12:    */ import javax.swing.GroupLayout.Alignment;
/*  13:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  14:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  15:    */ import org.openide.util.Lookup;
/*  16:    */ import org.openide.util.Lookup.Result;
/*  17:    */ import org.openide.util.LookupEvent;
/*  18:    */ import org.openide.util.LookupListener;
/*  19:    */ import org.openide.util.Utilities;
/*  20:    */ import org.openide.windows.TopComponent;
/*  21:    */ import org.openide.windows.TopComponent.Description;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ @TopComponent.Description(preferredID="PreviewTssTopComponent", persistenceType=0)
/*  53:    */ public final class PreviewTssTopComponent
/*  54:    */   extends TopComponent
/*  55:    */   implements LookupListener
/*  56:    */ {
/*  57:    */   private Lookup.Result<DataSetNode> lookupResult;
/*  58:    */   private JTsChart jTsChart1;
/*  59:    */   
/*  60:    */   private void initComponents()
/*  61:    */   {
/*  62: 62 */     jTsChart1 = new JTsChart();
/*  63:    */     
/*  64: 64 */     GroupLayout layout = new GroupLayout(this);
/*  65: 65 */     setLayout(layout);
/*  66: 66 */     layout.setHorizontalGroup(
/*  67: 67 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  68: 68 */       .addGap(0, 680, 32767)
/*  69: 69 */       .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  70: 70 */       .addGroup(layout.createSequentialGroup()
/*  71: 71 */       .addGap(0, 0, 0)
/*  72: 72 */       .addComponent(jTsChart1, -1, 680, 32767)
/*  73: 73 */       .addGap(0, 0, 0))));
/*  74:    */     
/*  75: 75 */     layout.setVerticalGroup(
/*  76: 76 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  77: 77 */       .addGap(0, 420, 32767)
/*  78: 78 */       .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  79: 79 */       .addGroup(layout.createSequentialGroup()
/*  80: 80 */       .addGap(0, 0, 0)
/*  81: 81 */       .addComponent(jTsChart1, -1, 420, 32767)
/*  82: 82 */       .addGap(0, 0, 0))));
/*  83:    */   }
/*  84:    */   
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */   public void componentOpened()
/*  90:    */   {
/*  91: 91 */     lookupResult = Utilities.actionsGlobalContext().lookupResult(DataSetNode.class);
/*  92: 92 */     lookupResult.addLookupListener(this);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void componentClosed()
/*  96:    */   {
/*  97: 97 */     lookupResult.removeLookupListener(this);
/*  98: 98 */     lookupResult = null;
/*  99:    */   }
/* 100:    */   
/* 101:    */ 
/* 102:    */ 
/* 103:    */   void writeProperties(Properties p)
/* 104:    */   {
/* 105:105 */     p.setProperty("version", "1.0");
/* 106:    */   }
/* 107:    */   
/* 108:    */   void readProperties(Properties p)
/* 109:    */   {
/* 110:110 */     String version = p.getProperty("version");
/* 111:    */   }
/* 112:    */   
/* 113:    */ 
/* 114:    */   public void resultChanged(LookupEvent le)
/* 115:    */   {
/* 116:116 */     if (le.getSource().equals(lookupResult)) {
/* 117:117 */       jTsChart1.getTsCollection().clear();
/* 118:118 */       for (DataSetNode o : lookupResult.allInstances())
/* 119:    */       {
/* 120:    */ 
/* 121:    */ 
/* 122:122 */         if ((o instanceof SeriesNode)) {
/* 123:123 */           Optional<Ts> data = TsProviders.getTs((DataSet)o.getLookup().lookup(DataSet.class), TsInformationType.Data);
/* 124:124 */           if (data.isPresent()) {
/* 125:125 */             jTsChart1.getTsCollection().add((Ts)data.get());
/* 126:    */           }
/* 127:    */         }
/* 128:    */       }
/* 129:    */     }
/* 130:    */   }
/* 131:    */ }
