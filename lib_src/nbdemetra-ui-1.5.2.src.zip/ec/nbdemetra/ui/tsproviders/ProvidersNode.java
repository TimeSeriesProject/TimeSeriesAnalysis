/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Predicate;
/*   6:    */ import com.google.common.base.Predicates;
/*   7:    */ import com.google.common.collect.FluentIterable;
/*   8:    */ import com.google.common.collect.Ordering;
/*   9:    */ import ec.nbdemetra.ui.Config;
/*  10:    */ import ec.nbdemetra.ui.DemetraUI;
/*  11:    */ import ec.nbdemetra.ui.interchange.Importable;
/*  12:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*  13:    */ import ec.tss.datatransfer.DataSourceTransferSupport;
/*  14:    */ import ec.tss.tsproviders.DataSource;
/*  15:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*  16:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  17:    */ import ec.tss.tsproviders.TsProviders;
/*  18:    */ import java.awt.datatransfer.Transferable;
/*  19:    */ import java.beans.PropertyChangeEvent;
/*  20:    */ import java.beans.PropertyChangeListener;
/*  21:    */ import java.io.IOException;
/*  22:    */ import java.util.Comparator;
/*  23:    */ import java.util.List;
/*  24:    */ import javax.swing.Action;
/*  25:    */ import org.openide.nodes.AbstractNode;
/*  26:    */ import org.openide.nodes.ChildFactory.Detachable;
/*  27:    */ import org.openide.nodes.Children;
/*  28:    */ import org.openide.nodes.Node;
/*  29:    */ import org.openide.util.Lookup;
/*  30:    */ import org.openide.util.Lookup.Result;
/*  31:    */ import org.openide.util.LookupEvent;
/*  32:    */ import org.openide.util.LookupListener;
/*  33:    */ import org.openide.util.datatransfer.PasteType;
/*  34:    */ import org.openide.util.lookup.AbstractLookup;
/*  35:    */ import org.openide.util.lookup.InstanceContent;
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ public final class ProvidersNode
/*  56:    */   extends AbstractNode
/*  57:    */ {
/*  58:    */   public static final String ACTION_PATH = "ProvidersNode";
/*  59:    */   
/*  60:    */   public ProvidersNode()
/*  61:    */   {
/*  62: 62 */     this(new InstanceContent());
/*  63:    */   }
/*  64:    */   
/*  65:    */   private ProvidersNode(InstanceContent abilities)
/*  66:    */   {
/*  67: 67 */     super(Children.create(new ProvidersChildFactory(), true), new AbstractLookup(abilities));
/*  68:    */     
/*  69:    */ 
/*  70:    */ 
/*  71: 71 */     abilities.add(new ImportableAsXmlImpl(null));
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */ 
/*  76:    */   public Action[] getActions(boolean context)
/*  77:    */   {
/*  78: 78 */     return Nodes.actionsForPath("ProvidersNode");
/*  79:    */   }
/*  80:    */   
/*  81:    */   public PasteType getDropType(Transferable t, int action, int index)
/*  82:    */   {
/*  83: 83 */     if (DataSourceTransferSupport.getDefault().canHandle(t)) {
/*  84: 84 */       return new PasteTypeImpl(t);
/*  85:    */     }
/*  86: 86 */     return null;
/*  87:    */   }
/*  88:    */   
/*  89:    */   @Deprecated
/*  90:    */   public void paste(DataSource dataSource) {
/*  91: 91 */     Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, dataSource);
/*  92: 92 */     if (loader.isPresent()) {
/*  93: 93 */       ((IDataSourceLoader)loader.get()).open(dataSource);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static final class ProvidersChildFactory extends ChildFactory.Detachable<IDataSourceProvider> implements LookupListener, PropertyChangeListener
/*  98:    */   {
/*  99:    */     private final Lookup.Result<IDataSourceProvider> lookupResult;
/* 100:    */     private final DemetraUI demetraUI;
/* 101:    */     
/* 102:    */     public ProvidersChildFactory() {
/* 103:103 */       lookupResult = Lookup.getDefault().lookupResult(IDataSourceProvider.class);
/* 104:104 */       demetraUI = DemetraUI.getDefault();
/* 105:    */     }
/* 106:    */     
/* 107:    */     protected void addNotify()
/* 108:    */     {
/* 109:109 */       lookupResult.addLookupListener(this);
/* 110:110 */       demetraUI.addPropertyChangeListener(this);
/* 111:    */     }
/* 112:    */     
/* 113:    */     protected void removeNotify()
/* 114:    */     {
/* 115:115 */       demetraUI.removePropertyChangeListener(this);
/* 116:116 */       lookupResult.removeLookupListener(this);
/* 117:    */     }
/* 118:    */     
/* 119:    */     protected boolean createKeys(List<IDataSourceProvider> list)
/* 120:    */     {
/* 121:121 */       list.addAll(FluentIterable.from(lookupResult.allInstances()).filter(getFilter()).toSortedList(getOrdering()));
/* 122:122 */       return true;
/* 123:    */     }
/* 124:    */     
/* 125:    */     protected Node createNodeForKey(IDataSourceProvider key)
/* 126:    */     {
/* 127:127 */       return new ProviderNode(key);
/* 128:    */     }
/* 129:    */     
/* 130:    */     protected Predicate<IDataSourceProvider> getFilter() {
/* 131:131 */       return demetraUI.isShowUnavailableTsProviders() ? Predicates.alwaysTrue() : ProvidersNode.IS_AVAILABLE;
/* 132:    */     }
/* 133:    */     
/* 134:    */     protected Comparator<IDataSourceProvider> getOrdering() {
/* 135:135 */       return ProvidersNode.ON_CLASS_SIMPLENAME;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public void resultChanged(LookupEvent ev)
/* 139:    */     {
/* 140:140 */       refresh(true);
/* 141:    */     }
/* 142:    */     
/* 143:    */     public void propertyChange(PropertyChangeEvent evt)
/* 144:    */     {
/* 145:145 */       if (evt.getPropertyName().equals("showUnavailableTsProviders")) {
/* 146:146 */         refresh(true);
/* 147:    */       }
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   private final class ImportableAsXmlImpl implements Importable {
/* 152:    */     private ImportableAsXmlImpl() {}
/* 153:    */     
/* 154:    */     public String getDomain() {
/* 155:155 */       return ProvidersUtil.getDataSourceDomain();
/* 156:    */     }
/* 157:    */     
/* 158:    */     public void importConfig(Config config) throws IllegalArgumentException
/* 159:    */     {
/* 160:160 */       DataSource dataSource = ProvidersUtil.getDataSource(config);
/* 161:161 */       Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, dataSource);
/* 162:162 */       if (loader.isPresent()) {
/* 163:163 */         ((IDataSourceLoader)loader.get()).open(dataSource);
/* 164:164 */         Optional<Node> node = ProvidersUtil.findNode(dataSource, ProvidersNode.this);
/* 165:165 */         if (node.isPresent()) {
/* 166:166 */           ((Node)node.get()).setDisplayName(config.getName());
/* 167:    */         }
/* 168:    */       }
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   private final class PasteTypeImpl extends PasteType
/* 173:    */   {
/* 174:    */     private final Transferable t;
/* 175:    */     
/* 176:    */     public PasteTypeImpl(Transferable t) {
/* 177:177 */       this.t = t;
/* 178:    */     }
/* 179:    */     
/* 180:    */     public Transferable paste() throws IOException
/* 181:    */     {
/* 182:182 */       Optional<DataSource> dataSource = DataSourceTransferSupport.getDefault().getDataSource(t);
/* 183:183 */       if (dataSource.isPresent()) {
/* 184:184 */         Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, (DataSource)dataSource.get());
/* 185:185 */         if (loader.isPresent()) {
/* 186:186 */           ((IDataSourceLoader)loader.get()).open((DataSource)dataSource.get());
/* 187:    */         }
/* 188:    */       }
/* 189:189 */       return null;
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:193 */   private static final Predicate<IDataSourceProvider> IS_AVAILABLE = new Predicate()
/* 194:    */   {
/* 195:    */     public boolean apply(IDataSourceProvider input) {
/* 196:196 */       return input.isAvailable();
/* 197:    */     }
/* 198:    */   };
/* 199:199 */   private static final Ordering<IDataSourceProvider> ON_CLASS_SIMPLENAME = Ordering.natural().onResultOf(new Function()
/* 200:    */   {
/* 201:    */     public String apply(IDataSourceProvider input) {
/* 202:202 */       return input.getClass().getSimpleName();
/* 203:    */     }
/* 204:199 */   });
/* 205:    */ }
