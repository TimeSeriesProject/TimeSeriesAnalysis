/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import org.netbeans.api.actions.Editable;
/*  5:   */ import org.openide.nodes.Node;
/*  6:   */ import org.openide.util.Lookup;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ public final class EditSourceAction
/* 34:   */   extends SingleNodeAction<Node>
/* 35:   */ {
/* 36:   */   public EditSourceAction()
/* 37:   */   {
/* 38:38 */     super(Node.class);
/* 39:   */   }
/* 40:   */   
/* 41:   */   protected void performAction(Node activatedNode)
/* 42:   */   {
/* 43:43 */     ((Editable)activatedNode.getLookup().lookup(Editable.class)).edit();
/* 44:   */   }
/* 45:   */   
/* 46:   */   protected boolean enable(Node activatedNode)
/* 47:   */   {
/* 48:48 */     return activatedNode.getLookup().lookup(Editable.class) != null;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public String getName()
/* 52:   */   {
/* 53:53 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 54:   */   }
/* 55:   */ }
