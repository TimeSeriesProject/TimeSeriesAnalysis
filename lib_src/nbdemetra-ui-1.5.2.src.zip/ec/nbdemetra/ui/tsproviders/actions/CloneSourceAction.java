/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  5:   */ import ec.nbdemetra.ui.tsproviders.DataSourceNode;
/*  6:   */ import ec.nbdemetra.ui.tsproviders.DataSourceProviderBuddySupport;
/*  7:   */ import ec.nbdemetra.ui.tsproviders.IDataSourceProviderBuddy;
/*  8:   */ import ec.tss.tsproviders.DataSource;
/*  9:   */ import ec.tss.tsproviders.IDataSourceLoader;
/* 10:   */ import ec.tss.tsproviders.TsProviders;
/* 11:   */ import java.beans.IntrospectionException;
/* 12:   */ import org.openide.util.HelpCtx;
/* 13:   */ import org.openide.util.Lookup;
/* 14:   */ import org.slf4j.Logger;
/* 15:   */ import org.slf4j.LoggerFactory;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public final class CloneSourceAction
/* 27:   */   extends SingleNodeAction<DataSourceNode>
/* 28:   */ {
/* 29:   */   public CloneSourceAction()
/* 30:   */   {
/* 31:31 */     super(DataSourceNode.class);
/* 32:   */   }
/* 33:   */   
/* 34:   */   protected void performAction(DataSourceNode activatedNode)
/* 35:   */   {
/* 36:   */     try {
/* 37:37 */       clone((DataSource)activatedNode.getLookup().lookup(DataSource.class));
/* 38:   */     } catch (IntrospectionException ex) {
/* 39:39 */       LoggerFactory.getLogger(CloneSourceAction.class).error("While cloning", ex);
/* 40:   */     }
/* 41:   */   }
/* 42:   */   
/* 43:   */   static DataSource clone(DataSource dataSource) throws IntrospectionException {
/* 44:44 */     IDataSourceLoader loader = (IDataSourceLoader)TsProviders.lookup(IDataSourceLoader.class, dataSource).get();
/* 45:45 */     Object bean = loader.decodeBean(dataSource);
/* 46:46 */     if (DataSourceProviderBuddySupport.getDefault().get(loader).editBean("Clone data source", bean)) {
/* 47:47 */       DataSource newDataSource = loader.encodeBean(bean);
/* 48:48 */       return loader.open(newDataSource) ? newDataSource : null;
/* 49:   */     }
/* 50:50 */     return null;
/* 51:   */   }
/* 52:   */   
/* 53:   */   protected boolean enable(DataSourceNode activatedNode)
/* 54:   */   {
/* 55:55 */     return TsProviders.lookup(IDataSourceLoader.class, (DataSource)activatedNode.getLookup().lookup(DataSource.class)).isPresent();
/* 56:   */   }
/* 57:   */   
/* 58:   */   public String getName()
/* 59:   */   {
/* 60:60 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 61:   */   }
/* 62:   */   
/* 63:   */   public HelpCtx getHelpCtx()
/* 64:   */   {
/* 65:65 */     return null;
/* 66:   */   }
/* 67:   */ }
