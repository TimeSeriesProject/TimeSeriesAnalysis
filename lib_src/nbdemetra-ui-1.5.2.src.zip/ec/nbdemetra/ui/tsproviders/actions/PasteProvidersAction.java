/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.tss.datatransfer.DataSourceTransferSupport;
/*  5:   */ import ec.tss.tsproviders.DataSource;
/*  6:   */ import ec.tss.tsproviders.IDataSourceLoader;
/*  7:   */ import ec.tss.tsproviders.TsProviders;
/*  8:   */ import java.awt.Toolkit;
/*  9:   */ import java.awt.datatransfer.Clipboard;
/* 10:   */ import java.awt.datatransfer.Transferable;
/* 11:   */ import org.openide.nodes.Node;
/* 12:   */ import org.openide.util.HelpCtx;
/* 13:   */ import org.openide.util.actions.NodeAction;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ public final class PasteProvidersAction
/* 42:   */   extends NodeAction
/* 43:   */ {
/* 44:   */   protected void performAction(Node[] activatedNodes)
/* 45:   */   {
/* 46:46 */     Optional<DataSource> dataSource = DataSourceTransferSupport.getDefault().getDataSource(getTransferable(activatedNodes));
/* 47:47 */     if (dataSource.isPresent()) {
/* 48:48 */       Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, (DataSource)dataSource.get());
/* 49:49 */       if (loader.isPresent()) {
/* 50:50 */         ((IDataSourceLoader)loader.get()).open((DataSource)dataSource.get());
/* 51:   */       }
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   protected boolean enable(Node[] activatedNodes)
/* 56:   */   {
/* 57:57 */     return DataSourceTransferSupport.getDefault().canHandle(getTransferable(activatedNodes));
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String getName()
/* 61:   */   {
/* 62:62 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 63:   */   }
/* 64:   */   
/* 65:   */   public HelpCtx getHelpCtx()
/* 66:   */   {
/* 67:67 */     return null;
/* 68:   */   }
/* 69:   */   
/* 70:   */   private static Transferable getTransferable(Node[] requestor) {
/* 71:71 */     return Toolkit.getDefaultToolkit().getSystemClipboard().getContents(requestor);
/* 72:   */   }
/* 73:   */ }
