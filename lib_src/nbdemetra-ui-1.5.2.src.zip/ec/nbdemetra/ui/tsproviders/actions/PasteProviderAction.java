/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  5:   */ import ec.nbdemetra.ui.tsproviders.ProviderNode;
/*  6:   */ import ec.tss.datatransfer.DataSourceTransferSupport;
/*  7:   */ import ec.tss.tsproviders.DataSource;
/*  8:   */ import ec.tss.tsproviders.IDataSourceLoader;
/*  9:   */ import java.awt.Toolkit;
/* 10:   */ import java.awt.datatransfer.Clipboard;
/* 11:   */ import java.awt.datatransfer.Transferable;
/* 12:   */ import org.openide.util.Lookup;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public final class PasteProviderAction
/* 26:   */   extends SingleNodeAction<ProviderNode>
/* 27:   */ {
/* 28:   */   public PasteProviderAction()
/* 29:   */   {
/* 30:30 */     super(ProviderNode.class);
/* 31:   */   }
/* 32:   */   
/* 33:   */   protected boolean enable(ProviderNode activatedNode)
/* 34:   */   {
/* 35:35 */     IDataSourceLoader loader = (IDataSourceLoader)activatedNode.getLookup().lookup(IDataSourceLoader.class);
/* 36:36 */     return (loader != null) && (DataSourceTransferSupport.getDefault().canHandle(getTransferable(activatedNode), loader.getSource()));
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String getName()
/* 40:   */   {
/* 41:41 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 42:   */   }
/* 43:   */   
/* 44:   */   protected void performAction(ProviderNode activatedNode)
/* 45:   */   {
/* 46:46 */     IDataSourceLoader loader = (IDataSourceLoader)activatedNode.getLookup().lookup(IDataSourceLoader.class);
/* 47:47 */     Optional<DataSource> dataSource = DataSourceTransferSupport.getDefault().getDataSource(getTransferable(activatedNode), loader.getSource());
/* 48:48 */     if (dataSource.isPresent()) {
/* 49:49 */       activatedNode.paste((DataSource)dataSource.get());
/* 50:   */     }
/* 51:   */   }
/* 52:   */   
/* 53:   */   static Transferable getTransferable(ProviderNode activatedNode) {
/* 54:54 */     return Toolkit.getDefaultToolkit().getSystemClipboard().getContents(activatedNode);
/* 55:   */   }
/* 56:   */ }
