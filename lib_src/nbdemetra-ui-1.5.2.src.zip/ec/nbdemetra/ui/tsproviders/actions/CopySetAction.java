/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import java.awt.Toolkit;
/*  5:   */ import java.awt.datatransfer.Clipboard;
/*  6:   */ import java.io.IOException;
/*  7:   */ import org.openide.nodes.Node;
/*  8:   */ import org.openide.util.Exceptions;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ public final class CopySetAction
/* 39:   */   extends SingleNodeAction<Node>
/* 40:   */ {
/* 41:   */   public CopySetAction()
/* 42:   */   {
/* 43:43 */     super(Node.class);
/* 44:   */   }
/* 45:   */   
/* 46:   */   protected void performAction(Node activatedNode)
/* 47:   */   {
/* 48:   */     try {
/* 49:49 */       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(activatedNode.clipboardCopy(), null);
/* 50:   */     } catch (IOException ex) {
/* 51:51 */       Exceptions.printStackTrace(ex);
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   protected boolean enable(Node activatedNode)
/* 56:   */   {
/* 57:57 */     return activatedNode.canCopy();
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String getName()
/* 61:   */   {
/* 62:62 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 63:   */   }
/* 64:   */ }
