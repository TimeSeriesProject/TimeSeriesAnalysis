/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import org.netbeans.api.actions.Openable;
/*  5:   */ import org.openide.nodes.Node;
/*  6:   */ import org.openide.util.Lookup;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ public final class OpenProviderAction
/* 38:   */   extends SingleNodeAction<Node>
/* 39:   */ {
/* 40:   */   public OpenProviderAction()
/* 41:   */   {
/* 42:42 */     super(Node.class);
/* 43:   */   }
/* 44:   */   
/* 45:   */   protected void performAction(Node activatedNode)
/* 46:   */   {
/* 47:47 */     ((Openable)activatedNode.getLookup().lookup(Openable.class)).open();
/* 48:   */   }
/* 49:   */   
/* 50:   */   protected boolean enable(Node activatedNode)
/* 51:   */   {
/* 52:52 */     return activatedNode.getLookup().lookup(Openable.class) != null;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public String getName()
/* 56:   */   {
/* 57:57 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 58:   */   }
/* 59:   */ }
