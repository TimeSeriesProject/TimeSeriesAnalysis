/*  1:   */ package ec.nbdemetra.ui.tsproviders.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import java.awt.Toolkit;
/*  5:   */ import java.awt.datatransfer.Clipboard;
/*  6:   */ import java.io.IOException;
/*  7:   */ import org.openide.nodes.Node;
/*  8:   */ import org.openide.util.Exceptions;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ public final class CopySourceAction
/* 37:   */   extends SingleNodeAction<Node>
/* 38:   */ {
/* 39:   */   public CopySourceAction()
/* 40:   */   {
/* 41:41 */     super(Node.class);
/* 42:   */   }
/* 43:   */   
/* 44:   */   protected void performAction(Node activatedNode)
/* 45:   */   {
/* 46:   */     try {
/* 47:47 */       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(activatedNode.clipboardCopy(), null);
/* 48:   */     } catch (IOException ex) {
/* 49:49 */       Exceptions.printStackTrace(ex);
/* 50:   */     }
/* 51:   */   }
/* 52:   */   
/* 53:   */   protected boolean enable(Node activatedNode)
/* 54:   */   {
/* 55:55 */     return activatedNode.canCopy();
/* 56:   */   }
/* 57:   */   
/* 58:   */   public String getName()
/* 59:   */   {
/* 60:60 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 61:   */   }
/* 62:   */ }
