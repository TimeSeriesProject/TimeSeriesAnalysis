/*   1:    */ package ec.nbdemetra.ui.tsproviders.actions;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Predicate;
/*   6:    */ import com.google.common.collect.FluentIterable;
/*   7:    */ import com.google.common.collect.Iterables;
/*   8:    */ import com.google.common.collect.Ordering;
/*   9:    */ import ec.nbdemetra.ui.tsproviders.DataSourceProviderBuddySupport;
/*  10:    */ import ec.nbdemetra.ui.tsproviders.IDataSourceProviderBuddy;
/*  11:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*  12:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  13:    */ import ec.tss.tsproviders.IFileLoader;
/*  14:    */ import ec.tss.tsproviders.TsProviders;
/*  15:    */ import java.awt.Component;
/*  16:    */ import java.awt.Image;
/*  17:    */ import java.awt.event.ActionEvent;
/*  18:    */ import java.beans.IntrospectionException;
/*  19:    */ import java.io.File;
/*  20:    */ import java.util.List;
/*  21:    */ import javax.swing.AbstractAction;
/*  22:    */ import javax.swing.DefaultListCellRenderer;
/*  23:    */ import javax.swing.JComboBox;
/*  24:    */ import javax.swing.JLabel;
/*  25:    */ import javax.swing.JList;
/*  26:    */ import javax.swing.JMenuItem;
/*  27:    */ import org.openide.DialogDescriptor;
/*  28:    */ import org.openide.DialogDisplayer;
/*  29:    */ import org.openide.NotifyDescriptor;
/*  30:    */ import org.openide.util.Exceptions;
/*  31:    */ import org.openide.util.ImageUtilities;
/*  32:    */ import org.openide.util.actions.Presenter.Popup;
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ public final class OpenProvidersAction
/*  66:    */   extends AbstractAction
/*  67:    */   implements Presenter.Popup
/*  68:    */ {
/*  69:    */   public void actionPerformed(ActionEvent e)
/*  70:    */   {
/*  71: 71 */     throw new UnsupportedOperationException("Not supported yet.");
/*  72:    */   }
/*  73:    */   
/*  74:    */   public JMenuItem getPopupPresenter()
/*  75:    */   {
/*  76: 76 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */   public static List<IFileLoader> getLoaders(File file)
/*  83:    */   {
/*  84: 84 */     
/*  85:    */     
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89: 89 */       TsProviders.all().filter(IFileLoader.class).filter(new Predicate()
/*  90:    */       {
/*  91:    */         public boolean apply(IFileLoader input)
/*  92:    */         {
/*  93: 87 */           return input.accept(OpenProvidersAction.this);
/*  94:    */         }
/*  95:    */       }).toList();
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static <T extends IDataSourceLoader> Optional<T> chooseLoader(List<T> loaders) {
/*  99: 93 */     if (loaders.size() == 1) {
/* 100: 94 */       return Optional.of((IDataSourceLoader)loaders.get(0));
/* 101:    */     }
/* 102: 96 */     JComboBox cb = new JComboBox(Iterables.toArray(loaders, IDataSourceLoader.class));
/* 103: 97 */     cb.setRenderer(new LoaderRenderer(null));
/* 104: 98 */     DialogDescriptor dd = new DialogDescriptor(cb, "Choose a loader");
/* 105: 99 */     if (DialogDisplayer.getDefault().notify(dd) == NotifyDescriptor.OK_OPTION) {
/* 106:100 */       return Optional.of((IDataSourceLoader)cb.getSelectedItem());
/* 107:    */     }
/* 108:102 */     return Optional.absent();
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static final class LoaderRenderer extends DefaultListCellRenderer
/* 112:    */   {
/* 113:    */     public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 114:    */     {
/* 115:109 */       JLabel result = (JLabel)super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
/* 116:110 */       result.setText(((IFileLoader)value).getDisplayName());
/* 117:111 */       result.setIcon(ImageUtilities.image2Icon(DataSourceProviderBuddySupport.getDefault().get((IFileLoader)value).getIcon(1, false)));
/* 118:112 */       return result;
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:116 */   private static final Ordering<IDataSourceProvider> ON_CLASS_SIMPLENAME = Ordering.natural().onResultOf(new Function()
/* 123:    */   {
/* 124:    */     public String apply(IDataSourceProvider input) {
/* 125:119 */       return input.getClass().getSimpleName();
/* 126:    */     }
/* 127:116 */   });
/* 128:    */   
/* 129:    */ 
/* 130:    */ 
/* 131:    */   private static final class AbstractActionImpl
/* 132:    */     extends AbstractAction
/* 133:    */   {
/* 134:    */     private final IFileLoader loader;
/* 135:    */     
/* 136:    */ 
/* 137:    */     public AbstractActionImpl(IFileLoader loader)
/* 138:    */     {
/* 139:128 */       super();
/* 140:129 */       Image image = DataSourceProviderBuddySupport.getDefault().get(loader).getIcon(1, false);
/* 141:130 */       if (image != null) {
/* 142:131 */         super.putValue("SmallIcon", ImageUtilities.image2Icon(image));
/* 143:    */       }
/* 144:133 */       this.loader = loader;
/* 145:    */     }
/* 146:    */     
/* 147:    */     public void actionPerformed(ActionEvent e)
/* 148:    */     {
/* 149:138 */       Object bean = loader.newBean();
/* 150:    */       try {
/* 151:140 */         if (DataSourceProviderBuddySupport.getDefault().get(loader).editBean("Open data source", bean)) {
/* 152:141 */           loader.open(loader.encodeBean(bean));
/* 153:    */         }
/* 154:    */       } catch (IntrospectionException ex) {
/* 155:144 */         Exceptions.printStackTrace(ex);
/* 156:    */       }
/* 157:    */     }
/* 158:    */   }
/* 159:    */ }
