/*  1:   */ package ec.nbdemetra.ui.tsproviders;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.tss.TsCollection;
/*  5:   */ import ec.tss.TsInformationType;
/*  6:   */ import ec.tss.datatransfer.TssTransferSupport;
/*  7:   */ import ec.tss.tsproviders.DataSet;
/*  8:   */ import ec.tss.tsproviders.TsProviders;
/*  9:   */ import java.awt.datatransfer.Transferable;
/* 10:   */ import java.io.IOException;
/* 11:   */ import javax.annotation.Nonnull;
/* 12:   */ import org.openide.util.Lookup;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ public final class CollectionNode
/* 33:   */   extends DataSetNode
/* 34:   */ {
/* 35:   */   public static final String ACTION_PATH = "CollectionNode";
/* 36:   */   
/* 37:   */   public CollectionNode(@Nonnull DataSet dataSet)
/* 38:   */   {
/* 39:39 */     super(dataSet, "CollectionNode");
/* 40:   */   }
/* 41:   */   
/* 42:   */   private Transferable getData(TsInformationType type) throws IOException {
/* 43:43 */     Optional<TsCollection> data = TsProviders.getTsCollection((DataSet)getLookup().lookup(DataSet.class), type);
/* 44:44 */     if (data.isPresent()) {
/* 45:45 */       return TssTransferSupport.getDefault().fromTsCollection((TsCollection)data.get());
/* 46:   */     }
/* 47:47 */     throw new IOException("Cannot create the TS collection '" + getDisplayName() + "'; check the logs for further details.");
/* 48:   */   }
/* 49:   */   
/* 50:   */ 
/* 51:   */   public Transferable clipboardCopy()
/* 52:   */     throws IOException
/* 53:   */   {
/* 54:54 */     return getData(TsInformationType.All);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public Transferable drag() throws IOException
/* 58:   */   {
/* 59:59 */     return getData(TsInformationType.Definition);
/* 60:   */   }
/* 61:   */ }
