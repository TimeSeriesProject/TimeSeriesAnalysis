/*  1:   */ package ec.nbdemetra.ui.tsproviders;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.Config;
/*  5:   */ import ec.nbdemetra.ui.Config.Builder;
/*  6:   */ import ec.tss.tsproviders.DataSource;
/*  7:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  8:   */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  9:   */ import javax.annotation.Nonnull;
/* 10:   */ import org.openide.nodes.Children;
/* 11:   */ import org.openide.nodes.Node;
/* 12:   */ import org.openide.util.Lookup;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ final class ProvidersUtil
/* 33:   */ {
/* 34:   */   @Nonnull
/* 35:   */   public static String getDataSourceDomain()
/* 36:   */   {
/* 37:37 */     return DataSource.class.getName();
/* 38:   */   }
/* 39:   */   
/* 40:   */   @Nonnull
/* 41:   */   public static DataSource getDataSource(@Nonnull Config config) throws IllegalArgumentException {
/* 42:42 */     String uri = config.get("uri");
/* 43:43 */     if (uri == null) {
/* 44:44 */       throw new IllegalArgumentException("Missing parameter");
/* 45:   */     }
/* 46:46 */     DataSource result = (DataSource)DataSource.uriParser().parse(uri);
/* 47:47 */     if (result == null) {
/* 48:48 */       throw new IllegalArgumentException("Invalid uri");
/* 49:   */     }
/* 50:50 */     return result;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public static Config getConfig(DataSource dataSource, String displayName) {
/* 54:54 */     return 
/* 55:   */     
/* 56:56 */       ((Config.Builder)Config.builder(getDataSourceDomain(), displayName, "").put("uri", DataSource.uriFormatter().formatAsString(dataSource))).build();
/* 57:   */   }
/* 58:   */   
/* 59:   */   public static Optional<Node> findNode(DataSource dataSource, Node node) {
/* 60:60 */     if ((node instanceof ProvidersNode)) {
/* 61:61 */       return find(dataSource, (ProvidersNode)node);
/* 62:   */     }
/* 63:63 */     if ((node instanceof ProviderNode)) {
/* 64:64 */       return find(dataSource, (ProviderNode)node);
/* 65:   */     }
/* 66:66 */     return Optional.absent();
/* 67:   */   }
/* 68:   */   
/* 69:   */   private static Optional<Node> find(DataSource dataSource, ProvidersNode node) {
/* 70:70 */     for (Node o : node.getChildren().getNodes()) {
/* 71:71 */       if (dataSource.getProviderName().equals(o.getName())) {
/* 72:72 */         return find(dataSource, (ProviderNode)o);
/* 73:   */       }
/* 74:   */     }
/* 75:75 */     return Optional.absent();
/* 76:   */   }
/* 77:   */   
/* 78:   */   private static Optional<Node> find(DataSource dataSource, ProviderNode node) {
/* 79:79 */     for (Node o : node.getChildren().getNodes()) {
/* 80:80 */       if (dataSource.equals(o.getLookup().lookup(DataSource.class))) {
/* 81:81 */         return Optional.of(o);
/* 82:   */       }
/* 83:   */     }
/* 84:84 */     return Optional.absent();
/* 85:   */   }
/* 86:   */ }
