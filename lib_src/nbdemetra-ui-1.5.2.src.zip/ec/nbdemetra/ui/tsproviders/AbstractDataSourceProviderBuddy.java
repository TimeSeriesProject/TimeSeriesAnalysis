/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import com.google.common.collect.Lists;
/*   5:    */ import ec.nbdemetra.ui.properties.ForwardingNodeProperty;
/*   6:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*   7:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.BooleanStep;
/*   8:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*   9:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.EnumStep;
/*  10:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  11:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  12:    */ import ec.nbdemetra.ui.properties.OpenIdePropertySheetBeanEditor;
/*  13:    */ import ec.tss.TsAsyncMode;
/*  14:    */ import ec.tss.tsproviders.DataSet;
/*  15:    */ import ec.tss.tsproviders.DataSet.Kind;
/*  16:    */ import ec.tss.tsproviders.DataSource;
/*  17:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*  18:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  19:    */ import ec.tss.tsproviders.IFileLoader;
/*  20:    */ import ec.tss.tsproviders.TsProviders;
/*  21:    */ import java.awt.Image;
/*  22:    */ import java.beans.IntrospectionException;
/*  23:    */ import java.util.ArrayList;
/*  24:    */ import java.util.Iterator;
/*  25:    */ import java.util.List;
/*  26:    */ import java.util.Map.Entry;
/*  27:    */ import java.util.SortedMap;
/*  28:    */ import org.openide.ErrorManager;
/*  29:    */ import org.openide.nodes.BeanNode;
/*  30:    */ import org.openide.nodes.Node.Property;
/*  31:    */ import org.openide.nodes.Node.PropertySet;
/*  32:    */ import org.openide.nodes.Sheet;
/*  33:    */ import org.openide.nodes.Sheet.Set;
/*  34:    */ import org.openide.util.ImageUtilities;
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ public abstract class AbstractDataSourceProviderBuddy
/*  43:    */   implements IDataSourceProviderBuddy
/*  44:    */ {
/*  45:    */   public Image getIcon(int type, boolean opened)
/*  46:    */   {
/*  47: 47 */     return ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/document.png", true);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Image getIcon(DataSource dataSource, int type, boolean opened)
/*  51:    */   {
/*  52: 52 */     return getIcon(type, opened);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Image getIcon(DataSet dataSet, int type, boolean opened)
/*  56:    */   {
/*  57: 57 */     switch (dataSet.getKind()) {
/*  58:    */     case DUMMY: 
/*  59: 59 */       return ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/folder.png", true);
/*  60:    */     case COLLECTION: 
/*  61: 61 */       return ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/chart_line.png", true);
/*  62:    */     case SERIES: 
/*  63: 63 */       return null;
/*  64:    */     }
/*  65: 65 */     throw new UnsupportedOperationException("Not supported yet.");
/*  66:    */   }
/*  67:    */   
/*  68:    */   static Sheet createSheet(List<Sheet.Set> sets) {
/*  69: 69 */     Sheet result = new Sheet();
/*  70: 70 */     for (Sheet.Set o : sets) {
/*  71: 71 */       result.put(o);
/*  72:    */     }
/*  73: 73 */     return result;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Sheet createSheet()
/*  77:    */   {
/*  78: 78 */     return createSheet(createSheetSets());
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected List<Sheet.Set> createSheetSets() {
/*  82: 82 */     List<Sheet.Set> result = new ArrayList();
/*  83: 83 */     IDataSourceProvider provider = (IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, getProviderName()).get();
/*  84: 84 */     NodePropertySetBuilder b = new NodePropertySetBuilder();
/*  85: 85 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(provider, "getSource", null)).display("Source").add();
/*  86: 86 */     ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsAsyncMode.class).select(provider, "getAsyncMode", null)).display("Async mode")).add();
/*  87: 87 */     ((NodePropertySetBuilder.DefaultStep)b.with(Boolean.class).select(provider, "isAvailable", null)).display("Available").add();
/*  88: 88 */     ((NodePropertySetBuilder.BooleanStep)b.withBoolean().select("Loadable", Boolean.valueOf(provider instanceof IDataSourceLoader))).add();
/*  89: 89 */     ((NodePropertySetBuilder.BooleanStep)b.withBoolean().select("Files as source", Boolean.valueOf(provider instanceof IFileLoader))).add();
/*  90: 90 */     result.add(b.build());
/*  91: 91 */     return result;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public Sheet createSheet(DataSource dataSource)
/*  95:    */   {
/*  96: 96 */     return createSheet(createSheetSets(dataSource));
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected List<Sheet.Set> createSheetSets(DataSource dataSource) {
/* 100:100 */     List<Sheet.Set> result = new ArrayList();
/* 101:101 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("DataSource");
/* 102:102 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(dataSource, "getProviderName", null)).display("Source").add();
/* 103:103 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(dataSource, "getVersion", null)).display("Version").add();
/* 104:104 */     Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, dataSource);
/* 105:105 */     if (loader.isPresent()) {
/* 106:106 */       Object bean = ((IDataSourceLoader)loader.get()).decodeBean(dataSource);
/* 107:    */       try { int j;
/* 108:108 */         int i; for (Iterator localIterator = createSheetSets(bean).iterator(); localIterator.hasNext(); 
/* 109:109 */             i < j)
/* 110:    */         {
/* 111:108 */           Sheet.Set set = (Sheet.Set)localIterator.next();
/* 112:109 */           Node.Property[] arrayOfProperty; j = (arrayOfProperty = set.getProperties()).length;i = 0; continue;Node.Property<?> o = arrayOfProperty[i];
/* 113:110 */           b.add(ForwardingNodeProperty.readOnly(o));i++;
/* 114:    */         }
/* 115:    */       }
/* 116:    */       catch (IntrospectionException ex)
/* 117:    */       {
/* 118:114 */         ErrorManager.getDefault().log(ex.getMessage());
/* 119:    */       }
/* 120:    */     }
/* 121:117 */     result.add(b.build());
/* 122:118 */     return result;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Sheet createSheet(DataSet dataSet)
/* 126:    */   {
/* 127:123 */     return createSheet(createSheetSets(dataSet));
/* 128:    */   }
/* 129:    */   
/* 130:    */   protected List<Sheet.Set> createSheetSets(DataSet dataSet) {
/* 131:127 */     List<Sheet.Set> result = Lists.newArrayList(createSheetSets(dataSet.getDataSource()));
/* 132:128 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("DataSet");
/* 133:129 */     ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(DataSet.Kind.class).select(dataSet, "getKind", null)).display("Kind")).add();
/* 134:130 */     fillParamProperties(b, dataSet);
/* 135:131 */     result.add(b.build());
/* 136:132 */     return result;
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected void fillParamProperties(NodePropertySetBuilder b, DataSet dataSet) {
/* 140:136 */     for (Map.Entry<String, String> o : dataSet.getParams().entrySet()) {
/* 141:137 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select((String)o.getKey(), (String)o.getValue())).add();
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean editBean(String title, Object bean) throws IntrospectionException
/* 146:    */   {
/* 147:143 */     Sheet sheet = createSheet(createSheetSets(bean));
/* 148:144 */     Image image = getIcon(1, false);
/* 149:145 */     return OpenIdePropertySheetBeanEditor.editSheet(sheet, title, image);
/* 150:    */   }
/* 151:    */   
/* 152:    */   protected List<Sheet.Set> createSheetSets(Object bean) throws IntrospectionException {
/* 153:149 */     List<Sheet.Set> result = new ArrayList();
/* 154:150 */     for (Node.PropertySet o : new BeanNode(bean).getPropertySets()) {
/* 155:151 */       Sheet.Set set = Sheet.createPropertiesSet();
/* 156:152 */       set.put(o.getProperties());
/* 157:153 */       result.add(set);
/* 158:    */     }
/* 159:155 */     return result;
/* 160:    */   }
/* 161:    */ }
