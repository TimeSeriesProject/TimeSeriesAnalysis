/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.nbdemetra.ui.Config;
/*   5:    */ import ec.nbdemetra.ui.INameable;
/*   6:    */ import ec.nbdemetra.ui.IReloadable;
/*   7:    */ import ec.nbdemetra.ui.interchange.Exportable;
/*   8:    */ import ec.nbdemetra.ui.nodes.FailSafeChildFactory;
/*   9:    */ import ec.nbdemetra.ui.nodes.NodeAnnotator.Support;
/*  10:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*  11:    */ import ec.tss.TsCollection;
/*  12:    */ import ec.tss.TsInformationType;
/*  13:    */ import ec.tss.datatransfer.DataTransfers;
/*  14:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  15:    */ import ec.tss.tsproviders.DataSet;
/*  16:    */ import ec.tss.tsproviders.DataSource;
/*  17:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*  18:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  19:    */ import ec.tss.tsproviders.TsProviders;
/*  20:    */ import java.awt.Image;
/*  21:    */ import java.awt.datatransfer.DataFlavor;
/*  22:    */ import java.awt.datatransfer.Transferable;
/*  23:    */ import java.awt.datatransfer.UnsupportedFlavorException;
/*  24:    */ import java.awt.event.ActionEvent;
/*  25:    */ import java.beans.IntrospectionException;
/*  26:    */ import java.io.File;
/*  27:    */ import java.io.IOException;
/*  28:    */ import java.util.List;
/*  29:    */ import javax.annotation.Nonnull;
/*  30:    */ import javax.swing.AbstractAction;
/*  31:    */ import javax.swing.Action;
/*  32:    */ import javax.swing.JButton;
/*  33:    */ import org.netbeans.api.actions.Closable;
/*  34:    */ import org.netbeans.api.actions.Editable;
/*  35:    */ import org.openide.DialogDisplayer;
/*  36:    */ import org.openide.NotifyDescriptor;
/*  37:    */ import org.openide.NotifyDescriptor.InputLine;
/*  38:    */ import org.openide.nodes.AbstractNode;
/*  39:    */ import org.openide.nodes.Children;
/*  40:    */ import org.openide.nodes.Node;
/*  41:    */ import org.openide.nodes.Sheet;
/*  42:    */ import org.openide.util.Exceptions;
/*  43:    */ import org.openide.util.Lookup;
/*  44:    */ import org.openide.util.datatransfer.ExTransferable;
/*  45:    */ import org.openide.util.datatransfer.ExTransferable.Single;
/*  46:    */ import org.openide.util.lookup.AbstractLookup;
/*  47:    */ import org.openide.util.lookup.InstanceContent;
/*  48:    */ import org.openide.util.lookup.Lookups;
/*  49:    */ import org.openide.util.lookup.ProxyLookup;
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ public final class DataSourceNode
/*  68:    */   extends AbstractNode
/*  69:    */ {
/*  70:    */   public static final String ACTION_PATH = "SourceNode";
/*  71:    */   
/*  72:    */   public DataSourceNode(@Nonnull DataSource dataSource)
/*  73:    */   {
/*  74: 74 */     this(dataSource, new InstanceContent());
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */   private DataSourceNode(DataSource dataSource, InstanceContent abilities)
/*  79:    */   {
/*  80: 80 */     super(Children.create(new DataSourceChildFactory(dataSource), true), new ProxyLookup(new Lookup[] { Lookups.singleton(dataSource), new AbstractLookup(abilities) }));
/*  81:    */     
/*  82:    */ 
/*  83: 83 */     abilities.add(DataSourceProviderBuddySupport.getDefault().get(dataSource));
/*  84: 84 */     abilities.add(new ReloadableImpl(null));
/*  85: 85 */     abilities.add(NodeAnnotator.Support.getDefault());
/*  86: 86 */     abilities.add(new NameableImpl(null));
/*  87: 87 */     if (TsProviders.lookup(IDataSourceLoader.class, dataSource).isPresent()) {
/*  88: 88 */       abilities.add(new EditableImpl(null));
/*  89: 89 */       abilities.add(new ClosableImpl(null));
/*  90: 90 */       abilities.add(new ExportableAsXmlImpl(null));
/*  91:    */     }
/*  92:    */     
/*  93:    */ 
/*  94: 94 */     IDataSourceProvider provider = (IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, dataSource).get();
/*  95: 95 */     setDisplayName(provider.getDisplayName(dataSource));
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Action[] getActions(boolean context)
/*  99:    */   {
/* 100:100 */     return Nodes.actionsForPath("SourceNode");
/* 101:    */   }
/* 102:    */   
/* 103:    */   @Deprecated
/* 104:    */   public void refreshAnnotation() {
/* 105:105 */     fireIconChange();
/* 106:106 */     fireOpenedIconChange();
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Image getIcon(int type)
/* 110:    */   {
/* 111:111 */     Image image = ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).getIcon((DataSource)getLookup().lookup(DataSource.class), type, false);
/* 112:112 */     return ((NodeAnnotator.Support)getLookup().lookup(NodeAnnotator.Support.class)).annotateIcon(this, image);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Image getOpenedIcon(int type)
/* 116:    */   {
/* 117:117 */     Image image = ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).getIcon((DataSource)getLookup().lookup(DataSource.class), type, true);
/* 118:118 */     return ((NodeAnnotator.Support)getLookup().lookup(NodeAnnotator.Support.class)).annotateIcon(this, image);
/* 119:    */   }
/* 120:    */   
/* 121:    */   protected Sheet createSheet()
/* 122:    */   {
/* 123:123 */     return ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).createSheet((DataSource)getLookup().lookup(DataSource.class));
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean canCopy()
/* 127:    */   {
/* 128:128 */     return true;
/* 129:    */   }
/* 130:    */   
/* 131:    */   private Transferable getData(TsInformationType type) throws IOException {
/* 132:132 */     Optional<TsCollection> data = TsProviders.getTsCollection((DataSource)getLookup().lookup(DataSource.class), type);
/* 133:133 */     if (data.isPresent()) {
/* 134:134 */       return TssTransferSupport.getDefault().fromTsCollection((TsCollection)data.get());
/* 135:    */     }
/* 136:136 */     throw new IOException("Cannot create the TS collection '" + getDisplayName() + "'; check the logs for further details.");
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */   public Transferable clipboardCopy()
/* 141:    */     throws IOException
/* 142:    */   {
/* 143:143 */     return getData(TsInformationType.All);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Transferable drag() throws IOException
/* 147:    */   {
/* 148:148 */     ExTransferable data = ExTransferable.create(getData(TsInformationType.Definition));
/* 149:    */     
/* 150:150 */     DataSource dataSource = (DataSource)getLookup().lookup(DataSource.class);
/* 151:151 */     Optional<File> file = TsProviders.tryGetFile(dataSource);
/* 152:152 */     if (file.isPresent()) {
/* 153:153 */       data.put(new LocalFileTransferable((File)file.get()));
/* 154:    */     }
/* 155:155 */     return data;
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static final class DataSourceChildFactory extends FailSafeChildFactory
/* 159:    */   {
/* 160:    */     private final DataSource dataSource;
/* 161:    */     
/* 162:    */     public DataSourceChildFactory(DataSource dataSource) {
/* 163:163 */       this.dataSource = dataSource;
/* 164:    */     }
/* 165:    */     
/* 166:    */     protected boolean tryCreateKeys(List<Object> list) throws Exception
/* 167:    */     {
/* 168:168 */       list.addAll(((IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, dataSource).get()).children(dataSource));
/* 169:169 */       return true;
/* 170:    */     }
/* 171:    */     
/* 172:    */     protected Node tryCreateNodeForKey(Object key) throws Exception
/* 173:    */     {
/* 174:174 */       return DataSetNode.create((DataSet)key);
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   private final class ReloadableImpl implements IReloadable {
/* 179:    */     private ReloadableImpl() {}
/* 180:    */     
/* 181:    */     public void reload() {
/* 182:182 */       setChildren(Children.create(new DataSourceNode.DataSourceChildFactory((DataSource)getLookup().lookup(DataSource.class)), true));
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   private final class NameableImpl implements INameable {
/* 187:    */     private NameableImpl() {}
/* 188:    */     
/* 189:    */     public void rename() {
/* 190:190 */       NotifyDescriptor.InputLine descriptor = new NotifyDescriptor.InputLine("New name:", "Rename DataSource");
/* 191:191 */       descriptor.setInputText(getDisplayName());
/* 192:192 */       descriptor.setAdditionalOptions(new Object[] { new JButton(new AbstractAction("Restore")
/* 193:    */       {
/* 194:    */         public void actionPerformed(ActionEvent e) {
/* 195:195 */           DataSource dataSource = (DataSource)getLookup().lookup(DataSource.class);
/* 196:196 */           setDisplayName(((IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, dataSource).get()).getDisplayName(dataSource));
/* 197:    */         }
/* 198:    */       }) });
/* 199:199 */       if (DialogDisplayer.getDefault().notify(descriptor) == NotifyDescriptor.OK_OPTION) {
/* 200:200 */         setDisplayName(descriptor.getInputText());
/* 201:    */       }
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   private final class ClosableImpl implements Closable {
/* 206:    */     private ClosableImpl() {}
/* 207:    */     
/* 208:    */     public boolean close() {
/* 209:209 */       DataSource dataSource = (DataSource)getLookup().lookup(DataSource.class);
/* 210:210 */       return ((IDataSourceLoader)TsProviders.lookup(IDataSourceLoader.class, dataSource).get()).close(dataSource);
/* 211:    */     }
/* 212:    */   }
/* 213:    */   
/* 214:    */   private final class EditableImpl implements Editable {
/* 215:    */     private EditableImpl() {}
/* 216:    */     
/* 217:    */     public void edit() {
/* 218:218 */       DataSource dataSource = (DataSource)getLookup().lookup(DataSource.class);
/* 219:219 */       IDataSourceLoader loader = (IDataSourceLoader)TsProviders.lookup(IDataSourceLoader.class, dataSource).get();
/* 220:220 */       Object bean = loader.decodeBean(dataSource);
/* 221:    */       try {
/* 222:222 */         if (DataSourceProviderBuddySupport.getDefault().get(loader).editBean("Edit data source", bean)) {
/* 223:223 */           loader.close(dataSource);
/* 224:224 */           loader.open(loader.encodeBean(bean));
/* 225:    */         }
/* 226:    */       } catch (IntrospectionException ex) {
/* 227:227 */         Exceptions.printStackTrace(ex);
/* 228:    */       }
/* 229:    */     }
/* 230:    */   }
/* 231:    */   
/* 232:    */   private final class ExportableAsXmlImpl implements Exportable {
/* 233:    */     private ExportableAsXmlImpl() {}
/* 234:    */     
/* 235:    */     public Config exportConfig() {
/* 236:236 */       DataSource dataSource = (DataSource)getLookup().lookup(DataSource.class);
/* 237:237 */       return ProvidersUtil.getConfig(dataSource, getDisplayName());
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   private static final class LocalFileTransferable extends ExTransferable.Single
/* 242:    */   {
/* 243:243 */     private static final DataFlavor LOCAL_FILE_DATA_FLAVOR = DataTransfers.newLocalObjectDataFlavor(File.class);
/* 244:    */     private final File file;
/* 245:    */     
/* 246:    */     public LocalFileTransferable(@Nonnull File file) {
/* 247:247 */       super();
/* 248:248 */       this.file = file;
/* 249:    */     }
/* 250:    */     
/* 251:    */     protected Object getData() throws IOException, UnsupportedFlavorException
/* 252:    */     {
/* 253:253 */       return file;
/* 254:    */     }
/* 255:    */   }
/* 256:    */ }
