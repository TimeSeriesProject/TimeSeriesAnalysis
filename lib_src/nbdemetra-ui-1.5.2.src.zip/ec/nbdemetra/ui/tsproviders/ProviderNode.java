/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Throwables;
/*   6:    */ import ec.nbdemetra.ui.Config;
/*   7:    */ import ec.nbdemetra.ui.interchange.Importable;
/*   8:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*   9:    */ import ec.tss.datatransfer.DataSourceTransferSupport;
/*  10:    */ import ec.tss.tsproviders.DataSource;
/*  11:    */ import ec.tss.tsproviders.IDataSourceListener;
/*  12:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*  13:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  14:    */ import ec.tss.tsproviders.TsProviders;
/*  15:    */ import java.awt.Image;
/*  16:    */ import java.awt.datatransfer.Transferable;
/*  17:    */ import java.beans.IntrospectionException;
/*  18:    */ import java.io.IOException;
/*  19:    */ import java.util.List;
/*  20:    */ import javax.annotation.Nonnull;
/*  21:    */ import javax.swing.Action;
/*  22:    */ import org.netbeans.api.actions.Openable;
/*  23:    */ import org.openide.nodes.AbstractNode;
/*  24:    */ import org.openide.nodes.ChildFactory.Detachable;
/*  25:    */ import org.openide.nodes.Children;
/*  26:    */ import org.openide.nodes.Node;
/*  27:    */ import org.openide.nodes.Sheet;
/*  28:    */ import org.openide.util.Lookup;
/*  29:    */ import org.openide.util.datatransfer.PasteType;
/*  30:    */ import org.openide.util.lookup.AbstractLookup;
/*  31:    */ import org.openide.util.lookup.InstanceContent;
/*  32:    */ import org.openide.util.lookup.Lookups;
/*  33:    */ import org.openide.util.lookup.ProxyLookup;
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ public final class ProviderNode
/*  50:    */   extends AbstractNode
/*  51:    */ {
/*  52:    */   public static final String ACTION_PATH = "ProviderNode";
/*  53:    */   
/*  54:    */   public ProviderNode(@Nonnull IDataSourceProvider provider)
/*  55:    */   {
/*  56: 56 */     this(provider, new InstanceContent());
/*  57:    */   }
/*  58:    */   
/*  59:    */ 
/*  60:    */   private ProviderNode(IDataSourceProvider provider, InstanceContent abilities)
/*  61:    */   {
/*  62: 62 */     super(Children.create(new ProviderChildFactory(provider), true), new ProxyLookup(new Lookup[] { Lookups.singleton(provider), new AbstractLookup(abilities) }));
/*  63:    */     
/*  64:    */ 
/*  65: 65 */     abilities.add(DataSourceProviderBuddySupport.getDefault().get(provider));
/*  66: 66 */     if ((provider instanceof IDataSourceLoader)) {
/*  67: 67 */       abilities.add(new OpenableImpl(null));
/*  68: 68 */       abilities.add(new ImportableAsXmlImpl(null));
/*  69:    */     }
/*  70:    */     
/*  71:    */ 
/*  72: 72 */     setName(provider.getSource());
/*  73: 73 */     setDisplayName(provider.getDisplayName());
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Action[] getActions(boolean context)
/*  77:    */   {
/*  78: 78 */     return Nodes.actionsForPath("ProviderNode");
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Image getIcon(int type)
/*  82:    */   {
/*  83: 83 */     return ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).getIcon(type, false);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Image getOpenedIcon(int type)
/*  87:    */   {
/*  88: 88 */     return ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).getIcon(type, true);
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected Sheet createSheet()
/*  92:    */   {
/*  93: 93 */     return ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).createSheet();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public PasteType getDropType(Transferable t, int action, int index)
/*  97:    */   {
/*  98: 98 */     IDataSourceLoader loader = (IDataSourceLoader)getLookup().lookup(IDataSourceLoader.class);
/*  99: 99 */     if ((loader != null) && (DataSourceTransferSupport.getDefault().canHandle(t, loader.getSource()))) {
/* 100:100 */       return new PasteTypeImpl(t, loader);
/* 101:    */     }
/* 102:102 */     return null;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void paste(DataSource dataSource) {
/* 106:106 */     IDataSourceLoader loader = (IDataSourceLoader)getLookup().lookup(IDataSourceLoader.class);
/* 107:107 */     Preconditions.checkArgument(loader != null);
/* 108:108 */     Preconditions.checkArgument(dataSource.getProviderName().equals(loader.getSource()));
/* 109:109 */     loader.open(dataSource);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean canCopy()
/* 113:    */   {
/* 114:114 */     return false;
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static final class ProviderChildFactory extends ChildFactory.Detachable<DataSource> implements IDataSourceListener
/* 118:    */   {
/* 119:    */     private final IDataSourceProvider provider;
/* 120:    */     
/* 121:    */     public ProviderChildFactory(IDataSourceProvider provider) {
/* 122:122 */       this.provider = provider;
/* 123:    */     }
/* 124:    */     
/* 125:    */     protected void addNotify()
/* 126:    */     {
/* 127:127 */       provider.addDataSourceListener(this);
/* 128:    */     }
/* 129:    */     
/* 130:    */     protected void removeNotify()
/* 131:    */     {
/* 132:132 */       provider.removeDataSourceListener(this);
/* 133:    */     }
/* 134:    */     
/* 135:    */     protected boolean createKeys(List<DataSource> list)
/* 136:    */     {
/* 137:137 */       list.addAll(provider.getDataSources());
/* 138:138 */       return true;
/* 139:    */     }
/* 140:    */     
/* 141:    */     protected Node createNodeForKey(DataSource key)
/* 142:    */     {
/* 143:143 */       return new DataSourceNode(key);
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void opened(DataSource dataSource)
/* 147:    */     {
/* 148:148 */       refresh(true);
/* 149:    */     }
/* 150:    */     
/* 151:    */     public void closed(DataSource dataSource)
/* 152:    */     {
/* 153:153 */       refresh(true);
/* 154:    */     }
/* 155:    */     
/* 156:    */     public void changed(DataSource dataSource)
/* 157:    */     {
/* 158:158 */       refresh(true);
/* 159:    */     }
/* 160:    */     
/* 161:    */     public void allClosed(String providerName)
/* 162:    */     {
/* 163:163 */       refresh(true);
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   private final class OpenableImpl implements Openable {
/* 168:    */     private OpenableImpl() {}
/* 169:    */     
/* 170:    */     public void open() {
/* 171:171 */       IDataSourceLoader loader = (IDataSourceLoader)getLookup().lookup(IDataSourceLoader.class);
/* 172:172 */       Object bean = loader.newBean();
/* 173:    */       try {
/* 174:174 */         if (((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).editBean("Open data source", bean)) {
/* 175:175 */           loader.open(loader.encodeBean(bean));
/* 176:    */         }
/* 177:    */       } catch (IntrospectionException ex) {
/* 178:178 */         throw Throwables.propagate(ex);
/* 179:    */       }
/* 180:    */     }
/* 181:    */   }
/* 182:    */   
/* 183:    */   private final class ImportableAsXmlImpl implements Importable {
/* 184:    */     private ImportableAsXmlImpl() {}
/* 185:    */     
/* 186:    */     public String getDomain() {
/* 187:187 */       return ProvidersUtil.getDataSourceDomain();
/* 188:    */     }
/* 189:    */     
/* 190:    */     public void importConfig(Config config) throws IllegalArgumentException
/* 191:    */     {
/* 192:192 */       DataSource dataSource = ProvidersUtil.getDataSource(config);
/* 193:193 */       Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, dataSource);
/* 194:194 */       if (loader.isPresent()) {
/* 195:195 */         ((IDataSourceLoader)loader.get()).open(dataSource);
/* 196:196 */         Optional<Node> node = ProvidersUtil.findNode(dataSource, ProviderNode.this);
/* 197:197 */         if (node.isPresent()) {
/* 198:198 */           ((Node)node.get()).setDisplayName(config.getName());
/* 199:    */         }
/* 200:    */       }
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   private static final class PasteTypeImpl extends PasteType
/* 205:    */   {
/* 206:    */     private final Transferable t;
/* 207:    */     private final IDataSourceLoader loader;
/* 208:    */     
/* 209:    */     public PasteTypeImpl(Transferable t, IDataSourceLoader loader) {
/* 210:210 */       this.t = t;
/* 211:211 */       this.loader = loader;
/* 212:    */     }
/* 213:    */     
/* 214:    */     public Transferable paste() throws IOException
/* 215:    */     {
/* 216:216 */       Optional<DataSource> dataSource = DataSourceTransferSupport.getDefault().getDataSource(t, loader.getSource());
/* 217:217 */       if (dataSource.isPresent()) {
/* 218:218 */         loader.open((DataSource)dataSource.get());
/* 219:    */       }
/* 220:220 */       return null;
/* 221:    */     }
/* 222:    */   }
/* 223:    */ }
