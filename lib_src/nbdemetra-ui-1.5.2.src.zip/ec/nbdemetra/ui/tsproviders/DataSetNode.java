/*   1:    */ package ec.nbdemetra.ui.tsproviders;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.nbdemetra.ui.IReloadable;
/*   5:    */ import ec.nbdemetra.ui.nodes.FailSafeChildFactory;
/*   6:    */ import ec.nbdemetra.ui.nodes.NodeAnnotator.Support;
/*   7:    */ import ec.nbdemetra.ui.nodes.Nodes;
/*   8:    */ import ec.tss.tsproviders.DataSet;
/*   9:    */ import ec.tss.tsproviders.DataSet.Kind;
/*  10:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  11:    */ import ec.tss.tsproviders.TsProviders;
/*  12:    */ import java.awt.Image;
/*  13:    */ import java.util.List;
/*  14:    */ import javax.annotation.Nonnull;
/*  15:    */ import javax.swing.Action;
/*  16:    */ import org.openide.nodes.AbstractNode;
/*  17:    */ import org.openide.nodes.Children;
/*  18:    */ import org.openide.nodes.Node;
/*  19:    */ import org.openide.nodes.Sheet;
/*  20:    */ import org.openide.util.Lookup;
/*  21:    */ import org.openide.util.lookup.AbstractLookup;
/*  22:    */ import org.openide.util.lookup.InstanceContent;
/*  23:    */ import org.openide.util.lookup.Lookups;
/*  24:    */ import org.openide.util.lookup.ProxyLookup;
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public abstract class DataSetNode
/*  47:    */   extends AbstractNode
/*  48:    */ {
/*  49:    */   private final String actionPath;
/*  50:    */   
/*  51:    */   @Nonnull
/*  52:    */   public static DataSetNode create(@Nonnull DataSet dataSet)
/*  53:    */   {
/*  54: 54 */     switch (dataSet.getKind()) {
/*  55:    */     case DUMMY: 
/*  56: 56 */       return new CollectionNode(dataSet);
/*  57:    */     case COLLECTION: 
/*  58: 58 */       return new SeriesNode(dataSet);
/*  59:    */     }
/*  60: 60 */     throw new RuntimeException("Not implemented ?");
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */   public DataSetNode(@Nonnull DataSet dataSet, @Nonnull String actionPath)
/*  65:    */   {
/*  66: 66 */     this(dataSet, new InstanceContent(), actionPath);
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70:    */   private DataSetNode(DataSet dataSet, InstanceContent abilities, String actionPath)
/*  71:    */   {
/*  72: 72 */     super(dataSet.getKind() == DataSet.Kind.COLLECTION ? Children.create(new DataSetChildFactory(dataSet), true) : Children.LEAF, new ProxyLookup(new Lookup[] { Lookups.singleton(dataSet), new AbstractLookup(abilities) }));
/*  73: 73 */     this.actionPath = actionPath;
/*  74:    */     
/*  75:    */ 
/*  76: 76 */     abilities.add(DataSourceProviderBuddySupport.getDefault().get(dataSet));
/*  77: 77 */     if (dataSet.getKind() == DataSet.Kind.COLLECTION) {
/*  78: 78 */       abilities.add(new ReloadableImpl(null));
/*  79:    */     }
/*  80: 80 */     abilities.add(NodeAnnotator.Support.getDefault());
/*  81:    */     
/*  82:    */ 
/*  83: 83 */     setDisplayName(((IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, dataSet).get()).getDisplayNodeName(dataSet));
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Action[] getActions(boolean context)
/*  87:    */   {
/*  88: 88 */     return Nodes.actionsForPath(actionPath);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Image getIcon(int type)
/*  92:    */   {
/*  93: 93 */     Image image = ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).getIcon((DataSet)getLookup().lookup(DataSet.class), type, false);
/*  94: 94 */     return ((NodeAnnotator.Support)getLookup().lookup(NodeAnnotator.Support.class)).annotateIcon(this, image);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public Image getOpenedIcon(int type)
/*  98:    */   {
/*  99: 99 */     Image image = ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).getIcon((DataSet)getLookup().lookup(DataSet.class), type, true);
/* 100:100 */     return ((NodeAnnotator.Support)getLookup().lookup(NodeAnnotator.Support.class)).annotateIcon(this, image);
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected Sheet createSheet()
/* 104:    */   {
/* 105:105 */     return ((IDataSourceProviderBuddy)getLookup().lookup(IDataSourceProviderBuddy.class)).createSheet((DataSet)getLookup().lookup(DataSet.class));
/* 106:    */   }
/* 107:    */   
/* 108:    */   public boolean canCopy()
/* 109:    */   {
/* 110:110 */     return true;
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static final class DataSetChildFactory extends FailSafeChildFactory
/* 114:    */   {
/* 115:    */     private final DataSet dataSet;
/* 116:    */     
/* 117:    */     public DataSetChildFactory(DataSet dataSet) {
/* 118:118 */       this.dataSet = dataSet;
/* 119:    */     }
/* 120:    */     
/* 121:    */     protected boolean tryCreateKeys(List<Object> list) throws Exception
/* 122:    */     {
/* 123:123 */       list.addAll(((IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, dataSet).get()).children(dataSet));
/* 124:124 */       return true;
/* 125:    */     }
/* 126:    */     
/* 127:    */     protected Node tryCreateNodeForKey(Object key) throws Exception
/* 128:    */     {
/* 129:129 */       return DataSetNode.create((DataSet)key);
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   private final class ReloadableImpl implements IReloadable {
/* 134:    */     private ReloadableImpl() {}
/* 135:    */     
/* 136:    */     public void reload() {
/* 137:137 */       setChildren(Children.create(new DataSetNode.DataSetChildFactory((DataSet)getLookup().lookup(DataSet.class)), true));
/* 138:    */     }
/* 139:    */   }
/* 140:    */ }
