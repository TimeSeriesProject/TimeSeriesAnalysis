package ec.nbdemetra.ui.tsproviders;

import ec.tss.tsproviders.DataSet;
import ec.tss.tsproviders.DataSource;
import java.awt.Image;
import java.beans.IntrospectionException;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.openide.nodes.Sheet;

public abstract interface IDataSourceProviderBuddy
{
  @Nonnull
  public abstract String getProviderName();
  
  @Nullable
  public abstract Image getIcon(int paramInt, boolean paramBoolean);
  
  @Nullable
  public abstract Image getIcon(@Nonnull DataSource paramDataSource, int paramInt, boolean paramBoolean);
  
  @Nullable
  public abstract Image getIcon(@Nonnull DataSet paramDataSet, int paramInt, boolean paramBoolean);
  
  @Nonnull
  public abstract Sheet createSheet();
  
  @Nonnull
  public abstract Sheet createSheet(@Nonnull DataSource paramDataSource);
  
  @Nonnull
  public abstract Sheet createSheet(@Nonnull DataSet paramDataSet);
  
  public abstract boolean editBean(@Nonnull String paramString, @Nonnull Object paramObject)
    throws IntrospectionException;
}
