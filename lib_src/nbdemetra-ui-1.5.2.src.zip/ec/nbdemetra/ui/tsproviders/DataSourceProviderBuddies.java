/*  1:   */ package ec.nbdemetra.ui.tsproviders;
/*  2:   */ 
/*  3:   */ import ec.tss.tsproviders.DataSet;
/*  4:   */ import ec.tss.tsproviders.DataSource;
/*  5:   */ import ec.tss.tsproviders.IDataSourceProvider;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ @Deprecated
/* 33:   */ public final class DataSourceProviderBuddies
/* 34:   */ {
/* 35:   */   @Deprecated
/* 36:   */   public static IDataSourceProviderBuddy get(String providerName)
/* 37:   */   {
/* 38:38 */     return DataSourceProviderBuddySupport.getDefault().get(providerName);
/* 39:   */   }
/* 40:   */   
/* 41:   */   @Deprecated
/* 42:   */   public static IDataSourceProviderBuddy get(IDataSourceProvider provider) {
/* 43:43 */     return get(provider.getSource());
/* 44:   */   }
/* 45:   */   
/* 46:   */   @Deprecated
/* 47:   */   public static IDataSourceProviderBuddy get(DataSource dataSource) {
/* 48:48 */     return get(dataSource.getProviderName());
/* 49:   */   }
/* 50:   */   
/* 51:   */   @Deprecated
/* 52:   */   public static IDataSourceProviderBuddy get(DataSet dataSet) {
/* 53:53 */     return get(dataSet.getDataSource());
/* 54:   */   }
/* 55:   */ }
