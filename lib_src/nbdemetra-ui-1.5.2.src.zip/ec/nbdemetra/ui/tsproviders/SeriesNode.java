/*  1:   */ package ec.nbdemetra.ui.tsproviders;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.DemetraUI;
/*  5:   */ import ec.nbdemetra.ui.tsaction.ITsAction;
/*  6:   */ import ec.tss.Ts;
/*  7:   */ import ec.tss.TsInformationType;
/*  8:   */ import ec.tss.datatransfer.TssTransferSupport;
/*  9:   */ import ec.tss.tsproviders.DataSet;
/* 10:   */ import ec.tss.tsproviders.TsProviders;
/* 11:   */ import java.awt.datatransfer.Transferable;
/* 12:   */ import java.awt.event.ActionEvent;
/* 13:   */ import java.io.IOException;
/* 14:   */ import javax.annotation.Nonnull;
/* 15:   */ import javax.swing.AbstractAction;
/* 16:   */ import javax.swing.Action;
/* 17:   */ import org.openide.util.Lookup;
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public final class SeriesNode
/* 36:   */   extends DataSetNode
/* 37:   */ {
/* 38:   */   public static final String ACTION_PATH = "SeriesNode";
/* 39:   */   
/* 40:   */   public SeriesNode(@Nonnull DataSet dataSet)
/* 41:   */   {
/* 42:42 */     super(dataSet, "SeriesNode");
/* 43:   */   }
/* 44:   */   
/* 45:   */   private Transferable getData(TsInformationType type) throws IOException {
/* 46:46 */     Optional<Ts> data = TsProviders.getTs((DataSet)getLookup().lookup(DataSet.class), type);
/* 47:47 */     if (data.isPresent()) {
/* 48:48 */       return TssTransferSupport.getDefault().fromTs((Ts)data.get());
/* 49:   */     }
/* 50:50 */     throw new IOException("Cannot create the TS '" + getDisplayName() + "'; check the logs for further details.");
/* 51:   */   }
/* 52:   */   
/* 53:   */ 
/* 54:   */   public Transferable clipboardCopy()
/* 55:   */     throws IOException
/* 56:   */   {
/* 57:57 */     return getData(TsInformationType.All);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public Transferable drag() throws IOException
/* 61:   */   {
/* 62:62 */     return getData(TsInformationType.Definition);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Action getPreferredAction()
/* 66:   */   {
/* 67:67 */     new AbstractAction()
/* 68:   */     {
/* 69:   */       public void actionPerformed(ActionEvent e) {
/* 70:70 */         Optional<Ts> data = TsProviders.getTs((DataSet)getLookup().lookup(DataSet.class), TsInformationType.Data);
/* 71:71 */         if (data.isPresent()) {
/* 72:72 */           DemetraUI.getDefault().getTsAction().open((Ts)data.get());
/* 73:   */         }
/* 74:   */       }
/* 75:   */     };
/* 76:   */   }
/* 77:   */ }
