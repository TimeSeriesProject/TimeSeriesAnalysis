/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.tsaction.ITsView2;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceFactory.Event;
/*  7:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  8:   */ import ec.tss.Ts;
/*  9:   */ import ec.tss.documents.TsDocument;
/* 10:   */ import ec.ui.view.tsprocessing.TsProcessingViewer;
/* 11:   */ import java.util.Collection;
/* 12:   */ import java.util.Iterator;
/* 13:   */ import javax.swing.JMenu;
/* 14:   */ import javax.swing.SwingUtilities;
/* 15:   */ import org.openide.explorer.ExplorerManager;
/* 16:   */ import org.openide.explorer.ExplorerManager.Provider;
/* 17:   */ import org.openide.util.Lookup;
/* 18:   */ import org.openide.util.Lookup.Result;
/* 19:   */ import org.openide.util.LookupEvent;
/* 20:   */ import org.openide.util.LookupListener;
/* 21:   */ import org.openide.windows.TopComponent;
/* 22:   */ 
/* 23:   */ public abstract class TsTopComponent extends TopComponent implements ExplorerManager.Provider, IActiveView, ITsView2, LookupListener
/* 24:   */ {
/* 25:   */   protected Lookup.Result<WorkspaceFactory.Event> result;
/* 26:   */   protected TsProcessingViewer panel;
/* 27:   */   
/* 28:   */   public ExplorerManager getExplorerManager()
/* 29:   */   {
/* 30:30 */     return ActiveViewManager.getInstance().getExplorerManager();
/* 31:   */   }
/* 32:   */   
/* 33:   */ 
/* 34:   */   protected TsTopComponent()
/* 35:   */   {
/* 36:36 */     result = WorkspaceFactory.getInstance().getLookup().lookupResult(WorkspaceFactory.Event.class);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void refresh() {
/* 40:40 */     panel.refreshAll();
/* 41:   */   }
/* 42:   */   
/* 43:   */   public boolean fill(JMenu menu)
/* 44:   */   {
/* 45:45 */     return true;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void componentOpened()
/* 49:   */   {
/* 50:50 */     result.addLookupListener(this);
/* 51:   */   }
/* 52:   */   
/* 53:   */ 
/* 54:   */   public void componentClosed()
/* 55:   */   {
/* 56:56 */     if (panel != null) {
/* 57:57 */       panel.dispose();
/* 58:   */     }
/* 59:59 */     result.removeLookupListener(this);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public Ts getTs()
/* 63:   */   {
/* 64:64 */     return ((TsDocument)panel.getDocument()).getTs();
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setTs(Ts ts)
/* 68:   */   {
/* 69:69 */     ((TsDocument)panel.getDocument()).setTs(ts);
/* 70:70 */     panel.refreshAll();
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void resultChanged(LookupEvent le)
/* 74:   */   {
/* 75:75 */     Collection<? extends WorkspaceFactory.Event> all = result.allInstances();
/* 76:76 */     if (!all.isEmpty()) {
/* 77:77 */       Iterator<? extends WorkspaceFactory.Event> iterator = all.iterator();
/* 78:78 */       while (iterator.hasNext()) {
/* 79:79 */         WorkspaceFactory.Event ev = (WorkspaceFactory.Event)iterator.next();
/* 80:80 */         if (info == 13) {
/* 81:81 */           WorkspaceItem<?> wdoc = workspace.searchDocument(id);
/* 82:82 */           if (wdoc.getElement() == panel.getDocument()) {
/* 83:83 */             SwingUtilities.invokeLater(new Runnable()
/* 84:   */             {
/* 85:   */               public void run()
/* 86:   */               {
/* 87:87 */                 close();
/* 88:   */               }
/* 89:   */             });
/* 90:   */           }
/* 91:91 */         } else if ((info == 16) && 
/* 92:92 */           (source != this)) {
/* 93:93 */           WorkspaceItem<?> wdoc = workspace.searchDocument(id);
/* 94:94 */           if (wdoc.getElement() == panel.getDocument()) {
/* 95:95 */             SwingUtilities.invokeLater(new Runnable()
/* 96:   */             {
/* 97:   */               public void run() {
/* 98:98 */                 refresh();
/* 99:   */               }
/* :0:   */             });
/* :1:   */           }
/* :2:   */         }
/* :3:   */       }
/* :4:   */     }
/* :5:   */   }
/* :6:   */ }
