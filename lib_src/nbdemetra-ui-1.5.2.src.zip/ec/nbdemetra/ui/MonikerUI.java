/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.tsproviders.DataSourceProviderBuddySupport;
/*  4:   */ import ec.nbdemetra.ui.tsproviders.IDataSourceProviderBuddy;
/*  5:   */ import ec.tss.Ts;
/*  6:   */ import ec.tss.TsMoniker;
/*  7:   */ import ec.tss.TsStatus;
/*  8:   */ import ec.tss.tsproviders.DataSet;
/*  9:   */ import ec.tss.tsproviders.DataSource;
/* 10:   */ import java.awt.Image;
/* 11:   */ import javax.annotation.Nonnull;
/* 12:   */ import javax.swing.Icon;
/* 13:   */ import org.openide.util.ImageUtilities;
/* 14:   */ import org.openide.util.Lookup;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class MonikerUI
/* 29:   */ {
/* 30:   */   @Nonnull
/* 31:   */   public static MonikerUI getDefault()
/* 32:   */   {
/* 33:33 */     return (MonikerUI)Lookup.getDefault().lookup(MonikerUI.class);
/* 34:   */   }
/* 35:   */   
/* 36:36 */   final Image badge = ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/exclamation-small-red.png", false);
/* 37:   */   
/* 38:   */ 
/* 39:   */ 
/* 40:   */   Image getImage(String providerName)
/* 41:   */   {
/* 42:42 */     return DataSourceProviderBuddySupport.getDefault().get(providerName).getIcon(1, false);
/* 43:   */   }
/* 44:   */   
/* 45:   */   Icon getIcon(String providerName) {
/* 46:46 */     return ImageUtilities.image2Icon(getImage(providerName));
/* 47:   */   }
/* 48:   */   
/* 49:   */   public Icon getIcon(TsMoniker moniker) {
/* 50:50 */     return getIcon(moniker.getSource());
/* 51:   */   }
/* 52:   */   
/* 53:   */   public Icon getIcon(DataSet dataSet) {
/* 54:54 */     return getIcon(dataSet.getDataSource());
/* 55:   */   }
/* 56:   */   
/* 57:   */   public Icon getIcon(DataSource dataSource) {
/* 58:58 */     return getIcon(dataSource.getProviderName());
/* 59:   */   }
/* 60:   */   
/* 61:   */   public Image getImage(Ts ts) {
/* 62:62 */     Image image = getImage(ts.getMoniker().getSource());
/* 63:63 */     return ts.hasData() == TsStatus.Invalid ? ImageUtilities.mergeImages(image, badge, 0, 0) : image;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public Icon getIcon(Ts ts) {
/* 67:67 */     return ImageUtilities.image2Icon(getImage(ts));
/* 68:   */   }
/* 69:   */ }
