/*  1:   */ package ec.nbdemetra.ui.mru;
/*  2:   */ 
/*  3:   */ import ec.tss.tsproviders.DataSource;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public final class SourceId
/* 13:   */ {
/* 14:   */   final DataSource dataSource;
/* 15:   */   final String label;
/* 16:   */   
/* 17:   */   public SourceId(DataSource dataSource, String label)
/* 18:   */   {
/* 19:19 */     this.dataSource = dataSource;
/* 20:20 */     this.label = label;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public DataSource getDataSource() {
/* 24:24 */     return dataSource;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getLabel() {
/* 28:28 */     return label;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int hashCode()
/* 32:   */   {
/* 33:33 */     return dataSource.hashCode();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean equals(Object obj)
/* 37:   */   {
/* 38:38 */     return (this == obj) || (((obj instanceof SourceId)) && (equals((SourceId)obj)));
/* 39:   */   }
/* 40:   */   
/* 41:   */   private boolean equals(SourceId that) {
/* 42:42 */     return dataSource.equals(dataSource);
/* 43:   */   }
/* 44:   */ }
