/*  1:   */ package ec.nbdemetra.ui.mru;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.awt.ListenableBean;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ import java.util.Iterator;
/*  6:   */ import java.util.List;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public final class MruList
/* 27:   */   extends ListenableBean
/* 28:   */   implements Iterable<SourceId>
/* 29:   */ {
/* 30:   */   public static final String CONTENT_PROPERTY = "123";
/* 31:31 */   private static final MruList PROVIDERS = new MruList();
/* 32:32 */   private static final MruList WORKSPACES = new MruList();
/* 33:   */   private final List<SourceId> list;
/* 34:   */   
/* 35:35 */   public static MruList getProvidersInstance() { return PROVIDERS; }
/* 36:   */   
/* 37:   */   public static MruList getWorkspacesInstance()
/* 38:   */   {
/* 39:39 */     return WORKSPACES;
/* 40:   */   }
/* 41:   */   
/* 42:   */ 
/* 43:   */   private int maxSize;
/* 44:   */   private MruList()
/* 45:   */   {
/* 46:46 */     maxSize = 9;
/* 47:47 */     list = new ArrayList(maxSize);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void clear() {
/* 51:51 */     list.clear();
/* 52:52 */     firePropertyChange("123", null, list);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public boolean isEmpty() {
/* 56:56 */     return list.isEmpty();
/* 57:   */   }
/* 58:   */   
/* 59:   */   public int getMaxSize() {
/* 60:60 */     return maxSize;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void add(SourceId item)
/* 64:   */   {
/* 65:65 */     list.remove(item);
/* 66:   */     
/* 67:   */ 
/* 68:68 */     list.add(0, item);
/* 69:69 */     while (list.size() > maxSize) {
/* 70:70 */       list.remove(list.size() - 1);
/* 71:   */     }
/* 72:72 */     firePropertyChange("123", null, list);
/* 73:   */   }
/* 74:   */   
/* 75:   */   public Iterator<SourceId> iterator()
/* 76:   */   {
/* 77:77 */     return list.iterator();
/* 78:   */   }
/* 79:   */ }
