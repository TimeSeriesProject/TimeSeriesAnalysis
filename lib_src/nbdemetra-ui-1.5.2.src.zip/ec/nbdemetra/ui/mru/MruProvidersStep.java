/*  1:   */ package ec.nbdemetra.ui.mru;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import com.google.common.collect.FluentIterable;
/*  5:   */ import ec.nbdemetra.core.InstallerStep.LookupStep;
/*  6:   */ import ec.tss.tsproviders.DataSource;
/*  7:   */ import ec.tss.tsproviders.IDataSourceProvider;
/*  8:   */ import ec.tss.tsproviders.TsProviders;
/*  9:   */ import ec.tss.tsproviders.utils.DataSourceAdapter;
/* 10:   */ import java.util.prefs.Preferences;
/* 11:   */ import org.openide.util.Lookup.Result;
/* 12:   */ import org.openide.util.NbPreferences;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public class MruProvidersStep
/* 20:   */   extends InstallerStep.LookupStep<IDataSourceProvider>
/* 21:   */ {
/* 22:22 */   final Preferences prefs = NbPreferences.forModule(MruWorkspacesStep.class).node("Mru");
/* 23:   */   final Listener listener;
/* 24:   */   
/* 25:   */   public MruProvidersStep() {
/* 26:26 */     super(IDataSourceProvider.class);
/* 27:27 */     listener = new Listener();
/* 28:   */   }
/* 29:   */   
/* 30:   */ 
/* 31:   */   protected void onResultChanged(Lookup.Result<IDataSourceProvider> lookup)
/* 32:   */   {
/* 33:33 */     for (IDataSourceProvider o : TsProviders.all().filter(IDataSourceProvider.class)) {
/* 34:34 */       o.addDataSourceListener(listener);
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected void onRestore(Lookup.Result<IDataSourceProvider> lookup)
/* 39:   */   {
/* 40:40 */     MruPreferences.INSTANCE.load(prefs, MruList.getProvidersInstance());
/* 41:41 */     for (IDataSourceProvider o : TsProviders.all().filter(IDataSourceProvider.class)) {
/* 42:42 */       o.addDataSourceListener(listener);
/* 43:   */     }
/* 44:   */   }
/* 45:   */   
/* 46:   */   protected void onClose(Lookup.Result<IDataSourceProvider> lookup)
/* 47:   */   {
/* 48:48 */     for (IDataSourceProvider o : TsProviders.all().filter(IDataSourceProvider.class)) {
/* 49:49 */       o.removeDataSourceListener(listener);
/* 50:   */     }
/* 51:51 */     MruPreferences.INSTANCE.store(prefs, MruList.getProvidersInstance());
/* 52:   */   }
/* 53:   */   
/* 54:   */   static class Listener extends DataSourceAdapter
/* 55:   */   {
/* 56:   */     public void opened(DataSource dataSource)
/* 57:   */     {
/* 58:58 */       IDataSourceProvider provider = (IDataSourceProvider)TsProviders.lookup(IDataSourceProvider.class, dataSource).get();
/* 59:59 */       MruList.getProvidersInstance().add(new SourceId(dataSource, provider.getDisplayName(dataSource)));
/* 60:   */     }
/* 61:   */   }
/* 62:   */ }
