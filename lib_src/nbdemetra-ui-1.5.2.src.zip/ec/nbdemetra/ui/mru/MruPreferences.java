/*  1:   */ package ec.nbdemetra.ui.mru;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import com.google.common.collect.ImmutableList;
/*  5:   */ import com.google.common.collect.Ordering;
/*  6:   */ import ec.tss.tsproviders.DataSource;
/*  7:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  8:   */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  9:   */ import java.util.Arrays;
/* 10:   */ import java.util.prefs.BackingStoreException;
/* 11:   */ import java.util.prefs.Preferences;
/* 12:   */ import org.slf4j.Logger;
/* 13:   */ import org.slf4j.LoggerFactory;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */  enum MruPreferences
/* 23:   */ {
/* 24:24 */   INSTANCE;
/* 25:   */   
/* 26:26 */   private static final Logger LOGGER = LoggerFactory.getLogger(MruPreferences.class);
/* 27:   */   private static final String DATASOURCE_PROPERTY = "MruDataSource";
/* 28:   */   private static final String LABEL_PROPERTY = "MruLabel";
/* 29:   */   
/* 30:   */   public void load(Preferences prefs, MruList list) {
/* 31:31 */     Parsers.Parser<DataSource> parser = DataSource.xmlParser();
/* 32:   */     try {
/* 33:33 */       for (String o : Ordering.natural().immutableSortedCopy(Arrays.asList(prefs.childrenNames())).reverse()) {
/* 34:34 */         Preferences node = prefs.node(o);
/* 35:35 */         String tmp = node.get("MruDataSource", null);
/* 36:36 */         if (tmp != null)
/* 37:   */         {
/* 38:   */ 
/* 39:39 */           Optional<DataSource> dataSource = parser.tryParse(tmp);
/* 40:40 */           if (dataSource.isPresent())
/* 41:   */           {
/* 42:   */ 
/* 43:43 */             String label = node.get("MruLabel", null);
/* 44:44 */             if (label != null)
/* 45:   */             {
/* 46:   */ 
/* 47:47 */               list.add(new SourceId((DataSource)dataSource.get(), label)); }
/* 48:   */           }
/* 49:   */         }
/* 50:50 */       } } catch (BackingStoreException ex) { LOGGER.warn("Can't get node list", ex);
/* 51:   */     }
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void store(Preferences prefs, MruList list)
/* 55:   */   {
/* 56:56 */     clear(prefs);
/* 57:57 */     Formatters.Formatter<DataSource> formatter = DataSource.xmlFormatter(false);
/* 58:58 */     int i = 0;
/* 59:59 */     for (SourceId o : list) {
/* 60:60 */       Preferences node = prefs.node(String.valueOf(i++));
/* 61:61 */       node.put("MruDataSource", (String)formatter.tryFormatAsString(o.getDataSource()).get());
/* 62:62 */       node.put("MruLabel", o.getLabel());
/* 63:   */     }
/* 64:   */     try {
/* 65:65 */       prefs.flush();
/* 66:   */     } catch (BackingStoreException ex) {
/* 67:67 */       LOGGER.warn("Can't flush storage", ex);
/* 68:   */     }
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void clear(Preferences prefs) {
/* 72:   */     try {
/* 73:73 */       prefs.clear();
/* 74:74 */       for (String i : prefs.childrenNames()) {
/* 75:75 */         prefs.node(i).removeNode();
/* 76:   */       }
/* 77:   */     } catch (BackingStoreException ex) {
/* 78:78 */       LOGGER.warn("Can't clear storage", ex);
/* 79:   */     }
/* 80:   */   }
/* 81:   */ }
