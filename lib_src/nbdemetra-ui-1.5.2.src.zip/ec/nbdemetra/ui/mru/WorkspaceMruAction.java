/*   1:    */ package ec.nbdemetra.ui.mru;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ws.IWorkspaceRepository;
/*   4:    */ import ec.nbdemetra.ws.Workspace;
/*   5:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   6:    */ import ec.tss.tsproviders.DataSource;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import javax.swing.AbstractAction;
/*  11:    */ import javax.swing.Action;
/*  12:    */ import javax.swing.JComponent;
/*  13:    */ import javax.swing.JMenu;
/*  14:    */ import javax.swing.JMenuItem;
/*  15:    */ import javax.swing.JSeparator;
/*  16:    */ import org.openide.awt.DynamicMenuContent;
/*  17:    */ import org.openide.util.WeakListeners;
/*  18:    */ import org.openide.util.actions.Presenter.Menu;
/*  19:    */ import org.openide.util.actions.Presenter.Popup;
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public final class WorkspaceMruAction
/*  47:    */   extends AbstractAction
/*  48:    */   implements Presenter.Popup, Presenter.Menu
/*  49:    */ {
/*  50:    */   public JMenuItem getMenuPresenter()
/*  51:    */   {
/*  52: 52 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  53:    */   }
/*  54:    */   
/*  55:    */   public JMenuItem getPopupPresenter()
/*  56:    */   {
/*  57: 57 */     return getMenuPresenter();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void actionPerformed(ActionEvent ae) {}
/*  61:    */   
/*  62:    */   private static final class MruMenu
/*  63:    */     extends JMenu implements DynamicMenuContent, PropertyChangeListener
/*  64:    */   {
/*  65:    */     public MruMenu(String s)
/*  66:    */     {
/*  67: 67 */       super();
/*  68: 68 */       MruList.getWorkspacesInstance().addPropertyChangeListener(WeakListeners.propertyChange(this, MruList.getWorkspacesInstance()));
/*  69: 69 */       updateMenu();
/*  70:    */     }
/*  71:    */     
/*  72:    */     public void propertyChange(PropertyChangeEvent evt)
/*  73:    */     {
/*  74: 74 */       if (evt.getSource().equals(MruList.getWorkspacesInstance())) {
/*  75: 75 */         updateMenu();
/*  76:    */       }
/*  77:    */     }
/*  78:    */     
/*  79:    */     public JComponent[] getMenuPresenters()
/*  80:    */     {
/*  81: 81 */       return new JComponent[] { this };
/*  82:    */     }
/*  83:    */     
/*  84:    */     public JComponent[] synchMenuPresenters(JComponent[] items)
/*  85:    */     {
/*  86: 86 */       return getMenuPresenters();
/*  87:    */     }
/*  88:    */     
/*  89:    */     private void updateMenu() {
/*  90: 90 */       removeAll();
/*  91: 91 */       if (MruList.getWorkspacesInstance().isEmpty()) {
/*  92: 92 */         setEnabled(false);
/*  93: 93 */         return;
/*  94:    */       }
/*  95: 95 */       setEnabled(true);
/*  96: 96 */       for (final SourceId item : MruList.getWorkspacesInstance()) {
/*  97: 97 */         Action action = new AbstractAction()
/*  98:    */         {
/*  99:    */           public void actionPerformed(ActionEvent e) {
/* 100:100 */             if (!WorkspaceFactory.getInstance().closeWorkspace(true)) {
/* 101:101 */               return;
/* 102:    */             }
/* 103:103 */             IWorkspaceRepository repository = WorkspaceFactory.getInstance().getRepository(item.getDataSource().getProviderName());
/* 104:104 */             if (repository != null) {
/* 105:105 */               Workspace ws = new Workspace(itemdataSource, itemlabel);
/* 106:106 */               if (repository.load(ws)) {
/* 107:107 */                 WorkspaceFactory.getInstance().setActiveWorkspace(ws, 2);
/* 108:    */               }
/* 109:    */             }
/* 110:    */           }
/* 111:111 */         };
/* 112:112 */         action.putValue("Name", item.getLabel());
/* 113:    */         
/* 114:114 */         JMenuItem jMenuItem = new JMenuItem(action);
/* 115:115 */         jMenuItem.setEnabled(isLoadable(item.getDataSource()));
/* 116:116 */         add(jMenuItem);
/* 117:    */       }
/* 118:118 */       add(new JSeparator());
/* 119:119 */       add(new JMenuItem(new AbstractAction("Clear")
/* 120:    */       {
/* 121:    */         public void actionPerformed(ActionEvent ae) {
/* 122:122 */           MruList.getWorkspacesInstance().clear();
/* 123:    */         }
/* 124:    */       }));
/* 125:    */     }
/* 126:    */     
/* 127:    */     boolean isLoadable(DataSource dataSource) {
/* 128:128 */       return WorkspaceFactory.getInstance().getRepository(dataSource.getProviderName()) != null;
/* 129:    */     }
/* 130:    */   }
/* 131:    */ }
