/*  1:   */ package ec.nbdemetra.ui.mru;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.core.InstallerStep;
/*  4:   */ import java.util.prefs.Preferences;
/*  5:   */ import org.openide.util.NbPreferences;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class MruWorkspacesStep
/* 15:   */   extends InstallerStep
/* 16:   */ {
/* 17:17 */   final Preferences prefsWs = NbPreferences.forModule(MruWorkspacesStep.class).node("MruWs");
/* 18:   */   
/* 19:   */   public void restore()
/* 20:   */   {
/* 21:21 */     MruPreferences.INSTANCE.load(prefsWs, MruList.getWorkspacesInstance());
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void close()
/* 25:   */   {
/* 26:26 */     MruPreferences.INSTANCE.store(prefsWs, MruList.getWorkspacesInstance());
/* 27:   */   }
/* 28:   */ }
