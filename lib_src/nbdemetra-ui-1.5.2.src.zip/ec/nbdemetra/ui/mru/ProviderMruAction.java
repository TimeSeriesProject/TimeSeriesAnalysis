/*   1:    */ package ec.nbdemetra.ui.mru;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.nbdemetra.ui.MonikerUI;
/*   5:    */ import ec.tss.tsproviders.DataSource;
/*   6:    */ import ec.tss.tsproviders.IDataSourceLoader;
/*   7:    */ import ec.tss.tsproviders.TsProviders;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import java.util.List;
/*  12:    */ import javax.swing.AbstractAction;
/*  13:    */ import javax.swing.Action;
/*  14:    */ import javax.swing.JComponent;
/*  15:    */ import javax.swing.JMenu;
/*  16:    */ import javax.swing.JMenuItem;
/*  17:    */ import javax.swing.JSeparator;
/*  18:    */ import org.openide.awt.DynamicMenuContent;
/*  19:    */ import org.openide.util.WeakListeners;
/*  20:    */ import org.openide.util.actions.Presenter.Menu;
/*  21:    */ import org.openide.util.actions.Presenter.Popup;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ public final class ProviderMruAction
/*  50:    */   extends AbstractAction
/*  51:    */   implements Presenter.Popup, Presenter.Menu
/*  52:    */ {
/*  53:    */   public JMenuItem getMenuPresenter()
/*  54:    */   {
/*  55: 55 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/*  56:    */   }
/*  57:    */   
/*  58:    */   public JMenuItem getPopupPresenter()
/*  59:    */   {
/*  60: 60 */     return getMenuPresenter();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void actionPerformed(ActionEvent ae)
/*  64:    */   {
/*  65: 65 */     throw new UnsupportedOperationException("Not supported yet.");
/*  66:    */   }
/*  67:    */   
/*  68:    */   private static final class MruMenu extends JMenu implements DynamicMenuContent, PropertyChangeListener
/*  69:    */   {
/*  70:    */     public MruMenu(String s) {
/*  71: 71 */       super();
/*  72: 72 */       MruList.getProvidersInstance().addPropertyChangeListener(WeakListeners.propertyChange(this, MruList.getProvidersInstance()));
/*  73: 73 */       updateMenu();
/*  74:    */     }
/*  75:    */     
/*  76:    */     public void propertyChange(PropertyChangeEvent evt)
/*  77:    */     {
/*  78: 78 */       if (evt.getSource().equals(MruList.getProvidersInstance())) {
/*  79: 79 */         updateMenu();
/*  80:    */       }
/*  81:    */     }
/*  82:    */     
/*  83:    */     public JComponent[] getMenuPresenters()
/*  84:    */     {
/*  85: 85 */       return new JComponent[] { this };
/*  86:    */     }
/*  87:    */     
/*  88:    */     public JComponent[] synchMenuPresenters(JComponent[] items)
/*  89:    */     {
/*  90: 90 */       return getMenuPresenters();
/*  91:    */     }
/*  92:    */     
/*  93:    */     private void updateMenu() {
/*  94: 94 */       removeAll();
/*  95: 95 */       if (MruList.getProvidersInstance().isEmpty()) {
/*  96: 96 */         setEnabled(false);
/*  97: 97 */         return;
/*  98:    */       }
/*  99: 99 */       setEnabled(true);
/* 100:100 */       MonikerUI monikerUI = MonikerUI.getDefault();
/* 101:101 */       for (final SourceId item : MruList.getProvidersInstance()) {
/* 102:102 */         Action action = new AbstractAction()
/* 103:    */         {
/* 104:    */           public void actionPerformed(ActionEvent e) {
/* 105:105 */             Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, item.getDataSource());
/* 106:106 */             if (loader.isPresent()) {
/* 107:107 */               ((IDataSourceLoader)loader.get()).open(item.getDataSource());
/* 108:    */             }
/* 109:    */           }
/* 110:110 */         };
/* 111:111 */         action.putValue("Name", item.getLabel());
/* 112:112 */         action.putValue("SmallIcon", monikerUI.getIcon(item.getDataSource()));
/* 113:113 */         JMenuItem jMenuItem = new JMenuItem(action);
/* 114:114 */         jMenuItem.setEnabled(isLoadable(item.getDataSource()));
/* 115:115 */         add(jMenuItem);
/* 116:    */       }
/* 117:117 */       add(new JSeparator());
/* 118:118 */       add(new JMenuItem(new AbstractAction("Clear")
/* 119:    */       {
/* 120:    */         public void actionPerformed(ActionEvent ae) {
/* 121:121 */           MruList.getProvidersInstance().clear();
/* 122:    */         }
/* 123:    */       }));
/* 124:    */     }
/* 125:    */     
/* 126:    */     boolean isLoadable(DataSource dataSource) {
/* 127:127 */       Optional<IDataSourceLoader> loader = TsProviders.lookup(IDataSourceLoader.class, dataSource);
/* 128:128 */       return (loader.isPresent()) && (!((IDataSourceLoader)loader.get()).getDataSources().contains(dataSource));
/* 129:    */     }
/* 130:    */   }
/* 131:    */ }
