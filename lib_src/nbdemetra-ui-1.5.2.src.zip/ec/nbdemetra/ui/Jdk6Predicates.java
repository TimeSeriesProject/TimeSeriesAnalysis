/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Predicate;
/*  4:   */ import org.openide.nodes.Node;
/*  5:   */ import org.openide.util.Lookup;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public final class Jdk6Predicates
/* 19:   */ {
/* 20:   */   public static Predicate<Node> lookupNode(Class<?> clazz)
/* 21:   */   {
/* 22:22 */     new Predicate()
/* 23:   */     {
/* 24:   */       public boolean apply(Node input) {
/* 25:25 */         return input.getLookup().lookup(Jdk6Predicates.this) != null;
/* 26:   */       }
/* 27:   */     };
/* 28:   */   }
/* 29:   */ }
