package ec.nbdemetra.ui;

public abstract interface INameable
{
  public abstract void rename();
}
