/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ns.NamedServiceChoicePanel;
/*   4:    */ import java.awt.event.ItemEvent;
/*   5:    */ import javax.swing.BorderFactory;
/*   6:    */ import javax.swing.GroupLayout;
/*   7:    */ import javax.swing.GroupLayout.Alignment;
/*   8:    */ import javax.swing.GroupLayout.ParallelGroup;
/*   9:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  10:    */ import javax.swing.JCheckBox;
/*  11:    */ import javax.swing.JComboBox;
/*  12:    */ import javax.swing.JLabel;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.LayoutStyle.ComponentPlacement;
/*  15:    */ import org.openide.awt.Mnemonics;
/*  16:    */ import org.openide.util.NbBundle;
/*  17:    */ 
/*  18:    */ final class DemetraBehaviourPanel extends JPanel implements java.awt.event.ItemListener
/*  19:    */ {
/*  20:    */   private final DemetraBehaviourOptionsPanelController controller;
/*  21:    */   private JLabel batchPoolLabel;
/*  22:    */   private JComboBox batchPoolSizeCombo;
/*  23:    */   private JComboBox batchPriorityCombo;
/*  24:    */   private JLabel batchPriorityLabel;
/*  25:    */   private JLabel doubleClickLabel;
/*  26:    */   private JCheckBox persistOpenDataSources;
/*  27:    */   private JCheckBox persistToolsContent;
/*  28:    */   private JPanel persistencePanel;
/*  29:    */   private JPanel providersPanel;
/*  30:    */   private JCheckBox showUnavailableCheckBox;
/*  31:    */   private JPanel threadingPanel;
/*  32:    */   private NamedServiceChoicePanel tsActionChoicePanel;
/*  33:    */   private JPanel tsPanel;
/*  34:    */   
/*  35:    */   DemetraBehaviourPanel(DemetraBehaviourOptionsPanelController controller)
/*  36:    */   {
/*  37: 37 */     this.controller = controller;
/*  38: 38 */     initComponents();
/*  39:    */     
/*  40: 40 */     showUnavailableCheckBox.addItemListener(this);
/*  41: 41 */     persistToolsContent.addItemListener(this);
/*  42: 42 */     persistOpenDataSources.addItemListener(this);
/*  43: 43 */     batchPoolSizeCombo.addItemListener(this);
/*  44: 44 */     batchPriorityCombo.addItemListener(this);
/*  45: 45 */     tsActionChoicePanel.getComboBox().addItemListener(this);
/*  46:    */   }
/*  47:    */   
/*  48:    */   void load() {
/*  49: 49 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  50: 50 */     showUnavailableCheckBox.setSelected(demetraUI.isShowUnavailableTsProviders());
/*  51: 51 */     persistToolsContent.setSelected(demetraUI.isPersistToolsContent());
/*  52: 52 */     persistOpenDataSources.setSelected(demetraUI.isPersistOpenedDataSources());
/*  53:    */     
/*  54: 54 */     tsActionChoicePanel.setContent(demetraUI.getTsActions());
/*  55: 55 */     tsActionChoicePanel.setSelectedServiceName(demetraUI.getTsActionName());
/*  56:    */     
/*  57: 57 */     batchPoolSizeCombo.setModel(new javax.swing.DefaultComboBoxModel(ec.tstoolkit.utilities.ThreadPoolSize.values()));
/*  58: 58 */     batchPoolSizeCombo.setSelectedItem(demetraUI.getBatchPoolSize());
/*  59: 59 */     batchPriorityCombo.setModel(new javax.swing.DefaultComboBoxModel(ec.tstoolkit.utilities.ThreadPriority.values()));
/*  60: 60 */     batchPriorityCombo.setSelectedItem(demetraUI.getBatchPriority());
/*  61:    */   }
/*  62:    */   
/*  63:    */   void store() {
/*  64: 64 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  65: 65 */     demetraUI.setShowUnavailableTsProviders(showUnavailableCheckBox.isSelected());
/*  66: 66 */     demetraUI.setPersistToolsContent(persistToolsContent.isSelected());
/*  67: 67 */     demetraUI.setPersistOpenedDataSources(persistOpenDataSources.isSelected());
/*  68:    */     
/*  69: 69 */     demetraUI.setTsActionName(tsActionChoicePanel.getSelectedServiceName());
/*  70:    */     
/*  71: 71 */     demetraUI.setBatchPriority((ec.tstoolkit.utilities.ThreadPriority)batchPriorityCombo.getSelectedItem());
/*  72: 72 */     demetraUI.setBatchPoolSize((ec.tstoolkit.utilities.ThreadPoolSize)batchPoolSizeCombo.getSelectedItem());
/*  73:    */   }
/*  74:    */   
/*  75:    */   boolean valid()
/*  76:    */   {
/*  77: 77 */     return true;
/*  78:    */   }
/*  79:    */   
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */   private void initComponents()
/*  88:    */   {
/*  89: 89 */     threadingPanel = new JPanel();
/*  90: 90 */     batchPoolLabel = new JLabel();
/*  91: 91 */     batchPriorityCombo = new JComboBox();
/*  92: 92 */     batchPriorityLabel = new JLabel();
/*  93: 93 */     batchPoolSizeCombo = new JComboBox();
/*  94: 94 */     persistencePanel = new JPanel();
/*  95: 95 */     persistToolsContent = new JCheckBox();
/*  96: 96 */     persistOpenDataSources = new JCheckBox();
/*  97: 97 */     providersPanel = new JPanel();
/*  98: 98 */     showUnavailableCheckBox = new JCheckBox();
/*  99: 99 */     tsPanel = new JPanel();
/* 100:100 */     doubleClickLabel = new JLabel();
/* 101:101 */     tsActionChoicePanel = new NamedServiceChoicePanel();
/* 102:    */     
/* 103:103 */     threadingPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.threadingPanel.border.title")));
/* 104:    */     
/* 105:105 */     Mnemonics.setLocalizedText(batchPoolLabel, NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.batchPoolLabel.text"));
/* 106:    */     
/* 107:107 */     batchPriorityCombo.setOpaque(false);
/* 108:    */     
/* 109:109 */     Mnemonics.setLocalizedText(batchPriorityLabel, NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.batchPriorityLabel.text"));
/* 110:    */     
/* 111:111 */     batchPoolSizeCombo.setOpaque(false);
/* 112:    */     
/* 113:113 */     GroupLayout threadingPanelLayout = new GroupLayout(threadingPanel);
/* 114:114 */     threadingPanel.setLayout(threadingPanelLayout);
/* 115:115 */     threadingPanelLayout.setHorizontalGroup(
/* 116:116 */       threadingPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 117:117 */       .addGroup(threadingPanelLayout.createSequentialGroup()
/* 118:118 */       .addContainerGap()
/* 119:119 */       .addGroup(threadingPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 120:120 */       .addComponent(batchPoolLabel)
/* 121:121 */       .addComponent(batchPriorityLabel, -2, 78, -2))
/* 122:122 */       .addGap(6, 6, 6)
/* 123:123 */       .addGroup(threadingPanelLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 124:124 */       .addComponent(batchPriorityCombo, 0, -1, 32767)
/* 125:125 */       .addComponent(batchPoolSizeCombo, -2, 176, -2))
/* 126:126 */       .addContainerGap(-1, 32767)));
/* 127:    */     
/* 128:128 */     threadingPanelLayout.setVerticalGroup(
/* 129:129 */       threadingPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 130:130 */       .addGroup(threadingPanelLayout.createSequentialGroup()
/* 131:131 */       .addGroup(threadingPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 132:132 */       .addComponent(batchPoolLabel)
/* 133:133 */       .addComponent(batchPoolSizeCombo, -2, -1, -2))
/* 134:134 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 135:135 */       .addGroup(threadingPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 136:136 */       .addComponent(batchPriorityLabel)
/* 137:137 */       .addComponent(batchPriorityCombo, -2, -1, -2))
/* 138:138 */       .addContainerGap()));
/* 139:    */     
/* 140:    */ 
/* 141:141 */     persistencePanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.persistencePanel.border.title")));
/* 142:    */     
/* 143:143 */     Mnemonics.setLocalizedText(persistToolsContent, NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.persistToolsContent.text"));
/* 144:    */     
/* 145:145 */     Mnemonics.setLocalizedText(persistOpenDataSources, NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.persistOpenDataSources.text"));
/* 146:    */     
/* 147:147 */     GroupLayout persistencePanelLayout = new GroupLayout(persistencePanel);
/* 148:148 */     persistencePanel.setLayout(persistencePanelLayout);
/* 149:149 */     persistencePanelLayout.setHorizontalGroup(
/* 150:150 */       persistencePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 151:151 */       .addGroup(persistencePanelLayout.createSequentialGroup()
/* 152:152 */       .addContainerGap()
/* 153:153 */       .addGroup(persistencePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 154:154 */       .addComponent(persistToolsContent)
/* 155:155 */       .addComponent(persistOpenDataSources))
/* 156:156 */       .addContainerGap(-1, 32767)));
/* 157:    */     
/* 158:158 */     persistencePanelLayout.setVerticalGroup(
/* 159:159 */       persistencePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 160:160 */       .addGroup(persistencePanelLayout.createSequentialGroup()
/* 161:161 */       .addComponent(persistOpenDataSources)
/* 162:162 */       .addGap(0, 0, 0)
/* 163:163 */       .addComponent(persistToolsContent)));
/* 164:    */     
/* 165:    */ 
/* 166:166 */     providersPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.providersPanel.border.title")));
/* 167:    */     
/* 168:168 */     Mnemonics.setLocalizedText(showUnavailableCheckBox, NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.showUnavailableCheckBox.text"));
/* 169:    */     
/* 170:170 */     GroupLayout providersPanelLayout = new GroupLayout(providersPanel);
/* 171:171 */     providersPanel.setLayout(providersPanelLayout);
/* 172:172 */     providersPanelLayout.setHorizontalGroup(
/* 173:173 */       providersPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 174:174 */       .addGroup(providersPanelLayout.createSequentialGroup()
/* 175:175 */       .addContainerGap()
/* 176:176 */       .addComponent(showUnavailableCheckBox)
/* 177:177 */       .addContainerGap(-1, 32767)));
/* 178:    */     
/* 179:179 */     providersPanelLayout.setVerticalGroup(
/* 180:180 */       providersPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 181:181 */       .addComponent(showUnavailableCheckBox));
/* 182:    */     
/* 183:    */ 
/* 184:184 */     tsPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.tsPanel.border.title")));
/* 185:    */     
/* 186:186 */     Mnemonics.setLocalizedText(doubleClickLabel, NbBundle.getMessage(DemetraBehaviourPanel.class, "DemetraBehaviourPanel.doubleClickLabel.text"));
/* 187:    */     
/* 188:188 */     tsActionChoicePanel.setOpaque(false);
/* 189:    */     
/* 190:190 */     GroupLayout tsPanelLayout = new GroupLayout(tsPanel);
/* 191:191 */     tsPanel.setLayout(tsPanelLayout);
/* 192:192 */     tsPanelLayout.setHorizontalGroup(
/* 193:193 */       tsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 194:194 */       .addGroup(tsPanelLayout.createSequentialGroup()
/* 195:195 */       .addContainerGap()
/* 196:196 */       .addComponent(doubleClickLabel, -2, 78, -2)
/* 197:197 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 198:198 */       .addComponent(tsActionChoicePanel, -2, 192, -2)
/* 199:199 */       .addContainerGap(70, 32767)));
/* 200:    */     
/* 201:201 */     tsPanelLayout.setVerticalGroup(
/* 202:202 */       tsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 203:203 */       .addComponent(doubleClickLabel, -1, -1, 32767)
/* 204:204 */       .addComponent(tsActionChoicePanel, -1, -1, 32767));
/* 205:    */     
/* 206:    */ 
/* 207:207 */     GroupLayout layout = new GroupLayout(this);
/* 208:208 */     setLayout(layout);
/* 209:209 */     layout.setHorizontalGroup(
/* 210:210 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 211:211 */       .addComponent(providersPanel, -1, -1, 32767)
/* 212:212 */       .addComponent(persistencePanel, -1, -1, 32767)
/* 213:213 */       .addComponent(threadingPanel, -1, -1, 32767)
/* 214:214 */       .addComponent(tsPanel, -1, -1, 32767));
/* 215:    */     
/* 216:216 */     layout.setVerticalGroup(
/* 217:217 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 218:218 */       .addGroup(layout.createSequentialGroup()
/* 219:219 */       .addComponent(providersPanel, -2, -1, -2)
/* 220:220 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 221:221 */       .addComponent(persistencePanel, -2, -1, -2)
/* 222:222 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 223:223 */       .addComponent(threadingPanel, -2, 68, -2)
/* 224:224 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 225:225 */       .addComponent(tsPanel, -2, -1, -2)
/* 226:226 */       .addContainerGap(-1, 32767)));
/* 227:    */   }
/* 228:    */   
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:    */ 
/* 247:    */   public void itemStateChanged(ItemEvent e)
/* 248:    */   {
/* 249:249 */     switch (e.getStateChange()) {
/* 250:    */     case 1: 
/* 251:    */     case 2: 
/* 252:252 */       controller.changed();
/* 253:    */     }
/* 254:    */   }
/* 255:    */ }
