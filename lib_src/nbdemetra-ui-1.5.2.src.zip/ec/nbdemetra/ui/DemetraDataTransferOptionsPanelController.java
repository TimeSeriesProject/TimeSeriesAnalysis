/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeListener;
/*  4:   */ import java.beans.PropertyChangeSupport;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import org.netbeans.spi.options.OptionsPanelController;
/*  7:   */ import org.openide.util.HelpCtx;
/*  8:   */ import org.openide.util.Lookup;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public final class DemetraDataTransferOptionsPanelController
/* 20:   */   extends OptionsPanelController
/* 21:   */ {
/* 22:   */   private DemetraDataTransferPanel panel;
/* 23:23 */   private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
/* 24:   */   private boolean changed;
/* 25:   */   
/* 26:   */   public void update()
/* 27:   */   {
/* 28:28 */     getPanel().load();
/* 29:29 */     changed = false;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void applyChanges()
/* 33:   */   {
/* 34:34 */     getPanel().store();
/* 35:35 */     changed = false;
/* 36:   */   }
/* 37:   */   
/* 38:   */ 
/* 39:   */ 
/* 40:   */   public void cancel() {}
/* 41:   */   
/* 42:   */ 
/* 43:   */   public boolean isValid()
/* 44:   */   {
/* 45:45 */     return getPanel().valid();
/* 46:   */   }
/* 47:   */   
/* 48:   */   public boolean isChanged()
/* 49:   */   {
/* 50:50 */     return changed;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public HelpCtx getHelpCtx()
/* 54:   */   {
/* 55:55 */     return null;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public JComponent getComponent(Lookup masterLookup)
/* 59:   */   {
/* 60:60 */     return getPanel();
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void addPropertyChangeListener(PropertyChangeListener l)
/* 64:   */   {
/* 65:65 */     pcs.addPropertyChangeListener(l);
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void removePropertyChangeListener(PropertyChangeListener l)
/* 69:   */   {
/* 70:70 */     pcs.removePropertyChangeListener(l);
/* 71:   */   }
/* 72:   */   
/* 73:   */   private DemetraDataTransferPanel getPanel() {
/* 74:74 */     if (panel == null) {
/* 75:75 */       panel = new DemetraDataTransferPanel(this);
/* 76:   */     }
/* 77:77 */     return panel;
/* 78:   */   }
/* 79:   */   
/* 80:   */   void changed() {
/* 81:81 */     if (!changed) {
/* 82:82 */       changed = true;
/* 83:83 */       pcs.firePropertyChange("changed", false, true);
/* 84:   */     }
/* 85:85 */     pcs.firePropertyChange("valid", null, null);
/* 86:   */   }
/* 87:   */ }
