package ec.nbdemetra.ui.docs;

abstract interface package-info {}
