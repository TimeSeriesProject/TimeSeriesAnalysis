/*  1:   */ package ec.nbdemetra.ui.tsaction;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.DemetraUI;
/*  4:   */ import ec.nbdemetra.ui.ns.NamedServiceChoicePanel;
/*  5:   */ import java.awt.Component;
/*  6:   */ import java.awt.FlowLayout;
/*  7:   */ import java.awt.event.ActionEvent;
/*  8:   */ import java.beans.PropertyChangeEvent;
/*  9:   */ import java.beans.PropertyChangeListener;
/* 10:   */ import java.beans.PropertyVetoException;
/* 11:   */ import java.beans.VetoableChangeListener;
/* 12:   */ import javax.swing.AbstractAction;
/* 13:   */ import javax.swing.JPanel;
/* 14:   */ import org.openide.explorer.ExplorerManager;
/* 15:   */ import org.openide.nodes.Children;
/* 16:   */ import org.openide.nodes.Node;
/* 17:   */ import org.openide.util.Exceptions;
/* 18:   */ import org.openide.util.WeakListeners;
/* 19:   */ import org.openide.util.actions.Presenter.Toolbar;
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public final class ChooseTsActionAction
/* 36:   */   extends AbstractAction
/* 37:   */   implements Presenter.Toolbar, VetoableChangeListener, PropertyChangeListener
/* 38:   */ {
/* 39:   */   final NamedServiceChoicePanel choicePanel;
/* 40:   */   
/* 41:   */   public ChooseTsActionAction()
/* 42:   */   {
/* 43:43 */     choicePanel = new NamedServiceChoicePanel();
/* 44:44 */     DemetraUI demetraUI = DemetraUI.getDefault();
/* 45:45 */     choicePanel.setContent(demetraUI.getTsActions());
/* 46:46 */     choicePanel.setSelectedServiceName(demetraUI.getTsActionName());
/* 47:47 */     choicePanel.getExplorerManager().addVetoableChangeListener(this);
/* 48:48 */     demetraUI.addPropertyChangeListener(WeakListeners.propertyChange(this, demetraUI));
/* 49:   */   }
/* 50:   */   
/* 51:   */ 
/* 52:   */ 
/* 53:   */   public void actionPerformed(ActionEvent e) {}
/* 54:   */   
/* 55:   */ 
/* 56:   */   public Component getToolbarPresenter()
/* 57:   */   {
/* 58:58 */     JPanel result = new JPanel(new FlowLayout());
/* 59:59 */     result.add(choicePanel);
/* 60:60 */     return result;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void propertyChange(PropertyChangeEvent evt)
/* 64:   */   {
/* 65:65 */     if (evt.getPropertyName().equals("tsActionName")) {
/* 66:66 */       Node o = choicePanel.getExplorerManager().getRootContext().getChildren().findChild((String)evt.getNewValue());
/* 67:67 */       if (o != null) {
/* 68:   */         try {
/* 69:69 */           choicePanel.getExplorerManager().setSelectedNodes(new Node[] { o });
/* 70:   */         } catch (PropertyVetoException ex) {
/* 71:71 */           Exceptions.printStackTrace(ex);
/* 72:   */         }
/* 73:   */       }
/* 74:   */     }
/* 75:   */   }
/* 76:   */   
/* 77:   */   public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException
/* 78:   */   {
/* 79:79 */     if ("selectedNodes".equals(evt.getPropertyName())) {
/* 80:80 */       Node[] nodes = (Node[])evt.getNewValue();
/* 81:81 */       if (nodes.length > 0) {
/* 82:82 */         DemetraUI.getDefault().setTsActionName(nodes[0].getName());
/* 83:   */       }
/* 84:   */     }
/* 85:   */   }
/* 86:   */ }
