package ec.nbdemetra.ui.tsaction;

import ec.tss.Ts;

public abstract interface ITsView2
{
  public abstract Ts getTs();
  
  public abstract void setTs(Ts paramTs);
}
