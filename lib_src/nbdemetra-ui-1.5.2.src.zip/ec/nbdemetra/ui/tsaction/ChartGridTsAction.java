/*   1:    */ package ec.nbdemetra.ui.tsaction;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import ec.nbdemetra.ui.MonikerUI;
/*   5:    */ import ec.nbdemetra.ui.NbComponents;
/*   6:    */ import ec.nbdemetra.ui.ns.AbstractNamedService;
/*   7:    */ import ec.nbdemetra.ui.tools.ChartTopComponent;
/*   8:    */ import ec.nbdemetra.ui.tools.GridTopComponent;
/*   9:    */ import ec.tss.Ts;
/*  10:    */ import ec.tss.TsCollection;
/*  11:    */ import ec.tss.TsMoniker;
/*  12:    */ import ec.tss.tsproviders.DataSet;
/*  13:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  14:    */ import ec.tss.tsproviders.TsProviders;
/*  15:    */ import ec.ui.ATsChart;
/*  16:    */ import ec.ui.ATsGrid;
/*  17:    */ import ec.ui.interfaces.ITsChart.LinesThickness;
/*  18:    */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/*  19:    */ import ec.ui.interfaces.ITsGrid.Mode;
/*  20:    */ import java.awt.Image;
/*  21:    */ import java.io.Serializable;
/*  22:    */ import org.netbeans.core.spi.multiview.MultiViewDescription;
/*  23:    */ import org.netbeans.core.spi.multiview.MultiViewElement;
/*  24:    */ import org.netbeans.core.spi.multiview.MultiViewFactory;
/*  25:    */ import org.openide.util.HelpCtx;
/*  26:    */ import org.openide.util.ImageUtilities;
/*  27:    */ import org.openide.windows.TopComponent;
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public class ChartGridTsAction
/*  31:    */   extends AbstractNamedService
/*  32:    */   implements ITsAction
/*  33:    */ {
/*  34:    */   public static final String NAME = "ChartGridTsAction";
/*  35:    */   
/*  36:    */   public ChartGridTsAction()
/*  37:    */   {
/*  38: 38 */     super(ITsAction.class, "ChartGridTsAction");
/*  39:    */   }
/*  40:    */   
/*  41:    */   public String getDisplayName()
/*  42:    */   {
/*  43: 43 */     return "Chart & grid";
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void open(Ts ts)
/*  47:    */   {
/*  48: 48 */     String name = "ChartGridTsAction" + ts.getMoniker().getId();
/*  49: 49 */     TopComponent c = NbComponents.findTopComponentByName(name);
/*  50: 50 */     if (c == null) {
/*  51: 51 */       MultiViewDescription[] descriptions = { new ChartTab(ts), new GridTab(ts) };
/*  52: 52 */       c = MultiViewFactory.createMultiView(descriptions, descriptions[0], null);
/*  53: 53 */       c.setName(name);
/*  54:    */       
/*  55: 55 */       MonikerUI monikerUI = MonikerUI.getDefault();
/*  56: 56 */       Optional<IDataSourceProvider> provider = TsProviders.lookup(IDataSourceProvider.class, ts.getMoniker());
/*  57: 57 */       if (provider.isPresent()) {
/*  58: 58 */         DataSet dataSet = ((IDataSourceProvider)provider.get()).toDataSet(ts.getMoniker());
/*  59: 59 */         if (dataSet != null) {
/*  60: 60 */           c.setIcon(ImageUtilities.icon2Image(monikerUI.getIcon(dataSet)));
/*  61: 61 */           c.setDisplayName(((IDataSourceProvider)provider.get()).getDisplayNodeName(dataSet));
/*  62:    */         }
/*  63:    */       } else {
/*  64: 64 */         c.setIcon(monikerUI.getImage(ts));
/*  65: 65 */         c.setDisplayName(ts.getName());
/*  66:    */       }
/*  67: 67 */       c.open();
/*  68:    */     }
/*  69: 69 */     c.requestActive();
/*  70:    */   }
/*  71:    */   
/*  72:    */   static class ChartTab implements MultiViewDescription, Serializable
/*  73:    */   {
/*  74:    */     final Ts ts;
/*  75:    */     
/*  76:    */     public ChartTab(Ts ts) {
/*  77: 77 */       this.ts = ts;
/*  78:    */     }
/*  79:    */     
/*  80:    */     public int getPersistenceType()
/*  81:    */     {
/*  82: 82 */       return 2;
/*  83:    */     }
/*  84:    */     
/*  85:    */     public String getDisplayName()
/*  86:    */     {
/*  87: 87 */       return "Chart";
/*  88:    */     }
/*  89:    */     
/*  90:    */     public Image getIcon()
/*  91:    */     {
/*  92: 92 */       return MonikerUI.getDefault().getImage(ts);
/*  93:    */     }
/*  94:    */     
/*  95:    */     public HelpCtx getHelpCtx()
/*  96:    */     {
/*  97: 97 */       return null;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public String preferredID()
/* 101:    */     {
/* 102:102 */       return "Chart";
/* 103:    */     }
/* 104:    */     
/* 105:    */     public MultiViewElement createElement()
/* 106:    */     {
/* 107:107 */       ChartTopComponent result = new ChartTopComponent();
/* 108:108 */       result.getChart().getTsCollection().add(ts);
/* 109:109 */       result.getChart().setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 110:110 */       result.getChart().setLegendVisible(true);
/* 111:111 */       result.getChart().setTitleVisible(false);
/* 112:112 */       result.getChart().setLinesThickness(ITsChart.LinesThickness.Thick);
/* 113:113 */       return result;
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   static class GridTab implements MultiViewDescription, Serializable
/* 118:    */   {
/* 119:    */     final Ts ts;
/* 120:    */     
/* 121:    */     public GridTab(Ts ts) {
/* 122:122 */       this.ts = ts;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public int getPersistenceType()
/* 126:    */     {
/* 127:127 */       return 2;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public String getDisplayName()
/* 131:    */     {
/* 132:132 */       return "Grid";
/* 133:    */     }
/* 134:    */     
/* 135:    */     public Image getIcon()
/* 136:    */     {
/* 137:137 */       return MonikerUI.getDefault().getImage(ts);
/* 138:    */     }
/* 139:    */     
/* 140:    */     public HelpCtx getHelpCtx()
/* 141:    */     {
/* 142:142 */       return null;
/* 143:    */     }
/* 144:    */     
/* 145:    */     public String preferredID()
/* 146:    */     {
/* 147:147 */       return "Grid";
/* 148:    */     }
/* 149:    */     
/* 150:    */     public MultiViewElement createElement()
/* 151:    */     {
/* 152:152 */       GridTopComponent result = new GridTopComponent();
/* 153:153 */       result.getGrid().getTsCollection().add(ts);
/* 154:154 */       result.getGrid().setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 155:155 */       result.getGrid().setMode(ITsGrid.Mode.SINGLETS);
/* 156:156 */       return result;
/* 157:    */     }
/* 158:    */   }
/* 159:    */ }
