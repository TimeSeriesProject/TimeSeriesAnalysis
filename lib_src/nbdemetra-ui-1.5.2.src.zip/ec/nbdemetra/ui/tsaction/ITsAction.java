package ec.nbdemetra.ui.tsaction;

import ec.nbdemetra.ui.ns.INamedService;
import ec.tss.Ts;

public abstract interface ITsAction
  extends INamedService
{
  public abstract void open(Ts paramTs);
}
