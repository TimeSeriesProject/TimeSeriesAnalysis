/*  1:   */ package ec.nbdemetra.ui.tsaction;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Iterables;
/*  4:   */ import ec.nbdemetra.ui.ns.AbstractNamedService;
/*  5:   */ import ec.tss.Ts;
/*  6:   */ import org.openide.windows.TopComponent;
/*  7:   */ import org.openide.windows.TopComponent.Registry;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ public class TsViewsTsAction
/* 16:   */   extends AbstractNamedService
/* 17:   */   implements ITsAction
/* 18:   */ {
/* 19:   */   public static final String NAME = "TsViewsTs";
/* 20:   */   
/* 21:   */   public TsViewsTsAction()
/* 22:   */   {
/* 23:23 */     super(ITsAction.class, "TsViewsTs");
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String getDisplayName()
/* 27:   */   {
/* 28:28 */     return "All ts views";
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void open(Ts ts)
/* 32:   */   {
/* 33:33 */     for (ITsView2 o : Iterables.filter(TopComponent.getRegistry().getOpened(), ITsView2.class)) {
/* 34:34 */       o.setTs(ts);
/* 35:   */     }
/* 36:   */   }
/* 37:   */ }
