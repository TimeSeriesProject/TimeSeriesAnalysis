/*  1:   */ package ec.nbdemetra.ui.tsaction;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.MonikerUI;
/*  5:   */ import ec.nbdemetra.ui.NbComponents;
/*  6:   */ import ec.nbdemetra.ui.ns.AbstractNamedService;
/*  7:   */ import ec.nbdemetra.ui.tools.ChartTopComponent;
/*  8:   */ import ec.tss.Ts;
/*  9:   */ import ec.tss.TsCollection;
/* 10:   */ import ec.tss.TsMoniker;
/* 11:   */ import ec.tss.tsproviders.DataSet;
/* 12:   */ import ec.tss.tsproviders.IDataSourceProvider;
/* 13:   */ import ec.tss.tsproviders.TsProviders;
/* 14:   */ import ec.ui.ATsChart;
/* 15:   */ import ec.ui.interfaces.ITsChart.LinesThickness;
/* 16:   */ import ec.ui.interfaces.ITsCollectionView.TsUpdateMode;
/* 17:   */ import org.openide.util.ImageUtilities;
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ public class SimpleChartTsAction
/* 24:   */   extends AbstractNamedService
/* 25:   */   implements ITsAction
/* 26:   */ {
/* 27:   */   public static final String NAME = "SimpleChartTsAction";
/* 28:   */   
/* 29:   */   public SimpleChartTsAction()
/* 30:   */   {
/* 31:31 */     super(ITsAction.class, "SimpleChartTsAction");
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getDisplayName()
/* 35:   */   {
/* 36:36 */     return "Simple chart";
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void open(Ts ts)
/* 40:   */   {
/* 41:41 */     String name = "SimpleChartTsAction" + ts.getMoniker().getId();
/* 42:42 */     ChartTopComponent c = (ChartTopComponent)NbComponents.findTopComponentByNameAndClass(name, ChartTopComponent.class);
/* 43:43 */     if (c == null) {
/* 44:44 */       c = new ChartTopComponent();
/* 45:45 */       c.setName(name);
/* 46:   */       
/* 47:47 */       MonikerUI monikerUI = MonikerUI.getDefault();
/* 48:48 */       Optional<IDataSourceProvider> provider = TsProviders.lookup(IDataSourceProvider.class, ts.getMoniker());
/* 49:49 */       if (provider.isPresent()) {
/* 50:50 */         DataSet dataSet = ((IDataSourceProvider)provider.get()).toDataSet(ts.getMoniker());
/* 51:51 */         if (dataSet != null) {
/* 52:52 */           c.setIcon(ImageUtilities.icon2Image(monikerUI.getIcon(dataSet)));
/* 53:53 */           c.setDisplayName(((IDataSourceProvider)provider.get()).getDisplayNodeName(dataSet));
/* 54:   */         }
/* 55:   */       } else {
/* 56:56 */         c.setIcon(monikerUI.getImage(ts));
/* 57:57 */         c.setDisplayName(ts.getName());
/* 58:   */       }
/* 59:   */       
/* 60:60 */       c.getChart().getTsCollection().add(ts);
/* 61:61 */       c.getChart().setTsUpdateMode(ITsCollectionView.TsUpdateMode.None);
/* 62:62 */       c.getChart().setLegendVisible(false);
/* 63:63 */       c.getChart().setTitle(ts.getName());
/* 64:64 */       c.getChart().setLinesThickness(ITsChart.LinesThickness.Thick);
/* 65:65 */       c.open();
/* 66:   */     }
/* 67:67 */     c.requestActive();
/* 68:   */   }
/* 69:   */ }
