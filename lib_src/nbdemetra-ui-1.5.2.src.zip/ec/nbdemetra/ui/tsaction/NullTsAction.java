/*  1:   */ package ec.nbdemetra.ui.tsaction;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.ns.AbstractNamedService;
/*  4:   */ import ec.tss.Ts;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class NullTsAction
/* 14:   */   extends AbstractNamedService
/* 15:   */   implements ITsAction
/* 16:   */ {
/* 17:   */   public static final String NAME = "NullTsAction";
/* 18:   */   
/* 19:   */   public NullTsAction()
/* 20:   */   {
/* 21:21 */     super(ITsAction.class, "NullTsAction");
/* 22:   */   }
/* 23:   */   
/* 24:   */ 
/* 25:   */   public void open(Ts ts) {}
/* 26:   */   
/* 27:   */ 
/* 28:   */   public String getDisplayName()
/* 29:   */   {
/* 30:30 */     return "Do nothing";
/* 31:   */   }
/* 32:   */ }
