/*  1:   */ package ec.nbdemetra.ui.nodes;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.openide.nodes.ChildFactory.Detachable;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ public abstract class BasicChildFactory<T>
/* 13:   */   extends ChildFactory.Detachable<T>
/* 14:   */ {
/* 15:   */   protected Exception exception;
/* 16:   */   
/* 17:   */   public BasicChildFactory()
/* 18:   */   {
/* 19:19 */     exception = null;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Exception getException() {
/* 23:23 */     return exception;
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected boolean createKeys(List<T> list)
/* 27:   */   {
/* 28:28 */     exception = null;
/* 29:   */     try {
/* 30:30 */       tryCreateKeys(list);
/* 31:   */     } catch (Exception ex) {
/* 32:32 */       exception = ex;
/* 33:   */     }
/* 34:34 */     return true;
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected abstract void tryCreateKeys(List<T> paramList)
/* 38:   */     throws Exception;
/* 39:   */ }
