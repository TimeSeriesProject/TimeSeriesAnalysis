/*   1:    */ package ec.nbdemetra.ui.nodes;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Optional;
/*   4:    */ import com.google.common.collect.Iterables;
/*   5:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*   6:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.BooleanStep;
/*   7:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*   8:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.EnumStep;
/*   9:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.IntStep;
/*  10:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  11:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  12:    */ import ec.tss.Ts;
/*  13:    */ import ec.tss.TsCollection;
/*  14:    */ import ec.tss.TsInformationType;
/*  15:    */ import ec.tss.TsMoniker;
/*  16:    */ import ec.tss.TsStatus;
/*  17:    */ import ec.tss.tsproviders.IDataSourceProvider;
/*  18:    */ import ec.tss.tsproviders.TsProviders;
/*  19:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  20:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  21:    */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/*  22:    */ import ec.ui.interfaces.ITsCollectionView;
/*  23:    */ import java.beans.PropertyChangeEvent;
/*  24:    */ import java.beans.PropertyChangeListener;
/*  25:    */ import java.util.ArrayList;
/*  26:    */ import java.util.Arrays;
/*  27:    */ import java.util.Collections;
/*  28:    */ import java.util.List;
/*  29:    */ import java.util.Map.Entry;
/*  30:    */ import java.util.TreeMap;
/*  31:    */ import org.openide.explorer.ExplorerManager;
/*  32:    */ import org.openide.nodes.AbstractNode;
/*  33:    */ import org.openide.nodes.Children;
/*  34:    */ import org.openide.nodes.Children.Keys;
/*  35:    */ import org.openide.nodes.Node;
/*  36:    */ import org.openide.nodes.Sheet;
/*  37:    */ import org.openide.util.Exceptions;
/*  38:    */ import org.openide.util.Lookup;
/*  39:    */ import org.openide.util.lookup.Lookups;
/*  40:    */ 
/*  41:    */ public class ControlNode
/*  42:    */ {
/*  43:    */   public static Node onComponentOpened(final ExplorerManager mgr, final ITsCollectionView view)
/*  44:    */   {
/*  45: 45 */     TsCollectionNode root = new TsCollectionNode(view.getTsCollection());
/*  46: 46 */     mgr.setRootContext(root);
/*  47:    */     
/*  48: 48 */     view.addPropertyChangeListener("selection", new PropertyChangeListener()
/*  49:    */     {
/*  50:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  51:    */         try {
/*  52: 52 */           List<Ts> selection = Arrays.asList(getSelection());
/*  53: 53 */           if (selection.isEmpty()) {
/*  54: 54 */             mgr.setSelectedNodes(new Node[] { mgr.getRootContext() });
/*  55:    */           } else {
/*  56: 56 */             List<Node> nodes = new ArrayList();
/*  57: 57 */             for (Node o : mgr.getRootContext().getChildren().getNodes()) {
/*  58: 58 */               if (selection.contains(o.getLookup().lookup(Ts.class))) {
/*  59: 59 */                 nodes.add(o);
/*  60:    */               }
/*  61:    */             }
/*  62: 62 */             mgr.setSelectedNodes((Node[])Iterables.toArray(nodes, Node.class));
/*  63:    */           }
/*  64:    */         } catch (Exception ex) {
/*  65: 65 */           Exceptions.printStackTrace(ex);
/*  66:    */         }
/*  67:    */       }
/*  68: 68 */     });
/*  69: 69 */     view.addPropertyChangeListener("tsCollection", new PropertyChangeListener()
/*  70:    */     {
/*  71:    */       public void propertyChange(PropertyChangeEvent evt) {
/*  72: 72 */         setRootContext(new ControlNode.TsCollectionNode(view.getTsCollection()));
/*  73:    */       }
/*  74:    */       
/*  75: 75 */     });
/*  76: 76 */     return root;
/*  77:    */   }
/*  78:    */   
/*  79:    */   static class TsCollectionNode extends AbstractNode
/*  80:    */   {
/*  81:    */     TsCollectionNode(TsCollection col) {
/*  82: 82 */       super(Lookups.singleton(col));
/*  83: 83 */       setName(col.getName());
/*  84:    */     }
/*  85:    */     
/*  86:    */     protected Sheet createSheet()
/*  87:    */     {
/*  88: 88 */       TsCollection col = (TsCollection)getLookup().lookup(TsCollection.class);
/*  89: 89 */       Sheet result = new Sheet();
/*  90: 90 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/*  91:    */       
/*  92: 92 */       b.reset("Collection");
/*  93: 93 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(col, "getName", null)).display("Name").add();
/*  94: 94 */       if (!col.getMoniker().isAnonymous()) {
/*  95: 95 */         Optional<IDataSourceProvider> provider = TsProviders.lookup(IDataSourceProvider.class, col.getMoniker());
/*  96: 96 */         ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select("Provider", provider.isPresent() ? ((IDataSourceProvider)provider.get()).getDisplayName() : col.getMoniker().getSource())).add();
/*  97:    */       }
/*  98:    */       
/*  99: 99 */       ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsInformationType.class).select(col, "getInformationType", null)).display("Information type")).add();
/* 100:100 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().select(col, "isLocked", null)).display("Locked")).add();
/* 101:101 */       ((NodePropertySetBuilder.IntStep)((NodePropertySetBuilder.IntStep)b.withInt().select(col, "getCount", null)).display("Series count")).add();
/* 102:102 */       if (col.hasMetaData() == TsStatus.Invalid) {
/* 103:103 */         ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsStatus.class).select(col, "hasMetaData", null)).display("Meta data status")).add();
/* 104:    */       }
/* 105:105 */       result.put(b.build());
/* 106:    */       
/* 107:107 */       if (col.hasMetaData() == TsStatus.Valid) {
/* 108:108 */         b.reset("Meta data");
/* 109:    */         
/* 110:110 */         for (Map.Entry<String, String> o : new TreeMap(col.getMetaData()).entrySet()) {
/* 111:111 */           ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select((String)o.getKey(), (String)o.getValue())).add();
/* 112:    */         }
/* 113:113 */         result.put(b.build());
/* 114:    */       }
/* 115:    */       
/* 116:116 */       return result;
/* 117:    */     }
/* 118:    */     
/* 119:    */     static class TsCollectionChildren extends Children.Keys<Ts>
/* 120:    */     {
/* 121:    */       final TsCollection col;
/* 122:    */       
/* 123:    */       TsCollectionChildren(TsCollection col) {
/* 124:124 */         this.col = col;
/* 125:    */       }
/* 126:    */       
/* 127:    */       protected void addNotify()
/* 128:    */       {
/* 129:129 */         setKeys(col.toArray());
/* 130:    */       }
/* 131:    */       
/* 132:    */       protected void removeNotify()
/* 133:    */       {
/* 134:134 */         setKeys(Collections.emptyList());
/* 135:    */       }
/* 136:    */       
/* 137:    */       protected Node[] createNodes(Ts key)
/* 138:    */       {
/* 139:139 */         return new Node[] { new ControlNode.TsNode(key) };
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   static class TsNode extends AbstractNode
/* 145:    */   {
/* 146:    */     TsNode(Ts ts) {
/* 147:147 */       super(Lookups.singleton(ts));
/* 148:148 */       setName(ts.getName());
/* 149:    */     }
/* 150:    */     
/* 151:    */     protected Sheet createSheet()
/* 152:    */     {
/* 153:153 */       Ts ts = (Ts)getLookup().lookup(Ts.class);
/* 154:154 */       Sheet result = new Sheet();
/* 155:155 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 156:    */       
/* 157:157 */       b.reset("Time series");
/* 158:158 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(ts, "getName", null)).display("Name").add();
/* 159:159 */       if (!ts.getMoniker().isAnonymous()) {
/* 160:160 */         Optional<IDataSourceProvider> provider = TsProviders.lookup(IDataSourceProvider.class, ts.getMoniker());
/* 161:161 */         ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select("Provider", provider.isPresent() ? ((IDataSourceProvider)provider.get()).getDisplayName() : ts.getMoniker().getSource())).add();
/* 162:    */       }
/* 163:    */       
/* 164:164 */       ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsInformationType.class).select(ts, "getInformationType", null)).display("Information type")).add();
/* 165:165 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().select(ts, "isFrozen", null)).display("Frozen")).add();
/* 166:166 */       if (ts.hasData() == TsStatus.Invalid) {
/* 167:167 */         ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsStatus.class).select(ts, "hasData", null)).display("Data status")).add();
/* 168:168 */         ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select("InvalidDataCause", ts.getInvalidDataCause())).display("Invalid data cause").add();
/* 169:    */       }
/* 170:170 */       if (ts.hasMetaData() == TsStatus.Invalid) {
/* 171:171 */         ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsStatus.class).select(ts, "hasMetaData", null)).display("Meta data status")).add();
/* 172:    */       }
/* 173:173 */       result.put(b.build());
/* 174:    */       
/* 175:175 */       if (ts.hasData() == TsStatus.Valid) {
/* 176:176 */         b.reset("Data");
/* 177:177 */         TsData data = ts.getTsData();
/* 178:178 */         ((NodePropertySetBuilder.EnumStep)((NodePropertySetBuilder.EnumStep)b.withEnum(TsFrequency.class).select(data, "getFrequency", null)).display("Frequency")).add();
/* 179:179 */         ((NodePropertySetBuilder.DefaultStep)b.with(TsPeriod.class).select(data, "getStart", null)).display("First period").add();
/* 180:180 */         ((NodePropertySetBuilder.DefaultStep)b.with(TsPeriod.class).select(data, "getLastPeriod", null)).display("Last period").add();
/* 181:181 */         ((NodePropertySetBuilder.IntStep)((NodePropertySetBuilder.IntStep)b.withInt().select(data, "getObsCount", null)).display("Obs count")).add();
/* 182:182 */         ((NodePropertySetBuilder.DefaultStep)b.with(TsData.class).select(ts, "getTsData", null)).display("Values").add();
/* 183:183 */         result.put(b.build());
/* 184:    */       }
/* 185:    */       
/* 186:186 */       if (ts.hasMetaData() == TsStatus.Valid) {
/* 187:187 */         b.reset("Meta data");
/* 188:    */         
/* 189:189 */         for (Map.Entry<String, String> o : new TreeMap(ts.getMetaData()).entrySet()) {
/* 190:190 */           ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select((String)o.getKey(), (String)o.getValue())).add();
/* 191:    */         }
/* 192:192 */         result.put(b.build());
/* 193:    */       }
/* 194:    */       
/* 195:195 */       return result;
/* 196:    */     }
/* 197:    */   }
/* 198:    */ }
