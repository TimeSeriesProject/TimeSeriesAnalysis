/*  1:   */ package ec.nbdemetra.ui.nodes;
/*  2:   */ 
/*  3:   */ import java.awt.Image;
/*  4:   */ import javax.swing.Action;
/*  5:   */ import org.openide.nodes.AbstractNode;
/*  6:   */ import org.openide.nodes.Children;
/*  7:   */ import org.openide.nodes.Node;
/*  8:   */ import org.openide.util.ImageUtilities;
/*  9:   */ import org.openide.util.Lookup;
/* 10:   */ import org.openide.util.lookup.Lookups;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public abstract class BasicNode<LTYPE>
/* 19:   */   extends AbstractNode
/* 20:   */ {
/* 21:   */   protected final BasicChildFactory<?> factory;
/* 22:   */   protected final Class<LTYPE> clazz;
/* 23:   */   protected final String actionPath;
/* 24:   */   
/* 25:   */   public BasicNode(BasicChildFactory<?> factory, LTYPE objectToLookup, String actionPath)
/* 26:   */   {
/* 27:27 */     super(factory != null ? Children.create(factory, true) : Children.LEAF, Lookups.singleton(objectToLookup));
/* 28:28 */     this.factory = factory;
/* 29:29 */     clazz = objectToLookup.getClass();
/* 30:30 */     this.actionPath = actionPath;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public BasicNode(Children children, LTYPE objectToLookup, String actionPath) {
/* 34:34 */     super(children, Lookups.singleton(objectToLookup));
/* 35:35 */     factory = null;
/* 36:36 */     clazz = objectToLookup.getClass();
/* 37:37 */     this.actionPath = actionPath;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public BasicChildFactory<?> getFactory() {
/* 41:41 */     return factory;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public LTYPE lookup() {
/* 45:45 */     return getLookup().lookup(clazz);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public Action[] getActions(boolean context)
/* 49:   */   {
/* 50:50 */     return Nodes.actionsForPath(actionPath);
/* 51:   */   }
/* 52:   */   
/* 53:   */   protected Image mergeExceptionBadge(Image image) {
/* 54:54 */     if ((factory != null) && (factory.getException() != null)) {
/* 55:55 */       Image badge = ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/exclamation-small-red.png", false);
/* 56:56 */       return ImageUtilities.mergeImages(image, badge, 0, 0);
/* 57:   */     }
/* 58:58 */     return image;
/* 59:   */   }
/* 60:   */   
/* 61:   */   protected Image annotate(Image image) {
/* 62:62 */     Image result = image;
/* 63:63 */     for (Annotator o : Lookup.getDefault().lookupAll(Annotator.class)) {
/* 64:64 */       result = o.annotateIcon(this, result);
/* 65:   */     }
/* 66:66 */     return mergeExceptionBadge(result);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public Image getIcon(int type)
/* 70:   */   {
/* 71:71 */     return annotate(super.getIcon(type));
/* 72:   */   }
/* 73:   */   
/* 74:   */   public Image getOpenedIcon(int type)
/* 75:   */   {
/* 76:76 */     return annotate(super.getOpenedIcon(type));
/* 77:   */   }
/* 78:   */   
/* 79:   */   public String getDisplayName()
/* 80:   */   {
/* 81:81 */     String result = super.getDisplayName();
/* 82:82 */     for (Annotator o : Lookup.getDefault().lookupAll(Annotator.class)) {
/* 83:83 */       result = o.annotateName(this, result);
/* 84:   */     }
/* 85:85 */     return result;
/* 86:   */   }
/* 87:   */   
/* 88:   */   public void refreshAnnotation() {
/* 89:89 */     fireIconChange();
/* 90:90 */     fireOpenedIconChange();
/* 91:   */   }
/* 92:   */   
/* 93:   */   public static abstract interface Annotator
/* 94:   */   {
/* 95:   */     public abstract Image annotateIcon(Node paramNode, Image paramImage);
/* 96:   */     
/* 97:   */     public abstract String annotateName(Node paramNode, String paramString);
/* 98:   */   }
/* 99:   */ }
