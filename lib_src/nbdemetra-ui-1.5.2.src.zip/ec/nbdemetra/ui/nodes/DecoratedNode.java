/*   1:    */ package ec.nbdemetra.ui.nodes;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Predicate;
/*   5:    */ import com.google.common.base.Predicates;
/*   6:    */ import com.google.common.collect.FluentIterable;
/*   7:    */ import com.google.common.collect.Iterables;
/*   8:    */ import ec.nbdemetra.ui.awt.JProperty;
/*   9:    */ import ec.nbdemetra.ui.awt.JProperty.Setter;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.List;
/*  13:    */ import javax.swing.AbstractAction;
/*  14:    */ import javax.swing.Action;
/*  15:    */ import org.openide.nodes.FilterNode;
/*  16:    */ import org.openide.nodes.FilterNode.Children;
/*  17:    */ import org.openide.nodes.Node;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class DecoratedNode
/*  37:    */   extends FilterNode
/*  38:    */ {
/*  39:    */   public static final String HTML_DECORATOR_PROPERTY = "htmlDecorator";
/*  40:    */   public static final String PREFERRED_ACTION_DECORATOR_PROPERTY = "preferredActionDecorator";
/*  41:    */   protected final JProperty<Function<Node, String>> htmlDecorator;
/*  42:    */   protected final JProperty<Function<Node, Action>> preferredActionDecorator;
/*  43:    */   
/*  44:    */   public DecoratedNode(Node original)
/*  45:    */   {
/*  46: 46 */     this(original, Predicates.alwaysTrue());
/*  47:    */   }
/*  48:    */   
/*  49:    */   public DecoratedNode(Node original, Predicate<Node> filter) {
/*  50: 50 */     super(original, original.isLeaf() ? FilterNode.Children.LEAF : new DecoratedChildren(original, filter));
/*  51: 51 */     htmlDecorator = newProperty("htmlDecorator", JProperty.nullTo(Html.DEFAULT), null);
/*  52: 52 */     preferredActionDecorator = newProperty("preferredActionDecorator", JProperty.nullTo(PreferredAction.DEFAULT), null);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Node getOriginal()
/*  56:    */   {
/*  57: 57 */     return super.getOriginal();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void setHtmlDecorator(Function<Node, String> decorator) {
/*  61: 61 */     htmlDecorator.set(decorator);
/*  62: 62 */     fireDisplayNameChange(null, getHtmlDisplayName());
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setPreferredActionDecorator(Function<Node, Action> decorator) {
/*  66: 66 */     preferredActionDecorator.set(decorator);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getHtmlDisplayName()
/*  70:    */   {
/*  71: 71 */     return (String)((Function)htmlDecorator.get()).apply(getOriginal());
/*  72:    */   }
/*  73:    */   
/*  74:    */   public Action getPreferredAction()
/*  75:    */   {
/*  76: 76 */     return (Action)((Function)preferredActionDecorator.get()).apply(getOriginal());
/*  77:    */   }
/*  78:    */   
/*  79:    */   public FluentIterable<DecoratedNode> breadthFirstIterable() {
/*  80: 80 */     return Nodes.breadthFirstIterable(this).filter(DecoratedNode.class);
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected final <T> JProperty<T> newProperty(String name, JProperty.Setter<T> setter, T initialValue) {
/*  84: 84 */     new JProperty(name, setter, setter.apply(null, initialValue))
/*  85:    */     {
/*  86:    */       protected void firePropertyChange(T oldValue, T newValue) {
/*  87: 87 */         firePropertyChange(getName(), oldValue, newValue);
/*  88:    */       }
/*  89:    */     };
/*  90:    */   }
/*  91:    */   
/*  92:    */   private static class DecoratedChildren extends FilterNode.Children
/*  93:    */   {
/*  94:    */     private final Predicate<Node> filter;
/*  95:    */     
/*  96:    */     public DecoratedChildren(Node owner, Predicate<Node> filter) {
/*  97: 97 */       super();
/*  98: 98 */       this.filter = filter;
/*  99:    */     }
/* 100:    */     
/* 101:    */     protected Node copyNode(Node original)
/* 102:    */     {
/* 103:103 */       return new DecoratedNode(original, filter);
/* 104:    */     }
/* 105:    */     
/* 106:    */     protected Node[] createNodes(Node key)
/* 107:    */     {
/* 108:108 */       List<Node> result = new ArrayList();
/* 109:109 */       for (Node o : super.createNodes(key)) {
/* 110:110 */         if (filter.apply(((DecoratedNode)o).getOriginal())) {
/* 111:111 */           result.add(o);
/* 112:    */         }
/* 113:    */       }
/* 114:114 */       return (Node[])Iterables.toArray(result, Node.class);
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static abstract enum Html implements Function<Node, String>
/* 119:    */   {
/* 120:120 */     DEFAULT, 
/* 121:    */     
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:126 */     BOLD;
/* 127:    */   }
/* 128:    */   
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */   public static abstract enum PreferredAction
/* 134:    */     implements Function<Node, Action>
/* 135:    */   {
/* 136:136 */     DEFAULT, 
/* 137:    */     
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:142 */     DO_NOTHING;
/* 143:    */   }
/* 144:    */   
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:154 */   public static final Function<DecoratedNode, Node> TO_ORIGINAL = new Function()
/* 155:    */   {
/* 156:    */     public Node apply(DecoratedNode input) {
/* 157:157 */       return input.getOriginal();
/* 158:    */     }
/* 159:    */   };
/* 160:    */ }
