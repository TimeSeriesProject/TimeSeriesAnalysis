/*  1:   */ package ec.nbdemetra.ui.nodes;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Iterables;
/*  4:   */ import ec.tstoolkit.design.IBuilder;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import java.util.List;
/*  8:   */ import org.openide.nodes.AbstractNode;
/*  9:   */ import org.openide.nodes.Children;
/* 10:   */ import org.openide.nodes.Children.Array;
/* 11:   */ import org.openide.nodes.Index.ArrayChildren;
/* 12:   */ import org.openide.nodes.Node;
/* 13:   */ import org.openide.nodes.Sheet;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class AbstractNodeBuilder
/* 21:   */   implements IBuilder<AbstractNode>
/* 22:   */ {
/* 23:   */   final List<Node> nodes;
/* 24:   */   String name;
/* 25:   */   boolean orderable;
/* 26:   */   Sheet sheet;
/* 27:   */   
/* 28:   */   public AbstractNodeBuilder()
/* 29:   */   {
/* 30:30 */     nodes = new ArrayList();
/* 31:31 */     name = null;
/* 32:32 */     orderable = true;
/* 33:33 */     sheet = null;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public AbstractNodeBuilder add(Node node) {
/* 37:37 */     nodes.add(node);
/* 38:38 */     return this;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public AbstractNodeBuilder add(Iterable<? extends Node> nodes) {
/* 42:42 */     Iterables.addAll(this.nodes, nodes);
/* 43:43 */     return this;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public AbstractNodeBuilder add(Node[] nodes) {
/* 47:47 */     return add(Arrays.asList(nodes));
/* 48:   */   }
/* 49:   */   
/* 50:   */   public AbstractNodeBuilder name(String name) {
/* 51:51 */     this.name = name;
/* 52:52 */     return this;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public AbstractNodeBuilder orderable(boolean orderable) {
/* 56:56 */     this.orderable = orderable;
/* 57:57 */     return this;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public AbstractNodeBuilder sheet(Sheet sheet) {
/* 61:61 */     this.sheet = sheet;
/* 62:62 */     return this;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public AbstractNode build()
/* 66:   */   {
/* 67:67 */     Children children = orderable ? new Index.ArrayChildren() : nodes.isEmpty() ? Children.LEAF : new Children.Array();
/* 68:68 */     children.add((Node[])Iterables.toArray(nodes, Node.class));
/* 69:69 */     CustomNode result = new CustomNode(children, sheet);
/* 70:70 */     if (name != null) {
/* 71:71 */       result.setName(name);
/* 72:   */     }
/* 73:73 */     return result;
/* 74:   */   }
/* 75:   */   
/* 76:   */   static class CustomNode extends AbstractNode
/* 77:   */   {
/* 78:   */     final Sheet sheet;
/* 79:   */     
/* 80:   */     CustomNode(Children children, Sheet sheet) {
/* 81:81 */       super();
/* 82:82 */       this.sheet = sheet;
/* 83:   */     }
/* 84:   */     
/* 85:   */     protected Sheet createSheet()
/* 86:   */     {
/* 87:87 */       return sheet != null ? sheet : super.createSheet();
/* 88:   */     }
/* 89:   */   }
/* 90:   */ }
