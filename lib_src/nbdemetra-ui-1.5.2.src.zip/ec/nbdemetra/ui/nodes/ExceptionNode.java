/*   1:    */ package ec.nbdemetra.ui.nodes;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.NbComponents;
/*   4:    */ import ec.nbdemetra.ui.awt.ExceptionPanel;
/*   5:    */ import java.awt.BorderLayout;
/*   6:    */ import java.awt.Dialog;
/*   7:    */ import java.awt.Image;
/*   8:    */ import java.awt.KeyboardFocusManager;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import javax.annotation.Nonnull;
/*  11:    */ import javax.swing.AbstractAction;
/*  12:    */ import javax.swing.Action;
/*  13:    */ import org.openide.DialogDisplayer;
/*  14:    */ import org.openide.nodes.AbstractNode;
/*  15:    */ import org.openide.nodes.Children;
/*  16:    */ import org.openide.nodes.Node;
/*  17:    */ import org.openide.util.ImageUtilities;
/*  18:    */ import org.openide.util.Lookup;
/*  19:    */ import org.openide.util.lookup.Lookups;
/*  20:    */ import org.openide.windows.TopComponent;
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ public class ExceptionNode
/*  42:    */   extends AbstractNode
/*  43:    */ {
/*  44:    */   public static final String ACTION_PATH = "Demetra/Exception/Actions";
/*  45: 45 */   private static int internalCounter = 0;
/*  46:    */   
/*  47:    */   public ExceptionNode(@Nonnull Exception ex) {
/*  48: 48 */     super(Children.LEAF, Lookups.fixed(new Object[] { ex, Integer.valueOf(internalCounter++) }));
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String getHtmlDisplayName()
/*  52:    */   {
/*  53: 53 */     Exception ex = (Exception)getLookup().lookup(Exception.class);
/*  54: 54 */     return "<b>" + ex.getClass().getSimpleName() + "</b>: " + ex.getMessage();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Image getIcon(int type)
/*  58:    */   {
/*  59: 59 */     return ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/exclamation-red.png", true);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Image getOpenedIcon(int type)
/*  63:    */   {
/*  64: 64 */     return super.getIcon(type);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Action[] getActions(boolean context)
/*  68:    */   {
/*  69: 69 */     return Nodes.actionsForPath("Demetra/Exception/Actions");
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Action getPreferredAction()
/*  73:    */   {
/*  74: 74 */     return ShowDetails.INSTANCE;
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static final class ShowDetails extends AbstractAction
/*  78:    */   {
/*  79: 79 */     private static final ShowDetails INSTANCE = new ShowDetails();
/*  80:    */     
/*  81:    */     public void actionPerformed(ActionEvent e)
/*  82:    */     {
/*  83: 83 */       actionPerformed((Node)e.getSource());
/*  84:    */     }
/*  85:    */     
/*  86:    */     private void actionPerformed(Node node) {
/*  87: 87 */       int id = ((Integer)node.getLookup().lookup(Integer.class)).intValue();
/*  88: 88 */       Exception ex = (Exception)node.getLookup().lookup(Exception.class);
/*  89: 89 */       if (isInModalDialog()) {
/*  90: 90 */         showDialog(ex);
/*  91:    */       } else {
/*  92: 92 */         showTopComponent(id, ex);
/*  93:    */       }
/*  94:    */     }
/*  95:    */     
/*  96:    */     private static void showTopComponent(int id, Exception exception) {
/*  97: 97 */       String name = "exception" + id;
/*  98: 98 */       TopComponent c = NbComponents.findTopComponentByNameAndClass(name, TopComponent.class);
/*  99: 99 */       if (c == null) {
/* 100:100 */         c = new TopComponent()
/* 101:    */         {
/* 102:    */           public int getPersistenceType() {
/* 103:103 */             return 2;
/* 104:    */           }
/* 105:105 */         };
/* 106:106 */         c.setName(name);
/* 107:107 */         c.setDisplayName(exception.getClass().getSimpleName());
/* 108:108 */         c.setLayout(new BorderLayout());
/* 109:109 */         c.add(ExceptionPanel.create(exception), "Center");
/* 110:110 */         c.open();
/* 111:    */       }
/* 112:112 */       c.requestActive();
/* 113:    */     }
/* 114:    */     
/* 115:    */     private static void showDialog(Exception exception) {
/* 116:116 */       ExceptionPanel p = ExceptionPanel.create(exception);
/* 117:117 */       DialogDisplayer.getDefault().notify(p.createDialogDescriptor(exception.getClass().getSimpleName()));
/* 118:    */     }
/* 119:    */     
/* 120:    */     private static boolean isInModalDialog() {
/* 121:121 */       return KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusedWindow() instanceof Dialog;
/* 122:    */     }
/* 123:    */   }
/* 124:    */ }
