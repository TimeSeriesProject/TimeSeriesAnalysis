/*  1:   */ package ec.nbdemetra.ui.nodes;
/*  2:   */ 
/*  3:   */ import javax.annotation.Nonnull;
/*  4:   */ import org.openide.nodes.Node;
/*  5:   */ import org.openide.util.HelpCtx;
/*  6:   */ import org.openide.util.actions.NodeAction;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public abstract class SingleNodeAction<T extends Node>
/* 30:   */   extends NodeAction
/* 31:   */ {
/* 32:   */   private final Class<T> nodeType;
/* 33:   */   
/* 34:   */   public SingleNodeAction(@Nonnull Class<T> nodeType)
/* 35:   */   {
/* 36:36 */     this.nodeType = nodeType;
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected final void performAction(Node[] nodes)
/* 40:   */   {
/* 41:41 */     performAction(nodes[0]);
/* 42:   */   }
/* 43:   */   
/* 44:   */   protected final boolean enable(Node[] activatedNodes)
/* 45:   */   {
/* 46:46 */     return (activatedNodes.length == 1) && 
/* 47:47 */       (nodeType.isInstance(activatedNodes[0])) && 
/* 48:48 */       (enable(activatedNodes[0]));
/* 49:   */   }
/* 50:   */   
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */   protected abstract void performAction(@Nonnull T paramT);
/* 56:   */   
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */   protected abstract boolean enable(@Nonnull T paramT);
/* 62:   */   
/* 63:   */ 
/* 64:   */ 
/* 65:   */ 
/* 66:   */   @Deprecated
/* 67:   */   protected T getSingleNode(Node[] activatedNodes)
/* 68:   */   {
/* 69:69 */     return activatedNodes[0];
/* 70:   */   }
/* 71:   */   
/* 72:   */   protected boolean asynchronous()
/* 73:   */   {
/* 74:74 */     return false;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public HelpCtx getHelpCtx()
/* 78:   */   {
/* 79:79 */     return null;
/* 80:   */   }
/* 81:   */ }
