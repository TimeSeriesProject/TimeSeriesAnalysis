/*  1:   */ package ec.nbdemetra.ui.nodes;
/*  2:   */ 
/*  3:   */ import java.awt.Image;
/*  4:   */ import javax.annotation.Nonnull;
/*  5:   */ import org.openide.nodes.Node;
/*  6:   */ import org.openide.util.Lookup;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public abstract interface NodeAnnotator
/* 20:   */ {
/* 21:   */   public abstract Image annotateIcon(Node paramNode, Image paramImage);
/* 22:   */   
/* 23:   */   public abstract String annotateName(Node paramNode, String paramString);
/* 24:   */   
/* 25:   */   public static class Support
/* 26:   */   {
/* 27:   */     @Nonnull
/* 28:   */     public static Support getDefault()
/* 29:   */     {
/* 30:30 */       return (Support)Lookup.getDefault().lookup(Support.class);
/* 31:   */     }
/* 32:   */     
/* 33:   */     @Deprecated
/* 34:   */     public static Support getInstance() {
/* 35:35 */       return getDefault();
/* 36:   */     }
/* 37:   */     
/* 38:   */     public Image annotateIcon(Node node, Image image) {
/* 39:39 */       Image result = image;
/* 40:40 */       for (NodeAnnotator o : Lookup.getDefault().lookupAll(NodeAnnotator.class)) {
/* 41:41 */         result = o.annotateIcon(node, result);
/* 42:   */       }
/* 43:43 */       return result;
/* 44:   */     }
/* 45:   */     
/* 46:   */     public String annotateName(Node node, String name) {
/* 47:47 */       String result = name;
/* 48:48 */       for (NodeAnnotator o : Lookup.getDefault().lookupAll(NodeAnnotator.class)) {
/* 49:49 */         result = o.annotateName(node, result);
/* 50:   */       }
/* 51:51 */       return result;
/* 52:   */     }
/* 53:   */   }
/* 54:   */ }
