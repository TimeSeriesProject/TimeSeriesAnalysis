/*   1:    */ package ec.nbdemetra.ui.nodes;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   4:    */ import ec.tstoolkit.utilities.Id;
/*   5:    */ import ec.tstoolkit.utilities.LinearId;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.Font;
/*   9:    */ import java.awt.FontMetrics;
/*  10:    */ import java.awt.Graphics;
/*  11:    */ import java.awt.Graphics2D;
/*  12:    */ import java.awt.Image;
/*  13:    */ import java.awt.RenderingHints;
/*  14:    */ import java.util.HashMap;
/*  15:    */ import java.util.Iterator;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.Map;
/*  18:    */ import javax.swing.Icon;
/*  19:    */ import org.openide.nodes.AbstractNode;
/*  20:    */ import org.openide.nodes.Children;
/*  21:    */ import org.openide.nodes.Children.Array;
/*  22:    */ import org.openide.nodes.Node;
/*  23:    */ import org.openide.util.ImageUtilities;
/*  24:    */ import org.openide.util.Lookup;
/*  25:    */ 
/*  26:    */ public final class IdNodes
/*  27:    */ {
/*  28:    */   static abstract interface INodeFactory<T>
/*  29:    */   {
/*  30:    */     public abstract Node create(Children paramChildren, T paramT);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static class IdIcon implements Icon
/*  34:    */   {
/*  35:    */     final Id id;
/*  36:    */     
/*  37:    */     public IdIcon(Id id)
/*  38:    */     {
/*  39: 39 */       this.id = id;
/*  40:    */     }
/*  41:    */     
/*  42:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/*  43:    */     {
/*  44: 44 */       g.drawImage(DemetraUiIcon.DOCUMENT_16.getImageIcon().getImage(), x, y, null);
/*  45: 45 */       String tail = id.tail();
/*  46: 46 */       if (!com.google.common.base.Strings.isNullOrEmpty(tail)) {
/*  47: 47 */         Graphics2D g2 = (Graphics2D)g;
/*  48: 48 */         Font old = c.getFont();
/*  49: 49 */         Color oldColor = c.getForeground();
/*  50: 50 */         g.setFont(c.getFont().deriveFont(7.0F));
/*  51: 51 */         g.setColor(Color.DARK_GRAY);
/*  52: 52 */         g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  53: 53 */         drawCenteredString(Character.toString(tail.charAt(0)), x + 17, y + 20, g);
/*  54: 54 */         g.setColor(oldColor);
/*  55: 55 */         g.setFont(old);
/*  56:    */       }
/*  57:    */     }
/*  58:    */     
/*  59:    */     public void drawCenteredString(String s, int w, int h, Graphics g) {
/*  60: 60 */       FontMetrics fm = g.getFontMetrics();
/*  61: 61 */       int x = (w - fm.stringWidth(s)) / 2;
/*  62: 62 */       int y = fm.getAscent() + (h - (fm.getAscent() + fm.getDescent())) / 2;
/*  63: 63 */       g.drawString(s, x, y);
/*  64:    */     }
/*  65:    */     
/*  66:    */     public int getIconWidth()
/*  67:    */     {
/*  68: 68 */       return 16;
/*  69:    */     }
/*  70:    */     
/*  71:    */ 
/*  72:    */ 
/*  73: 73 */     public int getIconHeight() { return 16; }
/*  74:    */   }
/*  75:    */   
/*  76: 76 */   static final INodeFactory<Id> FACTORY = new INodeFactory()
/*  77:    */   {
/*  78:    */     public Node create(Children children, Id id)
/*  79:    */     {
/*  80: 80 */       AbstractNode result = new AbstractNode(children, org.openide.util.lookup.Lookups.singleton(id))
/*  81:    */       {
/*  82:    */         final IdNodes.IdIcon icon;
/*  83:    */         
/*  84:    */         public Image getIcon(int type)
/*  85:    */         {
/*  86: 86 */           return ImageUtilities.icon2Image(icon);
/*  87:    */         }
/*  88:    */         
/*  89:    */         public Image getOpenedIcon(int type)
/*  90:    */         {
/*  91: 91 */           return getIcon(type);
/*  92:    */         }
/*  93: 93 */       };
/*  94: 94 */       result.setName(id.tail());
/*  95: 95 */       return result;
/*  96:    */     }
/*  97:    */   };
/*  98:    */   
/*  99:    */   public static Node getRootNode2(List<Id> list) {
/* 100:100 */     Node root = FACTORY.create(new Children.Array(), new LinearId());
/* 101:101 */     Map<Id, Node> index = new HashMap();
/* 102:102 */     int j; int i; for (Iterator localIterator = list.iterator(); localIterator.hasNext(); 
/* 103:    */         
/* 104:104 */         i < j)
/* 105:    */     {
/* 106:102 */       Id id = (Id)localIterator.next();
/* 107:103 */       Node prev = root;
/* 108:104 */       Id[] arrayOfId; j = (arrayOfId = id.path()).length;i = 0; continue;Id pathItem = arrayOfId[i];
/* 109:105 */       Node cur = (Node)index.get(pathItem);
/* 110:106 */       if (cur == null) {
/* 111:107 */         cur = FACTORY.create(new Children.Array(), pathItem);
/* 112:108 */         prev.getChildren().add(new Node[] { cur });
/* 113:109 */         index.put(pathItem, cur);
/* 114:    */       }
/* 115:111 */       prev = cur;i++;
/* 116:    */     }
/* 117:    */     
/* 118:114 */     return root;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static Node getRootNode(List<Id> list) {
/* 122:118 */     NodeBuilder root = new NodeBuilder(FACTORY, new LinearId());
/* 123:119 */     Map<Id, NodeBuilder> index = new HashMap();
/* 124:120 */     int j; int i; for (Iterator localIterator = list.iterator(); localIterator.hasNext(); 
/* 125:    */         
/* 126:122 */         i < j)
/* 127:    */     {
/* 128:120 */       Id id = (Id)localIterator.next();
/* 129:121 */       NodeBuilder prev = root;
/* 130:122 */       Id[] arrayOfId; j = (arrayOfId = id.path()).length;i = 0; continue;Id pathItem = arrayOfId[i];
/* 131:123 */       NodeBuilder cur = (NodeBuilder)index.get(pathItem);
/* 132:124 */       if (cur == null) {
/* 133:125 */         cur = prev.addAndGet(pathItem);
/* 134:126 */         index.put(pathItem, cur);
/* 135:    */       }
/* 136:128 */       prev = cur;i++;
/* 137:    */     }
/* 138:    */     
/* 139:131 */     return root.build();
/* 140:    */   }
/* 141:    */   
/* 142:    */ 
/* 143:    */   static class NodeBuilder<T>
/* 144:    */     implements ec.tstoolkit.design.IBuilder<Node>
/* 145:    */   {
/* 146:    */     private final T id;
/* 147:    */     
/* 148:    */     private final IdNodes.INodeFactory<T> factory;
/* 149:    */     
/* 150:    */     private final List<NodeBuilder> children;
/* 151:    */     
/* 152:    */     NodeBuilder(IdNodes.INodeFactory<T> factory, T id)
/* 153:    */     {
/* 154:146 */       this.id = id;
/* 155:147 */       this.factory = factory;
/* 156:148 */       children = new java.util.ArrayList();
/* 157:    */     }
/* 158:    */     
/* 159:    */     public NodeBuilder<T> addAndGet(T id) {
/* 160:152 */       NodeBuilder result = new NodeBuilder(factory, id);
/* 161:153 */       children.add(result);
/* 162:154 */       return result;
/* 163:    */     }
/* 164:    */     
/* 165:    */     public Node build()
/* 166:    */     {
/* 167:159 */       if (children.isEmpty()) {
/* 168:160 */         return factory.create(Children.LEAF, id);
/* 169:    */       }
/* 170:162 */       Node[] nodes = new Node[children.size()];
/* 171:163 */       for (int i = 0; i < nodes.length; i++) {
/* 172:164 */         nodes[i] = ((NodeBuilder)children.get(i)).build();
/* 173:    */       }
/* 174:166 */       Children result = new Children.Array();
/* 175:167 */       result.add(nodes);
/* 176:168 */       return factory.create(result, id);
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static Node findNode(Node root, Id id) {
/* 181:173 */     Node node = root;
/* 182:174 */     for (int i = 0; i < id.getCount(); i++) {
/* 183:175 */       node = node.getChildren().findChild(id.get(i));
/* 184:176 */       if (node == null) {
/* 185:177 */         return null;
/* 186:    */       }
/* 187:    */     }
/* 188:180 */     return node;
/* 189:    */   }
/* 190:    */ }
