/*   1:    */ package ec.nbdemetra.ui.nodes;
/*   2:    */ 
/*   3:    */ import com.google.common.collect.FluentIterable;
/*   4:    */ import com.google.common.collect.Iterables;
/*   5:    */ import com.google.common.collect.Iterators;
/*   6:    */ import com.google.common.collect.UnmodifiableIterator;
/*   7:    */ import ec.tstoolkit.design.UtilityClass;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Deque;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.LinkedList;
/*  13:    */ import java.util.Stack;
/*  14:    */ import javax.annotation.Nonnull;
/*  15:    */ import javax.swing.Action;
/*  16:    */ import org.openide.nodes.Children;
/*  17:    */ import org.openide.nodes.Node;
/*  18:    */ import org.openide.util.Utilities;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ @UtilityClass({Node.class})
/*  44:    */ public final class Nodes
/*  45:    */ {
/*  46:    */   @Nonnull
/*  47:    */   public static Action[] actionsForPath(@Nonnull String path)
/*  48:    */   {
/*  49: 49 */     return (Action[])Iterables.toArray(Utilities.actionsForPath(path), Action.class);
/*  50:    */   }
/*  51:    */   
/*  52:    */   @Nonnull
/*  53:    */   public static FluentIterable<Node> childrenIterable(@Nonnull Node root) {
/*  54: 54 */     return FluentIterable.from(root.isLeaf() ? Collections.emptyList() : Arrays.asList(root.getChildren().getNodes()));
/*  55:    */   }
/*  56:    */   
/*  57:    */   @Nonnull
/*  58:    */   public static FluentIterable<Node> breadthFirstIterable(@Nonnull Node root) {
/*  59: 59 */     return FluentIterable.from(root.isLeaf() ? Collections.singleton(root) : new BreadthFirstIterable(root));
/*  60:    */   }
/*  61:    */   
/*  62:    */   @Nonnull
/*  63:    */   public static FluentIterable<Node> depthFirstIterable(@Nonnull Node root) {
/*  64: 64 */     return FluentIterable.from(root.isLeaf() ? Collections.singleton(root) : new DepthFirstIterable(root));
/*  65:    */   }
/*  66:    */   
/*  67:    */   @Nonnull
/*  68:    */   public static FluentIterable<Node> asIterable(@Nonnull Node[] nodes) {
/*  69: 69 */     return FluentIterable.from(Arrays.asList(nodes));
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static class BreadthFirstIterable implements Iterable<Node>
/*  73:    */   {
/*  74:    */     private final Node root;
/*  75:    */     
/*  76:    */     public BreadthFirstIterable(Node root)
/*  77:    */     {
/*  78: 78 */       this.root = root;
/*  79:    */     }
/*  80:    */     
/*  81:    */     public Iterator<Node> iterator()
/*  82:    */     {
/*  83: 83 */       final Deque<Node> queue = new LinkedList();
/*  84: 84 */       queue.add(root);
/*  85: 85 */       new UnmodifiableIterator()
/*  86:    */       {
/*  87:    */         public boolean hasNext() {
/*  88: 88 */           return !queue.isEmpty();
/*  89:    */         }
/*  90:    */         
/*  91:    */         public Node next()
/*  92:    */         {
/*  93: 93 */           Node result = (Node)queue.removeFirst();
/*  94: 94 */           if (!result.isLeaf()) {
/*  95: 95 */             Collections.addAll(queue, result.getChildren().getNodes());
/*  96:    */           }
/*  97: 97 */           return result;
/*  98:    */         }
/*  99:    */       };
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static class DepthFirstIterable implements Iterable<Node>
/* 104:    */   {
/* 105:    */     private final Node root;
/* 106:    */     
/* 107:    */     public DepthFirstIterable(Node root) {
/* 108:108 */       this.root = root;
/* 109:    */     }
/* 110:    */     
/* 111:    */     public Iterator<Node> iterator()
/* 112:    */     {
/* 113:113 */       final Stack<Iterator<Node>> stack = new Stack();
/* 114:114 */       stack.push(Iterators.singletonIterator(root));
/* 115:115 */       new UnmodifiableIterator()
/* 116:    */       {
/* 117:    */         public boolean hasNext() {
/* 118:118 */           return (!stack.isEmpty()) && (((Iterator)stack.peek()).hasNext());
/* 119:    */         }
/* 120:    */         
/* 121:    */         public Node next()
/* 122:    */         {
/* 123:123 */           Iterator<Node> top = (Iterator)stack.peek();
/* 124:124 */           Node result = (Node)top.next();
/* 125:125 */           if (!top.hasNext()) {
/* 126:126 */             stack.pop();
/* 127:    */           }
/* 128:128 */           if (!result.isLeaf()) {
/* 129:129 */             stack.push(Iterators.forEnumeration(result.getChildren().nodes()));
/* 130:    */           }
/* 131:131 */           return result;
/* 132:    */         }
/* 133:    */       };
/* 134:    */     }
/* 135:    */   }
/* 136:    */ }
