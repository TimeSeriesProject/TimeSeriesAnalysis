/*   1:    */ package ec.nbdemetra.ui.nodes;
/*   2:    */ 
/*   3:    */ import ec.util.various.swing.OnAnyThread;
/*   4:    */ import ec.util.various.swing.OnEDT;
/*   5:    */ import java.util.List;
/*   6:    */ import javax.annotation.Nonnull;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ import org.openide.nodes.ChildFactory.Detachable;
/*   9:    */ import org.openide.nodes.Node;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ public abstract class FailSafeChildFactory
/*  28:    */   extends ChildFactory.Detachable<Object>
/*  29:    */ {
/*  30:    */   @OnAnyThread
/*  31:    */   protected abstract boolean tryCreateKeys(@Nonnull List<Object> paramList)
/*  32:    */     throws Exception;
/*  33:    */   
/*  34:    */   @OnEDT
/*  35:    */   @Nullable
/*  36:    */   protected Node tryCreateNodeForKey(@Nonnull Object key)
/*  37:    */     throws Exception
/*  38:    */   {
/*  39: 39 */     throw new AssertionError("Neither tryCreateNodeForKey() nor tryCreateNodesForKey() overridden in " + getClass().getName());
/*  40:    */   }
/*  41:    */   
/*  42:    */   @OnEDT
/*  43:    */   @Nullable
/*  44:    */   protected Node[] tryCreateNodesForKey(@Nonnull Object key) throws Exception {
/*  45: 45 */     Node n = tryCreateNodeForKey(key);
/*  46: 46 */     return new Node[] { n == null ? null : n };
/*  47:    */   }
/*  48:    */   
/*  49:    */   @OnEDT
/*  50:    */   @Nullable
/*  51:    */   protected Node createExceptionNode(@Nonnull Exception ex) {
/*  52: 52 */     return new ExceptionNode(ex);
/*  53:    */   }
/*  54:    */   
/*  55:    */   @OnEDT
/*  56:    */   @Nullable
/*  57:    */   protected Node[] createExceptionNodes(@Nonnull Exception ex) {
/*  58: 58 */     Node n = createExceptionNode(ex);
/*  59: 59 */     return new Node[] { n == null ? null : n };
/*  60:    */   }
/*  61:    */   
/*  62:    */   @OnEDT
/*  63:    */   @Nullable
/*  64:    */   protected Node createWaitNode()
/*  65:    */   {
/*  66: 66 */     return super.createWaitNode();
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected final boolean createKeys(List<Object> list)
/*  70:    */   {
/*  71:    */     try
/*  72:    */     {
/*  73: 73 */       return tryCreateKeys(list);
/*  74:    */     } catch (Exception ex) {
/*  75: 75 */       list.add(new ExceptionKey(ex)); }
/*  76: 76 */     return true;
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */   protected final Node createNodeForKey(Object key)
/*  81:    */   {
/*  82: 82 */     if ((key instanceof ExceptionKey)) {
/*  83: 83 */       return createExceptionNode(exception);
/*  84:    */     }
/*  85:    */     try {
/*  86: 86 */       return tryCreateNodeForKey(key);
/*  87:    */     } catch (Exception ex) {
/*  88: 88 */       return createExceptionNode(ex);
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   protected final Node[] createNodesForKey(Object key)
/*  93:    */   {
/*  94: 94 */     if ((key instanceof ExceptionKey)) {
/*  95: 95 */       return createExceptionNodes(exception);
/*  96:    */     }
/*  97:    */     try {
/*  98: 98 */       return tryCreateNodesForKey(key);
/*  99:    */     } catch (Exception ex) {
/* 100:100 */       return createExceptionNodes(ex);
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static final class ExceptionKey
/* 105:    */   {
/* 106:    */     private final Exception exception;
/* 107:    */     
/* 108:    */     public ExceptionKey(Exception exception) {
/* 109:109 */       this.exception = exception;
/* 110:    */     }
/* 111:    */   }
/* 112:    */ }
