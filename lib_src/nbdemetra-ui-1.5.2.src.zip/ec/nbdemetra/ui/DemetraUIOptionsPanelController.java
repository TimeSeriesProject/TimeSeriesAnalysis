/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.properties.DataFormatComponent2;
/*   4:    */ import java.beans.PropertyChangeListener;
/*   5:    */ import java.beans.PropertyChangeSupport;
/*   6:    */ import javax.swing.JComponent;
/*   7:    */ import org.netbeans.spi.options.OptionsPanelController;
/*   8:    */ import org.openide.util.HelpCtx;
/*   9:    */ import org.openide.util.Lookup;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public final class DemetraUIOptionsPanelController
/*  33:    */   extends OptionsPanelController
/*  34:    */ {
/*  35:    */   public static final String ID = "Demetra/DemetraUI";
/*  36:    */   private DemetraUIPanel panel;
/*  37: 37 */   private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
/*  38:    */   private boolean changed;
/*  39:    */   
/*  40:    */   public void update()
/*  41:    */   {
/*  42: 42 */     getPanel().getDataFormatComponent().setPreviewVisible(true);
/*  43: 43 */     getPanel().load();
/*  44: 44 */     changed = false;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void applyChanges()
/*  48:    */   {
/*  49: 49 */     getPanel().getDataFormatComponent().setPreviewVisible(false);
/*  50: 50 */     getPanel().store();
/*  51: 51 */     changed = false;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void cancel()
/*  55:    */   {
/*  56: 56 */     getPanel().getDataFormatComponent().setPreviewVisible(false);
/*  57:    */   }
/*  58:    */   
/*  59:    */ 
/*  60:    */   public boolean isValid()
/*  61:    */   {
/*  62: 62 */     return getPanel().valid();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean isChanged()
/*  66:    */   {
/*  67: 67 */     return changed;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public HelpCtx getHelpCtx()
/*  71:    */   {
/*  72: 72 */     return null;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public JComponent getComponent(Lookup masterLookup)
/*  76:    */   {
/*  77: 77 */     return getPanel();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void addPropertyChangeListener(PropertyChangeListener l)
/*  81:    */   {
/*  82: 82 */     pcs.addPropertyChangeListener(l);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void removePropertyChangeListener(PropertyChangeListener l)
/*  86:    */   {
/*  87: 87 */     pcs.removePropertyChangeListener(l);
/*  88:    */   }
/*  89:    */   
/*  90:    */   private DemetraUIPanel getPanel() {
/*  91: 91 */     if (panel == null) {
/*  92: 92 */       panel = new DemetraUIPanel(this);
/*  93:    */     }
/*  94: 94 */     return panel;
/*  95:    */   }
/*  96:    */   
/*  97:    */   void changed() {
/*  98: 98 */     if (!changed) {
/*  99: 99 */       changed = true;
/* 100:100 */       pcs.firePropertyChange("changed", false, true);
/* 101:    */     }
/* 102:102 */     pcs.firePropertyChange("valid", null, null);
/* 103:    */   }
/* 104:    */ }
