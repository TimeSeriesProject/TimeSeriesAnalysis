/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.awt.PopupListener;
/*   4:    */ import java.awt.event.MouseEvent;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import java.util.List;
/*   8:    */ import javax.swing.Action;
/*   9:    */ import javax.swing.JComponent;
/*  10:    */ import javax.swing.JMenu;
/*  11:    */ import javax.swing.JMenuItem;
/*  12:    */ import javax.swing.JPopupMenu;
/*  13:    */ import org.openide.awt.DynamicMenuContent;
/*  14:    */ import org.openide.util.ContextAwareAction;
/*  15:    */ import org.openide.util.Utilities;
/*  16:    */ import org.openide.util.actions.Presenter.Menu;
/*  17:    */ import org.openide.util.actions.Presenter.Popup;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public class Menus
/*  33:    */ {
/*  34:    */   public static Action[] createActions(Action[] defActions, String... paths)
/*  35:    */   {
/*  36: 36 */     ArrayList<Action> subActions = new ArrayList();
/*  37: 37 */     ArrayList<Action> actions = new ArrayList();
/*  38: 38 */     for (String path : paths) {
/*  39: 39 */       List<? extends Action> actionsForPath = Utilities.actionsForPath(path);
/*  40: 40 */       for (Action a : actionsForPath) {
/*  41: 41 */         if ((a instanceof Presenter.Popup)) {
/*  42: 42 */           List<Action> presenterActions = findSubActions((Presenter.Popup)a);
/*  43: 43 */           if (!presenterActions.isEmpty()) {
/*  44: 44 */             subActions.addAll(presenterActions);
/*  45:    */           }
/*  46:    */           
/*  47:    */         }
/*  48:    */         else
/*  49:    */         {
/*  50: 50 */           actions.add(a);
/*  51:    */         }
/*  52:    */       }
/*  53:    */     }
/*  54: 54 */     if (defActions != null) {
/*  55: 55 */       actions.addAll(Arrays.asList(defActions));
/*  56:    */     }
/*  57:    */     
/*  58:    */ 
/*  59: 59 */     actions.removeAll(subActions);
/*  60: 60 */     return (Action[])actions.toArray(new Action[actions.size()]);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void fillMenu(JMenu menu, String... paths) {
/*  64: 64 */     fillMenu(menu.getPopupMenu(), paths);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static void fillMenu(JPopupMenu menu, String... paths) {
/*  68: 68 */     fillMenu(menu, createActions(null, paths));
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static void fillMenu(JMenu menu, Action[] actions) {
/*  72: 72 */     fillMenu(menu.getPopupMenu(), actions);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void fillMenu(JPopupMenu menu, Action[] actions) {
/*  76: 76 */     boolean sep = false;
/*  77: 77 */     for (Action action : actions) {
/*  78: 78 */       if (action == null) {
/*  79: 79 */         if (sep) {
/*  80: 80 */           menu.addSeparator();
/*  81: 81 */           sep = false;
/*  82:    */         }
/*  83:    */       }
/*  84:    */       else {
/*  85: 85 */         sep = true;
/*  86: 86 */         if ((action instanceof DynamicMenuContent)) {
/*  87: 87 */           DynamicMenuContent dmenu = (DynamicMenuContent)action;
/*  88: 88 */           JComponent[] items = dmenu.getMenuPresenters();
/*  89: 89 */           if (items != null) {
/*  90: 90 */             for (int i = 0; i < items.length; i++) {
/*  91: 91 */               menu.add(items[i]);
/*  92:    */             }
/*  93:    */           }
/*  94:    */         }
/*  95: 95 */         else if ((action instanceof Presenter.Popup)) {
/*  96: 96 */           Presenter.Popup popup = (Presenter.Popup)action;
/*  97: 97 */           menu.add(popup.getPopupPresenter());
/*  98:    */         }
/*  99: 99 */         else if ((action instanceof Presenter.Menu)) {
/* 100:100 */           Presenter.Menu item = (Presenter.Menu)action;
/* 101:101 */           menu.add(item.getMenuPresenter());
/* 102:    */         }
/* 103:103 */         else if ((action instanceof ContextAwareAction)) {
/* 104:104 */           menu.add(((ContextAwareAction)action).createContextAwareInstance(Utilities.actionsGlobalContext()));
/* 105:    */         }
/* 106:    */         else {
/* 107:107 */           menu.add(action);
/* 108:    */         }
/* 109:    */       }
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static List<Action> findSubActions(Presenter.Popup subMenu) {
/* 114:114 */     List<Action> actions = new ArrayList();
/* 115:    */     
/* 116:116 */     JMenuItem item = subMenu.getPopupPresenter();
/* 117:117 */     if ((item instanceof JMenu)) {
/* 118:118 */       JMenu menu = (JMenu)item;
/* 119:119 */       for (int i = 0; i < menu.getItemCount(); i++) {
/* 120:120 */         JMenuItem cur = menu.getItem(i);
/* 121:121 */         if (cur != null) {
/* 122:122 */           Action a = menu.getItem(i).getAction();
/* 123:123 */           actions.add(a);
/* 124:    */           
/* 125:125 */           if ((a instanceof Presenter.Popup)) {
/* 126:126 */             actions.addAll(findSubActions((Presenter.Popup)a));
/* 127:    */           }
/* 128:    */         }
/* 129:    */       }
/* 130:    */     }
/* 131:    */     
/* 132:132 */     return actions;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static class DynamicPopup extends PopupListener
/* 136:    */   {
/* 137:    */     String[] paths;
/* 138:    */     
/* 139:    */     public DynamicPopup(String... paths) {
/* 140:140 */       this.paths = paths;
/* 141:    */     }
/* 142:    */     
/* 143:    */     protected JPopupMenu getPopup(MouseEvent e)
/* 144:    */     {
/* 145:145 */       JPopupMenu popup = new JPopupMenu();
/* 146:146 */       Menus.fillMenu(popup, paths);
/* 147:147 */       return popup;
/* 148:    */     }
/* 149:    */   }
/* 150:    */ }
