/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import java.awt.Frame;
/*   4:    */ import java.beans.PropertyVetoException;
/*   5:    */ import java.util.Collections;
/*   6:    */ import javax.swing.JFrame;
/*   7:    */ import javax.swing.JMenu;
/*   8:    */ import javax.swing.JMenuBar;
/*   9:    */ import javax.swing.event.MenuEvent;
/*  10:    */ import javax.swing.event.MenuListener;
/*  11:    */ import org.openide.explorer.ExplorerManager;
/*  12:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  13:    */ import org.openide.nodes.Node;
/*  14:    */ import org.openide.util.Exceptions;
/*  15:    */ import org.openide.util.Lookup;
/*  16:    */ import org.openide.util.Lookup.Provider;
/*  17:    */ import org.openide.util.lookup.AbstractLookup;
/*  18:    */ import org.openide.util.lookup.InstanceContent;
/*  19:    */ import org.openide.windows.TopComponent;
/*  20:    */ import org.openide.windows.TopComponent.Registry;
/*  21:    */ import org.openide.windows.WindowManager;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ public class ActiveViewManager
/*  30:    */   implements Lookup.Provider, ExplorerManager.Provider
/*  31:    */ {
/*  32: 32 */   public static ActiveViewManager getInstance() { return INSTANCE; }
/*  33:    */   
/*  34: 34 */   private static final ActiveViewManager INSTANCE = new ActiveViewManager();
/*  35:    */   private static final String ACTIVE = "_Active_View";
/*  36:    */   private static final int POS = 2;
/*  37: 37 */   private boolean updating = false;
/*  38: 38 */   private final InstanceContent content = new InstanceContent();
/*  39:    */   private final Lookup lookup;
/*  40: 40 */   private final ExplorerManager mgr = new ExplorerManager();
/*  41:    */   
/*  42:    */   public ExplorerManager getExplorerManager()
/*  43:    */   {
/*  44: 44 */     return mgr;
/*  45:    */   }
/*  46:    */   
/*  47:    */   private ActiveViewManager() {
/*  48: 48 */     lookup = new AbstractLookup(content);
/*  49: 49 */     mgr.setRootContext(Node.EMPTY);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void set(IActiveView view) {
/*  53: 53 */     if (view == null) {
/*  54: 54 */       content.set(Collections.EMPTY_SET, null);
/*  55:    */     }
/*  56:    */     else {
/*  57: 57 */       content.set(Collections.singleton(view), null);
/*  58: 58 */       Node node = view.getNode();
/*  59: 59 */       if (node != null) {
/*  60: 60 */         mgr.setRootContext(node);
/*  61:    */         try {
/*  62: 62 */           mgr.setSelectedNodes(new Node[] { node });
/*  63:    */         } catch (PropertyVetoException ex) {
/*  64: 64 */           Exceptions.printStackTrace(ex);
/*  65:    */         }
/*  66:    */       } else {
/*  67: 67 */         mgr.setRootContext(Node.EMPTY);
/*  68:    */       }
/*  69:    */     }
/*  70: 70 */     updateMenu(view);
/*  71:    */   }
/*  72:    */   
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */   private void updateMenu(IActiveView view)
/* 113:    */   {
/* 114:114 */     JMenu menu = activeMenu();
/* 115:115 */     if (menu == null) {
/* 116:116 */       return;
/* 117:    */     }
/* 118:118 */     if ((view == null) || (!view.hasContextMenu())) {
/* 119:119 */       menu.setVisible(false);
/* 120:    */     } else {
/* 121:121 */       menu.removeAll();
/* 122:122 */       menu.setVisible(true);
/* 123:123 */       menu.setText(view.getName());
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   private JMenu activeMenu() {
/* 128:128 */     Frame frame = WindowManager.getDefault().getMainWindow();
/* 129:129 */     if ((frame == null) || (!(frame instanceof JFrame))) {
/* 130:130 */       return null;
/* 131:    */     }
/* 132:132 */     JFrame mainWindow = (JFrame)frame;
/* 133:133 */     JMenuBar menuBar = mainWindow.getJMenuBar();
/* 134:134 */     if (menuBar == null) {
/* 135:135 */       return null;
/* 136:    */     }
/* 137:137 */     for (int i = 0; i < menuBar.getMenuCount(); i++) {
/* 138:138 */       JMenu cur = menuBar.getMenu(i);
/* 139:139 */       if ((cur != null) && ("_Active_View".equals(cur.getName()))) {
/* 140:140 */         return cur;
/* 141:    */       }
/* 142:    */     }
/* 143:143 */     final JMenu nmenu = new JMenu();
/* 144:144 */     nmenu.setName("_Active_View");
/* 145:145 */     menuBar.add(nmenu, 2);
/* 146:146 */     menuBar.validate();
/* 147:147 */     nmenu.addMenuListener(new MenuListener()
/* 148:    */     {
/* 149:    */       public void menuSelected(MenuEvent e) {
/* 150:150 */         if (updating) {
/* 151:151 */           return;
/* 152:    */         }
/* 153:153 */         nmenu.removeAll();
/* 154:154 */         IActiveView view = ActiveViewManager.this.currentView();
/* 155:155 */         if ((view != null) && (view.hasContextMenu())) {
/* 156:156 */           view.fill(nmenu);
/* 157:    */         }
/* 158:    */       }
/* 159:    */       
/* 160:    */ 
/* 161:    */ 
/* 162:    */       public void menuDeselected(MenuEvent e) {}
/* 163:    */       
/* 164:    */ 
/* 165:    */ 
/* 166:    */       public void menuCanceled(MenuEvent e) {}
/* 167:167 */     });
/* 168:168 */     return nmenu;
/* 169:    */   }
/* 170:    */   
/* 171:    */   private void fill(JMenu current) {
/* 172:    */     try {
/* 173:173 */       updating = true;
/* 174:174 */       TopComponent activated = WindowManager.getDefault().getRegistry().getActivated();
/* 175:175 */       if (activated != null) {
/* 176:176 */         IActiveView view = (activated instanceof IActiveView) ? (IActiveView)activated : (IActiveView)activated.getLookup().lookup(IActiveView.class);
/* 177:177 */         if (view == null) {
/* 178:178 */           current.setVisible(false);
/* 179:    */         } else {
/* 180:180 */           current.removeAll();
/* 181:181 */           current.setVisible(true);
/* 182:182 */           current.setText(activated.getName());
/* 183:    */         }
/* 184:    */       } else {
/* 185:185 */         current.setVisible(false);
/* 186:    */       }
/* 187:    */     } finally {
/* 188:188 */       updating = false;
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   private IActiveView currentView() {
/* 193:193 */     return (IActiveView)lookup.lookup(IActiveView.class);
/* 194:    */   }
/* 195:    */   
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */   public Lookup getLookup()
/* 233:    */   {
/* 234:234 */     return lookup;
/* 235:    */   }
/* 236:    */ }
