/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeListener;
/*  4:   */ import java.beans.PropertyChangeSupport;
/*  5:   */ import javax.swing.JComponent;
/*  6:   */ import org.netbeans.spi.options.OptionsPanelController;
/*  7:   */ import org.openide.util.HelpCtx;
/*  8:   */ import org.openide.util.Lookup;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public final class ProcDocumentItemsOptionsPanelController
/* 20:   */   extends OptionsPanelController
/* 21:   */ {
/* 22:   */   private ProcDocumentItemsPanel panel;
/* 23:23 */   private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
/* 24:   */   private boolean changed;
/* 25:   */   
/* 26:   */   public void update() {
/* 27:27 */     getPanel().load();
/* 28:28 */     changed = false;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void applyChanges() {
/* 32:32 */     getPanel().store();
/* 33:33 */     changed = false;
/* 34:   */   }
/* 35:   */   
/* 36:   */ 
/* 37:   */   public void cancel() {}
/* 38:   */   
/* 39:   */   public boolean isValid()
/* 40:   */   {
/* 41:41 */     return getPanel().valid();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public boolean isChanged() {
/* 45:45 */     return changed;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public HelpCtx getHelpCtx() {
/* 49:49 */     return null;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public JComponent getComponent(Lookup masterLookup) {
/* 53:53 */     return getPanel();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void addPropertyChangeListener(PropertyChangeListener l) {
/* 57:57 */     pcs.addPropertyChangeListener(l);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void removePropertyChangeListener(PropertyChangeListener l) {
/* 61:61 */     pcs.removePropertyChangeListener(l);
/* 62:   */   }
/* 63:   */   
/* 64:   */   private ProcDocumentItemsPanel getPanel() {
/* 65:65 */     if (panel == null) {
/* 66:66 */       panel = new ProcDocumentItemsPanel(this);
/* 67:   */     }
/* 68:68 */     return panel;
/* 69:   */   }
/* 70:   */   
/* 71:   */   void changed() {
/* 72:72 */     if (!changed) {
/* 73:73 */       changed = true;
/* 74:74 */       pcs.firePropertyChange("changed", false, true);
/* 75:   */     }
/* 76:76 */     pcs.firePropertyChange("valid", null, null);
/* 77:   */   }
/* 78:   */ }
