/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.propertysheet.PropertySheetPanel;
/*  4:   */ import ec.nbdemetra.ui.properties.l2fprod.PropertiesPanelFactory;
/*  5:   */ import ec.tstoolkit.algorithm.IProcDocument;
/*  6:   */ import ec.tstoolkit.algorithm.IProcSpecification;
/*  7:   */ import ec.tstoolkit.descriptors.IObjectDescriptor;
/*  8:   */ import ec.ui.view.tsprocessing.IProcDocumentView;
/*  9:   */ import java.beans.PropertyChangeEvent;
/* 10:   */ import java.beans.PropertyChangeListener;
/* 11:   */ import java.util.HashMap;
/* 12:   */ import java.util.Map;
/* 13:   */ import javax.annotation.Nonnull;
/* 14:   */ import javax.swing.JComponent;
/* 15:   */ import org.openide.util.Lookup;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public class DocumentUIServices
/* 26:   */ {
/* 27:   */   public static final String SPEC_PROPERTY = "specification";
/* 28:   */   protected final Map<Class, UIFactory> map;
/* 29:   */   
/* 30:   */   @Nonnull
/* 31:   */   public static DocumentUIServices getDefault()
/* 32:   */   {
/* 33:33 */     return (DocumentUIServices)Lookup.getDefault().lookup(DocumentUIServices.class);
/* 34:   */   }
/* 35:   */   
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */   public static abstract class AbstractUIFactory<S extends IProcSpecification, D extends IProcDocument<S, ?, ?>>
/* 47:   */     implements DocumentUIServices.UIFactory<S, D>
/* 48:   */   {
/* 49:   */     public JComponent getSpecView(IObjectDescriptor<S> desc)
/* 50:   */     {
/* 51:51 */       final PropertySheetPanel panel = PropertiesPanelFactory.INSTANCE.createPanel(desc);
/* 52:52 */       panel.addPropertySheetChangeListener(new PropertyChangeListener()
/* 53:   */       {
/* 54:   */         public void propertyChange(PropertyChangeEvent evt) {
/* 55:55 */           panel.firePropertyChange("specification", 0, 1);
/* 56:   */         }
/* 57:57 */       });
/* 58:58 */       return panel;
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */ 
/* 63:   */   public DocumentUIServices()
/* 64:   */   {
/* 65:65 */     map = new HashMap();
/* 66:   */   }
/* 67:   */   
/* 68:   */   public <S extends IProcSpecification, D extends IProcDocument<S, ?, ?>> UIFactory<S, D> getFactory(Class<D> dclass) {
/* 69:69 */     return (UIFactory)map.get(dclass);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public <S extends IProcSpecification, D extends IProcDocument<S, ?, ?>> void register(Class<D> dclass, UIFactory<S, D> factory) {
/* 73:73 */     map.put(dclass, factory);
/* 74:   */   }
/* 75:   */   
/* 76:   */   public <D extends IProcDocument<?, ?, ?>> void unregister(Class<D> dclass) {
/* 77:77 */     map.remove(dclass);
/* 78:   */   }
/* 79:   */   
/* 80:   */   public static abstract interface UIFactory<S extends IProcSpecification, D extends IProcDocument<S, ?, ?>>
/* 81:   */   {
/* 82:   */     public abstract IObjectDescriptor<S> getSpecificationDescriptor(D paramD);
/* 83:   */     
/* 84:   */     public abstract IProcDocumentView<D> getDocumentView(D paramD);
/* 85:   */     
/* 86:   */     public abstract JComponent getSpecView(IObjectDescriptor<S> paramIObjectDescriptor);
/* 87:   */   }
/* 88:   */ }
