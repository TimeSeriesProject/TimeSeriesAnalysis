/*  1:   */ package ec.nbdemetra.ui.star;
/*  2:   */ 
/*  3:   */ import ec.tss.tsproviders.DataSource;
/*  4:   */ import java.beans.PropertyChangeEvent;
/*  5:   */ import java.beans.PropertyChangeListener;
/*  6:   */ import java.util.HashSet;
/*  7:   */ import java.util.Iterator;
/*  8:   */ import java.util.Set;
/*  9:   */ import javax.swing.event.EventListenerList;
/* 10:   */ 
/* 11:   */ public final class StarList implements Iterable<DataSource>
/* 12:   */ {
/* 13:13 */   private static final StarList INSTANCE = new StarList();
/* 14:   */   final EventListenerList listeners;
/* 15:   */   
/* 16:16 */   public static StarList getInstance() { return INSTANCE; }
/* 17:   */   
/* 18:   */ 
/* 19:   */   final Set<DataSource> list;
/* 20:   */   
/* 21:   */   private StarList()
/* 22:   */   {
/* 23:23 */     list = new HashSet();
/* 24:24 */     listeners = new EventListenerList();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void clear() {
/* 28:28 */     list.clear();
/* 29:29 */     firePropertyChange("123", null, list);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void toggle(DataSource item) {
/* 33:33 */     if (list.contains(item)) {
/* 34:34 */       list.remove(item);
/* 35:   */     } else
/* 36:36 */       list.add(item);
/* 37:37 */     firePropertyChange("123", null, list);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 41:41 */     listeners.add(PropertyChangeListener.class, listener);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 45:45 */     listeners.remove(PropertyChangeListener.class, listener);
/* 46:   */   }
/* 47:   */   
/* 48:   */   protected void firePropertyChange(String propertyName, Object oldValue, Object newValue)
/* 49:   */   {
/* 50:50 */     Object[] tmp = listeners.getListenerList();
/* 51:   */     
/* 52:   */ 
/* 53:53 */     PropertyChangeEvent event = new PropertyChangeEvent(this, propertyName, oldValue, newValue);
/* 54:54 */     for (int i = tmp.length - 2; i >= 0; i -= 2) {
/* 55:55 */       if (tmp[i] == PropertyChangeListener.class) {
/* 56:56 */         ((PropertyChangeListener)tmp[(i + 1)]).propertyChange(event);
/* 57:   */       }
/* 58:   */     }
/* 59:   */   }
/* 60:   */   
/* 61:   */   public Iterator<DataSource> iterator()
/* 62:   */   {
/* 63:63 */     return list.iterator();
/* 64:   */   }
/* 65:   */   
/* 66:   */   boolean isStarred(DataSource dataSource) {
/* 67:67 */     return list.contains(dataSource);
/* 68:   */   }
/* 69:   */ }
