/*  1:   */ package ec.nbdemetra.ui.star;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.core.InstallerStep;
/*  5:   */ import ec.tss.tsproviders.DataSource;
/*  6:   */ import ec.tss.tsproviders.IDataSourceLoader;
/*  7:   */ import ec.tss.tsproviders.TsProviders;
/*  8:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  9:   */ import ec.tss.tsproviders.utils.Parsers.Parser;
/* 10:   */ import java.util.Iterator;
/* 11:   */ import java.util.prefs.BackingStoreException;
/* 12:   */ import java.util.prefs.Preferences;
/* 13:   */ import org.openide.util.NbPreferences;
/* 14:   */ import org.slf4j.Logger;
/* 15:   */ import org.slf4j.LoggerFactory;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public class StarHelper
/* 25:   */   extends InstallerStep
/* 26:   */ {
/* 27:27 */   static final Logger LOGGER = LoggerFactory.getLogger(StarHelper.class);
/* 28:   */   static final String DATASOURCE_PROPERTY = "StarDataSource";
/* 29:29 */   final Preferences prefs = NbPreferences.forModule(StarHelper.class).node("Star");
/* 30:   */   
/* 31:   */   public void restore()
/* 32:   */   {
/* 33:33 */     StarList.getInstance().clear();
/* 34:   */     
/* 35:35 */     Parsers.Parser<DataSource> parser = DataSource.xmlParser();
/* 36:   */     try
/* 37:   */     {
/* 38:38 */       for (String i : prefs.childrenNames()) {
/* 39:39 */         Optional<DataSource> dataSource = tryGet(prefs.node(i), "StarDataSource", parser);
/* 40:40 */         if (dataSource.isPresent()) {
/* 41:41 */           StarList.getInstance().toggle((DataSource)dataSource.get());
/* 42:   */         }
/* 43:   */       }
/* 44:   */     } catch (BackingStoreException ex) {
/* 45:45 */       LOGGER.warn("Can't get node list", ex);
/* 46:   */     }
/* 47:   */     
/* 48:48 */     for (DataSource o : StarList.getInstance()) {
/* 49:49 */       Object loader = TsProviders.lookup(IDataSourceLoader.class, o);
/* 50:50 */       if (((Optional)loader).isPresent()) {
/* 51:51 */         ((IDataSourceLoader)((Optional)loader).get()).open(o);
/* 52:   */       }
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void close()
/* 57:   */   {
/* 58:   */     try
/* 59:   */     {
/* 60:60 */       for (String i : prefs.childrenNames()) {
/* 61:61 */         prefs.node(i).removeNode();
/* 62:   */       }
/* 63:   */     } catch (BackingStoreException ex) {
/* 64:64 */       LOGGER.warn("Can't clear storage", ex);
/* 65:   */     }
/* 66:   */     
/* 67:67 */     Formatters.Formatter<DataSource> formatter = DataSource.xmlFormatter(false);
/* 68:   */     
/* 69:69 */     int i = 0;
/* 70:70 */     for (??? = StarList.getInstance().iterator(); ((Iterator)???).hasNext();) { DataSource o = (DataSource)((Iterator)???).next();
/* 71:71 */       Preferences node = prefs.node(String.valueOf(i++));
/* 72:72 */       tryPut(node, "StarDataSource", formatter, o);
/* 73:   */     }
/* 74:   */     try {
/* 75:75 */       prefs.flush();
/* 76:   */     } catch (BackingStoreException ex) {
/* 77:77 */       LOGGER.warn("Can't flush storage", ex);
/* 78:   */     }
/* 79:   */   }
/* 80:   */ }
