/*  1:   */ package ec.nbdemetra.ui.star;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import ec.nbdemetra.ui.tsproviders.DataSourceNode;
/*  5:   */ import ec.tss.tsproviders.DataSource;
/*  6:   */ import org.openide.util.Lookup;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public final class StarAction
/* 21:   */   extends SingleNodeAction<DataSourceNode>
/* 22:   */ {
/* 23:   */   public StarAction()
/* 24:   */   {
/* 25:25 */     super(DataSourceNode.class);
/* 26:   */   }
/* 27:   */   
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */   protected boolean enable(DataSourceNode paramDataSourceNode)
/* 33:   */   {
/* 34:34 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n\t无法解析 Bundle\n");
/* 35:   */   }
/* 36:   */   
/* 37:   */ 
/* 38:   */ 
/* 39:   */   protected void performAction(DataSourceNode activatedNode)
/* 40:   */   {
/* 41:41 */     StarList.getInstance().toggle((DataSource)activatedNode.getLookup().lookup(DataSource.class));
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getName()
/* 45:   */   {
/* 46:46 */     return StarAction.class.getName();
/* 47:   */   }
/* 48:   */ }
