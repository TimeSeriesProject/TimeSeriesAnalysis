/*  1:   */ package ec.nbdemetra.ui.star;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.NodeAnnotator;
/*  4:   */ import ec.tss.tsproviders.DataSource;
/*  5:   */ import java.awt.Image;
/*  6:   */ import org.openide.nodes.Node;
/*  7:   */ import org.openide.util.ImageUtilities;
/*  8:   */ import org.openide.util.Lookup;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ public class StarAnnotator
/* 18:   */   implements NodeAnnotator
/* 19:   */ {
/* 20:   */   boolean isStarred(Node node)
/* 21:   */   {
/* 22:22 */     DataSource dataSource = (DataSource)node.getLookup().lookup(DataSource.class);
/* 23:23 */     return (dataSource != null) && (StarList.getInstance().isStarred(dataSource));
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Image annotateIcon(Node node, Image image)
/* 27:   */   {
/* 28:28 */     if (isStarred(node)) {
/* 29:29 */       Image badge = ImageUtilities.loadImage("ec/nbdemetra/ui/nodes/bullet_star.png", false);
/* 30:30 */       return ImageUtilities.mergeImages(image, badge, 10, 0);
/* 31:   */     }
/* 32:   */     
/* 33:   */ 
/* 34:   */ 
/* 35:35 */     return image;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String annotateName(Node node, String name)
/* 39:   */   {
/* 40:40 */     return name;
/* 41:   */   }
/* 42:   */ }
