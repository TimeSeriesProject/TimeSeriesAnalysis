/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ns.NamedServiceChoicePanel;
/*   4:    */ import ec.nbdemetra.ui.properties.DataFormatComponent2;
/*   5:    */ import ec.ui.ATsChart;
/*   6:    */ import ec.util.chart.ColorScheme;
/*   7:    */ import java.beans.PropertyChangeEvent;
/*   8:    */ import javax.swing.BorderFactory;
/*   9:    */ import javax.swing.ButtonGroup;
/*  10:    */ import javax.swing.GroupLayout;
/*  11:    */ import javax.swing.GroupLayout.Alignment;
/*  12:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  13:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  14:    */ import javax.swing.JCheckBox;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JRadioButton;
/*  18:    */ import javax.swing.JSpinner;
/*  19:    */ import javax.swing.LayoutStyle.ComponentPlacement;
/*  20:    */ import org.openide.awt.Mnemonics;
/*  21:    */ import org.openide.util.NbBundle;
/*  22:    */ 
/*  23:    */ final class DemetraUIPanel extends JPanel implements java.beans.VetoableChangeListener, java.beans.PropertyChangeListener
/*  24:    */ {
/*  25:    */   private final DemetraUIOptionsPanelController controller;
/*  26:    */   final ATsChart colorSchemePreviewer;
/*  27:    */   private JRadioButton bigRadio;
/*  28:    */   private ButtonGroup buttonGroup1;
/*  29:    */   private JPanel chartPreviewPanel;
/*  30:    */   private JPanel chartsPanel;
/*  31:    */   private NamedServiceChoicePanel colorSchemeChoicePanel;
/*  32:    */   private JLabel colorSchemeLabel;
/*  33:    */   private DataFormatComponent2 dataFormatComponent;
/*  34:    */   private JLabel dataFormatLabel;
/*  35:    */   private JPanel growthChartsPanel;
/*  36:    */   private JSpinner growthLastYears;
/*  37:    */   private JPanel htmlFontPanel;
/*  38:    */   private JCheckBox iconsVisibleCB;
/*  39:    */   private JLabel lastYearsLabel;
/*  40:    */   private JRadioButton normalRadio;
/*  41:    */   private JPanel popupMenuPanel;
/*  42:    */   private JRadioButton smallRadio;
/*  43:    */   
/*  44:    */   DemetraUIPanel(DemetraUIOptionsPanelController controller)
/*  45:    */   {
/*  46: 46 */     this.controller = controller;
/*  47: 47 */     initComponents();
/*  48:    */     
/*  49: 49 */     colorSchemePreviewer = ComponentFactory.getDefault().newTsChart();
/*  50: 50 */     colorSchemePreviewer.setTsCollection(ec.ui.DemoUtils.randomTsCollection(3));
/*  51: 51 */     colorSchemePreviewer.setTsAction(new PreviewTsAction());
/*  52: 52 */     colorSchemePreviewer.setTsUpdateMode(ec.ui.interfaces.ITsCollectionView.TsUpdateMode.None);
/*  53: 53 */     chartPreviewPanel.add(colorSchemePreviewer);
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */   private void initComponents()
/*  63:    */   {
/*  64: 64 */     buttonGroup1 = new ButtonGroup();
/*  65: 65 */     chartsPanel = new JPanel();
/*  66: 66 */     chartPreviewPanel = new JPanel();
/*  67: 67 */     dataFormatComponent = new DataFormatComponent2();
/*  68: 68 */     colorSchemeChoicePanel = new NamedServiceChoicePanel();
/*  69: 69 */     dataFormatLabel = new JLabel();
/*  70: 70 */     colorSchemeLabel = new JLabel();
/*  71: 71 */     growthChartsPanel = new JPanel();
/*  72: 72 */     growthLastYears = new JSpinner();
/*  73: 73 */     lastYearsLabel = new JLabel();
/*  74: 74 */     htmlFontPanel = new JPanel();
/*  75: 75 */     smallRadio = new JRadioButton();
/*  76: 76 */     normalRadio = new JRadioButton();
/*  77: 77 */     bigRadio = new JRadioButton();
/*  78: 78 */     popupMenuPanel = new JPanel();
/*  79: 79 */     iconsVisibleCB = new JCheckBox();
/*  80:    */     
/*  81: 81 */     chartsPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.chartsPanel.border.title")));
/*  82:    */     
/*  83: 83 */     chartPreviewPanel.setBorder(BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
/*  84: 84 */     chartPreviewPanel.setLayout(new java.awt.BorderLayout());
/*  85:    */     
/*  86: 86 */     Mnemonics.setLocalizedText(dataFormatLabel, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.dataFormatLabel.text"));
/*  87:    */     
/*  88: 88 */     Mnemonics.setLocalizedText(colorSchemeLabel, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.colorSchemeLabel.text"));
/*  89:    */     
/*  90: 90 */     GroupLayout chartsPanelLayout = new GroupLayout(chartsPanel);
/*  91: 91 */     chartsPanel.setLayout(chartsPanelLayout);
/*  92: 92 */     chartsPanelLayout.setHorizontalGroup(
/*  93: 93 */       chartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  94: 94 */       .addGroup(chartsPanelLayout.createSequentialGroup()
/*  95: 95 */       .addContainerGap()
/*  96: 96 */       .addGroup(chartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  97: 97 */       .addGroup(chartsPanelLayout.createSequentialGroup()
/*  98: 98 */       .addComponent(colorSchemeLabel)
/*  99: 99 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 100:100 */       .addComponent(colorSchemeChoicePanel, -2, 192, -2)
/* 101:101 */       .addContainerGap(-1, 32767))
/* 102:102 */       .addGroup(chartsPanelLayout.createSequentialGroup()
/* 103:103 */       .addGroup(chartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 104:104 */       .addGroup(chartsPanelLayout.createSequentialGroup()
/* 105:105 */       .addComponent(dataFormatLabel)
/* 106:106 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 107:107 */       .addComponent(dataFormatComponent, -2, 305, -2))
/* 108:108 */       .addComponent(chartPreviewPanel, -2, 497, -2))
/* 109:109 */       .addGap(0, 43, 32767)))));
/* 110:    */     
/* 111:111 */     chartsPanelLayout.setVerticalGroup(
/* 112:112 */       chartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 113:113 */       .addGroup(chartsPanelLayout.createSequentialGroup()
/* 114:114 */       .addContainerGap()
/* 115:115 */       .addGroup(chartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 116:116 */       .addComponent(colorSchemeChoicePanel, -2, 0, 32767)
/* 117:117 */       .addComponent(colorSchemeLabel, -2, 23, -2))
/* 118:118 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 119:119 */       .addComponent(chartPreviewPanel, -2, 181, -2)
/* 120:120 */       .addGap(18, 18, 18)
/* 121:121 */       .addGroup(chartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 122:122 */       .addComponent(dataFormatComponent, -1, -1, 32767)
/* 123:123 */       .addComponent(dataFormatLabel, -1, -1, 32767))));
/* 124:    */     
/* 125:    */ 
/* 126:126 */     growthChartsPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.growthChartsPanel.border.title")));
/* 127:    */     
/* 128:128 */     growthLastYears.setModel(new javax.swing.SpinnerNumberModel(4, 1, 15, 1));
/* 129:    */     
/* 130:130 */     Mnemonics.setLocalizedText(lastYearsLabel, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.lastYearsLabel.text"));
/* 131:    */     
/* 132:132 */     GroupLayout growthChartsPanelLayout = new GroupLayout(growthChartsPanel);
/* 133:133 */     growthChartsPanel.setLayout(growthChartsPanelLayout);
/* 134:134 */     growthChartsPanelLayout.setHorizontalGroup(
/* 135:135 */       growthChartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 136:136 */       .addGroup(growthChartsPanelLayout.createSequentialGroup()
/* 137:137 */       .addContainerGap()
/* 138:138 */       .addComponent(lastYearsLabel)
/* 139:139 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 140:140 */       .addComponent(growthLastYears, -2, 48, -2)
/* 141:141 */       .addContainerGap(-1, 32767)));
/* 142:    */     
/* 143:143 */     growthChartsPanelLayout.setVerticalGroup(
/* 144:144 */       growthChartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 145:145 */       .addGroup(growthChartsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 146:146 */       .addComponent(lastYearsLabel, -1, -1, 32767)
/* 147:147 */       .addComponent(growthLastYears, -2, -1, -2)));
/* 148:    */     
/* 149:    */ 
/* 150:150 */     htmlFontPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.htmlFontPanel.border.title")));
/* 151:    */     
/* 152:152 */     buttonGroup1.add(smallRadio);
/* 153:153 */     Mnemonics.setLocalizedText(smallRadio, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.smallRadio.text"));
/* 154:154 */     smallRadio.setEnabled(false);
/* 155:155 */     smallRadio.setFocusPainted(false);
/* 156:    */     
/* 157:157 */     buttonGroup1.add(normalRadio);
/* 158:158 */     normalRadio.setSelected(true);
/* 159:159 */     Mnemonics.setLocalizedText(normalRadio, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.normalRadio.text"));
/* 160:160 */     normalRadio.setFocusPainted(false);
/* 161:    */     
/* 162:162 */     buttonGroup1.add(bigRadio);
/* 163:163 */     Mnemonics.setLocalizedText(bigRadio, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.bigRadio.text"));
/* 164:164 */     bigRadio.setEnabled(false);
/* 165:165 */     bigRadio.setFocusPainted(false);
/* 166:    */     
/* 167:167 */     GroupLayout htmlFontPanelLayout = new GroupLayout(htmlFontPanel);
/* 168:168 */     htmlFontPanel.setLayout(htmlFontPanelLayout);
/* 169:169 */     htmlFontPanelLayout.setHorizontalGroup(
/* 170:170 */       htmlFontPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 171:171 */       .addGroup(htmlFontPanelLayout.createSequentialGroup()
/* 172:172 */       .addContainerGap()
/* 173:173 */       .addComponent(smallRadio)
/* 174:174 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 175:175 */       .addComponent(normalRadio)
/* 176:176 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 177:177 */       .addComponent(bigRadio)
/* 178:178 */       .addContainerGap(-1, 32767)));
/* 179:    */     
/* 180:180 */     htmlFontPanelLayout.setVerticalGroup(
/* 181:181 */       htmlFontPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 182:182 */       .addGroup(htmlFontPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 183:183 */       .addComponent(smallRadio)
/* 184:184 */       .addComponent(normalRadio)
/* 185:185 */       .addComponent(bigRadio)));
/* 186:    */     
/* 187:    */ 
/* 188:188 */     popupMenuPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.popupMenuPanel.border.title")));
/* 189:189 */     popupMenuPanel.setPreferredSize(new java.awt.Dimension(562, 46));
/* 190:    */     
/* 191:191 */     Mnemonics.setLocalizedText(iconsVisibleCB, NbBundle.getMessage(DemetraUIPanel.class, "DemetraUIPanel.iconsVisibleCB.text"));
/* 192:192 */     iconsVisibleCB.setFocusPainted(false);
/* 193:    */     
/* 194:194 */     GroupLayout popupMenuPanelLayout = new GroupLayout(popupMenuPanel);
/* 195:195 */     popupMenuPanel.setLayout(popupMenuPanelLayout);
/* 196:196 */     popupMenuPanelLayout.setHorizontalGroup(
/* 197:197 */       popupMenuPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 198:198 */       .addGroup(popupMenuPanelLayout.createSequentialGroup()
/* 199:199 */       .addContainerGap()
/* 200:200 */       .addComponent(iconsVisibleCB)
/* 201:201 */       .addContainerGap(-1, 32767)));
/* 202:    */     
/* 203:203 */     popupMenuPanelLayout.setVerticalGroup(
/* 204:204 */       popupMenuPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 205:205 */       .addGroup(popupMenuPanelLayout.createSequentialGroup()
/* 206:206 */       .addComponent(iconsVisibleCB)
/* 207:207 */       .addGap(0, 1, 32767)));
/* 208:    */     
/* 209:    */ 
/* 210:210 */     GroupLayout layout = new GroupLayout(this);
/* 211:211 */     setLayout(layout);
/* 212:212 */     layout.setHorizontalGroup(
/* 213:213 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 214:214 */       .addComponent(chartsPanel, -1, -1, 32767)
/* 215:215 */       .addComponent(growthChartsPanel, -1, -1, 32767)
/* 216:216 */       .addComponent(htmlFontPanel, -1, -1, 32767)
/* 217:217 */       .addComponent(popupMenuPanel, -1, -1, 32767));
/* 218:    */     
/* 219:219 */     layout.setVerticalGroup(
/* 220:220 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 221:221 */       .addGroup(layout.createSequentialGroup()
/* 222:222 */       .addComponent(chartsPanel, -2, -1, -2)
/* 223:223 */       .addGap(0, 0, 0)
/* 224:224 */       .addComponent(growthChartsPanel, -2, -1, -2)
/* 225:225 */       .addGap(0, 0, 0)
/* 226:226 */       .addComponent(htmlFontPanel, -2, -1, -2)
/* 227:227 */       .addGap(0, 0, 0)
/* 228:228 */       .addComponent(popupMenuPanel, -2, -1, -2)
/* 229:229 */       .addContainerGap(15, 32767)));
/* 230:    */   }
/* 231:    */   
/* 232:    */   void load()
/* 233:    */   {
/* 234:234 */     DemetraUI demetraUI = DemetraUI.getDefault();
/* 235:235 */     com.google.common.base.Function<ColorScheme, ec.nbdemetra.ui.ns.INamedService> toNamedService = new com.google.common.base.Function()
/* 236:    */     {
/* 237:    */       public ec.nbdemetra.ui.ns.INamedService apply(ColorScheme input) {
/* 238:238 */         return new DemetraUIPanel.ColorSchemeNamedService(input);
/* 239:    */       }
/* 240:240 */     };
/* 241:241 */     colorSchemeChoicePanel.setContent(com.google.common.collect.Iterables.transform(demetraUI.getColorSchemes(), toNamedService));
/* 242:242 */     colorSchemeChoicePanel.getExplorerManager().addVetoableChangeListener(this);
/* 243:243 */     colorSchemeChoicePanel.setSelectedServiceName(demetraUI.getColorSchemeName());
/* 244:244 */     dataFormatComponent.setDataFormat(demetraUI.getDataFormat());
/* 245:245 */     dataFormatComponent.addPropertyChangeListener(this);
/* 246:246 */     growthLastYears.setValue(demetraUI.getGrowthLastYears());
/* 247:247 */     iconsVisibleCB.setSelected(demetraUI.getPopupMenuIconsVisible());
/* 248:    */   }
/* 249:    */   
/* 250:    */   void store() {
/* 251:251 */     DemetraUI demetraUI = DemetraUI.getDefault();
/* 252:252 */     demetraUI.setColorSchemeName(colorSchemeChoicePanel.getSelectedServiceName());
/* 253:253 */     demetraUI.setDataFormat(dataFormatComponent.getDataFormat());
/* 254:254 */     demetraUI.setGrowthLastYears((Integer)growthLastYears.getValue());
/* 255:255 */     demetraUI.setPopupMenuIconsVisible(iconsVisibleCB.isSelected());
/* 256:    */   }
/* 257:    */   
/* 258:    */   boolean valid()
/* 259:    */   {
/* 260:260 */     return true;
/* 261:    */   }
/* 262:    */   
/* 263:    */   public void vetoableChange(PropertyChangeEvent evt) throws java.beans.PropertyVetoException
/* 264:    */   {
/* 265:265 */     if ("selectedNodes".equals(evt.getPropertyName())) {
/* 266:266 */       org.openide.nodes.Node[] nodes = (org.openide.nodes.Node[])evt.getNewValue();
/* 267:267 */       if (nodes.length > 0) {
/* 268:268 */         ColorSchemeNamedService tmp = (ColorSchemeNamedService)nodes[0].getLookup().lookup(ColorSchemeNamedService.class);
/* 269:269 */         colorSchemePreviewer.setColorScheme(tmp.getColorScheme());
/* 270:270 */         colorSchemePreviewer.setTitle(tmp.getDisplayName());
/* 271:    */       }
/* 272:    */     }
/* 273:    */   }
/* 274:    */   
/* 275:    */   public void propertyChange(PropertyChangeEvent evt)
/* 276:    */   {
/* 277:277 */     if ((evt.getPropertyName().equals("dataFormat")) && (evt.getNewValue() != null)) {
/* 278:278 */       colorSchemePreviewer.setDataFormat(dataFormatComponent.getDataFormat());
/* 279:    */     }
/* 280:    */   }
/* 281:    */   
/* 282:    */   DataFormatComponent2 getDataFormatComponent() {
/* 283:283 */     return dataFormatComponent;
/* 284:    */   }
/* 285:    */   
/* 286:    */   private class PreviewTsAction extends ec.nbdemetra.ui.ns.AbstractNamedService implements ec.nbdemetra.ui.tsaction.ITsAction
/* 287:    */   {
/* 288:    */     PreviewTsAction() {
/* 289:289 */       super("PreviewTsAction");
/* 290:    */     }
/* 291:    */     
/* 292:    */ 
/* 293:    */ 
/* 294:    */     public void open(ec.tss.Ts ts) {}
/* 295:    */   }
/* 296:    */   
/* 297:    */ 
/* 298:    */   static class ColorSchemeNamedService
/* 299:    */     extends ec.nbdemetra.ui.ns.AbstractNamedService
/* 300:    */   {
/* 301:    */     private final ColorScheme colorScheme;
/* 302:    */     
/* 303:    */ 
/* 304:    */     public ColorSchemeNamedService(ColorScheme colorScheme)
/* 305:    */     {
/* 306:306 */       super(colorScheme.getName());
/* 307:307 */       this.colorScheme = colorScheme;
/* 308:    */     }
/* 309:    */     
/* 310:    */     public String getDisplayName()
/* 311:    */     {
/* 312:312 */       return colorScheme.getDisplayName();
/* 313:    */     }
/* 314:    */     
/* 315:    */     public java.awt.Image getIcon(int type, boolean opened)
/* 316:    */     {
/* 317:317 */       return org.openide.util.ImageUtilities.icon2Image(new ec.util.chart.swing.ColorSchemeIcon(colorScheme));
/* 318:    */     }
/* 319:    */     
/* 320:    */     public ColorScheme getColorScheme() {
/* 321:321 */       return colorScheme;
/* 322:    */     }
/* 323:    */   }
/* 324:    */ }
