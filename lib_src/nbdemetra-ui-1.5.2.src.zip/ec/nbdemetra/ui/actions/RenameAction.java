/*  1:   */ package ec.nbdemetra.ui.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.INameable;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ public final class RenameAction
/* 24:   */   extends AbilityAction<INameable>
/* 25:   */ {
/* 26:   */   public RenameAction()
/* 27:   */   {
/* 28:28 */     super(INameable.class);
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected void performAction(Iterable<INameable> items)
/* 32:   */   {
/* 33:33 */     for (INameable o : items) {
/* 34:34 */       o.rename();
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public String getName()
/* 39:   */   {
/* 40:40 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 41:   */   }
/* 42:   */ }
