/*  1:   */ package ec.nbdemetra.ui.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.IConfigurable;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public class ConfigureAction
/* 26:   */   extends AbilityAction<IConfigurable>
/* 27:   */ {
/* 28:   */   public ConfigureAction()
/* 29:   */   {
/* 30:30 */     super(IConfigurable.class);
/* 31:   */   }
/* 32:   */   
/* 33:   */   protected void performAction(Iterable<IConfigurable> items)
/* 34:   */   {
/* 35:35 */     for (IConfigurable o : items) {
/* 36:36 */       o.setConfig(o.editConfig(o.getConfig()));
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getName()
/* 41:   */   {
/* 42:42 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 43:   */   }
/* 44:   */ }
