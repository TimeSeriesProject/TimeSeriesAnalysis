/*  1:   */ package ec.nbdemetra.ui.actions;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Function;
/*  4:   */ import com.google.common.base.Predicate;
/*  5:   */ import com.google.common.base.Predicates;
/*  6:   */ import com.google.common.collect.FluentIterable;
/*  7:   */ import ec.nbdemetra.ui.Jdk6Functions;
/*  8:   */ import ec.nbdemetra.ui.Jdk6Predicates;
/*  9:   */ import ec.nbdemetra.ui.nodes.Nodes;
/* 10:   */ import org.openide.nodes.Node;
/* 11:   */ import org.openide.util.HelpCtx;
/* 12:   */ import org.openide.util.actions.NodeAction;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public abstract class AbilityAction<T>
/* 20:   */   extends NodeAction
/* 21:   */ {
/* 22:   */   final Predicate<Node> predicate;
/* 23:   */   final Function<Node, T> function;
/* 24:   */   
/* 25:   */   protected AbilityAction(Class<T> ability)
/* 26:   */   {
/* 27:27 */     predicate = Jdk6Predicates.lookupNode(ability);
/* 28:28 */     function = Jdk6Functions.lookupNode(ability);
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected abstract void performAction(Iterable<T> paramIterable);
/* 32:   */   
/* 33:   */   protected void performAction(Node[] activatedNodes)
/* 34:   */   {
/* 35:35 */     performAction(Nodes.asIterable(activatedNodes).transform(function).filter(Predicates.notNull()));
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected boolean enable(Node[] activatedNodes)
/* 39:   */   {
/* 40:40 */     return Nodes.asIterable(activatedNodes).anyMatch(predicate);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public HelpCtx getHelpCtx()
/* 44:   */   {
/* 45:45 */     throw new UnsupportedOperationException("Not supported yet.");
/* 46:   */   }
/* 47:   */ }
