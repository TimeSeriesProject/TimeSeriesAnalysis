/*  1:   */ package ec.nbdemetra.ui.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.IWorkspaceItemManager;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  6:   */ import ec.nbdemetra.ws.nodes.WsNode;
/*  7:   */ import ec.tstoolkit.utilities.Id;
/*  8:   */ import java.awt.event.ActionEvent;
/*  9:   */ import java.awt.event.ActionListener;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class AbstractSortItems
/* 28:   */   implements ActionListener
/* 29:   */ {
/* 30:   */   private final WsNode context;
/* 31:   */   
/* 32:   */   protected AbstractSortItems(WsNode context)
/* 33:   */   {
/* 34:34 */     this.context = context;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void actionPerformed(ActionEvent ev)
/* 38:   */   {
/* 39:39 */     IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager((Id)context.lookup());
/* 40:40 */     if (mgr != null) {
/* 41:41 */       Workspace ws = context.getWorkspace();
/* 42:42 */       ws.sortFamily((Id)context.lookup());
/* 43:   */     }
/* 44:   */   }
/* 45:   */ }
