/*  1:   */ package ec.nbdemetra.ui.actions;
/*  2:   */ 
/*  3:   */ import org.netbeans.api.actions.Closable;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ public final class CloseAction
/* 20:   */   extends AbilityAction<Closable>
/* 21:   */ {
/* 22:   */   public CloseAction()
/* 23:   */   {
/* 24:24 */     super(Closable.class);
/* 25:   */   }
/* 26:   */   
/* 27:   */   protected void performAction(Iterable<Closable> items)
/* 28:   */   {
/* 29:29 */     for (Closable o : items) {
/* 30:30 */       o.close();
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getName()
/* 35:   */   {
/* 36:36 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 37:   */   }
/* 38:   */ }
