/*  1:   */ package ec.nbdemetra.ui.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.IReloadable;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public final class ReloadAction
/* 26:   */   extends AbilityAction<IReloadable>
/* 27:   */ {
/* 28:   */   public ReloadAction()
/* 29:   */   {
/* 30:30 */     super(IReloadable.class);
/* 31:   */   }
/* 32:   */   
/* 33:   */   protected void performAction(Iterable<IReloadable> items)
/* 34:   */   {
/* 35:35 */     for (IReloadable o : items) {
/* 36:36 */       o.reload();
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getName()
/* 41:   */   {
/* 42:42 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 43:   */   }
/* 44:   */ }
