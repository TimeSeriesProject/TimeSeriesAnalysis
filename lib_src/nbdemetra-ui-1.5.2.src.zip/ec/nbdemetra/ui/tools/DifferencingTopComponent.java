/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ActiveViewManager;
/*   4:    */ import ec.nbdemetra.ui.IActiveView;
/*   5:    */ import ec.nbdemetra.ui.MonikerUI;
/*   6:    */ import ec.nbdemetra.ui.tsaction.ITsView2;
/*   7:    */ import ec.tss.Ts;
/*   8:    */ import ec.tss.TsCollection;
/*   9:    */ import ec.tss.TsFactory;
/*  10:    */ import ec.tss.TsInformationType;
/*  11:    */ import ec.tss.TsMoniker;
/*  12:    */ import ec.tss.datatransfer.TssTransferSupport;
/*  13:    */ import ec.tstoolkit.stats.AutoCorrelations;
/*  14:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  15:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  16:    */ import ec.ui.grid.JTsGrid;
/*  17:    */ import ec.ui.view.AutoCorrelationsView;
/*  18:    */ import ec.ui.view.PeriodogramView;
/*  19:    */ import java.awt.Dimension;
/*  20:    */ import java.awt.Font;
/*  21:    */ import java.lang.reflect.InvocationTargetException;
/*  22:    */ import java.util.Properties;
/*  23:    */ import javax.swing.BoxLayout;
/*  24:    */ import javax.swing.JLabel;
/*  25:    */ import javax.swing.JMenu;
/*  26:    */ import javax.swing.JSplitPane;
/*  27:    */ import javax.swing.JToolBar;
/*  28:    */ import javax.swing.SwingUtilities;
/*  29:    */ import javax.swing.TransferHandler;
/*  30:    */ import javax.swing.TransferHandler.TransferSupport;
/*  31:    */ import org.openide.explorer.ExplorerManager;
/*  32:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  33:    */ import org.openide.nodes.AbstractNode;
/*  34:    */ import org.openide.nodes.Children;
/*  35:    */ import org.openide.nodes.Node;
/*  36:    */ import org.openide.nodes.Node.Property;
/*  37:    */ import org.openide.nodes.Sheet;
/*  38:    */ import org.openide.nodes.Sheet.Set;
/*  39:    */ import org.openide.windows.TopComponent;
/*  40:    */ import org.openide.windows.TopComponent.Description;
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ @TopComponent.Description(preferredID="DifferencingTopComponent", persistenceType=2)
/*  63:    */ public final class DifferencingTopComponent
/*  64:    */   extends TopComponent
/*  65:    */   implements ITsView2, IActiveView, ExplorerManager.Provider
/*  66:    */ {
/*  67:    */   private final JToolBar toolBar;
/*  68: 68 */   private static final Font DROP_DATA_FONT = new JLabel().getFont().deriveFont(2);
/*  69:    */   
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */   private final JLabel dropDataLabel;
/*  74:    */   
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */   private final JLabel tsLabel;
/*  79:    */   
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */   private final JSplitPane splitter1;
/*  84:    */   
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   private final JSplitPane splitter2;
/*  89:    */   
/*  90:    */ 
/*  91:    */ 
/*  92:    */   private final PeriodogramView periodogramView;
/*  93:    */   
/*  94:    */ 
/*  95:    */ 
/*  96:    */   private final AutoCorrelationsView acView;
/*  97:    */   
/*  98:    */ 
/*  99:    */ 
/* 100:    */   private final JTsGrid grid;
/* 101:    */   
/* 102:    */ 
/* 103:    */ 
/* 104:    */   private Ts ts_;
/* 105:    */   
/* 106:    */ 
/* 107:    */ 
/* 108:    */   private Node node;
/* 109:    */   
/* 110:    */ 
/* 111:    */ 
/* 112:    */   private boolean isLog;
/* 113:    */   
/* 114:    */ 
/* 115:    */ 
/* 116:    */   private int diffOrder;
/* 117:    */   
/* 118:    */ 
/* 119:    */ 
/* 120:    */   private int seasonalDiffOrder;
/* 121:    */   
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */   public void refreshHeader()
/* 126:    */   {
/* 127:127 */     if (ts_ == null) {
/* 128:128 */       dropDataLabel.setVisible(true);
/* 129:129 */       tsLabel.setVisible(false);
/* 130:    */     } else {
/* 131:131 */       dropDataLabel.setVisible(false);
/* 132:132 */       tsLabel.setText(ts_.getName());
/* 133:133 */       TsMoniker moniker = ts_.getMoniker();
/* 134:134 */       tsLabel.setIcon(MonikerUI.getDefault().getIcon(ts_));
/* 135:135 */       tsLabel.setToolTipText(tsLabel.getText() + (moniker.getSource() != null ? " (" + moniker.getSource() + ")" : ""));
/* 136:136 */       tsLabel.setVisible(true);
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */   private void initComponents()
/* 147:    */   {
/* 148:148 */     setPreferredSize(new Dimension(100, 100));
/* 149:149 */     setLayout(new BoxLayout(this, 2));
/* 150:    */   }
/* 151:    */   
/* 152:    */ 
/* 153:    */ 
/* 154:    */   public void componentOpened()
/* 155:    */   {
/* 156:156 */     super.componentOpened();
/* 157:157 */     SwingUtilities.invokeLater(new Runnable()
/* 158:    */     {
/* 159:    */       public void run() {
/* 160:160 */         splitter2.setDividerLocation(0.5D);
/* 161:161 */         splitter2.setResizeWeight(0.5D);
/* 162:162 */         splitter1.setDividerLocation(0.5D);
/* 163:163 */         splitter1.setResizeWeight(0.5D);
/* 164:    */       }
/* 165:    */     });
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void componentClosed()
/* 169:    */   {
/* 170:170 */     super.componentClosed();
/* 171:    */   }
/* 172:    */   
/* 173:    */ 
/* 174:    */   public void componentActivated()
/* 175:    */   {
/* 176:176 */     super.componentActivated();
/* 177:177 */     ActiveViewManager.getInstance().set(this);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void componentDeactivated()
/* 181:    */   {
/* 182:182 */     super.componentDeactivated();
/* 183:183 */     ActiveViewManager.getInstance().set(null);
/* 184:    */   }
/* 185:    */   
/* 186:    */ 
/* 187:    */   void writeProperties(Properties p)
/* 188:    */   {
/* 189:189 */     p.setProperty("version", "1.0");
/* 190:    */   }
/* 191:    */   
/* 192:    */   void readProperties(Properties p)
/* 193:    */   {
/* 194:194 */     String version = p.getProperty("version");
/* 195:    */   }
/* 196:    */   
/* 197:    */   class TsHandler extends TransferHandler
/* 198:    */   {
/* 199:    */     TsHandler() {}
/* 200:    */     
/* 201:    */     public boolean canImport(TransferHandler.TransferSupport support) {
/* 202:202 */       return TssTransferSupport.getDefault().canImport(support.getDataFlavors());
/* 203:    */     }
/* 204:    */     
/* 205:    */     public boolean importData(TransferHandler.TransferSupport support)
/* 206:    */     {
/* 207:207 */       Ts s = TssTransferSupport.getDefault().toTs(support.getTransferable());
/* 208:208 */       if (s != null) {
/* 209:209 */         setTs(s);
/* 210:210 */         return true;
/* 211:    */       }
/* 212:212 */       return false;
/* 213:    */     }
/* 214:    */   }
/* 215:    */   
/* 216:    */   void showTests() {
/* 217:217 */     clear();
/* 218:218 */     TsData s = ts_.getTsData();
/* 219:219 */     if (isLog) {
/* 220:220 */       s = s.log();
/* 221:    */     }
/* 222:222 */     if (diffOrder > 0) {
/* 223:223 */       s = s.delta(1, diffOrder);
/* 224:    */     }
/* 225:225 */     int ifreq = s.getFrequency().intValue();
/* 226:226 */     if ((ifreq > 1) && (seasonalDiffOrder > 0)) {
/* 227:227 */       s = s.delta(ifreq, seasonalDiffOrder);
/* 228:    */     }
/* 229:229 */     Ts del = TsFactory.instance.createTs("Differenced series", null, s);
/* 230:230 */     grid.getTsCollection().replace(del);
/* 231:231 */     AutoCorrelations ac = new AutoCorrelations(s);
/* 232:232 */     acView.setLength(ifreq * 3);
/* 233:233 */     acView.setAutoCorrelations(ac);
/* 234:    */     
/* 235:235 */     periodogramView.setData("Periodogram", ifreq, s);
/* 236:    */   }
/* 237:    */   
/* 238:    */   private void clear() {
/* 239:239 */     acView.reset();
/* 240:240 */     periodogramView.reset();
/* 241:241 */     grid.getTsCollection().clear();
/* 242:    */   }
/* 243:    */   
/* 244:    */   public void setTs(Ts s)
/* 245:    */   {
/* 246:246 */     ts_ = s;
/* 247:247 */     ts_.load(TsInformationType.All);
/* 248:248 */     refreshHeader();
/* 249:249 */     showTests();
/* 250:    */   }
/* 251:    */   
/* 252:    */   public Ts getTs()
/* 253:    */   {
/* 254:254 */     return ts_;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public boolean fill(JMenu menu)
/* 258:    */   {
/* 259:259 */     return false;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public Node getNode()
/* 263:    */   {
/* 264:264 */     return node;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public ExplorerManager getExplorerManager()
/* 268:    */   {
/* 269:269 */     return ActiveViewManager.getInstance().getExplorerManager();
/* 270:    */   }
/* 271:    */   
/* 272:    */   public boolean hasContextMenu()
/* 273:    */   {
/* 274:274 */     return false;
/* 275:    */   }
/* 276:    */   
/* 277:    */   class InternalNode extends AbstractNode
/* 278:    */   {
/* 279:    */     InternalNode() {
/* 280:280 */       super();
/* 281:281 */       setDisplayName("Differencing");
/* 282:    */     }
/* 283:    */     
/* 284:    */     protected Sheet createSheet()
/* 285:    */     {
/* 286:286 */       Sheet sheet = super.createSheet();
/* 287:287 */       Sheet.Set transform = Sheet.createPropertiesSet();
/* 288:288 */       transform.setName("Transform");
/* 289:289 */       transform.setDisplayName("Transformation");
/* 290:290 */       Node.Property<Boolean> log = new Node.Property(Boolean.class)
/* 291:    */       {
/* 292:    */         public boolean canRead() {
/* 293:293 */           return true;
/* 294:    */         }
/* 295:    */         
/* 296:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 297:    */         {
/* 298:298 */           return Boolean.valueOf(isLog);
/* 299:    */         }
/* 300:    */         
/* 301:    */         public boolean canWrite()
/* 302:    */         {
/* 303:303 */           return true;
/* 304:    */         }
/* 305:    */         
/* 306:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 307:    */         {
/* 308:308 */           isLog = ((Boolean)t).booleanValue();
/* 309:309 */           showTests();
/* 310:    */         }
/* 311:    */         
/* 312:312 */       };
/* 313:313 */       log.setName("Log");
/* 314:314 */       transform.put(log);
/* 315:315 */       Node.Property<Integer> diff = new Node.Property(Integer.class)
/* 316:    */       {
/* 317:    */         public boolean canRead() {
/* 318:318 */           return true;
/* 319:    */         }
/* 320:    */         
/* 321:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 322:    */         {
/* 323:323 */           return Integer.valueOf(diffOrder);
/* 324:    */         }
/* 325:    */         
/* 326:    */         public boolean canWrite()
/* 327:    */         {
/* 328:328 */           return true;
/* 329:    */         }
/* 330:    */         
/* 331:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 332:    */         {
/* 333:333 */           diffOrder = ((Integer)t).intValue();
/* 334:334 */           showTests();
/* 335:    */         }
/* 336:    */         
/* 337:337 */       };
/* 338:338 */       diff.setName("Regular Differencing");
/* 339:339 */       transform.put(diff);
/* 340:340 */       Node.Property<Integer> sdiff = new Node.Property(Integer.class)
/* 341:    */       {
/* 342:    */         public boolean canRead() {
/* 343:343 */           return true;
/* 344:    */         }
/* 345:    */         
/* 346:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 347:    */         {
/* 348:348 */           return Integer.valueOf(seasonalDiffOrder);
/* 349:    */         }
/* 350:    */         
/* 351:    */         public boolean canWrite()
/* 352:    */         {
/* 353:353 */           return true;
/* 354:    */         }
/* 355:    */         
/* 356:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 357:    */         {
/* 358:358 */           seasonalDiffOrder = ((Integer)t).intValue();
/* 359:359 */           showTests();
/* 360:    */         }
/* 361:    */         
/* 362:362 */       };
/* 363:363 */       sdiff.setName("Seasonal Differencing");
/* 364:364 */       transform.put(sdiff);
/* 365:365 */       sheet.put(transform);
/* 366:366 */       return sheet;
/* 367:    */     }
/* 368:    */   }
/* 369:    */ }
