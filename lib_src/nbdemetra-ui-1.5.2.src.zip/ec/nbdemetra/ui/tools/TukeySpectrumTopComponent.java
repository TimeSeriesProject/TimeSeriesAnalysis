/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ActiveViewManager;
/*   4:    */ import ec.nbdemetra.ui.IActiveView;
/*   5:    */ import ec.nbdemetra.ui.tsaction.ITsView2;
/*   6:    */ import ec.tss.Ts;
/*   7:    */ import ec.tstoolkit.data.WindowType;
/*   8:    */ import ec.ui.view.TukeySpectrumView;
/*   9:    */ import java.lang.reflect.InvocationTargetException;
/*  10:    */ import java.util.Properties;
/*  11:    */ import javax.swing.BoxLayout;
/*  12:    */ import javax.swing.JMenu;
/*  13:    */ import org.openide.explorer.ExplorerManager;
/*  14:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  15:    */ import org.openide.nodes.AbstractNode;
/*  16:    */ import org.openide.nodes.Children;
/*  17:    */ import org.openide.nodes.Node;
/*  18:    */ import org.openide.nodes.Node.Property;
/*  19:    */ import org.openide.nodes.Sheet;
/*  20:    */ import org.openide.nodes.Sheet.Set;
/*  21:    */ import org.openide.windows.Mode;
/*  22:    */ import org.openide.windows.TopComponent;
/*  23:    */ import org.openide.windows.TopComponent.Description;
/*  24:    */ import org.openide.windows.WindowManager;
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ @TopComponent.Description(preferredID="TukeySpectrumTopComponent", persistenceType=2)
/*  56:    */ public final class TukeySpectrumTopComponent
/*  57:    */   extends TopComponent
/*  58:    */   implements ITsView2, IActiveView, ExplorerManager.Provider
/*  59:    */ {
/*  60:    */   private TukeySpectrumView view;
/*  61:    */   private Node node;
/*  62:    */   
/*  63:    */   public void open()
/*  64:    */   {
/*  65: 65 */     super.open();
/*  66: 66 */     Mode mode = WindowManager.getDefault().findMode("output");
/*  67: 67 */     if ((mode != null) && (mode.canDock(this))) {
/*  68: 68 */       mode.dockInto(this);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */   private void initComponents()
/*  79:    */   {
/*  80: 80 */     setLayout(new BoxLayout(this, 2));
/*  81:    */   }
/*  82:    */   
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */   public void componentOpened() {}
/*  87:    */   
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */   public void componentClosed() {}
/*  92:    */   
/*  93:    */ 
/*  94:    */ 
/*  95:    */   public void componentActivated()
/*  96:    */   {
/*  97: 97 */     ActiveViewManager.getInstance().set(this);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void componentDeactivated()
/* 101:    */   {
/* 102:102 */     ActiveViewManager.getInstance().set(null);
/* 103:    */   }
/* 104:    */   
/* 105:    */ 
/* 106:    */   void writeProperties(Properties p)
/* 107:    */   {
/* 108:108 */     p.setProperty("version", "1.0");
/* 109:    */   }
/* 110:    */   
/* 111:    */   void readProperties(Properties p)
/* 112:    */   {
/* 113:113 */     String version = p.getProperty("version");
/* 114:    */   }
/* 115:    */   
/* 116:    */ 
/* 117:    */   public boolean fill(JMenu menu)
/* 118:    */   {
/* 119:119 */     return false;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Node getNode()
/* 123:    */   {
/* 124:124 */     return node;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public ExplorerManager getExplorerManager()
/* 128:    */   {
/* 129:129 */     return ActiveViewManager.getInstance().getExplorerManager();
/* 130:    */   }
/* 131:    */   
/* 132:    */   public boolean hasContextMenu()
/* 133:    */   {
/* 134:134 */     return false;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public Ts getTs()
/* 138:    */   {
/* 139:139 */     return null;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setTs(Ts ts)
/* 143:    */   {
/* 144:144 */     view.setTs(ts);
/* 145:    */   }
/* 146:    */   
/* 147:    */   class InternalNode extends AbstractNode
/* 148:    */   {
/* 149:    */     InternalNode() {
/* 150:150 */       super();
/* 151:151 */       setDisplayName("Tukey Spectrum");
/* 152:    */     }
/* 153:    */     
/* 154:    */     protected Sheet createSheet()
/* 155:    */     {
/* 156:156 */       Sheet sheet = super.createSheet();
/* 157:157 */       Sheet.Set transform = Sheet.createPropertiesSet();
/* 158:158 */       transform.setName("Transform");
/* 159:159 */       transform.setDisplayName("Transformation");
/* 160:160 */       Node.Property<Boolean> log = new Node.Property(Boolean.class)
/* 161:    */       {
/* 162:    */         public boolean canRead()
/* 163:    */         {
/* 164:164 */           return true;
/* 165:    */         }
/* 166:    */         
/* 167:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 168:    */         {
/* 169:169 */           return Boolean.valueOf(view.isLogTransformation());
/* 170:    */         }
/* 171:    */         
/* 172:    */         public boolean canWrite()
/* 173:    */         {
/* 174:174 */           return true;
/* 175:    */         }
/* 176:    */         
/* 177:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 178:    */         {
/* 179:179 */           view.setLogTransformation(((Boolean)t).booleanValue());
/* 180:    */         }
/* 181:    */         
/* 182:182 */       };
/* 183:183 */       log.setName("Log");
/* 184:184 */       transform.put(log);
/* 185:185 */       Node.Property<Integer> diff = new Node.Property(Integer.class)
/* 186:    */       {
/* 187:    */         public boolean canRead()
/* 188:    */         {
/* 189:189 */           return true;
/* 190:    */         }
/* 191:    */         
/* 192:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 193:    */         {
/* 194:194 */           return Integer.valueOf(view.getDifferencingOrder());
/* 195:    */         }
/* 196:    */         
/* 197:    */         public boolean canWrite()
/* 198:    */         {
/* 199:199 */           return true;
/* 200:    */         }
/* 201:    */         
/* 202:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 203:    */         {
/* 204:204 */           view.setDifferencingOrder(((Integer)t).intValue());
/* 205:    */         }
/* 206:    */         
/* 207:207 */       };
/* 208:208 */       diff.setName("Differencing");
/* 209:209 */       transform.put(diff);
/* 210:    */       
/* 211:211 */       Node.Property<Integer> diffLag = new Node.Property(Integer.class)
/* 212:    */       {
/* 213:    */         public boolean canRead()
/* 214:    */         {
/* 215:215 */           return true;
/* 216:    */         }
/* 217:    */         
/* 218:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 219:    */         {
/* 220:220 */           return Integer.valueOf(view.getDifferencingLag());
/* 221:    */         }
/* 222:    */         
/* 223:    */         public boolean canWrite()
/* 224:    */         {
/* 225:225 */           return true;
/* 226:    */         }
/* 227:    */         
/* 228:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 229:    */         {
/* 230:230 */           view.setDifferencingLag(((Integer)t).intValue());
/* 231:    */         }
/* 232:232 */       };
/* 233:233 */       diffLag.setName("Differencing lag");
/* 234:234 */       transform.put(diffLag);
/* 235:    */       
/* 236:236 */       Node.Property<Integer> length = new Node.Property(Integer.class)
/* 237:    */       {
/* 238:    */         public boolean canRead()
/* 239:    */         {
/* 240:240 */           return true;
/* 241:    */         }
/* 242:    */         
/* 243:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 244:    */         {
/* 245:245 */           return Integer.valueOf(view.getLastYears());
/* 246:    */         }
/* 247:    */         
/* 248:    */         public boolean canWrite()
/* 249:    */         {
/* 250:250 */           return true;
/* 251:    */         }
/* 252:    */         
/* 253:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 254:    */         {
/* 255:255 */           view.setLastYears(((Integer)t).intValue());
/* 256:    */         }
/* 257:257 */       };
/* 258:258 */       length.setName("Last years");
/* 259:259 */       length.setShortDescription("Number of years at the end of the series taken into account (0 = whole series)");
/* 260:260 */       transform.put(length);
/* 261:    */       
/* 262:262 */       sheet.put(transform);
/* 263:263 */       Sheet.Set spectrum = Sheet.createPropertiesSet();
/* 264:264 */       spectrum.setName("Tukey Spectrum");
/* 265:265 */       spectrum.setDisplayName("Tukey Spectrum");
/* 266:266 */       Node.Property<Double> taper = new Node.Property(Double.class)
/* 267:    */       {
/* 268:    */         public boolean canRead()
/* 269:    */         {
/* 270:270 */           return true;
/* 271:    */         }
/* 272:    */         
/* 273:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 274:    */         {
/* 275:275 */           return Double.valueOf(view.getTaperPart());
/* 276:    */         }
/* 277:    */         
/* 278:    */         public boolean canWrite()
/* 279:    */         {
/* 280:280 */           return true;
/* 281:    */         }
/* 282:    */         
/* 283:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 284:    */         {
/* 285:285 */           double p = ((Double)t).doubleValue();
/* 286:286 */           if ((p <= 0.0D) || (p > 1.0D)) {
/* 287:287 */             throw new IllegalArgumentException("Should be in ]0,1]");
/* 288:    */           }
/* 289:289 */           view.setTaperPart(p);
/* 290:    */         }
/* 291:291 */       };
/* 292:292 */       taper.setName("Taper part");
/* 293:293 */       spectrum.put(taper);
/* 294:294 */       Node.Property<Integer> wlength = new Node.Property(Integer.class)
/* 295:    */       {
/* 296:    */         public boolean canRead()
/* 297:    */         {
/* 298:298 */           return true;
/* 299:    */         }
/* 300:    */         
/* 301:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 302:    */         {
/* 303:303 */           return Integer.valueOf(view.getWindowLength());
/* 304:    */         }
/* 305:    */         
/* 306:    */         public boolean canWrite()
/* 307:    */         {
/* 308:308 */           return true;
/* 309:    */         }
/* 310:    */         
/* 311:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 312:    */         {
/* 313:313 */           view.setWindowLength(((Integer)t).intValue());
/* 314:    */         }
/* 315:    */         
/* 316:316 */       };
/* 317:317 */       wlength.setName("Window length");
/* 318:318 */       spectrum.put(wlength);
/* 319:319 */       Node.Property<WindowType> wtype = new Node.Property(WindowType.class)
/* 320:    */       {
/* 321:    */         public boolean canRead()
/* 322:    */         {
/* 323:323 */           return true;
/* 324:    */         }
/* 325:    */         
/* 326:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 327:    */         {
/* 328:328 */           return view.getWindowType();
/* 329:    */         }
/* 330:    */         
/* 331:    */         public boolean canWrite()
/* 332:    */         {
/* 333:333 */           return true;
/* 334:    */         }
/* 335:    */         
/* 336:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 337:    */         {
/* 338:338 */           view.setWindowType((WindowType)t);
/* 339:    */         }
/* 340:    */         
/* 341:341 */       };
/* 342:342 */       wtype.setName("Window type");
/* 343:343 */       spectrum.put(wtype);
/* 344:344 */       sheet.put(spectrum);
/* 345:345 */       return sheet;
/* 346:    */     }
/* 347:    */   }
/* 348:    */ }
