/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.nodes.ControlNode;
/*   4:    */ import ec.ui.ATsGrowthChart;
/*   5:    */ import java.awt.BorderLayout;
/*   6:    */ import java.util.Properties;
/*   7:    */ import org.openide.explorer.ExplorerManager;
/*   8:    */ import org.openide.explorer.ExplorerManager.Provider;
/*   9:    */ import org.openide.nodes.Node;
/*  10:    */ import org.openide.windows.Mode;
/*  11:    */ import org.openide.windows.TopComponent;
/*  12:    */ import org.openide.windows.TopComponent.Description;
/*  13:    */ import org.openide.windows.WindowManager;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ @TopComponent.Description(preferredID="GrowthChartTopComponent", persistenceType=1)
/*  45:    */ public final class GrowthChartTopComponent
/*  46:    */   extends TopComponent
/*  47:    */   implements ExplorerManager.Provider
/*  48:    */ {
/*  49:    */   private final ExplorerManager mgr;
/*  50:    */   
/*  51:    */   public void open()
/*  52:    */   {
/*  53: 53 */     super.open();
/*  54: 54 */     Mode mode = WindowManager.getDefault().findMode("output");
/*  55: 55 */     if ((mode != null) && (mode.canDock(this))) {
/*  56: 56 */       mode.dockInto(this);
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */   private void initComponents()
/*  67:    */   {
/*  68: 68 */     setLayout(new BorderLayout());
/*  69:    */   }
/*  70:    */   
/*  71:    */ 
/*  72:    */ 
/*  73:    */   public void componentOpened()
/*  74:    */   {
/*  75: 75 */     ControlNode.onComponentOpened(mgr, getGrowthChart());
/*  76: 76 */     getGrowthChart().connect();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void componentClosed()
/*  80:    */   {
/*  81: 81 */     mgr.setRootContext(Node.EMPTY);
/*  82: 82 */     getGrowthChart().dispose();
/*  83:    */   }
/*  84:    */   
/*  85:    */ 
/*  86:    */   void writeProperties(Properties p)
/*  87:    */   {
/*  88: 88 */     p.setProperty("version", "1.0");
/*  89: 89 */     ToolsPersistence.writeTsCollection(getGrowthChart(), p);
/*  90:    */   }
/*  91:    */   
/*  92:    */   void readProperties(Properties p) {
/*  93: 93 */     String version = p.getProperty("version");
/*  94: 94 */     ToolsPersistence.readTsCollection(getGrowthChart(), p);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public ExplorerManager getExplorerManager()
/*  98:    */   {
/*  99: 99 */     return mgr;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public ATsGrowthChart getGrowthChart() {
/* 103:103 */     return (ATsGrowthChart)getComponent(0);
/* 104:    */   }
/* 105:    */ }
