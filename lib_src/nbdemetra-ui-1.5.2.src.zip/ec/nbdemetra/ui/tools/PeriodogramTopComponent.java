/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ActiveViewManager;
/*   4:    */ import ec.nbdemetra.ui.IActiveView;
/*   5:    */ import ec.nbdemetra.ui.tsaction.ITsView2;
/*   6:    */ import ec.tss.Ts;
/*   7:    */ import ec.ui.view.PeriodogramView;
/*   8:    */ import java.lang.reflect.InvocationTargetException;
/*   9:    */ import java.util.Properties;
/*  10:    */ import javax.swing.BoxLayout;
/*  11:    */ import javax.swing.JMenu;
/*  12:    */ import org.openide.explorer.ExplorerManager;
/*  13:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  14:    */ import org.openide.nodes.AbstractNode;
/*  15:    */ import org.openide.nodes.Children;
/*  16:    */ import org.openide.nodes.Node;
/*  17:    */ import org.openide.nodes.Node.Property;
/*  18:    */ import org.openide.nodes.Sheet;
/*  19:    */ import org.openide.nodes.Sheet.Set;
/*  20:    */ import org.openide.windows.Mode;
/*  21:    */ import org.openide.windows.TopComponent;
/*  22:    */ import org.openide.windows.TopComponent.Description;
/*  23:    */ import org.openide.windows.WindowManager;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ @TopComponent.Description(preferredID="PeriodogramTopComponent", persistenceType=2)
/*  51:    */ public final class PeriodogramTopComponent
/*  52:    */   extends TopComponent
/*  53:    */   implements ITsView2, IActiveView, ExplorerManager.Provider
/*  54:    */ {
/*  55:    */   private PeriodogramView view;
/*  56:    */   private Node node;
/*  57:    */   
/*  58:    */   public void open()
/*  59:    */   {
/*  60: 60 */     super.open();
/*  61: 61 */     Mode mode = WindowManager.getDefault().findMode("output");
/*  62: 62 */     if ((mode != null) && (mode.canDock(this))) {
/*  63: 63 */       mode.dockInto(this);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */   private void initComponents()
/*  74:    */   {
/*  75: 75 */     setLayout(new BoxLayout(this, 2));
/*  76:    */   }
/*  77:    */   
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */   public void componentOpened() {}
/*  82:    */   
/*  83:    */ 
/*  84:    */ 
/*  85:    */   public void componentClosed() {}
/*  86:    */   
/*  87:    */ 
/*  88:    */ 
/*  89:    */   public void componentActivated()
/*  90:    */   {
/*  91: 91 */     ActiveViewManager.getInstance().set(this);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void componentDeactivated()
/*  95:    */   {
/*  96: 96 */     ActiveViewManager.getInstance().set(null);
/*  97:    */   }
/*  98:    */   
/*  99:    */ 
/* 100:    */   void writeProperties(Properties p)
/* 101:    */   {
/* 102:102 */     p.setProperty("version", "1.0");
/* 103:    */   }
/* 104:    */   
/* 105:    */   void readProperties(Properties p)
/* 106:    */   {
/* 107:107 */     String version = p.getProperty("version");
/* 108:    */   }
/* 109:    */   
/* 110:    */ 
/* 111:    */   public Ts getTs()
/* 112:    */   {
/* 113:113 */     return null;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void setTs(Ts ts)
/* 117:    */   {
/* 118:118 */     view.setTs(ts);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean fill(JMenu menu)
/* 122:    */   {
/* 123:123 */     return false;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public Node getNode()
/* 127:    */   {
/* 128:128 */     return node;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public ExplorerManager getExplorerManager()
/* 132:    */   {
/* 133:133 */     return ActiveViewManager.getInstance().getExplorerManager();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public boolean hasContextMenu()
/* 137:    */   {
/* 138:138 */     return false;
/* 139:    */   }
/* 140:    */   
/* 141:    */   class InternalNode extends AbstractNode
/* 142:    */   {
/* 143:    */     InternalNode() {
/* 144:144 */       super();
/* 145:145 */       setDisplayName("Periodogram");
/* 146:    */     }
/* 147:    */     
/* 148:    */     protected Sheet createSheet()
/* 149:    */     {
/* 150:150 */       Sheet sheet = super.createSheet();
/* 151:151 */       Sheet.Set transform = Sheet.createPropertiesSet();
/* 152:152 */       transform.setName("Transform");
/* 153:153 */       transform.setDisplayName("Transformation");
/* 154:154 */       Node.Property<Boolean> log = new Node.Property(Boolean.class)
/* 155:    */       {
/* 156:    */         public boolean canRead() {
/* 157:157 */           return true;
/* 158:    */         }
/* 159:    */         
/* 160:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 161:    */         {
/* 162:162 */           return Boolean.valueOf(view.isLogTransformation());
/* 163:    */         }
/* 164:    */         
/* 165:    */         public boolean canWrite()
/* 166:    */         {
/* 167:167 */           return true;
/* 168:    */         }
/* 169:    */         
/* 170:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 171:    */         {
/* 172:172 */           view.setLogTransformation(((Boolean)t).booleanValue());
/* 173:    */         }
/* 174:    */         
/* 175:175 */       };
/* 176:176 */       log.setName("Log");
/* 177:177 */       transform.put(log);
/* 178:178 */       Node.Property<Integer> diff = new Node.Property(Integer.class)
/* 179:    */       {
/* 180:    */         public boolean canRead() {
/* 181:181 */           return true;
/* 182:    */         }
/* 183:    */         
/* 184:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 185:    */         {
/* 186:186 */           return Integer.valueOf(view.getDifferencingOrder());
/* 187:    */         }
/* 188:    */         
/* 189:    */         public boolean canWrite()
/* 190:    */         {
/* 191:191 */           return true;
/* 192:    */         }
/* 193:    */         
/* 194:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 195:    */         {
/* 196:196 */           view.setDifferencingOrder(((Integer)t).intValue());
/* 197:    */         }
/* 198:    */         
/* 199:199 */       };
/* 200:200 */       diff.setName("Differencing");
/* 201:201 */       transform.put(diff);
/* 202:202 */       Node.Property<Integer> diffLag = new Node.Property(Integer.class)
/* 203:    */       {
/* 204:    */         public boolean canRead() {
/* 205:205 */           return true;
/* 206:    */         }
/* 207:    */         
/* 208:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 209:    */         {
/* 210:210 */           return Integer.valueOf(view.getDifferencingLag());
/* 211:    */         }
/* 212:    */         
/* 213:    */         public boolean canWrite()
/* 214:    */         {
/* 215:215 */           return true;
/* 216:    */         }
/* 217:    */         
/* 218:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 219:    */         {
/* 220:220 */           view.setDifferencingLag(((Integer)t).intValue());
/* 221:    */         }
/* 222:222 */       };
/* 223:223 */       diffLag.setName("Differencing lag");
/* 224:224 */       transform.put(diffLag);
/* 225:    */       
/* 226:226 */       Node.Property<Integer> length = new Node.Property(Integer.class)
/* 227:    */       {
/* 228:    */         public boolean canRead() {
/* 229:229 */           return true;
/* 230:    */         }
/* 231:    */         
/* 232:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 233:    */         {
/* 234:234 */           return Integer.valueOf(view.getLastYears());
/* 235:    */         }
/* 236:    */         
/* 237:    */         public boolean canWrite()
/* 238:    */         {
/* 239:239 */           return true;
/* 240:    */         }
/* 241:    */         
/* 242:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 243:    */         {
/* 244:244 */           view.setLastYears(((Integer)t).intValue());
/* 245:    */         }
/* 246:246 */       };
/* 247:247 */       length.setName("Last years");
/* 248:248 */       length.setShortDescription("Number of years at the end of the series taken into account (0 = whole series)");
/* 249:249 */       transform.put(length);
/* 250:    */       
/* 251:251 */       sheet.put(transform);
/* 252:252 */       return sheet;
/* 253:    */     }
/* 254:    */   }
/* 255:    */ }
