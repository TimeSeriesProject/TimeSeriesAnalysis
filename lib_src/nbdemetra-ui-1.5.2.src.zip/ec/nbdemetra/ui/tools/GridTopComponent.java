/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.nbdemetra.ui.nodes.ControlNode;
/*   6:    */ import ec.ui.ATsGrid;
/*   7:    */ import java.awt.BorderLayout;
/*   8:    */ import java.util.Properties;
/*   9:    */ import javax.swing.ActionMap;
/*  10:    */ import javax.swing.JButton;
/*  11:    */ import javax.swing.JComponent;
/*  12:    */ import javax.swing.JToggleButton;
/*  13:    */ import javax.swing.JToolBar;
/*  14:    */ import org.netbeans.core.spi.multiview.CloseOperationState;
/*  15:    */ import org.netbeans.core.spi.multiview.MultiViewElement;
/*  16:    */ import org.netbeans.core.spi.multiview.MultiViewElementCallback;
/*  17:    */ import org.openide.explorer.ExplorerManager;
/*  18:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  19:    */ import org.openide.nodes.Node;
/*  20:    */ import org.openide.windows.Mode;
/*  21:    */ import org.openide.windows.TopComponent;
/*  22:    */ import org.openide.windows.TopComponent.Description;
/*  23:    */ import org.openide.windows.WindowManager;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ @TopComponent.Description(preferredID="GridTopComponent", persistenceType=1)
/*  58:    */ public final class GridTopComponent
/*  59:    */   extends TopComponent
/*  60:    */   implements ExplorerManager.Provider, MultiViewElement
/*  61:    */ {
/*  62:    */   private final ExplorerManager mgr;
/*  63:    */   
/*  64:    */   private void initComponents()
/*  65:    */   {
/*  66: 66 */     setLayout(new BorderLayout());
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70:    */ 
/*  71:    */   public void open()
/*  72:    */   {
/*  73: 73 */     super.open();
/*  74: 74 */     WindowManager.getDefault().getModes();
/*  75: 75 */     Mode mode = WindowManager.getDefault().findMode("tsnavigator");
/*  76: 76 */     if (mode != null) {
/*  77: 77 */       mode.dockInto(this);
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void componentOpened()
/*  82:    */   {
/*  83: 83 */     ControlNode.onComponentOpened(mgr, getGrid());
/*  84: 84 */     getGrid().connect();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void componentClosed()
/*  88:    */   {
/*  89: 89 */     mgr.setRootContext(Node.EMPTY);
/*  90: 90 */     getGrid().dispose();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public JComponent getVisualRepresentation()
/*  94:    */   {
/*  95: 95 */     return this;
/*  96:    */   }
/*  97:    */   
/*  98:    */ 
/*  99:    */   public JComponent getToolbarRepresentation()
/* 100:    */   {
/* 101:101 */     JToolBar result = NbComponents.newInnerToolbar();
/* 102:    */     
/* 103:103 */     result.addSeparator();
/* 104:    */     
/* 105:105 */     JButton copy = new JButton(getGrid().getActionMap().get("copyAll"));
/* 106:106 */     copy.setText("");
/* 107:107 */     copy.setToolTipText("Copy");
/* 108:108 */     copy.setIcon(DemetraUiIcon.EDIT_COPY_16);
/* 109:109 */     result.add(copy);
/* 110:    */     
/* 111:111 */     JToggleButton transpose = new JToggleButton(getGrid().getActionMap().get("transpose"));
/* 112:112 */     transpose.setText("");
/* 113:113 */     transpose.setToolTipText("Transpose");
/* 114:114 */     transpose.setIcon(DemetraUiIcon.HORIZONTAL_16);
/* 115:115 */     transpose.setSelectedIcon(DemetraUiIcon.VERTICAL_16);
/* 116:116 */     result.add(transpose);
/* 117:    */     
/* 118:118 */     JToggleButton reverse = new JToggleButton(getGrid().getActionMap().get("reverse"));
/* 119:119 */     reverse.setText("");
/* 120:120 */     reverse.setToolTipText("Reverse chronology");
/* 121:121 */     reverse.setIcon(DemetraUiIcon.SORT_DATE_16);
/* 122:122 */     reverse.setSelectedIcon(DemetraUiIcon.SORT_DATE_DESCENDING_16);
/* 123:123 */     result.add(reverse);
/* 124:    */     
/* 125:125 */     return result;
/* 126:    */   }
/* 127:    */   
/* 128:    */ 
/* 129:    */   public void setMultiViewCallback(MultiViewElementCallback callback) {}
/* 130:    */   
/* 131:    */ 
/* 132:    */   public void componentDeactivated()
/* 133:    */   {
/* 134:134 */     super.componentDeactivated();
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void componentActivated()
/* 138:    */   {
/* 139:139 */     super.componentActivated();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void componentHidden()
/* 143:    */   {
/* 144:144 */     super.componentHidden();
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void componentShowing()
/* 148:    */   {
/* 149:149 */     super.componentShowing();
/* 150:    */   }
/* 151:    */   
/* 152:    */   public CloseOperationState canCloseElement()
/* 153:    */   {
/* 154:154 */     return CloseOperationState.STATE_OK;
/* 155:    */   }
/* 156:    */   
/* 157:    */ 
/* 158:    */   void writeProperties(Properties p)
/* 159:    */   {
/* 160:160 */     p.setProperty("version", "1.0");
/* 161:161 */     ToolsPersistence.writeTsCollection(getGrid(), p);
/* 162:    */   }
/* 163:    */   
/* 164:    */   void readProperties(Properties p) {
/* 165:165 */     String version = p.getProperty("version");
/* 166:166 */     ToolsPersistence.readTsCollection(getGrid(), p);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public ExplorerManager getExplorerManager()
/* 170:    */   {
/* 171:171 */     return mgr;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public ATsGrid getGrid() {
/* 175:175 */     return (ATsGrid)getComponent(0);
/* 176:    */   }
/* 177:    */ }
