/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.nodes.ControlNode;
/*   4:    */ import ec.ui.ATsList;
/*   5:    */ import java.awt.BorderLayout;
/*   6:    */ import java.util.Properties;
/*   7:    */ import org.openide.explorer.ExplorerManager;
/*   8:    */ import org.openide.explorer.ExplorerManager.Provider;
/*   9:    */ import org.openide.nodes.Node;
/*  10:    */ import org.openide.windows.Mode;
/*  11:    */ import org.openide.windows.TopComponent;
/*  12:    */ import org.openide.windows.TopComponent.Description;
/*  13:    */ import org.openide.windows.WindowManager;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ @TopComponent.Description(preferredID="ListTopComponent", persistenceType=0)
/*  51:    */ public final class ListTopComponent
/*  52:    */   extends TopComponent
/*  53:    */   implements ExplorerManager.Provider
/*  54:    */ {
/*  55:    */   private final ExplorerManager mgr;
/*  56:    */   
/*  57:    */   private void initComponents()
/*  58:    */   {
/*  59: 59 */     setLayout(new BorderLayout());
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void open()
/*  63:    */   {
/*  64: 64 */     super.open();
/*  65: 65 */     WindowManager.getDefault().getModes();
/*  66: 66 */     Mode mode = WindowManager.getDefault().findMode("tsnavigator");
/*  67: 67 */     if (mode != null) {
/*  68: 68 */       mode.dockInto(this);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void componentOpened()
/*  73:    */   {
/*  74: 74 */     ControlNode.onComponentOpened(mgr, getList());
/*  75: 75 */     getList().connect();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void componentClosed()
/*  79:    */   {
/*  80: 80 */     mgr.setRootContext(Node.EMPTY);
/*  81: 81 */     getList().dispose();
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */   void writeProperties(Properties p)
/*  86:    */   {
/*  87: 87 */     p.setProperty("version", "1.0");
/*  88: 88 */     ToolsPersistence.writeTsCollection(getList(), p);
/*  89:    */   }
/*  90:    */   
/*  91:    */   void readProperties(Properties p) {
/*  92: 92 */     String version = p.getProperty("version");
/*  93: 93 */     ToolsPersistence.readTsCollection(getList(), p);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public ExplorerManager getExplorerManager()
/*  97:    */   {
/*  98: 98 */     return mgr;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public ATsList getList() {
/* 102:102 */     return (ATsList)getComponent(0);
/* 103:    */   }
/* 104:    */ }
