/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.tss.Ts;
/*   4:    */ import ec.tss.TsCollection;
/*   5:    */ import ec.tss.TsFactory;
/*   6:    */ import ec.tss.TsInformationType;
/*   7:    */ import ec.tss.TsStatus;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*   9:    */ import ec.ui.chart.JTsChart;
/*  10:    */ import ec.ui.list.JTsList;
/*  11:    */ import java.beans.PropertyChangeEvent;
/*  12:    */ import java.beans.PropertyChangeListener;
/*  13:    */ import java.util.Properties;
/*  14:    */ import javax.swing.JSplitPane;
/*  15:    */ import org.openide.windows.TopComponent;
/*  16:    */ import org.openide.windows.TopComponent.Description;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ @TopComponent.Description(preferredID="AggregationTopComponent", persistenceType=2)
/*  72:    */ public final class AggregationTopComponent
/*  73:    */   extends TopComponent
/*  74:    */ {
/*  75:    */   private final JSplitPane mainPane;
/*  76:    */   private final JTsList inputList;
/*  77:    */   private final JTsChart aggChart;
/*  78:    */   
/*  79:    */   private void initComponents() {}
/*  80:    */   
/*  81:    */   public void componentOpened()
/*  82:    */   {
/*  83: 83 */     aggChart.connect();
/*  84: 84 */     inputList.connect();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void componentClosed()
/*  88:    */   {
/*  89: 89 */     aggChart.dispose();
/*  90: 90 */     inputList.dispose();
/*  91:    */   }
/*  92:    */   
/*  93:    */ 
/*  94:    */   void writeProperties(Properties p)
/*  95:    */   {
/*  96: 96 */     p.setProperty("version", "1.0");
/*  97:    */   }
/*  98:    */   
/*  99:    */   void readProperties(Properties p)
/* 100:    */   {
/* 101:101 */     String version = p.getProperty("version");
/* 102:    */   }
/* 103:    */   
/* 104:    */   private void initList()
/* 105:    */   {
/* 106:106 */     inputList.addPropertyChangeListener("tsCollection", new PropertyChangeListener()
/* 107:    */     {
/* 108:    */       public void propertyChange(PropertyChangeEvent evt)
/* 109:    */       {
/* 110:110 */         TsData sum = null;
/* 111:111 */         for (Ts s : inputList.getTsCollection()) {
/* 112:112 */           if (s.hasData() == TsStatus.Undefined) {
/* 113:113 */             s.load(TsInformationType.Data);
/* 114:    */           }
/* 115:115 */           sum = TsData.add(sum, s.getTsData());
/* 116:    */         }
/* 117:117 */         Ts t = TsFactory.instance.createTs("Total", null, sum);
/* 118:118 */         aggChart.getTsCollection().replace(t);
/* 119:    */       }
/* 120:    */     });
/* 121:    */   }
/* 122:    */ }
