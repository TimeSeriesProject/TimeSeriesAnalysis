/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.collect.Iterables;
/*   6:    */ import com.google.common.collect.Lists;
/*   7:    */ import ec.nbdemetra.ui.Config;
/*   8:    */ import ec.nbdemetra.ui.DemetraUI;
/*   9:    */ import ec.nbdemetra.ui.IConfigurable;
/*  10:    */ import ec.tss.Ts;
/*  11:    */ import ec.tss.TsCollection;
/*  12:    */ import ec.tss.TsFactory;
/*  13:    */ import ec.tss.TsInformationType;
/*  14:    */ import ec.tss.TsMoniker;
/*  15:    */ import ec.tss.tsproviders.utils.Formatters;
/*  16:    */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  17:    */ import ec.tss.tsproviders.utils.Parsers;
/*  18:    */ import ec.tss.tsproviders.utils.Parsers.FailSafeParser;
/*  19:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  20:    */ import ec.tstoolkit.utilities.URLEncoder2;
/*  21:    */ import ec.ui.interfaces.ITsCollectionView;
/*  22:    */ import java.net.URLDecoder;
/*  23:    */ import java.nio.charset.Charset;
/*  24:    */ import java.nio.charset.StandardCharsets;
/*  25:    */ import java.util.ArrayList;
/*  26:    */ import java.util.Arrays;
/*  27:    */ import java.util.List;
/*  28:    */ import java.util.Properties;
/*  29:    */ import javax.xml.bind.annotation.XmlAccessType;
/*  30:    */ import javax.xml.bind.annotation.XmlAccessorType;
/*  31:    */ import javax.xml.bind.annotation.XmlRootElement;
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public final class ToolsPersistence
/*  41:    */ {
/*  42:    */   private static <T> Optional<T> tryGet(Properties p, String key, Parsers.Parser<T> parser, boolean escape)
/*  43:    */   {
/*  44: 44 */     CharSequence stringValue = p.getProperty(key);
/*  45: 45 */     if (stringValue == null) {
/*  46: 46 */       return Optional.absent();
/*  47:    */     }
/*  48: 48 */     if (escape) {
/*  49: 49 */       stringValue = (CharSequence)Decoder.INSTANCE.parse(stringValue);
/*  50: 50 */       if (stringValue == null) {
/*  51: 51 */         return Optional.absent();
/*  52:    */       }
/*  53:    */     }
/*  54: 54 */     return parser.tryParse(stringValue);
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static <T> boolean tryPut(Properties p, String key, Formatters.Formatter<T> formatter, boolean escape, T value) {
/*  58: 58 */     String stringValue = formatter.formatAsString(value);
/*  59: 59 */     if (stringValue == null) {
/*  60: 60 */       return false;
/*  61:    */     }
/*  62: 62 */     if (escape) {
/*  63: 63 */       stringValue = Encoder.INSTANCE.formatAsString(stringValue);
/*  64: 64 */       if (stringValue == null) {
/*  65: 65 */         return false;
/*  66:    */       }
/*  67:    */     }
/*  68: 68 */     p.setProperty(key, stringValue);
/*  69: 69 */     return true;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static void writeTsCollection(ITsCollectionView view, Properties p) {
/*  73: 73 */     if ((view instanceof IConfigurable)) {
/*  74: 74 */       Config config = ((IConfigurable)view).getConfig();
/*  75: 75 */       tryPut(p, "config", Config.xmlFormatter(false), true, config);
/*  76:    */     }
/*  77: 77 */     if (DemetraUI.getDefault().isPersistToolsContent()) {
/*  78: 78 */       Content content = new Content(Lists.newArrayList(view.getTsCollection()), Arrays.asList(view.getSelection()));
/*  79: 79 */       tryPut(p, "content", CONTENT_FORMATTER, true, content);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static void readTsCollection(ITsCollectionView view, Properties p) {
/*  84: 84 */     if (DemetraUI.getDefault().isPersistToolsContent()) {
/*  85: 85 */       Optional<Content> content = tryGet(p, "content", CONTENT_PARSER, true);
/*  86: 86 */       if (content.isPresent()) {
/*  87: 87 */         view.getTsCollection().append(get()collection);
/*  88: 88 */         view.getTsCollection().load(TsInformationType.Data);
/*  89: 89 */         view.setSelection((Ts[])Iterables.toArray(get()selection, Ts.class));
/*  90:    */       }
/*  91:    */     }
/*  92: 92 */     if ((view instanceof IConfigurable)) {
/*  93: 93 */       Optional<Config> config = tryGet(p, "config", Config.xmlParser(), true);
/*  94: 94 */       if (config.isPresent()) {
/*  95: 95 */         ((IConfigurable)view).setConfig((Config)config.get());
/*  96:    */       }
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:100 */   private static final Formatters.Formatter<Content> CONTENT_FORMATTER = Formatters.onJAXB(ContentBean.class, false).compose(new Function()
/* 101:    */   {
/* 102:    */     public ToolsPersistence.ContentBean apply(ToolsPersistence.Content input) {
/* 103:103 */       return input.toBean();
/* 104:    */     }
/* 105:100 */   });
/* 106:    */   
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:106 */   private static final Parsers.Parser<Content> CONTENT_PARSER = Parsers.onJAXB(ContentBean.class).compose(new Function()
/* 112:    */   {
/* 113:    */     public ToolsPersistence.Content apply(ToolsPersistence.ContentBean input) {
/* 114:109 */       return ToolsPersistence.Content.fromBean(input);
/* 115:    */     }
/* 116:106 */   });
/* 117:    */   
/* 118:    */ 
/* 119:    */ 
/* 120:    */   private static class Content
/* 121:    */   {
/* 122:    */     final List<Ts> collection;
/* 123:    */     
/* 124:    */     final List<Ts> selection;
/* 125:    */     
/* 126:    */ 
/* 127:    */     Content(List<Ts> collection, List<Ts> selection)
/* 128:    */     {
/* 129:119 */       this.collection = collection;
/* 130:120 */       this.selection = selection;
/* 131:    */     }
/* 132:    */     
/* 133:    */     ToolsPersistence.ContentBean toBean() {
/* 134:124 */       List<ToolsPersistence.ContentItemBean> items = new ArrayList();
/* 135:125 */       for (Ts o : collection) {
/* 136:126 */         TsMoniker moniker = o.getMoniker();
/* 137:127 */         if (!moniker.isAnonymous()) {
/* 138:128 */           ToolsPersistence.ContentItemBean bean = new ToolsPersistence.ContentItemBean();
/* 139:129 */           name = o.getName();
/* 140:130 */           source = moniker.getSource();
/* 141:131 */           id = moniker.getId();
/* 142:132 */           selected = selection.contains(o);
/* 143:133 */           items.add(bean);
/* 144:    */         }
/* 145:    */       }
/* 146:136 */       ToolsPersistence.ContentBean result = new ToolsPersistence.ContentBean();
/* 147:137 */       items = ((ToolsPersistence.ContentItemBean[])Iterables.toArray(items, ToolsPersistence.ContentItemBean.class));
/* 148:138 */       return result;
/* 149:    */     }
/* 150:    */     
/* 151:    */     static Content fromBean(ToolsPersistence.ContentBean input) {
/* 152:142 */       Content result = new Content(new ArrayList(), new ArrayList());
/* 153:143 */       if (items != null) {
/* 154:144 */         for (ToolsPersistence.ContentItemBean o : items) {
/* 155:145 */           TsMoniker moniker = new TsMoniker(source, id);
/* 156:146 */           Ts ts = TsFactory.instance.createTs(name, moniker, TsInformationType.Definition);
/* 157:147 */           if (ts != null) {
/* 158:148 */             if (selected) {
/* 159:149 */               selection.add(ts);
/* 160:    */             }
/* 161:151 */             collection.add(ts);
/* 162:    */           }
/* 163:    */         }
/* 164:    */       }
/* 165:155 */       return result;
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */   private static class Encoder
/* 185:    */     extends Formatters.Formatter<CharSequence>
/* 186:    */   {
/* 187:177 */     static final Encoder INSTANCE = new Encoder();
/* 188:    */     
/* 189:    */     public CharSequence format(CharSequence value) throws NullPointerException
/* 190:    */     {
/* 191:181 */       return URLEncoder2.encode(value.toString(), StandardCharsets.UTF_8);
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   private static class Decoder extends Parsers.FailSafeParser<CharSequence>
/* 196:    */   {
/* 197:187 */     static final Decoder INSTANCE = new Decoder();
/* 198:    */     
/* 199:    */     protected CharSequence doParse(CharSequence input) throws Exception
/* 200:    */     {
/* 201:191 */       return URLDecoder.decode(input.toString(), StandardCharsets.UTF_8.name());
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   @XmlRootElement
/* 206:    */   @XmlAccessorType(XmlAccessType.FIELD)
/* 207:    */   static class ContentBean
/* 208:    */   {
/* 209:    */     ToolsPersistence.ContentItemBean[] items;
/* 210:    */   }
/* 211:    */   
/* 212:    */   @XmlAccessorType(XmlAccessType.FIELD)
/* 213:    */   static class ContentItemBean
/* 214:    */   {
/* 215:    */     String source;
/* 216:    */     String id;
/* 217:    */     String name;
/* 218:    */     boolean selected;
/* 219:    */   }
/* 220:    */ }
