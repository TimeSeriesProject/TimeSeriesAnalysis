/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.ActiveViewManager;
/*   4:    */ import ec.nbdemetra.ui.IActiveView;
/*   5:    */ import ec.nbdemetra.ui.tsaction.ITsView2;
/*   6:    */ import ec.tss.Ts;
/*   7:    */ import ec.ui.view.AutoRegressiveSpectrumView;
/*   8:    */ import java.lang.reflect.InvocationTargetException;
/*   9:    */ import java.util.Properties;
/*  10:    */ import javax.swing.BoxLayout;
/*  11:    */ import javax.swing.JMenu;
/*  12:    */ import org.openide.explorer.ExplorerManager;
/*  13:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  14:    */ import org.openide.nodes.AbstractNode;
/*  15:    */ import org.openide.nodes.Children;
/*  16:    */ import org.openide.nodes.Node;
/*  17:    */ import org.openide.nodes.Node.Property;
/*  18:    */ import org.openide.nodes.Sheet;
/*  19:    */ import org.openide.nodes.Sheet.Set;
/*  20:    */ import org.openide.windows.Mode;
/*  21:    */ import org.openide.windows.TopComponent;
/*  22:    */ import org.openide.windows.TopComponent.Description;
/*  23:    */ import org.openide.windows.WindowManager;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ @TopComponent.Description(preferredID="AutoRegressiveSpectrumTopComponent", persistenceType=2)
/*  53:    */ public final class AutoRegressiveSpectrumTopComponent
/*  54:    */   extends TopComponent
/*  55:    */   implements ITsView2, IActiveView, ExplorerManager.Provider
/*  56:    */ {
/*  57:    */   private AutoRegressiveSpectrumView view;
/*  58:    */   private Node node;
/*  59:    */   
/*  60:    */   public void open()
/*  61:    */   {
/*  62: 62 */     super.open();
/*  63: 63 */     Mode mode = WindowManager.getDefault().findMode("output");
/*  64: 64 */     if ((mode != null) && (mode.canDock(this))) {
/*  65: 65 */       mode.dockInto(this);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */   private void initComponents()
/*  76:    */   {
/*  77: 77 */     setLayout(new BoxLayout(this, 2));
/*  78:    */   }
/*  79:    */   
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */   public void componentOpened() {}
/*  84:    */   
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   public void componentClosed() {}
/*  89:    */   
/*  90:    */ 
/*  91:    */ 
/*  92:    */   public void componentActivated()
/*  93:    */   {
/*  94: 94 */     ActiveViewManager.getInstance().set(this);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void componentDeactivated()
/*  98:    */   {
/*  99: 99 */     ActiveViewManager.getInstance().set(null);
/* 100:    */   }
/* 101:    */   
/* 102:    */ 
/* 103:    */   void writeProperties(Properties p)
/* 104:    */   {
/* 105:105 */     p.setProperty("version", "1.0");
/* 106:    */   }
/* 107:    */   
/* 108:    */   void readProperties(Properties p)
/* 109:    */   {
/* 110:110 */     String version = p.getProperty("version");
/* 111:    */   }
/* 112:    */   
/* 113:    */ 
/* 114:    */   public Ts getTs()
/* 115:    */   {
/* 116:116 */     return null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setTs(Ts ts)
/* 120:    */   {
/* 121:121 */     view.setTs(ts);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean fill(JMenu menu)
/* 125:    */   {
/* 126:126 */     return false;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public Node getNode()
/* 130:    */   {
/* 131:131 */     return node;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public ExplorerManager getExplorerManager()
/* 135:    */   {
/* 136:136 */     return ActiveViewManager.getInstance().getExplorerManager();
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean hasContextMenu()
/* 140:    */   {
/* 141:141 */     return false;
/* 142:    */   }
/* 143:    */   
/* 144:    */   class InternalNode extends AbstractNode
/* 145:    */   {
/* 146:    */     InternalNode() {
/* 147:147 */       super();
/* 148:148 */       setDisplayName("Auto-regressive spectrum");
/* 149:    */     }
/* 150:    */     
/* 151:    */     protected Sheet createSheet()
/* 152:    */     {
/* 153:153 */       Sheet sheet = super.createSheet();
/* 154:154 */       Sheet.Set transform = Sheet.createPropertiesSet();
/* 155:155 */       transform.setName("Transform");
/* 156:156 */       transform.setDisplayName("Transformation");
/* 157:157 */       Node.Property<Boolean> log = new Node.Property(Boolean.class)
/* 158:    */       {
/* 159:    */         public boolean canRead()
/* 160:    */         {
/* 161:161 */           return true;
/* 162:    */         }
/* 163:    */         
/* 164:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 165:    */         {
/* 166:166 */           return Boolean.valueOf(view.isLogTransformation());
/* 167:    */         }
/* 168:    */         
/* 169:    */         public boolean canWrite()
/* 170:    */         {
/* 171:171 */           return true;
/* 172:    */         }
/* 173:    */         
/* 174:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 175:    */         {
/* 176:176 */           view.setLogTransformation(((Boolean)t).booleanValue());
/* 177:    */         }
/* 178:    */         
/* 179:179 */       };
/* 180:180 */       log.setName("Log");
/* 181:181 */       transform.put(log);
/* 182:    */       
/* 183:183 */       Node.Property<Integer> diff = new Node.Property(Integer.class)
/* 184:    */       {
/* 185:    */         public boolean canRead()
/* 186:    */         {
/* 187:187 */           return true;
/* 188:    */         }
/* 189:    */         
/* 190:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 191:    */         {
/* 192:192 */           return Integer.valueOf(view.getDifferencingOrder());
/* 193:    */         }
/* 194:    */         
/* 195:    */         public boolean canWrite()
/* 196:    */         {
/* 197:197 */           return true;
/* 198:    */         }
/* 199:    */         
/* 200:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 201:    */         {
/* 202:202 */           view.setDifferencingOrder(((Integer)t).intValue());
/* 203:    */         }
/* 204:204 */       };
/* 205:205 */       diff.setName("Differencing");
/* 206:206 */       transform.put(diff);
/* 207:    */       
/* 208:208 */       Node.Property<Integer> diffLag = new Node.Property(Integer.class)
/* 209:    */       {
/* 210:    */         public boolean canRead()
/* 211:    */         {
/* 212:212 */           return true;
/* 213:    */         }
/* 214:    */         
/* 215:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 216:    */         {
/* 217:217 */           return Integer.valueOf(view.getDifferencingLag());
/* 218:    */         }
/* 219:    */         
/* 220:    */         public boolean canWrite()
/* 221:    */         {
/* 222:222 */           return true;
/* 223:    */         }
/* 224:    */         
/* 225:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 226:    */         {
/* 227:227 */           view.setDifferencingLag(((Integer)t).intValue());
/* 228:    */         }
/* 229:229 */       };
/* 230:230 */       diffLag.setName("Differencing lag");
/* 231:231 */       transform.put(diffLag);
/* 232:    */       
/* 233:233 */       Node.Property<Integer> length = new Node.Property(Integer.class)
/* 234:    */       {
/* 235:    */         public boolean canRead()
/* 236:    */         {
/* 237:237 */           return true;
/* 238:    */         }
/* 239:    */         
/* 240:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 241:    */         {
/* 242:242 */           return Integer.valueOf(view.getLastYears());
/* 243:    */         }
/* 244:    */         
/* 245:    */         public boolean canWrite()
/* 246:    */         {
/* 247:247 */           return true;
/* 248:    */         }
/* 249:    */         
/* 250:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 251:    */         {
/* 252:252 */           view.setLastYears(((Integer)t).intValue());
/* 253:    */         }
/* 254:254 */       };
/* 255:255 */       length.setName("Last years");
/* 256:256 */       length.setShortDescription("Number of years at the end of the series taken into account (0 = whole series)");
/* 257:257 */       transform.put(length);
/* 258:    */       
/* 259:259 */       Sheet.Set spectrum = Sheet.createPropertiesSet();
/* 260:260 */       spectrum.setName("Auto-regressive Spectrum");
/* 261:261 */       spectrum.setDisplayName("Auto-regressive Spectrum");
/* 262:    */       
/* 263:263 */       Node.Property<Integer> arcount = new Node.Property(Integer.class)
/* 264:    */       {
/* 265:    */         public boolean canRead()
/* 266:    */         {
/* 267:267 */           return true;
/* 268:    */         }
/* 269:    */         
/* 270:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 271:    */         {
/* 272:272 */           return Integer.valueOf(view.getArCount());
/* 273:    */         }
/* 274:    */         
/* 275:    */         public boolean canWrite()
/* 276:    */         {
/* 277:277 */           return true;
/* 278:    */         }
/* 279:    */         
/* 280:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 281:    */         {
/* 282:282 */           view.setArCount(((Integer)t).intValue());
/* 283:    */         }
/* 284:284 */       };
/* 285:285 */       arcount.setName("Auto-regressive polynomial order");
/* 286:286 */       spectrum.put(arcount);
/* 287:    */       
/* 288:288 */       Node.Property<Integer> resolution = new Node.Property(Integer.class)
/* 289:    */       {
/* 290:    */         public boolean canRead()
/* 291:    */         {
/* 292:292 */           return true;
/* 293:    */         }
/* 294:    */         
/* 295:    */         public Object getValue() throws IllegalAccessException, InvocationTargetException
/* 296:    */         {
/* 297:297 */           return Integer.valueOf(view.getResolution());
/* 298:    */         }
/* 299:    */         
/* 300:    */         public boolean canWrite()
/* 301:    */         {
/* 302:302 */           return true;
/* 303:    */         }
/* 304:    */         
/* 305:    */         public void setValue(Object t) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/* 306:    */         {
/* 307:307 */           view.setResolution(((Integer)t).intValue());
/* 308:    */         }
/* 309:309 */       };
/* 310:310 */       resolution.setName("Resolution");
/* 311:311 */       spectrum.put(resolution);
/* 312:    */       
/* 313:313 */       sheet.put(transform);
/* 314:314 */       sheet.put(spectrum);
/* 315:315 */       return sheet;
/* 316:    */     }
/* 317:    */   }
/* 318:    */ }
