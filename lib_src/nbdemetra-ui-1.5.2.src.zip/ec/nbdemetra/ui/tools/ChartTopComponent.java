/*   1:    */ package ec.nbdemetra.ui.tools;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   4:    */ import ec.nbdemetra.ui.NbComponents;
/*   5:    */ import ec.nbdemetra.ui.nodes.ControlNode;
/*   6:    */ import ec.ui.ATsChart;
/*   7:    */ import java.awt.BorderLayout;
/*   8:    */ import java.util.Properties;
/*   9:    */ import javax.swing.ActionMap;
/*  10:    */ import javax.swing.JButton;
/*  11:    */ import javax.swing.JComponent;
/*  12:    */ import javax.swing.JMenu;
/*  13:    */ import javax.swing.JPopupMenu;
/*  14:    */ import javax.swing.JToolBar;
/*  15:    */ import org.netbeans.core.spi.multiview.CloseOperationState;
/*  16:    */ import org.netbeans.core.spi.multiview.MultiViewElement;
/*  17:    */ import org.netbeans.core.spi.multiview.MultiViewElementCallback;
/*  18:    */ import org.openide.awt.DropDownButtonFactory;
/*  19:    */ import org.openide.explorer.ExplorerManager;
/*  20:    */ import org.openide.explorer.ExplorerManager.Provider;
/*  21:    */ import org.openide.nodes.Node;
/*  22:    */ import org.openide.windows.Mode;
/*  23:    */ import org.openide.windows.TopComponent;
/*  24:    */ import org.openide.windows.TopComponent.Description;
/*  25:    */ import org.openide.windows.WindowManager;
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ @TopComponent.Description(preferredID="ChartTopComponent", persistenceType=1)
/*  59:    */ public final class ChartTopComponent
/*  60:    */   extends TopComponent
/*  61:    */   implements ExplorerManager.Provider, MultiViewElement
/*  62:    */ {
/*  63:    */   private final ExplorerManager mgr;
/*  64:    */   
/*  65:    */   private void initComponents()
/*  66:    */   {
/*  67: 67 */     setLayout(new BorderLayout());
/*  68:    */   }
/*  69:    */   
/*  70:    */ 
/*  71:    */ 
/*  72:    */   public void open()
/*  73:    */   {
/*  74: 74 */     super.open();
/*  75: 75 */     WindowManager.getDefault().getModes();
/*  76: 76 */     Mode mode = WindowManager.getDefault().findMode("output");
/*  77: 77 */     if (mode != null) {
/*  78: 78 */       mode.dockInto(this);
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void componentOpened()
/*  83:    */   {
/*  84: 84 */     ControlNode.onComponentOpened(mgr, getChart());
/*  85: 85 */     getChart().connect();
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */   public JComponent getVisualRepresentation()
/* 110:    */   {
/* 111:111 */     return this;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public JComponent getToolbarRepresentation()
/* 115:    */   {
/* 116:116 */     JToolBar result = NbComponents.newInnerToolbar();
/* 117:    */     
/* 118:118 */     result.addSeparator();
/* 119:    */     
/* 120:120 */     JButton copyBtn = new JButton(getChart().getActionMap().get("copyAll"));
/* 121:121 */     copyBtn.setText("");
/* 122:122 */     copyBtn.setToolTipText("Copy");
/* 123:123 */     copyBtn.setIcon(DemetraUiIcon.EDIT_COPY_16);
/* 124:124 */     result.add(copyBtn);
/* 125:    */     
/* 126:126 */     JPopupMenu menuColorScheme = getChart().buildColorSchemeMenu().getPopupMenu();
/* 127:127 */     JButton coloSchemeBtn = DropDownButtonFactory.createDropDownButton(DemetraUiIcon.COLOR_SWATCH_16, menuColorScheme);
/* 128:128 */     coloSchemeBtn.addActionListener(getChart().getActionMap().get("defaultColorScheme"));
/* 129:129 */     result.add(coloSchemeBtn);
/* 130:    */     
/* 131:131 */     return result;
/* 132:    */   }
/* 133:    */   
/* 134:    */ 
/* 135:    */   public void setMultiViewCallback(MultiViewElementCallback callback) {}
/* 136:    */   
/* 137:    */ 
/* 138:    */   public void componentDeactivated()
/* 139:    */   {
/* 140:140 */     super.componentDeactivated();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void componentActivated()
/* 144:    */   {
/* 145:145 */     super.componentActivated();
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void componentHidden()
/* 149:    */   {
/* 150:150 */     super.componentHidden();
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void componentShowing()
/* 154:    */   {
/* 155:155 */     super.componentShowing();
/* 156:    */   }
/* 157:    */   
/* 158:    */   public CloseOperationState canCloseElement()
/* 159:    */   {
/* 160:160 */     return CloseOperationState.STATE_OK;
/* 161:    */   }
/* 162:    */   
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */   public void componentClosed()
/* 193:    */   {
/* 194:194 */     mgr.setRootContext(Node.EMPTY);
/* 195:195 */     getChart().dispose();
/* 196:    */   }
/* 197:    */   
/* 198:    */ 
/* 199:    */   void writeProperties(Properties p)
/* 200:    */   {
/* 201:201 */     p.setProperty("version", "1.0");
/* 202:202 */     ToolsPersistence.writeTsCollection(getChart(), p);
/* 203:    */   }
/* 204:    */   
/* 205:    */   void readProperties(Properties p) {
/* 206:206 */     String version = p.getProperty("version");
/* 207:207 */     ToolsPersistence.readTsCollection(getChart(), p);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public ExplorerManager getExplorerManager()
/* 211:    */   {
/* 212:212 */     return mgr;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public ATsChart getChart() {
/* 216:216 */     return (ATsChart)getComponent(0);
/* 217:    */   }
/* 218:    */ }
