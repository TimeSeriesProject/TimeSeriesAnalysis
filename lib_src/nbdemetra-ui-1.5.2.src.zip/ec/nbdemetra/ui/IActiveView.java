package ec.nbdemetra.ui;

import javax.swing.JMenu;
import org.openide.nodes.Node;

public abstract interface IActiveView
{
  public abstract String getName();
  
  public abstract boolean fill(JMenu paramJMenu);
  
  public abstract boolean hasContextMenu();
  
  public abstract Node getNode();
}
