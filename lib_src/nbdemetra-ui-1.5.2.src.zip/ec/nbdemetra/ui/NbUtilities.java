/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  4:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  5:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  6:   */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  7:   */ import ec.tss.tsproviders.DataSource;
/*  8:   */ import ec.tstoolkit.MetaData;
/*  9:   */ import ec.tstoolkit.algorithm.IProcDocument;
/* 10:   */ import java.awt.Dimension;
/* 11:   */ import java.util.ArrayList;
/* 12:   */ import java.util.Collections;
/* 13:   */ import java.util.List;
/* 14:   */ import java.util.Map.Entry;
/* 15:   */ import java.util.Objects;
/* 16:   */ import java.util.SortedMap;
/* 17:   */ import javax.swing.JEditorPane;
/* 18:   */ import javax.swing.JScrollPane;
/* 19:   */ import org.openide.DialogDescriptor;
/* 20:   */ import org.openide.DialogDisplayer;
/* 21:   */ import org.openide.NotifyDescriptor;
/* 22:   */ import org.openide.nodes.Sheet.Set;
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class NbUtilities
/* 28:   */ {
/* 29:   */   public static Sheet.Set createMetadataPropertiesSet(MetaData md)
/* 30:   */   {
/* 31:31 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Metadata");
/* 32:32 */     List<String> keys = new ArrayList(md.keySet());
/* 33:33 */     Collections.sort(keys);
/* 34:34 */     for (String key : keys) {
/* 35:35 */       String dname = key.charAt(0) == '@' ? key.substring(1) : key;
/* 36:36 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(key, md.get(key))).name(key).display(dname).add();
/* 37:   */     }
/* 38:38 */     return b.build();
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static Sheet.Set creatDataSourcePropertiesSet(DataSource dataSource) {
/* 42:42 */     NodePropertySetBuilder b = new NodePropertySetBuilder().name("Data source");
/* 43:43 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(dataSource, "getProviderName", null)).display("Source").add();
/* 44:44 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select(dataSource, "getVersion", null)).display("Version").add();
/* 45:45 */     for (Map.Entry<String, String> o : dataSource.getParams().entrySet()) {
/* 46:46 */       ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select((String)o.getKey(), (String)o.getValue())).add();
/* 47:   */     }
/* 48:48 */     return b.build();
/* 49:   */   }
/* 50:   */   
/* 51:   */   public static boolean editNote(IProcDocument doc) {
/* 52:52 */     if (doc == null) {
/* 53:53 */       return false;
/* 54:   */     }
/* 55:55 */     JEditorPane editor = new JEditorPane();
/* 56:56 */     JScrollPane scroll = NbComponents.newJScrollPane(editor);
/* 57:57 */     scroll.setPreferredSize(new Dimension(300, 100));
/* 58:58 */     MetaData md = doc.getMetaData();
/* 59:59 */     String oldNote = md.get("@note");
/* 60:60 */     editor.setText(oldNote);
/* 61:61 */     DialogDescriptor desc = new DialogDescriptor(scroll, "Note");
/* 62:62 */     if (DialogDisplayer.getDefault().notify(desc) != NotifyDescriptor.OK_OPTION) {
/* 63:63 */       return false;
/* 64:   */     }
/* 65:65 */     String newNote = editor.getText();
/* 66:66 */     if (Objects.equals(oldNote, newNote)) {
/* 67:67 */       return false;
/* 68:   */     }
/* 69:69 */     md.put("@note", newNote);
/* 70:70 */     return true;
/* 71:   */   }
/* 72:   */ }
