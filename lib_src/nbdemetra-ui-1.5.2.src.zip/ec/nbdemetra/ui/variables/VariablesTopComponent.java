/*  1:   */ package ec.nbdemetra.ui.variables;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  5:   */ import ec.nbdemetra.ws.ui.WorkspaceTopComponent;
/*  6:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  7:   */ import ec.ui.list.JTsVariableList;
/*  8:   */ import java.awt.BorderLayout;
/*  9:   */ import java.util.Properties;
/* 10:   */ import org.openide.util.NbBundle;
/* 11:   */ import org.openide.windows.TopComponent.Description;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ @TopComponent.Description(preferredID="VariablesTopComponent", persistenceType=0)
/* 38:   */ public final class VariablesTopComponent
/* 39:   */   extends WorkspaceTopComponent<TsVariables>
/* 40:   */ {
/* 41:   */   private JTsVariableList list;
/* 42:   */   
/* 43:   */   private static VariablesDocumentManager manager()
/* 44:   */   {
/* 45:45 */     return (VariablesDocumentManager)WorkspaceFactory.getInstance().getManager(VariablesDocumentManager.class);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public VariablesTopComponent() {
/* 49:49 */     super(manager().create(WorkspaceFactory.getInstance().getActiveWorkspace()));
/* 50:50 */     initDocument();
/* 51:   */   }
/* 52:   */   
/* 53:   */   public VariablesTopComponent(WorkspaceItem<TsVariables> doc) {
/* 54:54 */     super(doc);
/* 55:55 */     initDocument();
/* 56:   */   }
/* 57:   */   
/* 58:   */   private void initDocument() {
/* 59:59 */     initComponents();
/* 60:60 */     setToolTipText(NbBundle.getMessage(VariablesTopComponent.class, "HINT_VariablesTopComponent"));
/* 61:61 */     setName(getDocument().getDisplayName());
/* 62:   */   }
/* 63:   */   
/* 64:   */ 
/* 65:   */ 
/* 66:   */ 
/* 67:   */ 
/* 68:   */ 
/* 69:   */ 
/* 70:   */   private void initComponents()
/* 71:   */   {
/* 72:72 */     setLayout(new BorderLayout());
/* 73:73 */     list = new JTsVariableList((TsVariables)getDocument().getElement());
/* 74:74 */     add(list);
/* 75:   */   }
/* 76:   */   
/* 77:   */ 
/* 78:   */ 
/* 79:   */ 
/* 80:   */ 
/* 81:   */   void writeProperties(Properties p)
/* 82:   */   {
/* 83:83 */     p.setProperty("version", "1.0");
/* 84:   */   }
/* 85:   */   
/* 86:   */   void readProperties(Properties p)
/* 87:   */   {
/* 88:88 */     String version = p.getProperty("version");
/* 89:   */   }
/* 90:   */   
/* 91:   */ 
/* 92:   */ 
/* 93:   */   public void refresh() {}
/* 94:   */   
/* 95:   */ 
/* 96:   */ 
/* 97:   */   protected String getContextPath()
/* 98:   */   {
/* 99:99 */     return "variables.context";
/* :0:   */   }
/* :1:   */ }
