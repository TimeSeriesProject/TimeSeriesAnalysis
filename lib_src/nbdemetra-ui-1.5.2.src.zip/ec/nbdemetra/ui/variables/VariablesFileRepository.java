/*  1:   */ package ec.nbdemetra.ui.variables;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.AbstractFileItemRepository;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  6:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  7:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  8:   */ import ec.tstoolkit.utilities.NameManager;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public class VariablesFileRepository
/* 19:   */   extends AbstractFileItemRepository<TsVariables>
/* 20:   */ {
/* 21:   */   public static final String REPOSITORY = "Variables";
/* 22:   */   
/* 23:   */   public boolean load(WorkspaceItem<TsVariables> item)
/* 24:   */   {
/* 25:25 */     String sfile = fullName(item, "Variables", false);
/* 26:26 */     if (sfile == null) {
/* 27:27 */       return false;
/* 28:   */     }
/* 29:29 */     TsVariables doc = (TsVariables)AbstractFileItemRepository.loadLegacy(sfile, ec.tss.xml.regression.XmlTsVariables.class);
/* 30:30 */     if (doc == null) {
/* 31:31 */       doc = (TsVariables)AbstractFileItemRepository.loadLegacy(sfile, ec.tss.xml.legacy.XmlTsVariables.class);
/* 32:   */     }
/* 33:33 */     item.setElement(doc);
/* 34:34 */     item.resetDirty();
/* 35:35 */     if (doc != null) {
/* 36:36 */       item.getOwner().getContext().getTsVariableManagers().set(item.getDisplayName(), doc);
/* 37:   */     }
/* 38:38 */     return doc != null;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public boolean save(WorkspaceItem<TsVariables> item)
/* 42:   */   {
/* 43:43 */     String sfile = fullName(item, "Variables", true);
/* 44:44 */     if (sfile == null) {
/* 45:45 */       return false;
/* 46:   */     }
/* 47:47 */     if (AbstractFileItemRepository.saveLegacy(sfile, item, ec.tss.xml.regression.XmlTsVariables.class)) {
/* 48:48 */       item.resetDirty();
/* 49:49 */       ((TsVariables)item.getElement()).resetDirty();
/* 50:50 */       return true;
/* 51:   */     }
/* 52:52 */     return false;
/* 53:   */   }
/* 54:   */   
/* 55:   */ 
/* 56:   */   public boolean delete(WorkspaceItem<TsVariables> doc)
/* 57:   */   {
/* 58:58 */     return delete(doc, "Variables");
/* 59:   */   }
/* 60:   */   
/* 61:   */   public Class<TsVariables> getSupportedType()
/* 62:   */   {
/* 63:63 */     return TsVariables.class;
/* 64:   */   }
/* 65:   */ }
