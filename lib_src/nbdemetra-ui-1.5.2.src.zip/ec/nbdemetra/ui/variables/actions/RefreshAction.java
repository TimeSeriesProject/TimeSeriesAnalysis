/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  5:   */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*  6:   */ import ec.tstoolkit.timeseries.regression.ITsVariable;
/*  7:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  8:   */ import ec.tstoolkit.utilities.IDynamicObject;
/*  9:   */ import org.openide.DialogDisplayer;
/* 10:   */ import org.openide.NotifyDescriptor;
/* 11:   */ import org.openide.NotifyDescriptor.Confirmation;
/* 12:   */ import org.openide.util.HelpCtx;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public final class RefreshAction
/* 30:   */   extends SingleNodeAction<ItemWsNode>
/* 31:   */ {
/* 32:   */   public static final String WARNING_MESSAGE = "Refreshing variables may modify some estimations. Are you sure you want to continue?";
/* 33:   */   
/* 34:   */   public RefreshAction()
/* 35:   */   {
/* 36:36 */     super(ItemWsNode.class);
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected void performAction(ItemWsNode context)
/* 40:   */   {
/* 41:41 */     WorkspaceItem<TsVariables> cur = context.getItem();
/* 42:42 */     if ((cur != null) && (!cur.isReadOnly())) {
/* 43:43 */       NotifyDescriptor nd = new NotifyDescriptor.Confirmation("Refreshing variables may modify some estimations. Are you sure you want to continue?", 2);
/* 44:44 */       if (DialogDisplayer.getDefault().notify(nd) != NotifyDescriptor.OK_OPTION) {
/* 45:45 */         return;
/* 46:   */       }
/* 47:47 */       for (ITsVariable var : ((TsVariables)cur.getElement()).variables()) {
/* 48:48 */         if ((var instanceof IDynamicObject)) {
/* 49:49 */           IDynamicObject dvar = (IDynamicObject)var;
/* 50:50 */           dvar.refresh();
/* 51:   */         }
/* 52:   */       }
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   protected boolean enable(ItemWsNode context)
/* 57:   */   {
/* 58:58 */     WorkspaceItem<?> cur = context.getItem();
/* 59:59 */     return (cur != null) && (!cur.isReadOnly());
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String getName()
/* 63:   */   {
/* 64:64 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 65:   */   }
/* 66:   */   
/* 67:   */   public HelpCtx getHelpCtx()
/* 68:   */   {
/* 69:69 */     return null;
/* 70:   */   }
/* 71:   */ }
