/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.Workspace;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  6:   */ import ec.tstoolkit.timeseries.regression.ITsVariable;
/*  7:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  8:   */ import ec.tstoolkit.utilities.IDynamicObject;
/*  9:   */ import java.awt.event.ActionEvent;
/* 10:   */ import java.awt.event.ActionListener;
/* 11:   */ import java.util.Collection;
/* 12:   */ import java.util.Iterator;
/* 13:   */ import java.util.List;
/* 14:   */ import org.openide.DialogDisplayer;
/* 15:   */ import org.openide.NotifyDescriptor;
/* 16:   */ import org.openide.NotifyDescriptor.Confirmation;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ public final class RefreshAllAction
/* 35:   */   implements ActionListener
/* 36:   */ {
/* 37:   */   public static final String WARNING_MESSAGE = "Refreshing variables may modify some estimations. Are you sure you want to continue?";
/* 38:   */   
/* 39:   */   public void actionPerformed(ActionEvent e)
/* 40:   */   {
/* 41:41 */     NotifyDescriptor nd = new NotifyDescriptor.Confirmation("Refreshing variables may modify some estimations. Are you sure you want to continue?", 2);
/* 42:42 */     if (DialogDisplayer.getDefault().notify(nd) != NotifyDescriptor.OK_OPTION) {
/* 43:43 */       return;
/* 44:   */     }
/* 45:   */     
/* 46:46 */     List<WorkspaceItem<TsVariables>> documents = WorkspaceFactory.getInstance().getActiveWorkspace().searchDocuments(TsVariables.class);
/* 47:47 */     Iterator localIterator2; for (Iterator localIterator1 = documents.iterator(); localIterator1.hasNext(); 
/* 48:48 */         localIterator2.hasNext())
/* 49:   */     {
/* 50:47 */       WorkspaceItem<TsVariables> document = (WorkspaceItem)localIterator1.next();
/* 51:48 */       localIterator2 = ((TsVariables)document.getElement()).variables().iterator(); continue;ITsVariable var = (ITsVariable)localIterator2.next();
/* 52:49 */       if ((var instanceof IDynamicObject)) {
/* 53:50 */         IDynamicObject dvar = (IDynamicObject)var;
/* 54:51 */         dvar.refresh();
/* 55:   */       }
/* 56:   */     }
/* 57:   */   }
/* 58:   */ }
