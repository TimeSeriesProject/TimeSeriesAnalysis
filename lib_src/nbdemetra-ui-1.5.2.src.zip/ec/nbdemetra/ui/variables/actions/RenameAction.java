/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory.Event;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  7:   */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*  8:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  9:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/* 10:   */ import ec.tstoolkit.utilities.NameManager;
/* 11:   */ import java.beans.PropertyChangeEvent;
/* 12:   */ import java.beans.PropertyChangeListener;
/* 13:   */ import org.openide.DialogDisplayer;
/* 14:   */ import org.openide.NotifyDescriptor;
/* 15:   */ import org.openide.util.HelpCtx;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ public final class RenameAction
/* 37:   */   extends SingleNodeAction<ItemWsNode>
/* 38:   */ {
/* 39:   */   public static final String RENAME_TITLE = "Please enter the new name";
/* 40:   */   public static final String NAME_MESSAGE = "New name:";
/* 41:   */   
/* 42:   */   public RenameAction()
/* 43:   */   {
/* 44:44 */     super(ItemWsNode.class);
/* 45:   */   }
/* 46:   */   
/* 47:   */   protected void performAction(ItemWsNode context)
/* 48:   */   {
/* 49:49 */     WorkspaceItem<TsVariables> cur = context.getItem();
/* 50:50 */     if ((cur != null) && (!cur.isReadOnly()))
/* 51:   */     {
/* 52:52 */       String oldName = cur.getDisplayName();
/* 53:53 */       VarsName nd = new VarsName(cur.getFamily(), "New name:", "Please enter the new name", oldName);
/* 54:54 */       nd.addPropertyChangeListener(new PropertyChangeListener()
/* 55:   */       {
/* 56:   */         public void propertyChange(PropertyChangeEvent evt) {
/* 57:57 */           evt.getPropertyName().equals("detail");
/* 58:   */         }
/* 59:   */       });
/* 60:   */       
/* 61:61 */       if (DialogDisplayer.getDefault().notify(nd) != NotifyDescriptor.OK_OPTION) {
/* 62:62 */         return;
/* 63:   */       }
/* 64:64 */       String newName = nd.getInputText();
/* 65:65 */       if (newName.equals(oldName))
/* 66:66 */         return;
/* 67:67 */       ProcessingContext.getActiveContext().getTsVariableManagers().rename(oldName, newName);
/* 68:68 */       cur.setDisplayName(newName);
/* 69:69 */       WorkspaceFactory.Event ev = new WorkspaceFactory.Event(cur.getOwner(), cur.getId(), 17);
/* 70:70 */       WorkspaceFactory.getInstance().notifyEvent(ev);
/* 71:   */     }
/* 72:   */   }
/* 73:   */   
/* 74:   */   protected boolean enable(ItemWsNode context)
/* 75:   */   {
/* 76:76 */     WorkspaceItem<?> cur = context.getItem();
/* 77:77 */     return (cur != null) && (!cur.isReadOnly());
/* 78:   */   }
/* 79:   */   
/* 80:   */   public String getName()
/* 81:   */   {
/* 82:82 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 83:   */   }
/* 84:   */   
/* 85:   */   public HelpCtx getHelpCtx()
/* 86:   */   {
/* 87:87 */     return null;
/* 88:   */   }
/* 89:   */ }
