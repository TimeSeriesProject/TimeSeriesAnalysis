/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  4:   */ import ec.tstoolkit.utilities.Id;
/*  5:   */ import ec.tstoolkit.utilities.NameManager;
/*  6:   */ import javax.swing.InputVerifier;
/*  7:   */ import javax.swing.JComponent;
/*  8:   */ import javax.swing.JTextField;
/*  9:   */ import org.openide.DialogDisplayer;
/* 10:   */ import org.openide.NotifyDescriptor;
/* 11:   */ import org.openide.NotifyDescriptor.InputLine;
/* 12:   */ import org.openide.NotifyDescriptor.Message;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */ 
/* 62:   */ 
/* 63:   */ 
/* 64:   */ 
/* 65:   */ 
/* 66:   */ 
/* 67:   */ 
/* 68:   */ 
/* 69:   */ 
/* 70:   */ 
/* 71:   */ 
/* 72:   */ 
/* 73:   */ 
/* 74:   */ 
/* 75:   */ 
/* 76:   */ 
/* 77:   */ 
/* 78:   */ 
/* 79:   */ 
/* 80:   */ 
/* 81:   */ 
/* 82:   */ 
/* 83:   */ 
/* 84:   */ 
/* 85:   */ 
/* 86:   */ 
/* 87:   */ 
/* 88:   */ 
/* 89:   */ class VarsName
/* 90:   */   extends NotifyDescriptor.InputLine
/* 91:   */ {
/* 92:   */   VarsName(Id id, String title, final String text, String input)
/* 93:   */   {
/* 94:94 */     super(title, text);
/* 95:95 */     setInputText(input);
/* 96:96 */     textField.setInputVerifier(new InputVerifier()
/* 97:   */     {
/* 98:   */       public boolean verify(JComponent input)
/* 99:   */       {
/* :0::0 */         JTextField txt = (JTextField)input;
/* :1::1 */         String name = txt.getText();
/* :2::2 */         if (name.equals(text))
/* :3::3 */           return true;
/* :4::4 */         if (ProcessingContext.getActiveContext().getTsVariableManagers().contains(name)) {
/* :5::5 */           NotifyDescriptor nd = new NotifyDescriptor.Message(name + " is in use. You should choose another name!");
/* :6::6 */           DialogDisplayer.getDefault().notify(nd);
/* :7::7 */           return false;
/* :8:   */         }
/* :9::9 */         return true;
/* ;0:   */       }
/* ;1:   */     });
/* ;2:   */   }
/* ;3:   */ }
