/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.nodes.SingleNodeAction;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  6:   */ import ec.nbdemetra.ws.nodes.ItemWsNode;
/*  7:   */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  8:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  9:   */ import ec.tstoolkit.utilities.NameManager;
/* 10:   */ import org.openide.DialogDisplayer;
/* 11:   */ import org.openide.NotifyDescriptor;
/* 12:   */ import org.openide.NotifyDescriptor.Confirmation;
/* 13:   */ import org.openide.util.HelpCtx;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public final class DeleteAction
/* 30:   */   extends SingleNodeAction<ItemWsNode>
/* 31:   */ {
/* 32:   */   public static final String DELETE_MESSAGE = "Are you sure you want to delete this item?";
/* 33:   */   
/* 34:   */   public DeleteAction()
/* 35:   */   {
/* 36:36 */     super(ItemWsNode.class);
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected void performAction(ItemWsNode context)
/* 40:   */   {
/* 41:41 */     WorkspaceItem<TsVariables> cur = context.getItem();
/* 42:42 */     if ((cur != null) && (!cur.isReadOnly())) {
/* 43:43 */       NotifyDescriptor nd = new NotifyDescriptor.Confirmation("Are you sure you want to delete this item?", 2);
/* 44:44 */       if (DialogDisplayer.getDefault().notify(nd) != NotifyDescriptor.OK_OPTION) {
/* 45:45 */         return;
/* 46:   */       }
/* 47:47 */       context.getWorkspace().remove(cur);
/* 48:48 */       ProcessingContext.getActiveContext().getTsVariableManagers().remove(cur.getDisplayName());
/* 49:   */     }
/* 50:   */   }
/* 51:   */   
/* 52:   */   protected boolean enable(ItemWsNode context)
/* 53:   */   {
/* 54:54 */     WorkspaceItem<?> cur = context.getItem();
/* 55:55 */     return (cur != null) && (!cur.isReadOnly());
/* 56:   */   }
/* 57:   */   
/* 58:   */   public String getName()
/* 59:   */   {
/* 60:60 */     throw new Error("无法解析的编译问题：\n\t无法解析 Bundle\n");
/* 61:   */   }
/* 62:   */   
/* 63:   */   public HelpCtx getHelpCtx()
/* 64:   */   {
/* 65:65 */     return null;
/* 66:   */   }
/* 67:   */ }
