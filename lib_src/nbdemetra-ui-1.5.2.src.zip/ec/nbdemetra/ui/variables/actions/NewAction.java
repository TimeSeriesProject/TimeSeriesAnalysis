/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ws.IWorkspaceItemManager;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  6:   */ import ec.nbdemetra.ws.nodes.WsNode;
/*  7:   */ import ec.tstoolkit.utilities.Id;
/*  8:   */ import java.awt.event.ActionEvent;
/*  9:   */ import java.awt.event.ActionListener;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ public class NewAction
/* 24:   */   implements ActionListener
/* 25:   */ {
/* 26:   */   private final WsNode context;
/* 27:   */   
/* 28:   */   public NewAction(WsNode context)
/* 29:   */   {
/* 30:30 */     this.context = context;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void actionPerformed(ActionEvent ev)
/* 34:   */   {
/* 35:35 */     IWorkspaceItemManager mgr = WorkspaceFactory.getInstance().getManager((Id)context.lookup());
/* 36:36 */     if (mgr != null) {
/* 37:37 */       Workspace ws = context.getWorkspace();
/* 38:38 */       mgr.create(ws);
/* 39:   */     }
/* 40:   */   }
/* 41:   */ }
