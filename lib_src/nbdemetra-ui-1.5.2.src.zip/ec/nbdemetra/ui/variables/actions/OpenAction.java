/*  1:   */ package ec.nbdemetra.ui.variables.actions;
/*  2:   */ 
/*  3:   */ import ec.nbdemetra.ui.variables.VariablesDocumentManager;
/*  4:   */ import ec.nbdemetra.ws.Workspace;
/*  5:   */ import ec.nbdemetra.ws.WorkspaceFactory;
/*  6:   */ import ec.nbdemetra.ws.WorkspaceItem;
/*  7:   */ import ec.nbdemetra.ws.nodes.WsNode;
/*  8:   */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  9:   */ import ec.tstoolkit.utilities.Id;
/* 10:   */ import java.awt.event.ActionEvent;
/* 11:   */ import java.awt.event.ActionListener;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public class OpenAction
/* 26:   */   implements ActionListener
/* 27:   */ {
/* 28:   */   private final WsNode context;
/* 29:   */   
/* 30:   */   public OpenAction(WsNode context)
/* 31:   */   {
/* 32:32 */     this.context = context;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void actionPerformed(ActionEvent ev)
/* 36:   */   {
/* 37:37 */     WorkspaceItem<TsVariables> doc = context.getWorkspace().searchDocument((Id)context.lookup(), TsVariables.class);
/* 38:38 */     VariablesDocumentManager mgr = (VariablesDocumentManager)WorkspaceFactory.getInstance().getManager(VariablesDocumentManager.class);
/* 39:39 */     mgr.openDocument(doc);
/* 40:   */   }
/* 41:   */ }
