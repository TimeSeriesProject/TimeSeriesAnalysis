/*   1:    */ package ec.nbdemetra.ui.variables;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ws.AbstractWorkspaceItemManager;
/*   4:    */ import ec.nbdemetra.ws.IWorkspaceItemManager.ItemType;
/*   5:    */ import ec.nbdemetra.ws.IWorkspaceItemManager.Status;
/*   6:    */ import ec.nbdemetra.ws.Workspace;
/*   7:    */ import ec.nbdemetra.ws.WorkspaceFactory;
/*   8:    */ import ec.nbdemetra.ws.WorkspaceItem;
/*   9:    */ import ec.tstoolkit.algorithm.ProcessingContext;
/*  10:    */ import ec.tstoolkit.timeseries.regression.TsVariables;
/*  11:    */ import ec.tstoolkit.utilities.Id;
/*  12:    */ import ec.tstoolkit.utilities.LinearId;
/*  13:    */ import ec.tstoolkit.utilities.NameManager;
/*  14:    */ import java.awt.event.ActionEvent;
/*  15:    */ import java.util.Collections;
/*  16:    */ import java.util.List;
/*  17:    */ import javax.swing.AbstractAction;
/*  18:    */ import javax.swing.Action;
/*  19:    */ import javax.swing.Icon;
/*  20:    */ import org.openide.windows.TopComponent;
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public class VariablesDocumentManager
/*  31:    */   extends AbstractWorkspaceItemManager<TsVariables>
/*  32:    */ {
/*  33: 33 */   public static final LinearId ID = new LinearId("Utilities", "Variables");
/*  34:    */   public static final String PATH = "variables";
/*  35:    */   public static final String ITEMPATH = "variables.item";
/*  36:    */   public static final String CONTEXTPATH = "variables.context";
/*  37:    */   
/*  38:    */   public WorkspaceItem<TsVariables> create(Workspace ws)
/*  39:    */   {
/*  40: 40 */     WorkspaceItem<TsVariables> nvars = super.create(ws);
/*  41: 41 */     ProcessingContext.getActiveContext().getTsVariableManagers().set(nvars.getDisplayName(), (TsVariables)nvars.getElement());
/*  42: 42 */     return nvars;
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected String getItemPrefix()
/*  46:    */   {
/*  47: 47 */     return "Vars";
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Id getId()
/*  51:    */   {
/*  52: 52 */     return ID;
/*  53:    */   }
/*  54:    */   
/*  55:    */   protected TsVariables createNewObject()
/*  56:    */   {
/*  57: 57 */     return new TsVariables();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public IWorkspaceItemManager.ItemType getItemType()
/*  61:    */   {
/*  62: 62 */     return IWorkspaceItemManager.ItemType.Doc;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public String getActionsPath()
/*  66:    */   {
/*  67: 67 */     return "variables";
/*  68:    */   }
/*  69:    */   
/*  70:    */   public IWorkspaceItemManager.Status getStatus()
/*  71:    */   {
/*  72: 72 */     return IWorkspaceItemManager.Status.Experimental;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Action getPreferredItemAction(final Id child)
/*  76:    */   {
/*  77: 77 */     new AbstractAction()
/*  78:    */     {
/*  79:    */       public void actionPerformed(ActionEvent e) {
/*  80: 80 */         WorkspaceItem<TsVariables> doc = WorkspaceFactory.getInstance().getActiveWorkspace().searchDocument(child);
/*  81: 81 */         if (doc != null) {
/*  82: 82 */           openDocument(doc);
/*  83:    */         }
/*  84:    */       }
/*  85:    */     };
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void openDocument(WorkspaceItem<TsVariables> doc) {
/*  89: 89 */     if (doc.isOpen()) {
/*  90: 90 */       doc.getView().requestActive();
/*  91:    */     } else {
/*  92: 92 */       VariablesTopComponent view = new VariablesTopComponent(doc);
/*  93: 93 */       view.open();
/*  94: 94 */       view.requestActive();
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */   public List<WorkspaceItem<TsVariables>> getDefaultItems()
/* 105:    */   {
/* 106:106 */     return Collections.EMPTY_LIST;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Class<TsVariables> getItemClass()
/* 110:    */   {
/* 111:111 */     return TsVariables.class;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Icon getManagerIcon()
/* 115:    */   {
/* 116:116 */     return null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public Icon getItemIcon(WorkspaceItem<TsVariables> doc)
/* 120:    */   {
/* 121:121 */     return null;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static WorkspaceItem<TsVariables> systemItem(String name, TsVariables p) {
/* 125:125 */     return WorkspaceItem.system(ID, name, p);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public boolean isAutoLoad()
/* 129:    */   {
/* 130:130 */     return true;
/* 131:    */   }
/* 132:    */ }
