/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Function;
/*  4:   */ import ec.nbdemetra.ui.ns.INamedService;
/*  5:   */ import ec.nbdemetra.ui.ns.NamedServiceNode;
/*  6:   */ import ec.tss.tsproviders.utils.IFormatter;
/*  7:   */ import ec.tss.tsproviders.utils.IParser;
/*  8:   */ import ec.util.chart.ColorScheme;
/*  9:   */ import org.openide.nodes.Node;
/* 10:   */ import org.openide.util.Lookup;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ public final class Jdk6Functions
/* 24:   */ {
/* 25:   */   public static Function<ColorScheme, String> colorSchemeName()
/* 26:   */   {
/* 27:27 */     return COLOR_SCHEME_NAME;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static Function<ColorScheme, String> colorSchemeDisplayName() {
/* 31:31 */     return COLOR_SCHEME_DISPLAY_NAME;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static Function<INamedService, String> namedServiceName() {
/* 35:35 */     return NAMED_SERVICE_NAME;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static Function<INamedService, String> namedServiceDisplayName() {
/* 39:39 */     return NAMED_SERVICE_DISPLAY_NAME;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static Function<INamedService, NamedServiceNode> namedServiceToNode() {
/* 43:43 */     return NAMED_SERVICE_TO_NODE;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static <X> Function<X, CharSequence> forFormatter(IFormatter<X> formatter) {
/* 47:47 */     new Function()
/* 48:   */     {
/* 49:   */       public CharSequence apply(X input) {
/* 50:50 */         return format(input);
/* 51:   */       }
/* 52:   */     };
/* 53:   */   }
/* 54:   */   
/* 55:   */   public static <X> Function<CharSequence, X> forParser(IParser<X> parser) {
/* 56:56 */     new Function()
/* 57:   */     {
/* 58:   */       public X apply(CharSequence input) {
/* 59:59 */         return parse(input);
/* 60:   */       }
/* 61:   */     };
/* 62:   */   }
/* 63:   */   
/* 64:   */   public static <X> Function<Node, X> lookupNode(Class<X> clazz) {
/* 65:65 */     new Function()
/* 66:   */     {
/* 67:   */       public X apply(Node input) {
/* 68:68 */         return input.getLookup().lookup(Jdk6Functions.this);
/* 69:   */       }
/* 70:   */     };
/* 71:   */   }
/* 72:   */   
/* 73:73 */   private static final Function<ColorScheme, String> COLOR_SCHEME_NAME = new Function()
/* 74:   */   {
/* 75:   */     public String apply(ColorScheme input) {
/* 76:76 */       return input.getName();
/* 77:   */     }
/* 78:   */   };
/* 79:79 */   private static final Function<ColorScheme, String> COLOR_SCHEME_DISPLAY_NAME = new Function()
/* 80:   */   {
/* 81:   */     public String apply(ColorScheme input) {
/* 82:82 */       return input.getDisplayName();
/* 83:   */     }
/* 84:   */   };
/* 85:85 */   private static final Function<INamedService, String> NAMED_SERVICE_NAME = new Function()
/* 86:   */   {
/* 87:   */     public String apply(INamedService input) {
/* 88:88 */       return input.getName();
/* 89:   */     }
/* 90:   */   };
/* 91:91 */   private static final Function<INamedService, String> NAMED_SERVICE_DISPLAY_NAME = new Function()
/* 92:   */   {
/* 93:   */     public String apply(INamedService input) {
/* 94:94 */       return input.getDisplayName();
/* 95:   */     }
/* 96:   */   };
/* 97:97 */   private static final Function<INamedService, NamedServiceNode> NAMED_SERVICE_TO_NODE = new Function()
/* 98:   */   {
/* 99:   */     public NamedServiceNode apply(INamedService input) {
/* :0::0 */       return new NamedServiceNode(input);
/* :1:   */     }
/* :2:   */   };
/* :3:   */ }
