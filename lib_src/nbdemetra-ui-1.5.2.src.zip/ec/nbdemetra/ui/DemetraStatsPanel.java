/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ws.ui.SpecSelectionComponent;
/*   4:    */ import ec.satoolkit.ISaSpecification;
/*   5:    */ import ec.satoolkit.tramoseats.TramoSeatsSpecification;
/*   6:    */ import ec.tss.sa.EstimationPolicyType;
/*   7:    */ import java.awt.Image;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import javax.swing.BorderFactory;
/*  11:    */ import javax.swing.DefaultComboBoxModel;
/*  12:    */ import javax.swing.GroupLayout;
/*  13:    */ import javax.swing.GroupLayout.Alignment;
/*  14:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  15:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  16:    */ import javax.swing.JButton;
/*  17:    */ import javax.swing.JComboBox;
/*  18:    */ import javax.swing.JLabel;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.JPopupMenu;
/*  21:    */ import javax.swing.JSpinner;
/*  22:    */ import javax.swing.LayoutStyle.ComponentPlacement;
/*  23:    */ import javax.swing.SpinnerNumberModel;
/*  24:    */ import org.openide.awt.DropDownButtonFactory;
/*  25:    */ import org.openide.awt.Mnemonics;
/*  26:    */ import org.openide.util.ImageUtilities;
/*  27:    */ import org.openide.util.NbBundle;
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ final class DemetraStatsPanel
/*  35:    */   extends JPanel
/*  36:    */ {
/*  37:    */   private final DemetraStatsOptionsPanelController controller;
/*  38: 38 */   private JPopupMenu specPopup = new JPopupMenu();
/*  39: 39 */   private SpecSelectionComponent specComponent = new SpecSelectionComponent(true);
/*  40:    */   
/*  41: 41 */   private EstimationPolicyType[] types = { EstimationPolicyType.Complete, 
/*  42: 42 */     EstimationPolicyType.FreeParameters, 
/*  43: 43 */     EstimationPolicyType.None };
/*  44:    */   private JLabel defaultSpecLabel;
/*  45:    */   private JLabel estimationLabel;
/*  46:    */   private JComboBox estimationPolicyComboBox;
/*  47:    */   
/*  48:    */   DemetraStatsPanel(DemetraStatsOptionsPanelController controller) {
/*  49: 49 */     this.controller = controller;
/*  50: 50 */     initComponents();
/*  51: 51 */     initSpecButton();
/*  52:    */   }
/*  53:    */   
/*  54:    */   void load() {
/*  55: 55 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  56: 56 */     spectralLastYears.setValue(demetraUI.getSpectralLastYears());
/*  57:    */     
/*  58: 58 */     estimationPolicyComboBox.setModel(new DefaultComboBoxModel(types));
/*  59: 59 */     estimationPolicyComboBox.setSelectedItem(demetraUI.getEstimationPolicyType());
/*  60:    */     
/*  61: 61 */     stabilityLength.setValue(demetraUI.getStabilityLength());
/*  62:    */     
/*  63: 63 */     specComponent.setSpecification(demetraUI.getDefaultSASpec());
/*  64: 64 */     selectedSpecLabel.setText(demetraUI.getDefaultSASpec().toLongString());
/*  65:    */   }
/*  66:    */   
/*  67:    */   void store() {
/*  68: 68 */     DemetraUI demetraUI = DemetraUI.getDefault();
/*  69: 69 */     demetraUI.setSpectralLastYears((Integer)spectralLastYears.getValue());
/*  70: 70 */     demetraUI.setEstimationPolicyType((EstimationPolicyType)estimationPolicyComboBox.getSelectedItem());
/*  71: 71 */     demetraUI.setStabilityLength((Integer)stabilityLength.getValue());
/*  72:    */     
/*  73: 73 */     if ((specComponent.getSpecification() instanceof TramoSeatsSpecification)) {
/*  74: 74 */       demetraUI.setDefaultSASpec("tramoseats." + specComponent.getSpecification().toString());
/*  75:    */     } else {
/*  76: 76 */       demetraUI.setDefaultSASpec("x13." + specComponent.getSpecification().toString());
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */ 
/*  81:    */   boolean valid()
/*  82:    */   {
/*  83: 83 */     return true;
/*  84:    */   }
/*  85:    */   
/*  86:    */ 
/*  87:    */   private JPanel lastYearsPanel;
/*  88:    */   
/*  89:    */   private JPanel revisionHistoryPanel;
/*  90:    */   
/*  91:    */   private JPanel saPanel;
/*  92:    */   
/*  93:    */   private void initComponents()
/*  94:    */   {
/*  95: 95 */     lastYearsPanel = new JPanel();
/*  96: 96 */     spectralLastYears = new JSpinner();
/*  97: 97 */     spectralLabel = new JLabel();
/*  98: 98 */     stabilityLabel = new JLabel();
/*  99: 99 */     stabilityLength = new JSpinner();
/* 100:100 */     saPanel = new JPanel();
/* 101:101 */     defaultSpecLabel = new JLabel();
/* 102:102 */     specButton = DropDownButtonFactory.createDropDownButton(ImageUtilities.loadImageIcon("ec/nbdemetra/sa/blog_16x16.png", false), specPopup);
/* 103:103 */     selectedSpecLabel = new JLabel();
/* 104:104 */     revisionHistoryPanel = new JPanel();
/* 105:105 */     estimationLabel = new JLabel();
/* 106:106 */     estimationPolicyComboBox = new JComboBox();
/* 107:    */     
/* 108:108 */     lastYearsPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.lastYearsPanel.border.title")));
/* 109:    */     
/* 110:110 */     spectralLastYears.setModel(new SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
/* 111:    */     
/* 112:112 */     Mnemonics.setLocalizedText(spectralLabel, NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.spectralLabel.text"));
/* 113:    */     
/* 114:114 */     Mnemonics.setLocalizedText(stabilityLabel, NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.stabilityLabel.text"));
/* 115:    */     
/* 116:116 */     stabilityLength.setModel(new SpinnerNumberModel(Integer.valueOf(8), Integer.valueOf(1), null, Integer.valueOf(1)));
/* 117:    */     
/* 118:118 */     GroupLayout lastYearsPanelLayout = new GroupLayout(lastYearsPanel);
/* 119:119 */     lastYearsPanel.setLayout(lastYearsPanelLayout);
/* 120:120 */     lastYearsPanelLayout.setHorizontalGroup(
/* 121:121 */       lastYearsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 122:122 */       .addGroup(lastYearsPanelLayout.createSequentialGroup()
/* 123:123 */       .addContainerGap()
/* 124:124 */       .addGroup(lastYearsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 125:125 */       .addComponent(stabilityLabel, -1, -1, 32767)
/* 126:126 */       .addComponent(spectralLabel, -1, -1, 32767))
/* 127:127 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 128:128 */       .addGroup(lastYearsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 129:129 */       .addComponent(spectralLastYears, -2, 48, -2)
/* 130:130 */       .addComponent(stabilityLength, GroupLayout.Alignment.TRAILING, -2, 48, -2))
/* 131:131 */       .addContainerGap(-1, 32767)));
/* 132:    */     
/* 133:133 */     lastYearsPanelLayout.setVerticalGroup(
/* 134:134 */       lastYearsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 135:135 */       .addGroup(lastYearsPanelLayout.createSequentialGroup()
/* 136:136 */       .addGroup(lastYearsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 137:137 */       .addComponent(spectralLabel, -1, 23, 32767)
/* 138:138 */       .addGroup(lastYearsPanelLayout.createSequentialGroup()
/* 139:139 */       .addComponent(spectralLastYears, -2, -1, -2)
/* 140:140 */       .addGap(1, 1, 1)))
/* 141:141 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 142:142 */       .addGroup(lastYearsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 143:143 */       .addComponent(stabilityLabel, -1, 23, 32767)
/* 144:144 */       .addComponent(stabilityLength, -2, -1, -2))));
/* 145:    */     
/* 146:    */ 
/* 147:147 */     saPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.saPanel.border.title")));
/* 148:    */     
/* 149:149 */     Mnemonics.setLocalizedText(defaultSpecLabel, NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.defaultSpecLabel.text"));
/* 150:    */     
/* 151:151 */     Mnemonics.setLocalizedText(specButton, NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.specButton.text"));
/* 152:    */     
/* 153:153 */     Mnemonics.setLocalizedText(selectedSpecLabel, NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.selectedSpecLabel.text"));
/* 154:    */     
/* 155:155 */     GroupLayout saPanelLayout = new GroupLayout(saPanel);
/* 156:156 */     saPanel.setLayout(saPanelLayout);
/* 157:157 */     saPanelLayout.setHorizontalGroup(
/* 158:158 */       saPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 159:159 */       .addGroup(saPanelLayout.createSequentialGroup()
/* 160:160 */       .addContainerGap()
/* 161:161 */       .addComponent(defaultSpecLabel)
/* 162:162 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 163:163 */       .addComponent(specButton)
/* 164:164 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 165:165 */       .addComponent(selectedSpecLabel, -2, 76, -2)
/* 166:166 */       .addContainerGap(-1, 32767)));
/* 167:    */     
/* 168:168 */     saPanelLayout.setVerticalGroup(
/* 169:169 */       saPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 170:170 */       .addGroup(saPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 171:171 */       .addComponent(defaultSpecLabel, -2, 23, -2)
/* 172:172 */       .addComponent(specButton)
/* 173:173 */       .addComponent(selectedSpecLabel)));
/* 174:    */     
/* 175:    */ 
/* 176:176 */     revisionHistoryPanel.setBorder(BorderFactory.createTitledBorder(NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.revisionHistoryPanel.border.title")));
/* 177:    */     
/* 178:178 */     Mnemonics.setLocalizedText(estimationLabel, NbBundle.getMessage(DemetraStatsPanel.class, "DemetraStatsPanel.estimationLabel.text"));
/* 179:    */     
/* 180:180 */     GroupLayout revisionHistoryPanelLayout = new GroupLayout(revisionHistoryPanel);
/* 181:181 */     revisionHistoryPanel.setLayout(revisionHistoryPanelLayout);
/* 182:182 */     revisionHistoryPanelLayout.setHorizontalGroup(
/* 183:183 */       revisionHistoryPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 184:184 */       .addGroup(revisionHistoryPanelLayout.createSequentialGroup()
/* 185:185 */       .addContainerGap()
/* 186:186 */       .addComponent(estimationLabel)
/* 187:187 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 188:188 */       .addComponent(estimationPolicyComboBox, -2, 108, -2)
/* 189:189 */       .addContainerGap(119, 32767)));
/* 190:    */     
/* 191:191 */     revisionHistoryPanelLayout.setVerticalGroup(
/* 192:192 */       revisionHistoryPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 193:193 */       .addGroup(revisionHistoryPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 194:194 */       .addComponent(estimationLabel, -1, 23, 32767)
/* 195:195 */       .addComponent(estimationPolicyComboBox, -2, -1, -2)));
/* 196:    */     
/* 197:    */ 
/* 198:198 */     GroupLayout layout = new GroupLayout(this);
/* 199:199 */     setLayout(layout);
/* 200:200 */     layout.setHorizontalGroup(
/* 201:201 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 202:202 */       .addComponent(lastYearsPanel, -1, -1, 32767)
/* 203:203 */       .addComponent(saPanel, -1, -1, 32767)
/* 204:204 */       .addComponent(revisionHistoryPanel, -1, -1, 32767));
/* 205:    */     
/* 206:206 */     layout.setVerticalGroup(
/* 207:207 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 208:208 */       .addGroup(layout.createSequentialGroup()
/* 209:209 */       .addComponent(lastYearsPanel, -2, -1, -2)
/* 210:210 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 211:211 */       .addComponent(saPanel, -2, -1, -2)
/* 212:212 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 213:213 */       .addComponent(revisionHistoryPanel, -2, -1, -2)
/* 214:214 */       .addGap(0, 26, 32767)));
/* 215:    */   }
/* 216:    */   
/* 217:    */ 
/* 218:    */ 
/* 219:    */   private JLabel selectedSpecLabel;
/* 220:    */   
/* 221:    */ 
/* 222:    */   private JButton specButton;
/* 223:    */   
/* 224:    */ 
/* 225:    */   private JLabel spectralLabel;
/* 226:    */   
/* 227:    */   private JSpinner spectralLastYears;
/* 228:    */   
/* 229:    */   private JLabel stabilityLabel;
/* 230:    */   
/* 231:    */   private JSpinner stabilityLength;
/* 232:    */   
/* 233:    */   private void initSpecButton()
/* 234:    */   {
/* 235:235 */     specPopup.add(specComponent);
/* 236:236 */     specComponent.addPropertyChangeListener(new PropertyChangeListener()
/* 237:    */     {
/* 238:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 239:239 */         String p = evt.getPropertyName();
/* 240:240 */         if ((p.equals("specification")) && (evt.getNewValue() != null)) {
/* 241:241 */           selectedSpecLabel.setText(((ISaSpecification)evt.getNewValue()).toLongString());
/* 242:242 */         } else if ((p.equals("icon")) && (evt.getNewValue() != null)) {
/* 243:243 */           specButton.setIcon(ImageUtilities.image2Icon((Image)evt.getNewValue()));
/* 244:    */         }
/* 245:    */       }
/* 246:    */     });
/* 247:    */   }
/* 248:    */ }
