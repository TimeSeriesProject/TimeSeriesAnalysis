/*   1:    */ package ec.nbdemetra.ui;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.collect.FluentIterable;
/*   5:    */ import com.google.common.collect.ImmutableMultimap;
/*   6:    */ import com.google.common.collect.Iterables;
/*   7:    */ import com.google.common.collect.Multimaps;
/*   8:    */ import ec.nbdemetra.ui.nodes.AbstractNodeBuilder;
/*   9:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  10:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  11:    */ import ec.tstoolkit.utilities.Id;
/*  12:    */ import ec.ui.view.tsprocessing.ProcDocumentItemFactory;
/*  13:    */ import java.awt.Image;
/*  14:    */ import java.awt.event.ItemEvent;
/*  15:    */ import javax.swing.DefaultComboBoxModel;
/*  16:    */ import javax.swing.GroupLayout;
/*  17:    */ import javax.swing.GroupLayout.Alignment;
/*  18:    */ import javax.swing.GroupLayout.ParallelGroup;
/*  19:    */ import javax.swing.GroupLayout.SequentialGroup;
/*  20:    */ import javax.swing.JComboBox;
/*  21:    */ import org.openide.explorer.ExplorerManager;
/*  22:    */ import org.openide.explorer.view.OutlineView;
/*  23:    */ import org.openide.nodes.AbstractNode;
/*  24:    */ import org.openide.nodes.Node;
/*  25:    */ import org.openide.nodes.Sheet;
/*  26:    */ import org.openide.util.Lookup;
/*  27:    */ 
/*  28:    */ final class ProcDocumentItemsPanel extends javax.swing.JPanel implements org.openide.explorer.ExplorerManager.Provider
/*  29:    */ {
/*  30:    */   private final ProcDocumentItemsOptionsPanelController controller;
/*  31:    */   final ExplorerManager em;
/*  32:    */   private JComboBox jComboBox1;
/*  33:    */   private OutlineView outlineView1;
/*  34:    */   
/*  35:    */   ProcDocumentItemsPanel(ProcDocumentItemsOptionsPanelController controller)
/*  36:    */   {
/*  37: 37 */     this.controller = controller;
/*  38: 38 */     em = new ExplorerManager();
/*  39: 39 */     initComponents();
/*  40:    */     
/*  41: 41 */     outlineView1.getOutline().setRootVisible(false);
/*  42: 42 */     jComboBox1.setModel(new DefaultComboBoxModel(NodeStrategies.values()));
/*  43: 43 */     jComboBox1.setSelectedIndex(0);
/*  44: 44 */     jComboBox1.addItemListener(new java.awt.event.ItemListener()
/*  45:    */     {
/*  46:    */       public void itemStateChanged(ItemEvent e) {
/*  47: 47 */         load();
/*  48:    */       }
/*  49:    */     });
/*  50:    */   }
/*  51:    */   
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */   private void initComponents()
/*  59:    */   {
/*  60: 60 */     outlineView1 = new OutlineView();
/*  61: 61 */     jComboBox1 = new JComboBox();
/*  62:    */     
/*  63: 63 */     jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
/*  64:    */     
/*  65: 65 */     GroupLayout layout = new GroupLayout(this);
/*  66: 66 */     setLayout(layout);
/*  67: 67 */     layout.setHorizontalGroup(
/*  68: 68 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  69: 69 */       .addComponent(outlineView1, -1, 458, 32767)
/*  70: 70 */       .addComponent(jComboBox1, 0, -1, 32767));
/*  71:    */     
/*  72: 72 */     layout.setVerticalGroup(
/*  73: 73 */       layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/*  74: 74 */       .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/*  75: 75 */       .addComponent(jComboBox1, -2, -1, -2)
/*  76: 76 */       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
/*  77: 77 */       .addComponent(outlineView1, -1, 374, 32767)));
/*  78:    */   }
/*  79:    */   
/*  80:    */ 
/*  81:    */   public ExplorerManager getExplorerManager()
/*  82:    */   {
/*  83: 83 */     return em;
/*  84:    */   }
/*  85:    */   
/*  86:    */   void load() {
/*  87: 87 */     Iterable<? extends ProcDocumentItemFactory> all = Lookup.getDefault().lookupAll(ProcDocumentItemFactory.class);
/*  88: 88 */     NodeStrategies strategies = (NodeStrategies)jComboBox1.getSelectedItem();
/*  89: 89 */     em.setRootContext(strategies.getRoot(all));
/*  90: 90 */     outlineView1.setPropertyColumns(strategies.getPropertyColumns());
/*  91:    */   }
/*  92:    */   
/*  93:    */   void store() {}
/*  94:    */   
/*  95:    */   boolean valid()
/*  96:    */   {
/*  97: 97 */     return true;
/*  98:    */   }
/*  99:    */   
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */   static abstract enum NodeStrategies
/* 105:    */   {
/* 106:106 */     FLAT_LAYOUT, 
/* 107:    */     
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:120 */     GROUP_BY_DOCUMENT_TYPE, 
/* 121:    */     
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:138 */     GROUP_BY_DOCUMENT_TYPE_AND_ID;
/* 139:    */     
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */     public abstract Node getRoot(Iterable<? extends ProcDocumentItemFactory> paramIterable);
/* 147:    */     
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */     public abstract String[] getPropertyColumns();
/* 154:    */   }
/* 155:    */   
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */   static class ProcDocumentItemFactoryNode
/* 162:    */     extends AbstractNode
/* 163:    */   {
/* 164:    */     public ProcDocumentItemFactoryNode(ProcDocumentItemFactory factory)
/* 165:    */     {
/* 166:166 */       super(org.openide.util.lookup.Lookups.singleton(factory));
/* 167:167 */       setName(factory.getItemId().toString());
/* 168:    */     }
/* 169:    */     
/* 170:    */ 
/* 171:    */     public Image getIcon(int type)
/* 172:    */     {
/* 173:173 */       ProcDocumentItemFactory factory = (ProcDocumentItemFactory)getLookup().lookup(ProcDocumentItemFactory.class);
/* 174:174 */       javax.swing.Icon result = factory.getIcon();
/* 175:175 */       return org.openide.util.ImageUtilities.icon2Image(result != null ? result : new ec.nbdemetra.ui.nodes.IdNodes.IdIcon(factory.getItemId()));
/* 176:    */     }
/* 177:    */     
/* 178:    */     public Image getOpenedIcon(int type)
/* 179:    */     {
/* 180:180 */       return getIcon(type);
/* 181:    */     }
/* 182:    */     
/* 183:    */     protected Sheet createSheet()
/* 184:    */     {
/* 185:185 */       ProcDocumentItemFactory factory = (ProcDocumentItemFactory)getLookup().lookup(ProcDocumentItemFactory.class);
/* 186:186 */       Sheet result = super.createSheet();
/* 187:187 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 188:    */       
/* 189:189 */       ((NodePropertySetBuilder.DefaultStep)b.with(Class.class).select(factory, "getDocumentType", null))
/* 190:190 */         .name("DocumentType")
/* 191:191 */         .display("Document Type")
/* 192:192 */         .add();
/* 193:193 */       result.put(b.build());
/* 194:194 */       return result;
/* 195:    */     }
/* 196:    */   }
/* 197:    */   
/* 198:198 */   static final Function<ProcDocumentItemFactory, Class<?>> TO_DOCUMENT_TYPE = new Function()
/* 199:    */   {
/* 200:    */     public Class<?> apply(ProcDocumentItemFactory input) {
/* 201:201 */       return input.getDocumentType();
/* 202:    */     }
/* 203:    */   };
/* 204:204 */   static final Function<ProcDocumentItemFactory, Id> TO_ITEM_ID = new Function()
/* 205:    */   {
/* 206:    */     public Id apply(ProcDocumentItemFactory input) {
/* 207:207 */       return input.getItemId();
/* 208:    */     }
/* 209:    */   };
/* 210:210 */   static final Function<ProcDocumentItemFactory, Node> TO_NODE = new Function()
/* 211:    */   {
/* 212:    */     public Node apply(ProcDocumentItemFactory input) {
/* 213:213 */       return new ProcDocumentItemsPanel.ProcDocumentItemFactoryNode(input);
/* 214:    */     }
/* 215:    */   };
/* 216:    */ }
