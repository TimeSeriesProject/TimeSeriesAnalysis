/*  1:   */ package ec.nbdemetra.ui;
/*  2:   */ 
/*  3:   */ import ec.util.various.swing.ModernUI;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Toolkit;
/*  6:   */ import javax.annotation.Nonnull;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ import javax.swing.JScrollPane;
/*  9:   */ import javax.swing.JSplitPane;
/* 10:   */ import javax.swing.JToolBar;
/* 11:   */ import javax.swing.LookAndFeel;
/* 12:   */ import javax.swing.UIManager;
/* 13:   */ import javax.swing.border.Border;
/* 14:   */ import org.openide.windows.TopComponent;
/* 15:   */ import org.openide.windows.TopComponent.Registry;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ public final class NbComponents
/* 37:   */ {
/* 38:38 */   private static final boolean AQUA = "Aqua".equals(UIManager.getLookAndFeel().getID());
/* 39:   */   
/* 40:   */   public static boolean isXPTheme() {
/* 41:41 */     Boolean isXP = (Boolean)Toolkit.getDefaultToolkit().getDesktopProperty("win.xpstyle.themeActive");
/* 42:42 */     return isXP == null ? false : isXP.booleanValue();
/* 43:   */   }
/* 44:   */   
/* 45:   */   @Nonnull
/* 46:   */   public static JToolBar newInnerToolbar() {
/* 47:47 */     JToolBar result = new JToolBar();
/* 48:48 */     Border b = (Border)UIManager.get("Nb.Editor.Toolbar.border");
/* 49:49 */     result.setBorder(b);
/* 50:50 */     result.setFloatable(false);
/* 51:51 */     result.setFocusable(true);
/* 52:52 */     if (("Windows".equals(UIManager.getLookAndFeel().getID())) && (!isXPTheme())) {
/* 53:53 */       result.setRollover(true);
/* 54:54 */     } else if (AQUA) {
/* 55:55 */       result.setBackground(UIManager.getColor("NbExplorerView.background"));
/* 56:   */     }
/* 57:57 */     return result;
/* 58:   */   }
/* 59:   */   
/* 60:   */   @Nonnull
/* 61:   */   public static JScrollPane newJScrollPane() {
/* 62:62 */     return ModernUI.withEmptyBorders(new JScrollPane());
/* 63:   */   }
/* 64:   */   
/* 65:   */   @Nonnull
/* 66:   */   public static JScrollPane newJScrollPane(@Nonnull Component view) {
/* 67:67 */     return ModernUI.withEmptyBorders(new JScrollPane(view));
/* 68:   */   }
/* 69:   */   
/* 70:   */   @Nonnull
/* 71:   */   public static JSplitPane newJSplitPane(int orientation) {
/* 72:72 */     return ModernUI.withEmptyBorders(new JSplitPane(orientation));
/* 73:   */   }
/* 74:   */   
/* 75:   */   @Nonnull
/* 76:   */   public static JSplitPane newJSplitPane(int orientation, @Nonnull Component left, @Nonnull Component right) {
/* 77:77 */     return ModernUI.withEmptyBorders(new JSplitPane(orientation, left, right));
/* 78:   */   }
/* 79:   */   
/* 80:   */   @Nonnull
/* 81:   */   public static JSplitPane newJSplitPane(int orientation, boolean continuousLayout, @Nonnull Component left, @Nonnull Component right) {
/* 82:82 */     return ModernUI.withEmptyBorders(new JSplitPane(orientation, continuousLayout, left, right));
/* 83:   */   }
/* 84:   */   
/* 85:   */   @Nullable
/* 86:   */   public static <T extends TopComponent> T findTopComponentByNameAndClass(@Nonnull String name, @Nonnull Class<T> clazz) {
/* 87:87 */     for (TopComponent o : TopComponent.getRegistry().getOpened()) {
/* 88:88 */       if ((o.getName().equals(name)) && (clazz.isInstance(o))) {
/* 89:89 */         return o;
/* 90:   */       }
/* 91:   */     }
/* 92:92 */     return null;
/* 93:   */   }
/* 94:   */   
/* 95:   */   @Nullable
/* 96:   */   public static TopComponent findTopComponentByName(@Nonnull String name) {
/* 97:97 */     return findTopComponentByNameAndClass(name, TopComponent.class);
/* 98:   */   }
/* 99:   */ }
