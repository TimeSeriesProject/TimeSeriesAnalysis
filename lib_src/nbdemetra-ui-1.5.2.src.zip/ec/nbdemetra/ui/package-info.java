package ec.nbdemetra.ui;

abstract interface package-info {}
