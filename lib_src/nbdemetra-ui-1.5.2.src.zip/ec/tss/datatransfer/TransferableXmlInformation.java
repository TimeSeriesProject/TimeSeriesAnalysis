/*   1:    */ package ec.tss.datatransfer;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Throwables;
/*   4:    */ import ec.tss.xml.information.XmlInformationSet;
/*   5:    */ import ec.tstoolkit.information.InformationSet;
/*   6:    */ import ec.tstoolkit.information.InformationSetSerializable;
/*   7:    */ import java.awt.datatransfer.DataFlavor;
/*   8:    */ import java.awt.datatransfer.Transferable;
/*   9:    */ import java.awt.datatransfer.UnsupportedFlavorException;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.io.StringReader;
/*  12:    */ import java.io.StringWriter;
/*  13:    */ import javax.xml.bind.JAXBContext;
/*  14:    */ import javax.xml.bind.JAXBException;
/*  15:    */ import javax.xml.bind.Marshaller;
/*  16:    */ import javax.xml.bind.Unmarshaller;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ public class TransferableXmlInformation<T extends InformationSetSerializable>
/*  23:    */   implements Transferable
/*  24:    */ {
/*  25:    */   private final T obj_;
/*  26:    */   private final DataFlavor local_;
/*  27:    */   private final String type_;
/*  28:    */   private final String version_;
/*  29:    */   private static JAXBContext context;
/*  30:    */   
/*  31:    */   static
/*  32:    */   {
/*  33:    */     try
/*  34:    */     {
/*  35: 35 */       context = JAXBContext.newInstance(new Class[] { XmlInformationSet.class });
/*  36:    */     } catch (JAXBException ex) {
/*  37: 37 */       context = null;
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <T extends InformationSetSerializable> T read(Transferable dataobj, Class<T> tclass, String type, String version) {
/*  42:    */     try {
/*  43: 43 */       DataFlavor local = newLocalObjectDataFlavor(tclass);
/*  44: 44 */       if (dataobj.isDataFlavorSupported(local)) {
/*  45: 45 */         return (InformationSetSerializable)dataobj.getTransferData(local);
/*  46:    */       }
/*  47: 47 */       DataFlavor xmlflavor = BasicFormatter.DEMETRA;
/*  48: 48 */       if (!dataobj.isDataFlavorSupported(xmlflavor)) {
/*  49: 49 */         return null;
/*  50:    */       }
/*  51: 51 */       String str = (String)dataobj.getTransferData(BasicFormatter.DEMETRA);
/*  52: 52 */       StringReader reader = new StringReader(str);
/*  53:    */       
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58: 58 */       Unmarshaller unmarshaller = context.createUnmarshaller();
/*  59: 59 */       XmlInformationSet x = (XmlInformationSet)unmarshaller.unmarshal(reader);
/*  60: 60 */       if (x == null) {
/*  61: 61 */         return null;
/*  62:    */       }
/*  63: 63 */       InformationSet info = x.create();
/*  64: 64 */       if ((type != null) && (!info.isContent(type, version))) {
/*  65: 65 */         return null;
/*  66:    */       }
/*  67: 67 */       T rslt = (InformationSetSerializable)tclass.newInstance();
/*  68: 68 */       if (rslt.read(info)) {
/*  69: 69 */         return rslt;
/*  70:    */       }
/*  71: 71 */       return null;
/*  72:    */     }
/*  73:    */     catch (UnsupportedFlavorException|IOException|JAXBException|InstantiationException|IllegalAccessException ex) {}
/*  74: 74 */     return null;
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */   public TransferableXmlInformation(T obj, Class<T> tclass, String type, String version)
/*  79:    */   {
/*  80: 80 */     obj_ = obj;
/*  81: 81 */     type_ = type;
/*  82: 82 */     version_ = version;
/*  83: 83 */     local_ = newLocalObjectDataFlavor(tclass);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public DataFlavor[] getTransferDataFlavors()
/*  87:    */   {
/*  88: 88 */     return new DataFlavor[] { BasicFormatter.DEMETRA, local_ };
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean isDataFlavorSupported(DataFlavor flavor)
/*  92:    */   {
/*  93: 93 */     return (flavor.equals(BasicFormatter.DEMETRA)) || (flavor.equals(local_));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
/*  97:    */   {
/*  98: 98 */     if (obj_ == null) {
/*  99: 99 */       return null;
/* 100:    */     }
/* 101:101 */     if (flavor.equals(local_)) {
/* 102:102 */       return obj_;
/* 103:    */     }
/* 104:104 */     if (!flavor.equals(BasicFormatter.DEMETRA)) {
/* 105:105 */       return null;
/* 106:    */     }
/* 107:107 */     StringWriter writer = new StringWriter();
/* 108:    */     try {
/* 109:109 */       InformationSet info = obj_.write(false);
/* 110:110 */       if (info == null) {
/* 111:111 */         return null;
/* 112:    */       }
/* 113:113 */       info.setContent(type_, version_);
/* 114:114 */       Marshaller marshaller = context.createMarshaller();
/* 115:115 */       marshaller.setProperty("jaxb.formatted.output", Boolean.valueOf(true));
/* 116:116 */       XmlInformationSet xml = new XmlInformationSet();
/* 117:117 */       xml.copy(info);
/* 118:118 */       marshaller.marshal(xml, writer);
/* 119:119 */       writer.flush();
/* 120:120 */       return writer.toString();
/* 121:    */     } catch (Exception ex) {}
/* 122:122 */     return null;
/* 123:    */   }
/* 124:    */   
/* 125:    */   static DataFlavor newLocalObjectDataFlavor(Class<?> clazz)
/* 126:    */   {
/* 127:    */     try {
/* 128:128 */       return new DataFlavor("application/x-java-jvm-local-objectref;class=" + clazz.getName());
/* 129:    */     } catch (ClassNotFoundException ex) {
/* 130:130 */       throw Throwables.propagate(ex);
/* 131:    */     }
/* 132:    */   }
/* 133:    */ }
