package ec.tss.datatransfer;

import ec.nbdemetra.ui.ns.INamedService;
import ec.tss.TsCollection;
import java.awt.datatransfer.DataFlavor;
import java.io.IOException;

@Deprecated
public abstract interface ITsCollectionFormatter
  extends INamedService
{
  public abstract DataFlavor getDataFlavor();
  
  public abstract boolean canExportTransferData(TsCollection paramTsCollection);
  
  public abstract Object toTransferData(TsCollection paramTsCollection)
    throws IOException;
  
  public abstract boolean canImportTransferData(Object paramObject);
  
  public abstract TsCollection fromTransferData(Object paramObject)
    throws IOException, ClassCastException;
}
