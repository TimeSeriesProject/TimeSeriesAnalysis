/*  1:   */ package ec.tss.datatransfer;
/*  2:   */ 
/*  3:   */ import java.awt.datatransfer.DataFlavor;
/*  4:   */ import java.awt.datatransfer.SystemFlavorMap;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ class BasicFormatter
/* 17:   */ {
/* 18:18 */   static final DataFlavor TEXT = new DataFlavor(
/* 19:19 */     "text/plain;charset=utf-16;class=java.lang.String", "Text");
/* 20:   */   
/* 21:   */   static final DataFlavor DEMETRA;
/* 22:   */   
/* 23:   */ 
/* 24:   */   static
/* 25:   */   {
/* 26:26 */     DataFlavor flavor = null;
/* 27:27 */     flavor = null;
/* 28:   */     try {
/* 29:29 */       flavor = 
/* 30:30 */         SystemFlavorMap.decodeDataFlavor("XML Demetra");
/* 31:   */     }
/* 32:   */     catch (ClassNotFoundException localClassNotFoundException) {}
/* 33:33 */     if (flavor == null) {
/* 34:34 */       SystemFlavorMap table = (SystemFlavorMap)
/* 35:35 */         SystemFlavorMap.getDefaultFlavorMap();
/* 36:36 */       flavor = new DataFlavor("xml/x;class=\"[B\"", 
/* 37:37 */         "XML Demetra");
/* 38:38 */       table.addUnencodedNativeForFlavor(flavor, "XML Demetra");
/* 39:39 */       table.addFlavorForUnencodedNative("XML Demetra", flavor);
/* 40:   */     }
/* 41:41 */     DEMETRA = flavor;
/* 42:   */   }
/* 43:   */ }
