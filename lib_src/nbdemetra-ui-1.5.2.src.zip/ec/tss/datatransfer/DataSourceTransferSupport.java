/*  1:   */ package ec.tss.datatransfer;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import com.google.common.base.Predicate;
/*  5:   */ import com.google.common.collect.FluentIterable;
/*  6:   */ import ec.tss.tsproviders.DataSource;
/*  7:   */ import java.awt.datatransfer.Transferable;
/*  8:   */ import javax.annotation.Nonnull;
/*  9:   */ import org.openide.util.Lookup;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public class DataSourceTransferSupport
/* 36:   */ {
/* 37:   */   @Nonnull
/* 38:   */   public static DataSourceTransferSupport getDefault()
/* 39:   */   {
/* 40:40 */     return (DataSourceTransferSupport)Lookup.getDefault().lookup(DataSourceTransferSupport.class);
/* 41:   */   }
/* 42:   */   
/* 43:   */   @Nonnull
/* 44:   */   @Deprecated
/* 45:   */   public static DataSourceTransferSupport getInstance() {
/* 46:46 */     return getDefault();
/* 47:   */   }
/* 48:   */   
/* 49:   */   @Nonnull
/* 50:   */   public FluentIterable<? extends DataSourceTransferHandler> all() {
/* 51:51 */     return FluentIterable.from(Lookup.getDefault().lookupAll(DataSourceTransferHandler.class));
/* 52:   */   }
/* 53:   */   
/* 54:   */   public boolean canHandle(@Nonnull Transferable t) {
/* 55:55 */     return all().anyMatch(canHandlePredicate(t));
/* 56:   */   }
/* 57:   */   
/* 58:   */   public boolean canHandle(@Nonnull Transferable t, @Nonnull String providerName) {
/* 59:59 */     return all().anyMatch(canHandlePredicate(t, providerName));
/* 60:   */   }
/* 61:   */   
/* 62:   */   @Nonnull
/* 63:   */   public Optional<DataSource> getDataSource(@Nonnull Transferable t) {
/* 64:64 */     for (DataSourceTransferHandler o : all().filter(canHandlePredicate(t))) {
/* 65:65 */       Optional<DataSource> dataSource = o.getDataSource(t);
/* 66:66 */       if (dataSource.isPresent()) {
/* 67:67 */         return dataSource;
/* 68:   */       }
/* 69:   */     }
/* 70:70 */     return Optional.absent();
/* 71:   */   }
/* 72:   */   
/* 73:   */   @Nonnull
/* 74:   */   public Optional<DataSource> getDataSource(@Nonnull Transferable t, @Nonnull String providerName) {
/* 75:75 */     for (DataSourceTransferHandler o : all().filter(canHandlePredicate(t, providerName))) {
/* 76:76 */       Optional<DataSource> dataSource = o.getDataSource(t, providerName);
/* 77:77 */       if (dataSource.isPresent()) {
/* 78:78 */         return dataSource;
/* 79:   */       }
/* 80:   */     }
/* 81:81 */     return Optional.absent();
/* 82:   */   }
/* 83:   */   
/* 84:   */   private static Predicate<DataSourceTransferHandler> canHandlePredicate(Transferable t) {
/* 85:85 */     new Predicate()
/* 86:   */     {
/* 87:   */       public boolean apply(DataSourceTransferHandler input) {
/* 88:88 */         return input != null ? input.canHandle(DataSourceTransferSupport.this) : false;
/* 89:   */       }
/* 90:   */     };
/* 91:   */   }
/* 92:   */   
/* 93:   */   private static Predicate<DataSourceTransferHandler> canHandlePredicate(Transferable t, final String providerName) {
/* 94:94 */     new Predicate()
/* 95:   */     {
/* 96:   */       public boolean apply(DataSourceTransferHandler input) {
/* 97:97 */         return input != null ? input.canHandle(DataSourceTransferSupport.this, providerName) : false;
/* 98:   */       }
/* 99:   */     };
/* :0:   */   }
/* :1:   */ }
