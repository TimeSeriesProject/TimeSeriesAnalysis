/*  1:   */ package ec.tss.datatransfer;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Supplier;
/*  4:   */ import com.google.common.base.Suppliers;
/*  5:   */ import ec.nbdemetra.ui.ComponentFactory;
/*  6:   */ import ec.nbdemetra.ui.awt.TransferHandlers;
/*  7:   */ import ec.tss.Ts;
/*  8:   */ import ec.tss.TsCollection;
/*  9:   */ import ec.tss.TsFactory;
/* 10:   */ import ec.ui.ATsChart;
/* 11:   */ import java.awt.Color;
/* 12:   */ import java.awt.Component;
/* 13:   */ import java.awt.Dimension;
/* 14:   */ import java.awt.Font;
/* 15:   */ import java.awt.image.BufferedImage;
/* 16:   */ import java.util.List;
/* 17:   */ import javax.swing.BorderFactory;
/* 18:   */ import javax.swing.JLabel;
/* 19:   */ import javax.swing.JPanel;
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public abstract class TsDragRenderer
/* 29:   */ {
/* 30:   */   public abstract Component getTsDragRendererComponent(List<? extends Ts> paramList);
/* 31:   */   
/* 32:   */   public BufferedImage getTsDragRendererImage(List<? extends Ts> selection)
/* 33:   */   {
/* 34:34 */     return TransferHandlers.paintComponent(getTsDragRendererComponent(selection));
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static TsDragRenderer asChart() {
/* 38:38 */     return new ChartRenderer(null);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static TsDragRenderer asCount() {
/* 42:42 */     return new CountRenderer();
/* 43:   */   }
/* 44:   */   
/* 45:   */   private static class ChartRenderer extends TsDragRenderer
/* 46:   */   {
/* 47:47 */     final Supplier<ATsChart> supplier = Suppliers.memoize(TsDragRenderer.ChartSupplier.INSTANCE);
/* 48:   */     
/* 49:   */     public Component getTsDragRendererComponent(List<? extends Ts> selection)
/* 50:   */     {
/* 51:51 */       TsCollection col = TsFactory.instance.createTsCollection();
/* 52:52 */       col.quietAppend(selection);
/* 53:53 */       ATsChart result = (ATsChart)supplier.get();
/* 54:54 */       result.setTsCollection(col);
/* 55:55 */       return result;
/* 56:   */     }
/* 57:   */   }
/* 58:   */   
/* 59:   */   private static class ChartSupplier implements Supplier<ATsChart>
/* 60:   */   {
/* 61:61 */     public static final ChartSupplier INSTANCE = new ChartSupplier();
/* 62:   */     
/* 63:   */     public ATsChart get()
/* 64:   */     {
/* 65:65 */       ATsChart c = ComponentFactory.getDefault().newTsChart();
/* 66:66 */       c.setPreferredSize(new Dimension(150, 90));
/* 67:67 */       c.setAxisVisible(false);
/* 68:68 */       c.setLegendVisible(false);
/* 69:69 */       return c;
/* 70:   */     }
/* 71:   */   }
/* 72:   */   
/* 73:   */   private static class CountRenderer extends TsDragRenderer
/* 74:   */   {
/* 75:   */     final JPanel component;
/* 76:   */     final JLabel label;
/* 77:   */     
/* 78:   */     public CountRenderer() {
/* 79:79 */       component = new JPanel();
/* 80:80 */       component.setBorder(BorderFactory.createEmptyBorder(25, 25, 0, 0));
/* 81:81 */       component.setOpaque(false);
/* 82:82 */       label = new JLabel();
/* 83:83 */       label.setBackground(Color.BLACK);
/* 84:84 */       label.setForeground(Color.WHITE);
/* 85:85 */       label.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 86:86 */       label.setOpaque(true);
/* 87:87 */       Font normal = label.getFont();
/* 88:88 */       label.setFont(normal.deriveFont(normal.getSize2D() * 2.0F));
/* 89:89 */       component.add(label);
/* 90:   */     }
/* 91:   */     
/* 92:   */     public Component getTsDragRendererComponent(List<? extends Ts> selection)
/* 93:   */     {
/* 94:94 */       label.setText(String.valueOf(selection.size()));
/* 95:95 */       return component;
/* 96:   */     }
/* 97:   */   }
/* 98:   */ }
