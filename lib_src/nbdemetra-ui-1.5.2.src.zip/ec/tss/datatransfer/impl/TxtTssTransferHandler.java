/*   1:    */ package ec.tss.datatransfer.impl;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Converter;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.StandardSystemProperty;
/*   7:    */ import com.google.common.collect.ImmutableList;
/*   8:    */ import com.google.common.collect.ImmutableList.Builder;
/*   9:    */ import ec.nbdemetra.ui.BeanHandler;
/*  10:    */ import ec.nbdemetra.ui.Config;
/*  11:    */ import ec.nbdemetra.ui.Config.Builder;
/*  12:    */ import ec.nbdemetra.ui.Configurator;
/*  13:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*  14:    */ import ec.nbdemetra.ui.IConfigurable;
/*  15:    */ import ec.nbdemetra.ui.properties.IBeanEditor;
/*  16:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  17:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.BooleanStep;
/*  18:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  19:    */ import ec.nbdemetra.ui.properties.OpenIdePropertySheetBeanEditor;
/*  20:    */ import ec.tss.Ts;
/*  21:    */ import ec.tss.TsCollection;
/*  22:    */ import ec.tss.TsInformationType;
/*  23:    */ import ec.tss.TsStatus;
/*  24:    */ import ec.tss.datatransfer.TssTransferHandler;
/*  25:    */ import ec.tss.tsproviders.utils.DataFormat;
/*  26:    */ import ec.tss.tsproviders.utils.IParam;
/*  27:    */ import ec.tss.tsproviders.utils.Params;
/*  28:    */ import ec.tss.tsproviders.utils.Parsers;
/*  29:    */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  30:    */ import ec.tstoolkit.data.Table;
/*  31:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*  32:    */ import java.awt.datatransfer.DataFlavor;
/*  33:    */ import java.beans.IntrospectionException;
/*  34:    */ import java.io.IOException;
/*  35:    */ import java.text.DateFormat;
/*  36:    */ import java.text.NumberFormat;
/*  37:    */ import java.text.SimpleDateFormat;
/*  38:    */ import java.util.Date;
/*  39:    */ import java.util.Locale;
/*  40:    */ import org.openide.nodes.Sheet;
/*  41:    */ import org.openide.util.ImageUtilities;
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ public class TxtTssTransferHandler
/*  58:    */   extends TssTransferHandler
/*  59:    */   implements IConfigurable
/*  60:    */ {
/*  61:    */   private static final char DELIMITOR = '\t';
/*  62: 62 */   private static final String NEWLINE = StandardSystemProperty.LINE_SEPARATOR.value();
/*  63:    */   private static final int MINDATES = 2;
/*  64:    */   private final NumberFormat numberFormat;
/*  65:    */   private final DateFormat dateFormat;
/*  66:    */   private final Configurator<TxtTssTransferHandler> configurator;
/*  67:    */   private InternalConfig config;
/*  68:    */   
/*  69:    */   public TxtTssTransferHandler()
/*  70:    */   {
/*  71: 71 */     numberFormat = NumberFormat.getNumberInstance();
/*  72: 72 */     dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*  73: 73 */     configurator = new InternalConfigHandler(null).toConfigurator(new InternalConfigConverter(null), new InternalConfigEditor(null));
/*  74: 74 */     config = new InternalConfig();
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */   public String getName()
/*  79:    */   {
/*  80: 80 */     return "TXT";
/*  81:    */   }
/*  82:    */   
/*  83:    */   public String getDisplayName()
/*  84:    */   {
/*  85: 85 */     return "Tab-delimited values";
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */ 
/*  90:    */   public DataFlavor getDataFlavor()
/*  91:    */   {
/*  92: 92 */     return DataFlavor.stringFlavor;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public boolean canExportTsCollection(TsCollection col)
/*  96:    */   {
/*  97: 97 */     return (config.exportTimeSeries) && (!col.isEmpty());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Object exportTsCollection(TsCollection col) throws IOException
/* 101:    */   {
/* 102:102 */     col.load(TsInformationType.Data);
/* 103:103 */     return tsCollectionToString(col);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean canImportTsCollection(Object obj)
/* 107:    */   {
/* 108:108 */     return (config.importTimeSeries) && ((obj instanceof String));
/* 109:    */   }
/* 110:    */   
/* 111:    */   public TsCollection importTsCollection(Object obj) throws IOException
/* 112:    */   {
/* 113:113 */     return tsCollectionFromString((String)obj);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean canExportMatrix(Matrix matrix)
/* 117:    */   {
/* 118:118 */     return (config.exportMatrix) && (!matrix.isEmpty());
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Object exportMatrix(Matrix matrix) throws IOException
/* 122:    */   {
/* 123:123 */     StringBuilder result = new StringBuilder();
/* 124:124 */     for (int i = 0; i < matrix.getRowsCount(); i++) {
/* 125:125 */       result.append(numberFormat.format(matrix.get(i, 0)));
/* 126:126 */       for (int j = 1; j < matrix.getColumnsCount(); j++) {
/* 127:127 */         result.append('\t').append(numberFormat.format(matrix.get(i, j)));
/* 128:    */       }
/* 129:129 */       result.append(NEWLINE);
/* 130:    */     }
/* 131:131 */     return result.toString();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean canExportTable(Table<?> table)
/* 135:    */   {
/* 136:136 */     return (config.exportTable) && (!table.isEmpty());
/* 137:    */   }
/* 138:    */   
/* 139:    */   public Object exportTable(Table<?> table) throws IOException
/* 140:    */   {
/* 141:141 */     StringBuilder result = new StringBuilder();
/* 142:142 */     for (int i = 0; i < table.getRowsCount(); i++) {
/* 143:143 */       result.append(valueToString(table.get(i, 0)));
/* 144:144 */       for (int j = 1; j < table.getColumnsCount(); j++) {
/* 145:145 */         result.append('\t').append(valueToString(table.get(i, j)));
/* 146:    */       }
/* 147:147 */       result.append(NEWLINE);
/* 148:    */     }
/* 149:149 */     return result.toString();
/* 150:    */   }
/* 151:    */   
/* 152:    */ 
/* 153:    */ 
/* 154:    */   public Config getConfig()
/* 155:    */   {
/* 156:156 */     return configurator.getConfig(this);
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setConfig(Config config)
/* 160:    */   {
/* 161:161 */     configurator.setConfig(this, config);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public Config editConfig(Config config)
/* 165:    */   {
/* 166:166 */     return configurator.editConfig(config);
/* 167:    */   }
/* 168:    */   
/* 169:    */   private String valueToString(Object value)
/* 170:    */   {
/* 171:171 */     if (value == null) {
/* 172:172 */       return "";
/* 173:    */     }
/* 174:174 */     if ((value instanceof Date)) {
/* 175:175 */       return dateFormat.format((Date)value);
/* 176:    */     }
/* 177:177 */     if ((value instanceof Number)) {
/* 178:178 */       return numberFormat.format((Number)value);
/* 179:    */     }
/* 180:180 */     return value.toString();
/* 181:    */   }
/* 182:    */   
/* 183:    */   public String tsCollectionToString(TsCollection col) throws IOException
/* 184:    */   {
/* 185:185 */     if (col.isEmpty()) {
/* 186:186 */       return "";
/* 187:    */     }
/* 188:188 */     StringBuilder result = new StringBuilder();
/* 189:189 */     TsCollectionAnalyser analyser = new TsCollectionAnalyser();
/* 190:190 */     analyser.set(col, config.beginPeriod);
/* 191:191 */     int nbdates = dates.length;
/* 192:192 */     int nseries = titles.length;
/* 193:193 */     if (config.vertical)
/* 194:    */     {
/* 195:    */ 
/* 196:196 */       if (config.showTitle) {
/* 197:197 */         if (config.showDates) {
/* 198:198 */           result.append('\t');
/* 199:    */         }
/* 200:200 */         for (int i = 0; i < nseries; i++) {
/* 201:201 */           result.append(titles[i]);
/* 202:202 */           if (i == nseries - 1) {
/* 203:203 */             result.append(NEWLINE);
/* 204:    */           } else {
/* 205:205 */             result.append('\t');
/* 206:    */           }
/* 207:    */         }
/* 208:    */       }
/* 209:    */       
/* 210:210 */       for (int i = 0; i < nbdates; i++) {
/* 211:211 */         if (config.showDates) {
/* 212:212 */           result.append(dateFormat.format(dates[i])).append('\t');
/* 213:    */         }
/* 214:214 */         for (int j = 0; j < nseries; j++) {
/* 215:215 */           double val = data.get(i, j);
/* 216:216 */           if (!Double.isNaN(val)) {
/* 217:217 */             result.append(numberFormat.format(val));
/* 218:    */           }
/* 219:219 */           if (j == nseries - 1) {
/* 220:220 */             result.append(NEWLINE);
/* 221:    */           } else {
/* 222:222 */             result.append('\t');
/* 223:    */           }
/* 224:    */         }
/* 225:    */       }
/* 226:    */     }
/* 227:    */     else
/* 228:    */     {
/* 229:229 */       if (config.showDates) {
/* 230:230 */         if (config.showTitle) {
/* 231:231 */           result.append('\t');
/* 232:    */         }
/* 233:233 */         for (int i = 0; i < nbdates; i++) {
/* 234:234 */           result.append(dateFormat.format(dates[i]));
/* 235:235 */           result.append('\t');
/* 236:236 */           if (i == nbdates - 1) {
/* 237:237 */             result.append(NEWLINE);
/* 238:    */           } else {
/* 239:239 */             result.append('\t');
/* 240:    */           }
/* 241:    */         }
/* 242:    */       }
/* 243:243 */       for (int i = 0; i < nseries; i++) {
/* 244:244 */         if (config.showTitle) {
/* 245:245 */           result.append(titles[i]);
/* 246:246 */           result.append('\t');
/* 247:    */         }
/* 248:248 */         for (int j = 0; j < nbdates; j++) {
/* 249:249 */           double val = data.get(j, i);
/* 250:250 */           if (!Double.isNaN(val)) {
/* 251:251 */             result.append(numberFormat.format(val));
/* 252:    */           }
/* 253:253 */           if (j == nbdates - 1) {
/* 254:254 */             result.append(NEWLINE);
/* 255:    */           } else {
/* 256:256 */             result.append('\t');
/* 257:    */           }
/* 258:    */         }
/* 259:    */       }
/* 260:    */     }
/* 261:261 */     return result.toString();
/* 262:    */   }
/* 263:    */   
/* 264:    */   public TsCollection tsCollectionFromString(String text) throws IOException {
/* 265:265 */     Parsers.Parser<Date> periodParser = (Parsers.Parser)FALLBACK_PARSER.get();
/* 266:266 */     Parsers.Parser<Number> valueParser = Parsers.onNumberFormat(numberFormat);
/* 267:    */     
/* 268:268 */     TsCollection result = null;
/* 269:    */     try {
/* 270:270 */       int rows = 0;
/* 271:271 */       int cols = 0;
/* 272:272 */       boolean datesAreVertical = true;
/* 273:    */       
/* 274:274 */       String[] rowarray = text.split("\\r?\\n");
/* 275:275 */       rows = rowarray.length;
/* 276:276 */       for (int i = 0; i < rows; i++) {
/* 277:277 */         String[] colarray = rowarray[i].split("\\t");
/* 278:278 */         if (cols < colarray.length) {
/* 279:279 */           cols = colarray.length;
/* 280:    */         }
/* 281:281 */         datesAreVertical = periodParser.tryParse(colarray[0]).isPresent();
/* 282:    */       }
/* 283:    */       
/* 284:284 */       if ((cols < 1) || (rows < 1)) {
/* 285:285 */         return null;
/* 286:    */       }
/* 287:287 */       Matrix datamatrix = new Matrix(rows, cols);
/* 288:288 */       for (int i = 0; i < rows; i++) {
/* 289:289 */         for (int j = 0; j < cols; j++) {
/* 290:290 */           datamatrix.set(i, j, (0.0D / 0.0D));
/* 291:    */         }
/* 292:    */       }
/* 293:293 */       Date[] dates = new Date[datesAreVertical ? rows : cols];
/* 294:294 */       String[] titles = new String[datesAreVertical ? cols : rows];
/* 295:    */       
/* 296:296 */       rowarray = text.split("\\r?\\n");
/* 297:297 */       Number value; for (int i = 0; i < rowarray.length; i++) {
/* 298:298 */         String[] colarray = rowarray[i].split("\\t");
/* 299:299 */         for (int j = 0; j < colarray.length; j++) {
/* 300:300 */           if (((j == 0) && (datesAreVertical)) || ((i == 0) && (!datesAreVertical) && 
/* 301:301 */             (periodParser.tryParse(colarray[j]).isPresent()))) {
/* 302:302 */             dates[(datesAreVertical ? i : j)] = ((Date)periodParser.parse(colarray[j]));
/* 303:303 */           } else if (((j == 0) && (!datesAreVertical)) || (
/* 304:304 */             (i == 0) && (datesAreVertical))) {
/* 305:305 */             titles[(datesAreVertical ? j : i)] = colarray[j];
/* 306:    */           } else {
/* 307:307 */             value = (Number)valueParser.parse(colarray[j]);
/* 308:308 */             if (value != null) {
/* 309:309 */               datamatrix.set(i, j, value.doubleValue());
/* 310:    */             }
/* 311:    */           }
/* 312:    */         }
/* 313:    */       }
/* 314:314 */       int ndates = 0;
/* 315:315 */       for (int i = 0; i < dates.length; i++) {
/* 316:316 */         if (dates[i] != null) {
/* 317:317 */           ndates++;
/* 318:    */         }
/* 319:    */       }
/* 320:    */       
/* 321:321 */       if (ndates < 2) {
/* 322:322 */         return null;
/* 323:    */       }
/* 324:324 */       TsCollectionAnalyser analyser = new TsCollectionAnalyser();
/* 325:    */       
/* 326:326 */       data = (datesAreVertical ? datamatrix : datamatrix.transpose());
/* 327:327 */       dates = dates;
/* 328:328 */       titles = titles;
/* 329:329 */       result = analyser.create();
/* 330:    */       
/* 331:331 */       for (Ts s : result) {
/* 332:332 */         if (s.hasData() == TsStatus.Valid) {
/* 333:333 */           s.set(s.getTsData());
/* 334:    */         }
/* 335:    */       }
/* 336:    */     } catch (Exception ex) {
/* 337:337 */       throw new IOException("Problem while retrieving data", ex);
/* 338:    */     }
/* 339:339 */     return result; }
/* 340:    */   
/* 341:341 */   private static final ThreadLocal<Parsers.Parser<Date>> FALLBACK_PARSER = new ThreadLocal()
/* 342:    */   {
/* 343:    */     protected Parsers.Parser<Date> initialValue() {
/* 344:344 */       ImmutableList.Builder<Parsers.Parser<Date>> list = ImmutableList.builder();
/* 345:345 */       for (String o : TxtTssTransferHandler.FALLBACK_FORMATS) {
/* 346:346 */         list.add(new DataFormat(Locale.ROOT, o, null).dateParser());
/* 347:    */       }
/* 348:348 */       return Parsers.firstNotNull(list.build());
/* 349:    */     }
/* 350:    */   };
/* 351:    */   
/* 352:352 */   private static final String[] FALLBACK_FORMATS = {
/* 353:353 */     "yyyy-MM-dd", 
/* 354:354 */     "yyyy MM dd", 
/* 355:355 */     "yyyy.MM.dd", 
/* 356:356 */     "yyyy-MMM-dd", 
/* 357:357 */     "yyyy MMM dd", 
/* 358:358 */     "yyyy.MMM.dd", 
/* 359:359 */     "dd-MM-yyyy", 
/* 360:360 */     "dd MM yyyy", 
/* 361:361 */     "dd.MM.yyyy", 
/* 362:362 */     "dd/MM/yyyy", 
/* 363:363 */     "dd-MM-yy", 
/* 364:364 */     "dd MM yy", 
/* 365:365 */     "dd.MM.yy", 
/* 366:366 */     "dd/MM/yy", 
/* 367:367 */     "dd-MMM-yy", 
/* 368:368 */     "dd MMM yy", 
/* 369:369 */     "dd.MMM.yy", 
/* 370:370 */     "dd/MMM/yy", 
/* 371:371 */     "dd-MMM-yyyy", 
/* 372:372 */     "dd MMM yyyy", 
/* 373:373 */     "dd.MMM.yyyy", 
/* 374:374 */     "dd/MMM/yyyy", 
/* 375:375 */     "yyyy-MM-dd hh:mm:ss", 
/* 376:376 */     "yyyy MM dd hh:mm:ss", 
/* 377:377 */     "yyyy.MM.dd hh:mm:ss", 
/* 378:378 */     "yyyy/MM/dd hh:mm:ss", 
/* 379:379 */     "yyyy-MMM-dd hh:mm:ss", 
/* 380:380 */     "yyyy MMM dd hh:mm:ss", 
/* 381:381 */     "yyyy.MMM.dd hh:mm:ss", 
/* 382:382 */     "yyyy/MMM/dd hh:mm:ss", 
/* 383:383 */     "dd-MM-yyyy hh:mm:ss", 
/* 384:384 */     "dd MM yyyy hh:mm:ss", 
/* 385:385 */     "dd.MM.yyyy hh:mm:ss", 
/* 386:386 */     "dd/MM/yyyy hh:mm:ss", 
/* 387:387 */     "dd-MMM-yyyy hh:mm:ss", 
/* 388:388 */     "dd MMM yyyy hh:mm:ss", 
/* 389:389 */     "dd.MMM.yyyy hh:mm:ss", 
/* 390:390 */     "dd/MMM/yyyy hh:mm:ss" };
/* 391:    */   
/* 392:    */ 
/* 393:    */ 
/* 394:    */ 
/* 395:    */   public static final class InternalConfig
/* 396:    */   {
/* 397:397 */     public boolean vertical = true;
/* 398:    */     
/* 399:    */ 
/* 400:    */ 
/* 401:401 */     public boolean showDates = true;
/* 402:    */     
/* 403:    */ 
/* 404:    */ 
/* 405:405 */     public boolean showTitle = true;
/* 406:    */     
/* 407:    */ 
/* 408:    */ 
/* 409:    */ 
/* 410:410 */     public boolean beginPeriod = true;
/* 411:411 */     public boolean importTimeSeries = true;
/* 412:412 */     public boolean exportTimeSeries = true;
/* 413:413 */     public boolean importMatrix = true;
/* 414:414 */     public boolean exportMatrix = true;
/* 415:415 */     public boolean exportTable = true;
/* 416:    */   }
/* 417:    */   
/* 418:    */   private static final class InternalConfigHandler
/* 419:    */     extends BeanHandler<TxtTssTransferHandler.InternalConfig, TxtTssTransferHandler>
/* 420:    */   {
/* 421:    */     public TxtTssTransferHandler.InternalConfig loadBean(TxtTssTransferHandler resource)
/* 422:    */     {
/* 423:423 */       return config;
/* 424:    */     }
/* 425:    */     
/* 426:    */     public void storeBean(TxtTssTransferHandler resource, TxtTssTransferHandler.InternalConfig bean)
/* 427:    */     {
/* 428:428 */       config = bean;
/* 429:    */     }
/* 430:    */   }
/* 431:    */   
/* 432:    */   private static final class InternalConfigEditor implements IBeanEditor
/* 433:    */   {
/* 434:    */     public boolean editBean(Object bean) throws IntrospectionException
/* 435:    */     {
/* 436:436 */       Sheet sheet = new Sheet();
/* 437:437 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 438:    */       
/* 439:439 */       b.reset("tscollection").display("Time Series");
/* 440:440 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "importTimeSeries")).display("Allow import")).add();
/* 441:441 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "exportTimeSeries")).display("Allow export")).add();
/* 442:442 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "vertical")).display("Vertical alignment")).add();
/* 443:443 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "showDates")).display("Include date headers")).add();
/* 444:444 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "showTitle")).display("Include title headers")).add();
/* 445:445 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "beginPeriod")).display("Begin period")).add();
/* 446:446 */       sheet.put(b.build());
/* 447:    */       
/* 448:448 */       b.reset("matrix").display("Matrix");
/* 449:    */       
/* 450:450 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "exportMatrix")).display("Allow export")).add();
/* 451:451 */       sheet.put(b.build());
/* 452:    */       
/* 453:453 */       b.reset("table").display("Table");
/* 454:454 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "exportTable")).display("Allow export")).add();
/* 455:455 */       sheet.put(b.build());
/* 456:    */       
/* 457:457 */       return OpenIdePropertySheetBeanEditor.editSheet(sheet, "Configure Tab-delimited values", 
/* 458:458 */         ImageUtilities.icon2Image(DemetraUiIcon.CLIPBOARD_PASTE_DOCUMENT_TEXT_16));
/* 459:    */     }
/* 460:    */   }
/* 461:    */   
/* 462:    */   private static final class InternalConfigConverter extends Converter<TxtTssTransferHandler.InternalConfig, Config>
/* 463:    */   {
/* 464:464 */     private static final String DOMAIN = TssTransferHandler.class.getName();
/* 465:465 */     private static final String NAME = "TXT"; private static final String VERSION = ""; private static final IParam<Config, Boolean> VERTICAL = Params.onBoolean(Boolean.valueOf(true), "vertical");
/* 466:466 */     private static final IParam<Config, Boolean> SHOW_DATES = Params.onBoolean(Boolean.valueOf(true), "showDates");
/* 467:467 */     private static final IParam<Config, Boolean> SHOW_TITLE = Params.onBoolean(Boolean.valueOf(true), "showTitle");
/* 468:468 */     private static final IParam<Config, Boolean> BEGIN_PERIOD = Params.onBoolean(Boolean.valueOf(true), "beginPeriod");
/* 469:469 */     private static final IParam<Config, Boolean> IMPORT_TS = Params.onBoolean(Boolean.valueOf(true), "importEnabled");
/* 470:470 */     private static final IParam<Config, Boolean> EXPORT_TS = Params.onBoolean(Boolean.valueOf(true), "exportEnabled");
/* 471:471 */     private static final IParam<Config, Boolean> IMPORT_MATRIX = Params.onBoolean(Boolean.valueOf(true), "importMatrix");
/* 472:472 */     private static final IParam<Config, Boolean> EXPORT_MATRIX = Params.onBoolean(Boolean.valueOf(true), "exportMatrix");
/* 473:473 */     private static final IParam<Config, Boolean> EXPORT_TABLE = Params.onBoolean(Boolean.valueOf(true), "exportTable");
/* 474:    */     
/* 475:    */     protected Config doForward(TxtTssTransferHandler.InternalConfig a)
/* 476:    */     {
/* 477:477 */       Config.Builder b = Config.builder(DOMAIN, "TXT", "");
/* 478:478 */       VERTICAL.set(b, Boolean.valueOf(vertical));
/* 479:479 */       SHOW_DATES.set(b, Boolean.valueOf(showDates));
/* 480:480 */       SHOW_TITLE.set(b, Boolean.valueOf(showTitle));
/* 481:481 */       BEGIN_PERIOD.set(b, Boolean.valueOf(beginPeriod));
/* 482:482 */       IMPORT_TS.set(b, Boolean.valueOf(importTimeSeries));
/* 483:483 */       EXPORT_TS.set(b, Boolean.valueOf(exportTimeSeries));
/* 484:484 */       IMPORT_MATRIX.set(b, Boolean.valueOf(importMatrix));
/* 485:485 */       EXPORT_MATRIX.set(b, Boolean.valueOf(exportMatrix));
/* 486:486 */       EXPORT_TABLE.set(b, Boolean.valueOf(exportTable));
/* 487:487 */       return b.build();
/* 488:    */     }
/* 489:    */     
/* 490:    */     protected TxtTssTransferHandler.InternalConfig doBackward(Config config)
/* 491:    */     {
/* 492:492 */       Preconditions.checkArgument(DOMAIN.equals(config.getDomain()));
/* 493:493 */       Preconditions.checkArgument("TXT".equals(config.getName()));
/* 494:494 */       TxtTssTransferHandler.InternalConfig result = new TxtTssTransferHandler.InternalConfig();
/* 495:495 */       vertical = ((Boolean)VERTICAL.get(config)).booleanValue();
/* 496:496 */       showDates = ((Boolean)SHOW_DATES.get(config)).booleanValue();
/* 497:497 */       showTitle = ((Boolean)SHOW_TITLE.get(config)).booleanValue();
/* 498:498 */       beginPeriod = ((Boolean)BEGIN_PERIOD.get(config)).booleanValue();
/* 499:499 */       importTimeSeries = ((Boolean)IMPORT_TS.get(config)).booleanValue();
/* 500:500 */       exportTimeSeries = ((Boolean)EXPORT_TS.get(config)).booleanValue();
/* 501:501 */       importMatrix = ((Boolean)IMPORT_MATRIX.get(config)).booleanValue();
/* 502:502 */       exportMatrix = ((Boolean)EXPORT_MATRIX.get(config)).booleanValue();
/* 503:503 */       exportTable = ((Boolean)EXPORT_TABLE.get(config)).booleanValue();
/* 504:504 */       return result;
/* 505:    */     }
/* 506:    */   }
/* 507:    */ }
