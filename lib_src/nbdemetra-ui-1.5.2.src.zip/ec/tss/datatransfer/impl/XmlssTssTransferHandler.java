/*   1:    */ package ec.tss.datatransfer.impl;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Converter;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Strings;
/*   6:    */ import ec.nbdemetra.ui.BeanHandler;
/*   7:    */ import ec.nbdemetra.ui.Config;
/*   8:    */ import ec.nbdemetra.ui.Config.Builder;
/*   9:    */ import ec.nbdemetra.ui.Configurator;
/*  10:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*  11:    */ import ec.nbdemetra.ui.IConfigurable;
/*  12:    */ import ec.nbdemetra.ui.properties.IBeanEditor;
/*  13:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  14:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.BooleanStep;
/*  15:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  16:    */ import ec.nbdemetra.ui.properties.OpenIdePropertySheetBeanEditor;
/*  17:    */ import ec.tss.Ts;
/*  18:    */ import ec.tss.TsCollection;
/*  19:    */ import ec.tss.TsInformationType;
/*  20:    */ import ec.tss.TsStatus;
/*  21:    */ import ec.tss.datatransfer.TssTransferHandler;
/*  22:    */ import ec.tss.tsproviders.utils.IParam;
/*  23:    */ import ec.tss.tsproviders.utils.Params;
/*  24:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*  25:    */ import java.awt.datatransfer.DataFlavor;
/*  26:    */ import java.awt.datatransfer.SystemFlavorMap;
/*  27:    */ import java.beans.IntrospectionException;
/*  28:    */ import java.io.ByteArrayInputStream;
/*  29:    */ import java.io.IOException;
/*  30:    */ import java.text.DateFormat;
/*  31:    */ import java.text.NumberFormat;
/*  32:    */ import java.text.SimpleDateFormat;
/*  33:    */ import java.util.Date;
/*  34:    */ import java.util.Iterator;
/*  35:    */ import java.util.Locale;
/*  36:    */ import javax.xml.stream.XMLInputFactory;
/*  37:    */ import javax.xml.stream.XMLStreamException;
/*  38:    */ import javax.xml.stream.XMLStreamReader;
/*  39:    */ import javax.xml.stream.XMLStreamWriter;
/*  40:    */ import org.openide.nodes.Sheet;
/*  41:    */ import org.openide.util.ImageUtilities;
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ public class XmlssTssTransferHandler
/*  63:    */   extends TssTransferHandler
/*  64:    */   implements IConfigurable
/*  65:    */ {
/*  66: 66 */   private static final DataFlavor XMLSS = ;
/*  67:    */   private final NumberFormat numberFormat;
/*  68:    */   private final DateFormat dateFormat;
/*  69:    */   private final Configurator<XmlssTssTransferHandler> configurator;
/*  70:    */   private InternalConfig config;
/*  71:    */   
/*  72:    */   public XmlssTssTransferHandler()
/*  73:    */   {
/*  74: 74 */     numberFormat = NumberFormat.getNumberInstance(Locale.ROOT);
/*  75: 75 */     numberFormat.setMaximumFractionDigits(9);
/*  76: 76 */     numberFormat.setMaximumIntegerDigits(12);
/*  77: 77 */     dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*  78: 78 */     configurator = new InternalConfigHandler(null).toConfigurator(new InternalConfigConverter(null), new InternalConfigEditor(null));
/*  79: 79 */     config = new InternalConfig();
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */   public String getName()
/*  84:    */   {
/*  85: 85 */     return "XMLSS";
/*  86:    */   }
/*  87:    */   
/*  88:    */   public String getDisplayName()
/*  89:    */   {
/*  90: 90 */     return "XML Spreadsheet (XMLSS)";
/*  91:    */   }
/*  92:    */   
/*  93:    */ 
/*  94:    */ 
/*  95:    */   public DataFlavor getDataFlavor()
/*  96:    */   {
/*  97: 97 */     return XMLSS;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean canExportTsCollection(TsCollection col)
/* 101:    */   {
/* 102:102 */     return config.exportTimeSeries;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Object exportTsCollection(TsCollection col) throws IOException
/* 106:    */   {
/* 107:107 */     col.load(TsInformationType.Data);
/* 108:108 */     return tsCollectionToBytes(col);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean canImportTsCollection(Object obj)
/* 112:    */   {
/* 113:113 */     return (config.importTimeSeries) && ((obj instanceof byte[]));
/* 114:    */   }
/* 115:    */   
/* 116:    */   public TsCollection importTsCollection(Object obj) throws IOException
/* 117:    */   {
/* 118:118 */     return tsCollectionFromBytes((byte[])obj);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean canExportMatrix(Matrix matrix)
/* 122:    */   {
/* 123:123 */     return (config.exportMatrix) && (!matrix.isEmpty());
/* 124:    */   }
/* 125:    */   
/* 126:    */   /* Error */
/* 127:    */   public Object exportMatrix(Matrix matrix)
/* 128:    */     throws IOException
/* 129:    */   {
/* 130:    */     // Byte code:
/* 131:    */     //   0: aconst_null
/* 132:    */     //   1: astore_2
/* 133:    */     //   2: aconst_null
/* 134:    */     //   3: astore_3
/* 135:    */     //   4: new 157	java/io/ByteArrayOutputStream
/* 136:    */     //   7: dup
/* 137:    */     //   8: invokespecial 159	java/io/ByteArrayOutputStream:<init>	()V
/* 138:    */     //   11: astore 4
/* 139:    */     //   13: invokestatic 160	javax/xml/stream/XMLOutputFactory:newInstance	()Ljavax/xml/stream/XMLOutputFactory;
/* 140:    */     //   16: aload 4
/* 141:    */     //   18: invokevirtual 166	javax/xml/stream/XMLOutputFactory:createXMLStreamWriter	(Ljava/io/OutputStream;)Ljavax/xml/stream/XMLStreamWriter;
/* 142:    */     //   21: astore 5
/* 143:    */     //   23: aconst_null
/* 144:    */     //   24: astore 6
/* 145:    */     //   26: aconst_null
/* 146:    */     //   27: astore 7
/* 147:    */     //   29: aload 5
/* 148:    */     //   31: invokestatic 170	ec/tstoolkit/utilities/Closeables:asCloseable	(Ljavax/xml/stream/XMLStreamWriter;)Ljava/io/Closeable;
/* 149:    */     //   34: astore 8
/* 150:    */     //   36: new 176	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade
/* 151:    */     //   39: dup
/* 152:    */     //   40: aload 5
/* 153:    */     //   42: invokespecial 178	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:<init>	(Ljavax/xml/stream/XMLStreamWriter;)V
/* 154:    */     //   45: astore 9
/* 155:    */     //   47: aload 9
/* 156:    */     //   49: invokevirtual 181	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:beginWorkbook	()V
/* 157:    */     //   52: aload 9
/* 158:    */     //   54: invokevirtual 184	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:beginWorksheet	()V
/* 159:    */     //   57: aload 9
/* 160:    */     //   59: invokevirtual 187	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:beginTable	()V
/* 161:    */     //   62: aload_1
/* 162:    */     //   63: invokevirtual 190	ec/tstoolkit/maths/matrices/Matrix:rowList	()Ljava/util/List;
/* 163:    */     //   66: invokeinterface 194 1 0
/* 164:    */     //   71: astore 11
/* 165:    */     //   73: goto +56 -> 129
/* 166:    */     //   76: aload 11
/* 167:    */     //   78: invokeinterface 200 1 0
/* 168:    */     //   83: checkcast 206	ec/tstoolkit/data/DataBlock
/* 169:    */     //   86: astore 10
/* 170:    */     //   88: aload 9
/* 171:    */     //   90: invokevirtual 208	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:beginRow	()V
/* 172:    */     //   93: iconst_0
/* 173:    */     //   94: istore 12
/* 174:    */     //   96: goto +18 -> 114
/* 175:    */     //   99: aload 9
/* 176:    */     //   101: aload 10
/* 177:    */     //   103: iload 12
/* 178:    */     //   105: invokevirtual 211	ec/tstoolkit/data/DataBlock:get	(I)D
/* 179:    */     //   108: invokevirtual 215	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:writeCell	(D)V
/* 180:    */     //   111: iinc 12 1
/* 181:    */     //   114: iload 12
/* 182:    */     //   116: aload 10
/* 183:    */     //   118: invokevirtual 219	ec/tstoolkit/data/DataBlock:getLength	()I
/* 184:    */     //   121: if_icmplt -22 -> 99
/* 185:    */     //   124: aload 9
/* 186:    */     //   126: invokevirtual 223	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:endRow	()V
/* 187:    */     //   129: aload 11
/* 188:    */     //   131: invokeinterface 226 1 0
/* 189:    */     //   136: ifne -60 -> 76
/* 190:    */     //   139: aload 9
/* 191:    */     //   141: invokevirtual 229	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:endTable	()V
/* 192:    */     //   144: aload 9
/* 193:    */     //   146: invokevirtual 232	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:endWorksheet	()V
/* 194:    */     //   149: aload 9
/* 195:    */     //   151: invokevirtual 235	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:endWorkbook	()V
/* 196:    */     //   154: aload 4
/* 197:    */     //   156: invokevirtual 238	java/io/ByteArrayOutputStream:toByteArray	()[B
/* 198:    */     //   159: aload 8
/* 199:    */     //   161: ifnull +10 -> 171
/* 200:    */     //   164: aload 8
/* 201:    */     //   166: invokeinterface 242 1 0
/* 202:    */     //   171: aload 4
/* 203:    */     //   173: ifnull +8 -> 181
/* 204:    */     //   176: aload 4
/* 205:    */     //   178: invokevirtual 247	java/io/ByteArrayOutputStream:close	()V
/* 206:    */     //   181: areturn
/* 207:    */     //   182: astore 6
/* 208:    */     //   184: aload 8
/* 209:    */     //   186: ifnull +10 -> 196
/* 210:    */     //   189: aload 8
/* 211:    */     //   191: invokeinterface 242 1 0
/* 212:    */     //   196: aload 6
/* 213:    */     //   198: athrow
/* 214:    */     //   199: astore 7
/* 215:    */     //   201: aload 6
/* 216:    */     //   203: ifnonnull +10 -> 213
/* 217:    */     //   206: aload 7
/* 218:    */     //   208: astore 6
/* 219:    */     //   210: goto +17 -> 227
/* 220:    */     //   213: aload 6
/* 221:    */     //   215: aload 7
/* 222:    */     //   217: if_acmpeq +10 -> 227
/* 223:    */     //   220: aload 6
/* 224:    */     //   222: aload 7
/* 225:    */     //   224: invokevirtual 248	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 226:    */     //   227: aload 6
/* 227:    */     //   229: athrow
/* 228:    */     //   230: astore_2
/* 229:    */     //   231: aload 4
/* 230:    */     //   233: ifnull +8 -> 241
/* 231:    */     //   236: aload 4
/* 232:    */     //   238: invokevirtual 247	java/io/ByteArrayOutputStream:close	()V
/* 233:    */     //   241: aload_2
/* 234:    */     //   242: athrow
/* 235:    */     //   243: astore_3
/* 236:    */     //   244: aload_2
/* 237:    */     //   245: ifnonnull +8 -> 253
/* 238:    */     //   248: aload_3
/* 239:    */     //   249: astore_2
/* 240:    */     //   250: goto +13 -> 263
/* 241:    */     //   253: aload_2
/* 242:    */     //   254: aload_3
/* 243:    */     //   255: if_acmpeq +8 -> 263
/* 244:    */     //   258: aload_2
/* 245:    */     //   259: aload_3
/* 246:    */     //   260: invokevirtual 248	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 247:    */     //   263: aload_2
/* 248:    */     //   264: athrow
/* 249:    */     //   265: astore_2
/* 250:    */     //   266: new 109	java/io/IOException
/* 251:    */     //   269: dup
/* 252:    */     //   270: aload_2
/* 253:    */     //   271: invokespecial 254	java/io/IOException:<init>	(Ljava/lang/Throwable;)V
/* 254:    */     //   274: athrow
/* 255:    */     // Line number table:
/* 256:    */     //   Java source line #128	-> byte code offset #0
/* 257:    */     //   Java source line #129	-> byte code offset #13
/* 258:    */     //   Java source line #130	-> byte code offset #23
/* 259:    */     //   Java source line #130	-> byte code offset #29
/* 260:    */     //   Java source line #131	-> byte code offset #36
/* 261:    */     //   Java source line #132	-> byte code offset #47
/* 262:    */     //   Java source line #133	-> byte code offset #52
/* 263:    */     //   Java source line #134	-> byte code offset #57
/* 264:    */     //   Java source line #135	-> byte code offset #62
/* 265:    */     //   Java source line #136	-> byte code offset #88
/* 266:    */     //   Java source line #137	-> byte code offset #93
/* 267:    */     //   Java source line #138	-> byte code offset #99
/* 268:    */     //   Java source line #137	-> byte code offset #111
/* 269:    */     //   Java source line #140	-> byte code offset #124
/* 270:    */     //   Java source line #135	-> byte code offset #129
/* 271:    */     //   Java source line #142	-> byte code offset #139
/* 272:    */     //   Java source line #143	-> byte code offset #144
/* 273:    */     //   Java source line #144	-> byte code offset #149
/* 274:    */     //   Java source line #145	-> byte code offset #154
/* 275:    */     //   Java source line #146	-> byte code offset #159
/* 276:    */     //   Java source line #147	-> byte code offset #171
/* 277:    */     //   Java source line #145	-> byte code offset #181
/* 278:    */     //   Java source line #146	-> byte code offset #184
/* 279:    */     //   Java source line #147	-> byte code offset #231
/* 280:    */     //   Java source line #148	-> byte code offset #266
/* 281:    */     // Local variable table:
/* 282:    */     //   start	length	slot	name	signature
/* 283:    */     //   0	275	0	this	XmlssTssTransferHandler
/* 284:    */     //   0	275	1	matrix	Matrix
/* 285:    */     //   1	1	2	localObject1	Object
/* 286:    */     //   230	15	2	localObject2	Object
/* 287:    */     //   249	15	2	localObject3	Object
/* 288:    */     //   265	6	2	ex	XMLStreamException
/* 289:    */     //   3	1	3	localObject4	Object
/* 290:    */     //   243	17	3	localThrowable1	java.lang.Throwable
/* 291:    */     //   11	226	4	stream	java.io.ByteArrayOutputStream
/* 292:    */     //   21	20	5	xml	XMLStreamWriter
/* 293:    */     //   24	1	6	localObject5	Object
/* 294:    */     //   182	20	6	localObject6	Object
/* 295:    */     //   208	20	6	localObject7	Object
/* 296:    */     //   27	1	7	localObject8	Object
/* 297:    */     //   199	24	7	localThrowable2	java.lang.Throwable
/* 298:    */     //   34	156	8	c	java.io.Closeable
/* 299:    */     //   45	105	9	xmlss	XmlssWriterFacade
/* 300:    */     //   86	31	10	row	ec.tstoolkit.data.DataBlock
/* 301:    */     //   71	59	11	localIterator	Iterator
/* 302:    */     //   94	21	12	idx	int
/* 303:    */     // Exception table:
/* 304:    */     //   from	to	target	type
/* 305:    */     //   36	159	182	finally
/* 306:    */     //   171	182	182	finally
/* 307:    */     //   29	199	199	finally
/* 308:    */     //   13	171	230	finally
/* 309:    */     //   181	230	230	finally
/* 310:    */     //   4	243	243	finally
/* 311:    */     //   0	181	265	javax/xml/stream/XMLStreamException
/* 312:    */     //   182	265	265	javax/xml/stream/XMLStreamException
/* 313:    */   }
/* 314:    */   
/* 315:    */   public Config getConfig()
/* 316:    */   {
/* 317:156 */     return configurator.getConfig(this);
/* 318:    */   }
/* 319:    */   
/* 320:    */   public void setConfig(Config config)
/* 321:    */   {
/* 322:161 */     configurator.setConfig(this, config);
/* 323:    */   }
/* 324:    */   
/* 325:    */   public Config editConfig(Config config)
/* 326:    */   {
/* 327:166 */     return configurator.editConfig(config);
/* 328:    */   }
/* 329:    */   
/* 330:    */   /* Error */
/* 331:    */   public byte[] tsCollectionToBytes(TsCollection col)
/* 332:    */     throws IOException
/* 333:    */   {
/* 334:    */     // Byte code:
/* 335:    */     //   0: aconst_null
/* 336:    */     //   1: astore_2
/* 337:    */     //   2: aconst_null
/* 338:    */     //   3: astore_3
/* 339:    */     //   4: new 157	java/io/ByteArrayOutputStream
/* 340:    */     //   7: dup
/* 341:    */     //   8: invokespecial 159	java/io/ByteArrayOutputStream:<init>	()V
/* 342:    */     //   11: astore 4
/* 343:    */     //   13: invokestatic 160	javax/xml/stream/XMLOutputFactory:newInstance	()Ljavax/xml/stream/XMLOutputFactory;
/* 344:    */     //   16: aload 4
/* 345:    */     //   18: invokevirtual 166	javax/xml/stream/XMLOutputFactory:createXMLStreamWriter	(Ljava/io/OutputStream;)Ljavax/xml/stream/XMLStreamWriter;
/* 346:    */     //   21: astore 5
/* 347:    */     //   23: aconst_null
/* 348:    */     //   24: astore 6
/* 349:    */     //   26: aconst_null
/* 350:    */     //   27: astore 7
/* 351:    */     //   29: aload 5
/* 352:    */     //   31: invokestatic 170	ec/tstoolkit/utilities/Closeables:asCloseable	(Ljavax/xml/stream/XMLStreamWriter;)Ljava/io/Closeable;
/* 353:    */     //   34: astore 8
/* 354:    */     //   36: aload_0
/* 355:    */     //   37: aload_1
/* 356:    */     //   38: new 176	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade
/* 357:    */     //   41: dup
/* 358:    */     //   42: aload 5
/* 359:    */     //   44: invokespecial 178	ec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade:<init>	(Ljavax/xml/stream/XMLStreamWriter;)V
/* 360:    */     //   47: invokespecial 291	ec/tss/datatransfer/impl/XmlssTssTransferHandler:write	(Lec/tss/TsCollection;Lec/tss/datatransfer/impl/XmlssTssTransferHandler$XmlssWriterFacade;)V
/* 361:    */     //   50: aload 4
/* 362:    */     //   52: invokevirtual 238	java/io/ByteArrayOutputStream:toByteArray	()[B
/* 363:    */     //   55: aload 8
/* 364:    */     //   57: ifnull +10 -> 67
/* 365:    */     //   60: aload 8
/* 366:    */     //   62: invokeinterface 242 1 0
/* 367:    */     //   67: aload 4
/* 368:    */     //   69: ifnull +8 -> 77
/* 369:    */     //   72: aload 4
/* 370:    */     //   74: invokevirtual 247	java/io/ByteArrayOutputStream:close	()V
/* 371:    */     //   77: areturn
/* 372:    */     //   78: astore 6
/* 373:    */     //   80: aload 8
/* 374:    */     //   82: ifnull +10 -> 92
/* 375:    */     //   85: aload 8
/* 376:    */     //   87: invokeinterface 242 1 0
/* 377:    */     //   92: aload 6
/* 378:    */     //   94: athrow
/* 379:    */     //   95: astore 7
/* 380:    */     //   97: aload 6
/* 381:    */     //   99: ifnonnull +10 -> 109
/* 382:    */     //   102: aload 7
/* 383:    */     //   104: astore 6
/* 384:    */     //   106: goto +17 -> 123
/* 385:    */     //   109: aload 6
/* 386:    */     //   111: aload 7
/* 387:    */     //   113: if_acmpeq +10 -> 123
/* 388:    */     //   116: aload 6
/* 389:    */     //   118: aload 7
/* 390:    */     //   120: invokevirtual 248	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 391:    */     //   123: aload 6
/* 392:    */     //   125: athrow
/* 393:    */     //   126: astore_2
/* 394:    */     //   127: aload 4
/* 395:    */     //   129: ifnull +8 -> 137
/* 396:    */     //   132: aload 4
/* 397:    */     //   134: invokevirtual 247	java/io/ByteArrayOutputStream:close	()V
/* 398:    */     //   137: aload_2
/* 399:    */     //   138: athrow
/* 400:    */     //   139: astore_3
/* 401:    */     //   140: aload_2
/* 402:    */     //   141: ifnonnull +8 -> 149
/* 403:    */     //   144: aload_3
/* 404:    */     //   145: astore_2
/* 405:    */     //   146: goto +13 -> 159
/* 406:    */     //   149: aload_2
/* 407:    */     //   150: aload_3
/* 408:    */     //   151: if_acmpeq +8 -> 159
/* 409:    */     //   154: aload_2
/* 410:    */     //   155: aload_3
/* 411:    */     //   156: invokevirtual 248	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/* 412:    */     //   159: aload_2
/* 413:    */     //   160: athrow
/* 414:    */     //   161: astore_2
/* 415:    */     //   162: new 109	java/io/IOException
/* 416:    */     //   165: dup
/* 417:    */     //   166: aload_2
/* 418:    */     //   167: invokespecial 254	java/io/IOException:<init>	(Ljava/lang/Throwable;)V
/* 419:    */     //   170: athrow
/* 420:    */     // Line number table:
/* 421:    */     //   Java source line #171	-> byte code offset #0
/* 422:    */     //   Java source line #172	-> byte code offset #13
/* 423:    */     //   Java source line #173	-> byte code offset #23
/* 424:    */     //   Java source line #173	-> byte code offset #29
/* 425:    */     //   Java source line #174	-> byte code offset #36
/* 426:    */     //   Java source line #175	-> byte code offset #50
/* 427:    */     //   Java source line #176	-> byte code offset #55
/* 428:    */     //   Java source line #177	-> byte code offset #67
/* 429:    */     //   Java source line #175	-> byte code offset #77
/* 430:    */     //   Java source line #176	-> byte code offset #80
/* 431:    */     //   Java source line #177	-> byte code offset #127
/* 432:    */     //   Java source line #178	-> byte code offset #162
/* 433:    */     // Local variable table:
/* 434:    */     //   start	length	slot	name	signature
/* 435:    */     //   0	171	0	this	XmlssTssTransferHandler
/* 436:    */     //   0	171	1	col	TsCollection
/* 437:    */     //   1	1	2	localObject1	Object
/* 438:    */     //   126	15	2	localObject2	Object
/* 439:    */     //   145	15	2	localObject3	Object
/* 440:    */     //   161	6	2	ex	XMLStreamException
/* 441:    */     //   3	1	3	localObject4	Object
/* 442:    */     //   139	17	3	localThrowable1	java.lang.Throwable
/* 443:    */     //   11	122	4	stream	java.io.ByteArrayOutputStream
/* 444:    */     //   21	22	5	xml	XMLStreamWriter
/* 445:    */     //   24	1	6	localObject5	Object
/* 446:    */     //   78	20	6	localObject6	Object
/* 447:    */     //   104	20	6	localObject7	Object
/* 448:    */     //   27	1	7	localObject8	Object
/* 449:    */     //   95	24	7	localThrowable2	java.lang.Throwable
/* 450:    */     //   34	52	8	c	java.io.Closeable
/* 451:    */     // Exception table:
/* 452:    */     //   from	to	target	type
/* 453:    */     //   36	55	78	finally
/* 454:    */     //   67	78	78	finally
/* 455:    */     //   29	95	95	finally
/* 456:    */     //   13	67	126	finally
/* 457:    */     //   77	126	126	finally
/* 458:    */     //   4	139	139	finally
/* 459:    */     //   0	77	161	javax/xml/stream/XMLStreamException
/* 460:    */     //   78	161	161	javax/xml/stream/XMLStreamException
/* 461:    */   }
/* 462:    */   
/* 463:    */   public TsCollection tsCollectionFromBytes(byte[] bytes)
/* 464:    */     throws IOException
/* 465:    */   {
/* 466:184 */     ByteArrayInputStream mem = new ByteArrayInputStream(bytes, 0, bytes.length - 2);
/* 467:185 */     TsCollection result = null;
/* 468:    */     try {
/* 469:187 */       XMLInputFactory xmlif = XMLInputFactory.newInstance();
/* 470:188 */       XMLStreamReader xmlr = xmlif.createXMLStreamReader(mem);
/* 471:189 */       int cols = 0;
/* 472:190 */       int rows = 0;
/* 473:191 */       int colnum = 0;
/* 474:192 */       int rownum = 0;
/* 475:193 */       boolean datesAreVertical = true;
/* 476:    */       
/* 477:195 */       while (xmlr.hasNext()) {
/* 478:196 */         xmlr.next();
/* 479:197 */         String type; if (xmlr.getEventType() == 1) {
/* 480:198 */           if (xmlr.getLocalName().equals("Row")) {
/* 481:199 */             cols = Math.max(cols, colnum);
/* 482:200 */             colnum = 0;
/* 483:201 */             int count = xmlr.getAttributeCount();
/* 484:202 */             for (int i = 0; i < count; i++) {
/* 485:203 */               if (xmlr.getAttributeLocalName(i).equals("Index")) {
/* 486:204 */                 rows = Integer.parseInt(xmlr.getAttributeValue(i)) - 1;
/* 487:    */               }
/* 488:    */             }
/* 489:207 */           } else if (xmlr.getLocalName().equals("Cell")) {
/* 490:208 */             int count = xmlr.getAttributeCount();
/* 491:209 */             for (int i = 0; i < count; i++) {
/* 492:210 */               if (xmlr.getAttributeLocalName(i).equals("Index")) {
/* 493:211 */                 colnum = Integer.parseInt(xmlr.getAttributeValue(i)) - 1;
/* 494:    */               }
/* 495:    */             }
/* 496:214 */           } else if ((xmlr.getLocalName().equals("Data")) && 
/* 497:215 */             (colnum == 0)) {
/* 498:216 */             type = "";
/* 499:217 */             int count = xmlr.getAttributeCount();
/* 500:218 */             for (int i = 0; i < count; i++) {
/* 501:219 */               if (xmlr.getAttributeLocalName(i).equals("Type")) {
/* 502:220 */                 type = xmlr.getAttributeValue(i);
/* 503:221 */                 datesAreVertical = type.equals("DateTime");
/* 504:    */               }
/* 505:    */             }
/* 506:    */           }
/* 507:225 */         } else if (xmlr.getEventType() == 2) {
/* 508:226 */           switch ((type = xmlr.getLocalName()).hashCode()) {case 82362:  if (type.equals("Row")) break; break; case 2096514:  if (!type.equals("Cell"))
/* 509:    */             {
/* 510:    */               continue;rows++;
/* 511:    */             }
/* 512:    */             else {
/* 513:231 */               colnum++;
/* 514:    */             }
/* 515:    */             break;
/* 516:    */           }
/* 517:    */         }
/* 518:    */       }
/* 519:237 */       mem.reset();
/* 520:238 */       xmlr = xmlif.createXMLStreamReader(mem);
/* 521:239 */       if ((cols < 1) || (rows < 1)) {
/* 522:240 */         return null;
/* 523:    */       }
/* 524:242 */       Matrix datamatrix = new Matrix(rows, cols);
/* 525:243 */       for (int i = 0; i < rows; i++) {
/* 526:244 */         for (int j = 0; j < cols; j++) {
/* 527:245 */           datamatrix.set(i, j, (0.0D / 0.0D));
/* 528:    */         }
/* 529:    */       }
/* 530:248 */       Date[] dates = new Date[datesAreVertical ? rows : cols];
/* 531:249 */       String[] titles = new String[datesAreVertical ? cols : rows];
/* 532:250 */       rownum = 0;
/* 533:251 */       colnum = 0;
/* 534:    */       
/* 535:253 */       while (xmlr.hasNext()) {
/* 536:254 */         xmlr.next();
/* 537:255 */         String type; if (xmlr.getEventType() == 1) { String str1;
/* 538:256 */           switch ((str1 = xmlr.getLocalName()).hashCode()) {case 82362:  if (str1.equals("Row")) break; break; case 2096514:  if (str1.equals("Cell")) {} break; case 2122698:  if (!str1.equals("Data"))
/* 539:    */             {
/* 540:258 */               continue;colnum = 0;
/* 541:259 */               int count = xmlr.getAttributeCount();
/* 542:260 */               for (int i = 0; i < count; i++) {
/* 543:261 */                 if (xmlr.getAttributeLocalName(i).equals("Index")) {
/* 544:262 */                   rownum = Integer.parseInt(xmlr.getAttributeValue(i)) - 1;
/* 545:    */                 }
/* 546:    */               }
/* 547:265 */               continue;
/* 548:    */               
/* 549:    */ 
/* 550:268 */               int count = xmlr.getAttributeCount();
/* 551:269 */               for (int i = 0; i < count; i++) {
/* 552:270 */                 if (xmlr.getAttributeLocalName(i).equals("Index")) {
/* 553:271 */                   colnum = Integer.parseInt(xmlr.getAttributeValue(i)) - 1;
/* 554:    */                 }
/* 555:    */               }
/* 556:    */             }
/* 557:    */             else
/* 558:    */             {
/* 559:277 */               type = "";
/* 560:278 */               int count = xmlr.getAttributeCount();
/* 561:279 */               for (int i = 0; i < count; i++) {
/* 562:280 */                 if (xmlr.getAttributeLocalName(i).equals("Type")) {
/* 563:281 */                   type = xmlr.getAttributeValue(i);
/* 564:    */                 }
/* 565:    */               }
/* 566:284 */               String str = xmlr.getElementText();
/* 567:285 */               switch ((localObject = type).hashCode()) {case -1950496919:  if (((String)localObject).equals("Number")) {} break; case -1808118735:  if (((String)localObject).equals("String")) break; break; case 1857393595:  if (!((String)localObject).equals("DateTime"))
/* 568:    */                 {
/* 569:287 */                   continue;titles[(datesAreVertical ? colnum : rownum)] = str;
/* 570:288 */                   continue;
/* 571:    */                   try
/* 572:    */                   {
/* 573:291 */                     double valy = numberFormat.parse(str).doubleValue();
/* 574:292 */                     datamatrix.set(rownum, colnum, valy);
/* 575:    */                   }
/* 576:    */                   catch (Exception localException) {}
/* 577:    */                 }
/* 578:    */                 else {
/* 579:    */                   try {
/* 580:298 */                     Date date = dateFormat.parse(str);
/* 581:299 */                     dates[(datesAreVertical ? rownum : colnum)] = date;
/* 582:    */                   } catch (Exception localException1) {}
/* 583:    */                 }
/* 584:    */                 break;
/* 585:    */               }
/* 586:    */             }
/* 587:    */             break;
/* 588:    */           }
/* 589:307 */         } else if (xmlr.getEventType() == 2) {
/* 590:308 */           switch ((type = xmlr.getLocalName()).hashCode()) {case 82362:  if (type.equals("Row")) break; break; case 2096514:  if (!type.equals("Cell"))
/* 591:    */             {
/* 592:    */               continue;rownum++;
/* 593:    */             }
/* 594:    */             else {
/* 595:313 */               colnum++;
/* 596:    */             }
/* 597:    */             break;
/* 598:    */           }
/* 599:    */         }
/* 600:    */       }
/* 601:319 */       TsCollectionAnalyser analyser = new TsCollectionAnalyser();
/* 602:    */       
/* 603:321 */       data = (datesAreVertical ? datamatrix : datamatrix.transpose());
/* 604:322 */       dates = dates;
/* 605:323 */       titles = titles;
/* 606:324 */       result = analyser.create();
/* 607:325 */       xmlr.close();
/* 608:    */       
/* 609:327 */       for (Object localObject = result.iterator(); ((Iterator)localObject).hasNext();) { Ts s = (Ts)((Iterator)localObject).next();
/* 610:328 */         if (s.hasData() == TsStatus.Valid) {
/* 611:329 */           s.set(s.getTsData());
/* 612:    */         }
/* 613:    */       }
/* 614:    */     } catch (XMLStreamException ex) {
/* 615:333 */       throw new IOException("Problem while retrieving data", ex);
/* 616:    */     }
/* 617:335 */     return result;
/* 618:    */   }
/* 619:    */   
/* 620:    */   private void write(TsCollection col, XmlssWriterFacade writer) throws XMLStreamException {
/* 621:339 */     writer.beginWorkbook();
/* 622:340 */     writer.beginWorksheet();
/* 623:    */     
/* 624:342 */     TsCollectionAnalyser analyser = new TsCollectionAnalyser();
/* 625:343 */     analyser.set(col, config.beginPeriod);
/* 626:    */     
/* 627:345 */     if ((data != null) && (dates != null) && (titles != null))
/* 628:    */     {
/* 629:347 */       writer.beginTable();
/* 630:    */       
/* 631:349 */       int nbdates = dates.length;
/* 632:350 */       int nseries = titles.length;
/* 633:351 */       if (config.vertical)
/* 634:    */       {
/* 635:    */ 
/* 636:354 */         if (config.showTitle) {
/* 637:355 */           writer.beginRow();
/* 638:356 */           if (config.showDates) {
/* 639:357 */             writer.writeCell("");
/* 640:    */           }
/* 641:359 */           for (int i = 0; i < nseries; i++) {
/* 642:360 */             writer.writeCell(titles[i]);
/* 643:    */           }
/* 644:362 */           writer.endRow();
/* 645:    */         }
/* 646:    */         
/* 647:365 */         for (int i = 0; i < nbdates; i++) {
/* 648:366 */           writer.beginRow();
/* 649:367 */           if (config.showDates) {
/* 650:368 */             writer.writeCell(dates[i]);
/* 651:    */           }
/* 652:370 */           for (int j = 0; j < nseries; j++) {
/* 653:371 */             writer.writeCell(data.get(i, j));
/* 654:    */           }
/* 655:373 */           writer.endRow();
/* 656:    */         }
/* 657:    */       }
/* 658:    */       else {
/* 659:377 */         if (config.showDates) {
/* 660:378 */           writer.beginRow();
/* 661:379 */           if (config.showTitle) {
/* 662:380 */             writer.writeCell("");
/* 663:    */           }
/* 664:382 */           for (int i = 0; i < nbdates; i++) {
/* 665:383 */             writer.writeCell(dates[i]);
/* 666:    */           }
/* 667:385 */           writer.endRow();
/* 668:    */         }
/* 669:387 */         for (int i = 0; i < nseries; i++) {
/* 670:388 */           writer.beginRow();
/* 671:389 */           if (config.showTitle) {
/* 672:390 */             writer.writeCell(titles[i]);
/* 673:    */           }
/* 674:392 */           for (int j = 0; j < nbdates; j++) {
/* 675:393 */             writer.writeCell(data.get(j, i));
/* 676:    */           }
/* 677:395 */           writer.endRow();
/* 678:    */         }
/* 679:    */       }
/* 680:398 */       writer.endTable();
/* 681:    */     }
/* 682:400 */     writer.endWorksheet();
/* 683:401 */     writer.endWorkbook();
/* 684:    */   }
/* 685:    */   
/* 686:    */   static class XmlssWriterFacade
/* 687:    */   {
/* 688:    */     final XMLStreamWriter writer;
/* 689:    */     private final NumberFormat numberFormat;
/* 690:    */     private final DateFormat dateFormat;
/* 691:    */     
/* 692:    */     public XmlssWriterFacade(XMLStreamWriter writer) {
/* 693:411 */       this.writer = writer;
/* 694:412 */       numberFormat = NumberFormat.getNumberInstance(Locale.ROOT);
/* 695:413 */       numberFormat.setMaximumFractionDigits(9);
/* 696:414 */       numberFormat.setMaximumIntegerDigits(12);
/* 697:415 */       dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/* 698:    */     }
/* 699:    */     
/* 700:    */     public void beginWorkbook() throws XMLStreamException {
/* 701:419 */       writer.writeStartDocument();
/* 702:420 */       writer.writeStartElement("Workbook");
/* 703:421 */       writer.writeAttribute("xmlns", "urn:schemas-microsoft-com:office:spreadsheet");
/* 704:422 */       writer.writeAttribute("xmlns:o", "urn:schemas-microsoft-com:office:office");
/* 705:423 */       writer.writeAttribute("xmlns:x", "urn:schemas-microsoft-com:office:excel");
/* 706:424 */       writer.writeAttribute("xmlns:ss", "urn:schemas-microsoft-com:office:spreadsheet");
/* 707:425 */       writer.writeAttribute("xmlns:html", "http://www.w3.org/TR/REC-html40");
/* 708:426 */       writer.writeStartElement("Styles");
/* 709:427 */       writer.writeStartElement("Style");
/* 710:428 */       writer.writeAttribute("ss:ID", "s24");
/* 711:429 */       writer.writeStartElement("NumberFormat");
/* 712:430 */       writer.writeAttribute("ss:Format", "Short Date");
/* 713:431 */       writer.writeEndElement();
/* 714:432 */       writer.writeEndElement();
/* 715:433 */       writer.writeEndElement();
/* 716:    */     }
/* 717:    */     
/* 718:    */     public void endWorkbook() throws XMLStreamException {
/* 719:437 */       writer.writeEndElement();
/* 720:438 */       writer.writeEndDocument();
/* 721:439 */       writer.flush();
/* 722:    */     }
/* 723:    */     
/* 724:    */     public void beginWorksheet() throws XMLStreamException {
/* 725:443 */       writer.writeStartElement("Worksheet");
/* 726:444 */       writer.writeAttribute("ss:Name", "Sheet1");
/* 727:    */     }
/* 728:    */     
/* 729:    */     public void endWorksheet() throws XMLStreamException {
/* 730:448 */       writer.writeEndElement();
/* 731:449 */       writer.flush();
/* 732:    */     }
/* 733:    */     
/* 734:    */     public void beginTable() throws XMLStreamException {
/* 735:453 */       writer.writeStartElement("Table");
/* 736:    */     }
/* 737:    */     
/* 738:    */     public void endTable() throws XMLStreamException {
/* 739:457 */       writer.writeEndElement();
/* 740:    */     }
/* 741:    */     
/* 742:    */     public void beginRow() throws XMLStreamException {
/* 743:461 */       writer.writeStartElement("Row");
/* 744:    */     }
/* 745:    */     
/* 746:    */     public void endRow() throws XMLStreamException {
/* 747:465 */       writer.writeEndElement();
/* 748:    */     }
/* 749:    */     
/* 750:    */     public void writeCell(Date date) throws XMLStreamException {
/* 751:469 */       writer.writeStartElement("Cell");
/* 752:470 */       writer.writeAttribute("ss:StyleID", "s24");
/* 753:471 */       writer.writeStartElement("Data");
/* 754:472 */       writer.writeAttribute("ss:Type", "DateTime");
/* 755:473 */       String sd = dateFormat.format(date);
/* 756:474 */       writer.writeCharacters(sd);
/* 757:475 */       writer.writeEndElement();
/* 758:476 */       writer.writeEndElement();
/* 759:    */     }
/* 760:    */     
/* 761:    */     public void writeCell(double val) throws XMLStreamException {
/* 762:480 */       writer.writeStartElement("Cell");
/* 763:481 */       writer.writeStartElement("Data");
/* 764:482 */       if (!Double.isNaN(val)) {
/* 765:483 */         writer.writeAttribute("ss:Type", "Number");
/* 766:484 */         writer.writeCharacters(numberFormat.format(val));
/* 767:    */       } else {
/* 768:486 */         writer.writeAttribute("ss:Type", "String");
/* 769:487 */         writer.writeCharacters("");
/* 770:    */       }
/* 771:489 */       writer.writeEndElement();
/* 772:490 */       writer.writeEndElement();
/* 773:    */     }
/* 774:    */     
/* 775:    */     public void writeCell(String txt) throws XMLStreamException {
/* 776:494 */       writer.writeStartElement("Cell");
/* 777:495 */       writer.writeStartElement("Data");
/* 778:496 */       writer.writeAttribute("ss:Type", "String");
/* 779:497 */       writer.writeCharacters(Strings.nullToEmpty(txt));
/* 780:498 */       writer.writeEndElement();
/* 781:499 */       writer.writeEndElement();
/* 782:    */     }
/* 783:    */   }
/* 784:    */   
/* 785:    */   private static DataFlavor createXmlssDataFlavor() {
/* 786:504 */     DataFlavor result = null;
/* 787:    */     try {
/* 788:506 */       result = SystemFlavorMap.decodeDataFlavor("XML Spreadsheet");
/* 789:    */     }
/* 790:    */     catch (ClassNotFoundException localClassNotFoundException) {}
/* 791:509 */     if (result == null) {
/* 792:510 */       result = new DataFlavor("xml/x;class=\"[B\"", "XML Spreadsheet");
/* 793:511 */       SystemFlavorMap map = (SystemFlavorMap)SystemFlavorMap.getDefaultFlavorMap();
/* 794:512 */       map.addUnencodedNativeForFlavor(result, "XML Spreadsheet");
/* 795:513 */       map.addFlavorForUnencodedNative("XML Spreadsheet", result);
/* 796:514 */       return result;
/* 797:    */     }
/* 798:516 */     return result;
/* 799:    */   }
/* 800:    */   
/* 801:    */ 
/* 802:    */ 
/* 803:    */ 
/* 804:    */   public static final class InternalConfig
/* 805:    */   {
/* 806:524 */     public boolean vertical = true;
/* 807:    */     
/* 808:    */ 
/* 809:    */ 
/* 810:528 */     public boolean showDates = true;
/* 811:    */     
/* 812:    */ 
/* 813:    */ 
/* 814:532 */     public boolean showTitle = true;
/* 815:    */     
/* 816:    */ 
/* 817:    */ 
/* 818:    */ 
/* 819:537 */     public boolean beginPeriod = true;
/* 820:538 */     public boolean importTimeSeries = true;
/* 821:539 */     public boolean exportTimeSeries = true;
/* 822:540 */     public boolean importMatrix = true;
/* 823:541 */     public boolean exportMatrix = true;
/* 824:    */   }
/* 825:    */   
/* 826:    */   private static final class InternalConfigHandler extends BeanHandler<XmlssTssTransferHandler.InternalConfig, XmlssTssTransferHandler>
/* 827:    */   {
/* 828:    */     public XmlssTssTransferHandler.InternalConfig loadBean(XmlssTssTransferHandler resource)
/* 829:    */     {
/* 830:548 */       return config;
/* 831:    */     }
/* 832:    */     
/* 833:    */     public void storeBean(XmlssTssTransferHandler resource, XmlssTssTransferHandler.InternalConfig bean)
/* 834:    */     {
/* 835:553 */       config = bean;
/* 836:    */     }
/* 837:    */   }
/* 838:    */   
/* 839:    */   private static final class InternalConfigEditor implements IBeanEditor
/* 840:    */   {
/* 841:    */     public boolean editBean(Object bean) throws IntrospectionException
/* 842:    */     {
/* 843:561 */       Sheet sheet = new Sheet();
/* 844:562 */       NodePropertySetBuilder b = new NodePropertySetBuilder();
/* 845:    */       
/* 846:564 */       b.reset("tscollection").display("Time Series");
/* 847:565 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "importTimeSeries")).display("Allow import")).add();
/* 848:566 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "exportTimeSeries")).display("Allow export")).add();
/* 849:567 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "vertical")).display("Vertical alignment")).add();
/* 850:568 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "showDates")).display("Include date headers")).add();
/* 851:569 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "showTitle")).display("Include title headers")).add();
/* 852:570 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "beginPeriod")).display("Begin period")).add();
/* 853:571 */       sheet.put(b.build());
/* 854:572 */       b.reset("matrix").display("Matrix");
/* 855:    */       
/* 856:574 */       ((NodePropertySetBuilder.BooleanStep)((NodePropertySetBuilder.BooleanStep)b.withBoolean().selectField(bean, "exportMatrix")).display("Allow export")).add();
/* 857:575 */       sheet.put(b.build());
/* 858:    */       
/* 859:577 */       return OpenIdePropertySheetBeanEditor.editSheet(sheet, "Configure XML Spreadsheet (XMLSS)", 
/* 860:578 */         ImageUtilities.icon2Image(DemetraUiIcon.CLIPBOARD_PASTE_DOCUMENT_TEXT_16));
/* 861:    */     }
/* 862:    */   }
/* 863:    */   
/* 864:    */   private static final class InternalConfigConverter extends Converter<XmlssTssTransferHandler.InternalConfig, Config>
/* 865:    */   {
/* 866:584 */     private static final String DOMAIN = TssTransferHandler.class.getName();
/* 867:585 */     private static final String NAME = "XMLSS"; private static final String VERSION = ""; private static final IParam<Config, Boolean> VERTICAL = Params.onBoolean(Boolean.valueOf(true), "vertical");
/* 868:586 */     private static final IParam<Config, Boolean> SHOW_DATES = Params.onBoolean(Boolean.valueOf(true), "showDates");
/* 869:587 */     private static final IParam<Config, Boolean> SHOW_TITLE = Params.onBoolean(Boolean.valueOf(true), "showTitle");
/* 870:588 */     private static final IParam<Config, Boolean> BEGIN_PERIOD = Params.onBoolean(Boolean.valueOf(true), "beginPeriod");
/* 871:589 */     private static final IParam<Config, Boolean> IMPORT_TS = Params.onBoolean(Boolean.valueOf(true), "importEnabled");
/* 872:590 */     private static final IParam<Config, Boolean> EXPORT_TS = Params.onBoolean(Boolean.valueOf(true), "exportEnabled");
/* 873:591 */     private static final IParam<Config, Boolean> IMPORT_MATRIX = Params.onBoolean(Boolean.valueOf(true), "importMatrix");
/* 874:592 */     private static final IParam<Config, Boolean> EXPORT_MATRIX = Params.onBoolean(Boolean.valueOf(true), "exportMatrix");
/* 875:    */     
/* 876:    */     protected Config doForward(XmlssTssTransferHandler.InternalConfig a)
/* 877:    */     {
/* 878:596 */       Config.Builder b = Config.builder(DOMAIN, "XMLSS", "");
/* 879:597 */       VERTICAL.set(b, Boolean.valueOf(vertical));
/* 880:598 */       SHOW_DATES.set(b, Boolean.valueOf(showDates));
/* 881:599 */       SHOW_TITLE.set(b, Boolean.valueOf(showTitle));
/* 882:600 */       BEGIN_PERIOD.set(b, Boolean.valueOf(beginPeriod));
/* 883:601 */       IMPORT_TS.set(b, Boolean.valueOf(importTimeSeries));
/* 884:602 */       EXPORT_TS.set(b, Boolean.valueOf(exportTimeSeries));
/* 885:603 */       IMPORT_MATRIX.set(b, Boolean.valueOf(importMatrix));
/* 886:604 */       EXPORT_MATRIX.set(b, Boolean.valueOf(exportMatrix));
/* 887:605 */       return b.build();
/* 888:    */     }
/* 889:    */     
/* 890:    */     protected XmlssTssTransferHandler.InternalConfig doBackward(Config config)
/* 891:    */     {
/* 892:610 */       Preconditions.checkArgument(DOMAIN.equals(config.getDomain()));
/* 893:611 */       Preconditions.checkArgument("XMLSS".equals(config.getName()));
/* 894:612 */       XmlssTssTransferHandler.InternalConfig result = new XmlssTssTransferHandler.InternalConfig();
/* 895:613 */       vertical = ((Boolean)VERTICAL.get(config)).booleanValue();
/* 896:614 */       showDates = ((Boolean)SHOW_DATES.get(config)).booleanValue();
/* 897:615 */       showTitle = ((Boolean)SHOW_TITLE.get(config)).booleanValue();
/* 898:616 */       beginPeriod = ((Boolean)BEGIN_PERIOD.get(config)).booleanValue();
/* 899:617 */       importTimeSeries = ((Boolean)IMPORT_TS.get(config)).booleanValue();
/* 900:618 */       exportTimeSeries = ((Boolean)EXPORT_TS.get(config)).booleanValue();
/* 901:619 */       importMatrix = ((Boolean)IMPORT_MATRIX.get(config)).booleanValue();
/* 902:620 */       exportMatrix = ((Boolean)EXPORT_MATRIX.get(config)).booleanValue();
/* 903:621 */       return result;
/* 904:    */     }
/* 905:    */   }
/* 906:    */ }
