/*  1:   */ package ec.tss.datatransfer.impl;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.tss.datatransfer.DataSourceTransferHandler;
/*  5:   */ import ec.tss.datatransfer.DataTransfers;
/*  6:   */ import ec.tss.tsproviders.DataSource;
/*  7:   */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  8:   */ import java.awt.datatransfer.Transferable;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ public abstract class ParserTransferHandler
/* 19:   */   extends DataSourceTransferHandler
/* 20:   */ {
/* 21:   */   protected abstract Parsers.Parser<DataSource> getParser();
/* 22:   */   
/* 23:   */   public boolean canHandle(Transferable t)
/* 24:   */   {
/* 25:25 */     return getDataSource(t).isPresent();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean canHandle(Transferable t, String providerName)
/* 29:   */   {
/* 30:30 */     Optional<DataSource> dataSource = getDataSource(t);
/* 31:31 */     return (dataSource.isPresent()) && (((DataSource)dataSource.get()).getProviderName().equals(providerName));
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Optional<DataSource> getDataSource(Transferable t)
/* 35:   */   {
/* 36:36 */     return DataTransfers.tryParse(t, getParser());
/* 37:   */   }
/* 38:   */   
/* 39:   */   public Optional<DataSource> getDataSource(Transferable t, String providerName)
/* 40:   */   {
/* 41:41 */     Optional<DataSource> result = getDataSource(t);
/* 42:42 */     return (result.isPresent()) && (((DataSource)result.get()).getProviderName().equals(providerName)) ? result : Optional.absent();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public static class XmlParserHandler
/* 46:   */     extends ParserTransferHandler
/* 47:   */   {
/* 48:   */     protected Parsers.Parser<DataSource> getParser()
/* 49:   */     {
/* 50:50 */       return DataSource.xmlParser();
/* 51:   */     }
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static class UriParserHandler
/* 55:   */     extends ParserTransferHandler
/* 56:   */   {
/* 57:   */     protected Parsers.Parser<DataSource> getParser()
/* 58:   */     {
/* 59:59 */       return DataSource.uriParser();
/* 60:   */     }
/* 61:   */   }
/* 62:   */ }
