/*  1:   */ package ec.tss.datatransfer.impl;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import ec.nbdemetra.ui.tsproviders.DataSourceProviderBuddySupport;
/*  5:   */ import ec.nbdemetra.ui.tsproviders.IDataSourceProviderBuddy;
/*  6:   */ import ec.nbdemetra.ui.tsproviders.actions.OpenProvidersAction;
/*  7:   */ import ec.tss.datatransfer.DataSourceTransferHandler;
/*  8:   */ import ec.tss.datatransfer.DataTransfers;
/*  9:   */ import ec.tss.tsproviders.DataSource;
/* 10:   */ import ec.tss.tsproviders.IDataSourceProvider;
/* 11:   */ import ec.tss.tsproviders.IFileBean;
/* 12:   */ import ec.tss.tsproviders.IFileLoader;
/* 13:   */ import ec.tss.tsproviders.TsProviders;
/* 14:   */ import java.awt.datatransfer.Transferable;
/* 15:   */ import java.beans.IntrospectionException;
/* 16:   */ import java.io.File;
/* 17:   */ import java.util.List;
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public class FileTransferHandler
/* 27:   */   extends DataSourceTransferHandler
/* 28:   */ {
/* 29:   */   public boolean canHandle(Transferable t)
/* 30:   */   {
/* 31:31 */     Optional<File> file = DataTransfers.getSingleFile(t);
/* 32:32 */     return (file.isPresent()) && (!OpenProvidersAction.getLoaders((File)file.get()).isEmpty());
/* 33:   */   }
/* 34:   */   
/* 35:   */   public boolean canHandle(Transferable t, String providerName)
/* 36:   */   {
/* 37:37 */     Optional<File> file = DataTransfers.getSingleFile(t);
/* 38:38 */     if (file.isPresent()) {
/* 39:39 */       Optional<IFileLoader> loader = TsProviders.lookup(IFileLoader.class, providerName);
/* 40:40 */       return loader.isPresent() ? ((IFileLoader)loader.get()).accept((File)file.get()) : false;
/* 41:   */     }
/* 42:42 */     return false;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Optional<DataSource> getDataSource(Transferable t)
/* 46:   */   {
/* 47:47 */     File file = (File)DataTransfers.getSingleFile(t).get();
/* 48:48 */     List<IFileLoader> loaders = OpenProvidersAction.getLoaders(file);
/* 49:49 */     Optional<IFileLoader> loader = OpenProvidersAction.chooseLoader(loaders);
/* 50:50 */     if (loader.isPresent()) {
/* 51:51 */       IFileBean bean = ((IFileLoader)loader.get()).newBean();
/* 52:52 */       bean.setFile(file);
/* 53:   */       try {
/* 54:54 */         if (DataSourceProviderBuddySupport.getDefault().get((IDataSourceProvider)loader.get()).editBean("Open data source", bean)) {
/* 55:55 */           return Optional.of(((IFileLoader)loader.get()).encodeBean(bean));
/* 56:   */         }
/* 57:   */       }
/* 58:   */       catch (IntrospectionException localIntrospectionException) {}
/* 59:   */     }
/* 60:   */     
/* 61:61 */     return Optional.absent();
/* 62:   */   }
/* 63:   */   
/* 64:   */   public Optional<DataSource> getDataSource(Transferable t, String providerName)
/* 65:   */   {
/* 66:66 */     File file = (File)DataTransfers.getSingleFile(t).get();
/* 67:67 */     IFileLoader loader = (IFileLoader)TsProviders.lookup(IFileLoader.class, providerName).get();
/* 68:68 */     IFileBean bean = loader.newBean();
/* 69:69 */     bean.setFile(file);
/* 70:   */     try {
/* 71:71 */       if (DataSourceProviderBuddySupport.getDefault().get(loader).editBean("Open data source", bean)) {
/* 72:72 */         return Optional.of(loader.encodeBean(bean));
/* 73:   */       }
/* 74:   */     }
/* 75:   */     catch (IntrospectionException localIntrospectionException) {}
/* 76:   */     
/* 77:77 */     return Optional.absent();
/* 78:   */   }
/* 79:   */ }
