/*   1:    */ package ec.tss.datatransfer.impl;
/*   2:    */ 
/*   3:    */ import ec.tss.TsCollection;
/*   4:    */ import ec.tss.datatransfer.DataTransfers;
/*   5:    */ import ec.tss.datatransfer.TssTransferHandler;
/*   6:    */ import ec.tstoolkit.data.Table;
/*   7:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*   8:    */ import java.awt.datatransfer.DataFlavor;
/*   9:    */ import java.io.IOException;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ public class LocalObjectTssTransferHandler
/*  21:    */   extends TssTransferHandler
/*  22:    */ {
/*  23: 23 */   private static final DataFlavor LOCAL_TSCOL = DataTransfers.newLocalObjectDataFlavor(TsCollection.class);
/*  24:    */   
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */   public String getName()
/*  29:    */   {
/*  30: 30 */     return "LocalObject";
/*  31:    */   }
/*  32:    */   
/*  33:    */   public String getDisplayName()
/*  34:    */   {
/*  35: 35 */     return "Local Object";
/*  36:    */   }
/*  37:    */   
/*  38:    */   public DataFlavor getDataFlavor()
/*  39:    */   {
/*  40: 40 */     return LOCAL_TSCOL;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean canExportTsCollection(TsCollection col)
/*  44:    */   {
/*  45: 45 */     return true;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Object exportTsCollection(TsCollection col)
/*  49:    */   {
/*  50: 50 */     return col;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean canImportTsCollection(Object obj)
/*  54:    */   {
/*  55: 55 */     return obj instanceof TsCollection;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public TsCollection importTsCollection(Object obj) throws IOException
/*  59:    */   {
/*  60: 60 */     return (TsCollection)obj;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean canExportMatrix(Matrix matrix)
/*  64:    */   {
/*  65: 65 */     return true;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Object exportMatrix(Matrix matrix) throws IOException
/*  69:    */   {
/*  70: 70 */     return matrix;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean canImportMatrix(Object obj)
/*  74:    */   {
/*  75: 75 */     return obj instanceof Matrix;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Matrix importMatrix(Object obj) throws IOException, ClassCastException
/*  79:    */   {
/*  80: 80 */     return (Matrix)obj;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean canExportTable(Table<?> table)
/*  84:    */   {
/*  85: 85 */     return true;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Object exportTable(Table<?> table) throws IOException
/*  89:    */   {
/*  90: 90 */     return table;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public boolean canImportTable(Object obj)
/*  94:    */   {
/*  95: 95 */     return obj instanceof Table;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Table<?> importTable(Object obj) throws IOException, ClassCastException
/*  99:    */   {
/* 100:100 */     return (Table)obj;
/* 101:    */   }
/* 102:    */ }
