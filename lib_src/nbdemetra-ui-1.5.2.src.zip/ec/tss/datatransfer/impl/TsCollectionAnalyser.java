/*  1:   */ package ec.tss.datatransfer.impl;
/*  2:   */ 
/*  3:   */ import ec.tss.Ts;
/*  4:   */ import ec.tss.TsCollection;
/*  5:   */ import ec.tss.TsFactory;
/*  6:   */ import ec.tstoolkit.maths.matrices.Matrix;
/*  7:   */ import ec.tstoolkit.timeseries.Day;
/*  8:   */ import ec.tstoolkit.timeseries.TsAggregationType;
/*  9:   */ import ec.tstoolkit.timeseries.simplets.TsData;
/* 10:   */ import ec.tstoolkit.timeseries.simplets.TsDataCollector;
/* 11:   */ import ec.tstoolkit.timeseries.simplets.TsDataTable;
/* 12:   */ import ec.tstoolkit.timeseries.simplets.TsDataTableInfo;
/* 13:   */ import ec.tstoolkit.timeseries.simplets.TsDomain;
/* 14:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/* 15:   */ import ec.tstoolkit.timeseries.simplets.TsPeriod;
/* 16:   */ import java.util.Date;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ class TsCollectionAnalyser
/* 24:   */ {
/* 25:   */   String[] titles;
/* 26:   */   Date[] dates;
/* 27:   */   Matrix data;
/* 28:   */   
/* 29:   */   public TsCollection create()
/* 30:   */   {
/* 31:31 */     if ((titles == null) || (dates == null) || (data == null)) {
/* 32:32 */       return null;
/* 33:   */     }
/* 34:34 */     TsCollection coll = TsFactory.instance.createTsCollection();
/* 35:35 */     for (int i = 1; i < titles.length; i++) {
/* 36:36 */       TsDataCollector cur = new TsDataCollector();
/* 37:37 */       for (int j = 0; j < dates.length; j++) {
/* 38:38 */         double val = data.get(j, i);
/* 39:39 */         if (!Double.isNaN(val)) {
/* 40:40 */           cur.addObservation(dates[j], val);
/* 41:   */         }
/* 42:   */       }
/* 43:43 */       TsData sdata = cur.make(TsFrequency.Undefined, TsAggregationType.None);
/* 44:44 */       Ts s = TsFactory.instance.createTs(titles[i]);
/* 45:45 */       s.set(sdata);
/* 46:46 */       coll.quietAdd(s);
/* 47:   */     }
/* 48:48 */     return coll;
/* 49:   */   }
/* 50:   */   
/* 51:   */   void set(TsCollection col, boolean begin) {
/* 52:52 */     dates = null;
/* 53:53 */     data = null;
/* 54:54 */     titles = new String[col.getCount()];
/* 55:55 */     TsDataTable table = new TsDataTable();
/* 56:   */     
/* 57:57 */     for (int i = 0; i < titles.length; i++) {
/* 58:58 */       Ts cur = col.get(i);
/* 59:59 */       table.insert(-1, cur.getTsData());
/* 60:60 */       titles[i] = cur.getName();
/* 61:   */     }
/* 62:   */     
/* 63:63 */     TsDomain domain = table.getDomain();
/* 64:64 */     if (domain == null) {
/* 65:65 */       dates = new Date[0];
/* 66:66 */       data = new Matrix(0, 0);
/* 67:67 */       return;
/* 68:   */     }
/* 69:69 */     dates = new Date[domain.getLength()];
/* 70:70 */     for (int i = 0; i < dates.length; i++) {
/* 71:71 */       if (begin) {
/* 72:72 */         dates[i] = domain.get(i).firstday().getTime();
/* 73:   */       } else {
/* 74:74 */         dates[i] = domain.get(i).lastday().getTime();
/* 75:   */       }
/* 76:   */     }
/* 77:77 */     data = new Matrix(dates.length, titles.length);
/* 78:78 */     data.set((0.0D / 0.0D));
/* 79:79 */     for (int i = 0; i < dates.length; i++) {
/* 80:80 */       for (int j = 0; j < titles.length; j++) {
/* 81:81 */         if (table.getDataInfo(i, j) == TsDataTableInfo.Valid) {
/* 82:82 */           data.set(i, j, table.getData(i, j));
/* 83:   */         }
/* 84:   */       }
/* 85:   */     }
/* 86:   */   }
/* 87:   */ }
