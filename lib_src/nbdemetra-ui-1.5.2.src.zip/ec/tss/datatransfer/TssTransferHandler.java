/*   1:    */ package ec.tss.datatransfer;
/*   2:    */ 
/*   3:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   4:    */ import ec.nbdemetra.ui.ns.INamedService;
/*   5:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*   6:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*   7:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*   8:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*   9:    */ import ec.tss.TsCollection;
/*  10:    */ import ec.tstoolkit.data.Table;
/*  11:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*  12:    */ import java.awt.Image;
/*  13:    */ import java.awt.datatransfer.DataFlavor;
/*  14:    */ import java.io.IOException;
/*  15:    */ import javax.annotation.Nonnull;
/*  16:    */ import org.openide.nodes.Sheet;
/*  17:    */ import org.openide.util.ImageUtilities;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ public abstract class TssTransferHandler
/*  42:    */   implements INamedService
/*  43:    */ {
/*  44:    */   @Nonnull
/*  45:    */   public abstract DataFlavor getDataFlavor();
/*  46:    */   
/*  47:    */   public abstract String getName();
/*  48:    */   
/*  49:    */   public String getDisplayName()
/*  50:    */   {
/*  51: 51 */     return getName();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Image getIcon(int type, boolean opened)
/*  55:    */   {
/*  56: 56 */     return ImageUtilities.icon2Image(DemetraUiIcon.CLIPBOARD_PASTE_DOCUMENT_TEXT_16);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Sheet createSheet()
/*  60:    */   {
/*  61: 61 */     Sheet result = new Sheet();
/*  62: 62 */     NodePropertySetBuilder b = new NodePropertySetBuilder();
/*  63: 63 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select("DataFlavor", getDataFlavor().getMimeType())).display("Data Flavor").add();
/*  64: 64 */     result.put(b.build());
/*  65: 65 */     return result;
/*  66:    */   }
/*  67:    */   
/*  68:    */ 
/*  69:    */   public boolean canExportTsCollection(@Nonnull TsCollection col)
/*  70:    */   {
/*  71: 71 */     return false;
/*  72:    */   }
/*  73:    */   
/*  74:    */   @Nonnull
/*  75:    */   public Object exportTsCollection(@Nonnull TsCollection col) throws IOException {
/*  76: 76 */     throw new UnsupportedOperationException();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean canImportTsCollection(@Nonnull Object obj) {
/*  80: 80 */     return false;
/*  81:    */   }
/*  82:    */   
/*  83:    */   @Nonnull
/*  84:    */   public TsCollection importTsCollection(@Nonnull Object obj) throws IOException, ClassCastException {
/*  85: 85 */     throw new UnsupportedOperationException();
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */   public boolean canExportMatrix(@Nonnull Matrix matrix)
/*  90:    */   {
/*  91: 91 */     return false;
/*  92:    */   }
/*  93:    */   
/*  94:    */   @Nonnull
/*  95:    */   public Object exportMatrix(@Nonnull Matrix matrix) throws IOException {
/*  96: 96 */     throw new UnsupportedOperationException();
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean canImportMatrix(@Nonnull Object obj) {
/* 100:100 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   @Nonnull
/* 104:    */   public Matrix importMatrix(@Nonnull Object obj) throws IOException, ClassCastException {
/* 105:105 */     throw new UnsupportedOperationException();
/* 106:    */   }
/* 107:    */   
/* 108:    */ 
/* 109:    */   public boolean canExportTable(@Nonnull Table<?> table)
/* 110:    */   {
/* 111:111 */     return false;
/* 112:    */   }
/* 113:    */   
/* 114:    */   @Nonnull
/* 115:    */   public Object exportTable(@Nonnull Table<?> table) throws IOException {
/* 116:116 */     throw new UnsupportedOperationException();
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean canImportTable(@Nonnull Object obj) {
/* 120:120 */     return false;
/* 121:    */   }
/* 122:    */   
/* 123:    */   @Nonnull
/* 124:    */   public Table<?> importTable(@Nonnull Object obj) throws IOException, ClassCastException {
/* 125:125 */     throw new UnsupportedOperationException();
/* 126:    */   }
/* 127:    */ }
