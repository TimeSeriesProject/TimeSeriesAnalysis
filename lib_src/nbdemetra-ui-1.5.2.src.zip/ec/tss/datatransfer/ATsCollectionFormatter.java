/*   1:    */ package ec.tss.datatransfer;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.collect.FluentIterable;
/*   6:    */ import com.google.common.collect.ImmutableList;
/*   7:    */ import ec.nbdemetra.ui.Config;
/*   8:    */ import ec.nbdemetra.ui.DemetraUiIcon;
/*   9:    */ import ec.nbdemetra.ui.IConfigurable;
/*  10:    */ import ec.nbdemetra.ui.ns.AbstractNamedService;
/*  11:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder;
/*  12:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.DefaultStep;
/*  13:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.PropertyStep;
/*  14:    */ import ec.nbdemetra.ui.properties.NodePropertySetBuilder.SelectStep;
/*  15:    */ import ec.tss.TsCollection;
/*  16:    */ import java.awt.Image;
/*  17:    */ import java.awt.datatransfer.DataFlavor;
/*  18:    */ import java.io.IOException;
/*  19:    */ import org.openide.nodes.Sheet;
/*  20:    */ import org.openide.util.ImageUtilities;
/*  21:    */ import org.openide.util.Lookup;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ @Deprecated
/*  39:    */ public abstract class ATsCollectionFormatter
/*  40:    */   extends AbstractNamedService
/*  41:    */   implements ITsCollectionFormatter
/*  42:    */ {
/*  43:    */   protected ATsCollectionFormatter(String name)
/*  44:    */   {
/*  45: 45 */     super(ITsCollectionFormatter.class, name);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Image getIcon(int type, boolean opened)
/*  49:    */   {
/*  50: 50 */     return ImageUtilities.icon2Image(DemetraUiIcon.CLIPBOARD_PASTE_DOCUMENT_TEXT_16);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Sheet createSheet()
/*  54:    */   {
/*  55: 55 */     Sheet result = super.createSheet();
/*  56: 56 */     NodePropertySetBuilder b = new NodePropertySetBuilder();
/*  57: 57 */     ((NodePropertySetBuilder.DefaultStep)b.with(String.class).select("DataFlavor", getDataFlavor().getMimeType())).display("Data Flavor").add();
/*  58: 58 */     result.put(b.build());
/*  59: 59 */     return result;
/*  60:    */   }
/*  61:    */   
/*  62:    */   static ImmutableList<TssTransferHandler> getLegacyHandlers() {
/*  63: 63 */     return LEGACY_HANDLERS;
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static class TssTransferHandlerAdapter extends TssTransferHandler
/*  67:    */   {
/*  68:    */     protected final ITsCollectionFormatter formatter;
/*  69:    */     
/*  70:    */     public TssTransferHandlerAdapter(ITsCollectionFormatter formatter) {
/*  71: 71 */       this.formatter = formatter;
/*  72:    */     }
/*  73:    */     
/*  74:    */     public DataFlavor getDataFlavor()
/*  75:    */     {
/*  76: 76 */       return formatter.getDataFlavor();
/*  77:    */     }
/*  78:    */     
/*  79:    */     public boolean canExportTsCollection(TsCollection col)
/*  80:    */     {
/*  81: 81 */       return formatter.canExportTransferData(col);
/*  82:    */     }
/*  83:    */     
/*  84:    */     public Object exportTsCollection(TsCollection col) throws IOException
/*  85:    */     {
/*  86: 86 */       return formatter.toTransferData(col);
/*  87:    */     }
/*  88:    */     
/*  89:    */     public boolean canImportTsCollection(Object obj)
/*  90:    */     {
/*  91: 91 */       return formatter.canImportTransferData(obj);
/*  92:    */     }
/*  93:    */     
/*  94:    */     public TsCollection importTsCollection(Object obj) throws IOException, ClassCastException
/*  95:    */     {
/*  96: 96 */       return formatter.fromTransferData(obj);
/*  97:    */     }
/*  98:    */     
/*  99:    */     public String getName()
/* 100:    */     {
/* 101:101 */       return formatter.getName();
/* 102:    */     }
/* 103:    */     
/* 104:    */     public String getDisplayName()
/* 105:    */     {
/* 106:106 */       return formatter.getDisplayName();
/* 107:    */     }
/* 108:    */     
/* 109:    */     public Image getIcon(int type, boolean opened)
/* 110:    */     {
/* 111:111 */       return formatter.getIcon(type, opened);
/* 112:    */     }
/* 113:    */     
/* 114:    */     public Sheet createSheet()
/* 115:    */     {
/* 116:116 */       return formatter.createSheet();
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static class TssTransferHandlerAdapter2 extends ATsCollectionFormatter.TssTransferHandlerAdapter implements IConfigurable
/* 121:    */   {
/* 122:    */     public TssTransferHandlerAdapter2(ITsCollectionFormatter formatter) {
/* 123:123 */       super();
/* 124:124 */       Preconditions.checkArgument(formatter instanceof IConfigurable);
/* 125:    */     }
/* 126:    */     
/* 127:    */     public Config getConfig()
/* 128:    */     {
/* 129:129 */       return ((IConfigurable)formatter).getConfig();
/* 130:    */     }
/* 131:    */     
/* 132:    */     public void setConfig(Config config) throws IllegalArgumentException
/* 133:    */     {
/* 134:134 */       ((IConfigurable)formatter).setConfig(config);
/* 135:    */     }
/* 136:    */     
/* 137:    */     public Config editConfig(Config config) throws IllegalArgumentException
/* 138:    */     {
/* 139:139 */       return ((IConfigurable)formatter).editConfig(config);
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:143 */   private static final Function<ITsCollectionFormatter, TssTransferHandler> TO_HANDLER = new Function()
/* 144:    */   {
/* 145:    */     public TssTransferHandler apply(ITsCollectionFormatter input) {
/* 146:146 */       return (input instanceof IConfigurable) ? new ATsCollectionFormatter.TssTransferHandlerAdapter2(input) : new ATsCollectionFormatter.TssTransferHandlerAdapter(input);
/* 147:    */     }
/* 148:    */   };
/* 149:149 */   private static final ImmutableList<TssTransferHandler> LEGACY_HANDLERS = FluentIterable.from(Lookup.getDefault().lookupAll(ITsCollectionFormatter.class)).transform(TO_HANDLER).toList();
/* 150:    */ }
