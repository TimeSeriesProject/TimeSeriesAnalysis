/*  1:   */ package ec.tss.datatransfer;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Optional;
/*  4:   */ import com.google.common.base.Throwables;
/*  5:   */ import ec.tss.tsproviders.utils.Formatters.Formatter;
/*  6:   */ import ec.tss.tsproviders.utils.Parsers.Parser;
/*  7:   */ import java.awt.datatransfer.DataFlavor;
/*  8:   */ import java.awt.datatransfer.StringSelection;
/*  9:   */ import java.awt.datatransfer.Transferable;
/* 10:   */ import java.awt.datatransfer.UnsupportedFlavorException;
/* 11:   */ import java.io.File;
/* 12:   */ import java.io.IOException;
/* 13:   */ import java.util.List;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public final class DataTransfers
/* 26:   */ {
/* 27:   */   public static DataFlavor newLocalObjectDataFlavor(Class<?> clazz)
/* 28:   */   {
/* 29:   */     try
/* 30:   */     {
/* 31:31 */       return new DataFlavor("application/x-java-jvm-local-objectref;class=" + clazz.getName());
/* 32:   */     } catch (ClassNotFoundException ex) {
/* 33:33 */       throw Throwables.propagate(ex);
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static Optional<File> getSingleFile(Transferable t) {
/* 38:38 */     if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
/* 39:   */       try {
/* 40:40 */         List<File> files = (List)t.getTransferData(DataFlavor.javaFileListFlavor);
/* 41:41 */         if (files.size() == 1) {
/* 42:42 */           return Optional.of((File)files.get(0));
/* 43:   */         }
/* 44:   */       } catch (UnsupportedFlavorException|IOException ex) {
/* 45:45 */         throw Throwables.propagate(ex);
/* 46:   */       }
/* 47:   */     }
/* 48:48 */     return Optional.absent();
/* 49:   */   }
/* 50:   */   
/* 51:   */   public static <T> Optional<T> tryParse(Transferable t, Parsers.Parser<T> parser) {
/* 52:52 */     if (t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
/* 53:   */       try {
/* 54:54 */         String text = (String)t.getTransferData(DataFlavor.stringFlavor);
/* 55:55 */         return text != null ? parser.tryParse(text) : Optional.absent();
/* 56:   */       } catch (UnsupportedFlavorException ex) {
/* 57:57 */         throw Throwables.propagate(ex);
/* 58:   */       } catch (IOException ex) {
/* 59:59 */         return Optional.absent();
/* 60:   */       }
/* 61:   */     }
/* 62:62 */     return Optional.absent();
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static <T> Optional<Transferable> tryFormat(T value, Formatters.Formatter<T> formatter) {
/* 66:66 */     String text = formatter.formatAsString(value);
/* 67:67 */     return text != null ? 
/* 68:68 */       Optional.of(new StringSelection(text)) : 
/* 69:69 */       Optional.absent();
/* 70:   */   }
/* 71:   */ }
