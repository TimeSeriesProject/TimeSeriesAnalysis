/*   1:    */ package ec.tss.datatransfer;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Function;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicate;
/*   7:    */ import com.google.common.base.Predicates;
/*   8:    */ import com.google.common.collect.FluentIterable;
/*   9:    */ import com.google.common.collect.Iterables;
/*  10:    */ import ec.nbdemetra.ui.awt.ListenableBean;
/*  11:    */ import ec.tss.Ts;
/*  12:    */ import ec.tss.TsCollection;
/*  13:    */ import ec.tss.TsFactory;
/*  14:    */ import ec.tss.TsInformationType;
/*  15:    */ import ec.tss.TsStatus;
/*  16:    */ import ec.tstoolkit.data.Table;
/*  17:    */ import ec.tstoolkit.maths.matrices.Matrix;
/*  18:    */ import ec.tstoolkit.timeseries.simplets.TsData;
/*  19:    */ import java.awt.Toolkit;
/*  20:    */ import java.awt.datatransfer.Clipboard;
/*  21:    */ import java.awt.datatransfer.DataFlavor;
/*  22:    */ import java.awt.datatransfer.FlavorEvent;
/*  23:    */ import java.awt.datatransfer.FlavorListener;
/*  24:    */ import java.awt.datatransfer.Transferable;
/*  25:    */ import java.awt.datatransfer.UnsupportedFlavorException;
/*  26:    */ import java.io.IOException;
/*  27:    */ import java.util.ArrayList;
/*  28:    */ import java.util.Arrays;
/*  29:    */ import java.util.List;
/*  30:    */ import javax.annotation.Nonnull;
/*  31:    */ import javax.annotation.Nullable;
/*  32:    */ import org.openide.util.Lookup;
/*  33:    */ import org.slf4j.Logger;
/*  34:    */ import org.slf4j.LoggerFactory;
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ public class TssTransferSupport
/*  60:    */   extends ListenableBean
/*  61:    */ {
/*  62:    */   public static final String VALID_CLIPBOARD_PROPERTY = "validClipboard";
/*  63: 63 */   private static final Logger LOGGER = LoggerFactory.getLogger(TssTransferSupport.class);
/*  64:    */   
/*  65:    */ 
/*  66:    */ 
/*  67:    */   private boolean validClipboard;
/*  68:    */   
/*  69:    */ 
/*  70:    */ 
/*  71:    */   @Nonnull
/*  72:    */   public static TssTransferSupport getDefault()
/*  73:    */   {
/*  74: 74 */     return (TssTransferSupport)Lookup.getDefault().lookup(TssTransferSupport.class);
/*  75:    */   }
/*  76:    */   
/*  77:    */   @Nonnull
/*  78:    */   @Deprecated
/*  79:    */   public static TssTransferSupport getInstance() {
/*  80: 80 */     return getDefault();
/*  81:    */   }
/*  82:    */   
/*  83:    */ 
/*  84:    */   public TssTransferSupport()
/*  85:    */   {
/*  86: 86 */     validClipboard = false;
/*  87: 87 */     Toolkit.getDefaultToolkit().getSystemClipboard().addFlavorListener(new FlavorListener()
/*  88:    */     {
/*  89:    */       public void flavorsChanged(FlavorEvent e) {
/*  90:    */         try {
/*  91: 91 */           boolean old = validClipboard;
/*  92: 92 */           validClipboard = canImport(((Clipboard)e.getSource()).getContents(this).getTransferDataFlavors());
/*  93: 93 */           firePropertyChange("validClipboard", Boolean.valueOf(old), Boolean.valueOf(validClipboard));
/*  94:    */         } catch (Exception ex) {
/*  95: 95 */           TssTransferSupport.LOGGER.debug("While getting content from clipboard", ex);
/*  96:    */         }
/*  97:    */       }
/*  98:    */     });
/*  99:    */   }
/* 100:    */   
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */   public boolean isValidClipboard()
/* 106:    */   {
/* 107:107 */     return validClipboard;
/* 108:    */   }
/* 109:    */   
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */   @Nonnull
/* 115:    */   public FluentIterable<? extends TssTransferHandler> all()
/* 116:    */   {
/* 117:117 */     return FluentIterable.from(Iterables.concat(Lookup.getDefault().lookupAll(TssTransferHandler.class), ATsCollectionFormatter.getLegacyHandlers()));
/* 118:    */   }
/* 119:    */   
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */   @Nonnull
/* 127:    */   @Deprecated
/* 128:    */   public List<ITsCollectionFormatter> getFormatters()
/* 129:    */   {
/* 130:130 */     return new ArrayList();
/* 131:    */   }
/* 132:    */   
/* 133:    */   public boolean canImport(@Nonnull DataFlavor... dataFlavors) {
/* 134:134 */     return all().anyMatch(onDataFlavors(dataFlavors));
/* 135:    */   }
/* 136:    */   
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */   @Nonnull
/* 143:    */   public Transferable fromTsData(@Nonnull TsData data)
/* 144:    */   {
/* 145:145 */     Preconditions.checkNotNull(data);
/* 146:146 */     return fromTs(TsFactory.instance.createTs("", null, data));
/* 147:    */   }
/* 148:    */   
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */   @Nonnull
/* 155:    */   public Transferable fromTs(@Nonnull Ts ts)
/* 156:    */   {
/* 157:157 */     Preconditions.checkNotNull(ts);
/* 158:158 */     TsCollection col = TsFactory.instance.createTsCollection();
/* 159:159 */     col.quietAdd(ts);
/* 160:160 */     return fromTsCollection(col);
/* 161:    */   }
/* 162:    */   
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */   @Nonnull
/* 169:    */   public Transferable fromTsCollection(@Nonnull TsCollection col)
/* 170:    */   {
/* 171:171 */     Preconditions.checkNotNull(col);
/* 172:172 */     return new TsCollectionAdapter(col, all());
/* 173:    */   }
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */   @Nonnull
/* 181:    */   public Transferable fromMatrix(@Nonnull Matrix matrix)
/* 182:    */   {
/* 183:183 */     Preconditions.checkNotNull(matrix);
/* 184:184 */     return new MatrixAdapter(matrix, all());
/* 185:    */   }
/* 186:    */   
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */   @Nonnull
/* 193:    */   public Transferable fromTable(@Nonnull Table<?> table)
/* 194:    */   {
/* 195:195 */     Preconditions.checkNotNull(table);
/* 196:196 */     return new TableAdapter(table, all());
/* 197:    */   }
/* 198:    */   
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */   @Nullable
/* 205:    */   public TsData toTsData(@Nonnull Transferable transferable)
/* 206:    */   {
/* 207:207 */     Ts ts = toTs(transferable);
/* 208:208 */     if (ts != null) {
/* 209:209 */       ts.load(TsInformationType.Data);
/* 210:210 */       if (ts.hasData() == TsStatus.Valid) {
/* 211:211 */         return ts.getTsData();
/* 212:    */       }
/* 213:    */     }
/* 214:214 */     return null;
/* 215:    */   }
/* 216:    */   
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */   @Nullable
/* 227:    */   public Ts toTs(@Nonnull Transferable transferable)
/* 228:    */   {
/* 229:229 */     TsCollection col = toTsCollection(transferable);
/* 230:230 */     return (col != null) && (!col.isEmpty()) ? col.get(0) : null;
/* 231:    */   }
/* 232:    */   
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */   @Nullable
/* 244:    */   public TsCollection toTsCollection(@Nonnull Transferable transferable)
/* 245:    */   {
/* 246:246 */     Preconditions.checkNotNull(transferable);
/* 247:247 */     for (TssTransferHandler o : all().filter(onDataFlavors(transferable.getTransferDataFlavors()))) {
/* 248:    */       try {
/* 249:249 */         Object transferData = transferable.getTransferData(o.getDataFlavor());
/* 250:250 */         if (o.canImportTsCollection(transferData)) {
/* 251:251 */           LOGGER.debug("Getting collection using '{}'", o.getName());
/* 252:252 */           return o.importTsCollection(transferData);
/* 253:    */         }
/* 254:    */       } catch (UnsupportedFlavorException|IOException ex) {
/* 255:255 */         LOGGER.error("While getting collection using '" + o.getName() + "'", ex);
/* 256:    */       }
/* 257:    */     }
/* 258:258 */     return null;
/* 259:    */   }
/* 260:    */   
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */   @Nullable
/* 267:    */   public Matrix toMatrix(@Nonnull Transferable transferable)
/* 268:    */   {
/* 269:269 */     Preconditions.checkNotNull(transferable);
/* 270:270 */     for (TssTransferHandler o : all().filter(onDataFlavors(transferable.getTransferDataFlavors()))) {
/* 271:    */       try {
/* 272:272 */         Object transferData = transferable.getTransferData(o.getDataFlavor());
/* 273:273 */         if (o.canImportMatrix(transferData)) {
/* 274:274 */           LOGGER.debug("Getting matrix using '{}'", o.getName());
/* 275:275 */           return o.importMatrix(transferData);
/* 276:    */         }
/* 277:    */       } catch (UnsupportedFlavorException|IOException ex) {
/* 278:278 */         LOGGER.error("While getting matrix using '" + o.getName() + "'", ex);
/* 279:    */       }
/* 280:    */     }
/* 281:281 */     return null;
/* 282:    */   }
/* 283:    */   
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */   @Nullable
/* 290:    */   public Table<?> toTable(@Nonnull Transferable transferable)
/* 291:    */   {
/* 292:292 */     Preconditions.checkNotNull(transferable);
/* 293:293 */     for (TssTransferHandler o : all().filter(onDataFlavors(transferable.getTransferDataFlavors()))) {
/* 294:    */       try {
/* 295:295 */         Object transferData = transferable.getTransferData(o.getDataFlavor());
/* 296:296 */         if (o.canImportTable(transferData)) {
/* 297:297 */           LOGGER.debug("Getting table using '{}'", o.getName());
/* 298:298 */           return o.importTable(transferData);
/* 299:    */         }
/* 300:    */       } catch (UnsupportedFlavorException|IOException ex) {
/* 301:301 */         LOGGER.error("While getting table using '" + o.getName() + "'", ex);
/* 302:    */       }
/* 303:    */     }
/* 304:304 */     return null;
/* 305:    */   }
/* 306:    */   
/* 307:    */   private static abstract class CustomAdapter<T> implements Transferable
/* 308:    */   {
/* 309:    */     private final T data;
/* 310:    */     private final List<? extends TssTransferHandler> handlers;
/* 311:    */     
/* 312:    */     public CustomAdapter(T data, List<? extends TssTransferHandler> handlers)
/* 313:    */     {
/* 314:314 */       this.data = data;
/* 315:315 */       this.handlers = handlers;
/* 316:    */     }
/* 317:    */     
/* 318:    */     public DataFlavor[] getTransferDataFlavors()
/* 319:    */     {
/* 320:320 */       return (DataFlavor[])FluentIterable.from(handlers).transform(TssTransferSupport.TO_DATA_FLAVOR).toArray(DataFlavor.class);
/* 321:    */     }
/* 322:    */     
/* 323:    */     public boolean isDataFlavorSupported(DataFlavor flavor)
/* 324:    */     {
/* 325:325 */       return FluentIterable.from(handlers).anyMatch(TssTransferSupport.onDataFlavor(flavor));
/* 326:    */     }
/* 327:    */     
/* 328:    */     public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
/* 329:    */     {
/* 330:330 */       Optional<? extends TssTransferHandler> handler = FluentIterable.from(handlers).firstMatch(TssTransferSupport.onDataFlavor(flavor));
/* 331:331 */       if (handler.isPresent()) {
/* 332:332 */         TssTransferSupport.LOGGER.debug("Getting transfer data using '{}'", ((TssTransferHandler)handler.get()).getName());
/* 333:333 */         return getTransferData(data, (TssTransferHandler)handler.get());
/* 334:    */       }
/* 335:335 */       throw new UnsupportedFlavorException(flavor);
/* 336:    */     }
/* 337:    */     
/* 338:    */     protected abstract Object getTransferData(T paramT, TssTransferHandler paramTssTransferHandler) throws IOException;
/* 339:    */   }
/* 340:    */   
/* 341:    */   private static class TsCollectionAdapter extends TssTransferSupport.CustomAdapter<TsCollection>
/* 342:    */   {
/* 343:    */     TsCollectionAdapter(TsCollection col, FluentIterable<? extends TssTransferHandler> allHandlers) {
/* 344:344 */       super(allHandlers.filter(TssTransferSupport.onExportability(col)).toList());
/* 345:    */     }
/* 346:    */     
/* 347:    */     protected Object getTransferData(TsCollection data, TssTransferHandler handler) throws IOException
/* 348:    */     {
/* 349:349 */       return handler.exportTsCollection(data);
/* 350:    */     }
/* 351:    */   }
/* 352:    */   
/* 353:    */   private static class MatrixAdapter extends TssTransferSupport.CustomAdapter<Matrix>
/* 354:    */   {
/* 355:    */     MatrixAdapter(Matrix matrix, FluentIterable<? extends TssTransferHandler> allHandlers) {
/* 356:356 */       super(allHandlers.filter(TssTransferSupport.onExportability(matrix)).toList());
/* 357:    */     }
/* 358:    */     
/* 359:    */     protected Object getTransferData(Matrix data, TssTransferHandler handler) throws IOException
/* 360:    */     {
/* 361:361 */       return handler.exportMatrix(data);
/* 362:    */     }
/* 363:    */   }
/* 364:    */   
/* 365:    */   private static class TableAdapter extends TssTransferSupport.CustomAdapter<Table<?>>
/* 366:    */   {
/* 367:    */     TableAdapter(Table<?> table, FluentIterable<? extends TssTransferHandler> allHandlers) {
/* 368:368 */       super(allHandlers.filter(TssTransferSupport.onExportability(table)).toList());
/* 369:    */     }
/* 370:    */     
/* 371:    */     protected Object getTransferData(Table<?> data, TssTransferHandler handler) throws IOException
/* 372:    */     {
/* 373:373 */       return handler.exportTable(data);
/* 374:    */     }
/* 375:    */   }
/* 376:    */   
/* 377:    */ 
/* 378:    */ 
/* 379:379 */   private static final Function<TssTransferHandler, DataFlavor> TO_DATA_FLAVOR = new Function()
/* 380:    */   {
/* 381:    */     public DataFlavor apply(TssTransferHandler input) {
/* 382:382 */       return input != null ? input.getDataFlavor() : null;
/* 383:    */     }
/* 384:    */   };
/* 385:    */   
/* 386:    */   private static Predicate<TssTransferHandler> onExportability(TsCollection col) {
/* 387:387 */     new Predicate()
/* 388:    */     {
/* 389:    */       public boolean apply(TssTransferHandler input) {
/* 390:390 */         return (input != null ? Boolean.valueOf(input.canExportTsCollection(TssTransferSupport.this)) : null).booleanValue();
/* 391:    */       }
/* 392:    */     };
/* 393:    */   }
/* 394:    */   
/* 395:    */   private static Predicate<TssTransferHandler> onExportability(Matrix matrix) {
/* 396:396 */     new Predicate()
/* 397:    */     {
/* 398:    */       public boolean apply(TssTransferHandler input) {
/* 399:399 */         return (input != null ? Boolean.valueOf(input.canExportMatrix(TssTransferSupport.this)) : null).booleanValue();
/* 400:    */       }
/* 401:    */     };
/* 402:    */   }
/* 403:    */   
/* 404:    */   private static Predicate<TssTransferHandler> onExportability(Table<?> table) {
/* 405:405 */     new Predicate()
/* 406:    */     {
/* 407:    */       public boolean apply(TssTransferHandler input) {
/* 408:408 */         return (input != null ? Boolean.valueOf(input.canExportTable(TssTransferSupport.this)) : null).booleanValue();
/* 409:    */       }
/* 410:    */     };
/* 411:    */   }
/* 412:    */   
/* 413:    */   private static Predicate<TssTransferHandler> onDataFlavor(DataFlavor dataFlavor) {
/* 414:414 */     return Predicates.compose(Predicates.equalTo(dataFlavor), TO_DATA_FLAVOR);
/* 415:    */   }
/* 416:    */   
/* 417:    */   private static Predicate<TssTransferHandler> onDataFlavors(DataFlavor[] dataFlavors) {
/* 418:418 */     List<DataFlavor> list = Arrays.asList(dataFlavors);
/* 419:419 */     new Predicate()
/* 420:    */     {
/* 421:    */       public boolean apply(TssTransferHandler input) {
/* 422:422 */         return contains(input != null ? input.getDataFlavor() : null);
/* 423:    */       }
/* 424:    */     };
/* 425:    */   }
/* 426:    */ }
