/*   1:    */ package ec.tss.datatransfer;
/*   2:    */ 
/*   3:    */ import ec.tss.xml.IXmlConverter;
/*   4:    */ import java.awt.datatransfer.DataFlavor;
/*   5:    */ import java.awt.datatransfer.Transferable;
/*   6:    */ import java.awt.datatransfer.UnsupportedFlavorException;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.StringReader;
/*   9:    */ import java.io.StringWriter;
/*  10:    */ import javax.xml.bind.JAXBContext;
/*  11:    */ import javax.xml.bind.JAXBException;
/*  12:    */ import javax.xml.bind.Marshaller;
/*  13:    */ import javax.xml.bind.Unmarshaller;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ public class TransferableXml<T, X extends IXmlConverter<T>>
/*  21:    */   implements Transferable
/*  22:    */ {
/*  23:    */   private final Class<X> xclass_;
/*  24:    */   private final T obj_;
/*  25:    */   private final DataFlavor local_;
/*  26:    */   
/*  27:    */   public static <T, X extends IXmlConverter<T>> T read(Transferable dataobj, Class<T> tclass, Class<X> xclass)
/*  28:    */   {
/*  29:    */     try
/*  30:    */     {
/*  31: 31 */       DataFlavor local = DataTransfers.newLocalObjectDataFlavor(tclass);
/*  32: 32 */       if (dataobj.isDataFlavorSupported(local)) {
/*  33: 33 */         return dataobj.getTransferData(local);
/*  34:    */       }
/*  35: 35 */       return read(dataobj, xclass);
/*  36:    */     }
/*  37:    */     catch (UnsupportedFlavorException|IOException ex) {}
/*  38: 38 */     return null;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <T, X extends IXmlConverter<T>> T read(Transferable dataobj, Class<X> xclass)
/*  42:    */   {
/*  43:    */     try {
/*  44: 44 */       DataFlavor xmlflavor = BasicFormatter.TEXT;
/*  45: 45 */       if (!dataobj.isDataFlavorSupported(xmlflavor)) {
/*  46: 46 */         return null;
/*  47:    */       }
/*  48: 48 */       String str = (String)dataobj.getTransferData(BasicFormatter.TEXT);
/*  49: 49 */       StringReader reader = new StringReader(str);
/*  50:    */       
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55: 55 */       JAXBContext context = JAXBContext.newInstance(new Class[] { xclass });
/*  56: 56 */       Unmarshaller unmarshaller = context.createUnmarshaller();
/*  57: 57 */       X x = (IXmlConverter)unmarshaller.unmarshal(reader);
/*  58: 58 */       return x.create();
/*  59:    */     } catch (UnsupportedFlavorException|IOException|JAXBException ex) {}
/*  60: 60 */     return null;
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */   public TransferableXml(T obj, Class<X> xclass)
/*  65:    */   {
/*  66: 66 */     xclass_ = xclass;
/*  67: 67 */     obj_ = obj;
/*  68: 68 */     local_ = DataTransfers.newLocalObjectDataFlavor(obj.getClass());
/*  69:    */   }
/*  70:    */   
/*  71:    */   public DataFlavor[] getTransferDataFlavors()
/*  72:    */   {
/*  73: 73 */     return new DataFlavor[] { local_, BasicFormatter.TEXT };
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isDataFlavorSupported(DataFlavor flavor)
/*  77:    */   {
/*  78: 78 */     return (flavor.equals(local_)) || (flavor.equals(BasicFormatter.TEXT));
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
/*  82:    */   {
/*  83: 83 */     if (obj_ == null) {
/*  84: 84 */       return null;
/*  85:    */     }
/*  86: 86 */     if (flavor.equals(local_)) {
/*  87: 87 */       return obj_;
/*  88:    */     }
/*  89: 89 */     if (!flavor.equals(BasicFormatter.TEXT)) {
/*  90: 90 */       return null;
/*  91:    */     }
/*  92: 92 */     StringWriter writer = new StringWriter();
/*  93:    */     try {
/*  94: 94 */       JAXBContext context = JAXBContext.newInstance(new Class[] { xclass_ });
/*  95: 95 */       Marshaller marshaller = context.createMarshaller();
/*  96: 96 */       marshaller.setProperty("jaxb.formatted.output", Boolean.valueOf(true));
/*  97: 97 */       X x = (IXmlConverter)xclass_.newInstance();
/*  98: 98 */       x.copy(obj_);
/*  99: 99 */       marshaller.marshal(x, writer);
/* 100:100 */       writer.flush();
/* 101:101 */       return writer.toString();
/* 102:    */     } catch (JAXBException|InstantiationException|IllegalAccessException ex) {}
/* 103:103 */     return null;
/* 104:    */   }
/* 105:    */ }
