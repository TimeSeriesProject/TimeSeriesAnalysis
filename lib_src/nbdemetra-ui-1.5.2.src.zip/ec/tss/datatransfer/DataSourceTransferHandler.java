package ec.tss.datatransfer;

import com.google.common.base.Optional;
import ec.tss.tsproviders.DataSource;
import java.awt.datatransfer.Transferable;
import javax.annotation.Nonnull;

public abstract class DataSourceTransferHandler
{
  public abstract boolean canHandle(@Nonnull Transferable paramTransferable);
  
  public abstract boolean canHandle(@Nonnull Transferable paramTransferable, @Nonnull String paramString);
  
  @Nonnull
  public abstract Optional<DataSource> getDataSource(@Nonnull Transferable paramTransferable);
  
  @Nonnull
  public abstract Optional<DataSource> getDataSource(@Nonnull Transferable paramTransferable, @Nonnull String paramString);
}
