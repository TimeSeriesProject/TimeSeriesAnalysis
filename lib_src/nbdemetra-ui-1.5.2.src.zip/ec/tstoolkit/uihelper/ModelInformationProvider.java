/*   1:    */ package ec.tstoolkit.uihelper;
/*   2:    */ 
/*   3:    */ import ec.tstoolkit.arima.AutoCovarianceFunction;
/*   4:    */ import ec.tstoolkit.arima.IArimaModel;
/*   5:    */ import ec.tstoolkit.arima.ILinearModel;
/*   6:    */ import ec.tstoolkit.arima.Spectrum;
/*   7:    */ import ec.tstoolkit.arima.StationaryTransformation;
/*   8:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*   9:    */ import ec.tstoolkit.utilities.NamedObject;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Map;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ public class ModelInformationProvider
/*  17:    */   implements IContinuousInformationProvider, IDiscreteInformationProvider
/*  18:    */ {
/*  19:    */   private final ArrayList<NamedObject<IArimaModel>> models_;
/*  20:    */   public static final String SPECTRUM = "Spectrum";
/*  21:    */   public static final String AUTOCORRELATIONS = "Auto-correlations";
/*  22:    */   
/*  23:    */   public ModelInformationProvider(ArrayList<NamedObject<IArimaModel>> models)
/*  24:    */   {
/*  25: 25 */     models_ = models;
/*  26:    */   }
/*  27:    */   
/*  28:    */ 
/*  29:    */ 
/*  30:    */   public ModelInformationProvider(Map<String, ? extends IArimaModel> paramMap) {}
/*  31:    */   
/*  32:    */ 
/*  33:    */   private void fillSpectrum(int cmp, double[] data, ContinuousDisplayDomain domain)
/*  34:    */   {
/*  35: 35 */     Spectrum spectrum = ((IArimaModel)models_.get(cmp)).object).getSpectrum();
/*  36: 36 */     if (spectrum == null) {
/*  37: 37 */       return;
/*  38:    */     }
/*  39:    */     
/*  40: 40 */     double x = beg;
/*  41: 41 */     for (int i = 0; i < data.length; i++) {
/*  42: 42 */       data[i] = spectrum.get(x);
/*  43: 43 */       x += step;
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public DiscreteDisplayDomain getDiscreteDisplayDomain(int npoints)
/*  48:    */   {
/*  49: 49 */     int ifreq = freq_.intValue();
/*  50: 50 */     if (currentInfo_.equals("Auto-correlations")) {
/*  51: 51 */       return new DiscreteDisplayDomain(1, multiple(ifreq, npoints));
/*  52:    */     }
/*  53:    */     
/*  54: 54 */     return null;
/*  55:    */   }
/*  56:    */   
/*  57:    */   private int multiple(int ifreq, int n)
/*  58:    */   {
/*  59: 59 */     if (ifreq == 0) {
/*  60: 60 */       return n;
/*  61:    */     }
/*  62: 62 */     if (n % ifreq == 0) {
/*  63: 63 */       return n;
/*  64:    */     }
/*  65:    */     
/*  66: 66 */     return (n / ifreq + 1) * ifreq;
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70:    */   public DiscreteDisplayDomain getDiscreteDisplayDomain(int lower, int upper)
/*  71:    */   {
/*  72: 72 */     if (currentInfo_.equals("Auto-correlations")) {
/*  73: 73 */       return new DiscreteDisplayDomain(Math.max(1, lower), upper);
/*  74:    */     }
/*  75:    */     
/*  76: 76 */     return null;
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */   public double[] getDataArray(int cmp, DiscreteDisplayDomain domain)
/*  81:    */   {
/*  82: 82 */     double[] data = new double[domain.getLength()];
/*  83: 83 */     if (currentInfo_.equals("Auto-correlations")) {
/*  84: 84 */       fillAutocorrelations(cmp, data, domain);
/*  85:    */     }
/*  86:    */     else {
/*  87: 87 */       return null;
/*  88:    */     }
/*  89: 89 */     return data;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public double getData(int cmp, int x)
/*  93:    */   {
/*  94: 94 */     throw new UnsupportedOperationException("Not supported yet.");
/*  95:    */   }
/*  96:    */   
/*  97:    */   private void fillAutocorrelations(int cmp, double[] data, DiscreteDisplayDomain domain) {
/*  98: 98 */     IArimaModel cur = (IArimaModel)models_.get(cmp)).object;
/*  99: 99 */     AutoCovarianceFunction acgf = stationaryTransformation()stationaryModel.getAutoCovarianceFunction();
/* 100:100 */     if (acgf == null) {
/* 101:101 */       return;
/* 102:    */     }
/* 103:103 */     acgf.prepare(beg + data.length);
/* 104:104 */     double var = acgf.get(0);
/* 105:105 */     for (int i = 0; i < data.length; 
/* 106:106 */         i++) {
/* 107:107 */       data[i] = (acgf.get(i + beg) / var);
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */ 
/* 112:112 */   private String currentInfo_ = "Spectrum";
/* 113:113 */   private TsFrequency freq_ = TsFrequency.Undefined;
/* 114:    */   
/* 115:    */ 
/* 116:    */ 
/* 117:    */   public TsFrequency getFrequency()
/* 118:    */   {
/* 119:119 */     return freq_;
/* 120:    */   }
/* 121:    */   
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */   public void setFrequency(TsFrequency freq_)
/* 127:    */   {
/* 128:128 */     this.freq_ = freq_;
/* 129:    */   }
/* 130:    */   
/* 131:    */ 
/* 132:    */   public void setInformation(String info)
/* 133:    */   {
/* 134:134 */     currentInfo_ = info;
/* 135:    */   }
/* 136:    */   
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */   public String getInformation()
/* 144:    */   {
/* 145:145 */     return currentInfo_;
/* 146:    */   }
/* 147:    */   
/* 148:    */ 
/* 149:    */ 
/* 150:    */   public double[] getDataArray(int cmp, ContinuousDisplayDomain domain)
/* 151:    */   {
/* 152:152 */     double[] data = new double[npoints];
/* 153:    */     
/* 154:154 */     if (currentInfo_.equals("Spectrum")) {
/* 155:155 */       fillSpectrum(cmp, data, domain);
/* 156:    */     }
/* 157:    */     else {
/* 158:158 */       return null;
/* 159:    */     }
/* 160:    */     
/* 161:    */ 
/* 162:162 */     return data;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public double getData(int cmp, double x)
/* 166:    */   {
/* 167:167 */     throw new UnsupportedOperationException("Not supported yet.");
/* 168:    */   }
/* 169:    */   
/* 170:    */ 
/* 171:    */ 
/* 172:    */   public ContinuousDisplayDomain getContinuousDisplayDomain(int npoints)
/* 173:    */   {
/* 174:174 */     if (currentInfo_.equals("Spectrum")) {
/* 175:175 */       return FrequencyInformationProvider.getDisplayDomain(freq_, npoints);
/* 176:    */     }
/* 177:    */     
/* 178:178 */     return null;
/* 179:    */   }
/* 180:    */   
/* 181:    */ 
/* 182:    */   public ContinuousDisplayDomain getContinuousDisplayDomain(double lower, double upper, int npoints)
/* 183:    */   {
/* 184:184 */     if (currentInfo_.equals("Spectrum")) {
/* 185:185 */       return FrequencyInformationProvider.getDisplayDomain(freq_, lower, upper, npoints);
/* 186:    */     }
/* 187:    */     
/* 188:188 */     return null;
/* 189:    */   }
/* 190:    */   
/* 191:    */ 
/* 192:    */   public boolean isDefined(int idx)
/* 193:    */   {
/* 194:194 */     return (models_.get(idx)).object != null) && (!((IArimaModel)models_.get(idx)).object).isNull());
/* 195:    */   }
/* 196:    */   
/* 197:    */   public String[] getComponents()
/* 198:    */   {
/* 199:199 */     String[] names = new String[models_.size()];
/* 200:200 */     for (int i = 0; i < names.length; i++) {
/* 201:201 */       names[i] = models_.get(i)).name;
/* 202:    */     }
/* 203:203 */     return names;
/* 204:    */   }
/* 205:    */ }
