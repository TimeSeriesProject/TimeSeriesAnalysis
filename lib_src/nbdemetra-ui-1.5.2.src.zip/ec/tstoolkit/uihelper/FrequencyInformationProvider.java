/*  1:   */ package ec.tstoolkit.uihelper;
/*  2:   */ 
/*  3:   */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ public class FrequencyInformationProvider
/* 14:   */ {
/* 15:   */   public static ContinuousDisplayDomain getDisplayDomain(TsFrequency freq, int npoints)
/* 16:   */   {
/* 17:17 */     double beg = 0.0D;
/* 18:18 */     double end = 3.141592653589793D;
/* 19:19 */     int ifreq = freq.intValue();
/* 20:20 */     if (ifreq == 0) {
/* 21:21 */       return new ContinuousDisplayDomain(beg, end, npoints);
/* 22:   */     }
/* 23:23 */     return new ContinuousDisplayDomain(beg, end, adjust(freq, npoints));
/* 24:   */   }
/* 25:   */   
/* 26:   */ 
/* 27:   */   public static ContinuousDisplayDomain getDisplayDomain(TsFrequency freq, double beg, double end, int npoints)
/* 28:   */   {
/* 29:29 */     int ifreq = freq.intValue();
/* 30:30 */     if (ifreq == 0) {
/* 31:31 */       return new ContinuousDisplayDomain(beg, end, npoints);
/* 32:   */     }
/* 33:   */     
/* 34:34 */     double begc = beg;double endc = end;
/* 35:35 */     if (begc < 0.0D) {
/* 36:36 */       begc = 0.0D;
/* 37:   */     }
/* 38:38 */     if (endc > 3.141592653589793D) {
/* 39:39 */       endc = 3.141592653589793D;
/* 40:   */     }
/* 41:   */     
/* 42:   */ 
/* 43:43 */     int n = (int)(npoints * 3.141592653589793D / (endc - begc));
/* 44:44 */     double step = 3.141592653589793D / (n - 1);
/* 45:45 */     int ibeg = (int)(begc / step);
/* 46:46 */     begc = ibeg * step;
/* 47:47 */     n = adjust(freq, npoints);
/* 48:48 */     endc = begc + (n - 1) * step;
/* 49:   */     
/* 50:50 */     return new ContinuousDisplayDomain(begc, endc, n);
/* 51:   */   }
/* 52:   */   
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */   private static int adjust(TsFrequency freq, int npoints)
/* 57:   */   {
/* 58:58 */     int ifreq = freq.intValue();
/* 59:59 */     int ires = npoints % ifreq;
/* 60:60 */     int n; int n; if (ires == 0) {
/* 61:61 */       n = npoints + 1; } else { int n;
/* 62:62 */       if (ires == 1) {
/* 63:63 */         n = npoints;
/* 64:   */       } else
/* 65:65 */         n = (npoints / ifreq + 1) * ifreq + 1;
/* 66:   */     }
/* 67:67 */     return n;
/* 68:   */   }
/* 69:   */ }
