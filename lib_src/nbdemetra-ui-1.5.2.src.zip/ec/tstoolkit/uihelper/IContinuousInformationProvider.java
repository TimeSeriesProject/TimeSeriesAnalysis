package ec.tstoolkit.uihelper;

public abstract interface IContinuousInformationProvider
{
  public abstract String getInformation();
  
  public abstract String[] getComponents();
  
  public abstract ContinuousDisplayDomain getContinuousDisplayDomain(int paramInt);
  
  public abstract ContinuousDisplayDomain getContinuousDisplayDomain(double paramDouble1, double paramDouble2, int paramInt);
  
  public abstract double[] getDataArray(int paramInt, ContinuousDisplayDomain paramContinuousDisplayDomain);
  
  public abstract double getData(int paramInt, double paramDouble);
  
  public abstract boolean isDefined(int paramInt);
}
