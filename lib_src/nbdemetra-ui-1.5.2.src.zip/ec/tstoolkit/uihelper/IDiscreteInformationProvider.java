package ec.tstoolkit.uihelper;

public abstract interface IDiscreteInformationProvider
{
  public abstract String getInformation();
  
  public abstract String[] getComponents();
  
  public abstract DiscreteDisplayDomain getDiscreteDisplayDomain(int paramInt);
  
  public abstract DiscreteDisplayDomain getDiscreteDisplayDomain(int paramInt1, int paramInt2);
  
  public abstract boolean isDefined(int paramInt);
  
  public abstract double[] getDataArray(int paramInt, DiscreteDisplayDomain paramDiscreteDisplayDomain);
  
  public abstract double getData(int paramInt1, int paramInt2);
}
