/*   1:    */ package ec.tstoolkit.uihelper;
/*   2:    */ 
/*   3:    */ import ec.satoolkit.ComponentDescriptor;
/*   4:    */ import ec.tstoolkit.arima.ArimaModel;
/*   5:    */ import ec.tstoolkit.arima.AutoCovarianceFunction;
/*   6:    */ import ec.tstoolkit.arima.LinearModel;
/*   7:    */ import ec.tstoolkit.maths.Complex;
/*   8:    */ import ec.tstoolkit.maths.linearfilters.RationalFilter;
/*   9:    */ import ec.tstoolkit.timeseries.simplets.TsFrequency;
/*  10:    */ import ec.tstoolkit.ucarima.UcarimaModel;
/*  11:    */ import ec.tstoolkit.ucarima.WienerKolmogorovEstimator;
/*  12:    */ import ec.tstoolkit.ucarima.WienerKolmogorovEstimators;
/*  13:    */ import ec.tstoolkit.ucarima.WienerKolmogorovPreliminaryEstimatorProperties;
/*  14:    */ 
/*  15:    */ public class WienerKolmogorovUcarimaEstimators implements IContinuousInformationProvider, IDiscreteInformationProvider
/*  16:    */ {
/*  17:    */   public static final String SPECTRUM = "Spectrum";
/*  18:    */   public static final String GAIN = "Square gain";
/*  19:    */   public static final String PHASE = "Phase effect";
/*  20:    */   public static final String WKFILTER = "Weights";
/*  21:    */   public static final String PSIEWEIGHTS = "PsiE-weights";
/*  22:    */   public static final String AUTOCORRELATIONS = "Auto-correlations";
/*  23:    */   
/*  24:    */   private void fillGain(int cmp, double[] data, ContinuousDisplayDomain domain)
/*  25:    */   {
/*  26: 26 */     ComponentDescriptor desc = cmpDescs_[cmp];
/*  27: 27 */     if (type_ == EstimatorType.Preliminary) {
/*  28: 28 */       WienerKolmogorovPreliminaryEstimatorProperties wkp = new WienerKolmogorovPreliminaryEstimatorProperties(wk_);
/*  29: 29 */       wkp.setLag(lag_);
/*  30: 30 */       double freq = beg;
/*  31: 31 */       for (int j = 0; j < data.length; freq += step) {
/*  32: 32 */         data[j] = wkp.getFrequencyResponse(freq).absSquare();j++;
/*  33:    */       }
/*  34:    */     }
/*  35: 35 */     if (type_ == EstimatorType.Component) {
/*  36: 36 */       return;
/*  37:    */     }
/*  38:    */     
/*  39: 39 */     if (type_ == EstimatorType.Final) {
/*  40: 40 */       WienerKolmogorovEstimator estimator = wk_.finalEstimator(cmp, signal);
/*  41: 41 */       RationalFilter rf = estimator.getFilter();
/*  42: 42 */       for (int i = 0; i < data.length; i++) {
/*  43: 43 */         data[i] = rf.frequencyResponse(domain.x(i)).absSquare();
/*  44:    */       }
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   private void fillPhase(int cmp, double[] data, ContinuousDisplayDomain domain) {
/*  49: 49 */     ComponentDescriptor desc = cmpDescs_[cmp];
/*  50: 50 */     if (type_ == EstimatorType.Preliminary) {
/*  51: 51 */       WienerKolmogorovPreliminaryEstimatorProperties wkp = new WienerKolmogorovPreliminaryEstimatorProperties(wk_);
/*  52: 52 */       wkp.setLag(lag_);
/*  53: 53 */       double freq = beg;
/*  54: 54 */       for (int j = 0; j < data.length; freq += step) {
/*  55: 55 */         Complex rfw = wkp.getFrequencyResponse(freq);
/*  56: 56 */         if ((lowFrequency) && (j < data.length) && (freq != 0.0D)) {
/*  57: 57 */           data[j] = (-rfw.arg() / freq);
/*  58:    */         }
/*  59: 54 */         j++;
/*  60:    */       }
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */   private void fillSpectrum(int cmp, double[] data, ContinuousDisplayDomain domain)
/*  68:    */   {
/*  69: 64 */     ComponentDescriptor desc = cmpDescs_[cmp];
/*  70: 65 */     if (type_ == EstimatorType.Preliminary) {
/*  71: 66 */       throw new UnsupportedOperationException("Not yet implemented");
/*  72:    */     }
/*  73: 68 */     ec.tstoolkit.arima.Spectrum spectrum = null;
/*  74: 69 */     if (type_ == EstimatorType.Final) {
/*  75: 70 */       WienerKolmogorovEstimator estimator = wk_.finalEstimator(cmp, signal);
/*  76: 71 */       spectrum = estimator.getModel().getSpectrum();
/*  77: 72 */     } else if (type_ == EstimatorType.Component) {
/*  78: 73 */       if (signal) {
/*  79: 74 */         spectrum = wk_.getUcarimaModel().getComponent(cmp).getSpectrum();
/*  80:    */       } else {
/*  81: 76 */         spectrum = wk_.getUcarimaModel().getComplement(cmp).getSpectrum();
/*  82:    */       }
/*  83:    */     }
/*  84: 79 */     if (spectrum == null) {
/*  85: 80 */       return;
/*  86:    */     }
/*  87:    */     
/*  88: 83 */     double x = beg;
/*  89: 84 */     for (int i = 0; i < data.length; i++) {
/*  90: 85 */       data[i] = spectrum.get(x);
/*  91: 86 */       x += step;
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   public DiscreteDisplayDomain getDiscreteDisplayDomain(int npoints)
/*  96:    */   {
/*  97: 92 */     int ifreq = freq_.intValue();
/*  98: 93 */     String str; switch ((str = currentInfo_).hashCode()) {case -1399872293:  if (str.equals("Weights")) break; break; case -21152883:  if (str.equals("PsiE-weights")) break;  case 2005309039:  if ((goto 126) && (str.equals("Auto-correlations")))
/*  99:    */       {
/* 100: 95 */         return new DiscreteDisplayDomain(1, multiple(ifreq, npoints));
/* 101:    */         
/* 102:    */ 
/* 103: 98 */         int np = multiple(ifreq, npoints / 2);
/* 104: 99 */         return new DiscreteDisplayDomain(-np, np); }
/* 105:    */       break; }
/* 106:101 */     return null;
/* 107:    */   }
/* 108:    */   
/* 109:    */   private int multiple(int ifreq, int n)
/* 110:    */   {
/* 111:106 */     if (ifreq == 0)
/* 112:107 */       return n;
/* 113:108 */     if (n % ifreq == 0) {
/* 114:109 */       return n;
/* 115:    */     }
/* 116:111 */     return (n / ifreq + 1) * ifreq;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public DiscreteDisplayDomain getDiscreteDisplayDomain(int lower, int upper)
/* 120:    */   {
/* 121:    */     String str;
/* 122:117 */     switch ((str = currentInfo_).hashCode()) {case -1399872293:  if (str.equals("Weights")) break; break; case -21152883:  if (str.equals("PsiE-weights")) break;  case 2005309039:  if ((goto 104) && (str.equals("Auto-correlations")))
/* 123:    */       {
/* 124:119 */         return new DiscreteDisplayDomain(Math.max(1, lower), upper);
/* 125:    */         
/* 126:    */ 
/* 127:122 */         return new DiscreteDisplayDomain(lower, upper); }
/* 128:    */       break; }
/* 129:124 */     return null;
/* 130:    */   }
/* 131:    */   
/* 132:    */ 
/* 133:    */   public double[] getDataArray(int cmp, DiscreteDisplayDomain domain)
/* 134:    */   {
/* 135:130 */     double[] data = new double[domain.getLength()];
/* 136:131 */     String str; switch ((str = currentInfo_).hashCode()) {case -1399872293:  if (str.equals("Weights")) break; break; case -21152883:  if (str.equals("PsiE-weights")) {} case 2005309039:  if ((goto 121) && (str.equals("Auto-correlations")))
/* 137:    */       {
/* 138:133 */         fillAutocorrelations(cmp, data, domain);
/* 139:134 */         return data;
/* 140:    */         
/* 141:136 */         fillFilter(cmp, data, domain);
/* 142:137 */         return data;
/* 143:    */         
/* 144:139 */         fillPsie(cmp, data, domain); }
/* 145:140 */       break;
/* 146:    */     }
/* 147:142 */     return null;
/* 148:    */     
/* 149:144 */     return data;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public double getData(int cmp, int x)
/* 153:    */   {
/* 154:149 */     throw new UnsupportedOperationException("Not supported yet.");
/* 155:    */   }
/* 156:    */   
/* 157:    */   private void fillAutocorrelations(int cmp, double[] data, DiscreteDisplayDomain domain) {
/* 158:153 */     ComponentDescriptor desc = cmpDescs_[cmp];
/* 159:154 */     if (type_ == EstimatorType.Preliminary) {
/* 160:155 */       throw new UnsupportedOperationException("Not yet implemented");
/* 161:    */     }
/* 162:157 */     AutoCovarianceFunction acgf = null;
/* 163:158 */     if (type_ == EstimatorType.Final) {
/* 164:159 */       WienerKolmogorovEstimator estimator = wk_.finalEstimator(cmp, signal);
/* 165:160 */       acgf = estimator.getModel().doStationary().getAutoCovarianceFunction();
/* 166:161 */     } else if (type_ == EstimatorType.Component) {
/* 167:162 */       if (signal) {
/* 168:163 */         acgf = wk_.getUcarimaModel().getComponent(cmp).stationaryTransformation().stationaryModel.getAutoCovarianceFunction();
/* 169:    */       } else {
/* 170:165 */         acgf = wk_.getUcarimaModel().getComplement(cmp).stationaryTransformation().stationaryModel.getAutoCovarianceFunction();
/* 171:    */       }
/* 172:    */     }
/* 173:168 */     if (acgf == null) {
/* 174:169 */       return;
/* 175:    */     }
/* 176:    */     
/* 177:172 */     acgf.prepare(beg + data.length);
/* 178:173 */     double var = acgf.get(0);
/* 179:174 */     for (int i = 0; i < data.length; i++) {
/* 180:175 */       data[i] = (acgf.get(i + beg) / var);
/* 181:    */     }
/* 182:    */   }
/* 183:    */   
/* 184:    */   private void fillFilter(int cmp, double[] data, DiscreteDisplayDomain domain) {
/* 185:180 */     ComponentDescriptor desc = cmpDescs_[cmp];
/* 186:181 */     if (type_ == EstimatorType.Preliminary) {
/* 187:182 */       throw new UnsupportedOperationException("Not yet implemented");
/* 188:    */     }
/* 189:184 */     if (type_ == EstimatorType.Final) {
/* 190:185 */       WienerKolmogorovEstimator estimator = wk_.finalEstimator(cmp, signal);
/* 191:186 */       RationalFilter rf = estimator.getFilter();
/* 192:187 */       for (int i = 0; i < data.length; i++) {
/* 193:188 */         data[i] = rf.getWeight(domain.x(i));
/* 194:    */       }
/* 195:    */     } else {
/* 196:191 */       throw new UnsupportedOperationException();
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   private void fillPsie(int cmp, double[] data, DiscreteDisplayDomain domain)
/* 201:    */   {
/* 202:197 */     ComponentDescriptor desc = cmpDescs_[cmp];
/* 203:198 */     if (type_ != EstimatorType.Final) {
/* 204:199 */       throw new UnsupportedOperationException();
/* 205:    */     }
/* 206:201 */     if (type_ == EstimatorType.Final) {
/* 207:202 */       WienerKolmogorovEstimator estimator = wk_.finalEstimator(cmp, signal);
/* 208:203 */       RationalFilter rf = estimator.getModel().getFilter();
/* 209:204 */       for (int i = 0; i < data.length; i++) {
/* 210:205 */         data[i] = rf.getWeight(domain.x(i));
/* 211:    */       }
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */ 
/* 216:    */   public static enum EstimatorType
/* 217:    */   {
/* 218:213 */     Component,  Final,  Preliminary;
/* 219:    */   }
/* 220:    */   
/* 221:216 */   private String currentInfo_ = "Square gain";
/* 222:217 */   private EstimatorType type_ = EstimatorType.Final;
/* 223:218 */   private int lag_ = 0;
/* 224:    */   private WienerKolmogorovEstimators wk_;
/* 225:    */   private ComponentDescriptor[] cmpDescs_;
/* 226:221 */   private TsFrequency freq_ = TsFrequency.Undefined;
/* 227:    */   
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */   public WienerKolmogorovUcarimaEstimators(WienerKolmogorovEstimators wk, ComponentDescriptor[] cmps)
/* 233:    */   {
/* 234:229 */     wk_ = wk;
/* 235:230 */     cmpDescs_ = cmps;
/* 236:    */   }
/* 237:    */   
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */   public WienerKolmogorovUcarimaEstimators(UcarimaModel ucm, ComponentDescriptor[] cmps)
/* 243:    */   {
/* 244:239 */     wk_ = new WienerKolmogorovEstimators(ucm);
/* 245:240 */     cmpDescs_ = cmps;
/* 246:    */   }
/* 247:    */   
/* 248:    */ 
/* 249:    */ 
/* 250:    */   public TsFrequency getFrequency()
/* 251:    */   {
/* 252:247 */     return freq_;
/* 253:    */   }
/* 254:    */   
/* 255:    */ 
/* 256:    */ 
/* 257:    */   public void setFrequency(TsFrequency freq_)
/* 258:    */   {
/* 259:254 */     this.freq_ = freq_;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public void setInformation(String info) {
/* 263:258 */     currentInfo_ = info;
/* 264:    */   }
/* 265:    */   
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */   public String getInformation()
/* 271:    */   {
/* 272:267 */     return currentInfo_;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public EstimatorType getType() {
/* 276:271 */     return type_;
/* 277:    */   }
/* 278:    */   
/* 279:    */   public void setType(EstimatorType type) {
/* 280:275 */     type_ = type;
/* 281:    */   }
/* 282:    */   
/* 283:    */   public int getLag() {
/* 284:279 */     return type_ == EstimatorType.Preliminary ? lag_ : 0;
/* 285:    */   }
/* 286:    */   
/* 287:    */   public void setLag(int lag) {
/* 288:283 */     if (type_ == EstimatorType.Preliminary) {
/* 289:284 */       lag_ = lag;
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   public String[] getComponents()
/* 294:    */   {
/* 295:290 */     String[] cmps = new String[cmpDescs_.length];
/* 296:291 */     for (int i = 0; i < cmps.length; i++) {
/* 297:292 */       cmps[i] = cmpDescs_[i].name;
/* 298:    */     }
/* 299:294 */     return cmps;
/* 300:    */   }
/* 301:    */   
/* 302:    */   public double[] getDataArray(int cmp, ContinuousDisplayDomain domain)
/* 303:    */   {
/* 304:299 */     double[] data = new double[npoints];
/* 305:300 */     String str; switch ((str = currentInfo_).hashCode()) {case -2067891215:  if (str.equals("Spectrum")) break; break; case 1505942518:  if (str.equals("Phase effect")) {} case 1996272770:  if ((goto 121) && (str.equals("Square gain")))
/* 306:    */       {
/* 307:302 */         fillGain(cmp, data, domain);
/* 308:303 */         return data;
/* 309:    */         
/* 310:305 */         fillSpectrum(cmp, data, domain);
/* 311:306 */         return data;
/* 312:    */         
/* 313:308 */         fillPhase(cmp, data, domain); }
/* 314:309 */       break;
/* 315:    */     }
/* 316:311 */     return null;
/* 317:    */     
/* 318:313 */     return data;
/* 319:    */   }
/* 320:    */   
/* 321:    */   public double getData(int cmp, double x)
/* 322:    */   {
/* 323:318 */     throw new UnsupportedOperationException("Not supported yet.");
/* 324:    */   }
/* 325:    */   
/* 326:    */   public ContinuousDisplayDomain getContinuousDisplayDomain(int npoints) {
/* 327:    */     String str;
/* 328:323 */     switch ((str = currentInfo_).hashCode()) {case -2067891215:  if (str.equals("Spectrum")) break; break; case 1505942518:  if (str.equals("Phase effect")) {} case 1996272770:  if ((goto 122) && (str.equals("Square gain")))
/* 329:    */       {
/* 330:    */ 
/* 331:326 */         return FrequencyInformationProvider.getDisplayDomain(freq_, npoints);
/* 332:    */         
/* 333:328 */         int ifreq = freq_.intValue() / 2;
/* 334:329 */         if (ifreq == 0) {
/* 335:330 */           ifreq = 6;
/* 336:    */         }
/* 337:332 */         return FrequencyInformationProvider.getDisplayDomain(freq_, 0.0D, 3.141592653589793D / ifreq, npoints); }
/* 338:    */       break; }
/* 339:334 */     return null;
/* 340:    */   }
/* 341:    */   
/* 342:    */   public ContinuousDisplayDomain getContinuousDisplayDomain(double lower, double upper, int npoints)
/* 343:    */   {
/* 344:    */     String str;
/* 345:340 */     switch ((str = currentInfo_).hashCode()) {case -2067891215:  if (str.equals("Spectrum")) break; break; case 1505942518:  if (str.equals("Phase effect")) {} case 1996272770:  if ((goto 153) && (str.equals("Square gain")))
/* 346:    */       {
/* 347:    */ 
/* 348:343 */         return FrequencyInformationProvider.getDisplayDomain(freq_, lower, upper, npoints);
/* 349:    */         
/* 350:345 */         int ifreq = freq_.intValue() / 2;
/* 351:346 */         double fmax = upper;
/* 352:347 */         if (ifreq != 0) {
/* 353:348 */           fmax = Math.min(fmax, 3.141592653589793D / ifreq);
/* 354:    */         } else {
/* 355:350 */           fmax = Math.min(fmax, 0.5235987755982988D);
/* 356:    */         }
/* 357:352 */         return FrequencyInformationProvider.getDisplayDomain(freq_, lower, upper, npoints); }
/* 358:    */       break; }
/* 359:354 */     return null;
/* 360:    */   }
/* 361:    */   
/* 362:    */ 
/* 363:    */   public boolean isDefined(int idx)
/* 364:    */   {
/* 365:360 */     int cmp = cmpDescs_[idx].cmp;
/* 366:361 */     return !wk_.getUcarimaModel().getComponent(cmp).isNull();
/* 367:    */   }
/* 368:    */ }
