/*  1:   */ package ec.tstoolkit.uihelper;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ public class ContinuousDisplayDomain
/*  5:   */ {
/*  6:   */   public final double step;
/*  7:   */   
/*  8:   */   public final double beg;
/*  9:   */   
/* 10:   */   public final double end;
/* 11:   */   
/* 12:   */   public final int npoints;
/* 13:   */   
/* 14:   */   public ContinuousDisplayDomain(double beg, double end, int npoints)
/* 15:   */   {
/* 16:16 */     this.beg = beg;
/* 17:17 */     this.end = end;
/* 18:18 */     this.npoints = npoints;
/* 19:19 */     step = ((end - beg) / (npoints - 1));
/* 20:   */   }
/* 21:   */   
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */   public double x(int i)
/* 27:   */   {
/* 28:28 */     return beg + step * i;
/* 29:   */   }
/* 30:   */ }
