/*  1:   */ package ec.tstoolkit.uihelper;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ public class DiscreteDisplayDomain
/*  6:   */ {
/*  7:   */   public final int beg;
/*  8:   */   
/*  9:   */ 
/* 10:   */   public final int end;
/* 11:   */   
/* 12:   */ 
/* 13:   */   public DiscreteDisplayDomain(int beg, int end)
/* 14:   */   {
/* 15:15 */     this.beg = beg;
/* 16:16 */     this.end = end;
/* 17:   */   }
/* 18:   */   
/* 19:   */ 
/* 20:   */ 
/* 21:   */   public int x(int i)
/* 22:   */   {
/* 23:23 */     return beg + i;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int getLength()
/* 27:   */   {
/* 28:28 */     return end - beg + 1;
/* 29:   */   }
/* 30:   */ }
