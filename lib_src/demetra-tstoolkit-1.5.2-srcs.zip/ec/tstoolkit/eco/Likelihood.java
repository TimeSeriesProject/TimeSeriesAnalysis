/*
* Copyright 2013 National Bank of Belgium
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved 
* by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and 
* limitations under the Licence.
*/
package ec.tstoolkit.eco;

/**
 * Usual likelihood for a multi-variate gaussian distribution.
 * For a N(0, sig2*V) distribution (dim = n), the log-likelihood is given by 
 * -.5*[n*log(2*pi)+log(det(V)*sig2^n)+(1/sig2)*y*(V^-1)y] =
 * -.5*[n*log(2*pi)+log(det(V))+n*log(sig2)+(1/sig2)*ee']
 * We consider that sig2 is given by its max-likelihood estimator:
 * sig2=ee'/n where ee'= y*(V^-1)y.
 * 
 */
public class Likelihood implements ILikelihood {

    private double m_ll, m_ssqerr, m_ldet;

    private int m_n;

    private double[] m_res;

    /**
	 *
	 */
    public Likelihood() {
    }

    /**
     * 
     * @param nparams
     * @return
     */
    public double AIC(final int nparams) {
	return -2 * m_ll + 2 * nparams;
    }

    /**
     * 
     * @param nparams
     * @return
     */
    public double BIC(final int nparams) {
	return -2 * m_ll + nparams * Math.log(m_n);
    }

    /**
         *
         */
    public void clear() {
	m_ll = 0;
	m_ssqerr = 0;
	m_ldet = 0;
	m_n = 0;
    }
    
    public double getLogDeterminant(){
        return m_ldet;
    }

    @Override
    public double getFactor() {
	return Math.exp(m_ldet / m_n);
    }

    @Override
    public double getLogLikelihood() {
	return m_ll;
    }

    @Override
    public int getN() {
	return m_n;
    }

    @Override
    public double[] getResiduals() {
	return m_res;
    }

    /**
     * 
     * @return
     */
    public double getSer()
    {
	return Math.sqrt(m_ssqerr / m_n);
    }

    @Override
    public double getSigma() {
	return m_ssqerr / m_n;
    }

    @Override
    public double getSsqErr() {
	return m_ssqerr;
    }

    /**
     * Adjust the likelihood if the data have been pre-multiplied by a given
     * scaling factor
     * 
     * @param factor
     *            The scaling factor
     */
    public void rescale(final double factor) {
	if (factor == 1)
	    return;
	m_ssqerr /= factor * factor;
	m_ll += m_n * Math.log(factor);
	if (m_res != null)
	    for (int i = 0; i < m_res.length; ++i)
		m_res[i] /= factor;
    }

    /**
     * 
     * @param ssqerr
     * @param ldet
     * @param ndim
     */
    public void set(final double ssqerr, final double ldet, final int ndim) {
	m_ll = -.5
		* (ndim * Math.log(2 * Math.PI) + ndim
			* (1 + Math.log(ssqerr / ndim)) + ldet);
	m_ssqerr = ssqerr;
	m_ldet = ldet;
	m_n = ndim;
	m_res = null;
    }

    /**
     * 
     * @param res
     */
    public void setRes(final double[] res) {
	if (res != null)
	    m_res = res.clone();
	else
	    m_res = null;
    }
    
    @Override
    public String toString(){
        StringBuilder builder=new StringBuilder();
        builder.append("ll=").append(this.getLogLikelihood()).append("\r\n");
        builder.append("ssq=").append(this.getSsqErr()).append("\r\n");
        builder.append("ldet=").append(this.getLogDeterminant()).append("\r\n");
        return builder.toString();
        
        
    }

}
