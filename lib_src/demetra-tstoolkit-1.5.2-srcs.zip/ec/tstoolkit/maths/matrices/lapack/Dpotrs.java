/*
* Copyright 2013 National Bank of Belgium
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved 
* by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and 
* limitations under the Licence.
*/


package ec.tstoolkit.maths.matrices.lapack;

/**
 * 
 * @author PCuser
 */
public class Dpotrs {

    /**
     * 
     * @param uplo
     * @param n
     * @param nrhs
     * @param a
     * @param ia
     * @param lda
     * @param b
     * @param ib
     * @param ldb
     * @return
     */
    public static int fn(UPLO uplo, int n, int nrhs, double[] a, int ia,
	    int lda, double[] b, int ib, int ldb) {
	return 0;
    }

    /*
     * SUBROUTINE DPOTRS( UPLO, N, NRHS, A, LDA, B, LDB, INFO )
     * 
     * -- LAPACK routine (version 3.0) -- Univ. of Tennessee, Univ. of
     * California Berkeley, NAG Ltd., Courant Institute, Argonne National Lab,
     * and Rice University March 31, 1993
     * 
     * .. Scalar Arguments .. CHARACTER UPLO INTEGER INFO, LDA, LDB, N, NRHS ..
     * .. Array Arguments .. DOUBLE PRECISION A( LDA, * ), B( LDB, * ) ..
     * 
     * Purpose =======
     * 
     * DPOTRS solves a system of linear equations A*X = B with a symmetric
     * positive definite matrix A using the Cholesky factorization A = U**T*U or
     * A = L*L**T computed by DPOTRF.
     * 
     * Arguments =========
     * 
     * UPLO (input) CHARACTER*1 = 'U': Upper triangle of A is stored; = 'L':
     * Lower triangle of A is stored.
     * 
     * N (input) INTEGER The order of the matrix A. N >= 0.
     * 
     * NRHS (input) INTEGER The number of right hand sides, i.e., the number of
     * columns of the matrix B. NRHS >= 0.
     * 
     * A (input) DOUBLE PRECISION array, dimension (LDA,N) The triangular factor
     * U or L from the Cholesky factorization A = U**T*U or A = L*L**T, as
     * computed by DPOTRF.
     * 
     * LDA (input) INTEGER The leading dimension of the array A. LDA >=
     * max(1,N).
     * 
     * B (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS) On entry,
     * the right hand side matrix B. On exit, the solution matrix X.
     * 
     * LDB (input) INTEGER The leading dimension of the array B. LDB >=
     * max(1,N).
     * 
     * INFO (output) INTEGER = 0: successful exit < 0: if INFO = -i, the i-th
     * argument had an illegal value
     * 
     * =====================================================================
     * 
     * .. Parameters .. DOUBLE PRECISION ONE PARAMETER ( ONE = 1.0D+0 ) .. ..
     * Local Scalars .. LOGICAL UPPER .. .. External Functions .. LOGICAL LSAME
     * EXTERNAL LSAME .. .. External Subroutines .. EXTERNAL DTRSM, XERBLA .. ..
     * Intrinsic Functions .. INTRINSIC MAX .. .. Executable Statements ..
     * 
     * Test the input parameters.
     * 
     * INFO = 0 UPPER = LSAME( UPLO, 'U' ) IF( .NOT.UPPER .AND. .NOT.LSAME(
     * UPLO, 'L' ) ) THEN INFO = -1 ELSE IF( N.LT.0 ) THEN INFO = -2 ELSE IF(
     * NRHS.LT.0 ) THEN INFO = -3 ELSE IF( LDA.LT.MAX( 1, N ) ) THEN INFO = -5
     * ELSE IF( LDB.LT.MAX( 1, N ) ) THEN INFO = -7 END IF IF( INFO.NE.0 ) THEN
     * CALL XERBLA( 'DPOTRS', -INFO ) RETURN END IF
     * 
     * Quick return if possible
     * 
     * IF( N.EQ.0 .OR. NRHS.EQ.0 ) $ RETURN
     * 
     * IF( UPPER ) THEN
     * 
     * Solve A*X = B where A = U'*U.
     * 
     * Solve U'*X = B, overwriting B with X.
     * 
     * CALL DTRSM( 'Left', 'Upper', 'Transpose', 'Non-unit', N, NRHS, $ ONE, A,
     * LDA, B, LDB )
     * 
     * Solve U*X = B, overwriting B with X.
     * 
     * CALL DTRSM( 'Left', 'Upper', 'No transpose', 'Non-unit', N, $ NRHS, ONE,
     * A, LDA, B, LDB ) ELSE
     * 
     * Solve A*X = B where A = L*L'.
     * 
     * Solve L*X = B, overwriting B with X.
     * 
     * CALL DTRSM( 'Left', 'Lower', 'No transpose', 'Non-unit', N, $ NRHS, ONE,
     * A, LDA, B, LDB )
     * 
     * Solve L'*X = B, overwriting B with X.
     * 
     * CALL DTRSM( 'Left', 'Lower', 'Transpose', 'Non-unit', N, NRHS, $ ONE, A,
     * LDA, B, LDB ) END IF
     * 
     * RETURN
     * 
     * End of DPOTRS
     * 
     * END
     */
}
