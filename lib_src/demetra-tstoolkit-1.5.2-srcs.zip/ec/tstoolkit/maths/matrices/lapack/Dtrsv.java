/*
* Copyright 2013 National Bank of Belgium
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved 
* by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and 
* limitations under the Licence.
*/

package ec.tstoolkit.maths.matrices.lapack;

/**
 * 
 * @author PCuser
 */
public class Dtrsv {

    private final static double ZERO = 0.0;

    /**
     * 
     * @param uplo
     * @param trans
     * @param diag
     * @param n
     * @param a
     * @param ia
     * @param lda
     * @param x
     * @param ix
     * @param incx
     * @throws Xerbla
     */
    public static void fn(UPLO uplo, OP trans, DIAG diag, int n, double[] a,
	    int ia, int lda, double[] x, int ix, int incx) throws Xerbla {
	// Purpose
	// =======
	// DTRSV solves one of the systems of equations
	// A*x = b, or A'*x = b,
	// where b and x are n element vectors and A is an n by n unit, or
	// non-unit, upper or lower triangular matrix.
	// No test for singularity or near-singularity is included in this
	// routine. Such tests must be performed before calling this routine.
	// Parameters
	// ==========
	// UPLO - CHARACTER*1.
	// On entry, UPLO specifies whether the matrix is an upper or
	// lower triangular matrix as follows:
	// UPLO = 'U' or 'u' A is an upper triangular matrix.
	// UPLO = 'L' or 'l' A is a lower triangular matrix.
	// Unchanged on exit.
	// TRANS - CHARACTER*1.
	// On entry, TRANS specifies the equations to be solved as
	// follows:
	// TRANS = 'N' or 'n' A*x = b.
	// TRANS = 'T' or 't' A'*x = b.
	// TRANS = 'C' or 'c' A'*x = b.
	// Unchanged on exit.
	// DIAG - CHARACTER*1.
	// On entry, DIAG specifies whether or not A is unit
	// triangular as follows:
	// DIAG = 'U' or 'u' A is assumed to be unit triangular.
	// DIAG = 'N' or 'n' A is not assumed to be unit
	// triangular.
	// Unchanged on exit.
	// N - INTEGER.
	// On entry, N specifies the order of the matrix A.
	// N must be at least zero.
	// Unchanged on exit.
	// A - DOUBLE PRECISION array of DIMENSION ( LDA, n ).
	// Before entry with UPLO = 'U' or 'u', the leading n by n
	// upper triangular part of the array A must contain the upper
	// triangular matrix and the strictly lower triangular part of
	// A is not referenced.
	// Before entry with UPLO = 'L' or 'l', the leading n by n
	// lower triangular part of the array A must contain the lower
	// triangular matrix and the strictly upper triangular part of
	// A is not referenced.
	// Note that when DIAG = 'U' or 'u', the diagonal elements of
	// A are not referenced either, but are assumed to be unity.
	// Unchanged on exit.
	// LDA - INTEGER.
	// On entry, LDA specifies the first dimension of A as declared
	// in the calling (sub) program. LDA must be at least
	// max( 1, n ).
	// Unchanged on exit.
	// X - DOUBLE PRECISION array of dimension at least
	// ( 1 + ( n - 1 )*abs( INCX ) ).
	// Before entry, the incremented array X must contain the n
	// element right-hand side vector b. On exit, X is overwritten
	// with the solution vector x.
	// INCX - INTEGER.
	// On entry, INCX specifies the increment for the elements of
	// X. INCX must not be zero.
	// Unchanged on exit.
	int info = 0;
	if (n < 0) {
	    info = 4;
	} else if (lda < Math.max(1, n)) {
	    info = 6;
	} else if (incx == 0) {
	    info = 8;
	}
	if (info != 0) {
	    throw new Xerbla("dtrsv", info);
	}
	// Quick return if possible.
	if (n == 0) {
	    return;
	}
	// Start the operations. In this version the elements of A are
	// accessed sequentially with one pass through A.
	if (trans != OP.Transpose) {
	    // Form x := inv( A )*x.
	    if (uplo == UPLO.Upper) {
		if (incx == 1) {
		    for (int j = n - 1; j >= 0; --j)
			if (x[ix + j] != ZERO) {
			    if (diag != DIAG.Unit) {
				x[ix + j] /= a[ia + j * lda + j];
			    }
			    double temp = x[ix + j];
			    for (int i = j - 1; i >= 0; --i)
				x[ix + i] -= temp * a[ia + i + j * lda];
			}
		} else {
		    for (int j = n - 1, jx = ix + (n - 1) * incx; j >= 0; --j, jx -= incx)
			if (x[jx] != ZERO) {
			    if (diag != DIAG.Unit) {
				x[jx] /= a[ia + j * lda + j];
			    }
			    double temp = x[jx];
			    for (int i = j - 1, iw = jx - incx; i >= 0; --i, iw -= incx)
				x[iw] -= temp * a[ia + i + j * lda];
			}
		}
	    } else if (incx == 1) {
		for (int j = 0, ixj = ix + j, iajj = ia; j < n; ++j, ++ixj, iajj += lda + 1)
		    if (x[ixj] != ZERO) {
			if (diag != DIAG.Unit) {
			    x[ixj] /= a[iajj];
			}
			double temp = x[ixj];
			for (int i = j + 1, iaij = ia + i + j * lda; i < n; ++i, ++iaij)
			    x[ix + i] -= temp * a[iaij];
		    }
	    } else {
		for (int j = 0, jx = ix; j < n; ++j, jx += incx)
		    if (x[jx] != ZERO) {
			if (diag != DIAG.Unit) {
			    x[jx] /= a[ia + j * lda + j];
			}
			double temp = x[jx];
			for (int i = j + 1, iw = jx + incx; i < n; ++i, iw += incx)
			    x[iw] -= temp * a[ia + i + j * lda];
		    }
	    }
	} else // Form x := inv( A' )*x.
	{
	    if (uplo == UPLO.Upper) {
		if (incx == 1) {
		    for (int j = 0; j < n; ++j) {
			double temp = x[ix + j];
			for (int i = 0; i < j; ++i)
			    temp -= x[ix + i] * a[ia + i + j * lda];
			if (diag != DIAG.Unit) {
			    temp /= a[ia + j + j * lda];
			}
			x[ia + j] = temp;
		    }
		} else {
		    for (int j = 0, iv = ix; j < n; ++j, iv += incx) {
			double temp = x[iv];
			for (int i = 0, iw = ix; i < j; ++i, iw += incx)
			    temp -= x[iw] * a[ia + i + j * lda];
			if (diag != DIAG.Unit) {
			    temp /= a[ia + j + j * lda];
			}
			x[iv] = temp;
		    }
		}
	    } else {
		if (incx == 1) {
		    int ixn = ix + n - 1;
		    int ian = ia + (n - 1) * lda;
		    for (int j = ixn, it = ian; j >= 0; --j, it -= lda) {
			double temp = x[j];
			for (int i = ixn; i != j; --i)
			    temp -= x[i] * a[it + i];
			if (diag != DIAG.Unit) {
			    temp /= a[it + j];
			}
			x[j] = temp;
		    }
		} else {
		    for (int j = n - 1, iv = ix + j * incx; j >= 0; --j, iv -= incx) {
			double temp = x[iv];
			for (int i = n - 1, iw = ix + i * incx; i > j; --i, iw -= incx)
			    temp -= x[iw] * a[ia + i + j * lda];
			if (diag != DIAG.Unit) {
			    temp /= a[ia + j + j * lda];
			}
			x[iv] = temp;
		    }
		}
	    }
	}
    }
}
