/*
* Copyright 2013 National Bank of Belgium
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved 
* by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and 
* limitations under the Licence.
*/


package ec.tstoolkit.maths.matrices.lapack;

/**
 * 
 * @author PCuser
 */
public class Dgeqrf {

    /*
     * SUBROUTINE DGEQRF( M, N, A, LDA, TAU, WORK, LWORK, INFO )
     * 
     * -- LAPACK routine (version 3.0) -- Univ. of Tennessee, Univ. of
     * California Berkeley, NAG Ltd., Courant Institute, Argonne National Lab,
     * and Rice University June 30, 1999
     * 
     * .. Scalar Arguments .. INTEGER INFO, LDA, LWORK, M, N .. .. Array
     * Arguments .. DOUBLE PRECISION A( LDA, * ), TAU( * ), WORK( * ) ..
     * 
     * Purpose =======
     * 
     * DGEQRF computes a QR factorization of a real M-by-N matrix A: A = Q * R.
     * 
     * Arguments =========
     * 
     * M (input) INTEGER The number of rows of the matrix A. M >= 0.
     * 
     * N (input) INTEGER The number of columns of the matrix A. N >= 0.
     * 
     * A (input/output) DOUBLE PRECISION array, dimension (LDA,N) On entry, the
     * M-by-N matrix A. On exit, the elements on and above the diagonal of the
     * array contain the min(M,N)-by-N upper trapezoidal matrix R (R is upper
     * triangular if m >= n); the elements below the diagonal, with the array
     * TAU, represent the orthogonal matrix Q as a product of min(m,n)
     * elementary reflectors (see Further Details).
     * 
     * LDA (input) INTEGER The leading dimension of the array A. LDA >=
     * max(1,M).
     * 
     * TAU (output) DOUBLE PRECISION array, dimension (min(M,N)) The scalar
     * factors of the elementary reflectors (see Further Details).
     * 
     * WORK (workspace/output) DOUBLE PRECISION array, dimension (LWORK) On
     * exit, if INFO = 0, WORK(1) returns the optimal LWORK.
     * 
     * LWORK (input) INTEGER The dimension of the array WORK. LWORK >= max(1,N).
     * For optimum performance LWORK >= N*NB, where NB is the optimal blocksize.
     * 
     * If LWORK = -1, then a workspace query is assumed; the routine only
     * calculates the optimal size of the WORK array, returns this value as the
     * first entry of the WORK array, and no error message related to LWORK is
     * issued by XERBLA.
     * 
     * INFO (output) INTEGER = 0: successful exit < 0: if INFO = -i, the i-th
     * argument had an illegal value
     * 
     * Further Details ===============
     * 
     * The matrix Q is represented as a product of elementary reflectors
     * 
     * Q = H(1) H(2) . . . H(k), where k = min(m,n).
     * 
     * Each H(i) has the form
     * 
     * H(i) = I - tau * v * v'
     * 
     * where tau is a real scalar, and v is a real vector with v(1:i-1) = 0 and
     * v(i) = 1; v(i+1:m) is stored on exit in A(i+1:m,i), and tau in TAU(i).
     * 
     * =====================================================================
     * 
     * .. Local Scalars .. LOGICAL LQUERY INTEGER I, IB, IINFO, IWS, K, LDWORK,
     * LWKOPT, NB, $ NBMIN, NX .. .. External Subroutines .. EXTERNAL DGEQR2,
     * DLARFB, DLARFT, XERBLA .. .. Intrinsic Functions .. INTRINSIC MAX, MIN ..
     * .. External Functions .. INTEGER ILAENV EXTERNAL ILAENV .. .. Executable
     * Statements ..
     * 
     * Test the input arguments
     * 
     * INFO = 0 NB = ILAENV( 1, 'DGEQRF', ' ', M, N, -1, -1 ) LWKOPT = N*NB
     * WORK( 1 ) = LWKOPT LQUERY = ( LWORK.EQ.-1 ) IF( M.LT.0 ) THEN INFO = -1
     * ELSE IF( N.LT.0 ) THEN INFO = -2 ELSE IF( LDA.LT.MAX( 1, M ) ) THEN INFO
     * = -4 ELSE IF( LWORK.LT.MAX( 1, N ) .AND. .NOT.LQUERY ) THEN INFO = -7 END
     * IF IF( INFO.NE.0 ) THEN CALL XERBLA( 'DGEQRF', -INFO ) RETURN ELSE IF(
     * LQUERY ) THEN RETURN END IF
     * 
     * Quick return if possible
     * 
     * K = MIN( M, N ) IF( K.EQ.0 ) THEN WORK( 1 ) = 1 RETURN END IF
     * 
     * NBMIN = 2 NX = 0 IWS = N IF( NB.GT.1 .AND. NB.LT.K ) THEN
     * 
     * Determine when to cross over from blocked to unblocked code.
     * 
     * NX = MAX( 0, ILAENV( 3, 'DGEQRF', ' ', M, N, -1, -1 ) ) IF( NX.LT.K )
     * THEN
     * 
     * Determine if workspace is large enough for blocked code.
     * 
     * LDWORK = N IWS = LDWORK*NB IF( LWORK.LT.IWS ) THEN
     * 
     * Not enough workspace to use optimal NB: reduce NB and determine the
     * minimum value of NB.
     * 
     * NB = LWORK / LDWORK NBMIN = MAX( 2, ILAENV( 2, 'DGEQRF', ' ', M, N, -1, $
     * -1 ) ) END IF END IF END IF
     * 
     * IF( NB.GE.NBMIN .AND. NB.LT.K .AND. NX.LT.K ) THEN
     * 
     * Use blocked code initially
     * 
     * DO 10 I = 1, K - NX, NB IB = MIN( K-I+1, NB )
     * 
     * Compute the QR factorization of the current block A(i:m,i:i+ib-1)
     * 
     * CALL DGEQR2( M-I+1, IB, A( I, I ), LDA, TAU( I ), WORK, $ IINFO ) IF(
     * I+IB.LE.N ) THEN
     * 
     * Form the triangular factor of the block reflector H = H(i) H(i+1) . . .
     * H(i+ib-1)
     * 
     * CALL DLARFT( 'Forward', 'Columnwise', M-I+1, IB, $ A( I, I ), LDA, TAU( I
     * ), WORK, LDWORK )
     * 
     * Apply H' to A(i:m,i+ib:n) from the left
     * 
     * CALL DLARFB( 'Left', 'Transpose', 'Forward', $ 'Columnwise', M-I+1,
     * N-I-IB+1, IB, $ A( I, I ), LDA, WORK, LDWORK, A( I, I+IB ), $ LDA, WORK(
     * IB+1 ), LDWORK ) END IF 10 CONTINUE ELSE I = 1 END IF
     * 
     * Use unblocked code to factor the last or only block.
     * 
     * IF( I.LE.K ) $ CALL DGEQR2( M-I+1, N-I+1, A( I, I ), LDA, TAU( I ), WORK,
     * $ IINFO )
     * 
     * WORK( 1 ) = IWS RETURN
     * 
     * End of DGEQRF
     * 
     * END
     */
}
