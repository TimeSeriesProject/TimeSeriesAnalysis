/*
* Copyright 2013 National Bank of Belgium
*
* Licensed under the EUPL, Version 1.1 or – as soon they will be approved 
* by the European Commission - subsequent versions of the EUPL (the "Licence");
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at:
*
* http://ec.europa.eu/idabc/eupl
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the Licence is distributed on an "AS IS" basis,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the Licence for the specific language governing permissions and 
* limitations under the Licence.
*/
package ec.tstoolkit.dstats;

import ec.tstoolkit.BaseException;
import ec.tstoolkit.design.Development;

/**
 * 
 * @author Jean Palate
 */
@Development(status = Development.Status.Alpha)
public class DStatException extends BaseException {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1194137043460644262L;

    /**
         *
         */
    public static final String ERR_INV_SMALL = "Can't compute probability inverse (value is too near 0 or 1)",
	    ERR_ITER = "Too many iterations in search procedure", ERR_PARAM = "Invalid definition";

    /**
     *
     */
    public DStatException() {
    }

    /**
     * 
     * @param msg
     */
    public DStatException(final String msg) {
	super(msg);
    }

    /**
     * 
     * @param msg
     * @param distribution
     */
    public DStatException(final String msg, final String distribution) {
	super(msg, distribution, 0);
    }

}
