package com.toedter.calendar;

import java.util.Calendar;
import java.util.Date;

public class DateUtil
{
  protected Date minSelectableDate;
  protected Date maxSelectableDate;
  protected Date defaultMinSelectableDate;
  protected Date defaultMaxSelectableDate;
  
  public DateUtil()
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(1, 0, 1, 1, 1);
    defaultMinSelectableDate = localCalendar.getTime();
    minSelectableDate = defaultMinSelectableDate;
    localCalendar.set(9999, 0, 1, 1, 1);
    defaultMaxSelectableDate = localCalendar.getTime();
    maxSelectableDate = defaultMaxSelectableDate;
  }
  
  public void setSelectableDateRange(Date paramDate1, Date paramDate2)
  {
    if (paramDate1 == null) {
      minSelectableDate = defaultMinSelectableDate;
    } else {
      minSelectableDate = paramDate1;
    }
    if (paramDate2 == null) {
      maxSelectableDate = defaultMaxSelectableDate;
    } else {
      maxSelectableDate = paramDate2;
    }
    if (maxSelectableDate.before(minSelectableDate))
    {
      minSelectableDate = defaultMinSelectableDate;
      maxSelectableDate = defaultMaxSelectableDate;
    }
  }
  
  public Date setMaxSelectableDate(Date paramDate)
  {
    if (paramDate == null) {
      maxSelectableDate = defaultMaxSelectableDate;
    } else {
      maxSelectableDate = paramDate;
    }
    return maxSelectableDate;
  }
  
  public Date setMinSelectableDate(Date paramDate)
  {
    if (paramDate == null) {
      minSelectableDate = defaultMinSelectableDate;
    } else {
      minSelectableDate = paramDate;
    }
    return minSelectableDate;
  }
  
  public Date getMaxSelectableDate()
  {
    return maxSelectableDate;
  }
  
  public Date getMinSelectableDate()
  {
    return minSelectableDate;
  }
  
  public boolean checkDate(Date paramDate)
  {
    Calendar localCalendar1 = Calendar.getInstance();
    localCalendar1.setTime(paramDate);
    localCalendar1.set(11, 0);
    localCalendar1.set(12, 0);
    localCalendar1.set(13, 0);
    localCalendar1.set(14, 0);
    Calendar localCalendar2 = Calendar.getInstance();
    localCalendar2.setTime(minSelectableDate);
    localCalendar2.set(11, 0);
    localCalendar2.set(12, 0);
    localCalendar2.set(13, 0);
    localCalendar2.set(14, 0);
    Calendar localCalendar3 = Calendar.getInstance();
    localCalendar3.setTime(maxSelectableDate);
    localCalendar3.set(11, 0);
    localCalendar3.set(12, 0);
    localCalendar3.set(13, 0);
    localCalendar3.set(14, 0);
    return (!localCalendar1.before(localCalendar2)) && (!localCalendar1.after(localCalendar3));
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.DateUtil
 * JD-Core Version:    0.7.0.1
 */