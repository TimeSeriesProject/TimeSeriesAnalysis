package com.toedter.calendar;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DateEditor;
import javax.swing.SpinnerDateModel;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JSpinnerDateEditor
  extends JSpinner
  implements IDateEditor, FocusListener, ChangeListener
{
  private static final long serialVersionUID = 5692204052306085316L;
  protected Date date;
  protected String dateFormatString;
  protected SimpleDateFormat dateFormatter = (SimpleDateFormat)DateFormat.getDateInstance(2);
  
  public JSpinnerDateEditor()
  {
    super(new SpinnerDateModel());
    ((JSpinner.DateEditor)getEditor()).getTextField().addFocusListener(this);
    DateUtil localDateUtil = new DateUtil();
    setMinSelectableDate(localDateUtil.getMinSelectableDate());
    setMaxSelectableDate(localDateUtil.getMaxSelectableDate());
    ((JSpinner.DateEditor)getEditor()).getTextField().setFocusLostBehavior(3);
    addChangeListener(this);
  }
  
  public Date getDate()
  {
    if (date == null) {
      return null;
    }
    return ((SpinnerDateModel)getModel()).getDate();
  }
  
  public void setDate(Date paramDate)
  {
    setDate(paramDate, true);
  }
  
  public void setDate(Date paramDate, boolean paramBoolean)
  {
    Date localDate = date;
    date = paramDate;
    if (paramDate == null)
    {
      ((JSpinner.DateEditor)getEditor()).getFormat().applyPattern("");
      ((JSpinner.DateEditor)getEditor()).getTextField().setText("");
    }
    else if (paramBoolean)
    {
      if (dateFormatString != null) {
        ((JSpinner.DateEditor)getEditor()).getFormat().applyPattern(dateFormatString);
      }
      ((SpinnerDateModel)getModel()).setValue(paramDate);
    }
    firePropertyChange("date", localDate, paramDate);
  }
  
  public void setDateFormatString(String paramString)
  {
    try
    {
      dateFormatter.applyPattern(paramString);
    }
    catch (RuntimeException localRuntimeException)
    {
      dateFormatter = ((SimpleDateFormat)DateFormat.getDateInstance(2));
      dateFormatter.setLenient(false);
    }
    dateFormatString = dateFormatter.toPattern();
    setToolTipText(dateFormatString);
    if (date != null) {
      ((JSpinner.DateEditor)getEditor()).getFormat().applyPattern(dateFormatString);
    } else {
      ((JSpinner.DateEditor)getEditor()).getFormat().applyPattern("");
    }
    if (date != null)
    {
      String str = dateFormatter.format(date);
      ((JSpinner.DateEditor)getEditor()).getTextField().setText(str);
    }
  }
  
  public String getDateFormatString()
  {
    return dateFormatString;
  }
  
  public JComponent getUiComponent()
  {
    return this;
  }
  
  public void setLocale(Locale paramLocale)
  {
    super.setLocale(paramLocale);
    dateFormatter = ((SimpleDateFormat)DateFormat.getDateInstance(2, paramLocale));
    setEditor(new JSpinner.DateEditor(this, dateFormatter.toPattern()));
    setDateFormatString(dateFormatter.toPattern());
  }
  
  public void focusLost(FocusEvent paramFocusEvent)
  {
    String str = ((JSpinner.DateEditor)getEditor()).getTextField().getText();
    if (str.length() == 0) {
      setDate(null);
    }
  }
  
  public void focusGained(FocusEvent paramFocusEvent) {}
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    if (!paramBoolean) {
      ((JSpinner.DateEditor)getEditor()).getTextField().setBackground(UIManager.getColor("TextField.inactiveBackground"));
    }
  }
  
  public Date getMaxSelectableDate()
  {
    return (Date)((SpinnerDateModel)getModel()).getEnd();
  }
  
  public Date getMinSelectableDate()
  {
    return (Date)((SpinnerDateModel)getModel()).getStart();
  }
  
  public void setMaxSelectableDate(Date paramDate)
  {
    ((SpinnerDateModel)getModel()).setEnd(paramDate);
  }
  
  public void setMinSelectableDate(Date paramDate)
  {
    ((SpinnerDateModel)getModel()).setStart(paramDate);
  }
  
  public void setSelectableDateRange(Date paramDate1, Date paramDate2)
  {
    setMaxSelectableDate(paramDate2);
    setMinSelectableDate(paramDate1);
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    setDate(((SpinnerDateModel)getModel()).getDate(), false);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JSpinnerDateEditor
 * JD-Core Version:    0.7.0.1
 */