package com.toedter.calendar;

import java.awt.Color;
import java.util.Date;

public class MinMaxDateEvaluator
  implements IDateEvaluator
{
  private DateUtil dateUtil = new DateUtil();
  
  public boolean isSpecial(Date paramDate)
  {
    return false;
  }
  
  public Color getSpecialForegroundColor()
  {
    return null;
  }
  
  public Color getSpecialBackroundColor()
  {
    return null;
  }
  
  public String getSpecialTooltip()
  {
    return null;
  }
  
  public boolean isInvalid(Date paramDate)
  {
    return !dateUtil.checkDate(paramDate);
  }
  
  public Color getInvalidForegroundColor()
  {
    return null;
  }
  
  public Color getInvalidBackroundColor()
  {
    return null;
  }
  
  public String getInvalidTooltip()
  {
    return null;
  }
  
  public Date setMaxSelectableDate(Date paramDate)
  {
    return dateUtil.setMaxSelectableDate(paramDate);
  }
  
  public Date setMinSelectableDate(Date paramDate)
  {
    return dateUtil.setMinSelectableDate(paramDate);
  }
  
  public Date getMaxSelectableDate()
  {
    return dateUtil.getMaxSelectableDate();
  }
  
  public Date getMinSelectableDate()
  {
    return dateUtil.getMinSelectableDate();
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.MinMaxDateEvaluator
 * JD-Core Version:    0.7.0.1
 */