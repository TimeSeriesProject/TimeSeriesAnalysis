package com.toedter.calendar;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;

public class JDayChooser
  extends JPanel
  implements ActionListener, KeyListener, FocusListener
{
  private static final long serialVersionUID = 5876398337018781820L;
  protected JButton[] days;
  protected JButton[] weeks;
  protected JButton selectedDay;
  protected JPanel weekPanel;
  protected JPanel dayPanel;
  protected int day;
  protected Color oldDayBackgroundColor;
  protected Color selectedColor;
  protected Color sundayForeground;
  protected Color weekdayForeground;
  protected Color decorationBackgroundColor;
  protected String[] dayNames;
  protected Calendar calendar;
  protected Calendar today;
  protected Locale locale;
  protected boolean initialized;
  protected boolean weekOfYearVisible;
  protected boolean decorationBackgroundVisible = true;
  protected boolean decorationBordersVisible;
  protected boolean dayBordersVisible;
  private boolean alwaysFireDayProperty;
  protected int maxDayCharacters;
  protected List dateEvaluators;
  protected MinMaxDateEvaluator minMaxDateEvaluator;
  
  public JDayChooser()
  {
    this(false);
  }
  
  public JDayChooser(boolean paramBoolean)
  {
    setName("JDayChooser");
    setBackground(Color.blue);
    dateEvaluators = new ArrayList(1);
    minMaxDateEvaluator = new MinMaxDateEvaluator();
    addDateEvaluator(minMaxDateEvaluator);
    weekOfYearVisible = paramBoolean;
    locale = Locale.getDefault();
    days = new JButton[49];
    selectedDay = null;
    calendar = Calendar.getInstance(locale);
    today = ((Calendar)calendar.clone());
    setLayout(new BorderLayout());
    dayPanel = new JPanel();
    dayPanel.setLayout(new GridLayout(7, 7));
    sundayForeground = new Color(164, 0, 0);
    weekdayForeground = new Color(0, 90, 164);
    decorationBackgroundColor = new Color(210, 228, 238);
    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 7; j++)
      {
        int k = j + 7 * i;
        if (i == 0)
        {
          days[k] = new DecoratorButton();
        }
        else
        {
          days[k = new JButton("x")
          {
            private static final long serialVersionUID = -7433645992591669725L;
            
            public void paint(Graphics paramAnonymousGraphics)
            {
              if (("Windows".equals(UIManager.getLookAndFeel().getID())) && (selectedDay == this))
              {
                paramAnonymousGraphics.setColor(selectedColor);
                paramAnonymousGraphics.fillRect(0, 0, getWidth(), getHeight());
              }
              super.paint(paramAnonymousGraphics);
            }
          };
          days[k].addActionListener(this);
          days[k].addKeyListener(this);
          days[k].addFocusListener(this);
        }
        days[k].setMargin(new Insets(0, 0, 0, 0));
        days[k].setFocusPainted(false);
        dayPanel.add(days[k]);
      }
    }
    weekPanel = new JPanel();
    weekPanel.setLayout(new GridLayout(7, 1));
    weeks = new JButton[7];
    for (i = 0; i < 7; i++)
    {
      weeks[i] = new DecoratorButton();
      weeks[i].setMargin(new Insets(0, 0, 0, 0));
      weeks[i].setFocusPainted(false);
      weeks[i].setForeground(new Color(100, 100, 100));
      if (i != 0) {
        weeks[i].setText("0" + (i + 1));
      }
      weekPanel.add(weeks[i]);
    }
    init();
    setDay(Calendar.getInstance().get(5));
    add(dayPanel, "Center");
    if (paramBoolean) {
      add(weekPanel, "West");
    }
    initialized = true;
    updateUI();
  }
  
  protected void init()
  {
    JButton localJButton = new JButton();
    oldDayBackgroundColor = localJButton.getBackground();
    selectedColor = new Color(160, 160, 160);
    Date localDate = calendar.getTime();
    calendar = Calendar.getInstance(locale);
    calendar.setTime(localDate);
    drawDayNames();
    drawDays();
  }
  
  private void drawDayNames()
  {
    int i = calendar.getFirstDayOfWeek();
    DateFormatSymbols localDateFormatSymbols = new DateFormatSymbols(locale);
    dayNames = localDateFormatSymbols.getShortWeekdays();
    int j = i;
    for (int k = 0; k < 7; k++)
    {
      if ((maxDayCharacters > 0) && (maxDayCharacters < 5) && (dayNames[j].length() >= maxDayCharacters)) {
        dayNames[j] = dayNames[j].substring(0, maxDayCharacters);
      }
      days[k].setText(dayNames[j]);
      if (j == 1) {
        days[k].setForeground(sundayForeground);
      } else {
        days[k].setForeground(weekdayForeground);
      }
      if (j < 7) {
        j++;
      } else {
        j -= 6;
      }
    }
  }
  
  protected void initDecorations()
  {
    for (int i = 0; i < 7; i++)
    {
      days[i].setContentAreaFilled(decorationBackgroundVisible);
      days[i].setBorderPainted(decorationBordersVisible);
      days[i].invalidate();
      days[i].repaint();
      weeks[i].setContentAreaFilled(decorationBackgroundVisible);
      weeks[i].setBorderPainted(decorationBordersVisible);
      weeks[i].invalidate();
      weeks[i].repaint();
    }
  }
  
  protected void drawWeeks()
  {
    Calendar localCalendar = (Calendar)calendar.clone();
    for (int i = 1; i < 7; i++)
    {
      localCalendar.set(5, i * 7 - 6);
      int j = localCalendar.get(3);
      String str = Integer.toString(j);
      if (j < 10) {
        str = "0" + str;
      }
      weeks[i].setText(str);
      if ((i == 5) || (i == 6)) {
        weeks[i].setVisible(days[(i * 7)].isVisible());
      }
    }
  }
  
  protected void drawDays()
  {
    Calendar localCalendar = (Calendar)calendar.clone();
    localCalendar.set(11, 0);
    localCalendar.set(12, 0);
    localCalendar.set(13, 0);
    localCalendar.set(14, 0);
    int i = localCalendar.getFirstDayOfWeek();
    localCalendar.set(5, 1);
    int j = localCalendar.get(7) - i;
    if (j < 0) {
      j += 7;
    }
    for (int k = 0; k < j; k++)
    {
      days[(k + 7)].setVisible(false);
      days[(k + 7)].setText("");
    }
    localCalendar.add(2, 1);
    Date localDate1 = localCalendar.getTime();
    localCalendar.add(2, -1);
    Date localDate2 = localCalendar.getTime();
    int m = 0;
    Color localColor = getForeground();
    while (localDate2.before(localDate1))
    {
      days[(k + m + 7)].setText(Integer.toString(m + 1));
      days[(k + m + 7)].setVisible(true);
      if ((localCalendar.get(6) == today.get(6)) && (localCalendar.get(1) == today.get(1))) {
        days[(k + m + 7)].setForeground(sundayForeground);
      } else {
        days[(k + m + 7)].setForeground(localColor);
      }
      if (m + 1 == day)
      {
        days[(k + m + 7)].setBackground(selectedColor);
        selectedDay = days[(k + m + 7)];
      }
      else
      {
        days[(k + m + 7)].setBackground(oldDayBackgroundColor);
      }
      Iterator localIterator = dateEvaluators.iterator();
      days[(k + m + 7)].setEnabled(true);
      while (localIterator.hasNext())
      {
        IDateEvaluator localIDateEvaluator = (IDateEvaluator)localIterator.next();
        if (localIDateEvaluator.isSpecial(localDate2))
        {
          days[(k + m + 7)].setForeground(localIDateEvaluator.getSpecialForegroundColor());
          days[(k + m + 7)].setBackground(localIDateEvaluator.getSpecialBackroundColor());
          days[(k + m + 7)].setToolTipText(localIDateEvaluator.getSpecialTooltip());
          days[(k + m + 7)].setEnabled(true);
        }
        if (localIDateEvaluator.isInvalid(localDate2))
        {
          days[(k + m + 7)].setForeground(localIDateEvaluator.getInvalidForegroundColor());
          days[(k + m + 7)].setBackground(localIDateEvaluator.getInvalidBackroundColor());
          days[(k + m + 7)].setToolTipText(localIDateEvaluator.getInvalidTooltip());
          days[(k + m + 7)].setEnabled(false);
        }
      }
      m++;
      localCalendar.add(5, 1);
      localDate2 = localCalendar.getTime();
    }
    for (int n = m + k + 7; n < 49; n++)
    {
      days[n].setVisible(false);
      days[n].setText("");
    }
    drawWeeks();
  }
  
  public Locale getLocale()
  {
    return locale;
  }
  
  public void setLocale(Locale paramLocale)
  {
    if (!initialized)
    {
      super.setLocale(paramLocale);
    }
    else
    {
      locale = paramLocale;
      super.setLocale(paramLocale);
      init();
    }
  }
  
  public void setDay(int paramInt)
  {
    if (paramInt < 1) {
      paramInt = 1;
    }
    Calendar localCalendar = (Calendar)calendar.clone();
    localCalendar.set(5, 1);
    localCalendar.add(2, 1);
    localCalendar.add(5, -1);
    int i = localCalendar.get(5);
    if (paramInt > i) {
      paramInt = i;
    }
    int j = day;
    day = paramInt;
    if (selectedDay != null)
    {
      selectedDay.setBackground(oldDayBackgroundColor);
      selectedDay.repaint();
    }
    for (int k = 7; k < 49; k++) {
      if (days[k].getText().equals(Integer.toString(day)))
      {
        selectedDay = days[k];
        selectedDay.setBackground(selectedColor);
        break;
      }
    }
    if (alwaysFireDayProperty) {
      firePropertyChange("day", 0, day);
    } else {
      firePropertyChange("day", j, day);
    }
  }
  
  public void setAlwaysFireDayProperty(boolean paramBoolean)
  {
    alwaysFireDayProperty = paramBoolean;
  }
  
  public int getDay()
  {
    return day;
  }
  
  public void setMonth(int paramInt)
  {
    calendar.set(2, paramInt);
    int i = calendar.getActualMaximum(5);
    if (day > i) {
      day = i;
    }
    drawDays();
  }
  
  public void setYear(int paramInt)
  {
    calendar.set(1, paramInt);
    drawDays();
  }
  
  public void setCalendar(Calendar paramCalendar)
  {
    calendar = paramCalendar;
    drawDays();
  }
  
  public void setFont(Font paramFont)
  {
    int i;
    if (days != null) {
      for (i = 0; i < 49; i++) {
        days[i].setFont(paramFont);
      }
    }
    if (weeks != null) {
      for (i = 0; i < 7; i++) {
        weeks[i].setFont(paramFont);
      }
    }
  }
  
  public void setForeground(Color paramColor)
  {
    super.setForeground(paramColor);
    if (days != null)
    {
      for (int i = 7; i < 49; i++) {
        days[i].setForeground(paramColor);
      }
      drawDays();
    }
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    JButton localJButton = (JButton)paramActionEvent.getSource();
    String str = localJButton.getText();
    int i = new Integer(str).intValue();
    setDay(i);
  }
  
  public void focusGained(FocusEvent paramFocusEvent) {}
  
  public void focusLost(FocusEvent paramFocusEvent) {}
  
  public void keyPressed(KeyEvent paramKeyEvent)
  {
    int i = paramKeyEvent.getKeyCode() == 39 ? 1 : paramKeyEvent.getKeyCode() == 37 ? -1 : paramKeyEvent.getKeyCode() == 40 ? 7 : paramKeyEvent.getKeyCode() == 38 ? -7 : 0;
    int j = getDay() + i;
    if ((j >= 1) && (j <= calendar.getMaximum(5))) {
      setDay(j);
    }
  }
  
  public void keyTyped(KeyEvent paramKeyEvent) {}
  
  public void keyReleased(KeyEvent paramKeyEvent) {}
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    for (int i = 0; i < days.length; i = (short)(i + 1)) {
      if (days[i] != null) {
        days[i].setEnabled(paramBoolean);
      }
    }
    for (i = 0; i < weeks.length; i = (short)(i + 1)) {
      if (weeks[i] != null) {
        weeks[i].setEnabled(paramBoolean);
      }
    }
  }
  
  public boolean isWeekOfYearVisible()
  {
    return weekOfYearVisible;
  }
  
  public void setWeekOfYearVisible(boolean paramBoolean)
  {
    if (paramBoolean == weekOfYearVisible) {
      return;
    }
    if (paramBoolean) {
      add(weekPanel, "West");
    } else {
      remove(weekPanel);
    }
    weekOfYearVisible = paramBoolean;
    validate();
    dayPanel.validate();
  }
  
  public JPanel getDayPanel()
  {
    return dayPanel;
  }
  
  public Color getDecorationBackgroundColor()
  {
    return decorationBackgroundColor;
  }
  
  public void setDecorationBackgroundColor(Color paramColor)
  {
    decorationBackgroundColor = paramColor;
    int i;
    if (days != null) {
      for (i = 0; i < 7; i++) {
        days[i].setBackground(paramColor);
      }
    }
    if (weeks != null) {
      for (i = 0; i < 7; i++) {
        weeks[i].setBackground(paramColor);
      }
    }
  }
  
  public Color getSundayForeground()
  {
    return sundayForeground;
  }
  
  public Color getWeekdayForeground()
  {
    return weekdayForeground;
  }
  
  public void setSundayForeground(Color paramColor)
  {
    sundayForeground = paramColor;
    drawDayNames();
    drawDays();
  }
  
  public void setWeekdayForeground(Color paramColor)
  {
    weekdayForeground = paramColor;
    drawDayNames();
    drawDays();
  }
  
  public void setFocus()
  {
    if (selectedDay != null) {
      selectedDay.requestFocus();
    }
  }
  
  public boolean isDecorationBackgroundVisible()
  {
    return decorationBackgroundVisible;
  }
  
  public void setDecorationBackgroundVisible(boolean paramBoolean)
  {
    decorationBackgroundVisible = paramBoolean;
    initDecorations();
  }
  
  public boolean isDecorationBordersVisible()
  {
    return decorationBordersVisible;
  }
  
  public boolean isDayBordersVisible()
  {
    return dayBordersVisible;
  }
  
  public void setDecorationBordersVisible(boolean paramBoolean)
  {
    decorationBordersVisible = paramBoolean;
    initDecorations();
  }
  
  public void setDayBordersVisible(boolean paramBoolean)
  {
    dayBordersVisible = paramBoolean;
    if (initialized) {
      for (int i = 7; i < 49; i++)
      {
        if ("Windows".equals(UIManager.getLookAndFeel().getID())) {
          days[i].setContentAreaFilled(paramBoolean);
        } else {
          days[i].setContentAreaFilled(true);
        }
        days[i].setBorderPainted(paramBoolean);
      }
    }
  }
  
  public void updateUI()
  {
    super.updateUI();
    setFont(Font.decode("Dialog Plain 11"));
    if (weekPanel != null) {
      weekPanel.updateUI();
    }
    if (initialized) {
      if ("Windows".equals(UIManager.getLookAndFeel().getID()))
      {
        setDayBordersVisible(false);
        setDecorationBackgroundVisible(true);
        setDecorationBordersVisible(false);
      }
      else
      {
        setDayBordersVisible(true);
        setDecorationBackgroundVisible(decorationBackgroundVisible);
        setDecorationBordersVisible(decorationBordersVisible);
      }
    }
  }
  
  public void setSelectableDateRange(Date paramDate1, Date paramDate2)
  {
    minMaxDateEvaluator.setMaxSelectableDate(paramDate2);
    minMaxDateEvaluator.setMinSelectableDate(paramDate1);
    drawDays();
  }
  
  public Date setMaxSelectableDate(Date paramDate)
  {
    Date localDate = minMaxDateEvaluator.setMaxSelectableDate(paramDate);
    drawDays();
    return localDate;
  }
  
  public Date setMinSelectableDate(Date paramDate)
  {
    Date localDate = minMaxDateEvaluator.setMinSelectableDate(paramDate);
    drawDays();
    return localDate;
  }
  
  public Date getMaxSelectableDate()
  {
    return minMaxDateEvaluator.getMaxSelectableDate();
  }
  
  public Date getMinSelectableDate()
  {
    return minMaxDateEvaluator.getMinSelectableDate();
  }
  
  public int getMaxDayCharacters()
  {
    return maxDayCharacters;
  }
  
  public void setMaxDayCharacters(int paramInt)
  {
    if (paramInt == maxDayCharacters) {
      return;
    }
    if ((paramInt < 0) || (paramInt > 4)) {
      maxDayCharacters = 0;
    } else {
      maxDayCharacters = paramInt;
    }
    drawDayNames();
    drawDays();
    invalidate();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("JDayChooser");
    localJFrame.getContentPane().add(new JDayChooser());
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
  
  public void addDateEvaluator(IDateEvaluator paramIDateEvaluator)
  {
    dateEvaluators.add(paramIDateEvaluator);
  }
  
  public void removeDateEvaluator(IDateEvaluator paramIDateEvaluator)
  {
    dateEvaluators.remove(paramIDateEvaluator);
  }
  
  class DecoratorButton
    extends JButton
  {
    private static final long serialVersionUID = -5306477668406547496L;
    
    public DecoratorButton()
    {
      setBackground(decorationBackgroundColor);
      setContentAreaFilled(decorationBackgroundVisible);
      setBorderPainted(decorationBordersVisible);
    }
    
    public void addMouseListener(MouseListener paramMouseListener) {}
    
    public boolean isFocusable()
    {
      return false;
    }
    
    public void paint(Graphics paramGraphics)
    {
      if ("Windows".equals(UIManager.getLookAndFeel().getID()))
      {
        if (decorationBackgroundVisible) {
          paramGraphics.setColor(decorationBackgroundColor);
        } else {
          paramGraphics.setColor(days[7].getBackground());
        }
        paramGraphics.fillRect(0, 0, getWidth(), getHeight());
        if (isBorderPainted()) {
          setContentAreaFilled(true);
        } else {
          setContentAreaFilled(false);
        }
      }
      super.paint(paramGraphics);
    }
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JDayChooser
 * JD-Core Version:    0.7.0.1
 */