package com.toedter.calendar.demo;

import com.jgoodies.looks.FontPolicies;
import com.jgoodies.looks.FontPolicy;
import com.jgoodies.looks.FontSet;
import com.jgoodies.looks.FontSets;
import com.jgoodies.looks.plastic.PlasticLookAndFeel;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JYearChooser;
import com.toedter.components.JLocaleChooser;
import com.toedter.components.JSpinField;
import com.toedter.components.JTitlePanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyDescriptor;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.basic.BasicSplitPaneUI;

public class JCalendarDemo
  extends JApplet
  implements PropertyChangeListener
{
  private static final long serialVersionUID = 6739986412544494316L;
  private JSplitPane splitPane;
  private JPanel calendarPanel;
  private JComponent[] beans;
  private JPanel propertyPanel;
  private JTitlePanel propertyTitlePanel;
  private JTitlePanel componentTitlePanel;
  private JPanel componentPanel;
  private JToolBar toolBar;
  
  public void init()
  {
    initializeLookAndFeels();
    beans = new JComponent[6];
    beans[0] = new DateChooserPanel();
    beans[1] = new JCalendar();
    beans[2] = new JDayChooser();
    beans[3] = new JMonthChooser();
    beans[4] = new JYearChooser();
    beans[5] = new JSpinField();
    ((JSpinField)beans[5]).adjustWidthToMaximumValue();
    ((JYearChooser)beans[4]).setMaximum(((JSpinField)beans[5]).getMaximum());
    ((JYearChooser)beans[4]).adjustWidthToMaximumValue();
    getContentPane().setLayout(new BorderLayout());
    setJMenuBar(createMenuBar());
    toolBar = createToolBar();
    getContentPane().add(toolBar, "North");
    splitPane = new JSplitPane(0);
    splitPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
    splitPane.setDividerSize(4);
    splitPane.setDividerLocation(240);
    BasicSplitPaneDivider localBasicSplitPaneDivider = ((BasicSplitPaneUI)splitPane.getUI()).getDivider();
    if (localBasicSplitPaneDivider != null) {
      localBasicSplitPaneDivider.setBorder(null);
    }
    propertyPanel = new JPanel();
    componentPanel = new JPanel();
    URL localURL = beans[0].getClass().getResource("images/" + beans[0].getName() + "Color16.gif");
    ImageIcon localImageIcon = new ImageIcon(localURL);
    propertyTitlePanel = new JTitlePanel("Properties", null, propertyPanel, BorderFactory.createEmptyBorder(4, 4, 4, 4));
    componentTitlePanel = new JTitlePanel("Component", localImageIcon, componentPanel, BorderFactory.createEmptyBorder(4, 4, 0, 4));
    splitPane.setBottomComponent(propertyTitlePanel);
    splitPane.setTopComponent(componentTitlePanel);
    installBean(beans[0]);
    getContentPane().add(splitPane, "Center");
  }
  
  public final void initializeLookAndFeels()
  {
    try
    {
      UIManager.LookAndFeelInfo[] arrayOfLookAndFeelInfo = UIManager.getInstalledLookAndFeels();
      int i = 0;
      for (int j = 0; j < arrayOfLookAndFeelInfo.length; j++) {
        if (arrayOfLookAndFeelInfo[j].getName().equals("JGoodies Plastic 3D")) {
          i = 1;
        }
      }
      if (i == 0) {
        UIManager.installLookAndFeel("JGoodies Plastic 3D", "com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
      }
      String str = System.getProperty("os.name");
      FontSet localFontSet = null;
      if (str.startsWith("Windows")) {
        localFontSet = FontSets.createDefaultFontSet(new Font("arial unicode MS", 0, 12));
      } else {
        localFontSet = FontSets.createDefaultFontSet(new Font("arial unicode", 0, 12));
      }
      FontPolicy localFontPolicy = FontPolicies.createFixedPolicy(localFontSet);
      PlasticLookAndFeel.setFontPolicy(localFontPolicy);
      UIManager.setLookAndFeel("com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
    }
    catch (Throwable localThrowable)
    {
      try
      {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
  }
  
  public JToolBar createToolBar()
  {
    toolBar = new JToolBar();
    toolBar.putClientProperty("jgoodies.headerStyle", "Both");
    toolBar.setRollover(true);
    toolBar.setFloatable(false);
    for (int i = 0; i < beans.length; i++)
    {
      JButton localJButton;
      try
      {
        final JComponent localJComponent = beans[i];
        URL localURL = localJComponent.getClass().getResource("images/" + localJComponent.getName() + "Color16.gif");
        ImageIcon localImageIcon = new ImageIcon(localURL);
        localJButton = new JButton(localImageIcon);
        ActionListener local1 = new ActionListener()
        {
          private final JComponent val$bean;
          
          public void actionPerformed(ActionEvent paramAnonymousActionEvent)
          {
            JCalendarDemo.this.installBean(localJComponent);
          }
        };
        localJButton.addActionListener(local1);
      }
      catch (Exception localException)
      {
        System.out.println("JCalendarDemo.createToolBar(): " + localException);
        localJButton = new JButton(beans[i].getName());
      }
      localJButton.setFocusPainted(false);
      toolBar.add(localJButton);
    }
    return toolBar;
  }
  
  public JMenuBar createMenuBar()
  {
    final JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu1 = new JMenu("Components");
    localJMenu1.setMnemonic('C');
    localJMenuBar.add(localJMenu1);
    for (int i = 0; i < beans.length; i++)
    {
      try
      {
        URL localURL = beans[i].getClass().getResource("images/" + beans[i].getName() + "Color16.gif");
        localObject1 = new ImageIcon(localURL);
        localObject2 = new JMenuItem(beans[i].getName(), (Icon)localObject1);
      }
      catch (Exception localException)
      {
        System.out.println("JCalendarDemo.createMenuBar(): " + localException + " for URL: " + "images/" + beans[i].getName() + "Color16.gif");
        localObject2 = new JMenuItem(beans[i].getName());
      }
      localJMenu1.add((JMenuItem)localObject2);
      final JComponent localJComponent = beans[i];
      localObject3 = new ActionListener()
      {
        private final JComponent val$bean;
        
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          JCalendarDemo.this.installBean(localJComponent);
        }
      };
      ((JMenuItem)localObject2).addActionListener((ActionListener)localObject3);
    }
    UIManager.LookAndFeelInfo[] arrayOfLookAndFeelInfo = UIManager.getInstalledLookAndFeels();
    Object localObject1 = new ButtonGroup();
    Object localObject2 = new JMenu("Look&Feel");
    ((JMenu)localObject2).setMnemonic('L');
    localJMenuBar.add((JMenu)localObject2);
    for (int j = 0; j < arrayOfLookAndFeelInfo.length; j++) {
      if (!arrayOfLookAndFeelInfo[j].getName().equals("CDE/Motif"))
      {
        localObject3 = new JRadioButtonMenuItem(arrayOfLookAndFeelInfo[j].getName());
        ((JMenu)localObject2).add((JMenuItem)localObject3);
        ((JRadioButtonMenuItem)localObject3).setSelected(UIManager.getLookAndFeel().getName().equals(arrayOfLookAndFeelInfo[j].getName()));
        ((JRadioButtonMenuItem)localObject3).putClientProperty("lnf name", arrayOfLookAndFeelInfo[j]);
        ((JRadioButtonMenuItem)localObject3).addItemListener(new ItemListener()
        {
          private final JMenuBar val$menuBar;
          
          public void itemStateChanged(ItemEvent paramAnonymousItemEvent)
          {
            JRadioButtonMenuItem localJRadioButtonMenuItem = (JRadioButtonMenuItem)paramAnonymousItemEvent.getSource();
            if (localJRadioButtonMenuItem.isSelected())
            {
              UIManager.LookAndFeelInfo localLookAndFeelInfo = (UIManager.LookAndFeelInfo)localJRadioButtonMenuItem.getClientProperty("lnf name");
              try
              {
                localJMenuBar.putClientProperty("jgoodies.headerStyle", "Both");
                UIManager.setLookAndFeel(localLookAndFeelInfo.getClassName());
                SwingUtilities.updateComponentTreeUI(JCalendarDemo.this);
                for (int i = 0; i < beans.length; i++) {
                  SwingUtilities.updateComponentTreeUI(beans[i]);
                }
                BasicSplitPaneDivider localBasicSplitPaneDivider = ((BasicSplitPaneUI)splitPane.getUI()).getDivider();
                if (localBasicSplitPaneDivider != null) {
                  localBasicSplitPaneDivider.setBorder(null);
                }
              }
              catch (Exception localException)
              {
                localException.printStackTrace();
                System.err.println("Unable to set UI " + localException.getMessage());
              }
            }
          }
        });
        ((ButtonGroup)localObject1).add((AbstractButton)localObject3);
      }
    }
    JMenu localJMenu2 = new JMenu("Help");
    localJMenu2.setMnemonic('H');
    Object localObject3 = localJMenu2.add(new AboutAction(this));
    ((JMenuItem)localObject3).setMnemonic('A');
    ((JMenuItem)localObject3).setAccelerator(KeyStroke.getKeyStroke(65, 2));
    localJMenuBar.add(localJMenu2);
    return localJMenuBar;
  }
  
  public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
  {
    if ((calendarPanel != null) && (paramPropertyChangeEvent.getPropertyName().equals("calendar"))) {}
  }
  
  public static void main(String[] paramArrayOfString)
  {
    WindowAdapter local4 = new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        System.exit(0);
      }
    };
    JFrame localJFrame = new JFrame("JCalendar Demo");
    localJFrame.addWindowListener(local4);
    JCalendarDemo localJCalendarDemo = new JCalendarDemo();
    localJCalendarDemo.init();
    localJFrame.getContentPane().add(localJCalendarDemo);
    localJFrame.pack();
    localJFrame.setBounds(200, 200, (int)localJFrame.getPreferredSize().getWidth() + 40, (int)localJFrame.getPreferredSize().getHeight() + 250);
    localJFrame.setVisible(true);
  }
  
  private void installBean(JComponent paramJComponent)
  {
    try
    {
      componentPanel.removeAll();
      componentPanel.add(paramJComponent);
      BeanInfo localBeanInfo = Introspector.getBeanInfo(paramJComponent.getClass(), paramJComponent.getClass().getSuperclass());
      PropertyDescriptor[] arrayOfPropertyDescriptor = localBeanInfo.getPropertyDescriptors();
      propertyPanel.removeAll();
      GridBagLayout localGridBagLayout = new GridBagLayout();
      GridBagConstraints localGridBagConstraints = new GridBagConstraints();
      fill = 1;
      propertyPanel.setLayout(localGridBagLayout);
      int i = 0;
      String[] arrayOfString = { "class java.util.Locale", "boolean", "int", "class java.awt.Color", "class java.util.Date", "class java.lang.String" };
      for (int j = 0; j < arrayOfString.length; j++) {
        for (int k = 0; k < arrayOfPropertyDescriptor.length; k++) {
          if (arrayOfPropertyDescriptor[k].getWriteMethod() != null)
          {
            String str = arrayOfPropertyDescriptor[k].getPropertyType().toString();
            PropertyDescriptor localPropertyDescriptor = arrayOfPropertyDescriptor[k];
            final JComponent localJComponent = paramJComponent;
            Method localMethod1 = localPropertyDescriptor.getReadMethod();
            final Method localMethod2 = localPropertyDescriptor.getWriteMethod();
            if ((str.equals(arrayOfString[j])) && (((localMethod1 != null) && (localMethod2 != null)) || ("class java.util.Locale".equals(str))))
            {
              Object localObject2;
              if ("boolean".equals(str))
              {
                boolean bool = false;
                try
                {
                  Boolean localBoolean = (Boolean)localMethod1.invoke(paramJComponent, (Object[])null);
                  bool = localBoolean.booleanValue();
                }
                catch (Exception localException1)
                {
                  localException1.printStackTrace();
                }
                localObject2 = new JCheckBox("", bool);
                ((JCheckBox)localObject2).addActionListener(new ActionListener()
                {
                  private final JCheckBox val$checkBox;
                  private final Method val$writeMethod;
                  private final JComponent val$currentBean;
                  
                  public void actionPerformed(ActionEvent paramAnonymousActionEvent)
                  {
                    try
                    {
                      if (val$checkBox.isSelected()) {
                        localMethod2.invoke(localJComponent, new Object[] { new Boolean(true) });
                      } else {
                        localMethod2.invoke(localJComponent, new Object[] { new Boolean(false) });
                      }
                    }
                    catch (Exception localException)
                    {
                      localException.printStackTrace();
                    }
                  }
                });
                addProperty(arrayOfPropertyDescriptor[k], (JComponent)localObject2, localGridBagLayout);
                i++;
              }
              else
              {
                Object localObject1;
                if ("int".equals(str))
                {
                  localObject1 = new JSpinField();
                  ((JSpinField)localObject1).addPropertyChangeListener(new PropertyChangeListener()
                  {
                    private final Method val$writeMethod;
                    private final JComponent val$currentBean;
                    
                    public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
                    {
                      try
                      {
                        if (paramAnonymousPropertyChangeEvent.getPropertyName().equals("value")) {
                          localMethod2.invoke(localJComponent, new Object[] { paramAnonymousPropertyChangeEvent.getNewValue() });
                        }
                      }
                      catch (Exception localException) {}
                    }
                  });
                  try
                  {
                    localObject2 = (Integer)localMethod1.invoke(paramJComponent, (Object[])null);
                    ((JSpinField)localObject1).setValue(((Integer)localObject2).intValue());
                  }
                  catch (Exception localException2)
                  {
                    localException2.printStackTrace();
                  }
                  addProperty(arrayOfPropertyDescriptor[k], (JComponent)localObject1, localGridBagLayout);
                  i++;
                }
                else
                {
                  Object localObject4;
                  if ("class java.lang.String".equals(str))
                  {
                    localObject1 = "";
                    try
                    {
                      localObject1 = (String)localMethod1.invoke(paramJComponent, (Object[])null);
                    }
                    catch (Exception localException3)
                    {
                      localException3.printStackTrace();
                    }
                    JTextField localJTextField = new JTextField((String)localObject1);
                    localObject4 = new ActionListener()
                    {
                      private final Method val$writeMethod;
                      private final JComponent val$currentBean;
                      
                      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
                      {
                        try
                        {
                          localMethod2.invoke(localJComponent, new Object[] { paramAnonymousActionEvent.getActionCommand() });
                        }
                        catch (Exception localException) {}
                      }
                    };
                    localJTextField.addActionListener((ActionListener)localObject4);
                    addProperty(arrayOfPropertyDescriptor[k], localJTextField, localGridBagLayout);
                    i++;
                  }
                  else if ("class java.util.Locale".equals(str))
                  {
                    localObject1 = new JLocaleChooser(paramJComponent);
                    ((JLocaleChooser)localObject1).setPreferredSize(new Dimension(200, getPreferredSize()height));
                    addProperty(arrayOfPropertyDescriptor[k], (JComponent)localObject1, localGridBagLayout);
                    i++;
                  }
                  else
                  {
                    Object localObject3;
                    if ("class java.util.Date".equals(str))
                    {
                      localObject1 = null;
                      try
                      {
                        localObject1 = (Date)localMethod1.invoke(paramJComponent, (Object[])null);
                      }
                      catch (Exception localException4)
                      {
                        localException4.printStackTrace();
                      }
                      localObject3 = new JDateChooser((Date)localObject1);
                      ((JDateChooser)localObject3).addPropertyChangeListener(new PropertyChangeListener()
                      {
                        private final Method val$writeMethod;
                        private final JComponent val$currentBean;
                        
                        public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
                        {
                          try
                          {
                            if (paramAnonymousPropertyChangeEvent.getPropertyName().equals("date")) {
                              localMethod2.invoke(localJComponent, new Object[] { paramAnonymousPropertyChangeEvent.getNewValue() });
                            }
                          }
                          catch (Exception localException) {}
                        }
                      });
                      addProperty(arrayOfPropertyDescriptor[k], (JComponent)localObject3, localGridBagLayout);
                      i++;
                    }
                    else if ("class java.awt.Color".equals(str))
                    {
                      localObject1 = new JButton();
                      try
                      {
                        localObject3 = (Color)localMethod1.invoke(paramJComponent, (Object[])null);
                        ((JButton)localObject1).setText("...");
                        ((JButton)localObject1).setBackground((Color)localObject3);
                        localObject4 = new ActionListener()
                        {
                          private final Color val$colorObj;
                          private final JButton val$button;
                          private final Method val$writeMethod;
                          private final JComponent val$currentBean;
                          
                          public void actionPerformed(ActionEvent paramAnonymousActionEvent)
                          {
                            Color localColor = JColorChooser.showDialog(JCalendarDemo.this, "Choose Color", val$colorObj);
                            val$button.setBackground(localColor);
                            try
                            {
                              localMethod2.invoke(localJComponent, new Object[] { localColor });
                            }
                            catch (Exception localException)
                            {
                              localException.printStackTrace();
                            }
                          }
                        };
                        ((JButton)localObject1).addActionListener((ActionListener)localObject4);
                      }
                      catch (Exception localException5)
                      {
                        localException5.printStackTrace();
                      }
                      addProperty(arrayOfPropertyDescriptor[k], (JComponent)localObject1, localGridBagLayout);
                      i++;
                    }
                  }
                }
              }
            }
          }
        }
      }
      URL localURL = paramJComponent.getClass().getResource("images/" + paramJComponent.getName() + "Color16.gif");
      ImageIcon localImageIcon = new ImageIcon(localURL);
      componentTitlePanel.setTitle(paramJComponent.getName(), localImageIcon);
      paramJComponent.invalidate();
      propertyPanel.invalidate();
      componentPanel.invalidate();
      componentPanel.repaint();
    }
    catch (IntrospectionException localIntrospectionException)
    {
      localIntrospectionException.printStackTrace();
    }
  }
  
  private void addProperty(PropertyDescriptor paramPropertyDescriptor, JComponent paramJComponent, GridBagLayout paramGridBagLayout)
  {
    String str1 = paramPropertyDescriptor.getDisplayName();
    String str2 = "";
    for (int i = 0; i < str1.length(); i++)
    {
      char c = str1.charAt(i);
      if (((c >= 'A') && (c <= 'Z')) || (i == 0))
      {
        if (i == 0) {
          c = (char)(c - ' ');
        }
        str2 = str2 + " " + c;
      }
      else
      {
        str2 = str2 + c;
      }
    }
    JLabel localJLabel = new JLabel(str2 + ": ", null, 4);
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    weightx = 1.0D;
    fill = 1;
    paramGridBagLayout.setConstraints(localJLabel, localGridBagConstraints);
    propertyPanel.add(localJLabel);
    gridwidth = 0;
    paramGridBagLayout.setConstraints(paramJComponent, localGridBagConstraints);
    propertyPanel.add(paramJComponent);
    JPanel local10 = new JPanel()
    {
      private static final long serialVersionUID = 4514530330521503732L;
      
      public Dimension getPreferredSize()
      {
        return new Dimension(10, 2);
      }
    };
    paramGridBagLayout.setConstraints(local10, localGridBagConstraints);
    propertyPanel.add(local10);
  }
  
  class AboutAction
    extends AbstractAction
  {
    private static final long serialVersionUID = -5204865941545323214L;
    private final JCalendarDemo demo;
    
    AboutAction(JCalendarDemo paramJCalendarDemo)
    {
      super();
      demo = paramJCalendarDemo;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      JOptionPane.showMessageDialog(demo, "JCalendar Demo\nVersion 1.4\n\nKai Toedter\nkai@toedter.com\nwww.toedter.com", "About...", 1);
    }
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.demo.JCalendarDemo
 * JD-Core Version:    0.7.0.1
 */