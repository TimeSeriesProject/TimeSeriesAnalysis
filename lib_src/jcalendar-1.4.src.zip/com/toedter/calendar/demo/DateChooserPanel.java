package com.toedter.calendar.demo;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JSpinnerDateEditor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;
import java.util.Locale;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DateChooserPanel
  extends JPanel
  implements PropertyChangeListener
{
  private static final long serialVersionUID = -1282280858252793253L;
  private final JComponent[] components;
  
  public DateChooserPanel()
  {
    setName("JDateChooser");
    GridBagLayout localGridBagLayout = new GridBagLayout();
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    fill = 1;
    setLayout(localGridBagLayout);
    components = new JComponent[6];
    components[0] = new JDateChooser();
    components[1] = new JDateChooser();
    ((JDateChooser)components[1]).getJCalendar().getDayChooser().addDateEvaluator(new BirthdayEvaluator());
    ((JDateChooser)components[1]).getJCalendar().getDayChooser().addDateEvaluator(new TestDateEvaluator());
    ((JDateChooser)components[1]).getJCalendar().setTodayButtonVisible(true);
    ((JDateChooser)components[1]).getJCalendar().setNullDateButtonVisible(true);
    components[2] = new JDateChooser(new Date());
    components[3] = new JDateChooser(null, null, null, new JSpinnerDateEditor());
    components[4] = new JDateChooser("yyyy/MM/dd", "####/##/##", '_');
    components[5] = new DemoTable();
    addEntry("Default", components[0], localGridBagLayout);
    addEntry("Default (with addons)", components[1], localGridBagLayout);
    addEntry("Default with date set", components[2], localGridBagLayout);
    addEntry("Spinner Editor", components[3], localGridBagLayout);
    addEntry("Explicite date pattern and mask", components[4], localGridBagLayout);
    addEntry("Table with date editors", components[5], localGridBagLayout);
  }
  
  private void addEntry(String paramString, JComponent paramJComponent, GridBagLayout paramGridBagLayout)
  {
    JLabel localJLabel = new JLabel(paramString + ": ", null, 4);
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    weightx = 1.0D;
    fill = 1;
    paramGridBagLayout.setConstraints(localJLabel, localGridBagConstraints);
    add(localJLabel);
    gridwidth = 0;
    paramGridBagLayout.setConstraints(paramJComponent, localGridBagConstraints);
    add(paramJComponent);
    JPanel local1 = new JPanel()
    {
      private static final long serialVersionUID = 4514530330521503732L;
      
      public Dimension getPreferredSize()
      {
        return new Dimension(10, 3);
      }
    };
    paramGridBagLayout.setConstraints(local1, localGridBagConstraints);
    add(local1);
  }
  
  public String getDateFormatString()
  {
    return ((JDateChooser)components[1]).getDateFormatString();
  }
  
  public void setDateFormatString(String paramString)
  {
    for (int i = 0; i < 4; i++) {
      ((JDateChooser)components[i]).setDateFormatString(paramString);
    }
  }
  
  public Date getDate()
  {
    return ((JDateChooser)components[1]).getDate();
  }
  
  public void setDate(Date paramDate)
  {
    for (int i = 0; i < 4; i++) {
      ((JDateChooser)components[i]).setDate(paramDate);
    }
  }
  
  public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
  {
    if (paramPropertyChangeEvent.getPropertyName().equals("date")) {
      setDate((Date)paramPropertyChangeEvent.getNewValue());
    }
  }
  
  public Locale getLocale()
  {
    return ((JDateChooser)components[0]).getLocale();
  }
  
  public void setLocale(Locale paramLocale)
  {
    for (int i = 0; i < 5; i++) {
      components[i].setLocale(paramLocale);
    }
  }
  
  public boolean isEnabled()
  {
    return ((JDateChooser)components[0]).isEnabled();
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    for (int i = 0; i < 5; i++) {
      components[i].setEnabled(paramBoolean);
    }
  }
  
  public Date getMinSelectableDate()
  {
    return ((JDateChooser)components[0]).getMinSelectableDate();
  }
  
  public void setMinSelectableDate(Date paramDate)
  {
    for (int i = 0; i < 4; i++) {
      ((JDateChooser)components[i]).setMinSelectableDate(paramDate);
    }
  }
  
  public Date getMaxSelectableDate()
  {
    return ((JDateChooser)components[0]).getMaxSelectableDate();
  }
  
  public void setMaxSelectableDate(Date paramDate)
  {
    for (int i = 0; i < 4; i++) {
      ((JDateChooser)components[i]).setMaxSelectableDate(paramDate);
    }
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.demo.DateChooserPanel
 * JD-Core Version:    0.7.0.1
 */