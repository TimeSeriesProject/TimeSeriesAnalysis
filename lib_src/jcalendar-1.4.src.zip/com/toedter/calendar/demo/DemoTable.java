package com.toedter.calendar.demo;

import com.toedter.calendar.JDateChooserCellEditor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Date;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

public class DemoTable
  extends JPanel
{
  private static final long serialVersionUID = -2823838920746867592L;
  
  public DemoTable()
  {
    super(new GridLayout(1, 0));
    setName("DemoTable");
    JTable localJTable = new JTable(new DemoTableModel());
    localJTable.setPreferredScrollableViewportSize(new Dimension(180, 32));
    localJTable.setDefaultEditor(Date.class, new JDateChooserCellEditor());
    JScrollPane localJScrollPane = new JScrollPane(localJTable);
    add(localJScrollPane);
  }
  
  class DemoTableModel
    extends AbstractTableModel
  {
    private static final long serialVersionUID = 3283465559187131559L;
    private final String[] columnNames = { "Empty Date", "Date set" };
    private final Object[][] data = { { null, new Date() }, { null, new Date() } };
    
    DemoTableModel() {}
    
    public int getColumnCount()
    {
      return columnNames.length;
    }
    
    public int getRowCount()
    {
      return data.length;
    }
    
    public String getColumnName(int paramInt)
    {
      return columnNames[paramInt];
    }
    
    public Object getValueAt(int paramInt1, int paramInt2)
    {
      return data[paramInt1][paramInt2];
    }
    
    public Class getColumnClass(int paramInt)
    {
      return getValueAt(0, 1).getClass();
    }
    
    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return true;
    }
    
    public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
    {
      data[paramInt1][paramInt2] = paramObject;
      fireTableCellUpdated(paramInt1, paramInt2);
    }
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.demo.DemoTable
 * JD-Core Version:    0.7.0.1
 */