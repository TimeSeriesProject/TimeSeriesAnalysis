package com.toedter.calendar.demo;

import com.toedter.calendar.IDateEvaluator;
import java.awt.Color;
import java.util.Calendar;
import java.util.Date;

public class TestDateEvaluator
  implements IDateEvaluator
{
  private Calendar calendar = Calendar.getInstance();
  private Calendar calendar2 = Calendar.getInstance();
  private Color darkGreen = new Color(32512);
  private Color lightGreen = new Color(12315592);
  private Color darkRed = new Color(10878983);
  private Color lightRed = new Color(16757173);
  
  public boolean isSpecial(Date paramDate)
  {
    calendar2.setTime(paramDate);
    for (int i = 2; i < 5; i++) {
      if ((calendar.get(2) == calendar2.get(2)) && (calendar.get(5) == calendar2.get(5) + i)) {
        return true;
      }
    }
    return false;
  }
  
  public Color getSpecialForegroundColor()
  {
    return darkGreen;
  }
  
  public Color getSpecialBackroundColor()
  {
    return lightGreen;
  }
  
  public String getSpecialTooltip()
  {
    return "Special Day!";
  }
  
  public boolean isInvalid(Date paramDate)
  {
    calendar2.setTime(paramDate);
    for (int i = 4; i < 6; i++) {
      if ((calendar.get(2) == calendar2.get(2)) && (calendar.get(5) == calendar2.get(5) + i)) {
        return true;
      }
    }
    return false;
  }
  
  public Color getInvalidForegroundColor()
  {
    return darkRed;
  }
  
  public Color getInvalidBackroundColor()
  {
    return null;
  }
  
  public String getInvalidTooltip()
  {
    return "You cannot select this date...";
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.demo.TestDateEvaluator
 * JD-Core Version:    0.7.0.1
 */