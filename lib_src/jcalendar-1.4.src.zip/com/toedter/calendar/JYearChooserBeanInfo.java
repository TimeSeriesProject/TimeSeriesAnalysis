package com.toedter.calendar;

import com.toedter.components.GenericBeanInfo;

public class JYearChooserBeanInfo
  extends GenericBeanInfo
{
  public JYearChooserBeanInfo()
  {
    super("JYearChooser", false);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JYearChooserBeanInfo
 * JD-Core Version:    0.7.0.1
 */