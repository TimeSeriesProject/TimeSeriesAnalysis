package com.toedter.calendar;

import com.toedter.components.GenericBeanInfo;

public class JDayChooserBeanInfo
  extends GenericBeanInfo
{
  public JDayChooserBeanInfo()
  {
    super("JDayChooser", true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JDayChooserBeanInfo
 * JD-Core Version:    0.7.0.1
 */