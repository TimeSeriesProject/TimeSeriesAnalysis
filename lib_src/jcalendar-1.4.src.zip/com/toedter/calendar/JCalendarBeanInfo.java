package com.toedter.calendar;

import com.toedter.components.GenericBeanInfo;

public class JCalendarBeanInfo
  extends GenericBeanInfo
{
  public JCalendarBeanInfo()
  {
    super("JCalendar", true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JCalendarBeanInfo
 * JD-Core Version:    0.7.0.1
 */