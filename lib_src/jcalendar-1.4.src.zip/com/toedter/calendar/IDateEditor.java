package com.toedter.calendar;

import java.beans.PropertyChangeListener;
import java.util.Date;
import java.util.Locale;
import javax.swing.JComponent;

public abstract interface IDateEditor
{
  public abstract Date getDate();
  
  public abstract void setDate(Date paramDate);
  
  public abstract void setDateFormatString(String paramString);
  
  public abstract String getDateFormatString();
  
  public abstract void setSelectableDateRange(Date paramDate1, Date paramDate2);
  
  public abstract Date getMaxSelectableDate();
  
  public abstract Date getMinSelectableDate();
  
  public abstract void setMaxSelectableDate(Date paramDate);
  
  public abstract void setMinSelectableDate(Date paramDate);
  
  public abstract JComponent getUiComponent();
  
  public abstract void setLocale(Locale paramLocale);
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void addPropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.IDateEditor
 * JD-Core Version:    0.7.0.1
 */