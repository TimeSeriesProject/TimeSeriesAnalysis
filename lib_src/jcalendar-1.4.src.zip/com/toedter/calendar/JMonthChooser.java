package com.toedter.calendar;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.LookAndFeel;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JMonthChooser
  extends JPanel
  implements ItemListener, ChangeListener
{
  private static final long serialVersionUID = -2028361332231218527L;
  protected boolean hasSpinner;
  private Locale locale;
  private int month;
  private int oldSpinnerValue = 0;
  private JDayChooser dayChooser;
  private JYearChooser yearChooser;
  private JComboBox comboBox;
  private JSpinner spinner;
  private boolean initialized;
  private boolean localInitialize;
  
  public JMonthChooser()
  {
    this(true);
  }
  
  public JMonthChooser(boolean paramBoolean)
  {
    setName("JMonthChooser");
    hasSpinner = paramBoolean;
    setLayout(new BorderLayout());
    comboBox = new JComboBox();
    comboBox.addItemListener(this);
    locale = Locale.getDefault();
    initNames();
    if (paramBoolean)
    {
      spinner = new JSpinner()
      {
        private static final long serialVersionUID = 1L;
        private JTextField textField = new JTextField();
        
        public Dimension getPreferredSize()
        {
          Dimension localDimension = super.getPreferredSize();
          return new Dimension(width, textField.getPreferredSize().height);
        }
      };
      spinner.addChangeListener(this);
      spinner.setEditor(comboBox);
      comboBox.setBorder(new EmptyBorder(0, 0, 0, 0));
      updateUI();
      add(spinner, "West");
    }
    else
    {
      add(comboBox, "West");
    }
    initialized = true;
    setMonth(Calendar.getInstance().get(2));
  }
  
  public void initNames()
  {
    localInitialize = true;
    DateFormatSymbols localDateFormatSymbols = new DateFormatSymbols(locale);
    String[] arrayOfString = localDateFormatSymbols.getMonths();
    if (comboBox.getItemCount() == 12) {
      comboBox.removeAllItems();
    }
    for (int i = 0; i < 12; i++) {
      comboBox.addItem(arrayOfString[i]);
    }
    localInitialize = false;
    comboBox.setSelectedIndex(month);
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    SpinnerNumberModel localSpinnerNumberModel = (SpinnerNumberModel)((JSpinner)paramChangeEvent.getSource()).getModel();
    int i = localSpinnerNumberModel.getNumber().intValue();
    int j = i > oldSpinnerValue ? 1 : 0;
    oldSpinnerValue = i;
    int k = getMonth();
    int m;
    if (j != 0)
    {
      k++;
      if (k == 12)
      {
        k = 0;
        if (yearChooser != null)
        {
          m = yearChooser.getYear();
          m++;
          yearChooser.setYear(m);
        }
      }
    }
    else
    {
      k--;
      if (k == -1)
      {
        k = 11;
        if (yearChooser != null)
        {
          m = yearChooser.getYear();
          m--;
          yearChooser.setYear(m);
        }
      }
    }
    setMonth(k);
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    if (paramItemEvent.getStateChange() == 1)
    {
      int i = comboBox.getSelectedIndex();
      if ((i >= 0) && (i != month)) {
        setMonth(i, false);
      }
    }
  }
  
  private void setMonth(int paramInt, boolean paramBoolean)
  {
    if ((!initialized) || (localInitialize)) {
      return;
    }
    int i = month;
    month = paramInt;
    if (paramBoolean) {
      comboBox.setSelectedIndex(month);
    }
    if (dayChooser != null) {
      dayChooser.setMonth(month);
    }
    firePropertyChange("month", i, month);
  }
  
  public void setMonth(int paramInt)
  {
    if ((paramInt < 0) || (paramInt == -2147483648)) {
      setMonth(0, true);
    } else if (paramInt > 11) {
      setMonth(11, true);
    } else {
      setMonth(paramInt, true);
    }
  }
  
  public int getMonth()
  {
    return month;
  }
  
  public void setDayChooser(JDayChooser paramJDayChooser)
  {
    dayChooser = paramJDayChooser;
  }
  
  public void setYearChooser(JYearChooser paramJYearChooser)
  {
    yearChooser = paramJYearChooser;
  }
  
  public Locale getLocale()
  {
    return locale;
  }
  
  public void setLocale(Locale paramLocale)
  {
    if (!initialized)
    {
      super.setLocale(paramLocale);
    }
    else
    {
      locale = paramLocale;
      initNames();
    }
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    comboBox.setEnabled(paramBoolean);
    if (spinner != null) {
      spinner.setEnabled(paramBoolean);
    }
  }
  
  public Component getComboBox()
  {
    return comboBox;
  }
  
  public Component getSpinner()
  {
    return spinner;
  }
  
  public boolean hasSpinner()
  {
    return hasSpinner;
  }
  
  public void setFont(Font paramFont)
  {
    if (comboBox != null) {
      comboBox.setFont(paramFont);
    }
    super.setFont(paramFont);
  }
  
  public void updateUI()
  {
    JSpinner localJSpinner = new JSpinner();
    if (spinner != null) {
      if ("Windows".equals(UIManager.getLookAndFeel().getID())) {
        spinner.setBorder(localJSpinner.getBorder());
      } else {
        spinner.setBorder(new EmptyBorder(0, 0, 0, 0));
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("MonthChooser");
    localJFrame.getContentPane().add(new JMonthChooser());
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JMonthChooser
 * JD-Core Version:    0.7.0.1
 */