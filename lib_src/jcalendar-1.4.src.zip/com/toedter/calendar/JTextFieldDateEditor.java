package com.toedter.calendar;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.MaskFormatter;

public class JTextFieldDateEditor
  extends JFormattedTextField
  implements IDateEditor, CaretListener, FocusListener, ActionListener
{
  private static final long serialVersionUID = -8901842591101625304L;
  protected Date date;
  protected SimpleDateFormat dateFormatter = (SimpleDateFormat)DateFormat.getDateInstance(2);
  protected MaskFormatter maskFormatter;
  protected String datePattern;
  protected String maskPattern;
  protected char placeholder;
  protected Color darkGreen;
  protected DateUtil dateUtil;
  private boolean isMaskVisible;
  private boolean ignoreDatePatternChange;
  private int hours;
  private int minutes;
  private int seconds;
  private int millis;
  private Calendar calendar;
  
  public JTextFieldDateEditor()
  {
    this(false, null, null, ' ');
  }
  
  public JTextFieldDateEditor(String paramString1, String paramString2, char paramChar)
  {
    this(true, paramString1, paramString2, paramChar);
  }
  
  public JTextFieldDateEditor(boolean paramBoolean, String paramString1, String paramString2, char paramChar)
  {
    dateFormatter.setLenient(false);
    setDateFormatString(paramString1);
    if (paramString1 != null) {
      ignoreDatePatternChange = true;
    }
    placeholder = paramChar;
    if (paramString2 == null) {
      maskPattern = createMaskFromDatePattern(datePattern);
    } else {
      maskPattern = paramString2;
    }
    setToolTipText(datePattern);
    setMaskVisible(paramBoolean);
    addCaretListener(this);
    addFocusListener(this);
    addActionListener(this);
    darkGreen = new Color(0, 150, 0);
    calendar = Calendar.getInstance();
    dateUtil = new DateUtil();
  }
  
  public Date getDate()
  {
    try
    {
      calendar.setTime(dateFormatter.parse(getText()));
      calendar.set(11, hours);
      calendar.set(12, minutes);
      calendar.set(13, seconds);
      calendar.set(14, millis);
      date = calendar.getTime();
    }
    catch (ParseException localParseException)
    {
      date = null;
    }
    return date;
  }
  
  public void setDate(Date paramDate)
  {
    setDate(paramDate, true);
  }
  
  protected void setDate(Date paramDate, boolean paramBoolean)
  {
    Date localDate = date;
    date = paramDate;
    if (paramDate == null)
    {
      setText("");
    }
    else
    {
      calendar.setTime(paramDate);
      hours = calendar.get(11);
      minutes = calendar.get(12);
      seconds = calendar.get(13);
      millis = calendar.get(14);
      String str = dateFormatter.format(paramDate);
      try
      {
        setText(str);
      }
      catch (RuntimeException localRuntimeException)
      {
        localRuntimeException.printStackTrace();
      }
    }
    if ((paramDate != null) && (dateUtil.checkDate(paramDate))) {
      setForeground(Color.BLACK);
    }
    if (paramBoolean) {
      firePropertyChange("date", localDate, paramDate);
    }
  }
  
  public void setDateFormatString(String paramString)
  {
    if (ignoreDatePatternChange) {
      return;
    }
    try
    {
      dateFormatter.applyPattern(paramString);
    }
    catch (RuntimeException localRuntimeException)
    {
      dateFormatter = ((SimpleDateFormat)DateFormat.getDateInstance(2));
      dateFormatter.setLenient(false);
    }
    datePattern = dateFormatter.toPattern();
    setToolTipText(datePattern);
    setDate(date, false);
  }
  
  public String getDateFormatString()
  {
    return datePattern;
  }
  
  public JComponent getUiComponent()
  {
    return this;
  }
  
  public void caretUpdate(CaretEvent paramCaretEvent)
  {
    String str1 = getText().trim();
    String str2 = maskPattern.replace('#', placeholder);
    if ((str1.length() == 0) || (str1.equals(str2)))
    {
      setForeground(Color.BLACK);
      return;
    }
    try
    {
      Date localDate = dateFormatter.parse(getText());
      if (dateUtil.checkDate(localDate)) {
        setForeground(darkGreen);
      } else {
        setForeground(Color.RED);
      }
    }
    catch (Exception localException)
    {
      setForeground(Color.RED);
    }
  }
  
  public void focusLost(FocusEvent paramFocusEvent)
  {
    checkText();
  }
  
  private void checkText()
  {
    try
    {
      Date localDate = dateFormatter.parse(getText());
      setDate(localDate, true);
    }
    catch (Exception localException) {}
  }
  
  public void focusGained(FocusEvent paramFocusEvent) {}
  
  public void setLocale(Locale paramLocale)
  {
    if ((paramLocale == getLocale()) || (ignoreDatePatternChange)) {
      return;
    }
    super.setLocale(paramLocale);
    dateFormatter = ((SimpleDateFormat)DateFormat.getDateInstance(2, paramLocale));
    setToolTipText(dateFormatter.toPattern());
    setDate(date, false);
    doLayout();
  }
  
  public String createMaskFromDatePattern(String paramString)
  {
    String str1 = "GyMdkHmsSEDFwWahKzZ";
    String str2 = "";
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      int j = 0;
      for (int k = 0; k < str1.length(); k++) {
        if (str1.charAt(k) == c)
        {
          str2 = str2 + "#";
          j = 1;
          break;
        }
      }
      if (j == 0) {
        str2 = str2 + c;
      }
    }
    return str2;
  }
  
  public boolean isMaskVisible()
  {
    return isMaskVisible;
  }
  
  public void setMaskVisible(boolean paramBoolean)
  {
    isMaskVisible = paramBoolean;
    if ((paramBoolean) && (maskFormatter == null)) {
      try
      {
        maskFormatter = new MaskFormatter(createMaskFromDatePattern(datePattern));
        maskFormatter.setPlaceholderCharacter(placeholder);
        maskFormatter.install(this);
      }
      catch (ParseException localParseException)
      {
        localParseException.printStackTrace();
      }
    }
  }
  
  public Dimension getPreferredSize()
  {
    if (datePattern != null) {
      return new JTextField(datePattern).getPreferredSize();
    }
    return super.getPreferredSize();
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    checkText();
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    if (!paramBoolean) {
      super.setBackground(UIManager.getColor("TextField.inactiveBackground"));
    }
  }
  
  public Date getMaxSelectableDate()
  {
    return dateUtil.getMaxSelectableDate();
  }
  
  public Date getMinSelectableDate()
  {
    return dateUtil.getMinSelectableDate();
  }
  
  public void setMaxSelectableDate(Date paramDate)
  {
    dateUtil.setMaxSelectableDate(paramDate);
    checkText();
  }
  
  public void setMinSelectableDate(Date paramDate)
  {
    dateUtil.setMinSelectableDate(paramDate);
    checkText();
  }
  
  public void setSelectableDateRange(Date paramDate1, Date paramDate2)
  {
    dateUtil.setSelectableDateRange(paramDate1, paramDate2);
    checkText();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("JTextFieldDateEditor");
    JTextFieldDateEditor localJTextFieldDateEditor = new JTextFieldDateEditor();
    localJTextFieldDateEditor.setDate(new Date());
    localJFrame.getContentPane().add(localJTextFieldDateEditor);
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JTextFieldDateEditor
 * JD-Core Version:    0.7.0.1
 */