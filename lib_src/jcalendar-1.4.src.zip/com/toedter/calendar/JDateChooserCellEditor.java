package com.toedter.calendar;

import java.awt.Component;
import java.util.Date;
import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

public class JDateChooserCellEditor
  extends AbstractCellEditor
  implements TableCellEditor
{
  private static final long serialVersionUID = 917881575221755609L;
  private JDateChooser dateChooser = new JDateChooser();
  
  public Component getTableCellEditorComponent(JTable paramJTable, Object paramObject, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    Date localDate = null;
    if ((paramObject instanceof Date)) {
      localDate = (Date)paramObject;
    }
    dateChooser.setDate(localDate);
    return dateChooser;
  }
  
  public Object getCellEditorValue()
  {
    return dateChooser.getDate();
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JDateChooserCellEditor
 * JD-Core Version:    0.7.0.1
 */