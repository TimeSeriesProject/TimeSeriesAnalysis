package com.toedter.calendar;

import com.toedter.components.UTF8ResourceBundle;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JCalendar
  extends JPanel
  implements PropertyChangeListener
{
  private static final long serialVersionUID = 8913369762644440133L;
  private Calendar calendar;
  private boolean initialized = false;
  private final JPanel monthYearPanel;
  private final JPanel specialButtonPanel;
  private boolean isTodayButtonVisible;
  private boolean isNullDateButtonVisible;
  private final String defaultTodayButtonText = "Today";
  private final String defaultNullDateButtonText = "No Date";
  private String todayButtonText;
  private String nullDateButtonText;
  protected JDayChooser dayChooser;
  protected boolean weekOfYearVisible = true;
  protected Locale locale;
  protected JMonthChooser monthChooser;
  protected JYearChooser yearChooser;
  private final JButton todayButton;
  private final JButton nullDateButton;
  
  public JCalendar()
  {
    this(null, null, true, true);
  }
  
  public JCalendar(Date paramDate)
  {
    this(paramDate, null, true, true);
  }
  
  public JCalendar(Calendar paramCalendar)
  {
    this(null, null, true, true);
    setCalendar(paramCalendar);
  }
  
  public JCalendar(Locale paramLocale)
  {
    this(null, paramLocale, true, true);
  }
  
  public JCalendar(Date paramDate, Locale paramLocale)
  {
    this(paramDate, paramLocale, true, true);
  }
  
  public JCalendar(Date paramDate, boolean paramBoolean)
  {
    this(paramDate, null, paramBoolean, true);
  }
  
  public JCalendar(Locale paramLocale, boolean paramBoolean)
  {
    this(null, paramLocale, paramBoolean, true);
  }
  
  public JCalendar(boolean paramBoolean)
  {
    this(null, null, paramBoolean, true);
  }
  
  public JCalendar(Date paramDate, Locale paramLocale, boolean paramBoolean1, boolean paramBoolean2)
  {
    setName("JCalendar");
    dayChooser = null;
    monthChooser = null;
    yearChooser = null;
    weekOfYearVisible = paramBoolean2;
    if (paramLocale == null) {
      locale = Locale.getDefault();
    } else {
      locale = paramLocale;
    }
    calendar = Calendar.getInstance(locale);
    setLayout(new BorderLayout());
    monthYearPanel = new JPanel();
    monthYearPanel.setLayout(new BorderLayout());
    monthChooser = new JMonthChooser(paramBoolean1);
    yearChooser = new JYearChooser();
    monthChooser.setYearChooser(yearChooser);
    monthChooser.setLocale(locale);
    monthYearPanel.add(monthChooser, "West");
    monthYearPanel.add(yearChooser, "Center");
    monthYearPanel.setBorder(BorderFactory.createEmptyBorder());
    dayChooser = new JDayChooser(paramBoolean2);
    dayChooser.addPropertyChangeListener(this);
    dayChooser.setLocale(locale);
    monthChooser.setDayChooser(dayChooser);
    monthChooser.addPropertyChangeListener(this);
    yearChooser.setDayChooser(dayChooser);
    yearChooser.addPropertyChangeListener(this);
    add(monthYearPanel, "North");
    add(dayChooser, "Center");
    specialButtonPanel = new JPanel();
    todayButton = new JButton();
    todayButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        setDate(new Date());
      }
    });
    nullDateButton = new JButton();
    nullDateButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        dayChooser.firePropertyChange("day", 0, -1);
      }
    });
    specialButtonPanel.setVisible(false);
    add(specialButtonPanel, "South");
    if (paramDate != null) {
      calendar.setTime(paramDate);
    }
    initialized = true;
    setCalendar(calendar);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("JCalendar");
    JCalendar localJCalendar = new JCalendar();
    localJFrame.getContentPane().add(localJCalendar);
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
  
  public Calendar getCalendar()
  {
    return calendar;
  }
  
  public JDayChooser getDayChooser()
  {
    return dayChooser;
  }
  
  public Locale getLocale()
  {
    return locale;
  }
  
  public JMonthChooser getMonthChooser()
  {
    return monthChooser;
  }
  
  public JYearChooser getYearChooser()
  {
    return yearChooser;
  }
  
  public boolean isWeekOfYearVisible()
  {
    return dayChooser.isWeekOfYearVisible();
  }
  
  public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
  {
    if (calendar != null)
    {
      Calendar localCalendar = (Calendar)calendar.clone();
      if (paramPropertyChangeEvent.getPropertyName().equals("day"))
      {
        localCalendar.set(5, ((Integer)paramPropertyChangeEvent.getNewValue()).intValue());
        setCalendar(localCalendar, false);
      }
      else if (paramPropertyChangeEvent.getPropertyName().equals("month"))
      {
        localCalendar.set(2, ((Integer)paramPropertyChangeEvent.getNewValue()).intValue());
        setCalendar(localCalendar, false);
      }
      else if (paramPropertyChangeEvent.getPropertyName().equals("year"))
      {
        localCalendar.set(1, ((Integer)paramPropertyChangeEvent.getNewValue()).intValue());
        setCalendar(localCalendar, false);
      }
      else if (paramPropertyChangeEvent.getPropertyName().equals("date"))
      {
        localCalendar.setTime((Date)paramPropertyChangeEvent.getNewValue());
        setCalendar(localCalendar, true);
      }
    }
  }
  
  public void setBackground(Color paramColor)
  {
    super.setBackground(paramColor);
    if (dayChooser != null) {
      dayChooser.setBackground(paramColor);
    }
  }
  
  public void setCalendar(Calendar paramCalendar)
  {
    setCalendar(paramCalendar, true);
  }
  
  private void setCalendar(Calendar paramCalendar, boolean paramBoolean)
  {
    if (paramCalendar == null) {
      setDate(null);
    }
    Calendar localCalendar = calendar;
    calendar = paramCalendar;
    if (paramBoolean)
    {
      yearChooser.setYear(paramCalendar.get(1));
      monthChooser.setMonth(paramCalendar.get(2));
      dayChooser.setDay(paramCalendar.get(5));
    }
    firePropertyChange("calendar", localCalendar, calendar);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    if (dayChooser != null)
    {
      dayChooser.setEnabled(paramBoolean);
      monthChooser.setEnabled(paramBoolean);
      yearChooser.setEnabled(paramBoolean);
    }
  }
  
  public boolean isEnabled()
  {
    return super.isEnabled();
  }
  
  public void setFont(Font paramFont)
  {
    super.setFont(paramFont);
    if (dayChooser != null)
    {
      dayChooser.setFont(paramFont);
      monthChooser.setFont(paramFont);
      yearChooser.setFont(paramFont);
    }
  }
  
  public void setForeground(Color paramColor)
  {
    super.setForeground(paramColor);
    if (dayChooser != null)
    {
      dayChooser.setForeground(paramColor);
      monthChooser.setForeground(paramColor);
      yearChooser.setForeground(paramColor);
    }
  }
  
  public void setLocale(Locale paramLocale)
  {
    if (!initialized)
    {
      super.setLocale(paramLocale);
    }
    else
    {
      Locale localLocale = locale;
      locale = paramLocale;
      dayChooser.setLocale(locale);
      monthChooser.setLocale(locale);
      relayoutSpecialButtonPanel();
      firePropertyChange("locale", localLocale, locale);
    }
  }
  
  public void setWeekOfYearVisible(boolean paramBoolean)
  {
    dayChooser.setWeekOfYearVisible(paramBoolean);
    setLocale(locale);
  }
  
  public boolean isDecorationBackgroundVisible()
  {
    return dayChooser.isDecorationBackgroundVisible();
  }
  
  public void setDecorationBackgroundVisible(boolean paramBoolean)
  {
    dayChooser.setDecorationBackgroundVisible(paramBoolean);
    setLocale(locale);
  }
  
  public boolean isDecorationBordersVisible()
  {
    return dayChooser.isDecorationBordersVisible();
  }
  
  public void setDecorationBordersVisible(boolean paramBoolean)
  {
    dayChooser.setDecorationBordersVisible(paramBoolean);
    setLocale(locale);
  }
  
  public Color getDecorationBackgroundColor()
  {
    return dayChooser.getDecorationBackgroundColor();
  }
  
  public void setDecorationBackgroundColor(Color paramColor)
  {
    dayChooser.setDecorationBackgroundColor(paramColor);
  }
  
  public Color getSundayForeground()
  {
    return dayChooser.getSundayForeground();
  }
  
  public Color getWeekdayForeground()
  {
    return dayChooser.getWeekdayForeground();
  }
  
  public void setSundayForeground(Color paramColor)
  {
    dayChooser.setSundayForeground(paramColor);
  }
  
  public void setWeekdayForeground(Color paramColor)
  {
    dayChooser.setWeekdayForeground(paramColor);
  }
  
  public Date getDate()
  {
    return new Date(calendar.getTimeInMillis());
  }
  
  public void setDate(Date paramDate)
  {
    Date localDate = calendar.getTime();
    calendar.setTime(paramDate);
    int i = calendar.get(1);
    int j = calendar.get(2);
    int k = calendar.get(5);
    yearChooser.setYear(i);
    monthChooser.setMonth(j);
    dayChooser.setCalendar(calendar);
    dayChooser.setDay(k);
    firePropertyChange("date", localDate, paramDate);
  }
  
  public void setSelectableDateRange(Date paramDate1, Date paramDate2)
  {
    dayChooser.setSelectableDateRange(paramDate1, paramDate2);
  }
  
  public Date getMaxSelectableDate()
  {
    return dayChooser.getMaxSelectableDate();
  }
  
  public Date getMinSelectableDate()
  {
    return dayChooser.getMinSelectableDate();
  }
  
  public void setMaxSelectableDate(Date paramDate)
  {
    dayChooser.setMaxSelectableDate(paramDate);
  }
  
  public void setMinSelectableDate(Date paramDate)
  {
    dayChooser.setMinSelectableDate(paramDate);
  }
  
  public int getMaxDayCharacters()
  {
    return dayChooser.getMaxDayCharacters();
  }
  
  public void setMaxDayCharacters(int paramInt)
  {
    dayChooser.setMaxDayCharacters(paramInt);
  }
  
  public void setTodayButtonVisible(boolean paramBoolean)
  {
    isTodayButtonVisible = paramBoolean;
    relayoutSpecialButtonPanel();
  }
  
  public boolean isTodayButtonVisible()
  {
    return isTodayButtonVisible;
  }
  
  public void setNullDateButtonVisible(boolean paramBoolean)
  {
    isNullDateButtonVisible = paramBoolean;
    relayoutSpecialButtonPanel();
  }
  
  public boolean isNullDateButtonVisible()
  {
    return isNullDateButtonVisible;
  }
  
  private void relayoutSpecialButtonPanel()
  {
    ResourceBundle localResourceBundle = null;
    try
    {
      localResourceBundle = UTF8ResourceBundle.getBundle("com.toedter.calendar.jcalendar", locale);
    }
    catch (Exception localException1)
    {
      System.out.println(localException1.getMessage());
    }
    specialButtonPanel.removeAll();
    int i = 0;
    String str;
    if (isTodayButtonVisible)
    {
      str = todayButtonText;
      if ((str == null) && (localResourceBundle != null)) {
        try
        {
          str = localResourceBundle.getString("todayButton.text");
        }
        catch (Exception localException2) {}
      }
      if (str == null) {
        str = "Today";
      }
      todayButton.setText(str);
      specialButtonPanel.add(todayButton);
      i++;
    }
    if (isNullDateButtonVisible)
    {
      str = nullDateButtonText;
      if ((str == null) && (localResourceBundle != null)) {
        try
        {
          str = localResourceBundle.getString("nullDateButton.text");
        }
        catch (Exception localException3) {}
      }
      if (str == null) {
        str = "No Date";
      }
      nullDateButton.setText(str);
      specialButtonPanel.add(nullDateButton);
      i++;
    }
    specialButtonPanel.setLayout(new GridLayout(1, i));
    if (isTodayButtonVisible) {
      specialButtonPanel.add(todayButton);
    }
    if (isNullDateButtonVisible) {
      specialButtonPanel.add(nullDateButton);
    }
    specialButtonPanel.setVisible((isNullDateButtonVisible) || (isTodayButtonVisible));
    todayButton.invalidate();
    todayButton.repaint();
    nullDateButton.invalidate();
    nullDateButton.repaint();
    specialButtonPanel.invalidate();
    specialButtonPanel.doLayout();
    specialButtonPanel.repaint();
    invalidate();
    repaint();
  }
  
  public String getTodayButtonText()
  {
    return todayButtonText;
  }
  
  public void setTodayButtonText(String paramString)
  {
    if (((paramString != null ? 1 : 0) & (paramString.trim().length() == 0 ? 1 : 0)) != 0) {
      todayButtonText = null;
    } else {
      todayButtonText = paramString;
    }
    relayoutSpecialButtonPanel();
  }
  
  public String getNullDateButtonText()
  {
    return nullDateButtonText;
  }
  
  public void setNullDateButtonText(String paramString)
  {
    if (((paramString != null ? 1 : 0) & (paramString.trim().length() == 0 ? 1 : 0)) != 0) {
      nullDateButtonText = null;
    } else {
      nullDateButtonText = paramString;
    }
    relayoutSpecialButtonPanel();
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JCalendar
 * JD-Core Version:    0.7.0.1
 */