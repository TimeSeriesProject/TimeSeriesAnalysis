package com.toedter.calendar;

import java.awt.Color;
import java.util.Date;

public abstract interface IDateEvaluator
{
  public abstract boolean isSpecial(Date paramDate);
  
  public abstract Color getSpecialForegroundColor();
  
  public abstract Color getSpecialBackroundColor();
  
  public abstract String getSpecialTooltip();
  
  public abstract boolean isInvalid(Date paramDate);
  
  public abstract Color getInvalidForegroundColor();
  
  public abstract Color getInvalidBackroundColor();
  
  public abstract String getInvalidTooltip();
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.IDateEvaluator
 * JD-Core Version:    0.7.0.1
 */