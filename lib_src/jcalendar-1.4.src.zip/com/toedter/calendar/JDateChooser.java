package com.toedter.calendar;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JDateChooser
  extends JPanel
  implements ActionListener, PropertyChangeListener
{
  private static final long serialVersionUID = -4306412745720670722L;
  protected IDateEditor dateEditor;
  protected JButton calendarButton;
  protected JCalendar jcalendar;
  protected JPopupMenu popup;
  protected boolean isInitialized;
  protected boolean dateSelected;
  protected Date lastSelectedDate;
  private ChangeListener changeListener;
  
  public JDateChooser()
  {
    this(null, null, null, null);
  }
  
  public JDateChooser(IDateEditor paramIDateEditor)
  {
    this(null, null, null, paramIDateEditor);
  }
  
  public JDateChooser(Date paramDate)
  {
    this(paramDate, null);
  }
  
  public JDateChooser(Date paramDate, String paramString)
  {
    this(paramDate, paramString, null);
  }
  
  public JDateChooser(Date paramDate, String paramString, IDateEditor paramIDateEditor)
  {
    this(null, paramDate, paramString, paramIDateEditor);
  }
  
  public JDateChooser(String paramString1, String paramString2, char paramChar)
  {
    this(null, null, paramString1, new JTextFieldDateEditor(paramString1, paramString2, paramChar));
  }
  
  public JDateChooser(JCalendar paramJCalendar, Date paramDate, String paramString, IDateEditor paramIDateEditor)
  {
    setName("JDateChooser");
    dateEditor = paramIDateEditor;
    if (dateEditor == null) {
      dateEditor = new JTextFieldDateEditor();
    }
    dateEditor.addPropertyChangeListener("date", this);
    if (paramJCalendar == null)
    {
      jcalendar = new JCalendar(paramDate);
    }
    else
    {
      jcalendar = paramJCalendar;
      if (paramDate != null) {
        jcalendar.setDate(paramDate);
      }
    }
    setLayout(new BorderLayout());
    jcalendar.getDayChooser().addPropertyChangeListener("day", this);
    jcalendar.getDayChooser().setAlwaysFireDayProperty(true);
    setDateFormatString(paramString);
    setDate(paramDate);
    URL localURL = getClass().getResource("/com/toedter/calendar/images/JDateChooserIcon.gif");
    ImageIcon localImageIcon = new ImageIcon(localURL);
    calendarButton = new JButton(localImageIcon)
    {
      private static final long serialVersionUID = -1913767779079949668L;
      
      public boolean isFocusable()
      {
        return false;
      }
    };
    calendarButton.setMargin(new Insets(0, 0, 0, 0));
    calendarButton.addActionListener(this);
    calendarButton.setMnemonic(67);
    add(calendarButton, "East");
    add(dateEditor.getUiComponent(), "Center");
    calendarButton.setMargin(new Insets(0, 0, 0, 0));
    popup = new JPopupMenu()
    {
      private static final long serialVersionUID = -6078272560337577761L;
      
      public void setVisible(boolean paramAnonymousBoolean)
      {
        Boolean localBoolean = (Boolean)getClientProperty("JPopupMenu.firePopupMenuCanceled");
        if ((paramAnonymousBoolean) || ((!paramAnonymousBoolean) && (dateSelected)) || ((localBoolean != null) && (!paramAnonymousBoolean) && (localBoolean.booleanValue()))) {
          super.setVisible(paramAnonymousBoolean);
        }
      }
    };
    popup.setLightWeightPopupEnabled(true);
    popup.add(jcalendar);
    lastSelectedDate = paramDate;
    changeListener = new ChangeListener()
    {
      boolean hasListened = false;
      
      public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
      {
        if (hasListened)
        {
          hasListened = false;
          return;
        }
        if ((popup.isVisible()) && (jcalendar.monthChooser.getComboBox().hasFocus()))
        {
          MenuElement[] arrayOfMenuElement1 = MenuSelectionManager.defaultManager().getSelectedPath();
          MenuElement[] arrayOfMenuElement2 = new MenuElement[arrayOfMenuElement1.length + 1];
          arrayOfMenuElement2[0] = popup;
          for (int i = 0; i < arrayOfMenuElement1.length; i++) {
            arrayOfMenuElement2[(i + 1)] = arrayOfMenuElement1[i];
          }
          hasListened = true;
          MenuSelectionManager.defaultManager().setSelectedPath(arrayOfMenuElement2);
        }
      }
    };
    MenuSelectionManager.defaultManager().addChangeListener(changeListener);
    isInitialized = true;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    int i = calendarButton.getWidth() - (int)popup.getPreferredSize().getWidth();
    int j = calendarButton.getY() + calendarButton.getHeight();
    Calendar localCalendar = Calendar.getInstance();
    Date localDate = dateEditor.getDate();
    if (localDate != null) {
      localCalendar.setTime(localDate);
    }
    jcalendar.setCalendar(localCalendar);
    popup.show(calendarButton, i, j);
    dateSelected = false;
  }
  
  public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
  {
    if (paramPropertyChangeEvent.getPropertyName().equals("day"))
    {
      if (popup.isVisible())
      {
        dateSelected = true;
        popup.setVisible(false);
        if (((Integer)paramPropertyChangeEvent.getNewValue()).intValue() > 0) {
          setDate(jcalendar.getCalendar().getTime());
        } else {
          setDate(null);
        }
      }
    }
    else if (paramPropertyChangeEvent.getPropertyName().equals("date")) {
      if (paramPropertyChangeEvent.getSource() == dateEditor) {
        firePropertyChange("date", paramPropertyChangeEvent.getOldValue(), paramPropertyChangeEvent.getNewValue());
      } else {
        setDate((Date)paramPropertyChangeEvent.getNewValue());
      }
    }
  }
  
  public void updateUI()
  {
    super.updateUI();
    setEnabled(isEnabled());
    if (jcalendar != null) {
      SwingUtilities.updateComponentTreeUI(popup);
    }
  }
  
  public void setLocale(Locale paramLocale)
  {
    super.setLocale(paramLocale);
    dateEditor.setLocale(paramLocale);
    jcalendar.setLocale(paramLocale);
  }
  
  public String getDateFormatString()
  {
    return dateEditor.getDateFormatString();
  }
  
  public void setDateFormatString(String paramString)
  {
    dateEditor.setDateFormatString(paramString);
    invalidate();
  }
  
  public Date getDate()
  {
    return dateEditor.getDate();
  }
  
  public void setDate(Date paramDate)
  {
    dateEditor.setDate(paramDate);
    if (getParent() != null) {
      getParent().invalidate();
    }
  }
  
  public Calendar getCalendar()
  {
    Date localDate = getDate();
    if (localDate == null) {
      return null;
    }
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTime(localDate);
    return localCalendar;
  }
  
  public void setCalendar(Calendar paramCalendar)
  {
    if (paramCalendar == null) {
      dateEditor.setDate(null);
    } else {
      dateEditor.setDate(paramCalendar.getTime());
    }
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    if (dateEditor != null)
    {
      dateEditor.setEnabled(paramBoolean);
      calendarButton.setEnabled(paramBoolean);
    }
  }
  
  public boolean isEnabled()
  {
    return super.isEnabled();
  }
  
  public void setIcon(ImageIcon paramImageIcon)
  {
    calendarButton.setIcon(paramImageIcon);
  }
  
  public void setFont(Font paramFont)
  {
    if (isInitialized)
    {
      dateEditor.getUiComponent().setFont(paramFont);
      jcalendar.setFont(paramFont);
    }
    super.setFont(paramFont);
  }
  
  public JCalendar getJCalendar()
  {
    return jcalendar;
  }
  
  public JButton getCalendarButton()
  {
    return calendarButton;
  }
  
  public IDateEditor getDateEditor()
  {
    return dateEditor;
  }
  
  public void setSelectableDateRange(Date paramDate1, Date paramDate2)
  {
    jcalendar.setSelectableDateRange(paramDate1, paramDate2);
    dateEditor.setSelectableDateRange(jcalendar.getMinSelectableDate(), jcalendar.getMaxSelectableDate());
  }
  
  public void setMaxSelectableDate(Date paramDate)
  {
    jcalendar.setMaxSelectableDate(paramDate);
    dateEditor.setMaxSelectableDate(paramDate);
  }
  
  public void setMinSelectableDate(Date paramDate)
  {
    jcalendar.setMinSelectableDate(paramDate);
    dateEditor.setMinSelectableDate(paramDate);
  }
  
  public Date getMaxSelectableDate()
  {
    return jcalendar.getMaxSelectableDate();
  }
  
  public Date getMinSelectableDate()
  {
    return jcalendar.getMinSelectableDate();
  }
  
  public void cleanup()
  {
    MenuSelectionManager.defaultManager().removeChangeListener(changeListener);
    changeListener = null;
  }
  
  public boolean requestFocusInWindow()
  {
    if ((dateEditor instanceof JComponent)) {
      return ((JComponent)dateEditor).requestFocusInWindow();
    }
    return super.requestFocusInWindow();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("JDateChooser");
    JDateChooser localJDateChooser = new JDateChooser();
    localJFrame.getContentPane().add(localJDateChooser);
    localJFrame.pack();
    localJFrame.setVisible(true);
    localJDateChooser.requestFocusInWindow();
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JDateChooser
 * JD-Core Version:    0.7.0.1
 */