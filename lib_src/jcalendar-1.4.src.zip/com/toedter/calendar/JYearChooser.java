package com.toedter.calendar;

import com.toedter.components.JSpinField;
import java.awt.Container;
import java.util.Calendar;
import javax.swing.JFrame;
import javax.swing.JSpinner;

public class JYearChooser
  extends JSpinField
{
  private static final long serialVersionUID = 2648810220491090064L;
  protected JDayChooser dayChooser;
  protected int oldYear;
  protected int startYear;
  protected int endYear;
  
  public JYearChooser()
  {
    setName("JYearChooser");
    Calendar localCalendar = Calendar.getInstance();
    dayChooser = null;
    setMinimum(localCalendar.getMinimum(1));
    setMaximum(localCalendar.getMaximum(1));
    setValue(localCalendar.get(1));
  }
  
  public void setYear(int paramInt)
  {
    super.setValue(paramInt, true, false);
    if (dayChooser != null) {
      dayChooser.setYear(value);
    }
    spinner.setValue(new Integer(value));
    firePropertyChange("year", oldYear, value);
    oldYear = value;
  }
  
  public void setValue(int paramInt)
  {
    setYear(paramInt);
  }
  
  public int getYear()
  {
    return super.getValue();
  }
  
  public void setDayChooser(JDayChooser paramJDayChooser)
  {
    dayChooser = paramJDayChooser;
  }
  
  public int getEndYear()
  {
    return getMaximum();
  }
  
  public void setEndYear(int paramInt)
  {
    setMaximum(paramInt);
  }
  
  public int getStartYear()
  {
    return getMinimum();
  }
  
  public void setStartYear(int paramInt)
  {
    setMinimum(paramInt);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("JYearChooser");
    localJFrame.getContentPane().add(new JYearChooser());
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.calendar.JYearChooser
 * JD-Core Version:    0.7.0.1
 */