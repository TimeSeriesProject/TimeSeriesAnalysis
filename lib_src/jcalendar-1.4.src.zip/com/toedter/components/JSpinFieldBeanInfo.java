package com.toedter.components;

public class JSpinFieldBeanInfo
  extends GenericBeanInfo
{
  public JSpinFieldBeanInfo()
  {
    super("JSpinField", false);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.JSpinFieldBeanInfo
 * JD-Core Version:    0.7.0.1
 */