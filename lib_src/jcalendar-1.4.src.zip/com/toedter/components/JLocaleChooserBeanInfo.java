package com.toedter.components;

public class JLocaleChooserBeanInfo
  extends GenericBeanInfo
{
  public JLocaleChooserBeanInfo()
  {
    super("JLocaleChooser", true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.JLocaleChooserBeanInfo
 * JD-Core Version:    0.7.0.1
 */