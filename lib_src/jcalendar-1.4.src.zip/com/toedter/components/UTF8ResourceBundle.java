package com.toedter.components;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public abstract class UTF8ResourceBundle
{
  public static final ResourceBundle getBundle(String paramString, Locale paramLocale)
  {
    ResourceBundle localResourceBundle = ResourceBundle.getBundle(paramString, paramLocale);
    if (!(localResourceBundle instanceof PropertyResourceBundle)) {
      return localResourceBundle;
    }
    return new UTF8PropertyResourceBundle((PropertyResourceBundle)localResourceBundle, null);
  }
  
  private static class UTF8PropertyResourceBundle
    extends ResourceBundle
  {
    PropertyResourceBundle propertyResourceBundle;
    
    private UTF8PropertyResourceBundle(PropertyResourceBundle paramPropertyResourceBundle)
    {
      propertyResourceBundle = paramPropertyResourceBundle;
    }
    
    public Enumeration getKeys()
    {
      return propertyResourceBundle.getKeys();
    }
    
    protected Object handleGetObject(String paramString)
    {
      String str = (String)propertyResourceBundle.handleGetObject(paramString);
      if (str != null) {
        try
        {
          return new String(str.getBytes("ISO-8859-1"), "UTF-8");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          throw new RuntimeException("UTF-8 encoding is not supported.", localUnsupportedEncodingException);
        }
      }
      return null;
    }
    
    UTF8PropertyResourceBundle(PropertyResourceBundle paramPropertyResourceBundle, UTF8ResourceBundle.1 param1)
    {
      this(paramPropertyResourceBundle);
    }
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.UTF8ResourceBundle
 * JD-Core Version:    0.7.0.1
 */