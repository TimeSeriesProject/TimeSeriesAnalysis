package com.toedter.components;

import java.awt.Image;
import java.beans.PropertyEditorManager;
import java.beans.SimpleBeanInfo;
import java.io.PrintStream;
import java.util.Locale;

public class GenericBeanInfo
  extends SimpleBeanInfo
{
  protected Image iconColor16;
  protected Image iconColor32;
  protected Image iconMono16;
  protected Image iconMono32;
  
  public GenericBeanInfo(String paramString, boolean paramBoolean)
  {
    try
    {
      iconColor16 = loadImage("images/" + paramString + "Color16.gif");
      iconColor32 = loadImage("images/" + paramString + "Color32.gif");
      iconMono16 = loadImage("images/" + paramString + "Mono16.gif");
      iconMono32 = loadImage("images/" + paramString + "Mono32.gif");
    }
    catch (RuntimeException localRuntimeException)
    {
      System.out.println("GenericBeanInfo.GenericBeanInfo(): " + localRuntimeException);
    }
    if (paramBoolean) {
      PropertyEditorManager.registerEditor(Locale.class, LocaleEditor.class);
    }
  }
  
  public Image getIcon(int paramInt)
  {
    switch (paramInt)
    {
    case 1: 
      return iconColor16;
    case 2: 
      return iconColor32;
    case 3: 
      return iconMono16;
    case 4: 
      return iconMono32;
    }
    return null;
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.GenericBeanInfo
 * JD-Core Version:    0.7.0.1
 */