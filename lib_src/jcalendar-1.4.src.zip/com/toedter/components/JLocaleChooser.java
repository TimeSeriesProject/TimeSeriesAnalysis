package com.toedter.components;

import java.awt.Container;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class JLocaleChooser
  extends JComboBox
  implements ItemListener
{
  private static final long serialVersionUID = 8152430789764877431L;
  protected JComponent component;
  private Locale[] locales;
  private Locale locale;
  private int localeCount;
  
  public JLocaleChooser()
  {
    this(null);
  }
  
  public String getName()
  {
    return "JLocaleChoose";
  }
  
  public JLocaleChooser(JComponent paramJComponent)
  {
    component = paramJComponent;
    addItemListener(this);
    locales = Calendar.getAvailableLocales();
    localeCount = locales.length;
    for (int i = 0; i < localeCount; i++) {
      if (locales[i].getCountry().length() > 0) {
        addItem(locales[i].getDisplayName());
      }
    }
    setLocale(Locale.getDefault());
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    String str = (String)paramItemEvent.getItem();
    for (int i = 0; (i < localeCount) && (!locales[i].getDisplayName().equals(str)); i++) {}
    setLocale(locales[i], false);
  }
  
  private void setLocale(Locale paramLocale, boolean paramBoolean)
  {
    Locale localLocale = locale;
    locale = paramLocale;
    int i = 0;
    if (paramBoolean) {
      for (int j = 0; j < localeCount; j++) {
        if (locales[j].getCountry().length() > 0)
        {
          if (locales[j].equals(locale)) {
            setSelectedIndex(i);
          }
          i++;
        }
      }
    }
    firePropertyChange("locale", localLocale, locale);
    if (component != null) {
      component.setLocale(paramLocale);
    }
  }
  
  public void setLocale(Locale paramLocale)
  {
    setLocale(paramLocale, true);
  }
  
  public Locale getLocale()
  {
    return locale;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("LocaleChooser");
    localJFrame.getContentPane().add(new JLocaleChooser());
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.JLocaleChooser
 * JD-Core Version:    0.7.0.1
 */