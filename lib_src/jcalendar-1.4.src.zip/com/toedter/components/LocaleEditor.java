package com.toedter.components;

import java.beans.PropertyEditorSupport;
import java.util.Calendar;
import java.util.Locale;

public class LocaleEditor
  extends PropertyEditorSupport
{
  private Locale[] locales = Calendar.getAvailableLocales();
  private String[] localeStrings = new String[length];
  private Locale locale = Locale.getDefault();
  private int length = locales.length;
  
  public String[] getTags()
  {
    for (int i = 0; i < length; i++) {
      localeStrings[i] = locales[i].getDisplayName();
    }
    return localeStrings;
  }
  
  public void setAsText(String paramString)
    throws IllegalArgumentException
  {
    for (int i = 0; i < length; i++) {
      if (paramString.equals(locales[i].getDisplayName()))
      {
        locale = locales[i];
        setValue(locale);
        break;
      }
    }
  }
  
  public String getAsText()
  {
    return locale.getDisplayName();
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.LocaleEditor
 * JD-Core Version:    0.7.0.1
 */