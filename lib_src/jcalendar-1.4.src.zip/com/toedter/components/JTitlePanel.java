package com.toedter.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class JTitlePanel
  extends JPanel
{
  private static final long serialVersionUID = 9104873267039717087L;
  protected JPanel northPanel;
  protected JLabel label;
  
  public JTitlePanel(String paramString, Icon paramIcon, JComponent paramJComponent, Border paramBorder)
  {
    setLayout(new BorderLayout());
    label = new JLabel(paramString, paramIcon, 10);
    label.setForeground(Color.WHITE);
    GradientPanel localGradientPanel = new GradientPanel(Color.BLACK, null);
    localGradientPanel.setLayout(new BorderLayout());
    localGradientPanel.add(label, "West");
    int i = 2;
    if (paramIcon == null) {
      i++;
    }
    localGradientPanel.setBorder(BorderFactory.createEmptyBorder(i, 4, i, 1));
    add(localGradientPanel, "North");
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout());
    localJPanel.add(paramJComponent, "North");
    localJPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    add(localJPanel, "Center");
    if (paramBorder == null) {
      setBorder(BorderFactory.createLineBorder(Color.GRAY));
    } else {
      setBorder(BorderFactory.createCompoundBorder(paramBorder, BorderFactory.createLineBorder(Color.GRAY)));
    }
  }
  
  public void setTitle(String paramString, Icon paramIcon)
  {
    label.setText(paramString);
    label.setIcon(paramIcon);
  }
  
  private static class GradientPanel
    extends JPanel
  {
    private static final long serialVersionUID = -6385751027379193053L;
    
    private GradientPanel(Color paramColor)
    {
      setBackground(paramColor);
    }
    
    public void paintComponent(Graphics paramGraphics)
    {
      super.paintComponent(paramGraphics);
      if (isOpaque())
      {
        Color localColor = new Color(165, 201, 215);
        int i = getWidth();
        int j = getHeight();
        Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
        Paint localPaint = localGraphics2D.getPaint();
        localGraphics2D.setPaint(new GradientPaint(0.0F, 0.0F, getBackground(), i, 0.0F, localColor));
        localGraphics2D.fillRect(0, 0, i, j);
        localGraphics2D.setPaint(localPaint);
      }
    }
    
    GradientPanel(Color paramColor, JTitlePanel.1 param1)
    {
      this(paramColor);
    }
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.JTitlePanel
 * JD-Core Version:    0.7.0.1
 */