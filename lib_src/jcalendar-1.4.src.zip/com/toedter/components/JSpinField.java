package com.toedter.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JSpinField
  extends JPanel
  implements ChangeListener, CaretListener, ActionListener, FocusListener
{
  private static final long serialVersionUID = 1694904792717740650L;
  protected JSpinner spinner;
  protected JTextField textField;
  protected int min;
  protected int max;
  protected int value;
  protected Color darkGreen;
  
  public JSpinField()
  {
    this(-2147483648, 2147483647);
  }
  
  public JSpinField(int paramInt1, int paramInt2)
  {
    setName("JSpinField");
    min = paramInt1;
    if (paramInt2 < paramInt1) {
      paramInt2 = paramInt1;
    }
    max = paramInt2;
    value = 0;
    if (value < paramInt1) {
      value = paramInt1;
    }
    if (value > paramInt2) {
      value = paramInt2;
    }
    darkGreen = new Color(0, 150, 0);
    setLayout(new BorderLayout());
    textField = new JTextField();
    textField.addCaretListener(this);
    textField.addActionListener(this);
    textField.setHorizontalAlignment(4);
    textField.setBorder(BorderFactory.createEmptyBorder());
    textField.setText(Integer.toString(value));
    textField.addFocusListener(this);
    spinner = new JSpinner()
    {
      private static final long serialVersionUID = -6287709243342021172L;
      private JTextField textField = new JTextField();
      
      public Dimension getPreferredSize()
      {
        Dimension localDimension = super.getPreferredSize();
        return new Dimension(width, textField.getPreferredSize().height);
      }
    };
    spinner.setEditor(textField);
    spinner.addChangeListener(this);
    add(spinner, "Center");
  }
  
  public void adjustWidthToMaximumValue()
  {
    JTextField localJTextField = new JTextField(Integer.toString(max));
    int i = getPreferredSize()width;
    int j = getPreferredSize()height;
    textField.setPreferredSize(new Dimension(i, j));
    textField.revalidate();
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    SpinnerNumberModel localSpinnerNumberModel = (SpinnerNumberModel)spinner.getModel();
    int i = localSpinnerNumberModel.getNumber().intValue();
    setValue(i);
  }
  
  protected void setValue(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    int i = value;
    if (paramInt < min) {
      value = min;
    } else if (paramInt > max) {
      value = max;
    } else {
      value = paramInt;
    }
    if (paramBoolean1)
    {
      textField.setText(Integer.toString(value));
      textField.setForeground(Color.black);
    }
    if (paramBoolean2) {
      firePropertyChange("value", i, value);
    }
  }
  
  public void setValue(int paramInt)
  {
    setValue(paramInt, true, true);
    spinner.setValue(new Integer(value));
  }
  
  public int getValue()
  {
    return value;
  }
  
  public void setMinimum(int paramInt)
  {
    min = paramInt;
  }
  
  public int getMinimum()
  {
    return min;
  }
  
  public void setMaximum(int paramInt)
  {
    max = paramInt;
  }
  
  public void setHorizontalAlignment(int paramInt)
  {
    textField.setHorizontalAlignment(paramInt);
  }
  
  public int getMaximum()
  {
    return max;
  }
  
  public void setFont(Font paramFont)
  {
    if (textField != null) {
      textField.setFont(paramFont);
    }
  }
  
  public void setForeground(Color paramColor)
  {
    if (textField != null) {
      textField.setForeground(paramColor);
    }
  }
  
  public void caretUpdate(CaretEvent paramCaretEvent)
  {
    try
    {
      int i = Integer.valueOf(textField.getText()).intValue();
      if ((i >= min) && (i <= max))
      {
        textField.setForeground(darkGreen);
        setValue(i, false, true);
      }
      else
      {
        textField.setForeground(Color.red);
      }
    }
    catch (Exception localException)
    {
      if ((localException instanceof NumberFormatException)) {
        textField.setForeground(Color.red);
      }
    }
    textField.repaint();
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (textField.getForeground().equals(darkGreen)) {
      setValue(Integer.valueOf(textField.getText()).intValue());
    }
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    super.setEnabled(paramBoolean);
    spinner.setEnabled(paramBoolean);
    textField.setEnabled(paramBoolean);
    if (!paramBoolean) {
      textField.setBackground(UIManager.getColor("TextField.inactiveBackground"));
    }
  }
  
  public Component getSpinner()
  {
    return spinner;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    JFrame localJFrame = new JFrame("JSpinField");
    localJFrame.getContentPane().add(new JSpinField());
    localJFrame.pack();
    localJFrame.setVisible(true);
  }
  
  public void focusGained(FocusEvent paramFocusEvent) {}
  
  public void focusLost(FocusEvent paramFocusEvent)
  {
    actionPerformed(null);
  }
}


/* Location:           C:\Program Files (x86)\nbdemetra\nbdemetra\modules\ext\com.toedter\jcalendar-1.4.jar
 * Qualified Name:     com.toedter.components.JSpinField
 * JD-Core Version:    0.7.0.1
 */