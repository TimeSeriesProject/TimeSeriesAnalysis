/*  1:   */ package com.l2fprod.common.springrcp;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JDirectoryChooser;
/*  4:   */ import java.io.File;
/*  5:   */ import java.util.Map;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ import org.springframework.binding.form.FormModel;
/*  8:   */ import org.springframework.richclient.form.binding.Binding;
/*  9:   */ import org.springframework.richclient.form.binding.support.AbstractBinder;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public class JDirectoryChooserBinder
/* 30:   */   extends AbstractBinder
/* 31:   */ {
/* 32:   */   protected JDirectoryChooserBinder()
/* 33:   */   {
/* 34:34 */     super(File.class);
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected JComponent createControl(Map context) {
/* 38:38 */     return new JDirectoryChooser();
/* 39:   */   }
/* 40:   */   
/* 41:   */   protected Binding doBind(JComponent control, FormModel formModel, String formPropertyPath, Map context)
/* 42:   */   {
/* 43:43 */     JDirectoryChooser directoryChooser = (JDirectoryChooser)control;
/* 44:44 */     return new JDirectoryChooserBinding(formModel, formPropertyPath, directoryChooser);
/* 45:   */   }
/* 46:   */ }
