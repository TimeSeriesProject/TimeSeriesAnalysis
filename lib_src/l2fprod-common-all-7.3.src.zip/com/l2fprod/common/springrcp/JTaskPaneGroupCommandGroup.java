/*   1:    */ package com.l2fprod.common.springrcp;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JTaskPaneGroup;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import org.springframework.richclient.command.ActionCommand;
/*   8:    */ import org.springframework.richclient.command.CommandGroup;
/*   9:    */ import org.springframework.richclient.command.CommandRegistry;
/*  10:    */ import org.springframework.richclient.command.SwingActionAdapter;
/*  11:    */ import org.springframework.richclient.command.config.CommandFaceDescriptor;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public class JTaskPaneGroupCommandGroup
/*  31:    */   extends CommandGroup
/*  32:    */ {
/*  33: 33 */   private List actions = new ArrayList();
/*  34:    */   private boolean expanded;
/*  35:    */   private boolean special;
/*  36:    */   private boolean scrollOnExpand;
/*  37:    */   private boolean animated;
/*  38:    */   
/*  39:    */   public JTaskPaneGroupCommandGroup(String groupId, CommandRegistry registry)
/*  40:    */   {
/*  41: 41 */     super(groupId, registry);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setExpanded(boolean expanded) {
/*  45: 45 */     if (hasChanged(isExpanded(), expanded)) {
/*  46: 46 */       this.expanded = expanded;
/*  47: 47 */       firePropertyChange("expanded", !expanded, expanded);
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean isExpanded()
/*  52:    */   {
/*  53: 53 */     return expanded;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean isAnimated() {
/*  57: 57 */     return animated;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void setAnimated(boolean animated) {
/*  61: 61 */     if (hasChanged(isAnimated(), animated)) {
/*  62: 62 */       this.animated = animated;
/*  63: 63 */       firePropertyChange("animated", !animated, animated);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isScrollOnExpand()
/*  68:    */   {
/*  69: 69 */     return scrollOnExpand;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setScrollOnExpand(boolean scrollOnExpand) {
/*  73: 73 */     if (hasChanged(isScrollOnExpand(), scrollOnExpand)) {
/*  74: 74 */       this.scrollOnExpand = scrollOnExpand;
/*  75: 75 */       firePropertyChange("scrollOnExpand", !scrollOnExpand, scrollOnExpand);
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean isSpecial()
/*  80:    */   {
/*  81: 81 */     return special;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setSpecial(boolean special) {
/*  85: 85 */     if (hasChanged(isSpecial(), special)) {
/*  86: 86 */       this.special = special;
/*  87: 87 */       firePropertyChange("special", !special, special);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public JTaskPaneGroup createTaskPaneGroup() {
/*  92: 92 */     JTaskPaneGroup taskpane = new JTaskPaneGroup();
/*  93: 93 */     taskpane.setExpanded(isExpanded());
/*  94: 94 */     taskpane.setTitle(getText());
/*  95: 95 */     taskpane.setAnimated(isAnimated());
/*  96: 96 */     taskpane.setScrollOnExpand(isScrollOnExpand());
/*  97: 97 */     taskpane.setSpecial(isSpecial());
/*  98: 98 */     if (isFaceConfigured()) {
/*  99: 99 */       taskpane.setToolTipText(getFaceDescriptor().getCaption());
/* 100:    */     }
/* 101:    */     
/* 102:102 */     for (Iterator members = actions.iterator(); members.hasNext();) {
/* 103:103 */       ActionCommand member = (ActionCommand)members.next();
/* 104:    */       
/* 105:105 */       SwingActionAdapter adapter = new SwingActionAdapter(member);
/* 106:106 */       taskpane.add(adapter);
/* 107:    */     }
/* 108:108 */     return taskpane;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void addActionCommand(ActionCommand command) {
/* 112:112 */     super.add(command);
/* 113:113 */     actions.add(command);
/* 114:    */   }
/* 115:    */ }
