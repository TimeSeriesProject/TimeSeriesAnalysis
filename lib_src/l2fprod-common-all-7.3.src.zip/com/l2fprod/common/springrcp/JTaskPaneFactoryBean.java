/*  1:   */ package com.l2fprod.common.springrcp;
/*  2:   */ 
/*  3:   */ import org.springframework.richclient.command.CommandGroup;
/*  4:   */ import org.springframework.richclient.command.CommandGroupFactoryBean;
/*  5:   */ import org.springframework.richclient.command.CommandRegistry;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class JTaskPaneFactoryBean
/* 23:   */   extends CommandGroupFactoryBean
/* 24:   */ {
/* 25:   */   private String groupId;
/* 26:   */   private Object[] encodedMembers;
/* 27:   */   private CommandRegistry registry;
/* 28:   */   
/* 29:   */   public void setBeanName(String beanName)
/* 30:   */   {
/* 31:31 */     groupId = beanName;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setMembers(Object[] members) {
/* 35:35 */     encodedMembers = members;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setCommandRegistry(CommandRegistry registry) {
/* 39:39 */     this.registry = registry;
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected CommandGroup createCommandGroup() {
/* 43:43 */     JTaskPaneCommandGroup group = new JTaskPaneCommandGroup(groupId, registry);
/* 44:   */     
/* 45:45 */     if (encodedMembers != null) {
/* 46:46 */       for (int i = 0; i < encodedMembers.length; i++) {
/* 47:47 */         JTaskPaneGroupCommandGroup childGroup = (JTaskPaneGroupCommandGroup)encodedMembers[i];
/* 48:48 */         group.addTaskPaneGroup(childGroup);
/* 49:   */       }
/* 50:   */     }
/* 51:   */     
/* 52:52 */     return group;
/* 53:   */   }
/* 54:   */ }
