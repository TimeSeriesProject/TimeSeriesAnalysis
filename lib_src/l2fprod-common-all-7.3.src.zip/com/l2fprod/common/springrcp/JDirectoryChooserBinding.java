/*  1:   */ package com.l2fprod.common.springrcp;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JDirectoryChooser;
/*  4:   */ import java.beans.PropertyChangeEvent;
/*  5:   */ import java.beans.PropertyChangeListener;
/*  6:   */ import java.io.File;
/*  7:   */ import javax.swing.JComponent;
/*  8:   */ import org.springframework.binding.form.FormModel;
/*  9:   */ import org.springframework.richclient.form.binding.support.CustomBinding;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ public class JDirectoryChooserBinding
/* 31:   */   extends CustomBinding
/* 32:   */ {
/* 33:   */   private final JDirectoryChooser component;
/* 34:   */   
/* 35:   */   public JDirectoryChooserBinding(FormModel model, String property, JDirectoryChooser component)
/* 36:   */   {
/* 37:37 */     super(model, property, File.class);
/* 38:38 */     this.component = component;
/* 39:   */   }
/* 40:   */   
/* 41:   */   protected JComponent doBindControl() {
/* 42:42 */     component.setSelectedFile((File)getValue());
/* 43:43 */     component.addPropertyChangeListener(new PropertyChangeListener() {
/* 44:   */       public void propertyChange(PropertyChangeEvent evt) {
/* 45:45 */         String prop = evt.getPropertyName();
/* 46:46 */         if ("SelectedFileChangedProperty".equals(prop)) {
/* 47:47 */           File file = (File)evt.getNewValue();
/* 48:48 */           controlValueChanged(file);
/* 49:   */         }
/* 50:   */       }
/* 51:51 */     });
/* 52:52 */     return component;
/* 53:   */   }
/* 54:   */   
/* 55:   */   protected void readOnlyChanged() {
/* 56:56 */     component.setEnabled((isEnabled()) && (!isReadOnly()));
/* 57:   */   }
/* 58:   */   
/* 59:   */   protected void enabledChanged() {
/* 60:60 */     component.setEnabled((isEnabled()) && (!isReadOnly()));
/* 61:   */   }
/* 62:   */   
/* 63:   */   protected void valueModelChanged(Object newValue) {
/* 64:64 */     component.setSelectedFile((File)newValue);
/* 65:   */   }
/* 66:   */ }
