/*  1:   */ package com.l2fprod.common.springrcp;
/*  2:   */ 
/*  3:   */ import org.springframework.richclient.command.ActionCommand;
/*  4:   */ import org.springframework.richclient.command.CommandGroup;
/*  5:   */ import org.springframework.richclient.command.CommandGroupFactoryBean;
/*  6:   */ import org.springframework.richclient.command.CommandRegistry;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ public class JTaskPaneGroupFactoryBean
/* 25:   */   extends CommandGroupFactoryBean
/* 26:   */ {
/* 27:   */   private String groupId;
/* 28:   */   private Object[] encodedMembers;
/* 29:29 */   private boolean expanded = true;
/* 30:30 */   private boolean special = false;
/* 31:31 */   private boolean scrollOnExpand = false;
/* 32:32 */   private boolean animated = true;
/* 33:   */   private CommandRegistry registry;
/* 34:   */   
/* 35:   */   public void setBeanName(String beanName)
/* 36:   */   {
/* 37:37 */     groupId = beanName;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setMembers(Object[] members) {
/* 41:41 */     encodedMembers = members;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void setExpanded(boolean expanded) {
/* 45:45 */     this.expanded = expanded;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setAnimated(boolean animated) {
/* 49:49 */     this.animated = animated;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void setScrollOnExpand(boolean scrollOnExpand) {
/* 53:53 */     this.scrollOnExpand = scrollOnExpand;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void setSpecial(boolean special) {
/* 57:57 */     this.special = special;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void setCommandRegistry(CommandRegistry registry) {
/* 61:61 */     this.registry = registry;
/* 62:   */   }
/* 63:   */   
/* 64:   */   protected CommandGroup createCommandGroup() {
/* 65:65 */     JTaskPaneGroupCommandGroup group = new JTaskPaneGroupCommandGroup(groupId, registry);
/* 66:   */     
/* 67:67 */     group.setExpanded(expanded);
/* 68:68 */     group.setAnimated(animated);
/* 69:69 */     group.setScrollOnExpand(scrollOnExpand);
/* 70:70 */     group.setSpecial(special);
/* 71:71 */     if (encodedMembers != null) {
/* 72:72 */       for (int i = 0; i < encodedMembers.length; i++) {
/* 73:73 */         String actionName = (String)encodedMembers[i];
/* 74:74 */         ActionCommand childAction = registry.getActionCommand(actionName);
/* 75:75 */         group.addActionCommand(childAction);
/* 76:   */       }
/* 77:   */     }
/* 78:78 */     return group;
/* 79:   */   }
/* 80:   */ }
