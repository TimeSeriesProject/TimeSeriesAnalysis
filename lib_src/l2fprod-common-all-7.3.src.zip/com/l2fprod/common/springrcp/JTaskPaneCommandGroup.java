/*  1:   */ package com.l2fprod.common.springrcp;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JTaskPane;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ import java.util.Iterator;
/*  6:   */ import java.util.List;
/*  7:   */ import org.springframework.richclient.command.CommandGroup;
/*  8:   */ import org.springframework.richclient.command.CommandRegistry;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class JTaskPaneCommandGroup
/* 29:   */   extends CommandGroup
/* 30:   */ {
/* 31:31 */   private List groups = new ArrayList();
/* 32:   */   
/* 33:   */   public JTaskPaneCommandGroup(String groupId, CommandRegistry registry) {
/* 34:34 */     super(groupId, registry);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public JTaskPane createTaskPane() {
/* 38:38 */     JTaskPane taskPane = new JTaskPane();
/* 39:39 */     for (Iterator it = groups.iterator(); it.hasNext();) {
/* 40:40 */       JTaskPaneGroupCommandGroup member = (JTaskPaneGroupCommandGroup)it.next();
/* 41:41 */       taskPane.add(member.createTaskPaneGroup());
/* 42:   */     }
/* 43:43 */     return taskPane;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void addTaskPaneGroup(JTaskPaneGroupCommandGroup childGroup) {
/* 47:47 */     super.add(childGroup);
/* 48:48 */     groups.add(childGroup);
/* 49:   */   }
/* 50:   */ }
