package com.l2fprod.common.beans;

import java.beans.BeanInfo;

public abstract interface BeanInfoResolver
{
  public abstract BeanInfo getBeanInfo(Object paramObject);
  
  public abstract BeanInfo getBeanInfo(Class paramClass);
}
