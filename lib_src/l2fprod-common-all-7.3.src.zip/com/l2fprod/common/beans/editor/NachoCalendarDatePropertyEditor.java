/*   1:    */ package com.l2fprod.common.beans.editor;
/*   2:    */ 
/*   3:    */ import java.text.SimpleDateFormat;
/*   4:    */ import java.util.Date;
/*   5:    */ import java.util.Locale;
/*   6:    */ import net.sf.nachocalendar.CalendarFactory;
/*   7:    */ import net.sf.nachocalendar.components.DateField;
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public class NachoCalendarDatePropertyEditor
/*  33:    */   extends AbstractPropertyEditor
/*  34:    */ {
/*  35:    */   private String dateFormatString;
/*  36:    */   
/*  37:    */   public NachoCalendarDatePropertyEditor()
/*  38:    */   {
/*  39: 39 */     editor = CalendarFactory.createDateField();
/*  40: 40 */     ((DateField)editor).setValue(new Date());
/*  41:    */   }
/*  42:    */   
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */   public NachoCalendarDatePropertyEditor(String dateFormatString, Locale locale)
/*  51:    */   {
/*  52: 52 */     editor = CalendarFactory.createDateField();
/*  53: 53 */     ((DateField)editor).setValue(new Date());
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */   public NachoCalendarDatePropertyEditor(Locale locale)
/*  61:    */   {
/*  62: 62 */     editor = CalendarFactory.createDateField();
/*  63: 63 */     ((DateField)editor).setValue(new Date());
/*  64: 64 */     ((DateField)editor).setLocale(locale);
/*  65:    */   }
/*  66:    */   
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */   public Object getValue()
/*  73:    */   {
/*  74: 74 */     return ((DateField)editor).getValue();
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */   public void setValue(Object value)
/*  82:    */   {
/*  83: 83 */     if (value != null) {
/*  84: 84 */       ((DateField)editor).setValue(value);
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   public String getAsText()
/*  93:    */   {
/*  94: 94 */     Date date = (Date)getValue();
/*  95: 95 */     SimpleDateFormat formatter = new SimpleDateFormat(getDateFormatString());
/*  96:    */     
/*  97: 97 */     String s = formatter.format(date);
/*  98: 98 */     return s;
/*  99:    */   }
/* 100:    */   
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */   public void setDateFormatString(String dateFormatString)
/* 108:    */   {
/* 109:109 */     this.dateFormatString = dateFormatString;
/* 110:    */   }
/* 111:    */   
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */   public String getDateFormatString()
/* 117:    */   {
/* 118:118 */     return dateFormatString;
/* 119:    */   }
/* 120:    */   
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */   public void setLocale(Locale l)
/* 126:    */   {
/* 127:127 */     ((DateField)editor).setLocale(l);
/* 128:    */   }
/* 129:    */   
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */   public Locale getLocale()
/* 135:    */   {
/* 136:136 */     return ((DateField)editor).getLocale();
/* 137:    */   }
/* 138:    */ }
