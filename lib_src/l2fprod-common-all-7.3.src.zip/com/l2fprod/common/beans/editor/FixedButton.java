/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.util.OS;
/*  4:   */ import java.awt.Dimension;
/*  5:   */ import java.awt.Insets;
/*  6:   */ import javax.swing.JButton;
/*  7:   */ import javax.swing.LookAndFeel;
/*  8:   */ import javax.swing.UIManager;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ public final class FixedButton
/* 32:   */   extends JButton
/* 33:   */ {
/* 34:   */   public FixedButton()
/* 35:   */   {
/* 36:36 */     super("...");
/* 37:   */     
/* 38:38 */     if ((OS.isMacOSX()) && (UIManager.getLookAndFeel().isNativeLookAndFeel())) {
/* 39:39 */       setPreferredSize(new Dimension(16, 30));
/* 40:   */     }
/* 41:   */     
/* 42:42 */     setMargin(new Insets(0, 0, 0, 0));
/* 43:   */   }
/* 44:   */ }
