/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*  4:   */ import javax.swing.JTextField;
/*  5:   */ import javax.swing.text.JTextComponent;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class StringPropertyEditor
/* 28:   */   extends AbstractPropertyEditor
/* 29:   */ {
/* 30:   */   public StringPropertyEditor()
/* 31:   */   {
/* 32:32 */     editor = new JTextField();
/* 33:33 */     ((JTextField)editor).setBorder(LookAndFeelTweaks.EMPTY_BORDER);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Object getValue() {
/* 37:37 */     return ((JTextComponent)editor).getText();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setValue(Object value) {
/* 41:41 */     if (value == null) {
/* 42:42 */       ((JTextComponent)editor).setText("");
/* 43:   */     } else {
/* 44:44 */       ((JTextComponent)editor).setText(String.valueOf(value));
/* 45:   */     }
/* 46:   */   }
/* 47:   */ }
