/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*  4:   */ import com.l2fprod.common.util.converter.ConverterRegistry;
/*  5:   */ import javax.swing.JTextField;
/*  6:   */ import javax.swing.text.JTextComponent;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public abstract class StringConverterPropertyEditor
/* 29:   */   extends AbstractPropertyEditor
/* 30:   */ {
/* 31:   */   private Object oldValue;
/* 32:   */   
/* 33:   */   public StringConverterPropertyEditor()
/* 34:   */   {
/* 35:35 */     editor = new JTextField();
/* 36:36 */     ((JTextField)editor).setBorder(LookAndFeelTweaks.EMPTY_BORDER);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public Object getValue() {
/* 40:40 */     String text = ((JTextComponent)editor).getText();
/* 41:41 */     if ((text == null) || (text.trim().length() == 0)) {
/* 42:42 */       return null;
/* 43:   */     }
/* 44:   */     try {
/* 45:45 */       return convertFromString(text.trim());
/* 46:   */     }
/* 47:   */     catch (Exception e) {}
/* 48:48 */     return oldValue;
/* 49:   */   }
/* 50:   */   
/* 51:   */ 
/* 52:   */   public void setValue(Object value)
/* 53:   */   {
/* 54:54 */     if (value == null) {
/* 55:55 */       ((JTextComponent)editor).setText("");
/* 56:   */     } else {
/* 57:57 */       oldValue = value;
/* 58:58 */       ((JTextComponent)editor).setText(convertToString(value));
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   protected abstract Object convertFromString(String paramString);
/* 63:   */   
/* 64:   */   protected String convertToString(Object value) {
/* 65:65 */     return (String)ConverterRegistry.instance().convert(String.class, value);
/* 66:   */   }
/* 67:   */ }
