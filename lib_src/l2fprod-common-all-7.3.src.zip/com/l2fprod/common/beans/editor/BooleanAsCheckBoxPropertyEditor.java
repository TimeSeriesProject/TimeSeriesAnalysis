/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import java.awt.event.ActionListener;
/*  5:   */ import javax.swing.JCheckBox;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class BooleanAsCheckBoxPropertyEditor
/* 28:   */   extends AbstractPropertyEditor
/* 29:   */ {
/* 30:   */   public BooleanAsCheckBoxPropertyEditor()
/* 31:   */   {
/* 32:32 */     editor = new JCheckBox();
/* 33:33 */     ((JCheckBox)editor).setOpaque(false);
/* 34:34 */     ((JCheckBox)editor).addActionListener(new ActionListener() {
/* 35:   */       public void actionPerformed(ActionEvent e) {
/* 36:36 */         firePropertyChange(((JCheckBox)editor).isSelected() ? Boolean.FALSE : Boolean.TRUE, ((JCheckBox)editor).isSelected() ? Boolean.TRUE : Boolean.FALSE);
/* 37:   */         
/* 38:   */ 
/* 39:39 */         ((JCheckBox)editor).transferFocus();
/* 40:   */       }
/* 41:   */     });
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Object getValue() {
/* 45:45 */     return ((JCheckBox)editor).isSelected() ? Boolean.TRUE : Boolean.FALSE;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setValue(Object value) {
/* 49:49 */     ((JCheckBox)editor).setSelected(Boolean.TRUE.equals(value));
/* 50:   */   }
/* 51:   */ }
