/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ public class ShortPropertyEditor
/* 23:   */   extends NumberPropertyEditor
/* 24:   */ {
/* 25:   */   public ShortPropertyEditor()
/* 26:   */   {
/* 27:27 */     super(Short.class);
/* 28:   */   }
/* 29:   */ }
