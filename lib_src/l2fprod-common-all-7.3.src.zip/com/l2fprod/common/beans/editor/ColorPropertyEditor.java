/*   1:    */ package com.l2fprod.common.beans.editor;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.ComponentFactory;
/*   4:    */ import com.l2fprod.common.swing.ComponentFactory.Helper;
/*   5:    */ import com.l2fprod.common.swing.PercentLayout;
/*   6:    */ import com.l2fprod.common.swing.renderer.ColorCellRenderer;
/*   7:    */ import com.l2fprod.common.util.ResourceManager;
/*   8:    */ import java.awt.Color;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import java.awt.event.ActionListener;
/*  11:    */ import javax.swing.JButton;
/*  12:    */ import javax.swing.JColorChooser;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ public class ColorPropertyEditor
/*  36:    */   extends AbstractPropertyEditor
/*  37:    */ {
/*  38:    */   private ColorCellRenderer label;
/*  39:    */   private JButton button;
/*  40:    */   private Color color;
/*  41:    */   
/*  42:    */   public ColorPropertyEditor()
/*  43:    */   {
/*  44: 44 */     editor = new JPanel(new PercentLayout(0, 0));
/*  45: 45 */     ((JPanel)editor).add("*", this.label = new ColorCellRenderer());
/*  46: 46 */     label.setOpaque(false);
/*  47: 47 */     ((JPanel)editor).add(this.button = ComponentFactory.Helper.getFactory().createMiniButton());
/*  48:    */     
/*  49: 49 */     button.addActionListener(new ActionListener() {
/*  50:    */       public void actionPerformed(ActionEvent e) {
/*  51: 51 */         selectColor();
/*  52:    */       }
/*  53: 53 */     });
/*  54: 54 */     ((JPanel)editor).add(this.button = ComponentFactory.Helper.getFactory().createMiniButton());
/*  55:    */     
/*  56: 56 */     button.setText("X");
/*  57: 57 */     button.addActionListener(new ActionListener() {
/*  58:    */       public void actionPerformed(ActionEvent e) {
/*  59: 59 */         selectNull();
/*  60:    */       }
/*  61: 61 */     });
/*  62: 62 */     ((JPanel)editor).setOpaque(false);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Object getValue() {
/*  66: 66 */     return color;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setValue(Object value) {
/*  70: 70 */     color = ((Color)value);
/*  71: 71 */     label.setValue(color);
/*  72:    */   }
/*  73:    */   
/*  74:    */   protected void selectColor() {
/*  75: 75 */     ResourceManager rm = ResourceManager.all(FilePropertyEditor.class);
/*  76: 76 */     String title = rm.getString("ColorPropertyEditor.title");
/*  77: 77 */     Color selectedColor = JColorChooser.showDialog(editor, title, color);
/*  78:    */     
/*  79: 79 */     if (selectedColor != null) {
/*  80: 80 */       Color oldColor = color;
/*  81: 81 */       Color newColor = selectedColor;
/*  82: 82 */       label.setValue(newColor);
/*  83: 83 */       color = newColor;
/*  84: 84 */       firePropertyChange(oldColor, newColor);
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected void selectNull() {
/*  89: 89 */     Color oldColor = color;
/*  90: 90 */     label.setValue(null);
/*  91: 91 */     color = null;
/*  92: 92 */     firePropertyChange(oldColor, null);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static class AsInt extends ColorPropertyEditor {
/*  96:    */     public void setValue(Object arg0) {
/*  97: 97 */       if ((arg0 instanceof Integer)) {
/*  98: 98 */         super.setValue(new Color(((Integer)arg0).intValue()));
/*  99:    */       } else {
/* 100:100 */         super.setValue(arg0);
/* 101:    */       }
/* 102:    */     }
/* 103:    */     
/* 104:    */     public Object getValue() {
/* 105:105 */       Object value = super.getValue();
/* 106:106 */       if (value == null) {
/* 107:107 */         return null;
/* 108:    */       }
/* 109:109 */       return new Integer(((Color)value).getRGB());
/* 110:    */     }
/* 111:    */     
/* 112:    */     protected void firePropertyChange(Object oldValue, Object newValue)
/* 113:    */     {
/* 114:114 */       if ((oldValue instanceof Color)) {
/* 115:115 */         oldValue = new Integer(((Color)oldValue).getRGB());
/* 116:    */       }
/* 117:117 */       if ((newValue instanceof Color)) {
/* 118:118 */         newValue = new Integer(((Color)newValue).getRGB());
/* 119:    */       }
/* 120:120 */       super.firePropertyChange(oldValue, newValue);
/* 121:    */     }
/* 122:    */   }
/* 123:    */ }
