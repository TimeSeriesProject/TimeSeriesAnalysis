/*   1:    */ package com.l2fprod.common.beans.editor;
/*   2:    */ 
/*   3:    */ import com.toedter.calendar.JDateChooser;
/*   4:    */ import java.text.SimpleDateFormat;
/*   5:    */ import java.util.Date;
/*   6:    */ import java.util.Locale;
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ public class JCalendarDatePropertyEditor
/*  32:    */   extends AbstractPropertyEditor
/*  33:    */ {
/*  34:    */   public JCalendarDatePropertyEditor()
/*  35:    */   {
/*  36: 36 */     editor = new JDateChooser();
/*  37:    */   }
/*  38:    */   
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */   public JCalendarDatePropertyEditor(String dateFormatString, Locale locale)
/*  47:    */   {
/*  48: 48 */     editor = new JDateChooser();
/*  49: 49 */     ((JDateChooser)editor).setDateFormatString(dateFormatString);
/*  50: 50 */     ((JDateChooser)editor).setLocale(locale);
/*  51:    */   }
/*  52:    */   
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */   public JCalendarDatePropertyEditor(Locale locale)
/*  58:    */   {
/*  59: 59 */     editor = new JDateChooser();
/*  60: 60 */     ((JDateChooser)editor).setLocale(locale);
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */   public Object getValue()
/*  69:    */   {
/*  70: 70 */     return ((JDateChooser)editor).getDate();
/*  71:    */   }
/*  72:    */   
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */   public void setValue(Object value)
/*  78:    */   {
/*  79: 79 */     if (value != null) {
/*  80: 80 */       ((JDateChooser)editor).setDate((Date)value);
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   public String getAsText()
/*  89:    */   {
/*  90: 90 */     Date date = (Date)getValue();
/*  91: 91 */     SimpleDateFormat formatter = new SimpleDateFormat(getDateFormatString());
/*  92:    */     
/*  93: 93 */     String s = formatter.format(date);
/*  94: 94 */     return s;
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */   public void setDateFormatString(String dateFormatString)
/* 104:    */   {
/* 105:105 */     ((JDateChooser)editor).setDateFormatString(dateFormatString);
/* 106:    */   }
/* 107:    */   
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */   public String getDateFormatString()
/* 113:    */   {
/* 114:114 */     return ((JDateChooser)editor).getDateFormatString();
/* 115:    */   }
/* 116:    */   
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */   public void setLocale(Locale l)
/* 122:    */   {
/* 123:123 */     ((JDateChooser)editor).setLocale(l);
/* 124:    */   }
/* 125:    */   
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */   public Locale getLocale()
/* 131:    */   {
/* 132:132 */     return ((JDateChooser)editor).getLocale();
/* 133:    */   }
/* 134:    */ }
