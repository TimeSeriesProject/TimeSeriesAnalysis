/*   1:    */ package com.l2fprod.common.beans.editor;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.event.KeyAdapter;
/*   5:    */ import java.awt.event.KeyEvent;
/*   6:    */ import javax.swing.ComboBoxModel;
/*   7:    */ import javax.swing.DefaultComboBoxModel;
/*   8:    */ import javax.swing.DefaultListCellRenderer;
/*   9:    */ import javax.swing.Icon;
/*  10:    */ import javax.swing.JComboBox;
/*  11:    */ import javax.swing.JLabel;
/*  12:    */ import javax.swing.JList;
/*  13:    */ import javax.swing.event.PopupMenuEvent;
/*  14:    */ import javax.swing.event.PopupMenuListener;
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ public class ComboBoxPropertyEditor
/*  36:    */   extends AbstractPropertyEditor
/*  37:    */ {
/*  38:    */   private Object oldValue;
/*  39:    */   private Icon[] icons;
/*  40:    */   
/*  41:    */   public ComboBoxPropertyEditor()
/*  42:    */   {
/*  43: 43 */     editor = new JComboBox() {
/*  44:    */       public void setSelectedItem(Object anObject) {
/*  45: 45 */         oldValue = getSelectedItem();
/*  46: 46 */         super.setSelectedItem(anObject);
/*  47:    */       }
/*  48:    */       
/*  49: 49 */     };
/*  50: 50 */     JComboBox combo = (JComboBox)editor;
/*  51:    */     
/*  52: 52 */     combo.setRenderer(new Renderer());
/*  53: 53 */     combo.addPopupMenuListener(new PopupMenuListener() {
/*  54:    */       public void popupMenuCanceled(PopupMenuEvent e) {}
/*  55:    */       
/*  56: 56 */       public void popupMenuWillBecomeInvisible(PopupMenuEvent e) { firePropertyChange(oldValue, val$combo.getSelectedItem()); }
/*  57:    */       
/*  58:    */       private final JComboBox val$combo;
/*  59:    */       public void popupMenuWillBecomeVisible(PopupMenuEvent e) {}
/*  60: 60 */     });
/*  61: 61 */     combo.addKeyListener(new KeyAdapter() { private final JComboBox val$combo;
/*  62:    */       
/*  63: 63 */       public void keyPressed(KeyEvent e) { if (e.getKeyCode() == 10) {
/*  64: 64 */           firePropertyChange(oldValue, val$combo.getSelectedItem());
/*  65:    */         }
/*  66:    */         
/*  67:    */       }
/*  68: 68 */     });
/*  69: 69 */     combo.setSelectedIndex(-1);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Object getValue() {
/*  73: 73 */     Object selected = ((JComboBox)editor).getSelectedItem();
/*  74: 74 */     if ((selected instanceof Value)) {
/*  75: 75 */       return value;
/*  76:    */     }
/*  77: 77 */     return selected;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setValue(Object value)
/*  81:    */   {
/*  82: 82 */     JComboBox combo = (JComboBox)editor;
/*  83: 83 */     Object current = null;
/*  84: 84 */     int index = -1;
/*  85: 85 */     int i = 0; for (int c = combo.getModel().getSize(); i < c; i++) {
/*  86: 86 */       current = combo.getModel().getElementAt(i);
/*  87: 87 */       if ((value == current) || ((current != null) && (current.equals(value)))) {
/*  88: 88 */         index = i;
/*  89: 89 */         break;
/*  90:    */       }
/*  91:    */     }
/*  92: 92 */     ((JComboBox)editor).setSelectedIndex(index);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setAvailableValues(Object[] values) {
/*  96: 96 */     ((JComboBox)editor).setModel(new DefaultComboBoxModel(values));
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setAvailableIcons(Icon[] icons) {
/* 100:100 */     this.icons = icons;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public class Renderer
/* 104:    */     extends DefaultListCellRenderer
/* 105:    */   {
/* 106:    */     public Renderer() {}
/* 107:    */     
/* 108:    */     public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 109:    */     {
/* 110:110 */       Component component = super.getListCellRendererComponent(list, (value instanceof ComboBoxPropertyEditor.Value) ? visualValue : value, index, isSelected, cellHasFocus);
/* 111:    */       
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:116 */       if ((icons != null) && (index >= 0) && ((component instanceof JLabel)))
/* 117:117 */         ((JLabel)component).setIcon(icons[index]);
/* 118:118 */       return component;
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static final class Value {
/* 123:    */     private Object value;
/* 124:    */     private Object visualValue;
/* 125:    */     
/* 126:126 */     public Value(Object value, Object visualValue) { this.value = value;
/* 127:127 */       this.visualValue = visualValue;
/* 128:    */     }
/* 129:    */     
/* 130:130 */     public boolean equals(Object o) { if (o == this)
/* 131:131 */         return true;
/* 132:132 */       if ((value == o) || ((value != null) && (value.equals(o))))
/* 133:133 */         return true;
/* 134:134 */       return false;
/* 135:    */     }
/* 136:    */     
/* 137:137 */     public int hashCode() { return value == null ? 0 : value.hashCode(); }
/* 138:    */   }
/* 139:    */ }
