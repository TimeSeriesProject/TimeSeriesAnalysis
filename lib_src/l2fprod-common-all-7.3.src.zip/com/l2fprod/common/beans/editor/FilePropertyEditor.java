/*   1:    */ package com.l2fprod.common.beans.editor;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.ComponentFactory;
/*   4:    */ import com.l2fprod.common.swing.ComponentFactory.Helper;
/*   5:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   6:    */ import com.l2fprod.common.swing.PercentLayout;
/*   7:    */ import com.l2fprod.common.swing.UserPreferences;
/*   8:    */ import com.l2fprod.common.util.ResourceManager;
/*   9:    */ import java.awt.LayoutManager;
/*  10:    */ import java.awt.datatransfer.DataFlavor;
/*  11:    */ import java.awt.datatransfer.Transferable;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.event.ActionListener;
/*  14:    */ import java.io.File;
/*  15:    */ import java.util.List;
/*  16:    */ import javax.swing.JButton;
/*  17:    */ import javax.swing.JComponent;
/*  18:    */ import javax.swing.JFileChooser;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.JTextField;
/*  21:    */ import javax.swing.TransferHandler;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ public class FilePropertyEditor
/*  43:    */   extends AbstractPropertyEditor
/*  44:    */ {
/*  45:    */   protected JTextField textfield;
/*  46:    */   private JButton button;
/*  47:    */   private JButton cancelButton;
/*  48:    */   
/*  49:    */   public FilePropertyEditor()
/*  50:    */   {
/*  51: 51 */     this(true);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public FilePropertyEditor(boolean asTableEditor) {
/*  55: 55 */     editor = new JPanel(new PercentLayout(0, 0)) {
/*  56:    */       public void setEnabled(boolean enabled) {
/*  57: 57 */         super.setEnabled(enabled);
/*  58: 58 */         textfield.setEnabled(enabled);
/*  59: 59 */         button.setEnabled(enabled);
/*  60: 60 */         cancelButton.setEnabled(enabled);
/*  61:    */       }
/*  62: 62 */     };
/*  63: 63 */     ((JPanel)editor).add("*", this.textfield = new JTextField());
/*  64: 64 */     ((JPanel)editor).add(this.button = ComponentFactory.Helper.getFactory().createMiniButton());
/*  65:    */     
/*  66: 66 */     if (asTableEditor) {
/*  67: 67 */       textfield.setBorder(LookAndFeelTweaks.EMPTY_BORDER);
/*  68:    */     }
/*  69: 69 */     button.addActionListener(new ActionListener() {
/*  70:    */       public void actionPerformed(ActionEvent e) {
/*  71: 71 */         selectFile();
/*  72:    */       }
/*  73: 73 */     });
/*  74: 74 */     ((JPanel)editor).add(this.cancelButton = ComponentFactory.Helper.getFactory().createMiniButton());
/*  75:    */     
/*  76: 76 */     cancelButton.setText("X");
/*  77: 77 */     cancelButton.addActionListener(new ActionListener() {
/*  78:    */       public void actionPerformed(ActionEvent e) {
/*  79: 79 */         selectNull();
/*  80:    */       }
/*  81: 81 */     });
/*  82: 82 */     textfield.setTransferHandler(new FileTransferHandler());
/*  83:    */   }
/*  84:    */   
/*  85:    */   class FileTransferHandler extends TransferHandler { FileTransferHandler() {}
/*  86:    */     
/*  87: 87 */     public boolean canImport(JComponent comp, DataFlavor[] transferFlavors) { int i = 0; for (int c = transferFlavors.length; i < c; i++) {
/*  88: 88 */         if (transferFlavors[i].equals(DataFlavor.javaFileListFlavor)) {
/*  89: 89 */           return true;
/*  90:    */         }
/*  91:    */       }
/*  92: 92 */       return false;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public boolean importData(JComponent comp, Transferable t) {
/*  96: 96 */       try { List list = (List)t.getTransferData(DataFlavor.javaFileListFlavor);
/*  97: 97 */         if (list.size() > 0) {
/*  98: 98 */           File oldFile = (File)getValue();
/*  99: 99 */           File newFile = (File)list.get(0);
/* 100:100 */           String text = newFile.getAbsolutePath();
/* 101:101 */           textfield.setText(text);
/* 102:102 */           firePropertyChange(oldFile, newFile);
/* 103:    */         }
/* 104:    */       } catch (Exception e) {
/* 105:105 */         e.printStackTrace();
/* 106:    */       }
/* 107:107 */       return true;
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   public Object getValue() {
/* 112:112 */     if ("".equals(textfield.getText().trim())) {
/* 113:113 */       return null;
/* 114:    */     }
/* 115:115 */     return new File(textfield.getText());
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void setValue(Object value)
/* 119:    */   {
/* 120:120 */     if ((value instanceof File)) {
/* 121:121 */       textfield.setText(((File)value).getAbsolutePath());
/* 122:    */     } else {
/* 123:123 */       textfield.setText("");
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected void selectFile() {
/* 128:128 */     ResourceManager rm = ResourceManager.all(FilePropertyEditor.class);
/* 129:    */     
/* 130:130 */     JFileChooser chooser = UserPreferences.getDefaultFileChooser();
/* 131:131 */     chooser.setDialogTitle(rm.getString("FilePropertyEditor.dialogTitle"));
/* 132:132 */     chooser.setApproveButtonText(rm.getString("FilePropertyEditor.approveButtonText"));
/* 133:    */     
/* 134:134 */     chooser.setApproveButtonMnemonic(rm.getChar("FilePropertyEditor.approveButtonMnemonic"));
/* 135:    */     
/* 136:136 */     customizeFileChooser(chooser);
/* 137:    */     
/* 138:138 */     if (0 == chooser.showOpenDialog(editor)) {
/* 139:139 */       File oldFile = (File)getValue();
/* 140:140 */       File newFile = chooser.getSelectedFile();
/* 141:141 */       String text = newFile.getAbsolutePath();
/* 142:142 */       textfield.setText(text);
/* 143:143 */       firePropertyChange(oldFile, newFile);
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */   protected void customizeFileChooser(JFileChooser chooser) {}
/* 151:    */   
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */   protected void selectNull()
/* 156:    */   {
/* 157:157 */     Object oldFile = getValue();
/* 158:158 */     textfield.setText("");
/* 159:159 */     firePropertyChange(oldFile, null);
/* 160:    */   }
/* 161:    */ }
