/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.ComponentFactory;
/*  4:   */ import com.l2fprod.common.swing.ComponentFactory.Helper;
/*  5:   */ import com.l2fprod.common.swing.JFontChooser;
/*  6:   */ import com.l2fprod.common.swing.PercentLayout;
/*  7:   */ import com.l2fprod.common.swing.renderer.DefaultCellRenderer;
/*  8:   */ import com.l2fprod.common.util.ResourceManager;
/*  9:   */ import java.awt.Font;
/* 10:   */ import java.awt.event.ActionEvent;
/* 11:   */ import java.awt.event.ActionListener;
/* 12:   */ import javax.swing.JButton;
/* 13:   */ import javax.swing.JPanel;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public class FontPropertyEditor
/* 36:   */   extends AbstractPropertyEditor
/* 37:   */ {
/* 38:   */   private DefaultCellRenderer label;
/* 39:   */   private JButton button;
/* 40:   */   private Font font;
/* 41:   */   
/* 42:   */   public FontPropertyEditor()
/* 43:   */   {
/* 44:44 */     editor = new JPanel(new PercentLayout(0, 0));
/* 45:45 */     ((JPanel)editor).add("*", this.label = new DefaultCellRenderer());
/* 46:46 */     label.setOpaque(false);
/* 47:47 */     ((JPanel)editor).add(this.button = ComponentFactory.Helper.getFactory().createMiniButton());
/* 48:   */     
/* 49:49 */     button.addActionListener(new ActionListener() {
/* 50:   */       public void actionPerformed(ActionEvent e) {
/* 51:51 */         selectFont();
/* 52:   */       }
/* 53:53 */     });
/* 54:54 */     ((JPanel)editor).add(this.button = ComponentFactory.Helper.getFactory().createMiniButton());
/* 55:   */     
/* 56:56 */     button.setText("X");
/* 57:57 */     button.addActionListener(new ActionListener() {
/* 58:   */       public void actionPerformed(ActionEvent e) {
/* 59:59 */         selectNull();
/* 60:   */       }
/* 61:61 */     });
/* 62:62 */     ((JPanel)editor).setOpaque(false);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Object getValue() {
/* 66:66 */     return font;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setValue(Object value) {
/* 70:70 */     font = ((Font)value);
/* 71:71 */     label.setValue(value);
/* 72:   */   }
/* 73:   */   
/* 74:   */   protected void selectFont() {
/* 75:75 */     ResourceManager rm = ResourceManager.all(FontPropertyEditor.class);
/* 76:76 */     String title = rm.getString("FontPropertyEditor.title");
/* 77:   */     
/* 78:78 */     Font selectedFont = JFontChooser.showDialog(editor, title, font);
/* 79:   */     
/* 80:80 */     if (selectedFont != null) {
/* 81:81 */       Font oldFont = font;
/* 82:82 */       Font newFont = selectedFont;
/* 83:83 */       label.setValue(newFont);
/* 84:84 */       font = newFont;
/* 85:85 */       firePropertyChange(oldFont, newFont);
/* 86:   */     }
/* 87:   */   }
/* 88:   */   
/* 89:   */   protected void selectNull() {
/* 90:90 */     Object oldFont = font;
/* 91:91 */     label.setValue(null);
/* 92:92 */     font = null;
/* 93:93 */     firePropertyChange(oldFont, null);
/* 94:   */   }
/* 95:   */ }
