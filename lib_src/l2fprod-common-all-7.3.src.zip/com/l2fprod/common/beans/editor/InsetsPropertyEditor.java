/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.util.converter.ConverterRegistry;
/*  4:   */ import java.awt.Insets;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public class InsetsPropertyEditor
/* 27:   */   extends StringConverterPropertyEditor
/* 28:   */ {
/* 29:   */   protected Object convertFromString(String text)
/* 30:   */   {
/* 31:31 */     return ConverterRegistry.instance().convert(Insets.class, text);
/* 32:   */   }
/* 33:   */ }
