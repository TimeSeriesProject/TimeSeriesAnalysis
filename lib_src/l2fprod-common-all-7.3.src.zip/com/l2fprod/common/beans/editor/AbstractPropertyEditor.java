/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import java.awt.Rectangle;
/*  6:   */ import java.beans.PropertyChangeListener;
/*  7:   */ import java.beans.PropertyChangeSupport;
/*  8:   */ import java.beans.PropertyEditor;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ public class AbstractPropertyEditor
/* 31:   */   implements PropertyEditor
/* 32:   */ {
/* 33:   */   protected Component editor;
/* 34:34 */   private PropertyChangeSupport listeners = new PropertyChangeSupport(this);
/* 35:   */   
/* 36:   */   public boolean isPaintable() {
/* 37:37 */     return false;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public boolean supportsCustomEditor() {
/* 41:41 */     return false;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Component getCustomEditor() {
/* 45:45 */     return editor;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 49:49 */     listeners.addPropertyChangeListener(listener);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 53:53 */     listeners.removePropertyChangeListener(listener);
/* 54:   */   }
/* 55:   */   
/* 56:   */   protected void firePropertyChange(Object oldValue, Object newValue) {
/* 57:57 */     listeners.firePropertyChange("value", oldValue, newValue);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public Object getValue() {
/* 61:61 */     return null;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void setValue(Object value) {}
/* 65:   */   
/* 66:   */   public String getAsText()
/* 67:   */   {
/* 68:68 */     return null;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public String getJavaInitializationString() {
/* 72:72 */     return null;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public String[] getTags() {
/* 76:76 */     return null;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setAsText(String text)
/* 80:   */     throws IllegalArgumentException
/* 81:   */   {}
/* 82:   */   
/* 83:   */   public void paintValue(Graphics gfx, Rectangle box) {}
/* 84:   */ }
