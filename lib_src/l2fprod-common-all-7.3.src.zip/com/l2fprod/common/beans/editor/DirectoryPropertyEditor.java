/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.UserPreferences;
/*  4:   */ import com.l2fprod.common.util.ResourceManager;
/*  5:   */ import java.io.File;
/*  6:   */ import java.io.IOException;
/*  7:   */ import javax.swing.JFileChooser;
/*  8:   */ import javax.swing.JTextField;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ public class DirectoryPropertyEditor
/* 32:   */   extends FilePropertyEditor
/* 33:   */ {
/* 34:   */   protected void selectFile()
/* 35:   */   {
/* 36:36 */     ResourceManager rm = ResourceManager.all(FilePropertyEditor.class);
/* 37:   */     
/* 38:38 */     JFileChooser chooser = UserPreferences.getDefaultDirectoryChooser();
/* 39:   */     
/* 40:40 */     chooser.setDialogTitle(rm.getString("DirectoryPropertyEditor.dialogTitle"));
/* 41:41 */     chooser.setApproveButtonText(rm.getString("DirectoryPropertyEditor.approveButtonText"));
/* 42:   */     
/* 43:43 */     chooser.setApproveButtonMnemonic(rm.getChar("DirectoryPropertyEditor.approveButtonMnemonic"));
/* 44:   */     
/* 45:   */ 
/* 46:46 */     File oldFile = (File)getValue();
/* 47:47 */     if ((oldFile != null) && (oldFile.isDirectory())) {
/* 48:   */       try {
/* 49:49 */         chooser.setCurrentDirectory(oldFile.getCanonicalFile());
/* 50:   */       } catch (IOException e) {
/* 51:51 */         e.printStackTrace();
/* 52:   */       }
/* 53:   */     }
/* 54:   */     
/* 55:55 */     if (0 == chooser.showOpenDialog(editor)) {
/* 56:56 */       File newFile = chooser.getSelectedFile();
/* 57:57 */       String text = newFile.getAbsolutePath();
/* 58:58 */       textfield.setText(text);
/* 59:59 */       firePropertyChange(oldFile, newFile);
/* 60:   */     }
/* 61:   */   }
/* 62:   */ }
