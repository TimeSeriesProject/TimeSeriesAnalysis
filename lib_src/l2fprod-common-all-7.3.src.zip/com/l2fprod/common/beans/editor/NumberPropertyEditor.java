/*   1:    */ package com.l2fprod.common.beans.editor;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   4:    */ import com.l2fprod.common.util.converter.ConverterRegistry;
/*   5:    */ import com.l2fprod.common.util.converter.NumberConverters;
/*   6:    */ import java.lang.reflect.Constructor;
/*   7:    */ import java.text.NumberFormat;
/*   8:    */ import javax.swing.JFormattedTextField;
/*   9:    */ import javax.swing.JTextField;
/*  10:    */ import javax.swing.LookAndFeel;
/*  11:    */ import javax.swing.UIManager;
/*  12:    */ import javax.swing.text.DefaultFormatterFactory;
/*  13:    */ import javax.swing.text.NumberFormatter;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ public class NumberPropertyEditor
/*  34:    */   extends AbstractPropertyEditor
/*  35:    */ {
/*  36:    */   private final Class type;
/*  37:    */   private Object lastGoodValue;
/*  38:    */   
/*  39:    */   public NumberPropertyEditor(Class type)
/*  40:    */   {
/*  41: 41 */     if (!Number.class.isAssignableFrom(type)) {
/*  42: 42 */       throw new IllegalArgumentException("type must be a subclass of Number");
/*  43:    */     }
/*  44:    */     
/*  45: 45 */     editor = new JFormattedTextField();
/*  46: 46 */     this.type = type;
/*  47: 47 */     ((JFormattedTextField)editor).setValue(getDefaultValue());
/*  48: 48 */     ((JFormattedTextField)editor).setBorder(LookAndFeelTweaks.EMPTY_BORDER);
/*  49:    */     
/*  50:    */ 
/*  51: 51 */     NumberFormat format = NumberConverters.getDefaultFormat();
/*  52:    */     
/*  53: 53 */     ((JFormattedTextField)editor).setFormatterFactory(new DefaultFormatterFactory(new NumberFormatter(format)));
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */   public Object getValue()
/*  58:    */   {
/*  59: 59 */     String text = ((JTextField)editor).getText();
/*  60: 60 */     if ((text == null) || (text.trim().length() == 0)) {
/*  61: 61 */       return getDefaultValue();
/*  62:    */     }
/*  63:    */     
/*  64:    */ 
/*  65: 65 */     text = text.replace(',', '.');
/*  66:    */     
/*  67:    */ 
/*  68: 68 */     StringBuffer number = new StringBuffer();
/*  69: 69 */     number.ensureCapacity(text.length());
/*  70: 70 */     int i = 0; for (int c = text.length(); i < c; i++) {
/*  71: 71 */       char character = text.charAt(i);
/*  72: 72 */       if (('.' == character) || ('-' == character) || ((Double.class.equals(type)) && ('E' == character)) || ((Float.class.equals(type)) && ('E' == character)) || (Character.isDigit(character)))
/*  73:    */       {
/*  74:    */ 
/*  75:    */ 
/*  76: 76 */         number.append(character); } else {
/*  77: 77 */         if (' ' != character) {
/*  78:    */           break;
/*  79:    */         }
/*  80:    */       }
/*  81:    */     }
/*  82:    */     
/*  83:    */     try
/*  84:    */     {
/*  85: 85 */       lastGoodValue = ConverterRegistry.instance().convert(type, number.toString());
/*  86:    */     }
/*  87:    */     catch (Exception e) {
/*  88: 88 */       UIManager.getLookAndFeel().provideErrorFeedback(editor);
/*  89:    */     }
/*  90:    */     
/*  91: 91 */     return lastGoodValue;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setValue(Object value) {
/*  95: 95 */     if ((value instanceof Number)) {
/*  96: 96 */       ((JFormattedTextField)editor).setText(value.toString());
/*  97:    */     } else {
/*  98: 98 */       ((JFormattedTextField)editor).setValue(getDefaultValue());
/*  99:    */     }
/* 100:100 */     lastGoodValue = value;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private Object getDefaultValue() {
/* 104:    */     try {
/* 105:105 */       return type.getConstructor(new Class[] { String.class }).newInstance(new Object[] { "0" });
/* 106:    */     }
/* 107:    */     catch (Exception e)
/* 108:    */     {
/* 109:109 */       throw new RuntimeException(e);
/* 110:    */     }
/* 111:    */   }
/* 112:    */ }
