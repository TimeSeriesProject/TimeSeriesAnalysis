/*  1:   */ package com.l2fprod.common.beans.editor;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.util.ResourceManager;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public class BooleanPropertyEditor
/* 26:   */   extends ComboBoxPropertyEditor
/* 27:   */ {
/* 28:   */   public BooleanPropertyEditor()
/* 29:   */   {
/* 30:30 */     Object[] values = { new ComboBoxPropertyEditor.Value(Boolean.TRUE, ResourceManager.common().getString("true")), new ComboBoxPropertyEditor.Value(Boolean.FALSE, ResourceManager.common().getString("false")) };
/* 31:   */     
/* 32:   */ 
/* 33:   */ 
/* 34:34 */     setAvailableValues(values);
/* 35:   */   }
/* 36:   */ }
