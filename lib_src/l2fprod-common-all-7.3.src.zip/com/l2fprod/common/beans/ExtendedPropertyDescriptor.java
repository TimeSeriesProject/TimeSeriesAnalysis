/*   1:    */ package com.l2fprod.common.beans;
/*   2:    */ 
/*   3:    */ import java.beans.IntrospectionException;
/*   4:    */ import java.beans.PropertyDescriptor;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.util.Comparator;
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ public class ExtendedPropertyDescriptor
/*  29:    */   extends PropertyDescriptor
/*  30:    */ {
/*  31: 31 */   private Class tableCellRendererClass = null;
/*  32: 32 */   private String category = "";
/*  33:    */   
/*  34:    */   public ExtendedPropertyDescriptor(String propertyName, Class beanClass) throws IntrospectionException
/*  35:    */   {
/*  36: 36 */     super(propertyName, beanClass);
/*  37:    */   }
/*  38:    */   
/*  39:    */ 
/*  40:    */ 
/*  41:    */   public ExtendedPropertyDescriptor(String propertyName, Method getter, Method setter)
/*  42:    */     throws IntrospectionException
/*  43:    */   {
/*  44: 44 */     super(propertyName, getter, setter);
/*  45:    */   }
/*  46:    */   
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */   public ExtendedPropertyDescriptor(String propertyName, Class beanClass, String getterName, String setterName)
/*  51:    */     throws IntrospectionException
/*  52:    */   {
/*  53: 53 */     super(propertyName, beanClass, getterName, setterName);
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */   public ExtendedPropertyDescriptor setCategory(String category)
/*  62:    */   {
/*  63: 63 */     this.category = category;
/*  64: 64 */     return this;
/*  65:    */   }
/*  66:    */   
/*  67:    */ 
/*  68:    */ 
/*  69:    */   public String getCategory()
/*  70:    */   {
/*  71: 71 */     return category;
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */   public ExtendedPropertyDescriptor setReadOnly()
/*  78:    */   {
/*  79:    */     try
/*  80:    */     {
/*  81: 81 */       setWriteMethod(null);
/*  82:    */     } catch (IntrospectionException e) {
/*  83: 83 */       e.printStackTrace();
/*  84:    */     }
/*  85: 85 */     return this;
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */   public void setPropertyTableRendererClass(Class tableCellRendererClass)
/*  95:    */   {
/*  96: 96 */     this.tableCellRendererClass = tableCellRendererClass;
/*  97:    */   }
/*  98:    */   
/*  99:    */ 
/* 100:    */ 
/* 101:    */   public Class getPropertyTableRendererClass()
/* 102:    */   {
/* 103:103 */     return tableCellRendererClass;
/* 104:    */   }
/* 105:    */   
/* 106:    */ 
/* 107:    */ 
/* 108:    */   public static ExtendedPropertyDescriptor newPropertyDescriptor(String propertyName, Class beanClass)
/* 109:    */     throws IntrospectionException
/* 110:    */   {
/* 111:111 */     Method readMethod = BeanUtils.getReadMethod(beanClass, propertyName);
/* 112:112 */     Method writeMethod = null;
/* 113:    */     
/* 114:114 */     if (readMethod == null) {
/* 115:115 */       throw new IntrospectionException("No getter for property " + propertyName + " in class " + beanClass.getName());
/* 116:    */     }
/* 117:    */     
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:122 */     writeMethod = BeanUtils.getWriteMethod(beanClass, propertyName, readMethod.getReturnType());
/* 123:    */     
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:128 */     return new ExtendedPropertyDescriptor(propertyName, readMethod, writeMethod);
/* 129:    */   }
/* 130:    */   
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:134 */   public static final Comparator BY_CATEGORY_COMPARATOR = new Comparator() {
/* 135:    */     public int compare(Object o1, Object o2) {
/* 136:136 */       PropertyDescriptor desc1 = (PropertyDescriptor)o1;
/* 137:137 */       PropertyDescriptor desc2 = (PropertyDescriptor)o2;
/* 138:    */       
/* 139:139 */       if ((desc1 == null) && (desc2 == null))
/* 140:140 */         return 0;
/* 141:141 */       if ((desc1 != null) && (desc2 == null))
/* 142:142 */         return 1;
/* 143:143 */       if ((desc1 == null) && (desc2 != null)) {
/* 144:144 */         return -1;
/* 145:    */       }
/* 146:146 */       if (((desc1 instanceof ExtendedPropertyDescriptor)) && (!(desc2 instanceof ExtendedPropertyDescriptor)))
/* 147:    */       {
/* 148:148 */         return -1; }
/* 149:149 */       if ((!(desc1 instanceof ExtendedPropertyDescriptor)) && ((desc2 instanceof ExtendedPropertyDescriptor)))
/* 150:    */       {
/* 151:    */ 
/* 152:152 */         return 1; }
/* 153:153 */       if ((!(desc1 instanceof ExtendedPropertyDescriptor)) && (!(desc2 instanceof ExtendedPropertyDescriptor)))
/* 154:    */       {
/* 155:    */ 
/* 156:156 */         return String.CASE_INSENSITIVE_ORDER.compare(desc1.getDisplayName(), desc2.getDisplayName());
/* 157:    */       }
/* 158:    */       
/* 159:    */ 
/* 160:160 */       int category = String.CASE_INSENSITIVE_ORDER.compare(((ExtendedPropertyDescriptor)desc1).getCategory() == null ? "" : ((ExtendedPropertyDescriptor)desc1).getCategory(), ((ExtendedPropertyDescriptor)desc2).getCategory() == null ? "" : ((ExtendedPropertyDescriptor)desc2).getCategory());
/* 161:    */       
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:168 */       if (category == 0) {
/* 169:169 */         return String.CASE_INSENSITIVE_ORDER.compare(desc1.getDisplayName(), desc2.getDisplayName());
/* 170:    */       }
/* 171:    */       
/* 172:    */ 
/* 173:173 */       return category;
/* 174:    */     }
/* 175:    */   };
/* 176:    */ }
