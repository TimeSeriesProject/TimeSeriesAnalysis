/*   1:    */ package com.l2fprod.common.beans;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.util.ResourceManager;
/*   4:    */ import java.awt.Image;
/*   5:    */ import java.beans.BeanDescriptor;
/*   6:    */ import java.beans.IntrospectionException;
/*   7:    */ import java.beans.PropertyDescriptor;
/*   8:    */ import java.beans.SimpleBeanInfo;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.MissingResourceException;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ public class BaseBeanInfo
/*  38:    */   extends SimpleBeanInfo
/*  39:    */ {
/*  40:    */   private Class type;
/*  41:    */   private BeanDescriptor beanDescriptor;
/*  42: 42 */   private List properties = new ArrayList(0);
/*  43:    */   
/*  44:    */   public BaseBeanInfo(Class type) {
/*  45: 45 */     this.type = type;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public final Class getType() {
/*  49: 49 */     return type;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ResourceManager getResources() {
/*  53: 53 */     return ResourceManager.get(getType());
/*  54:    */   }
/*  55:    */   
/*  56:    */   public BeanDescriptor getBeanDescriptor() {
/*  57: 57 */     if (beanDescriptor == null) {
/*  58: 58 */       beanDescriptor = new DefaultBeanDescriptor(this);
/*  59:    */     }
/*  60: 60 */     return beanDescriptor;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public PropertyDescriptor[] getPropertyDescriptors() {
/*  64: 64 */     return (PropertyDescriptor[])properties.toArray(new PropertyDescriptor[0]);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getPropertyDescriptorCount() {
/*  68: 68 */     return properties.size();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public PropertyDescriptor getPropertyDescriptor(int index) {
/*  72: 72 */     return (PropertyDescriptor)properties.get(index);
/*  73:    */   }
/*  74:    */   
/*  75:    */   protected PropertyDescriptor addPropertyDescriptor(PropertyDescriptor property) {
/*  76: 76 */     properties.add(property);
/*  77: 77 */     return property;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public ExtendedPropertyDescriptor addProperty(String propertyName)
/*  81:    */   {
/*  82:    */     try {
/*  83: 83 */       if ((propertyName == null) || (propertyName.trim().length() == 0)) {
/*  84: 84 */         throw new IntrospectionException("bad property name");
/*  85:    */       }
/*  86:    */       
/*  87: 87 */       ExtendedPropertyDescriptor descriptor = ExtendedPropertyDescriptor.newPropertyDescriptor(propertyName, getType());
/*  88:    */       
/*  89:    */       try
/*  90:    */       {
/*  91: 91 */         descriptor.setDisplayName(getResources().getString(propertyName));
/*  92:    */       }
/*  93:    */       catch (MissingResourceException e) {}
/*  94:    */       try
/*  95:    */       {
/*  96: 96 */         descriptor.setShortDescription(getResources().getString(propertyName + ".shortDescription"));
/*  97:    */       }
/*  98:    */       catch (MissingResourceException e) {}
/*  99:    */       
/* 100:    */ 
/* 101:    */ 
/* 102:102 */       addPropertyDescriptor(descriptor);
/* 103:103 */       return descriptor;
/* 104:    */     } catch (IntrospectionException e) {
/* 105:105 */       throw new RuntimeException(e);
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */   public PropertyDescriptor removeProperty(String propertyName)
/* 114:    */   {
/* 115:115 */     if (propertyName == null) {
/* 116:116 */       throw new IllegalArgumentException("Property name can not be null");
/* 117:    */     }
/* 118:118 */     for (Iterator iter = properties.iterator(); iter.hasNext();) {
/* 119:119 */       PropertyDescriptor property = (PropertyDescriptor)iter.next();
/* 120:120 */       if (propertyName.equals(property.getName()))
/* 121:    */       {
/* 122:122 */         iter.remove();
/* 123:123 */         return property;
/* 124:    */       }
/* 125:    */     }
/* 126:126 */     return null;
/* 127:    */   }
/* 128:    */   
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */   public Image getIcon(int kind)
/* 135:    */   {
/* 136:136 */     return null;
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */   public String getText(Object value)
/* 145:    */   {
/* 146:146 */     return value.toString();
/* 147:    */   }
/* 148:    */   
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */   public String getDescription(Object value)
/* 156:    */   {
/* 157:157 */     return getText(value);
/* 158:    */   }
/* 159:    */   
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */   public String getToolTipText(Object value)
/* 167:    */   {
/* 168:168 */     return getText(value);
/* 169:    */   }
/* 170:    */ }
