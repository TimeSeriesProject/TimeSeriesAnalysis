/*  1:   */ package com.l2fprod.common.beans;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.Method;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class BeanUtils
/* 29:   */ {
/* 30:   */   public static Method getReadMethod(Class clazz, String propertyName)
/* 31:   */   {
/* 32:32 */     Method readMethod = null;
/* 33:33 */     String base = capitalize(propertyName);
/* 34:   */     
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */     try
/* 40:   */     {
/* 41:41 */       readMethod = clazz.getMethod("is" + base, null);
/* 42:   */     }
/* 43:   */     catch (Exception getterExc) {
/* 44:   */       try {
/* 45:45 */         readMethod = clazz.getMethod("get" + base, null);
/* 46:   */       }
/* 47:   */       catch (Exception e) {}
/* 48:   */     }
/* 49:   */     
/* 50:   */ 
/* 51:51 */     return readMethod;
/* 52:   */   }
/* 53:   */   
/* 54:   */ 
/* 55:   */ 
/* 56:   */   public static Method getWriteMethod(Class clazz, String propertyName, Class propertyType)
/* 57:   */   {
/* 58:58 */     Method writeMethod = null;
/* 59:59 */     String base = capitalize(propertyName);
/* 60:   */     
/* 61:61 */     Class[] params = { propertyType };
/* 62:   */     try {
/* 63:63 */       writeMethod = clazz.getMethod("set" + base, params);
/* 64:   */     }
/* 65:   */     catch (Exception e) {}
/* 66:   */     
/* 67:   */ 
/* 68:68 */     return writeMethod;
/* 69:   */   }
/* 70:   */   
/* 71:   */   private static String capitalize(String s) {
/* 72:72 */     if (s.length() == 0) {
/* 73:73 */       return s;
/* 74:   */     }
/* 75:75 */     char[] chars = s.toCharArray();
/* 76:76 */     chars[0] = Character.toUpperCase(chars[0]);
/* 77:77 */     return String.valueOf(chars);
/* 78:   */   }
/* 79:   */ }
