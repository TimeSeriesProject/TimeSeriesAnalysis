/*  1:   */ package com.l2fprod.common.beans;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.util.ResourceManager;
/*  4:   */ import java.beans.BeanDescriptor;
/*  5:   */ import java.util.MissingResourceException;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ final class DefaultBeanDescriptor
/* 26:   */   extends BeanDescriptor
/* 27:   */ {
/* 28:   */   private String displayName;
/* 29:   */   
/* 30:   */   public DefaultBeanDescriptor(BaseBeanInfo beanInfo)
/* 31:   */   {
/* 32:32 */     super(beanInfo.getType());
/* 33:   */     try {
/* 34:34 */       setDisplayName(beanInfo.getResources().getString("beanName"));
/* 35:   */     }
/* 36:   */     catch (MissingResourceException e) {}
/* 37:   */     try
/* 38:   */     {
/* 39:39 */       setShortDescription(beanInfo.getResources().getString("beanDescription"));
/* 40:   */     }
/* 41:   */     catch (MissingResourceException e) {}
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getDisplayName()
/* 45:   */   {
/* 46:46 */     return displayName;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setDisplayName(String p_name) {
/* 50:50 */     displayName = p_name;
/* 51:   */   }
/* 52:   */ }
