/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.JTaskPaneGroupAddon;
/*   4:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.swing.plaf.TaskPaneGroupUI;
/*   6:    */ import java.awt.BorderLayout;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.Container;
/*   9:    */ import java.awt.LayoutManager;
/*  10:    */ import java.beans.PropertyChangeEvent;
/*  11:    */ import java.beans.PropertyChangeListener;
/*  12:    */ import javax.swing.Action;
/*  13:    */ import javax.swing.Icon;
/*  14:    */ import javax.swing.JPanel;
/*  15:    */ import javax.swing.UIManager;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ public class JTaskPaneGroup
/* 126:    */   extends JPanel
/* 127:    */   implements JCollapsiblePane.JCollapsiblePaneContainer
/* 128:    */ {
/* 129:    */   public static final String UI_CLASS_ID = "TaskPaneGroupUI";
/* 130:    */   public static final String EXPANDED_CHANGED_KEY = "expanded";
/* 131:    */   public static final String COLLAPSABLE_CHANGED_KEY = "collapsable";
/* 132:    */   public static final String SCROLL_ON_EXPAND_CHANGED_KEY = "scrollOnExpand";
/* 133:    */   public static final String TITLE_CHANGED_KEY = "title";
/* 134:    */   public static final String ICON_CHANGED_KEY = "icon";
/* 135:    */   public static final String SPECIAL_CHANGED_KEY = "special";
/* 136:    */   public static final String ANIMATED_CHANGED_KEY = "animated";
/* 137:    */   private String title;
/* 138:    */   private Icon icon;
/* 139:    */   private boolean special;
/* 140:    */   
/* 141:    */   static
/* 142:    */   {
/* 143:143 */     LookAndFeelAddons.contribute(new JTaskPaneGroupAddon());
/* 144:    */   }
/* 145:    */   
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:184 */   private boolean expanded = true;
/* 185:    */   private boolean scrollOnExpand;
/* 186:186 */   private boolean collapsable = true;
/* 187:    */   
/* 188:    */ 
/* 189:    */   private JCollapsiblePane collapsePane;
/* 190:    */   
/* 191:    */ 
/* 192:    */   public JTaskPaneGroup()
/* 193:    */   {
/* 194:194 */     collapsePane = new JCollapsiblePane();
/* 195:195 */     super.setLayout(new BorderLayout(0, 0));
/* 196:196 */     super.addImpl(collapsePane, "Center", -1);
/* 197:    */     
/* 198:198 */     updateUI();
/* 199:199 */     setFocusable(true);
/* 200:200 */     setOpaque(false);
/* 201:    */     
/* 202:    */ 
/* 203:203 */     setAnimated(!Boolean.FALSE.equals(UIManager.get("TaskPaneGroup.animate")));
/* 204:    */     
/* 205:    */ 
/* 206:206 */     collapsePane.addPropertyChangeListener("animationState", new PropertyChangeListener()
/* 207:    */     {
/* 208:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 209:209 */         firePropertyChange(evt.getPropertyName(), evt.getOldValue(), evt.getNewValue());
/* 210:    */       }
/* 211:    */     });
/* 212:    */   }
/* 213:    */   
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */   public Container getContentPane()
/* 219:    */   {
/* 220:220 */     return collapsePane.getContentPane();
/* 221:    */   }
/* 222:    */   
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */   public void updateUI()
/* 231:    */   {
/* 232:232 */     if (collapsePane == null) {
/* 233:233 */       return;
/* 234:    */     }
/* 235:235 */     setUI((TaskPaneGroupUI)LookAndFeelAddons.getUI(this, TaskPaneGroupUI.class));
/* 236:    */   }
/* 237:    */   
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:    */   public void setUI(TaskPaneGroupUI ui)
/* 247:    */   {
/* 248:248 */     super.setUI(ui);
/* 249:    */   }
/* 250:    */   
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */   public String getUIClassID()
/* 258:    */   {
/* 259:259 */     return "TaskPaneGroupUI";
/* 260:    */   }
/* 261:    */   
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */   public String getTitle()
/* 268:    */   {
/* 269:269 */     return title;
/* 270:    */   }
/* 271:    */   
/* 272:    */ 
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */   public void setTitle(String title)
/* 281:    */   {
/* 282:282 */     String old = title;
/* 283:283 */     this.title = title;
/* 284:284 */     firePropertyChange("title", old, title);
/* 285:    */   }
/* 286:    */   
/* 287:    */ 
/* 288:    */   /**
/* 289:    */    * @deprecated
/* 290:    */    */
/* 291:    */   public void setText(String text)
/* 292:    */   {
/* 293:293 */     setTitle(text);
/* 294:    */   }
/* 295:    */   
/* 296:    */   /**
/* 297:    */    * @deprecated
/* 298:    */    */
/* 299:    */   public String getText()
/* 300:    */   {
/* 301:301 */     return getTitle();
/* 302:    */   }
/* 303:    */   
/* 304:    */ 
/* 305:    */ 
/* 306:    */ 
/* 307:    */ 
/* 308:    */   public Icon getIcon()
/* 309:    */   {
/* 310:310 */     return icon;
/* 311:    */   }
/* 312:    */   
/* 313:    */ 
/* 314:    */ 
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */ 
/* 321:    */ 
/* 322:    */   public void setIcon(Icon icon)
/* 323:    */   {
/* 324:324 */     Icon old = icon;
/* 325:325 */     this.icon = icon;
/* 326:326 */     firePropertyChange("icon", old, icon);
/* 327:    */   }
/* 328:    */   
/* 329:    */ 
/* 330:    */ 
/* 331:    */ 
/* 332:    */ 
/* 333:    */   public boolean isSpecial()
/* 334:    */   {
/* 335:335 */     return special;
/* 336:    */   }
/* 337:    */   
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:    */ 
/* 349:    */ 
/* 350:    */ 
/* 351:    */ 
/* 352:    */ 
/* 353:    */   public void setSpecial(boolean special)
/* 354:    */   {
/* 355:355 */     if (this.special != special) {
/* 356:356 */       this.special = special;
/* 357:357 */       firePropertyChange("special", !special, special);
/* 358:    */     }
/* 359:    */   }
/* 360:    */   
/* 361:    */ 
/* 362:    */ 
/* 363:    */ 
/* 364:    */ 
/* 365:    */ 
/* 366:    */ 
/* 367:    */ 
/* 368:    */ 
/* 369:    */ 
/* 370:    */ 
/* 371:    */ 
/* 372:    */ 
/* 373:    */   public void setScrollOnExpand(boolean scrollOnExpand)
/* 374:    */   {
/* 375:375 */     if (this.scrollOnExpand != scrollOnExpand) {
/* 376:376 */       this.scrollOnExpand = scrollOnExpand;
/* 377:377 */       firePropertyChange("scrollOnExpand", !scrollOnExpand, scrollOnExpand);
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */ 
/* 382:    */ 
/* 383:    */ 
/* 384:    */ 
/* 385:    */ 
/* 386:    */ 
/* 387:    */ 
/* 388:    */   public boolean isScrollOnExpand()
/* 389:    */   {
/* 390:390 */     return scrollOnExpand;
/* 391:    */   }
/* 392:    */   
/* 393:    */ 
/* 394:    */ 
/* 395:    */ 
/* 396:    */ 
/* 397:    */ 
/* 398:    */ 
/* 399:    */ 
/* 400:    */   public void setExpanded(boolean expanded)
/* 401:    */   {
/* 402:402 */     if (this.expanded != expanded) {
/* 403:403 */       this.expanded = expanded;
/* 404:404 */       collapsePane.setCollapsed(!expanded);
/* 405:405 */       firePropertyChange("expanded", !expanded, expanded);
/* 406:    */     }
/* 407:    */   }
/* 408:    */   
/* 409:    */ 
/* 410:    */ 
/* 411:    */ 
/* 412:    */ 
/* 413:    */   public boolean isExpanded()
/* 414:    */   {
/* 415:415 */     return expanded;
/* 416:    */   }
/* 417:    */   
/* 418:    */ 
/* 419:    */ 
/* 420:    */ 
/* 421:    */ 
/* 422:    */ 
/* 423:    */   public void setCollapsable(boolean collapsable)
/* 424:    */   {
/* 425:425 */     if (this.collapsable != collapsable) {
/* 426:426 */       this.collapsable = collapsable;
/* 427:427 */       firePropertyChange("collapsable", !collapsable, collapsable);
/* 428:    */     }
/* 429:    */   }
/* 430:    */   
/* 431:    */ 
/* 432:    */ 
/* 433:    */   public boolean isCollapsable()
/* 434:    */   {
/* 435:435 */     return collapsable;
/* 436:    */   }
/* 437:    */   
/* 438:    */ 
/* 439:    */ 
/* 440:    */ 
/* 441:    */ 
/* 442:    */ 
/* 443:    */ 
/* 444:    */ 
/* 445:    */   public void setAnimated(boolean animated)
/* 446:    */   {
/* 447:447 */     if (isAnimated() != animated) {
/* 448:448 */       collapsePane.setAnimated(animated);
/* 449:449 */       firePropertyChange("animated", !isAnimated(), isAnimated());
/* 450:    */     }
/* 451:    */   }
/* 452:    */   
/* 453:    */ 
/* 454:    */ 
/* 455:    */ 
/* 456:    */ 
/* 457:    */ 
/* 458:    */ 
/* 459:    */   public boolean isAnimated()
/* 460:    */   {
/* 461:461 */     return collapsePane.isAnimated();
/* 462:    */   }
/* 463:    */   
/* 464:    */ 
/* 465:    */ 
/* 466:    */ 
/* 467:    */ 
/* 468:    */ 
/* 469:    */ 
/* 470:    */ 
/* 471:    */   public Component add(Action action)
/* 472:    */   {
/* 473:473 */     Component c = ((TaskPaneGroupUI)ui).createAction(action);
/* 474:474 */     add(c);
/* 475:475 */     return c;
/* 476:    */   }
/* 477:    */   
/* 478:    */   public Container getValidatingContainer() {
/* 479:479 */     return getParent();
/* 480:    */   }
/* 481:    */   
/* 482:    */ 
/* 483:    */ 
/* 484:    */   protected void addImpl(Component comp, Object constraints, int index)
/* 485:    */   {
/* 486:486 */     getContentPane().add(comp, constraints, index);
/* 487:    */   }
/* 488:    */   
/* 489:    */ 
/* 490:    */ 
/* 491:    */   public void setLayout(LayoutManager mgr)
/* 492:    */   {
/* 493:493 */     if (collapsePane != null) {
/* 494:494 */       getContentPane().setLayout(mgr);
/* 495:    */     }
/* 496:    */   }
/* 497:    */   
/* 498:    */ 
/* 499:    */ 
/* 500:    */   public void remove(Component comp)
/* 501:    */   {
/* 502:502 */     getContentPane().remove(comp);
/* 503:    */   }
/* 504:    */   
/* 505:    */ 
/* 506:    */ 
/* 507:    */   public void remove(int index)
/* 508:    */   {
/* 509:509 */     getContentPane().remove(index);
/* 510:    */   }
/* 511:    */   
/* 512:    */ 
/* 513:    */ 
/* 514:    */   public void removeAll()
/* 515:    */   {
/* 516:516 */     getContentPane().removeAll();
/* 517:    */   }
/* 518:    */   
/* 519:    */ 
/* 520:    */ 
/* 521:    */   public boolean isFocusable()
/* 522:    */   {
/* 523:523 */     return (super.isFocusable()) && (isCollapsable());
/* 524:    */   }
/* 525:    */   
/* 526:    */ 
/* 527:    */ 
/* 528:    */   protected String paramString()
/* 529:    */   {
/* 530:530 */     return super.paramString() + ",title=" + getTitle() + ",icon=" + getIcon() + ",expanded=" + String.valueOf(isExpanded()) + ",special=" + String.valueOf(isSpecial()) + ",scrollOnExpand=" + String.valueOf(isScrollOnExpand()) + ",ui=" + getUI();
/* 531:    */   }
/* 532:    */ }
