package com.l2fprod.common.swing.plaf.motif;

import com.l2fprod.common.swing.plaf.basic.BasicLookAndFeelAddons;

public class MotifLookAndFeelAddons
  extends BasicLookAndFeelAddons
{}
