/*   1:    */ package com.l2fprod.common.swing.plaf;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.aqua.AquaLookAndFeelAddons;
/*   4:    */ import com.l2fprod.common.swing.plaf.metal.MetalLookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.swing.plaf.motif.MotifLookAndFeelAddons;
/*   6:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*   7:    */ import java.awt.Color;
/*   8:    */ import java.awt.Font;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Enumeration;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.ResourceBundle;
/*  13:    */ import javax.swing.UIManager;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ public abstract class AbstractComponentAddon
/*  27:    */   implements ComponentAddon
/*  28:    */ {
/*  29:    */   private String name;
/*  30:    */   
/*  31:    */   protected AbstractComponentAddon(String name)
/*  32:    */   {
/*  33: 33 */     this.name = name;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public final String getName() {
/*  37: 37 */     return name;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void initialize(LookAndFeelAddons addon) {
/*  41: 41 */     addon.loadDefaults(getDefaults(addon));
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void uninitialize(LookAndFeelAddons addon) {
/*  45: 45 */     addon.unloadDefaults(getDefaults(addon));
/*  46:    */   }
/*  47:    */   
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {}
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */   protected void addMacDefaults(LookAndFeelAddons addon, List defaults)
/*  63:    */   {
/*  64: 64 */     addBasicDefaults(addon, defaults);
/*  65:    */   }
/*  66:    */   
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */   protected void addMetalDefaults(LookAndFeelAddons addon, List defaults)
/*  73:    */   {
/*  74: 74 */     addBasicDefaults(addon, defaults);
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */   protected void addMotifDefaults(LookAndFeelAddons addon, List defaults)
/*  83:    */   {
/*  84: 84 */     addBasicDefaults(addon, defaults);
/*  85:    */   }
/*  86:    */   
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   protected void addWindowsDefaults(LookAndFeelAddons addon, List defaults)
/*  93:    */   {
/*  94: 94 */     addBasicDefaults(addon, defaults);
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */   private Object[] getDefaults(LookAndFeelAddons addon)
/* 120:    */   {
/* 121:121 */     List defaults = new ArrayList();
/* 122:122 */     if (isWindows(addon)) {
/* 123:123 */       addWindowsDefaults(addon, defaults);
/* 124:124 */     } else if (isMetal(addon)) {
/* 125:125 */       addMetalDefaults(addon, defaults);
/* 126:126 */     } else if (isMac(addon)) {
/* 127:127 */       addMacDefaults(addon, defaults);
/* 128:128 */     } else if (isMotif(addon)) {
/* 129:129 */       addMotifDefaults(addon, defaults);
/* 130:    */     }
/* 131:    */     else {
/* 132:132 */       addBasicDefaults(addon, defaults);
/* 133:    */     }
/* 134:134 */     return defaults.toArray();
/* 135:    */   }
/* 136:    */   
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */   protected void addResource(List defaults, String bundleName)
/* 145:    */   {
/* 146:146 */     ResourceBundle bundle = ResourceBundle.getBundle(bundleName);
/* 147:147 */     for (Enumeration keys = bundle.getKeys(); keys.hasMoreElements();) {
/* 148:148 */       String key = (String)keys.nextElement();
/* 149:149 */       defaults.add(key);
/* 150:150 */       defaults.add(bundle.getObject(key));
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */ 
/* 156:    */   protected boolean isWindows(LookAndFeelAddons addon)
/* 157:    */   {
/* 158:158 */     return addon instanceof WindowsLookAndFeelAddons;
/* 159:    */   }
/* 160:    */   
/* 161:    */ 
/* 162:    */ 
/* 163:    */   protected boolean isMetal(LookAndFeelAddons addon)
/* 164:    */   {
/* 165:165 */     return addon instanceof MetalLookAndFeelAddons;
/* 166:    */   }
/* 167:    */   
/* 168:    */ 
/* 169:    */ 
/* 170:    */   protected boolean isMac(LookAndFeelAddons addon)
/* 171:    */   {
/* 172:172 */     return addon instanceof AquaLookAndFeelAddons;
/* 173:    */   }
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */   protected boolean isMotif(LookAndFeelAddons addon)
/* 178:    */   {
/* 179:179 */     return addon instanceof MotifLookAndFeelAddons;
/* 180:    */   }
/* 181:    */   
/* 182:    */ 
/* 183:    */ 
/* 184:    */   protected boolean isPlastic()
/* 185:    */   {
/* 186:186 */     return UIManager.getLookAndFeel().getClass().getName().indexOf("Plastic") != -1;
/* 187:    */   }
/* 188:    */   
/* 189:    */ 
/* 190:    */ 
/* 191:    */   protected boolean isSynth()
/* 192:    */   {
/* 193:193 */     return UIManager.getLookAndFeel().getClass().getName().indexOf("ynth") != -1;
/* 194:    */   }
/* 195:    */   
/* 196:    */   protected Font getFont(String key, Font defaultFont) {
/* 197:197 */     Font result = UIManager.getFont(key);
/* 198:198 */     return result != null ? result : defaultFont;
/* 199:    */   }
/* 200:    */   
/* 201:    */   protected Color getColor(String key, Color defaultColor) {
/* 202:202 */     Color result = UIManager.getColor(key);
/* 203:203 */     return result != null ? result : defaultColor;
/* 204:    */   }
/* 205:    */ }
