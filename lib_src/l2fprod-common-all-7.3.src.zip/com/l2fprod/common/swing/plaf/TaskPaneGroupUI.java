/*  1:   */ package com.l2fprod.common.swing.plaf;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import javax.swing.Action;
/*  5:   */ import javax.swing.JButton;
/*  6:   */ import javax.swing.plaf.PanelUI;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ public class TaskPaneGroupUI
/* 37:   */   extends PanelUI
/* 38:   */ {
/* 39:   */   public Component createAction(Action action)
/* 40:   */   {
/* 41:41 */     return new JButton(action);
/* 42:   */   }
/* 43:   */ }
