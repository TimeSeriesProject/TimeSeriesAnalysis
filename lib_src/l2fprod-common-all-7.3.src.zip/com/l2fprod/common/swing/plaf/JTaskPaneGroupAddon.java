/*   1:    */ package com.l2fprod.common.swing.plaf;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons;
/*   4:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.util.JVM;
/*   6:    */ import com.l2fprod.common.util.OS;
/*   7:    */ import java.awt.Color;
/*   8:    */ import java.awt.Font;
/*   9:    */ import java.awt.SystemColor;
/*  10:    */ import java.awt.Toolkit;
/*  11:    */ import java.lang.reflect.Method;
/*  12:    */ import java.util.Arrays;
/*  13:    */ import java.util.List;
/*  14:    */ import javax.swing.UIDefaults.LazyInputMap;
/*  15:    */ import javax.swing.UIManager;
/*  16:    */ import javax.swing.plaf.ColorUIResource;
/*  17:    */ import javax.swing.plaf.FontUIResource;
/*  18:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ public class JTaskPaneGroupAddon
/*  44:    */   extends AbstractComponentAddon
/*  45:    */ {
/*  46:    */   public JTaskPaneGroupAddon()
/*  47:    */   {
/*  48: 48 */     super("JTaskPaneGroup");
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/*  52: 52 */     Font taskPaneFont = UIManager.getFont("Label.font");
/*  53: 53 */     if (taskPaneFont == null) {
/*  54: 54 */       taskPaneFont = new Font("Dialog", 0, 12);
/*  55:    */     }
/*  56: 56 */     taskPaneFont = taskPaneFont.deriveFont(1);
/*  57:    */     
/*  58:    */ 
/*  59: 59 */     Color menuBackground = new ColorUIResource(SystemColor.menu);
/*  60: 60 */     defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroupUI", "com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI", "TaskPaneGroup.font", new FontUIResource(taskPaneFont), "TaskPaneGroup.background", UIManager.getColor("List.background"), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(menuBackground.darker()), "TaskPaneGroup.titleBackgroundGradientStart", menuBackground, "TaskPaneGroup.titleBackgroundGradientEnd", menuBackground, "TaskPaneGroup.titleForeground", new ColorUIResource(SystemColor.menuText), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(SystemColor.menuText).brighter(), "TaskPaneGroup.animate", Boolean.TRUE, "TaskPaneGroup.focusInputMap", new UIDefaults.LazyInputMap(new Object[] { "ENTER", "toggleExpanded", "SPACE", "toggleExpanded" }) }));
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   protected void addMetalDefaults(LookAndFeelAddons addon, List defaults)
/*  89:    */   {
/*  90: 90 */     super.addMetalDefaults(addon, defaults);
/*  91:    */     
/*  92: 92 */     String taskPaneGroupUI = "com.l2fprod.common.swing.plaf.metal.MetalTaskPaneGroupUI";
/*  93: 93 */     if (JVM.current().isOrLater(15)) {
/*  94:    */       try {
/*  95: 95 */         Method method = MetalLookAndFeel.class.getMethod("getCurrentTheme", null);
/*  96: 96 */         Object currentTheme = method.invoke(null, null);
/*  97: 97 */         if (Class.forName("javax.swing.plaf.metal.OceanTheme").isInstance(currentTheme))
/*  98:    */         {
/*  99: 99 */           taskPaneGroupUI = "com.l2fprod.common.swing.plaf.misc.GlossyTaskPaneGroupUI";
/* 100:    */         }
/* 101:    */       }
/* 102:    */       catch (Exception e) {}
/* 103:    */     }
/* 104:104 */     defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroupUI", taskPaneGroupUI, "TaskPaneGroup.foreground", UIManager.getColor("activeCaptionText"), "TaskPaneGroup.background", MetalLookAndFeel.getControl(), "TaskPaneGroup.specialTitleBackground", MetalLookAndFeel.getPrimaryControl(), "TaskPaneGroup.titleBackgroundGradientStart", MetalLookAndFeel.getPrimaryControl(), "TaskPaneGroup.titleBackgroundGradientEnd", MetalLookAndFeel.getPrimaryControlHighlight(), "TaskPaneGroup.titleForeground", MetalLookAndFeel.getControlTextColor(), "TaskPaneGroup.specialTitleForeground", MetalLookAndFeel.getControlTextColor(), "TaskPaneGroup.borderColor", MetalLookAndFeel.getPrimaryControl(), "TaskPaneGroup.titleOver", MetalLookAndFeel.getControl().darker(), "TaskPaneGroup.specialTitleOver", MetalLookAndFeel.getPrimaryControlHighlight() }));
/* 105:    */   }
/* 106:    */   
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */   protected void addWindowsDefaults(LookAndFeelAddons addon, List defaults)
/* 131:    */   {
/* 132:132 */     super.addWindowsDefaults(addon, defaults);
/* 133:    */     
/* 134:134 */     if ((addon instanceof WindowsLookAndFeelAddons)) {
/* 135:135 */       defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroupUI", "com.l2fprod.common.swing.plaf.windows.WindowsTaskPaneGroupUI" }));
/* 136:    */       
/* 137:    */ 
/* 138:    */ 
/* 139:139 */       String xpStyle = OS.getWindowsVisualStyle();
/* 140:140 */       if ("HomeStead".equalsIgnoreCase(xpStyle))
/* 141:    */       {
/* 142:142 */         defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroup.foreground", new ColorUIResource(86, 102, 45), "TaskPaneGroup.background", new ColorUIResource(246, 246, 236), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(224, 231, 184), "TaskPaneGroup.titleBackgroundGradientStart", new ColorUIResource(255, 255, 255), "TaskPaneGroup.titleBackgroundGradientEnd", new ColorUIResource(224, 231, 184), "TaskPaneGroup.titleForeground", new ColorUIResource(86, 102, 45), "TaskPaneGroup.titleOver", new ColorUIResource(114, 146, 29), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(86, 102, 45), "TaskPaneGroup.specialTitleOver", new ColorUIResource(114, 146, 29), "TaskPaneGroup.borderColor", new ColorUIResource(255, 255, 255) }));
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */       }
/* 164:164 */       else if ("Metallic".equalsIgnoreCase(xpStyle))
/* 165:    */       {
/* 166:166 */         defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroup.foreground", new ColorUIResource(Color.black), "TaskPaneGroup.background", new ColorUIResource(240, 241, 245), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(222, 222, 222), "TaskPaneGroup.titleBackgroundGradientStart", new ColorUIResource(Color.white), "TaskPaneGroup.titleBackgroundGradientEnd", new ColorUIResource(214, 215, 224), "TaskPaneGroup.titleForeground", new ColorUIResource(Color.black), "TaskPaneGroup.titleOver", new ColorUIResource(126, 124, 124), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(Color.black), "TaskPaneGroup.specialTitleOver", new ColorUIResource(126, 124, 124), "TaskPaneGroup.borderColor", new ColorUIResource(Color.white) }));
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */       }
/* 188:188 */       else if (OS.isWindowsVista()) {
/* 189:189 */         Toolkit toolkit = Toolkit.getDefaultToolkit();
/* 190:190 */         defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroup.foreground", new ColorUIResource(Color.white), "TaskPaneGroup.background", new ColorUIResource((Color)toolkit.getDesktopProperty("win.3d.backgroundColor")), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(33, 89, 201), "TaskPaneGroup.titleBackgroundGradientStart", new ColorUIResource(Color.white), "TaskPaneGroup.titleBackgroundGradientEnd", new ColorUIResource((Color)toolkit.getDesktopProperty("win.frame.inactiveCaptionColor")), "TaskPaneGroup.titleForeground", new ColorUIResource((Color)toolkit.getDesktopProperty("win.frame.inactiveCaptionTextColor")), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(Color.white), "TaskPaneGroup.borderColor", new ColorUIResource(Color.white) }));
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */       }
/* 200:    */       else
/* 201:    */       {
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:209 */         defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroup.foreground", new ColorUIResource(Color.white), "TaskPaneGroup.background", new ColorUIResource(214, 223, 247), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(33, 89, 201), "TaskPaneGroup.titleBackgroundGradientStart", new ColorUIResource(Color.white), "TaskPaneGroup.titleBackgroundGradientEnd", new ColorUIResource(199, 212, 247), "TaskPaneGroup.titleForeground", new ColorUIResource(33, 89, 201), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(Color.white), "TaskPaneGroup.borderColor", new ColorUIResource(Color.white) }));
/* 210:    */       }
/* 211:    */     }
/* 212:    */     
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:230 */     if ((addon instanceof WindowsClassicLookAndFeelAddons)) {
/* 231:231 */       defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroupUI", "com.l2fprod.common.swing.plaf.windows.WindowsClassicTaskPaneGroupUI", "TaskPaneGroup.foreground", new ColorUIResource(Color.black), "TaskPaneGroup.background", new ColorUIResource(Color.white), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(10, 36, 106), "TaskPaneGroup.titleBackgroundGradientStart", new ColorUIResource(212, 208, 200), "TaskPaneGroup.titleBackgroundGradientEnd", new ColorUIResource(212, 208, 200), "TaskPaneGroup.titleForeground", new ColorUIResource(Color.black), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(Color.white), "TaskPaneGroup.borderColor", new ColorUIResource(212, 208, 200) }));
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:    */ 
/* 247:    */ 
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:    */   protected void addMacDefaults(LookAndFeelAddons addon, List defaults)
/* 254:    */   {
/* 255:255 */     super.addMacDefaults(addon, defaults);
/* 256:256 */     defaults.addAll(Arrays.asList(new Object[] { "TaskPaneGroupUI", "com.l2fprod.common.swing.plaf.misc.GlossyTaskPaneGroupUI", "TaskPaneGroup.background", new ColorUIResource(245, 245, 245), "TaskPaneGroup.titleForeground", new ColorUIResource(Color.black), "TaskPaneGroup.specialTitleBackground", new ColorUIResource(188, 188, 188), "TaskPaneGroup.specialTitleForeground", new ColorUIResource(Color.black), "TaskPaneGroup.titleBackgroundGradientStart", new ColorUIResource(250, 250, 250), "TaskPaneGroup.titleBackgroundGradientEnd", new ColorUIResource(188, 188, 188), "TaskPaneGroup.borderColor", new ColorUIResource(97, 97, 97), "TaskPaneGroup.titleOver", new ColorUIResource(125, 125, 97), "TaskPaneGroup.specialTitleOver", new ColorUIResource(125, 125, 97) }));
/* 257:    */   }
/* 258:    */ }
