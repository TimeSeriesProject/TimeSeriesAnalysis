/*  1:   */ package com.l2fprod.common.swing.plaf;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.basic.BasicTipOfTheDayUI;
/*  4:   */ import com.l2fprod.common.swing.plaf.windows.WindowsTipOfTheDayUI;
/*  5:   */ import com.l2fprod.common.swing.plaf.windows.WindowsTipOfTheDayUI.TipAreaBorder;
/*  6:   */ import java.awt.Color;
/*  7:   */ import java.awt.Font;
/*  8:   */ import java.util.List;
/*  9:   */ import javax.swing.BorderFactory;
/* 10:   */ import javax.swing.LookAndFeel;
/* 11:   */ import javax.swing.UIManager;
/* 12:   */ import javax.swing.plaf.BorderUIResource;
/* 13:   */ import javax.swing.plaf.ColorUIResource;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public class JTipOfTheDayAddon
/* 36:   */   extends AbstractComponentAddon
/* 37:   */ {
/* 38:   */   public JTipOfTheDayAddon()
/* 39:   */   {
/* 40:40 */     super("JTipOfTheDay");
/* 41:   */   }
/* 42:   */   
/* 43:   */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/* 44:44 */     defaults.add("l2fprod/TipOfTheDayUI");
/* 45:45 */     defaults.add(BasicTipOfTheDayUI.class.getName());
/* 46:   */     
/* 47:47 */     defaults.add("TipOfTheDay.font");
/* 48:48 */     defaults.add(UIManager.getFont("TextPane.font"));
/* 49:   */     
/* 50:50 */     defaults.add("TipOfTheDay.tipFont");
/* 51:51 */     defaults.add(UIManager.getFont("Label.font").deriveFont(1, 13.0F));
/* 52:   */     
/* 53:53 */     defaults.add("TipOfTheDay.background");
/* 54:54 */     defaults.add(new ColorUIResource(Color.white));
/* 55:   */     
/* 56:56 */     defaults.add("TipOfTheDay.icon");
/* 57:57 */     defaults.add(LookAndFeel.makeIcon(BasicTipOfTheDayUI.class, "TipOfTheDay24.gif"));
/* 58:   */     
/* 59:   */ 
/* 60:60 */     defaults.add("TipOfTheDay.border");
/* 61:61 */     defaults.add(new BorderUIResource(BorderFactory.createLineBorder(new Color(117, 117, 117))));
/* 62:   */     
/* 63:   */ 
/* 64:64 */     addResource(defaults, "com.l2fprod.common.swing.plaf.basic.resources.TipOfTheDay");
/* 65:   */   }
/* 66:   */   
/* 67:   */   protected void addWindowsDefaults(LookAndFeelAddons addon, List defaults)
/* 68:   */   {
/* 69:69 */     super.addWindowsDefaults(addon, defaults);
/* 70:   */     
/* 71:71 */     defaults.add("l2fprod/TipOfTheDayUI");
/* 72:72 */     defaults.add(WindowsTipOfTheDayUI.class.getName());
/* 73:   */     
/* 74:74 */     defaults.add("TipOfTheDay.background");
/* 75:75 */     defaults.add(new ColorUIResource(128, 128, 128));
/* 76:   */     
/* 77:77 */     defaults.add("TipOfTheDay.font");
/* 78:78 */     defaults.add(UIManager.getFont("Label.font").deriveFont(13.0F));
/* 79:   */     
/* 80:80 */     defaults.add("TipOfTheDay.icon");
/* 81:81 */     defaults.add(LookAndFeel.makeIcon(WindowsTipOfTheDayUI.class, "tipoftheday.png"));
/* 82:   */     
/* 83:   */ 
/* 84:84 */     defaults.add("TipOfTheDay.border");
/* 85:85 */     defaults.add(new BorderUIResource(new WindowsTipOfTheDayUI.TipAreaBorder()));
/* 86:   */     
/* 87:   */ 
/* 88:88 */     addResource(defaults, "com.l2fprod.common.swing.plaf.windows.resources.TipOfTheDay");
/* 89:   */   }
/* 90:   */ }
