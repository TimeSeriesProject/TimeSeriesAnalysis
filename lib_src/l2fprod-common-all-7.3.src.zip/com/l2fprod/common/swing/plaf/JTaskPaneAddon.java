/*   1:    */ package com.l2fprod.common.swing.plaf;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons;
/*   4:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.util.OS;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Toolkit;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.List;
/*  10:    */ import javax.swing.UIManager;
/*  11:    */ import javax.swing.plaf.ColorUIResource;
/*  12:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class JTaskPaneAddon
/*  37:    */   extends AbstractComponentAddon
/*  38:    */ {
/*  39:    */   public JTaskPaneAddon()
/*  40:    */   {
/*  41: 41 */     super("JTaskPane");
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/*  45: 45 */     super.addBasicDefaults(addon, defaults);
/*  46: 46 */     defaults.addAll(Arrays.asList(new Object[] { "TaskPaneUI", "com.l2fprod.common.swing.plaf.basic.BasicTaskPaneUI", "TaskPane.useGradient", Boolean.FALSE, "TaskPane.background", UIManager.getColor("Desktop.background") }));
/*  47:    */   }
/*  48:    */   
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */   protected void addMetalDefaults(LookAndFeelAddons addon, List defaults)
/*  56:    */   {
/*  57: 57 */     super.addMetalDefaults(addon, defaults);
/*  58: 58 */     defaults.addAll(Arrays.asList(new Object[] { "TaskPane.background", MetalLookAndFeel.getDesktopColor() }));
/*  59:    */   }
/*  60:    */   
/*  61:    */ 
/*  62:    */ 
/*  63:    */   protected void addWindowsDefaults(LookAndFeelAddons addon, List defaults)
/*  64:    */   {
/*  65: 65 */     super.addWindowsDefaults(addon, defaults);
/*  66: 66 */     if ((addon instanceof WindowsClassicLookAndFeelAddons)) {
/*  67: 67 */       defaults.addAll(Arrays.asList(new Object[] { "TaskPane.background", UIManager.getColor("List.background") }));
/*  68:    */ 
/*  69:    */ 
/*  70:    */     }
/*  71: 71 */     else if ((addon instanceof WindowsLookAndFeelAddons)) {
/*  72: 72 */       String xpStyle = OS.getWindowsVisualStyle();
/*  73:    */       ColorUIResource backgroundGradientEnd;
/*  74:    */       ColorUIResource background;
/*  75:    */       ColorUIResource backgroundGradientStart;
/*  76:    */       ColorUIResource backgroundGradientEnd;
/*  77: 77 */       if ("HomeStead".equalsIgnoreCase(xpStyle))
/*  78:    */       {
/*  79: 79 */         ColorUIResource background = new ColorUIResource(201, 215, 170);
/*  80: 80 */         ColorUIResource backgroundGradientStart = new ColorUIResource(204, 217, 173);
/*  81: 81 */         backgroundGradientEnd = new ColorUIResource(165, 189, 132); } else { ColorUIResource backgroundGradientEnd;
/*  82: 82 */         if ("Metallic".equalsIgnoreCase(xpStyle))
/*  83:    */         {
/*  84: 84 */           ColorUIResource background = new ColorUIResource(192, 195, 209);
/*  85: 85 */           ColorUIResource backgroundGradientStart = new ColorUIResource(196, 200, 212);
/*  86: 86 */           backgroundGradientEnd = new ColorUIResource(177, 179, 200);
/*  87:    */         } else { ColorUIResource backgroundGradientEnd;
/*  88: 88 */           if (OS.isWindowsVista()) {
/*  89: 89 */             Toolkit toolkit = Toolkit.getDefaultToolkit();
/*  90: 90 */             ColorUIResource background = new ColorUIResource((Color)toolkit.getDesktopProperty("win.3d.backgroundColor"));
/*  91: 91 */             ColorUIResource backgroundGradientStart = new ColorUIResource((Color)toolkit.getDesktopProperty("win.frame.activeCaptionColor"));
/*  92: 92 */             backgroundGradientEnd = new ColorUIResource((Color)toolkit.getDesktopProperty("win.frame.inactiveCaptionColor"));
/*  93:    */           } else {
/*  94: 94 */             background = new ColorUIResource(117, 150, 227);
/*  95: 95 */             backgroundGradientStart = new ColorUIResource(123, 162, 231);
/*  96: 96 */             backgroundGradientEnd = new ColorUIResource(99, 117, 214);
/*  97:    */           }
/*  98:    */         } }
/*  99: 99 */       defaults.addAll(Arrays.asList(new Object[] { "TaskPane.useGradient", Boolean.TRUE, "TaskPane.background", background, "TaskPane.backgroundGradientStart", backgroundGradientStart, "TaskPane.backgroundGradientEnd", backgroundGradientEnd }));
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */   protected void addMacDefaults(LookAndFeelAddons addon, List defaults)
/* 112:    */   {
/* 113:113 */     super.addMacDefaults(addon, defaults);
/* 114:114 */     defaults.addAll(Arrays.asList(new Object[] { "TaskPane.background", new ColorUIResource(238, 238, 238) }));
/* 115:    */   }
/* 116:    */ }
