package com.l2fprod.common.swing.plaf;

import com.l2fprod.common.swing.JTipOfTheDay.ShowOnStartupChoice;
import java.awt.Component;
import javax.swing.JDialog;
import javax.swing.plaf.ComponentUI;

public abstract class TipOfTheDayUI
  extends ComponentUI
{
  public abstract JDialog createDialog(Component paramComponent, JTipOfTheDay.ShowOnStartupChoice paramShowOnStartupChoice);
}
