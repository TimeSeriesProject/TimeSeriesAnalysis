/*   1:    */ package com.l2fprod.common.swing.plaf.basic;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JCollapsiblePane;
/*   4:    */ import com.l2fprod.common.swing.JLinkButton;
/*   5:    */ import com.l2fprod.common.swing.JTaskPaneGroup;
/*   6:    */ import com.l2fprod.common.swing.icons.EmptyIcon;
/*   7:    */ import com.l2fprod.common.swing.plaf.TaskPaneGroupUI;
/*   8:    */ import java.awt.Color;
/*   9:    */ import java.awt.Component;
/*  10:    */ import java.awt.ComponentOrientation;
/*  11:    */ import java.awt.Cursor;
/*  12:    */ import java.awt.Dimension;
/*  13:    */ import java.awt.Graphics;
/*  14:    */ import java.awt.Insets;
/*  15:    */ import java.awt.Rectangle;
/*  16:    */ import java.awt.event.ActionEvent;
/*  17:    */ import java.awt.event.FocusEvent;
/*  18:    */ import java.awt.event.FocusListener;
/*  19:    */ import java.awt.event.MouseEvent;
/*  20:    */ import java.beans.PropertyChangeEvent;
/*  21:    */ import java.beans.PropertyChangeListener;
/*  22:    */ import javax.swing.AbstractAction;
/*  23:    */ import javax.swing.Action;
/*  24:    */ import javax.swing.ActionMap;
/*  25:    */ import javax.swing.BorderFactory;
/*  26:    */ import javax.swing.Icon;
/*  27:    */ import javax.swing.InputMap;
/*  28:    */ import javax.swing.JComponent;
/*  29:    */ import javax.swing.JLabel;
/*  30:    */ import javax.swing.LookAndFeel;
/*  31:    */ import javax.swing.SwingUtilities;
/*  32:    */ import javax.swing.UIManager;
/*  33:    */ import javax.swing.border.Border;
/*  34:    */ import javax.swing.border.CompoundBorder;
/*  35:    */ import javax.swing.event.MouseInputAdapter;
/*  36:    */ import javax.swing.event.MouseInputListener;
/*  37:    */ import javax.swing.plaf.ActionMapUIResource;
/*  38:    */ import javax.swing.plaf.ComponentUI;
/*  39:    */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ public class BasicTaskPaneGroupUI
/*  62:    */   extends TaskPaneGroupUI
/*  63:    */ {
/*  64: 64 */   private static FocusListener focusListener = new RepaintOnFocus();
/*  65:    */   
/*  66:    */   public static ComponentUI createUI(JComponent c) {
/*  67: 67 */     return new BasicTaskPaneGroupUI();
/*  68:    */   }
/*  69:    */   
/*  70: 70 */   protected static int TITLE_HEIGHT = 25;
/*  71: 71 */   protected static int ROUND_HEIGHT = 5;
/*  72:    */   
/*  73:    */   protected JTaskPaneGroup group;
/*  74:    */   
/*  75:    */   protected boolean mouseOver;
/*  76:    */   protected MouseInputListener mouseListener;
/*  77:    */   protected PropertyChangeListener propertyListener;
/*  78:    */   
/*  79:    */   public void installUI(JComponent c)
/*  80:    */   {
/*  81: 81 */     super.installUI(c);
/*  82: 82 */     group = ((JTaskPaneGroup)c);
/*  83:    */     
/*  84: 84 */     installDefaults();
/*  85: 85 */     installListeners();
/*  86: 86 */     installKeyboardActions();
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected void installDefaults() {
/*  90: 90 */     group.setOpaque(true);
/*  91: 91 */     group.setBorder(createPaneBorder());
/*  92: 92 */     ((JComponent)group.getContentPane()).setBorder(createContentPaneBorder());
/*  93:    */     
/*  94: 94 */     LookAndFeel.installColorsAndFont(group, "TaskPaneGroup.background", "TaskPaneGroup.foreground", "TaskPaneGroup.font");
/*  95:    */     
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:100 */     LookAndFeel.installColorsAndFont((JComponent)group.getContentPane(), "TaskPaneGroup.background", "TaskPaneGroup.foreground", "TaskPaneGroup.font");
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */   protected void installListeners()
/* 107:    */   {
/* 108:108 */     mouseListener = createMouseInputListener();
/* 109:109 */     group.addMouseMotionListener(mouseListener);
/* 110:110 */     group.addMouseListener(mouseListener);
/* 111:    */     
/* 112:112 */     group.addFocusListener(focusListener);
/* 113:113 */     propertyListener = createPropertyListener();
/* 114:114 */     group.addPropertyChangeListener(propertyListener);
/* 115:    */   }
/* 116:    */   
/* 117:    */   protected void installKeyboardActions() {
/* 118:118 */     InputMap inputMap = (InputMap)UIManager.get("TaskPaneGroup.focusInputMap");
/* 119:119 */     if (inputMap != null) {
/* 120:120 */       SwingUtilities.replaceUIInputMap(group, 0, inputMap);
/* 121:    */     }
/* 122:    */     
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:126 */     ActionMap map = getActionMap();
/* 127:127 */     if (map != null) {
/* 128:128 */       SwingUtilities.replaceUIActionMap(group, map);
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   ActionMap getActionMap() {
/* 133:133 */     ActionMap map = new ActionMapUIResource();
/* 134:134 */     map.put("toggleExpanded", new ToggleExpandedAction());
/* 135:135 */     return map;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void uninstallUI(JComponent c) {
/* 139:139 */     uninstallListeners();
/* 140:140 */     super.uninstallUI(c);
/* 141:    */   }
/* 142:    */   
/* 143:    */   protected void uninstallListeners() {
/* 144:144 */     group.removeMouseListener(mouseListener);
/* 145:145 */     group.removeMouseMotionListener(mouseListener);
/* 146:146 */     group.removeFocusListener(focusListener);
/* 147:147 */     group.removePropertyChangeListener(propertyListener);
/* 148:    */   }
/* 149:    */   
/* 150:    */   protected MouseInputListener createMouseInputListener() {
/* 151:151 */     return new ToggleListener();
/* 152:    */   }
/* 153:    */   
/* 154:    */   protected PropertyChangeListener createPropertyListener() {
/* 155:155 */     return new ChangeListener();
/* 156:    */   }
/* 157:    */   
/* 158:    */   protected boolean isInBorder(MouseEvent event) {
/* 159:159 */     return event.getY() < getTitleHeight();
/* 160:    */   }
/* 161:    */   
/* 162:    */   protected final int getTitleHeight() {
/* 163:163 */     return TITLE_HEIGHT;
/* 164:    */   }
/* 165:    */   
/* 166:    */   protected Border createPaneBorder() {
/* 167:167 */     return new PaneBorder();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public Dimension getPreferredSize(JComponent c) {
/* 171:171 */     Component component = group.getComponent(0);
/* 172:172 */     if (!(component instanceof JCollapsiblePane))
/* 173:    */     {
/* 174:174 */       return super.getPreferredSize(c);
/* 175:    */     }
/* 176:    */     
/* 177:177 */     JCollapsiblePane collapsible = (JCollapsiblePane)component;
/* 178:178 */     Dimension dim = collapsible.getPreferredSize();
/* 179:    */     
/* 180:180 */     Border groupBorder = group.getBorder();
/* 181:181 */     if ((groupBorder instanceof PaneBorder)) {
/* 182:182 */       Dimension border = ((PaneBorder)groupBorder).getPreferredSize(group);
/* 183:183 */       width = Math.max(width, width);
/* 184:184 */       height += height;
/* 185:    */     } else {
/* 186:186 */       height += getTitleHeight();
/* 187:    */     }
/* 188:    */     
/* 189:189 */     return dim;
/* 190:    */   }
/* 191:    */   
/* 192:    */   protected Border createContentPaneBorder() {
/* 193:193 */     Color borderColor = UIManager.getColor("TaskPaneGroup.borderColor");
/* 194:194 */     return new CompoundBorder(new ContentPaneBorder(borderColor), BorderFactory.createEmptyBorder(10, 10, 10, 10));
/* 195:    */   }
/* 196:    */   
/* 197:    */   public Component createAction(Action action)
/* 198:    */   {
/* 199:199 */     JLinkButton link = new JLinkButton(action) {
/* 200:    */       public void updateUI() {
/* 201:201 */         super.updateUI();
/* 202:    */         
/* 203:203 */         if (BasicTaskPaneGroupUI.this != null) {
/* 204:204 */           configure(this);
/* 205:    */         }
/* 206:    */       }
/* 207:207 */     };
/* 208:208 */     configure(link);
/* 209:209 */     return link;
/* 210:    */   }
/* 211:    */   
/* 212:    */   protected void configure(JLinkButton link) {
/* 213:213 */     link.setOpaque(false);
/* 214:214 */     link.setBorder(null);
/* 215:215 */     link.setBorderPainted(false);
/* 216:216 */     link.setFocusPainted(true);
/* 217:217 */     link.setForeground(UIManager.getColor("TaskPaneGroup.titleForeground"));
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected void ensureVisible() {
/* 221:221 */     SwingUtilities.invokeLater(new Runnable() {
/* 222:    */       public void run() {
/* 223:223 */         group.scrollRectToVisible(new Rectangle(group.getWidth(), group.getHeight()));
/* 224:    */       }
/* 225:    */     });
/* 226:    */   }
/* 227:    */   
/* 228:    */   static class RepaintOnFocus implements FocusListener
/* 229:    */   {
/* 230:    */     public void focusGained(FocusEvent e) {
/* 231:231 */       e.getComponent().repaint();
/* 232:    */     }
/* 233:    */     
/* 234:234 */     public void focusLost(FocusEvent e) { e.getComponent().repaint(); }
/* 235:    */   }
/* 236:    */   
/* 237:    */   class ChangeListener implements PropertyChangeListener
/* 238:    */   {
/* 239:    */     ChangeListener() {}
/* 240:    */     
/* 241:    */     public void propertyChange(PropertyChangeEvent evt)
/* 242:    */     {
/* 243:243 */       if ((("expanded".equals(evt.getPropertyName())) && (Boolean.TRUE.equals(evt.getNewValue())) && (!group.isAnimated())) || (("animationState".equals(evt.getPropertyName())) && ("expanded".equals(evt.getNewValue()))))
/* 244:    */       {
/* 245:    */ 
/* 246:    */ 
/* 247:247 */         if (group.isScrollOnExpand()) {
/* 248:248 */           ensureVisible();
/* 249:    */         }
/* 250:250 */       } else if (("icon".equals(evt.getPropertyName())) || ("title".equals(evt.getPropertyName())) || ("special".equals(evt.getPropertyName())) || ("collapsable".equals(evt.getPropertyName())))
/* 251:    */       {
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:255 */         group.repaint(); }
/* 256:    */     }
/* 257:    */   }
/* 258:    */   
/* 259:    */   class ToggleListener extends MouseInputAdapter {
/* 260:    */     ToggleListener() {}
/* 261:    */     
/* 262:262 */     public void mouseEntered(MouseEvent e) { if (isInBorder(e)) {
/* 263:263 */         e.getComponent().setCursor(Cursor.getPredefinedCursor(12));
/* 264:    */       }
/* 265:    */       else {
/* 266:266 */         mouseOver = false;
/* 267:267 */         group.repaint();
/* 268:    */       }
/* 269:    */     }
/* 270:    */     
/* 271:271 */     public void mouseExited(MouseEvent e) { e.getComponent().setCursor(null);
/* 272:272 */       mouseOver = false;
/* 273:273 */       group.repaint();
/* 274:    */     }
/* 275:    */     
/* 276:276 */     public void mouseMoved(MouseEvent e) { if ((isInBorder(e)) && (group.isCollapsable())) {
/* 277:277 */         e.getComponent().setCursor(Cursor.getPredefinedCursor(12));
/* 278:    */         
/* 279:279 */         mouseOver = true;
/* 280:280 */         group.repaint();
/* 281:    */       } else {
/* 282:282 */         e.getComponent().setCursor(null);
/* 283:283 */         mouseOver = false;
/* 284:284 */         group.repaint();
/* 285:    */       }
/* 286:    */     }
/* 287:    */     
/* 288:288 */     public void mouseReleased(MouseEvent e) { if ((isInBorder(e)) && (group.isCollapsable())) {
/* 289:289 */         group.setExpanded(!group.isExpanded());
/* 290:    */       }
/* 291:    */     }
/* 292:    */   }
/* 293:    */   
/* 294:    */   class ToggleExpandedAction extends AbstractAction {
/* 295:    */     public ToggleExpandedAction() {
/* 296:296 */       super();
/* 297:    */     }
/* 298:    */     
/* 299:299 */     public void actionPerformed(ActionEvent e) { group.setExpanded(!group.isExpanded()); }
/* 300:    */     
/* 301:    */     public boolean isEnabled() {
/* 302:302 */       return (group.isVisible()) && (group.isCollapsable());
/* 303:    */     }
/* 304:    */   }
/* 305:    */   
/* 306:    */   protected static class ChevronIcon implements Icon {
/* 307:307 */     boolean up = true;
/* 308:    */     
/* 309:309 */     public ChevronIcon(boolean up) { this.up = up; }
/* 310:    */     
/* 311:    */     public int getIconHeight() {
/* 312:312 */       return 3;
/* 313:    */     }
/* 314:    */     
/* 315:315 */     public int getIconWidth() { return 6; }
/* 316:    */     
/* 317:    */     public void paintIcon(Component c, Graphics g, int x, int y) {
/* 318:318 */       if (up) {
/* 319:319 */         g.drawLine(x + 3, y, x, y + 3);
/* 320:320 */         g.drawLine(x + 3, y, x + 6, y + 3);
/* 321:    */       } else {
/* 322:322 */         g.drawLine(x, y, x + 3, y + 3);
/* 323:323 */         g.drawLine(x + 3, y + 3, x + 6, y);
/* 324:    */       }
/* 325:    */     }
/* 326:    */   }
/* 327:    */   
/* 328:    */   protected static class ContentPaneBorder implements Border
/* 329:    */   {
/* 330:    */     Color color;
/* 331:    */     
/* 332:    */     public ContentPaneBorder(Color color)
/* 333:    */     {
/* 334:334 */       this.color = color;
/* 335:    */     }
/* 336:    */     
/* 337:337 */     public Insets getBorderInsets(Component c) { return new Insets(0, 1, 1, 1); }
/* 338:    */     
/* 339:    */ 
/* 340:340 */     public boolean isBorderOpaque() { return true; }
/* 341:    */     
/* 342:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
/* 343:343 */       g.setColor(color);
/* 344:344 */       g.drawLine(x, y, x, y + height - 1);
/* 345:345 */       g.drawLine(x, y + height - 1, x + width - 1, y + height - 1);
/* 346:346 */       g.drawLine(x + width - 1, y, x + width - 1, y + height - 1);
/* 347:    */     }
/* 348:    */   }
/* 349:    */   
/* 350:    */ 
/* 351:    */   protected class PaneBorder
/* 352:    */     implements Border
/* 353:    */   {
/* 354:    */     protected Color borderColor;
/* 355:    */     
/* 356:    */     protected Color titleForeground;
/* 357:    */     
/* 358:    */     protected Color specialTitleBackground;
/* 359:    */     
/* 360:    */     protected Color specialTitleForeground;
/* 361:    */     
/* 362:    */     protected Color titleBackgroundGradientStart;
/* 363:    */     protected Color titleBackgroundGradientEnd;
/* 364:    */     protected Color titleOver;
/* 365:    */     protected Color specialTitleOver;
/* 366:    */     protected JLabel label;
/* 367:    */     
/* 368:    */     public PaneBorder()
/* 369:    */     {
/* 370:370 */       borderColor = UIManager.getColor("TaskPaneGroup.borderColor");
/* 371:    */       
/* 372:372 */       titleForeground = UIManager.getColor("TaskPaneGroup.titleForeground");
/* 373:    */       
/* 374:374 */       specialTitleBackground = UIManager.getColor("TaskPaneGroup.specialTitleBackground");
/* 375:    */       
/* 376:376 */       specialTitleForeground = UIManager.getColor("TaskPaneGroup.specialTitleForeground");
/* 377:    */       
/* 378:    */ 
/* 379:379 */       titleBackgroundGradientStart = UIManager.getColor("TaskPaneGroup.titleBackgroundGradientStart");
/* 380:    */       
/* 381:381 */       titleBackgroundGradientEnd = UIManager.getColor("TaskPaneGroup.titleBackgroundGradientEnd");
/* 382:    */       
/* 383:    */ 
/* 384:384 */       titleOver = UIManager.getColor("TaskPaneGroup.titleOver");
/* 385:385 */       if (titleOver == null) {
/* 386:386 */         titleOver = specialTitleBackground.brighter();
/* 387:    */       }
/* 388:388 */       specialTitleOver = UIManager.getColor("TaskPaneGroup.specialTitleOver");
/* 389:389 */       if (specialTitleOver == null) {
/* 390:390 */         specialTitleOver = specialTitleBackground.brighter();
/* 391:    */       }
/* 392:    */       
/* 393:393 */       label = new JLabel();
/* 394:394 */       label.setOpaque(false);
/* 395:395 */       label.setIconTextGap(8);
/* 396:    */     }
/* 397:    */     
/* 398:    */     public Insets getBorderInsets(Component c) {
/* 399:399 */       return new Insets(getTitleHeight(), 0, 0, 0);
/* 400:    */     }
/* 401:    */     
/* 402:    */     public boolean isBorderOpaque() {
/* 403:403 */       return true;
/* 404:    */     }
/* 405:    */     
/* 406:    */ 
/* 407:    */ 
/* 408:    */ 
/* 409:    */ 
/* 410:    */     public Dimension getPreferredSize(JTaskPaneGroup group)
/* 411:    */     {
/* 412:412 */       configureLabel(group);
/* 413:413 */       Dimension dim = label.getPreferredSize();
/* 414:    */       
/* 415:415 */       width += 3;
/* 416:    */       
/* 417:417 */       width += BasicTaskPaneGroupUI.TITLE_HEIGHT;
/* 418:    */       
/* 419:419 */       width += 3;
/* 420:    */       
/* 421:421 */       height = getTitleHeight();
/* 422:422 */       return dim;
/* 423:    */     }
/* 424:    */     
/* 425:    */     protected void paintTitleBackground(JTaskPaneGroup group, Graphics g) {
/* 426:426 */       if (group.isSpecial()) {
/* 427:427 */         g.setColor(specialTitleBackground);
/* 428:    */       } else {
/* 429:429 */         g.setColor(titleBackgroundGradientStart);
/* 430:    */       }
/* 431:431 */       g.fillRect(0, 0, group.getWidth(), getTitleHeight() - 1);
/* 432:    */     }
/* 433:    */     
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:    */ 
/* 438:    */ 
/* 439:    */ 
/* 440:    */     protected void paintTitle(JTaskPaneGroup group, Graphics g, Color textColor, int x, int y, int width, int height)
/* 441:    */     {
/* 442:442 */       configureLabel(group);
/* 443:443 */       label.setForeground(textColor);
/* 444:444 */       g.translate(x, y);
/* 445:445 */       label.setBounds(0, 0, width, height);
/* 446:446 */       label.paint(g);
/* 447:447 */       g.translate(-x, -y);
/* 448:    */     }
/* 449:    */     
/* 450:    */     protected void configureLabel(JTaskPaneGroup group) {
/* 451:451 */       label.applyComponentOrientation(group.getComponentOrientation());
/* 452:452 */       label.setFont(group.getFont());
/* 453:453 */       label.setText(group.getTitle());
/* 454:454 */       label.setIcon(group.getIcon() == null ? new EmptyIcon() : group.getIcon());
/* 455:    */     }
/* 456:    */     
/* 457:    */     protected void paintExpandedControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height) {}
/* 458:    */     
/* 459:    */     protected Color getPaintColor(JTaskPaneGroup group)
/* 460:    */     {
/* 461:    */       Color paintColor;
/* 462:    */       Color paintColor;
/* 463:463 */       if (isMouseOverBorder()) { Color paintColor;
/* 464:464 */         if (mouseOver) { Color paintColor;
/* 465:465 */           if (group.isSpecial()) {
/* 466:466 */             paintColor = specialTitleOver;
/* 467:    */           } else
/* 468:468 */             paintColor = titleOver;
/* 469:    */         } else {
/* 470:    */           Color paintColor;
/* 471:471 */           if (group.isSpecial()) {
/* 472:472 */             paintColor = specialTitleForeground;
/* 473:    */           } else
/* 474:474 */             paintColor = titleForeground;
/* 475:    */         }
/* 476:    */       } else {
/* 477:    */         Color paintColor;
/* 478:478 */         if (group.isSpecial()) {
/* 479:479 */           paintColor = specialTitleForeground;
/* 480:    */         } else {
/* 481:481 */           paintColor = titleForeground;
/* 482:    */         }
/* 483:    */       }
/* 484:484 */       return paintColor;
/* 485:    */     }
/* 486:    */     
/* 487:    */ 
/* 488:    */ 
/* 489:    */ 
/* 490:    */ 
/* 491:    */ 
/* 492:    */ 
/* 493:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 494:    */     {
/* 495:495 */       JTaskPaneGroup group = (JTaskPaneGroup)c;
/* 496:    */       
/* 497:    */ 
/* 498:498 */       int controlWidth = BasicTaskPaneGroupUI.TITLE_HEIGHT - 2 * BasicTaskPaneGroupUI.ROUND_HEIGHT;
/* 499:    */       
/* 500:500 */       if (controlWidth % 2 != 0) { controlWidth++;
/* 501:    */       }
/* 502:502 */       int controlX = group.getWidth() - BasicTaskPaneGroupUI.TITLE_HEIGHT;
/* 503:503 */       int controlY = BasicTaskPaneGroupUI.ROUND_HEIGHT - 1;
/* 504:504 */       int titleX = 3;
/* 505:505 */       int titleY = 0;
/* 506:506 */       int titleWidth = group.getWidth() - getTitleHeight() - 3;
/* 507:507 */       int titleHeight = getTitleHeight();
/* 508:    */       
/* 509:509 */       if (!group.getComponentOrientation().isLeftToRight()) {
/* 510:510 */         controlX = group.getWidth() - controlX - controlWidth;
/* 511:511 */         titleX = group.getWidth() - titleX - titleWidth;
/* 512:    */       }
/* 513:    */       
/* 514:    */ 
/* 515:515 */       paintTitleBackground(group, g);
/* 516:    */       
/* 517:    */ 
/* 518:518 */       if (group.isCollapsable()) {
/* 519:519 */         paintExpandedControls(group, g, controlX, controlY, controlWidth, controlWidth);
/* 520:    */       }
/* 521:    */       
/* 522:    */ 
/* 523:    */ 
/* 524:524 */       Color paintColor = getPaintColor(group);
/* 525:    */       
/* 526:    */ 
/* 527:527 */       if (group.hasFocus()) {
/* 528:528 */         paintFocus(g, paintColor, 3, 3, width - 6, getTitleHeight() - 6);
/* 529:    */       }
/* 530:    */       
/* 531:    */ 
/* 532:    */ 
/* 533:    */ 
/* 534:    */ 
/* 535:    */ 
/* 536:536 */       paintTitle(group, g, paintColor, titleX, titleY, titleWidth, titleHeight);
/* 537:    */     }
/* 538:    */     
/* 539:    */ 
/* 540:    */ 
/* 541:    */ 
/* 542:    */ 
/* 543:    */ 
/* 544:    */ 
/* 545:    */ 
/* 546:    */     protected void paintRectAroundControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height, Color highColor, Color lowColor)
/* 547:    */     {
/* 548:548 */       if (mouseOver) {
/* 549:549 */         int x2 = x + width;
/* 550:550 */         int y2 = y + height;
/* 551:551 */         g.setColor(highColor);
/* 552:552 */         g.drawLine(x, y, x2, y);
/* 553:553 */         g.drawLine(x, y, x, y2);
/* 554:554 */         g.setColor(lowColor);
/* 555:555 */         g.drawLine(x2, y, x2, y2);
/* 556:556 */         g.drawLine(x, y2, x2, y2);
/* 557:    */       }
/* 558:    */     }
/* 559:    */     
/* 560:    */     protected void paintOvalAroundControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height)
/* 561:    */     {
/* 562:562 */       if (group.isSpecial()) {
/* 563:563 */         g.setColor(specialTitleBackground.brighter());
/* 564:564 */         g.drawOval(x, y, width, height);
/* 565:    */ 
/* 566:    */       }
/* 567:    */       else
/* 568:    */       {
/* 569:    */ 
/* 570:570 */         g.setColor(titleBackgroundGradientStart);
/* 571:571 */         g.fillOval(x, y, width, width);
/* 572:    */         
/* 573:    */ 
/* 574:    */ 
/* 575:    */ 
/* 576:    */ 
/* 577:577 */         g.setColor(titleBackgroundGradientEnd.darker());
/* 578:578 */         g.drawOval(x, y, width, width);
/* 579:    */       }
/* 580:    */     }
/* 581:    */     
/* 582:    */ 
/* 583:    */     protected void paintChevronControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height)
/* 584:    */     {
/* 585:    */       BasicTaskPaneGroupUI.ChevronIcon chevron;
/* 586:    */       
/* 587:    */       BasicTaskPaneGroupUI.ChevronIcon chevron;
/* 588:    */       
/* 589:589 */       if (group.isExpanded()) {
/* 590:590 */         chevron = new BasicTaskPaneGroupUI.ChevronIcon(true);
/* 591:    */       } else {
/* 592:592 */         chevron = new BasicTaskPaneGroupUI.ChevronIcon(false);
/* 593:    */       }
/* 594:594 */       int chevronX = x + width / 2 - chevron.getIconWidth() / 2;
/* 595:595 */       int chevronY = y + (height / 2 - chevron.getIconHeight()) - (group.isExpanded() ? 1 : 0);
/* 596:596 */       chevron.paintIcon(group, g, chevronX, chevronY);
/* 597:597 */       chevron.paintIcon(group, g, chevronX, chevronY + chevron.getIconHeight() + 1);
/* 598:    */     }
/* 599:    */     
/* 600:    */ 
/* 601:    */ 
/* 602:    */ 
/* 603:    */     protected void paintFocus(Graphics g, Color paintColor, int x, int y, int width, int height)
/* 604:    */     {
/* 605:605 */       g.setColor(paintColor);
/* 606:606 */       BasicGraphicsUtils.drawDashedRect(g, x, y, width, height);
/* 607:    */     }
/* 608:    */     
/* 609:    */ 
/* 610:    */ 
/* 611:    */ 
/* 612:    */ 
/* 613:    */ 
/* 614:    */ 
/* 615:    */ 
/* 616:    */ 
/* 617:    */ 
/* 618:    */ 
/* 619:    */     protected boolean isMouseOverBorder()
/* 620:    */     {
/* 621:621 */       return false;
/* 622:    */     }
/* 623:    */   }
/* 624:    */ }
