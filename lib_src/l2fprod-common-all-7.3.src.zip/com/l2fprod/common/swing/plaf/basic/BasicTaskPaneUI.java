/*  1:   */ package com.l2fprod.common.swing.plaf.basic;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JTaskPane;
/*  4:   */ import com.l2fprod.common.swing.PercentLayout;
/*  5:   */ import com.l2fprod.common.swing.plaf.TaskPaneUI;
/*  6:   */ import java.awt.Color;
/*  7:   */ import java.awt.GradientPaint;
/*  8:   */ import java.awt.Graphics;
/*  9:   */ import java.awt.Graphics2D;
/* 10:   */ import java.awt.Paint;
/* 11:   */ import javax.swing.BorderFactory;
/* 12:   */ import javax.swing.JComponent;
/* 13:   */ import javax.swing.UIManager;
/* 14:   */ import javax.swing.plaf.ColorUIResource;
/* 15:   */ import javax.swing.plaf.ComponentUI;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ public class BasicTaskPaneUI
/* 33:   */   extends TaskPaneUI
/* 34:   */ {
/* 35:   */   protected JTaskPane taskPane;
/* 36:   */   protected boolean useGradient;
/* 37:   */   protected Color gradientStart;
/* 38:   */   protected Color gradientEnd;
/* 39:   */   
/* 40:   */   public static ComponentUI createUI(JComponent c)
/* 41:   */   {
/* 42:42 */     return new BasicTaskPaneUI();
/* 43:   */   }
/* 44:   */   
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */   public void installUI(JComponent c)
/* 50:   */   {
/* 51:51 */     super.installUI(c);
/* 52:52 */     taskPane = ((JTaskPane)c);
/* 53:53 */     taskPane.setLayout(new PercentLayout(1, 14));
/* 54:54 */     taskPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
/* 55:55 */     taskPane.setOpaque(true);
/* 56:   */     
/* 57:57 */     if ((taskPane.getBackground() == null) || ((taskPane.getBackground() instanceof ColorUIResource)))
/* 58:   */     {
/* 59:59 */       taskPane.setBackground(UIManager.getColor("TaskPane.background"));
/* 60:   */     }
/* 61:   */     
/* 62:   */ 
/* 63:63 */     useGradient = UIManager.getBoolean("TaskPane.useGradient");
/* 64:64 */     if (useGradient) {
/* 65:65 */       gradientStart = UIManager.getColor("TaskPane.backgroundGradientStart");
/* 66:   */       
/* 67:67 */       gradientEnd = UIManager.getColor("TaskPane.backgroundGradientEnd");
/* 68:   */     }
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void paint(Graphics g, JComponent c)
/* 72:   */   {
/* 73:73 */     Graphics2D g2d = (Graphics2D)g;
/* 74:74 */     if (useGradient) {
/* 75:75 */       Paint old = g2d.getPaint();
/* 76:76 */       GradientPaint gradient = new GradientPaint(0.0F, 0.0F, gradientStart, 0.0F, c.getHeight(), gradientEnd);
/* 77:   */       
/* 78:78 */       g2d.setPaint(gradient);
/* 79:79 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/* 80:80 */       g2d.setPaint(old);
/* 81:   */     }
/* 82:   */   }
/* 83:   */ }
