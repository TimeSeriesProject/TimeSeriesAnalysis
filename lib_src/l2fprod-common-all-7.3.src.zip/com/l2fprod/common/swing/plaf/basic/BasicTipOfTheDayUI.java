/*   1:    */ package com.l2fprod.common.swing.plaf.basic;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.ButtonAreaLayout;
/*   4:    */ import com.l2fprod.common.swing.JTipOfTheDay;
/*   5:    */ import com.l2fprod.common.swing.JTipOfTheDay.ShowOnStartupChoice;
/*   6:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   7:    */ import com.l2fprod.common.swing.TipModel;
/*   8:    */ import com.l2fprod.common.swing.TipModel.Tip;
/*   9:    */ import com.l2fprod.common.swing.plaf.TipOfTheDayUI;
/*  10:    */ import java.awt.BorderLayout;
/*  11:    */ import java.awt.Component;
/*  12:    */ import java.awt.Container;
/*  13:    */ import java.awt.Dialog;
/*  14:    */ import java.awt.Dimension;
/*  15:    */ import java.awt.Font;
/*  16:    */ import java.awt.Frame;
/*  17:    */ import java.awt.Window;
/*  18:    */ import java.awt.event.ActionEvent;
/*  19:    */ import java.awt.event.ActionListener;
/*  20:    */ import java.awt.event.WindowAdapter;
/*  21:    */ import java.awt.event.WindowEvent;
/*  22:    */ import java.beans.PropertyChangeEvent;
/*  23:    */ import java.beans.PropertyChangeListener;
/*  24:    */ import javax.swing.AbstractAction;
/*  25:    */ import javax.swing.ActionMap;
/*  26:    */ import javax.swing.BorderFactory;
/*  27:    */ import javax.swing.Icon;
/*  28:    */ import javax.swing.JButton;
/*  29:    */ import javax.swing.JCheckBox;
/*  30:    */ import javax.swing.JComponent;
/*  31:    */ import javax.swing.JDialog;
/*  32:    */ import javax.swing.JEditorPane;
/*  33:    */ import javax.swing.JLabel;
/*  34:    */ import javax.swing.JOptionPane;
/*  35:    */ import javax.swing.JPanel;
/*  36:    */ import javax.swing.JRootPane;
/*  37:    */ import javax.swing.JScrollPane;
/*  38:    */ import javax.swing.JTextArea;
/*  39:    */ import javax.swing.JViewport;
/*  40:    */ import javax.swing.KeyStroke;
/*  41:    */ import javax.swing.LookAndFeel;
/*  42:    */ import javax.swing.SwingUtilities;
/*  43:    */ import javax.swing.UIManager;
/*  44:    */ import javax.swing.plaf.ActionMapUIResource;
/*  45:    */ import javax.swing.plaf.ComponentUI;
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ public class BasicTipOfTheDayUI
/*  56:    */   extends TipOfTheDayUI
/*  57:    */ {
/*  58:    */   protected JTipOfTheDay tipPane;
/*  59:    */   protected JPanel tipArea;
/*  60:    */   protected Component currentTipComponent;
/*  61:    */   protected Font tipFont;
/*  62:    */   protected PropertyChangeListener changeListener;
/*  63:    */   
/*  64:    */   public static ComponentUI createUI(JComponent c)
/*  65:    */   {
/*  66: 66 */     return new BasicTipOfTheDayUI((JTipOfTheDay)c);
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */   public BasicTipOfTheDayUI(JTipOfTheDay tipPane)
/*  76:    */   {
/*  77: 77 */     this.tipPane = tipPane;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public JDialog createDialog(Component parentComponent, JTipOfTheDay.ShowOnStartupChoice choice)
/*  81:    */   {
/*  82: 82 */     return createDialog(parentComponent, choice, true);
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected JDialog createDialog(Component parentComponent, JTipOfTheDay.ShowOnStartupChoice choice, boolean showPreviousButton)
/*  86:    */   {
/*  87: 87 */     String title = UIManager.getString("TipOfTheDay.dialogTitle");
/*  88:    */     
/*  89:    */     Window window;
/*  90:    */     
/*  91:    */     Window window;
/*  92: 92 */     if (parentComponent == null) {
/*  93: 93 */       window = JOptionPane.getRootFrame();
/*  94:    */     } else {
/*  95: 95 */       window = (parentComponent instanceof Window) ? (Window)parentComponent : SwingUtilities.getWindowAncestor(parentComponent);
/*  96:    */     }
/*  97:    */     JDialog dialog;
/*  98:    */     JDialog dialog;
/*  99: 99 */     if ((window instanceof Frame)) {
/* 100:100 */       dialog = new JDialog((Frame)window, title, true);
/* 101:    */     } else {
/* 102:102 */       dialog = new JDialog((Dialog)window, title, true);
/* 103:    */     }
/* 104:    */     
/* 105:105 */     dialog.getContentPane().setLayout(new BorderLayout(10, 10));
/* 106:106 */     dialog.getContentPane().add("Center", tipPane);
/* 107:107 */     ((JComponent)dialog.getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/* 108:    */     
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:113 */     JPanel controls = new JPanel(new BorderLayout());
/* 114:114 */     dialog.getContentPane().add("South", controls);
/* 115:    */     JCheckBox showOnStartupBox;
/* 116:116 */     if (choice != null) {
/* 117:117 */       JCheckBox showOnStartupBox = new JCheckBox(UIManager.getString("TipOfTheDay.showOnStartupText"), choice.isShowingOnStartup());
/* 118:    */       
/* 119:    */ 
/* 120:120 */       controls.add("Center", showOnStartupBox);
/* 121:    */     } else {
/* 122:122 */       showOnStartupBox = null;
/* 123:    */     }
/* 124:    */     
/* 125:125 */     JPanel buttons = new JPanel(new ButtonAreaLayout(9));
/* 126:126 */     controls.add("East", buttons);
/* 127:    */     
/* 128:128 */     if (showPreviousButton) {
/* 129:129 */       JButton previousTipButton = new JButton(UIManager.getString("TipOfTheDay.previousTipText"));
/* 130:    */       
/* 131:131 */       buttons.add(previousTipButton);
/* 132:132 */       previousTipButton.addActionListener(getActionMap().get("previousTip"));
/* 133:    */     }
/* 134:    */     
/* 135:135 */     JButton nextTipButton = new JButton(UIManager.getString("TipOfTheDay.nextTipText"));
/* 136:    */     
/* 137:137 */     buttons.add(nextTipButton);
/* 138:138 */     nextTipButton.addActionListener(getActionMap().get("nextTip"));
/* 139:    */     
/* 140:140 */     JButton closeButton = new JButton(UIManager.getString("TipOfTheDay.closeText"));
/* 141:    */     
/* 142:142 */     buttons.add(closeButton);
/* 143:    */     
/* 144:144 */     ActionListener saveChoice = new ActionListener() { private final JTipOfTheDay.ShowOnStartupChoice val$choice;
/* 145:    */       
/* 146:146 */       public void actionPerformed(ActionEvent e) { if (val$choice != null) {
/* 147:147 */           val$choice.setShowingOnStartup(val$showOnStartupBox.isSelected());
/* 148:    */         }
/* 149:149 */         val$dialog.setVisible(false);
/* 150:    */       }
/* 151:    */       
/* 152:152 */     };
/* 153:153 */     closeButton.addActionListener(new ActionListener() { private final JCheckBox val$showOnStartupBox;
/* 154:    */       
/* 155:155 */       public void actionPerformed(ActionEvent e) { val$dialog.setVisible(false);
/* 156:156 */         val$saveChoice.actionPerformed(null);
/* 157:    */       }
/* 158:158 */     });
/* 159:159 */     dialog.getRootPane().setDefaultButton(closeButton);
/* 160:    */     
/* 161:161 */     dialog.addWindowListener(new WindowAdapter() { private final JDialog val$dialog;
/* 162:    */       
/* 163:163 */       public void windowClosing(WindowEvent e) { val$saveChoice.actionPerformed(null);
/* 164:    */       }
/* 165:    */ 
/* 166:166 */     });
/* 167:167 */     ((JComponent)dialog.getContentPane()).registerKeyboardAction(saveChoice, KeyStroke.getKeyStroke(27, 0), 2);
/* 168:    */     
/* 169:    */ 
/* 170:    */ 
/* 171:171 */     dialog.pack();
/* 172:172 */     dialog.setLocationRelativeTo(parentComponent);
/* 173:    */     
/* 174:174 */     return dialog;
/* 175:    */   }
/* 176:    */   
/* 177:    */   private final JDialog val$dialog;
/* 178:178 */   public void installUI(JComponent c) { super.installUI(c);
/* 179:179 */     installDefaults();
/* 180:180 */     installKeyboardActions();
/* 181:181 */     installComponents();
/* 182:182 */     installListeners();
/* 183:    */     
/* 184:184 */     showCurrentTip();
/* 185:    */   }
/* 186:    */   
/* 187:    */   protected void installKeyboardActions() {
/* 188:188 */     ActionMap map = getActionMap();
/* 189:189 */     if (map != null) {
/* 190:190 */       SwingUtilities.replaceUIActionMap(tipPane, map);
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   ActionMap getActionMap() {
/* 195:195 */     ActionMap map = new ActionMapUIResource();
/* 196:196 */     map.put("previousTip", new PreviousTipAction());
/* 197:197 */     map.put("nextTip", new NextTipAction());
/* 198:198 */     return map;
/* 199:    */   }
/* 200:    */   
/* 201:    */   protected void installListeners() {
/* 202:202 */     changeListener = createChangeListener();
/* 203:203 */     tipPane.addPropertyChangeListener(changeListener);
/* 204:    */   }
/* 205:    */   
/* 206:    */   protected PropertyChangeListener createChangeListener() {
/* 207:207 */     return new ChangeListener();
/* 208:    */   }
/* 209:    */   
/* 210:    */   protected void installDefaults() {
/* 211:211 */     LookAndFeel.installColorsAndFont(tipPane, "TipOfTheDay.background", "TipOfTheDay.foreground", "TipOfTheDay.font");
/* 212:    */     
/* 213:213 */     LookAndFeel.installBorder(tipPane, "TipOfTheDay.border");
/* 214:214 */     tipFont = UIManager.getFont("TipOfTheDay.tipFont");
/* 215:215 */     tipPane.setOpaque(true);
/* 216:    */   }
/* 217:    */   
/* 218:    */   protected void installComponents() {
/* 219:219 */     tipPane.setLayout(new BorderLayout());
/* 220:    */     
/* 221:    */ 
/* 222:222 */     JLabel tipIcon = new JLabel(UIManager.getString("TipOfTheDay.didYouKnowText"));
/* 223:    */     
/* 224:224 */     tipIcon.setIcon(UIManager.getIcon("TipOfTheDay.icon"));
/* 225:225 */     tipIcon.setBorder(BorderFactory.createEmptyBorder(22, 15, 22, 15));
/* 226:226 */     tipPane.add("North", tipIcon);
/* 227:    */     
/* 228:    */ 
/* 229:229 */     tipArea = new JPanel(new BorderLayout(2, 2));
/* 230:230 */     tipArea.setOpaque(false);
/* 231:231 */     tipArea.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
/* 232:232 */     tipPane.add("Center", tipArea);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public Dimension getPreferredSize(JComponent c) {
/* 236:236 */     return new Dimension(420, 175);
/* 237:    */   }
/* 238:    */   
/* 239:    */   protected void showCurrentTip() {
/* 240:240 */     if (currentTipComponent != null) {
/* 241:241 */       tipArea.remove(currentTipComponent);
/* 242:    */     }
/* 243:    */     
/* 244:244 */     int currentTip = tipPane.getCurrentTip();
/* 245:245 */     if (currentTip == -1) {
/* 246:246 */       JLabel label = new JLabel();
/* 247:247 */       label.setOpaque(true);
/* 248:248 */       label.setBackground(UIManager.getColor("TextArea.background"));
/* 249:249 */       currentTipComponent = label;
/* 250:250 */       tipArea.add("Center", currentTipComponent);
/* 251:251 */       return;
/* 252:    */     }
/* 253:    */     
/* 254:    */ 
/* 255:255 */     if ((tipPane.getModel().getTipCount() == 0) || ((currentTip < 0) && (currentTip >= tipPane.getModel().getTipCount())))
/* 256:    */     {
/* 257:257 */       currentTipComponent = new JLabel();
/* 258:    */     } else {
/* 259:259 */       TipModel.Tip tip = tipPane.getModel().getTipAt(currentTip);
/* 260:    */       
/* 261:261 */       Object tipObject = tip.getTip();
/* 262:262 */       if ((tipObject instanceof Component)) {
/* 263:263 */         currentTipComponent = ((Component)tipObject);
/* 264:264 */       } else if ((tipObject instanceof Icon)) {
/* 265:265 */         currentTipComponent = new JLabel((Icon)tipObject);
/* 266:    */       } else {
/* 267:267 */         JScrollPane tipScroll = new JScrollPane();
/* 268:268 */         tipScroll.setBorder(null);
/* 269:269 */         tipScroll.setOpaque(false);
/* 270:270 */         tipScroll.getViewport().setOpaque(false);
/* 271:271 */         tipScroll.setBorder(null);
/* 272:    */         
/* 273:273 */         String text = tipObject == null ? "" : tipObject.toString();
/* 274:    */         
/* 275:275 */         if (text.toLowerCase().startsWith("<html>")) {
/* 276:276 */           JEditorPane editor = new JEditorPane("text/html", text);
/* 277:277 */           LookAndFeelTweaks.htmlize(editor, tipPane.getFont());
/* 278:278 */           editor.setEditable(false);
/* 279:279 */           editor.setBorder(null);
/* 280:280 */           editor.setMargin(null);
/* 281:281 */           editor.setOpaque(false);
/* 282:282 */           tipScroll.getViewport().setView(editor);
/* 283:    */         } else {
/* 284:284 */           JTextArea area = new JTextArea(text);
/* 285:285 */           area.setFont(tipPane.getFont());
/* 286:286 */           area.setEditable(false);
/* 287:287 */           area.setLineWrap(true);
/* 288:288 */           area.setWrapStyleWord(true);
/* 289:289 */           area.setBorder(null);
/* 290:290 */           area.setMargin(null);
/* 291:291 */           area.setOpaque(false);
/* 292:292 */           tipScroll.getViewport().setView(area);
/* 293:    */         }
/* 294:    */         
/* 295:295 */         currentTipComponent = tipScroll;
/* 296:    */       }
/* 297:    */     }
/* 298:    */     
/* 299:299 */     tipArea.add("Center", currentTipComponent);
/* 300:300 */     tipArea.revalidate();
/* 301:301 */     tipArea.repaint();
/* 302:    */   }
/* 303:    */   
/* 304:    */   public void uninstallUI(JComponent c) {
/* 305:305 */     uninstallListeners();
/* 306:306 */     uninstallComponents();
/* 307:307 */     uninstallDefaults();
/* 308:308 */     super.uninstallUI(c); }
/* 309:    */   
/* 310:    */   private final ActionListener val$saveChoice;
/* 311:    */   private final ActionListener val$saveChoice;
/* 312:312 */   protected void uninstallListeners() { tipPane.removePropertyChangeListener(changeListener); }
/* 313:    */   
/* 314:    */   protected void uninstallComponents() {}
/* 315:    */   
/* 316:    */   protected void uninstallDefaults() {}
/* 317:    */   
/* 318:    */   class ChangeListener implements PropertyChangeListener {
/* 319:    */     ChangeListener() {}
/* 320:    */     
/* 321:321 */     public void propertyChange(PropertyChangeEvent evt) { if ("currentTip".equals(evt.getPropertyName())) {
/* 322:322 */         showCurrentTip();
/* 323:    */       }
/* 324:    */     }
/* 325:    */   }
/* 326:    */   
/* 327:    */   class PreviousTipAction extends AbstractAction {
/* 328:    */     public PreviousTipAction() {
/* 329:329 */       super();
/* 330:    */     }
/* 331:    */     
/* 332:332 */     public void actionPerformed(ActionEvent e) { tipPane.previousTip(); }
/* 333:    */     
/* 334:    */     public boolean isEnabled() {
/* 335:335 */       return tipPane.isEnabled();
/* 336:    */     }
/* 337:    */   }
/* 338:    */   
/* 339:    */   class NextTipAction extends AbstractAction {
/* 340:    */     public NextTipAction() {
/* 341:341 */       super();
/* 342:    */     }
/* 343:    */     
/* 344:344 */     public void actionPerformed(ActionEvent e) { tipPane.nextTip(); }
/* 345:    */     
/* 346:    */     public boolean isEnabled() {
/* 347:347 */       return tipPane.isEnabled();
/* 348:    */     }
/* 349:    */   }
/* 350:    */ }
