/*   1:    */ package com.l2fprod.common.swing.plaf.basic;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JOutlookBar;
/*   4:    */ import com.l2fprod.common.swing.PercentLayout;
/*   5:    */ import com.l2fprod.common.swing.PercentLayoutAnimator;
/*   6:    */ import com.l2fprod.common.swing.plaf.OutlookBarUI;
/*   7:    */ import com.l2fprod.common.util.JVM;
/*   8:    */ import java.awt.BorderLayout;
/*   9:    */ import java.awt.Color;
/*  10:    */ import java.awt.Component;
/*  11:    */ import java.awt.Container;
/*  12:    */ import java.awt.Dimension;
/*  13:    */ import java.awt.Font;
/*  14:    */ import java.awt.FontMetrics;
/*  15:    */ import java.awt.Graphics;
/*  16:    */ import java.awt.KeyboardFocusManager;
/*  17:    */ import java.awt.Rectangle;
/*  18:    */ import java.awt.event.ActionEvent;
/*  19:    */ import java.awt.event.ActionListener;
/*  20:    */ import java.awt.event.ContainerAdapter;
/*  21:    */ import java.awt.event.ContainerEvent;
/*  22:    */ import java.awt.event.ContainerListener;
/*  23:    */ import java.awt.event.MouseAdapter;
/*  24:    */ import java.awt.event.MouseListener;
/*  25:    */ import java.beans.PropertyChangeEvent;
/*  26:    */ import java.beans.PropertyChangeListener;
/*  27:    */ import java.util.ArrayList;
/*  28:    */ import java.util.HashMap;
/*  29:    */ import java.util.Iterator;
/*  30:    */ import java.util.List;
/*  31:    */ import java.util.Map;
/*  32:    */ import javax.swing.BorderFactory;
/*  33:    */ import javax.swing.Icon;
/*  34:    */ import javax.swing.JButton;
/*  35:    */ import javax.swing.JComponent;
/*  36:    */ import javax.swing.JPanel;
/*  37:    */ import javax.swing.JScrollPane;
/*  38:    */ import javax.swing.JTabbedPane;
/*  39:    */ import javax.swing.JViewport;
/*  40:    */ import javax.swing.LookAndFeel;
/*  41:    */ import javax.swing.Scrollable;
/*  42:    */ import javax.swing.SwingUtilities;
/*  43:    */ import javax.swing.event.ChangeEvent;
/*  44:    */ import javax.swing.event.ChangeListener;
/*  45:    */ import javax.swing.plaf.ButtonUI;
/*  46:    */ import javax.swing.plaf.ComponentUI;
/*  47:    */ import javax.swing.plaf.UIResource;
/*  48:    */ import javax.swing.plaf.basic.BasicTabbedPaneUI;
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ public class BasicOutlookBarUI
/*  66:    */   extends BasicTabbedPaneUI
/*  67:    */   implements OutlookBarUI
/*  68:    */ {
/*  69:    */   private static final String BUTTON_ORIGINAL_FOREGROUND = "TabButton/foreground";
/*  70:    */   private static final String BUTTON_ORIGINAL_BACKGROUND = "TabButton/background";
/*  71:    */   private ContainerListener tabListener;
/*  72:    */   private Map buttonToTab;
/*  73:    */   private Map tabToButton;
/*  74:    */   private Component nextVisibleComponent;
/*  75:    */   private PercentLayoutAnimator animator;
/*  76:    */   
/*  77:    */   public static ComponentUI createUI(JComponent c)
/*  78:    */   {
/*  79: 79 */     return new BasicOutlookBarUI();
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   public JScrollPane makeScrollPane(Component component)
/*  89:    */   {
/*  90: 90 */     JScrollPane scroll = new JScrollPane();
/*  91: 91 */     scroll.setBorder(BorderFactory.createEmptyBorder());
/*  92: 92 */     if ((component instanceof Scrollable)) {
/*  93: 93 */       scroll.getViewport().setView(component);
/*  94:    */     } else {
/*  95: 95 */       scroll.getViewport().setView(new ScrollableJPanel(component));
/*  96:    */     }
/*  97: 97 */     scroll.setOpaque(false);
/*  98: 98 */     scroll.getViewport().setOpaque(false);
/*  99: 99 */     return scroll;
/* 100:    */   }
/* 101:    */   
/* 102:    */   protected void installDefaults() {
/* 103:103 */     super.installDefaults();
/* 104:    */     
/* 105:105 */     TabLayout layout = new TabLayout();
/* 106:106 */     tabPane.setLayout(layout);
/* 107:    */     
/* 108:108 */     layout.setLayoutConstraints(tabPane);
/* 109:109 */     updateTabLayoutOrientation();
/* 110:    */     
/* 111:111 */     buttonToTab = new HashMap();
/* 112:112 */     tabToButton = new HashMap();
/* 113:    */     
/* 114:114 */     LookAndFeel.installBorder(tabPane, "OutlookBar.border");
/* 115:115 */     LookAndFeel.installColors(tabPane, "OutlookBar.background", "OutlookBar.foreground");
/* 116:    */     
/* 117:    */ 
/* 118:118 */     tabPane.setOpaque(true);
/* 119:    */     
/* 120:    */ 
/* 121:121 */     Component[] components = tabPane.getComponents();
/* 122:122 */     int i = 0; for (int c = components.length; i < c; i++) {
/* 123:123 */       tabAdded(components[i]);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected void uninstallDefaults()
/* 128:    */   {
/* 129:129 */     List tabs = new ArrayList(buttonToTab.values());
/* 130:130 */     for (Iterator iter = tabs.iterator(); iter.hasNext();) {
/* 131:131 */       Component tab = (Component)iter.next();
/* 132:132 */       tabRemoved(tab);
/* 133:    */     }
/* 134:134 */     super.uninstallDefaults();
/* 135:    */   }
/* 136:    */   
/* 137:    */   protected void installListeners() {
/* 138:138 */     tabPane.addContainerListener(this.tabListener = createTabListener());
/* 139:139 */     tabPane.addPropertyChangeListener(this.propertyChangeListener = createPropertyChangeListener());
/* 140:140 */     tabPane.addChangeListener(this.tabChangeListener = createChangeListener());
/* 141:    */   }
/* 142:    */   
/* 143:    */   protected ContainerListener createTabListener() {
/* 144:144 */     return new ContainerTabHandler();
/* 145:    */   }
/* 146:    */   
/* 147:    */   protected PropertyChangeListener createPropertyChangeListener() {
/* 148:148 */     return new PropertyChangeHandler();
/* 149:    */   }
/* 150:    */   
/* 151:    */   protected ChangeListener createChangeListener() {
/* 152:152 */     return new ChangeHandler();
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected void uninstallListeners() {
/* 156:156 */     tabPane.removeChangeListener(tabChangeListener);
/* 157:157 */     tabPane.removePropertyChangeListener(propertyChangeListener);
/* 158:158 */     tabPane.removeContainerListener(tabListener);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public Rectangle getTabBounds(JTabbedPane pane, int index) {
/* 162:162 */     Component tab = pane.getComponentAt(index);
/* 163:163 */     return tab.getBounds();
/* 164:    */   }
/* 165:    */   
/* 166:    */   public int getTabRunCount(JTabbedPane pane) {
/* 167:167 */     return 0;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public int tabForCoordinate(JTabbedPane pane, int x, int y) {
/* 171:171 */     int index = -1;
/* 172:172 */     int i = 0; for (int c = pane.getTabCount(); i < c; i++) {
/* 173:173 */       if (pane.getComponentAt(i).contains(x, y)) {
/* 174:174 */         index = i;
/* 175:175 */         break;
/* 176:    */       }
/* 177:    */     }
/* 178:178 */     return index;
/* 179:    */   }
/* 180:    */   
/* 181:    */   protected int indexOfComponent(Component component) {
/* 182:182 */     int index = -1;
/* 183:183 */     Component[] components = tabPane.getComponents();
/* 184:184 */     for (int i = 0; i < components.length; i++) {
/* 185:185 */       if (components[i] == component) {
/* 186:186 */         index = i;
/* 187:187 */         break;
/* 188:    */       }
/* 189:    */     }
/* 190:190 */     return index;
/* 191:    */   }
/* 192:    */   
/* 193:    */   protected TabButton createTabButton() {
/* 194:194 */     TabButton button = new TabButton();
/* 195:195 */     button.setOpaque(true);
/* 196:196 */     return button;
/* 197:    */   }
/* 198:    */   
/* 199:    */   protected void tabAdded(Component newTab) {
/* 200:200 */     TabButton button = (TabButton)tabToButton.get(newTab);
/* 201:201 */     if (button == null) {
/* 202:202 */       button = createTabButton();
/* 203:    */       
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:207 */       button.putClientProperty("TabButton/foreground", button.getForeground());
/* 208:208 */       button.putClientProperty("TabButton/background", button.getBackground());
/* 209:    */       
/* 210:210 */       buttonToTab.put(button, newTab);
/* 211:211 */       tabToButton.put(newTab, button);
/* 212:212 */       button.addActionListener(new ActionListener() { private final Component val$newTab;
/* 213:    */         
/* 214:214 */         public void actionPerformed(ActionEvent e) { Component current = getVisibleComponent();
/* 215:215 */           Component target = val$newTab;
/* 216:    */           
/* 217:    */ 
/* 218:    */ 
/* 219:219 */           if ((((JOutlookBar)tabPane).isAnimated()) && (current != target) && (current != null) && (target != null))
/* 220:    */           {
/* 221:221 */             if (animator != null) {
/* 222:222 */               animator.stop();
/* 223:    */             }
/* 224:224 */             animator = new BasicOutlookBarUI.2(this, tabPane, (PercentLayout)tabPane.getLayout(), current);
/* 225:    */             
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:239 */             nextVisibleComponent = val$newTab;
/* 240:240 */             animator.setTargetPercent(current, 1.0F, 0.0F);
/* 241:241 */             animator.setTargetPercent(val$newTab, 0.0F, 1.0F);
/* 242:242 */             animator.start();
/* 243:    */           } else {
/* 244:244 */             nextVisibleComponent = null;
/* 245:245 */             tabPane.setSelectedComponent(val$newTab);
/* 246:    */           }
/* 247:    */         }
/* 248:    */       });
/* 249:    */     }
/* 250:    */     else
/* 251:    */     {
/* 252:252 */       tabPane.remove(button);
/* 253:    */     }
/* 254:    */     
/* 255:    */ 
/* 256:256 */     updateTabButtonAt(tabPane.indexOfComponent(newTab));
/* 257:    */     
/* 258:258 */     int index = indexOfComponent(newTab);
/* 259:259 */     tabPane.add(button, index);
/* 260:    */     
/* 261:    */ 
/* 262:    */ 
/* 263:263 */     if (JVM.current().isOneDotFive()) {
/* 264:264 */       assureRectsCreated(tabPane.getTabCount());
/* 265:    */     }
/* 266:    */   }
/* 267:    */   
/* 268:    */   protected void tabRemoved(Component removedTab) {
/* 269:269 */     TabButton button = (TabButton)tabToButton.get(removedTab);
/* 270:270 */     tabPane.remove(button);
/* 271:271 */     buttonToTab.remove(button);
/* 272:272 */     tabToButton.remove(removedTab);
/* 273:    */   }
/* 274:    */   
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */   protected void updateTabButtonAt(int index)
/* 280:    */   {
/* 281:281 */     TabButton button = buttonForTab(index);
/* 282:282 */     button.setText(tabPane.getTitleAt(index));
/* 283:283 */     button.setIcon(tabPane.getIconAt(index));
/* 284:284 */     button.setDisabledIcon(tabPane.getDisabledIconAt(index));
/* 285:    */     
/* 286:286 */     Color background = tabPane.getBackgroundAt(index);
/* 287:287 */     if (background == null) {
/* 288:288 */       background = (Color)button.getClientProperty("TabButton/background");
/* 289:    */     }
/* 290:290 */     button.setBackground(background);
/* 291:    */     
/* 292:292 */     Color foreground = tabPane.getForegroundAt(index);
/* 293:293 */     if (foreground == null) {
/* 294:294 */       foreground = (Color)button.getClientProperty("TabButton/foreground");
/* 295:    */     }
/* 296:296 */     button.setForeground(foreground);
/* 297:    */     
/* 298:298 */     button.setToolTipText(tabPane.getToolTipTextAt(index));
/* 299:299 */     button.setDisplayedMnemonicIndex(tabPane.getDisplayedMnemonicIndexAt(index));
/* 300:    */     
/* 301:301 */     button.setMnemonic(tabPane.getMnemonicAt(index));
/* 302:302 */     button.setEnabled(tabPane.isEnabledAt(index));
/* 303:303 */     button.setHorizontalAlignment(((JOutlookBar)tabPane).getAlignmentAt(index));
/* 304:    */   }
/* 305:    */   
/* 306:    */   protected TabButton buttonForTab(int index) {
/* 307:307 */     Component component = tabPane.getComponentAt(index);
/* 308:308 */     return (TabButton)tabToButton.get(component);
/* 309:    */   }
/* 310:    */   
/* 311:    */   class ChangeHandler implements ChangeListener { ChangeHandler() {}
/* 312:    */     
/* 313:313 */     public void stateChanged(ChangeEvent e) { JTabbedPane tabPane = (JTabbedPane)e.getSource();
/* 314:314 */       tabPane.revalidate();
/* 315:315 */       tabPane.repaint();
/* 316:    */     }
/* 317:    */   }
/* 318:    */   
/* 319:    */   class PropertyChangeHandler implements PropertyChangeListener {
/* 320:    */     PropertyChangeHandler() {}
/* 321:    */     
/* 322:322 */     public void propertyChange(PropertyChangeEvent e) { String name = e.getPropertyName();
/* 323:323 */       if ("tabPropertyChangedAtIndex".equals(name)) {
/* 324:324 */         int index = ((Integer)e.getNewValue()).intValue();
/* 325:325 */         updateTabButtonAt(index);
/* 326:326 */       } else if ("tabPlacement".equals(name)) {
/* 327:327 */         updateTabLayoutOrientation();
/* 328:    */       }
/* 329:    */     }
/* 330:    */   }
/* 331:    */   
/* 332:    */   protected void updateTabLayoutOrientation() {
/* 333:333 */     TabLayout layout = (TabLayout)tabPane.getLayout();
/* 334:334 */     int placement = tabPane.getTabPlacement();
/* 335:335 */     if ((placement == 1) || (placement == 3)) {
/* 336:336 */       layout.setOrientation(0);
/* 337:    */     } else {
/* 338:338 */       layout.setOrientation(1);
/* 339:    */     }
/* 340:    */   }
/* 341:    */   
/* 342:    */   class ContainerTabHandler extends ContainerAdapter
/* 343:    */   {
/* 344:    */     ContainerTabHandler() {}
/* 345:    */     
/* 346:    */     public void componentAdded(ContainerEvent e)
/* 347:    */     {
/* 348:348 */       if (!(e.getChild() instanceof UIResource)) {
/* 349:349 */         Component newTab = e.getChild();
/* 350:350 */         tabAdded(newTab);
/* 351:    */       }
/* 352:    */     }
/* 353:    */     
/* 354:    */     public void componentRemoved(ContainerEvent e) {
/* 355:355 */       if (!(e.getChild() instanceof UIResource)) {
/* 356:356 */         Component oldTab = e.getChild();
/* 357:357 */         tabRemoved(oldTab);
/* 358:    */       }
/* 359:    */     }
/* 360:    */   }
/* 361:    */   
/* 362:    */   protected class TabLayout extends PercentLayout
/* 363:    */   {
/* 364:    */     protected TabLayout() {}
/* 365:    */     
/* 366:    */     public void addLayoutComponent(Component component, Object constraints) {
/* 367:367 */       if (constraints == null) {
/* 368:368 */         if ((component instanceof BasicOutlookBarUI.TabButton)) {
/* 369:369 */           super.addLayoutComponent(component, "");
/* 370:    */         } else {
/* 371:371 */           super.addLayoutComponent(component, "100%");
/* 372:    */         }
/* 373:    */       } else
/* 374:374 */         super.addLayoutComponent(component, constraints);
/* 375:    */     }
/* 376:    */     
/* 377:    */     public void setLayoutConstraints(Container parent) {
/* 378:378 */       Component[] components = parent.getComponents();
/* 379:379 */       int i = 0; for (int c = components.length; i < c; i++) {
/* 380:380 */         if (!(components[i] instanceof BasicOutlookBarUI.TabButton))
/* 381:381 */           super.addLayoutComponent(components[i], "100%");
/* 382:    */       }
/* 383:    */     }
/* 384:    */     
/* 385:    */     public void layoutContainer(Container parent) {
/* 386:386 */       int selectedIndex = tabPane.getSelectedIndex();
/* 387:387 */       Component visibleComponent = getVisibleComponent();
/* 388:    */       
/* 389:389 */       if (selectedIndex < 0) {
/* 390:390 */         if (visibleComponent != null)
/* 391:    */         {
/* 392:392 */           setVisibleComponent(null);
/* 393:    */         }
/* 394:    */       } else {
/* 395:395 */         Component selectedComponent = tabPane.getComponentAt(selectedIndex);
/* 396:396 */         boolean shouldChangeFocus = false;
/* 397:    */         
/* 398:    */ 
/* 399:    */ 
/* 400:    */ 
/* 401:    */ 
/* 402:    */ 
/* 403:    */ 
/* 404:    */ 
/* 405:405 */         if (selectedComponent != null) {
/* 406:406 */           if ((selectedComponent != visibleComponent) && (visibleComponent != null))
/* 407:    */           {
/* 408:408 */             Component currentFocusOwner = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/* 409:    */             
/* 410:    */ 
/* 411:411 */             if ((currentFocusOwner != null) && (SwingUtilities.isDescendingFrom(currentFocusOwner, visibleComponent)))
/* 412:    */             {
/* 413:    */ 
/* 414:414 */               shouldChangeFocus = true;
/* 415:    */             }
/* 416:    */           }
/* 417:417 */           setVisibleComponent(selectedComponent);
/* 418:    */           
/* 419:    */ 
/* 420:420 */           Component[] components = parent.getComponents();
/* 421:421 */           for (int i = 0; i < components.length; i++) {
/* 422:422 */             if ((!(components[i] instanceof UIResource)) && (components[i].isVisible()) && (components[i] != selectedComponent))
/* 423:    */             {
/* 424:    */ 
/* 425:425 */               components[i].setVisible(false);
/* 426:426 */               setConstraint(components[i], "*");
/* 427:    */             }
/* 428:    */           }
/* 429:    */           
/* 430:430 */           if (nextVisibleComponent != null) {
/* 431:431 */             nextVisibleComponent.setVisible(true);
/* 432:    */           }
/* 433:    */         }
/* 434:    */         
/* 435:435 */         super.layoutContainer(parent);
/* 436:    */         
/* 437:437 */         if ((shouldChangeFocus) && 
/* 438:438 */           (!requestFocusForVisibleComponent0())) {
/* 439:439 */           tabPane.requestFocus();
/* 440:    */         }
/* 441:    */       }
/* 442:    */     }
/* 443:    */   }
/* 444:    */   
/* 445:    */ 
/* 446:    */   protected boolean requestFocusForVisibleComponent0()
/* 447:    */   {
/* 448:448 */     Component visibleComponent = getVisibleComponent();
/* 449:449 */     if (visibleComponent.isFocusable()) {
/* 450:450 */       visibleComponent.requestFocus();
/* 451:451 */       return true; }
/* 452:452 */     if (((visibleComponent instanceof JComponent)) && 
/* 453:453 */       (((JComponent)visibleComponent).requestDefaultFocus())) { return true;
/* 454:    */     }
/* 455:455 */     return false;
/* 456:    */   }
/* 457:    */   
/* 458:    */   protected static class TabButton extends JButton implements UIResource {
/* 459:    */     public TabButton() {}
/* 460:    */     
/* 461:461 */     public TabButton(ButtonUI ui) { setUI(ui); }
/* 462:    */   }
/* 463:    */   
/* 464:    */ 
/* 465:    */ 
/* 466:    */ 
/* 467:    */ 
/* 468:    */ 
/* 469:    */ 
/* 470:    */ 
/* 471:    */ 
/* 472:    */ 
/* 473:    */ 
/* 474:474 */   protected MouseListener createMouseListener() { new MouseAdapter() {}; }
/* 475:    */   
/* 476:    */   public void paint(Graphics g, JComponent c) {}
/* 477:    */   
/* 478:    */   protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {}
/* 479:    */   
/* 480:    */   protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {}
/* 481:    */   
/* 482:    */   private static class ScrollableJPanel extends JPanel implements Scrollable {
/* 483:483 */     public ScrollableJPanel(Component component) { setLayout(new BorderLayout(0, 0));
/* 484:484 */       add("Center", component);
/* 485:485 */       setOpaque(false);
/* 486:    */     }
/* 487:    */     
/* 488:    */     public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
/* 489:489 */       return 16;
/* 490:    */     }
/* 491:    */     
/* 492:492 */     public Dimension getPreferredScrollableViewportSize() { return super.getPreferredSize(); }
/* 493:    */     
/* 494:    */     public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction)
/* 495:    */     {
/* 496:496 */       return 16;
/* 497:    */     }
/* 498:    */     
/* 499:499 */     public boolean getScrollableTracksViewportWidth() { return true; }
/* 500:    */     
/* 501:    */     public boolean getScrollableTracksViewportHeight() {
/* 502:502 */       return false;
/* 503:    */     }
/* 504:    */   }
/* 505:    */   
/* 506:    */   protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {}
/* 507:    */   
/* 508:    */   protected void paintContentBorderRightEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {}
/* 509:    */   
/* 510:    */   protected void paintContentBorderTopEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {}
/* 511:    */   
/* 512:    */   protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}
/* 513:    */   
/* 514:    */   protected void paintIcon(Graphics g, int tabPlacement, int tabIndex, Icon icon, Rectangle iconRect, boolean isSelected) {}
/* 515:    */   
/* 516:    */   protected void paintTab(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect) {}
/* 517:    */   
/* 518:    */   protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex) {}
/* 519:    */   
/* 520:    */   protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {}
/* 521:    */   
/* 522:    */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {}
/* 523:    */   
/* 524:    */   protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics, int tabIndex, String title, Rectangle textRect, boolean isSelected) {}
/* 525:    */ }
