/*   1:    */ package com.l2fprod.common.swing.plaf.basic;
/*   2:    */ 
/*   3:    */ import java.awt.AlphaComposite;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Composite;
/*   7:    */ import java.awt.Cursor;
/*   8:    */ import java.awt.Font;
/*   9:    */ import java.awt.FontMetrics;
/*  10:    */ import java.awt.Graphics;
/*  11:    */ import java.awt.Graphics2D;
/*  12:    */ import java.awt.Insets;
/*  13:    */ import java.awt.Rectangle;
/*  14:    */ import java.awt.event.MouseAdapter;
/*  15:    */ import java.awt.event.MouseEvent;
/*  16:    */ import java.awt.event.MouseListener;
/*  17:    */ import javax.swing.AbstractButton;
/*  18:    */ import javax.swing.ButtonModel;
/*  19:    */ import javax.swing.JComponent;
/*  20:    */ import javax.swing.JToolBar;
/*  21:    */ import javax.swing.SwingUtilities;
/*  22:    */ import javax.swing.UIManager;
/*  23:    */ import javax.swing.plaf.ComponentUI;
/*  24:    */ import javax.swing.plaf.basic.BasicButtonUI;
/*  25:    */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  26:    */ import javax.swing.text.View;
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ public class BasicLinkButtonUI
/*  39:    */   extends BasicButtonUI
/*  40:    */ {
/*  41:    */   public static ComponentUI createUI(JComponent c)
/*  42:    */   {
/*  43: 43 */     return new BasicLinkButtonUI();
/*  44:    */   }
/*  45:    */   
/*  46: 46 */   private static Rectangle viewRect = new Rectangle();
/*  47: 47 */   private static Rectangle textRect = new Rectangle();
/*  48: 48 */   private static Rectangle iconRect = new Rectangle();
/*  49: 49 */   private static MouseListener handCursorListener = new HandCursor();
/*  50:    */   protected int dashedRectGapX;
/*  51:    */   protected int dashedRectGapY;
/*  52:    */   protected int dashedRectGapWidth;
/*  53:    */   protected int dashedRectGapHeight;
/*  54:    */   private Color focusColor;
/*  55:    */   
/*  56:    */   protected void installDefaults(AbstractButton b)
/*  57:    */   {
/*  58: 58 */     super.installDefaults(b);
/*  59:    */     
/*  60: 60 */     b.setOpaque(false);
/*  61: 61 */     b.setBorderPainted(false);
/*  62: 62 */     b.setRolloverEnabled(true);
/*  63:    */     
/*  64: 64 */     dashedRectGapX = UIManager.getInt("ButtonUI.dashedRectGapX");
/*  65: 65 */     dashedRectGapY = UIManager.getInt("ButtonUI.dashedRectGapY");
/*  66: 66 */     dashedRectGapWidth = UIManager.getInt("ButtonUI.dashedRectGapWidth");
/*  67: 67 */     dashedRectGapHeight = UIManager.getInt("ButtonUI.dashedRectGapHeight");
/*  68: 68 */     focusColor = UIManager.getColor("ButtonUI.focus");
/*  69:    */     
/*  70: 70 */     b.setHorizontalAlignment(2);
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected void installListeners(AbstractButton b) {
/*  74: 74 */     super.installListeners(b);
/*  75: 75 */     b.addMouseListener(handCursorListener);
/*  76:    */   }
/*  77:    */   
/*  78:    */   protected void uninstallListeners(AbstractButton b) {
/*  79: 79 */     super.uninstallListeners(b);
/*  80: 80 */     b.removeMouseListener(handCursorListener);
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected Color getFocusColor() {
/*  84: 84 */     return focusColor;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void paint(Graphics g, JComponent c) {
/*  88: 88 */     AbstractButton b = (AbstractButton)c;
/*  89: 89 */     ButtonModel model = b.getModel();
/*  90:    */     
/*  91: 91 */     FontMetrics fm = g.getFontMetrics();
/*  92:    */     
/*  93: 93 */     Insets i = c.getInsets();
/*  94:    */     
/*  95: 95 */     viewRectx = left;
/*  96: 96 */     viewRecty = top;
/*  97: 97 */     viewRectwidth = (b.getWidth() - (right + viewRectx));
/*  98: 98 */     viewRectheight = (b.getHeight() - (bottom + viewRecty));
/*  99:    */     
/* 100:100 */     textRectx = (textRect.y = textRect.width = textRect.height = 0);
/* 101:101 */     iconRectx = (iconRect.y = iconRect.width = iconRect.height = 0);
/* 102:    */     
/* 103:103 */     Font f = c.getFont();
/* 104:104 */     g.setFont(f);
/* 105:    */     
/* 106:    */ 
/* 107:107 */     String text = SwingUtilities.layoutCompoundLabel(c, fm, b.getText(), b.getIcon(), b.getVerticalAlignment(), b.getHorizontalAlignment(), b.getVerticalTextPosition(), b.getHorizontalTextPosition(), viewRect, iconRect, textRect, b.getText() == null ? 0 : b.getIconTextGap());
/* 108:    */     
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:122 */     clearTextShiftOffset();
/* 123:    */     
/* 124:    */ 
/* 125:125 */     if ((model.isArmed()) && (model.isPressed())) {
/* 126:126 */       paintButtonPressed(g, b);
/* 127:    */     }
/* 128:    */     
/* 129:    */ 
/* 130:130 */     if (b.getIcon() != null) {
/* 131:131 */       paintIcon(g, c, iconRect);
/* 132:    */     }
/* 133:    */     
/* 134:134 */     Composite oldComposite = ((Graphics2D)g).getComposite();
/* 135:    */     
/* 136:136 */     if (model.isRollover()) {
/* 137:137 */       ((Graphics2D)g).setComposite(AlphaComposite.getInstance(3, 0.5F));
/* 138:    */     }
/* 139:    */     
/* 140:    */ 
/* 141:141 */     if ((text != null) && (!text.equals(""))) {
/* 142:142 */       View v = (View)c.getClientProperty("html");
/* 143:143 */       if (v != null) {
/* 144:144 */         textRectx += getTextShiftOffset();
/* 145:145 */         textRecty += getTextShiftOffset();
/* 146:146 */         v.paint(g, textRect);
/* 147:147 */         textRectx -= getTextShiftOffset();
/* 148:148 */         textRecty -= getTextShiftOffset();
/* 149:    */       } else {
/* 150:150 */         paintText(g, b, textRect, text);
/* 151:    */       }
/* 152:    */     }
/* 153:    */     
/* 154:154 */     if ((b.isFocusPainted()) && (b.hasFocus()))
/* 155:    */     {
/* 156:156 */       paintFocus(g, b, viewRect, textRect, iconRect);
/* 157:    */     }
/* 158:    */     
/* 159:159 */     ((Graphics2D)g).setComposite(oldComposite);
/* 160:    */   }
/* 161:    */   
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */   protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect)
/* 167:    */   {
/* 168:168 */     if ((b.getParent() instanceof JToolBar))
/* 169:    */     {
/* 170:170 */       return;
/* 171:    */     }
/* 172:    */     
/* 173:    */ 
/* 174:174 */     int width = b.getWidth();
/* 175:175 */     int height = b.getHeight();
/* 176:176 */     g.setColor(getFocusColor());
/* 177:177 */     BasicGraphicsUtils.drawDashedRect(g, dashedRectGapX, dashedRectGapY, width - dashedRectGapWidth, height - dashedRectGapHeight);
/* 178:    */   }
/* 179:    */   
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */   protected void paintButtonPressed(Graphics g, AbstractButton b)
/* 185:    */   {
/* 186:186 */     setTextShiftOffset();
/* 187:    */   }
/* 188:    */   
/* 189:    */   static class HandCursor extends MouseAdapter {
/* 190:    */     public void mouseEntered(MouseEvent e) {
/* 191:191 */       e.getComponent().setCursor(Cursor.getPredefinedCursor(12));
/* 192:    */     }
/* 193:    */     
/* 194:    */     public void mouseExited(MouseEvent e) {
/* 195:195 */       e.getComponent().setCursor(Cursor.getDefaultCursor());
/* 196:    */     }
/* 197:    */   }
/* 198:    */ }
