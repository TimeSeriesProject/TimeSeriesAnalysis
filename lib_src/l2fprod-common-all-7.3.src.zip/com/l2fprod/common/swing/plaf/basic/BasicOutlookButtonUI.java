/*  1:   */ package com.l2fprod.common.swing.plaf.basic;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.border.ButtonBorder;
/*  4:   */ import com.l2fprod.common.swing.border.FourLineBorder;
/*  5:   */ import java.awt.Color;
/*  6:   */ import java.awt.Component;
/*  7:   */ import java.awt.Graphics;
/*  8:   */ import java.awt.Insets;
/*  9:   */ import javax.swing.AbstractButton;
/* 10:   */ import javax.swing.JComponent;
/* 11:   */ import javax.swing.LookAndFeel;
/* 12:   */ import javax.swing.plaf.ComponentUI;
/* 13:   */ import javax.swing.plaf.basic.BasicButtonUI;
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ public class BasicOutlookButtonUI
/* 37:   */   extends BasicButtonUI
/* 38:   */ {
/* 39:   */   public static ComponentUI createUI(JComponent c)
/* 40:   */   {
/* 41:41 */     return new BasicOutlookButtonUI();
/* 42:   */   }
/* 43:   */   
/* 44:   */   protected void installDefaults(AbstractButton b) {
/* 45:45 */     super.installDefaults(b);
/* 46:   */     
/* 47:47 */     b.setRolloverEnabled(true);
/* 48:48 */     b.setOpaque(false);
/* 49:49 */     b.setHorizontalTextPosition(0);
/* 50:50 */     b.setVerticalTextPosition(3);
/* 51:   */     
/* 52:52 */     LookAndFeel.installBorder(b, "OutlookButton.border");
/* 53:   */   }
/* 54:   */   
/* 55:   */ 
/* 56:56 */   protected void paintButtonPressed(Graphics g, AbstractButton b) { setTextShiftOffset(); }
/* 57:   */   
/* 58:   */   public static class OutlookButtonBorder extends ButtonBorder {
/* 59:   */     FourLineBorder rolloverBorder;
/* 60:   */     FourLineBorder pressedBorder;
/* 61:   */     
/* 62:   */     public OutlookButtonBorder(Color color1, Color color2) {
/* 63:63 */       rolloverBorder = new FourLineBorder(color1, color1, color2, color2);
/* 64:64 */       pressedBorder = new FourLineBorder(color2, color2, color1, color1);
/* 65:   */     }
/* 66:   */     
/* 67:   */     protected void paintRollover(AbstractButton b, Graphics g, int x, int y, int width, int height) {
/* 68:68 */       rolloverBorder.paintBorder(b, g, x, y, width, height);
/* 69:   */     }
/* 70:   */     
/* 71:   */     protected void paintPressed(AbstractButton b, Graphics g, int x, int y, int width, int height) {
/* 72:72 */       pressedBorder.paintBorder(b, g, x, y, width, height);
/* 73:   */     }
/* 74:   */     
/* 75:75 */     public Insets getBorderInsets(Component c) { return rolloverBorder.getBorderInsets(c); }
/* 76:   */   }
/* 77:   */ }
