/*   1:    */ package com.l2fprod.common.swing.plaf.basic;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JButtonBar;
/*   4:    */ import com.l2fprod.common.swing.PercentLayout;
/*   5:    */ import com.l2fprod.common.swing.plaf.ButtonBarUI;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.LayoutManager;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.plaf.ComponentUI;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ public class BasicButtonBarUI
/*  34:    */   extends ButtonBarUI
/*  35:    */ {
/*  36:    */   protected JButtonBar bar;
/*  37:    */   protected PropertyChangeListener propertyListener;
/*  38:    */   
/*  39:    */   public static ComponentUI createUI(JComponent c)
/*  40:    */   {
/*  41: 41 */     return new BasicButtonBarUI();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void installUI(JComponent c) {
/*  45: 45 */     super.installUI(c);
/*  46:    */     
/*  47: 47 */     bar = ((JButtonBar)c);
/*  48:    */     
/*  49: 49 */     installDefaults();
/*  50: 50 */     installListeners();
/*  51:    */     
/*  52: 52 */     updateLayout();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void uninstallUI(JComponent c) {
/*  56: 56 */     uninstallDefaults();
/*  57: 57 */     uninstallListeners();
/*  58: 58 */     super.uninstallUI(c);
/*  59:    */   }
/*  60:    */   
/*  61:    */ 
/*  62:    */   protected void installDefaults() {}
/*  63:    */   
/*  64:    */   protected void uninstallDefaults() {}
/*  65:    */   
/*  66:    */   protected void installListeners()
/*  67:    */   {
/*  68: 68 */     propertyListener = createPropertyChangeListener();
/*  69: 69 */     bar.addPropertyChangeListener(propertyListener);
/*  70:    */   }
/*  71:    */   
/*  72:    */   protected void uninstallListeners() {
/*  73: 73 */     bar.removePropertyChangeListener(propertyListener);
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected PropertyChangeListener createPropertyChangeListener() {
/*  77: 77 */     return new ChangeListener(null);
/*  78:    */   }
/*  79:    */   
/*  80:    */   protected void updateLayout() {
/*  81: 81 */     if (bar.getOrientation() == 0) {
/*  82: 82 */       bar.setLayout(new PercentLayout(0, 2));
/*  83:    */     } else {
/*  84: 84 */       bar.setLayout(new PercentLayout(1, 2));
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Dimension getPreferredSize(JComponent c) {
/*  89: 89 */     JButtonBar b = (JButtonBar)c;
/*  90:    */     Dimension preferred;
/*  91:    */     Dimension preferred;
/*  92: 92 */     if (b.getLayout() == null) {
/*  93: 93 */       preferred = new Dimension(100, 100);
/*  94:    */     } else {
/*  95: 95 */       preferred = b.getLayout().preferredLayoutSize(c);
/*  96:    */     }
/*  97:    */     
/*  98: 98 */     if (b.getOrientation() == 0) {
/*  99: 99 */       return new Dimension(width, 53);
/* 100:    */     }
/* 101:101 */     return new Dimension(74, height);
/* 102:    */   }
/* 103:    */   
/* 104:    */   private class ChangeListener
/* 105:    */     implements PropertyChangeListener {
/* 106:106 */     ChangeListener(BasicButtonBarUI.1 x1) { this(); }
/* 107:    */     
/* 108:108 */     public void propertyChange(PropertyChangeEvent evt) { if (evt.getPropertyName().equals("orientation")) {
/* 109:109 */         updateLayout();
/* 110:110 */         bar.revalidate();
/* 111:111 */         bar.repaint();
/* 112:    */       }
/* 113:    */     }
/* 114:    */     
/* 115:    */     private ChangeListener() {}
/* 116:    */   }
/* 117:    */ }
