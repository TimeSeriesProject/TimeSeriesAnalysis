/*   1:    */ package com.l2fprod.common.swing.plaf.basic;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.FontChooserModel;
/*   4:    */ import com.l2fprod.common.swing.JFontChooser;
/*   5:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   6:    */ import com.l2fprod.common.swing.PercentLayout;
/*   7:    */ import com.l2fprod.common.swing.plaf.FontChooserUI;
/*   8:    */ import java.awt.Dimension;
/*   9:    */ import java.awt.Font;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.ActionListener;
/*  12:    */ import java.awt.font.TextAttribute;
/*  13:    */ import java.beans.PropertyChangeEvent;
/*  14:    */ import java.beans.PropertyChangeListener;
/*  15:    */ import java.util.HashMap;
/*  16:    */ import java.util.Map;
/*  17:    */ import java.util.ResourceBundle;
/*  18:    */ import javax.swing.JCheckBox;
/*  19:    */ import javax.swing.JComponent;
/*  20:    */ import javax.swing.JLabel;
/*  21:    */ import javax.swing.JList;
/*  22:    */ import javax.swing.JPanel;
/*  23:    */ import javax.swing.JScrollPane;
/*  24:    */ import javax.swing.JTextArea;
/*  25:    */ import javax.swing.JTextField;
/*  26:    */ import javax.swing.SwingUtilities;
/*  27:    */ import javax.swing.event.DocumentEvent;
/*  28:    */ import javax.swing.event.DocumentListener;
/*  29:    */ import javax.swing.event.ListSelectionEvent;
/*  30:    */ import javax.swing.event.ListSelectionListener;
/*  31:    */ import javax.swing.plaf.ComponentUI;
/*  32:    */ import javax.swing.text.Document;
/*  33:    */ 
/*  34:    */ public class BasicFontChooserUI extends FontChooserUI
/*  35:    */ {
/*  36:    */   private JFontChooser chooser;
/*  37:    */   private JPanel fontPanel;
/*  38:    */   private JTextField fontField;
/*  39:    */   private JList fontList;
/*  40:    */   private JPanel fontSizePanel;
/*  41:    */   private JTextField fontSizeField;
/*  42:    */   private JList fontSizeList;
/*  43:    */   private JCheckBox boldCheck;
/*  44:    */   private JCheckBox italicCheck;
/*  45:    */   private JTextArea previewPanel;
/*  46:    */   private PropertyChangeListener propertyListener;
/*  47:    */   
/*  48:    */   public static ComponentUI createUI(JComponent component)
/*  49:    */   {
/*  50: 50 */     return new BasicFontChooserUI();
/*  51:    */   }
/*  52:    */   
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */   public void installUI(JComponent c)
/*  70:    */   {
/*  71: 71 */     super.installUI(c);
/*  72:    */     
/*  73: 73 */     chooser = ((JFontChooser)c);
/*  74:    */     
/*  75: 75 */     installComponents();
/*  76: 76 */     installListeners();
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */   protected void installComponents()
/*  81:    */   {
/*  82: 82 */     ResourceBundle bundle = ResourceBundle.getBundle(FontChooserUI.class.getName() + "RB");
/*  83:    */     
/*  84:    */ 
/*  85: 85 */     fontPanel = new JPanel(new PercentLayout(1, 2));
/*  86: 86 */     JLabel label; fontPanel.add(label = new JLabel(bundle.getString("FontChooserUI.fontLabel")));
/*  87:    */     
/*  88: 88 */     fontPanel.add(this.fontField = new JTextField(25));
/*  89: 89 */     fontField.setEditable(false);
/*  90: 90 */     fontPanel.add(new JScrollPane(this.fontList = new JList()), "*");
/*  91: 91 */     label.setLabelFor(fontList);
/*  92: 92 */     label.setDisplayedMnemonic(bundle.getString("FontChooserUI.fontLabel.mnemonic").charAt(0));
/*  93:    */     
/*  94: 94 */     fontList.setVisibleRowCount(7);
/*  95: 95 */     fontList.setSelectionMode(0);
/*  96:    */     
/*  97: 97 */     String[] fontFamilies = chooser.getModel().getFontFamilies(null);
/*  98: 98 */     fontList.setListData(fontFamilies);
/*  99:    */     
/* 100:100 */     fontSizePanel = new JPanel(new PercentLayout(1, 2));
/* 101:    */     
/* 102:102 */     fontSizePanel.add(label = new JLabel(bundle.getString("FontChooserUI.styleLabel")));
/* 103:    */     
/* 104:104 */     fontSizePanel.add(this.boldCheck = new JCheckBox(bundle.getString("FontChooserUI.style.bold")));
/* 105:    */     
/* 106:106 */     fontSizePanel.add(this.italicCheck = new JCheckBox(bundle.getString("FontChooserUI.style.italic")));
/* 107:    */     
/* 108:    */ 
/* 109:109 */     boldCheck.setMnemonic(bundle.getString("FontChooserUI.style.bold.mnemonic").charAt(0));
/* 110:    */     
/* 111:111 */     italicCheck.setMnemonic(bundle.getString("FontChooserUI.style.italic.mnemonic").charAt(0));
/* 112:    */     
/* 113:    */ 
/* 114:114 */     fontSizePanel.add(label = new JLabel(bundle.getString("FontChooserUI.sizeLabel")));
/* 115:    */     
/* 116:    */ 
/* 117:117 */     label.setDisplayedMnemonic(bundle.getString("FontChooserUI.sizeLabel.mnemonic").charAt(0));
/* 118:    */     
/* 119:    */ 
/* 120:120 */     fontSizePanel.add(this.fontSizeField = new JTextField());
/* 121:121 */     label.setLabelFor(fontSizeField);
/* 122:122 */     fontSizePanel.add(new JScrollPane(this.fontSizeList = new JList()), "*");
/* 123:    */     
/* 124:124 */     int[] defaultFontSizes = chooser.getModel().getDefaultSizes();
/* 125:125 */     String[] sizes = new String[defaultFontSizes.length];
/* 126:126 */     int i = 0; for (int c = sizes.length; i < c; i++) {
/* 127:127 */       sizes[i] = String.valueOf(defaultFontSizes[i]);
/* 128:    */     }
/* 129:129 */     fontSizeList.setListData(sizes);
/* 130:130 */     fontSizeList.setSelectionMode(0);
/* 131:131 */     fontSizeList.setVisibleRowCount(2);
/* 132:    */     
/* 133:133 */     chooser.setLayout(LookAndFeelTweaks.createBorderLayout());
/* 134:134 */     JPanel panel = new JPanel();
/* 135:135 */     panel.setLayout(LookAndFeelTweaks.createHorizontalPercentLayout());
/* 136:136 */     panel.add(fontPanel, "*");
/* 137:137 */     panel.add(fontSizePanel);
/* 138:138 */     chooser.add("Center", panel);
/* 139:    */     
/* 140:140 */     previewPanel = new JTextArea();
/* 141:141 */     previewPanel.setPreferredSize(new Dimension(100, 40));
/* 142:142 */     previewPanel.setText(chooser.getModel().getPreviewMessage(null));
/* 143:143 */     JScrollPane scroll = new JScrollPane(previewPanel);
/* 144:144 */     chooser.add("South", scroll);
/* 145:    */   }
/* 146:    */   
/* 147:    */   protected void installListeners() {
/* 148:148 */     SelectedFontUpdater listener = new SelectedFontUpdater(null);
/* 149:149 */     fontList.addListSelectionListener(listener);
/* 150:150 */     fontSizeList.addListSelectionListener(listener);
/* 151:151 */     fontSizeField.getDocument().addDocumentListener(listener);
/* 152:152 */     boldCheck.addActionListener(listener);
/* 153:153 */     italicCheck.addActionListener(listener);
/* 154:    */     
/* 155:155 */     propertyListener = createPropertyChangeListener();
/* 156:156 */     chooser.addPropertyChangeListener("selectedFont", propertyListener);
/* 157:    */   }
/* 158:    */   
/* 159:    */ 
/* 160:    */   public void uninstallUI(JComponent c)
/* 161:    */   {
/* 162:162 */     chooser.remove(fontPanel);
/* 163:163 */     chooser.remove(fontSizePanel);
/* 164:    */     
/* 165:165 */     super.uninstallUI(c);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void uninstallListeners() {
/* 169:169 */     chooser.removePropertyChangeListener(propertyListener);
/* 170:    */   }
/* 171:    */   
/* 172:    */   protected PropertyChangeListener createPropertyChangeListener() {
/* 173:173 */     new PropertyChangeListener() {
/* 174:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 175:175 */         BasicFontChooserUI.this.updateDisplay();
/* 176:    */       }
/* 177:    */     };
/* 178:    */   }
/* 179:    */   
/* 180:    */   private void updateDisplay() {
/* 181:181 */     Font selected = chooser.getSelectedFont();
/* 182:182 */     if (selected != null) {
/* 183:183 */       previewPanel.setFont(selected);
/* 184:184 */       fontList.setSelectedValue(selected.getName(), true);
/* 185:185 */       fontSizeField.setText(String.valueOf(selected.getSize()));
/* 186:186 */       fontSizeList.setSelectedValue(String.valueOf(selected.getSize()), true);
/* 187:187 */       boldCheck.setSelected(selected.isBold());
/* 188:188 */       italicCheck.setSelected(selected.isItalic());
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   private void updateSelectedFont() {
/* 193:193 */     Font currentFont = chooser.getSelectedFont();
/* 194:194 */     String fontFamily = currentFont == null ? "SansSerif" : currentFont.getName();
/* 195:    */     
/* 196:196 */     int fontSize = currentFont == null ? 11 : currentFont.getSize();
/* 197:    */     
/* 198:198 */     if (fontList.getSelectedIndex() >= 0) {
/* 199:199 */       fontFamily = (String)fontList.getSelectedValue();
/* 200:    */     }
/* 201:    */     
/* 202:202 */     if (fontSizeField.getText().trim().length() > 0) {
/* 203:    */       try {
/* 204:204 */         fontSize = Integer.parseInt(fontSizeField.getText().trim());
/* 205:    */       }
/* 206:    */       catch (Exception e) {}
/* 207:    */     }
/* 208:    */     
/* 209:    */ 
/* 210:210 */     Map attributes = new HashMap();
/* 211:211 */     attributes.put(TextAttribute.SIZE, new Float(fontSize));
/* 212:212 */     attributes.put(TextAttribute.FAMILY, fontFamily);
/* 213:213 */     if (boldCheck.isSelected()) {
/* 214:214 */       attributes.put(TextAttribute.WEIGHT, TextAttribute.WEIGHT_BOLD);
/* 215:    */     }
/* 216:216 */     if (italicCheck.isSelected()) {
/* 217:217 */       attributes.put(TextAttribute.POSTURE, TextAttribute.POSTURE_OBLIQUE);
/* 218:    */     }
/* 219:    */     
/* 220:220 */     Font font = Font.getFont(attributes);
/* 221:221 */     if (!font.equals(currentFont)) {
/* 222:222 */       chooser.setSelectedFont(font);
/* 223:223 */       previewPanel.setFont(font);
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:227 */   private class SelectedFontUpdater implements ListSelectionListener, DocumentListener, ActionListener { SelectedFontUpdater(BasicFontChooserUI.1 x1) { this(); }
/* 228:    */     
/* 229:    */     public void valueChanged(ListSelectionEvent e) {
/* 230:230 */       if ((fontList == e.getSource()) && (fontList.getSelectedValue() != null)) {
/* 231:231 */         fontField.setText((String)fontList.getSelectedValue());
/* 232:    */       }
/* 233:233 */       if ((fontSizeList == e.getSource()) && (fontSizeList.getSelectedValue() != null))
/* 234:    */       {
/* 235:235 */         fontSizeField.setText((String)fontSizeList.getSelectedValue());
/* 236:    */       }
/* 237:237 */       BasicFontChooserUI.this.updateSelectedFont();
/* 238:    */     }
/* 239:    */     
/* 240:240 */     public void changedUpdate(DocumentEvent e) { updateLater(); }
/* 241:    */     
/* 242:    */     public void insertUpdate(DocumentEvent e) {
/* 243:243 */       updateLater();
/* 244:    */     }
/* 245:    */     
/* 246:246 */     public void removeUpdate(DocumentEvent e) { updateLater(); }
/* 247:    */     
/* 248:    */     public void actionPerformed(ActionEvent e) {
/* 249:249 */       updateLater();
/* 250:    */     }
/* 251:    */     
/* 252:252 */     void updateLater() { SwingUtilities.invokeLater(new BasicFontChooserUI.2(this)); }
/* 253:    */     
/* 254:    */     private SelectedFontUpdater() {}
/* 255:    */   }
/* 256:    */ }
