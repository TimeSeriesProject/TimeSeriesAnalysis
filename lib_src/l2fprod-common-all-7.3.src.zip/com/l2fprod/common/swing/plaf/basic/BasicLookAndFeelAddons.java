package com.l2fprod.common.swing.plaf.basic;

import com.l2fprod.common.swing.plaf.LookAndFeelAddons;

public class BasicLookAndFeelAddons
  extends LookAndFeelAddons
{}
