/*  1:   */ package com.l2fprod.common.swing.plaf;
/*  2:   */ 
/*  3:   */ import java.util.Arrays;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class JDirectoryChooserAddon
/* 29:   */   extends AbstractComponentAddon
/* 30:   */ {
/* 31:   */   public JDirectoryChooserAddon()
/* 32:   */   {
/* 33:33 */     super("JDirectoryChooser");
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/* 37:37 */     defaults.addAll(Arrays.asList(new Object[] { "l2fprod/DirectoryChooserUI", "com.l2fprod.common.swing.plaf.windows.WindowsDirectoryChooserUI" }));
/* 38:   */     
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:42 */     addResource(defaults, "com.l2fprod.common.swing.plaf.DirectoryChooserUIRB");
/* 43:   */   }
/* 44:   */ }
