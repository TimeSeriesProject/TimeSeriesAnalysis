/*  1:   */ package com.l2fprod.common.swing.plaf;
/*  2:   */ 
/*  3:   */ import java.util.Arrays;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public class JFontChooserAddon
/* 26:   */   extends AbstractComponentAddon
/* 27:   */ {
/* 28:   */   public JFontChooserAddon()
/* 29:   */   {
/* 30:30 */     super("JFontChooser");
/* 31:   */   }
/* 32:   */   
/* 33:   */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/* 34:34 */     defaults.addAll(Arrays.asList(new Object[] { "FontChooserUI", "com.l2fprod.common.swing.plaf.basic.BasicFontChooserUI" }));
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected void addWindowsDefaults(LookAndFeelAddons addon, List defaults)
/* 38:   */   {
/* 39:39 */     defaults.addAll(Arrays.asList(new Object[] { "FontChooserUI", "com.l2fprod.common.swing.plaf.windows.WindowsFontChooserUI" }));
/* 40:   */   }
/* 41:   */ }
