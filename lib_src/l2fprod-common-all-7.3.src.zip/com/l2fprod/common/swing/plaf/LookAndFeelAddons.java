/*   1:    */ package com.l2fprod.common.swing.plaf;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.aqua.AquaLookAndFeelAddons;
/*   4:    */ import com.l2fprod.common.swing.plaf.metal.MetalLookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons;
/*   6:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*   7:    */ import com.l2fprod.common.util.OS;
/*   8:    */ import java.beans.PropertyChangeEvent;
/*   9:    */ import java.beans.PropertyChangeListener;
/*  10:    */ import java.lang.reflect.Method;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import javax.swing.JComponent;
/*  15:    */ import javax.swing.UIDefaults;
/*  16:    */ import javax.swing.UIManager;
/*  17:    */ import javax.swing.plaf.ComponentUI;
/*  18:    */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ public class LookAndFeelAddons
/*  61:    */ {
/*  62: 62 */   private static List contributedComponents = new ArrayList();
/*  63:    */   
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68: 68 */   private static final Object APPCONTEXT_INITIALIZED = new Object();
/*  69:    */   
/*  70: 70 */   private static boolean trackingChanges = false;
/*  71:    */   private static PropertyChangeListener changeListener;
/*  72:    */   private static LookAndFeelAddons currentAddon;
/*  73:    */   
/*  74:    */   static {
/*  75: 75 */     String addonClassname = getBestMatchAddonClassName();
/*  76:    */     try {
/*  77: 77 */       addonClassname = System.getProperty("swing.addon", addonClassname);
/*  78:    */     }
/*  79:    */     catch (SecurityException e) {}
/*  80:    */     
/*  81:    */     try
/*  82:    */     {
/*  83: 83 */       setAddon(addonClassname);
/*  84: 84 */       setTrackingLookAndFeelChanges(true);
/*  85:    */     } catch (InstantiationException e) {
/*  86: 86 */       e.printStackTrace();
/*  87:    */     } catch (IllegalAccessException e) {
/*  88: 88 */       e.printStackTrace();
/*  89:    */     } catch (ClassNotFoundException e) {
/*  90: 90 */       e.printStackTrace();
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */ 
/*  95:    */   public void initialize()
/*  96:    */   {
/*  97: 97 */     for (Iterator iter = contributedComponents.iterator(); iter.hasNext();) {
/*  98: 98 */       ComponentAddon addon = (ComponentAddon)iter.next();
/*  99: 99 */       addon.initialize(this);
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void uninitialize() {
/* 104:104 */     for (Iterator iter = contributedComponents.iterator(); iter.hasNext();) {
/* 105:105 */       ComponentAddon addon = (ComponentAddon)iter.next();
/* 106:106 */       addon.uninitialize(this);
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */   public void loadDefaults(Object[] keysAndValues)
/* 124:    */   {
/* 125:125 */     for (int i = keysAndValues.length - 2; i >= 0; i -= 2) {
/* 126:126 */       if (UIManager.getLookAndFeelDefaults().get(keysAndValues[i]) == null) {
/* 127:127 */         UIManager.getLookAndFeelDefaults().put(keysAndValues[i], keysAndValues[(i + 1)]);
/* 128:    */       }
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void unloadDefaults(Object[] keysAndValues) {
/* 133:133 */     int i = 0; for (int c = keysAndValues.length; i < c; i += 2) {
/* 134:134 */       UIManager.getLookAndFeelDefaults().put(keysAndValues[i], null);
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static void setAddon(String addonClassName)
/* 139:    */     throws InstantiationException, IllegalAccessException, ClassNotFoundException
/* 140:    */   {
/* 141:141 */     setAddon(Class.forName(addonClassName));
/* 142:    */   }
/* 143:    */   
/* 144:    */   public static void setAddon(Class addonClass) throws InstantiationException, IllegalAccessException
/* 145:    */   {
/* 146:146 */     LookAndFeelAddons addon = (LookAndFeelAddons)addonClass.newInstance();
/* 147:147 */     setAddon(addon);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static void setAddon(LookAndFeelAddons addon) {
/* 151:151 */     if (currentAddon != null) {
/* 152:152 */       currentAddon.uninitialize();
/* 153:    */     }
/* 154:    */     
/* 155:155 */     addon.initialize();
/* 156:156 */     currentAddon = addon;
/* 157:157 */     UIManager.put(APPCONTEXT_INITIALIZED, Boolean.TRUE);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static LookAndFeelAddons getAddon() {
/* 161:161 */     return currentAddon;
/* 162:    */   }
/* 163:    */   
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */   public static String getBestMatchAddonClassName()
/* 171:    */   {
/* 172:172 */     String lnf = UIManager.getLookAndFeel().getClass().getName();
/* 173:    */     String addon;
/* 174:174 */     String addon; if (UIManager.getCrossPlatformLookAndFeelClassName().equals(lnf)) {
/* 175:175 */       addon = MetalLookAndFeelAddons.class.getName(); } else { String addon;
/* 176:176 */       if (UIManager.getSystemLookAndFeelClassName().equals(lnf)) {
/* 177:177 */         addon = getSystemAddonClassName(); } else { String addon;
/* 178:178 */         if (("com.sun.java.swing.plaf.windows.WindowsLookAndFeel".equals(lnf)) || ("com.jgoodies.looks.windows.WindowsLookAndFeel".equals(lnf))) {
/* 179:    */           String addon;
/* 180:180 */           if (OS.isUsingWindowsVisualStyles()) {
/* 181:181 */             addon = WindowsLookAndFeelAddons.class.getName();
/* 182:    */           } else
/* 183:183 */             addon = WindowsClassicLookAndFeelAddons.class.getName();
/* 184:    */         } else { String addon;
/* 185:185 */           if ("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel".equals(lnf))
/* 186:    */           {
/* 187:187 */             addon = WindowsClassicLookAndFeelAddons.class.getName(); } else { String addon;
/* 188:188 */             if ((UIManager.getLookAndFeel() instanceof MetalLookAndFeel))
/* 189:    */             {
/* 190:190 */               addon = MetalLookAndFeelAddons.class.getName();
/* 191:    */             } else
/* 192:192 */               addon = getSystemAddonClassName();
/* 193:    */           } } } }
/* 194:194 */     return addon;
/* 195:    */   }
/* 196:    */   
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:    */ 
/* 202:    */   public static String getSystemAddonClassName()
/* 203:    */   {
/* 204:204 */     String addon = WindowsClassicLookAndFeelAddons.class.getName();
/* 205:    */     
/* 206:206 */     if (OS.isMacOSX()) {
/* 207:207 */       addon = AquaLookAndFeelAddons.class.getName();
/* 208:208 */     } else if (OS.isWindows())
/* 209:    */     {
/* 210:210 */       if (OS.isUsingWindowsVisualStyles()) {
/* 211:211 */         addon = WindowsLookAndFeelAddons.class.getName();
/* 212:    */       } else {
/* 213:213 */         addon = WindowsClassicLookAndFeelAddons.class.getName();
/* 214:    */       }
/* 215:    */     }
/* 216:    */     
/* 217:217 */     return addon;
/* 218:    */   }
/* 219:    */   
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */   public static void contribute(ComponentAddon component)
/* 227:    */   {
/* 228:228 */     contributedComponents.add(component);
/* 229:    */     
/* 230:230 */     if (currentAddon != null)
/* 231:    */     {
/* 232:    */ 
/* 233:233 */       component.initialize(currentAddon);
/* 234:    */     }
/* 235:    */   }
/* 236:    */   
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */   public static void uncontribute(ComponentAddon component)
/* 242:    */   {
/* 243:243 */     contributedComponents.remove(component);
/* 244:    */     
/* 245:245 */     if (currentAddon != null) {
/* 246:246 */       component.uninitialize(currentAddon);
/* 247:    */     }
/* 248:    */   }
/* 249:    */   
/* 250:    */ 
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */   public static ComponentUI getUI(JComponent component, Class expectedUIClass)
/* 258:    */   {
/* 259:259 */     maybeInitialize();
/* 260:    */     
/* 261:    */ 
/* 262:262 */     String uiClassname = (String)UIManager.get(component.getUIClassID());
/* 263:    */     try {
/* 264:264 */       Class uiClass = Class.forName(uiClassname);
/* 265:265 */       UIManager.put(uiClassname, uiClass);
/* 266:    */     }
/* 267:    */     catch (Exception e) {}
/* 268:    */     
/* 269:    */ 
/* 270:270 */     ComponentUI ui = UIManager.getUI(component);
/* 271:    */     
/* 272:272 */     if (expectedUIClass.isInstance(ui)) {
/* 273:273 */       return ui;
/* 274:    */     }
/* 275:275 */     String realUI = ui.getClass().getName();
/* 276:    */     try
/* 277:    */     {
/* 278:278 */       realUIClass = expectedUIClass.getClassLoader().loadClass(realUI);
/* 279:    */     } catch (ClassNotFoundException e) {
/* 280:    */       Class realUIClass;
/* 281:281 */       throw new RuntimeException("Failed to load class " + realUI, e); }
/* 282:    */     Class realUIClass;
/* 283:283 */     Method createUIMethod = null;
/* 284:    */     try {
/* 285:285 */       createUIMethod = realUIClass.getMethod("createUI", new Class[] { JComponent.class });
/* 286:    */     } catch (NoSuchMethodException e1) {
/* 287:287 */       throw new RuntimeException("Class " + realUI + " has no method createUI(JComponent)");
/* 288:    */     }
/* 289:    */     try {
/* 290:290 */       return (ComponentUI)createUIMethod.invoke(null, new Object[] { component });
/* 291:    */     } catch (Exception e2) {
/* 292:292 */       throw new RuntimeException("Failed to invoke " + realUI + "#createUI(JComponent)");
/* 293:    */     }
/* 294:    */   }
/* 295:    */   
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:    */ 
/* 306:    */ 
/* 307:    */   private static synchronized void maybeInitialize()
/* 308:    */   {
/* 309:309 */     if (currentAddon != null)
/* 310:    */     {
/* 311:    */ 
/* 312:312 */       UIManager.getLookAndFeelDefaults();
/* 313:    */       
/* 314:314 */       if (!UIManager.getBoolean(APPCONTEXT_INITIALIZED)) {
/* 315:315 */         setAddon(currentAddon);
/* 316:    */       }
/* 317:    */     }
/* 318:    */   }
/* 319:    */   
/* 320:    */   private static class UpdateAddon
/* 321:    */     implements PropertyChangeListener
/* 322:    */   {
/* 323:323 */     UpdateAddon(LookAndFeelAddons.1 x0) { this(); }
/* 324:    */     
/* 325:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 326:326 */       try { LookAndFeelAddons.setAddon(LookAndFeelAddons.getBestMatchAddonClassName());
/* 327:    */       }
/* 328:    */       catch (Exception e) {
/* 329:329 */         throw new RuntimeException(e);
/* 330:    */       }
/* 331:    */     }
/* 332:    */     
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */     private UpdateAddon() {}
/* 337:    */   }
/* 338:    */   
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */   public static synchronized void setTrackingLookAndFeelChanges(boolean tracking)
/* 343:    */   {
/* 344:344 */     if (trackingChanges != tracking) {
/* 345:345 */       if (tracking) {
/* 346:346 */         if (changeListener == null) {
/* 347:347 */           changeListener = new UpdateAddon(null);
/* 348:    */         }
/* 349:349 */         UIManager.addPropertyChangeListener(changeListener);
/* 350:    */       } else {
/* 351:351 */         if (changeListener != null) {
/* 352:352 */           UIManager.removePropertyChangeListener(changeListener);
/* 353:    */         }
/* 354:354 */         changeListener = null;
/* 355:    */       }
/* 356:356 */       trackingChanges = tracking;
/* 357:    */     }
/* 358:    */   }
/* 359:    */   
/* 360:    */ 
/* 361:    */ 
/* 362:    */ 
/* 363:    */ 
/* 364:    */   public static synchronized boolean isTrackingLookAndFeelChanges()
/* 365:    */   {
/* 366:366 */     return trackingChanges;
/* 367:    */   }
/* 368:    */ }
