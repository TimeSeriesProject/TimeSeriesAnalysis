package com.l2fprod.common.swing.plaf;

public abstract interface ComponentAddon
{
  public abstract String getName();
  
  public abstract void initialize(LookAndFeelAddons paramLookAndFeelAddons);
  
  public abstract void uninitialize(LookAndFeelAddons paramLookAndFeelAddons);
}
