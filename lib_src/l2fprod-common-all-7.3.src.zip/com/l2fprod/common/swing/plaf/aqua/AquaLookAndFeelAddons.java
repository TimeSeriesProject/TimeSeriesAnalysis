/*  1:   */ package com.l2fprod.common.swing.plaf.aqua;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.basic.BasicLookAndFeelAddons;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class AquaLookAndFeelAddons
/* 21:   */   extends BasicLookAndFeelAddons
/* 22:   */ {
/* 23:   */   public void initialize()
/* 24:   */   {
/* 25:25 */     super.initialize();
/* 26:26 */     loadDefaults(getDefaults());
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void uninitialize() {
/* 30:30 */     super.uninitialize();
/* 31:31 */     unloadDefaults(getDefaults());
/* 32:   */   }
/* 33:   */   
/* 34:   */   private Object[] getDefaults()
/* 35:   */   {
/* 36:36 */     Object[] defaults = { "TaskPaneGroupUI", "com.l2fprod.common.swing.plaf.misc.GlossyTaskPaneGroupUI" };
/* 37:   */     
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:41 */     return defaults;
/* 42:   */   }
/* 43:   */ }
