/*   1:    */ package com.l2fprod.common.swing.plaf.windows;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JDirectoryChooser;
/*   4:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   5:    */ import com.l2fprod.common.swing.plaf.DirectoryChooserUI;
/*   6:    */ import com.l2fprod.common.swing.tree.LazyMutableTreeNode;
/*   7:    */ import com.l2fprod.common.util.OS;
/*   8:    */ import java.awt.Component;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.GridBagConstraints;
/*  11:    */ import java.awt.GridBagLayout;
/*  12:    */ import java.awt.Insets;
/*  13:    */ import java.awt.event.ActionEvent;
/*  14:    */ import java.awt.event.MouseEvent;
/*  15:    */ import java.beans.PropertyChangeEvent;
/*  16:    */ import java.beans.PropertyChangeListener;
/*  17:    */ import java.io.File;
/*  18:    */ import java.lang.reflect.InvocationTargetException;
/*  19:    */ import java.util.ArrayList;
/*  20:    */ import java.util.Arrays;
/*  21:    */ import java.util.Enumeration;
/*  22:    */ import java.util.List;
/*  23:    */ import java.util.Stack;
/*  24:    */ import javax.swing.AbstractAction;
/*  25:    */ import javax.swing.Action;
/*  26:    */ import javax.swing.ActionMap;
/*  27:    */ import javax.swing.Box;
/*  28:    */ import javax.swing.Icon;
/*  29:    */ import javax.swing.InputMap;
/*  30:    */ import javax.swing.JButton;
/*  31:    */ import javax.swing.JComponent;
/*  32:    */ import javax.swing.JFileChooser;
/*  33:    */ import javax.swing.JOptionPane;
/*  34:    */ import javax.swing.JPanel;
/*  35:    */ import javax.swing.JScrollPane;
/*  36:    */ import javax.swing.JTree;
/*  37:    */ import javax.swing.KeyStroke;
/*  38:    */ import javax.swing.LookAndFeel;
/*  39:    */ import javax.swing.SwingUtilities;
/*  40:    */ import javax.swing.UIManager;
/*  41:    */ import javax.swing.event.TreeExpansionEvent;
/*  42:    */ import javax.swing.event.TreeExpansionListener;
/*  43:    */ import javax.swing.event.TreeSelectionEvent;
/*  44:    */ import javax.swing.event.TreeSelectionListener;
/*  45:    */ import javax.swing.filechooser.FileSystemView;
/*  46:    */ import javax.swing.filechooser.FileView;
/*  47:    */ import javax.swing.plaf.ComponentUI;
/*  48:    */ import javax.swing.plaf.basic.BasicFileChooserUI;
/*  49:    */ import javax.swing.plaf.basic.BasicFileChooserUI.BasicFileView;
/*  50:    */ import javax.swing.tree.DefaultMutableTreeNode;
/*  51:    */ import javax.swing.tree.DefaultTreeCellRenderer;
/*  52:    */ import javax.swing.tree.DefaultTreeModel;
/*  53:    */ import javax.swing.tree.TreeModel;
/*  54:    */ import javax.swing.tree.TreePath;
/*  55:    */ import javax.swing.tree.TreeSelectionModel;
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ public class WindowsDirectoryChooserUI
/*  66:    */   extends BasicFileChooserUI
/*  67:    */   implements DirectoryChooserUI
/*  68:    */ {
/*  69:    */   private static Queue nodeQueue;
/*  70:    */   private JFileChooser chooser;
/*  71:    */   private JTree tree;
/*  72:    */   private JScrollPane treeScroll;
/*  73:    */   private JButton approveButton;
/*  74:    */   private JButton cancelButton;
/*  75:    */   private JPanel buttonPanel;
/*  76:    */   
/*  77:    */   public static ComponentUI createUI(JComponent c)
/*  78:    */   {
/*  79: 79 */     return new WindowsDirectoryChooserUI((JFileChooser)c);
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90: 90 */   private BasicFileChooserUI.BasicFileView fileView = new WindowsFileView();
/*  91: 91 */   private Action approveSelectionAction = new ApproveSelectionAction();
/*  92:    */   
/*  93:    */   private boolean useNodeQueue;
/*  94:    */   private JButton newFolderButton;
/*  95: 95 */   private Action newFolderAction = new NewFolderAction(null);
/*  96: 96 */   private String newFolderText = null;
/*  97: 97 */   private String newFolderToolTipText = null;
/*  98:    */   
/*  99:    */   public WindowsDirectoryChooserUI(JFileChooser chooser) {
/* 100:100 */     super(chooser);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void rescanCurrentDirectory(JFileChooser fc) {
/* 104:104 */     super.rescanCurrentDirectory(fc);
/* 105:105 */     findFile(chooser.getSelectedFile() == null ? chooser.getCurrentDirectory() : chooser.getSelectedFile(), true, true);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void ensureFileIsVisible(JFileChooser fc, File f)
/* 109:    */   {
/* 110:110 */     super.ensureFileIsVisible(fc, f);
/* 111:111 */     File selectedFile = fc.getSelectedFile();
/* 112:112 */     boolean select = (selectedFile != null) && (selectedFile.equals(f));
/* 113:113 */     findFile(f, select, false);
/* 114:    */   }
/* 115:    */   
/* 116:    */   protected String getToolTipText(MouseEvent event) {
/* 117:117 */     TreePath path = tree.getPathForLocation(event.getX(), event.getY());
/* 118:118 */     if ((path != null) && ((path.getLastPathComponent() instanceof FileTreeNode))) {
/* 119:119 */       FileTreeNode node = (FileTreeNode)path.getLastPathComponent();
/* 120:120 */       String typeDescription = getFileView(chooser).getTypeDescription(node.getFile());
/* 121:    */       
/* 122:122 */       if ((typeDescription == null) || (typeDescription.length() == 0)) {
/* 123:123 */         return node.toString();
/* 124:    */       }
/* 125:125 */       return node.toString() + " - " + typeDescription;
/* 126:    */     }
/* 127:    */     
/* 128:128 */     return null;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void installComponents(JFileChooser chooser)
/* 132:    */   {
/* 133:133 */     this.chooser = chooser;
/* 134:    */     
/* 135:135 */     chooser.setLayout(LookAndFeelTweaks.createBorderLayout());
/* 136:136 */     chooser.setFileSelectionMode(1);
/* 137:    */     
/* 138:138 */     Component accessory = chooser.getAccessory();
/* 139:139 */     if (accessory != null) {
/* 140:140 */       chooser.add("North", chooser.getAccessory());
/* 141:    */     }
/* 142:    */     
/* 143:143 */     tree = new JTree()
/* 144:    */     {
/* 145:    */       public String getToolTipText(MouseEvent event) {
/* 146:146 */         String tip = WindowsDirectoryChooserUI.this.getToolTipText(event);
/* 147:147 */         if (tip == null) {
/* 148:148 */           return super.getToolTipText(event);
/* 149:    */         }
/* 150:150 */         return tip;
/* 151:    */       }
/* 152:    */       
/* 153:153 */     };
/* 154:154 */     tree.addTreeExpansionListener(new TreeExpansion(null));
/* 155:    */     
/* 156:156 */     tree.setModel(new FileSystemTreeModel(chooser.getFileSystemView()));
/* 157:157 */     tree.setRootVisible(false);
/* 158:158 */     tree.setShowsRootHandles(false);
/* 159:159 */     tree.setCellRenderer(new FileSystemTreeRenderer(null));
/* 160:160 */     tree.setToolTipText("");
/* 161:    */     
/* 162:162 */     chooser.add("Center", this.treeScroll = new JScrollPane(tree));
/* 163:163 */     treeScroll.setPreferredSize(new Dimension(300, 300));
/* 164:    */     
/* 165:165 */     approveButton = new JButton();
/* 166:166 */     approveButton.setAction(getApproveSelectionAction());
/* 167:    */     
/* 168:168 */     cancelButton = new JButton();
/* 169:169 */     cancelButton.setAction(getCancelSelectionAction());
/* 170:170 */     cancelButton.setDefaultCapable(true);
/* 171:    */     
/* 172:172 */     newFolderButton = new JButton();
/* 173:173 */     newFolderButton.setAction(getNewFolderAction());
/* 174:    */     
/* 175:175 */     buttonPanel = new JPanel(new GridBagLayout());
/* 176:    */     
/* 177:177 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 178:178 */     insets = new Insets(0, 0, 0, 25);
/* 179:179 */     anchor = 13;
/* 180:180 */     weightx = 1.0D;
/* 181:181 */     gridy = 0;
/* 182:182 */     gridx = 0;
/* 183:183 */     buttonPanel.add(Box.createHorizontalStrut(0), gridBagConstraints);
/* 184:184 */     buttonPanel.add(newFolderButton, gridBagConstraints);
/* 185:    */     
/* 186:186 */     gridBagConstraints = new GridBagConstraints();
/* 187:187 */     insets = new Insets(0, 0, 0, 6);
/* 188:188 */     weightx = 0.0D;
/* 189:189 */     gridy = 0;
/* 190:190 */     gridx = 1;
/* 191:191 */     buttonPanel.add(approveButton, gridBagConstraints);
/* 192:    */     
/* 193:193 */     gridBagConstraints = new GridBagConstraints();
/* 194:194 */     weightx = 0.0D;
/* 195:195 */     gridy = 0;
/* 196:196 */     gridx = 2;
/* 197:197 */     buttonPanel.add(cancelButton, gridBagConstraints);
/* 198:198 */     chooser.add("South", buttonPanel);
/* 199:    */     
/* 200:200 */     updateView(chooser);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public Action getNewFolderAction() {
/* 204:204 */     return newFolderAction;
/* 205:    */   }
/* 206:    */   
/* 207:    */   protected void installStrings(JFileChooser fc) {
/* 208:208 */     super.installStrings(fc);
/* 209:    */     
/* 210:210 */     saveButtonToolTipText = UIManager.getString("DirectoryChooser.saveButtonToolTipText");
/* 211:    */     
/* 212:212 */     openButtonToolTipText = UIManager.getString("DirectoryChooser.openButtonToolTipText");
/* 213:    */     
/* 214:214 */     cancelButtonToolTipText = UIManager.getString("DirectoryChooser.cancelButtonToolTipText");
/* 215:    */     
/* 216:    */ 
/* 217:217 */     newFolderText = UIManager.getString("DirectoryChooser.newFolderButtonText");
/* 218:218 */     newFolderToolTipText = UIManager.getString("DirectoryChooser.newFolderButtonToolTipText");
/* 219:    */   }
/* 220:    */   
/* 221:    */   protected void uninstallStrings(JFileChooser fc)
/* 222:    */   {
/* 223:223 */     super.uninstallStrings(fc);
/* 224:    */     
/* 225:225 */     newFolderText = null;
/* 226:226 */     newFolderToolTipText = null;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public void uninstallComponents(JFileChooser chooser) {
/* 230:230 */     chooser.remove(treeScroll);
/* 231:231 */     chooser.remove(buttonPanel);
/* 232:    */   }
/* 233:    */   
/* 234:    */   public FileView getFileView(JFileChooser fc) {
/* 235:235 */     return fileView;
/* 236:    */   }
/* 237:    */   
/* 238:    */   protected void installListeners(JFileChooser fc) {
/* 239:239 */     super.installListeners(fc);
/* 240:    */     
/* 241:241 */     tree.addTreeSelectionListener(new SelectionListener(null));
/* 242:    */     
/* 243:243 */     fc.getActionMap().put("refreshTree", new UpdateAction(null));
/* 244:244 */     fc.getInputMap(1).put(KeyStroke.getKeyStroke("F5"), "refreshTree");
/* 245:    */   }
/* 246:    */   
/* 247:    */   private class UpdateAction extends AbstractAction {
/* 248:248 */     UpdateAction(WindowsDirectoryChooserUI.1 x1) { this(); }
/* 249:    */     
/* 250:250 */     public void actionPerformed(ActionEvent e) { JFileChooser fc = getFileChooser();
/* 251:251 */       fc.rescanCurrentDirectory();
/* 252:    */     }
/* 253:    */     
/* 254:    */     private UpdateAction() {} }
/* 255:    */   
/* 256:256 */   protected void uninstallListeners(JFileChooser fc) { super.uninstallListeners(fc); }
/* 257:    */   
/* 258:    */   public PropertyChangeListener createPropertyChangeListener(JFileChooser fc)
/* 259:    */   {
/* 260:260 */     return new ChangeListener(null);
/* 261:    */   }
/* 262:    */   
/* 263:    */   private void updateView(JFileChooser chooser) {
/* 264:264 */     if (chooser.getApproveButtonText() != null) {
/* 265:265 */       approveButton.setText(chooser.getApproveButtonText());
/* 266:266 */       approveButton.setMnemonic(chooser.getApproveButtonMnemonic());
/* 267:    */     }
/* 268:268 */     else if (0 == chooser.getDialogType()) {
/* 269:269 */       approveButton.setText(openButtonText);
/* 270:270 */       approveButton.setToolTipText(openButtonToolTipText);
/* 271:271 */       approveButton.setMnemonic(openButtonMnemonic);
/* 272:    */     } else {
/* 273:273 */       approveButton.setText(saveButtonText);
/* 274:274 */       approveButton.setToolTipText(saveButtonToolTipText);
/* 275:275 */       approveButton.setMnemonic(saveButtonMnemonic);
/* 276:    */     }
/* 277:    */     
/* 278:    */ 
/* 279:279 */     cancelButton.setText(cancelButtonText);
/* 280:280 */     cancelButton.setMnemonic(cancelButtonMnemonic);
/* 281:    */     
/* 282:282 */     newFolderButton.setText(newFolderText);
/* 283:283 */     newFolderButton.setToolTipText(newFolderToolTipText);
/* 284:284 */     newFolderButton.setVisible(((JDirectoryChooser)chooser).isShowingCreateDirectory());
/* 285:    */     
/* 286:286 */     buttonPanel.setVisible(chooser.getControlButtonsAreShown());
/* 287:    */     
/* 288:    */ 
/* 289:289 */     approveButton.setPreferredSize(null);
/* 290:290 */     cancelButton.setPreferredSize(null);
/* 291:    */     
/* 292:292 */     Dimension preferredSize = approveButton.getMinimumSize();
/* 293:293 */     preferredSize = new Dimension(Math.max(width, cancelButton.getPreferredSize().width), height);
/* 294:    */     
/* 295:295 */     approveButton.setPreferredSize(preferredSize);
/* 296:296 */     cancelButton.setPreferredSize(preferredSize);
/* 297:    */   }
/* 298:    */   
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:    */   private void findFile(File fileToLocate, boolean selectFile, boolean reload)
/* 306:    */   {
/* 307:307 */     if ((fileToLocate == null) || (!fileToLocate.isDirectory())) { return;
/* 308:    */     }
/* 309:    */     
/* 310:    */ 
/* 311:    */ 
/* 312:312 */     File file = null;
/* 313:    */     try {
/* 314:314 */       file = fileToLocate.getCanonicalFile();
/* 315:    */     } catch (Exception e) {
/* 316:316 */       return;
/* 317:    */     }
/* 318:    */     
/* 319:    */ 
/* 320:320 */     useNodeQueue = false;
/* 321:    */     
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */     try
/* 326:    */     {
/* 327:327 */       List files = new ArrayList();
/* 328:328 */       files.add(file);
/* 329:329 */       while ((file = chooser.getFileSystemView().getParentDirectory(file)) != null) {
/* 330:330 */         files.add(0, file);
/* 331:    */       }
/* 332:    */       
/* 333:333 */       List path = new ArrayList();
/* 334:    */       
/* 335:    */ 
/* 336:336 */       DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getModel().getRoot();
/* 337:    */       
/* 338:338 */       path.add(node);
/* 339:    */       
/* 340:    */ 
/* 341:    */ 
/* 342:342 */       boolean found = true;
/* 343:    */       
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:    */ 
/* 349:349 */       while ((files.size() > 0) && (found)) {
/* 350:350 */         found = false;
/* 351:351 */         int i = 0; for (int c = node.getChildCount(); i < c; i++) {
/* 352:352 */           DefaultMutableTreeNode current = (DefaultMutableTreeNode)node.getChildAt(i);
/* 353:353 */           File f = ((FileTreeNode)current).getFile();
/* 354:354 */           if (files.get(0).equals(f)) {
/* 355:355 */             path.add(current);
/* 356:356 */             files.remove(0);
/* 357:357 */             node = current;
/* 358:358 */             found = true;
/* 359:359 */             break;
/* 360:    */           }
/* 361:    */         }
/* 362:    */       }
/* 363:    */       
/* 364:    */ 
/* 365:    */ 
/* 366:    */ 
/* 367:367 */       TreePath pathToSelect = new TreePath(path.toArray());
/* 368:368 */       if (((pathToSelect.getLastPathComponent() instanceof FileTreeNode)) && (reload)) {
/* 369:369 */         ((FileTreeNode)pathToSelect.getLastPathComponent()).clear();
/* 370:370 */         enqueueChildren((FileTreeNode)pathToSelect.getLastPathComponent());
/* 371:    */       }
/* 372:    */     }
/* 373:    */     finally {
/* 374:374 */       useNodeQueue = true;
/* 375:    */     }
/* 376:    */     TreePath pathToSelect;
/* 377:377 */     if (selectFile) {
/* 378:378 */       tree.expandPath(pathToSelect);
/* 379:379 */       tree.setSelectionPath(pathToSelect);
/* 380:    */     }
/* 381:    */     
/* 382:382 */     tree.makeVisible(pathToSelect);
/* 383:    */   }
/* 384:    */   
/* 385:385 */   private class ChangeListener implements PropertyChangeListener { ChangeListener(WindowsDirectoryChooserUI.1 x1) { this(); }
/* 386:    */     
/* 387:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 388:388 */       if ("ApproveButtonTextChangedProperty".equals(evt.getPropertyName()))
/* 389:    */       {
/* 390:390 */         WindowsDirectoryChooserUI.this.updateView(chooser);
/* 391:    */       }
/* 392:    */       
/* 393:393 */       if ("MultiSelectionEnabledChangedProperty".equals(evt.getPropertyName()))
/* 394:    */       {
/* 395:395 */         if (chooser.isMultiSelectionEnabled()) {
/* 396:396 */           tree.getSelectionModel().setSelectionMode(4);
/* 397:    */         }
/* 398:    */         else {
/* 399:399 */           tree.getSelectionModel().setSelectionMode(1);
/* 400:    */         }
/* 401:    */       }
/* 402:    */       
/* 403:    */ 
/* 404:404 */       if ("directoryChanged".equals(evt.getPropertyName())) {
/* 405:405 */         WindowsDirectoryChooserUI.this.findFile(chooser.getCurrentDirectory(), false, false);
/* 406:    */       }
/* 407:    */       
/* 408:408 */       if ("AccessoryChangedProperty".equals(evt.getPropertyName())) {
/* 409:409 */         Component oldValue = (Component)evt.getOldValue();
/* 410:410 */         Component newValue = (Component)evt.getNewValue();
/* 411:411 */         if (oldValue != null) {
/* 412:412 */           chooser.remove(oldValue);
/* 413:    */         }
/* 414:414 */         if (newValue != null) {
/* 415:415 */           chooser.add("North", newValue);
/* 416:    */         }
/* 417:417 */         chooser.revalidate();
/* 418:418 */         chooser.repaint();
/* 419:    */       }
/* 420:    */       
/* 421:421 */       if ("ControlButtonsAreShownChangedProperty".equals(evt.getPropertyName()))
/* 422:    */       {
/* 423:423 */         WindowsDirectoryChooserUI.this.updateView(chooser);
/* 424:    */       }
/* 425:    */       
/* 426:426 */       if ("showingCreateDirectory".equals(evt.getPropertyName()))
/* 427:    */       {
/* 428:428 */         WindowsDirectoryChooserUI.this.updateView(chooser); }
/* 429:    */     }
/* 430:    */     
/* 431:    */     private ChangeListener() {} }
/* 432:    */   
/* 433:433 */   private class SelectionListener implements TreeSelectionListener { SelectionListener(WindowsDirectoryChooserUI.1 x1) { this(); }
/* 434:    */     
/* 435:    */     public void valueChanged(TreeSelectionEvent e) {
/* 436:436 */       getApproveSelectionAction().setEnabled(tree.getSelectionCount() > 0);
/* 437:437 */       WindowsDirectoryChooserUI.this.setSelectedFiles();
/* 438:    */       
/* 439:    */ 
/* 440:440 */       TreePath currentDirectoryPath = tree.getSelectionPath();
/* 441:441 */       if (currentDirectoryPath != null) {
/* 442:442 */         File currentDirectory = ((WindowsDirectoryChooserUI.FileTreeNode)currentDirectoryPath.getLastPathComponent()).getFile();
/* 443:    */         
/* 444:444 */         chooser.setCurrentDirectory(currentDirectory);
/* 445:    */       }
/* 446:    */     }
/* 447:    */     
/* 448:    */     private SelectionListener() {} }
/* 449:    */   
/* 450:450 */   public Action getApproveSelectionAction() { return approveSelectionAction; }
/* 451:    */   
/* 452:    */   private void setSelectedFiles()
/* 453:    */   {
/* 454:454 */     TreePath[] selectedPaths = tree.getSelectionPaths();
/* 455:455 */     if ((selectedPaths == null) || (selectedPaths.length == 0)) {
/* 456:456 */       chooser.setSelectedFile(null);
/* 457:457 */       return;
/* 458:    */     }
/* 459:    */     
/* 460:460 */     List files = new ArrayList();
/* 461:461 */     int i = 0; for (int c = selectedPaths.length; i < c; i++) {
/* 462:462 */       LazyMutableTreeNode node = (LazyMutableTreeNode)selectedPaths[i].getLastPathComponent();
/* 463:    */       
/* 464:464 */       if ((node instanceof FileTreeNode)) {
/* 465:465 */         File f = ((FileTreeNode)node).getFile();
/* 466:466 */         files.add(f);
/* 467:    */       }
/* 468:    */     }
/* 469:    */     
/* 470:470 */     chooser.setSelectedFiles((File[])files.toArray(new File[0]));
/* 471:    */   }
/* 472:    */   
/* 473:    */   private class ApproveSelectionAction extends AbstractAction
/* 474:    */   {
/* 475:    */     public ApproveSelectionAction() {
/* 476:476 */       setEnabled(false);
/* 477:    */     }
/* 478:    */     
/* 479:    */     public void actionPerformed(ActionEvent e) {
/* 480:480 */       WindowsDirectoryChooserUI.this.setSelectedFiles();
/* 481:481 */       chooser.approveSelection();
/* 482:    */     }
/* 483:    */   }
/* 484:    */   
/* 485:    */   private class TreeExpansion
/* 486:    */     implements TreeExpansionListener
/* 487:    */   {
/* 488:    */     TreeExpansion(WindowsDirectoryChooserUI.1 x1)
/* 489:    */     {
/* 490:490 */       this();
/* 491:    */     }
/* 492:    */     
/* 493:    */ 
/* 494:    */     public void treeExpanded(TreeExpansionEvent event)
/* 495:    */     {
/* 496:496 */       if (event.getPath() != null) {
/* 497:497 */         Object lastElement = event.getPath().getLastPathComponent();
/* 498:498 */         if (((lastElement instanceof WindowsDirectoryChooserUI.FileTreeNode)) && (useNodeQueue) && 
/* 499:499 */           (((WindowsDirectoryChooserUI.FileTreeNode)lastElement).isLoaded()))
/* 500:500 */           WindowsDirectoryChooserUI.this.enqueueChildren((WindowsDirectoryChooserUI.FileTreeNode)lastElement);
/* 501:    */       }
/* 502:    */     }
/* 503:    */     
/* 504:    */     public void treeCollapsed(TreeExpansionEvent event) {}
/* 505:    */     
/* 506:    */     private TreeExpansion() {} }
/* 507:    */   
/* 508:508 */   private void enqueueChildren(FileTreeNode node) { for (Enumeration e = node.children(); e.hasMoreElements();)
/* 509:509 */       addToQueue((FileTreeNode)e.nextElement(), tree);
/* 510:    */   }
/* 511:    */   
/* 512:    */   private class FileSystemTreeRenderer extends DefaultTreeCellRenderer {
/* 513:513 */     FileSystemTreeRenderer(WindowsDirectoryChooserUI.1 x1) { this(); }
/* 514:    */     
/* 515:    */     public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
/* 516:    */     {
/* 517:517 */       super.getTreeCellRendererComponent(tree, value, sel, expanded, false, row, hasFocus);
/* 518:    */       
/* 519:    */ 
/* 520:    */ 
/* 521:521 */       if ((value instanceof WindowsDirectoryChooserUI.FileTreeNode)) {
/* 522:522 */         WindowsDirectoryChooserUI.FileTreeNode node = (WindowsDirectoryChooserUI.FileTreeNode)value;
/* 523:523 */         setText(getFileView(chooser).getName(node.getFile()));
/* 524:    */         
/* 525:525 */         if ((!OS.isMacOSX()) || (!UIManager.getLookAndFeel().isNativeLookAndFeel()))
/* 526:    */         {
/* 527:    */ 
/* 528:    */ 
/* 529:    */ 
/* 530:    */ 
/* 531:    */ 
/* 532:    */ 
/* 533:    */ 
/* 534:534 */           setIcon(getFileView(chooser).getIcon(node.getFile()));
/* 535:    */         }
/* 536:    */       }
/* 537:    */       
/* 538:538 */       return this; }
/* 539:    */     
/* 540:    */     private FileSystemTreeRenderer() {} }
/* 541:    */   
/* 542:542 */   private class NewFolderAction extends AbstractAction { NewFolderAction(WindowsDirectoryChooserUI.1 x1) { this(); }
/* 543:    */     
/* 544:    */     public void actionPerformed(ActionEvent e) {
/* 545:545 */       JFileChooser fc = getFileChooser();
/* 546:546 */       File currentDirectory = fc.getCurrentDirectory();
/* 547:    */       
/* 548:548 */       if (!currentDirectory.canWrite()) {
/* 549:549 */         JOptionPane.showMessageDialog(fc, UIManager.getString("DirectoryChooser.cantCreateFolderHere"), UIManager.getString("DirectoryChooser.cantCreateFolderHere.title"), 0);
/* 550:    */         
/* 551:    */ 
/* 552:    */ 
/* 553:    */ 
/* 554:    */ 
/* 555:555 */         return;
/* 556:    */       }
/* 557:    */       
/* 558:558 */       String newFolderName = JOptionPane.showInputDialog(fc, UIManager.getString("DirectoryChooser.enterFolderName"), newFolderText, 3);
/* 559:    */       
/* 560:    */ 
/* 561:561 */       if (newFolderName != null) {
/* 562:562 */         File newFolder = new File(currentDirectory, newFolderName);
/* 563:563 */         if (newFolder.mkdir()) {
/* 564:564 */           if (fc.isMultiSelectionEnabled()) {
/* 565:565 */             fc.setSelectedFiles(new File[] { newFolder });
/* 566:    */           } else {
/* 567:567 */             fc.setSelectedFile(newFolder);
/* 568:    */           }
/* 569:569 */           fc.rescanCurrentDirectory();
/* 570:    */         } else {
/* 571:571 */           JOptionPane.showMessageDialog(fc, UIManager.getString("DirectoryChooser.createFolderFailed"), UIManager.getString("DirectoryChooser.createFolderFailed.title"), 0);
/* 572:    */         }
/* 573:    */       }
/* 574:    */     }
/* 575:    */     
/* 576:    */     private NewFolderAction() {}
/* 577:    */   }
/* 578:    */   
/* 579:    */   private class FileSystemTreeModel
/* 580:    */     extends DefaultTreeModel
/* 581:    */   {
/* 582:    */     public FileSystemTreeModel(FileSystemView fsv)
/* 583:    */     {
/* 584:584 */       super(false);
/* 585:    */     }
/* 586:    */   }
/* 587:    */   
/* 588:    */   private class MyComputerTreeNode extends LazyMutableTreeNode
/* 589:    */   {
/* 590:    */     public MyComputerTreeNode(FileSystemView fsv) {
/* 591:591 */       super();
/* 592:    */     }
/* 593:    */     
/* 594:    */     protected void loadChildren() {
/* 595:595 */       FileSystemView fsv = (FileSystemView)getUserObject();
/* 596:596 */       File[] roots = fsv.getRoots();
/* 597:597 */       if (roots != null) {
/* 598:598 */         Arrays.sort(roots);
/* 599:599 */         int i = 0; for (int c = roots.length; i < c; i++) {
/* 600:600 */           add(new WindowsDirectoryChooserUI.FileTreeNode(WindowsDirectoryChooserUI.this, roots[i]));
/* 601:    */         }
/* 602:    */       }
/* 603:    */     }
/* 604:    */     
/* 605:    */     public String toString() {
/* 606:606 */       return "/";
/* 607:    */     }
/* 608:    */   }
/* 609:    */   
/* 610:    */   private class FileTreeNode extends LazyMutableTreeNode implements Comparable
/* 611:    */   {
/* 612:    */     public FileTreeNode(File file) {
/* 613:613 */       super();
/* 614:    */     }
/* 615:    */     
/* 616:    */     public boolean canEnqueue() {
/* 617:617 */       return (!isLoaded()) && (!chooser.getFileSystemView().isFloppyDrive(getFile())) && (!chooser.getFileSystemView().isFileSystemRoot(getFile()));
/* 618:    */     }
/* 619:    */     
/* 620:    */ 
/* 621:    */     public boolean isLeaf()
/* 622:    */     {
/* 623:623 */       if (!isLoaded()) {
/* 624:624 */         return false;
/* 625:    */       }
/* 626:626 */       return super.isLeaf();
/* 627:    */     }
/* 628:    */     
/* 629:    */     protected void loadChildren()
/* 630:    */     {
/* 631:631 */       FileTreeNode[] nodes = getChildren();
/* 632:632 */       int i = 0; for (int c = nodes.length; i < c; i++) {
/* 633:633 */         add(nodes[i]);
/* 634:    */       }
/* 635:    */     }
/* 636:    */     
/* 637:    */     private FileTreeNode[] getChildren() {
/* 638:638 */       File[] files = chooser.getFileSystemView().getFiles(getFile(), chooser.isFileHidingEnabled());
/* 639:    */       
/* 640:    */ 
/* 641:    */ 
/* 642:642 */       ArrayList nodes = new ArrayList();
/* 643:    */       
/* 644:644 */       if (files != null) {
/* 645:645 */         int i = 0; for (int c = files.length; i < c; i++) {
/* 646:646 */           if (files[i].isDirectory()) {
/* 647:647 */             nodes.add(new FileTreeNode(WindowsDirectoryChooserUI.this, files[i]));
/* 648:    */           }
/* 649:    */         }
/* 650:    */       }
/* 651:    */       
/* 652:652 */       FileTreeNode[] result = (FileTreeNode[])nodes.toArray(new FileTreeNode[0]);
/* 653:    */       
/* 654:654 */       Arrays.sort(result);
/* 655:655 */       return result;
/* 656:    */     }
/* 657:    */     
/* 658:    */     public File getFile() {
/* 659:659 */       return (File)getUserObject();
/* 660:    */     }
/* 661:    */     
/* 662:    */     public String toString() {
/* 663:663 */       return chooser.getFileSystemView().getSystemDisplayName((File)getUserObject());
/* 664:    */     }
/* 665:    */     
/* 666:    */     public int compareTo(Object o)
/* 667:    */     {
/* 668:668 */       if (!(o instanceof FileTreeNode)) return 1;
/* 669:669 */       return getFile().compareTo(((FileTreeNode)o).getFile());
/* 670:    */     }
/* 671:    */     
/* 672:    */     public void clear() {
/* 673:673 */       super.clear();
/* 674:674 */       ((DefaultTreeModel)tree.getModel()).nodeStructureChanged(this);
/* 675:    */     }
/* 676:    */   }
/* 677:    */   
/* 678:    */   protected class WindowsFileView
/* 679:    */     extends BasicFileChooserUI.BasicFileView
/* 680:    */   {
/* 681:681 */     protected WindowsFileView() { super(); }
/* 682:    */     
/* 683:    */     public Icon getIcon(File f) {
/* 684:684 */       Icon icon = getCachedIcon(f);
/* 685:685 */       if (icon != null) return icon;
/* 686:686 */       if (f != null) {
/* 687:687 */         icon = getFileChooser().getFileSystemView().getSystemIcon(f);
/* 688:    */       }
/* 689:689 */       if (icon == null) {
/* 690:690 */         icon = super.getIcon(f);
/* 691:    */       }
/* 692:692 */       cacheIcon(f, icon);
/* 693:693 */       return icon;
/* 694:    */     }
/* 695:    */   }
/* 696:    */   
/* 697:    */   private static synchronized void addToQueue(FileTreeNode node, JTree tree) {
/* 698:698 */     if ((nodeQueue == null) || (!nodeQueue.isAlive())) {
/* 699:699 */       nodeQueue = new Queue();
/* 700:700 */       nodeQueue.start();
/* 701:    */     }
/* 702:702 */     if (node.canEnqueue()) {
/* 703:703 */       nodeQueue.add(node, tree);
/* 704:    */     }
/* 705:    */   }
/* 706:    */   
/* 707:    */ 
/* 708:    */ 
/* 709:    */   private static final class Queue
/* 710:    */     extends Thread
/* 711:    */   {
/* 712:712 */     private volatile Stack nodes = new Stack();
/* 713:    */     
/* 714:714 */     private Object lock = new Object();
/* 715:    */     
/* 716:716 */     private volatile boolean running = true;
/* 717:    */     
/* 718:    */     public Queue() {
/* 719:719 */       super();
/* 720:720 */       setDaemon(true);
/* 721:    */     }
/* 722:    */     
/* 723:    */     public void add(WindowsDirectoryChooserUI.FileTreeNode node, JTree tree) {
/* 724:724 */       if (!isAlive()) {
/* 725:725 */         throw new IllegalArgumentException("Queue is no longer alive");
/* 726:    */       }
/* 727:    */       
/* 728:728 */       synchronized (lock) {
/* 729:729 */         if (running) {
/* 730:730 */           nodes.addElement(new WindowsDirectoryChooserUI.QueueItem(node, tree));
/* 731:731 */           lock.notifyAll();
/* 732:    */         }
/* 733:    */       }
/* 734:    */     }
/* 735:    */     
/* 736:    */     public void run() {
/* 737:737 */       while (running) {
/* 738:738 */         while (nodes.size() > 0) {
/* 739:739 */           WindowsDirectoryChooserUI.QueueItem item = (WindowsDirectoryChooserUI.QueueItem)nodes.pop();
/* 740:740 */           WindowsDirectoryChooserUI.FileTreeNode node = node;
/* 741:741 */           JTree tree = tree;
/* 742:    */           
/* 743:    */ 
/* 744:744 */           node.getChildCount();
/* 745:    */           
/* 746:746 */           Runnable runnable = new WindowsDirectoryChooserUI.2(this, tree, node);
/* 747:    */           
/* 748:    */ 
/* 749:    */ 
/* 750:    */ 
/* 751:    */ 
/* 752:    */           try
/* 753:    */           {
/* 754:754 */             SwingUtilities.invokeAndWait(runnable);
/* 755:    */           } catch (InterruptedException e) {
/* 756:756 */             e.printStackTrace();
/* 757:    */           } catch (InvocationTargetException e) {
/* 758:758 */             e.printStackTrace();
/* 759:    */           }
/* 760:    */         }
/* 761:    */         
/* 762:    */ 
/* 763:    */ 
/* 764:    */         try
/* 765:    */         {
/* 766:766 */           synchronized (lock) {
/* 767:767 */             lock.wait(5000L);
/* 768:    */           }
/* 769:    */           
/* 770:770 */           if (nodes.size() == 0) {
/* 771:771 */             running = false;
/* 772:    */           }
/* 773:    */         }
/* 774:    */         catch (InterruptedException e) {
/* 775:775 */           e.printStackTrace();
/* 776:    */         }
/* 777:    */       }
/* 778:    */     }
/* 779:    */   }
/* 780:    */   
/* 781:    */   private static final class QueueItem
/* 782:    */   {
/* 783:    */     WindowsDirectoryChooserUI.FileTreeNode node;
/* 784:    */     JTree tree;
/* 785:    */     
/* 786:    */     public QueueItem(WindowsDirectoryChooserUI.FileTreeNode node, JTree tree)
/* 787:    */     {
/* 788:788 */       this.node = node;
/* 789:789 */       this.tree = tree;
/* 790:    */     }
/* 791:    */   }
/* 792:    */ }
