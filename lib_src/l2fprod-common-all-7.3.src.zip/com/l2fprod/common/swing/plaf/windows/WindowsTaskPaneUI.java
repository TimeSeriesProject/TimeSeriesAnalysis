/*  1:   */ package com.l2fprod.common.swing.plaf.windows;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneUI;
/*  4:   */ import javax.swing.JComponent;
/*  5:   */ import javax.swing.plaf.ComponentUI;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class WindowsTaskPaneUI
/* 29:   */   extends BasicTaskPaneUI
/* 30:   */ {
/* 31:   */   public static ComponentUI createUI(JComponent c)
/* 32:   */   {
/* 33:33 */     return new WindowsTaskPaneUI();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void installUI(JComponent c) {
/* 37:37 */     super.installUI(c);
/* 38:   */   }
/* 39:   */ }
