/*   1:    */ package com.l2fprod.common.swing.plaf.windows;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JTaskPaneGroup;
/*   4:    */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI;
/*   5:    */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI.PaneBorder;
/*   6:    */ import java.awt.ComponentOrientation;
/*   7:    */ import java.awt.Container;
/*   8:    */ import java.awt.GradientPaint;
/*   9:    */ import java.awt.Graphics;
/*  10:    */ import java.awt.Graphics2D;
/*  11:    */ import java.awt.Paint;
/*  12:    */ import java.awt.RenderingHints;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.border.Border;
/*  15:    */ import javax.swing.plaf.ComponentUI;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class WindowsTaskPaneGroupUI
/*  37:    */   extends BasicTaskPaneGroupUI
/*  38:    */ {
/*  39:    */   public static ComponentUI createUI(JComponent c)
/*  40:    */   {
/*  41: 41 */     return new WindowsTaskPaneGroupUI();
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected Border createPaneBorder() {
/*  45: 45 */     return new XPPaneBorder();
/*  46:    */   }
/*  47:    */   
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */   public void update(Graphics g, JComponent c)
/*  52:    */   {
/*  53: 53 */     if (c.isOpaque()) {
/*  54: 54 */       g.setColor(c.getParent().getBackground());
/*  55: 55 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*  56: 56 */       g.setColor(c.getBackground());
/*  57: 57 */       g.fillRect(0, ROUND_HEIGHT, c.getWidth(), c.getHeight() - ROUND_HEIGHT);
/*  58:    */     }
/*  59: 59 */     paint(g, c);
/*  60:    */   }
/*  61:    */   
/*  62:    */ 
/*  63:    */ 
/*  64:    */   class XPPaneBorder
/*  65:    */     extends BasicTaskPaneGroupUI.PaneBorder
/*  66:    */   {
/*  67: 67 */     XPPaneBorder() { super(); }
/*  68:    */     
/*  69:    */     protected void paintTitleBackground(JTaskPaneGroup group, Graphics g) {
/*  70: 70 */       if (group.isSpecial()) {
/*  71: 71 */         g.setColor(specialTitleBackground);
/*  72: 72 */         g.fillRoundRect(0, 0, group.getWidth(), WindowsTaskPaneGroupUI.ROUND_HEIGHT * 2, WindowsTaskPaneGroupUI.ROUND_HEIGHT, WindowsTaskPaneGroupUI.ROUND_HEIGHT);
/*  73:    */         
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79: 79 */         g.fillRect(0, WindowsTaskPaneGroupUI.ROUND_HEIGHT, group.getWidth(), WindowsTaskPaneGroupUI.TITLE_HEIGHT - WindowsTaskPaneGroupUI.ROUND_HEIGHT);
/*  80:    */ 
/*  81:    */       }
/*  82:    */       else
/*  83:    */       {
/*  84:    */ 
/*  85: 85 */         Paint oldPaint = ((Graphics2D)g).getPaint();
/*  86: 86 */         GradientPaint gradient = new GradientPaint(0.0F, group.getWidth() / 2, group.getComponentOrientation().isLeftToRight() ? titleBackgroundGradientStart : titleBackgroundGradientEnd, group.getWidth(), WindowsTaskPaneGroupUI.TITLE_HEIGHT, group.getComponentOrientation().isLeftToRight() ? titleBackgroundGradientEnd : titleBackgroundGradientStart);
/*  87:    */         
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98: 98 */         ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
/*  99:    */         
/* 100:    */ 
/* 101:101 */         ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 102:    */         
/* 103:    */ 
/* 104:104 */         ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
/* 105:    */         
/* 106:    */ 
/* 107:107 */         ((Graphics2D)g).setPaint(gradient);
/* 108:108 */         g.fillRoundRect(0, 0, group.getWidth(), WindowsTaskPaneGroupUI.ROUND_HEIGHT * 2, WindowsTaskPaneGroupUI.ROUND_HEIGHT, WindowsTaskPaneGroupUI.ROUND_HEIGHT);
/* 109:    */         
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:115 */         g.fillRect(0, WindowsTaskPaneGroupUI.ROUND_HEIGHT, group.getWidth(), WindowsTaskPaneGroupUI.TITLE_HEIGHT - WindowsTaskPaneGroupUI.ROUND_HEIGHT);
/* 116:    */         
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:120 */         ((Graphics2D)g).setPaint(oldPaint);
/* 121:    */       }
/* 122:    */     }
/* 123:    */     
/* 124:    */     protected void paintExpandedControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height)
/* 125:    */     {
/* 126:126 */       ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 127:    */       
/* 128:    */ 
/* 129:    */ 
/* 130:130 */       paintOvalAroundControls(group, g, x, y, width, height);
/* 131:131 */       g.setColor(getPaintColor(group));
/* 132:132 */       paintChevronControls(group, g, x, y, width, height);
/* 133:    */       
/* 134:134 */       ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/* 135:    */     }
/* 136:    */     
/* 137:    */ 
/* 138:    */     protected boolean isMouseOverBorder()
/* 139:    */     {
/* 140:140 */       return true;
/* 141:    */     }
/* 142:    */   }
/* 143:    */ }
