/*   1:    */ package com.l2fprod.common.swing.plaf.windows;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.border.ButtonBorder;
/*   4:    */ import com.l2fprod.common.swing.border.FourLineBorder;
/*   5:    */ import com.l2fprod.common.swing.plaf.basic.BasicOutlookBarUI;
/*   6:    */ import com.l2fprod.common.swing.plaf.basic.BasicOutlookBarUI.TabButton;
/*   7:    */ import java.awt.Color;
/*   8:    */ import java.awt.Component;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.Graphics;
/*  11:    */ import java.awt.Insets;
/*  12:    */ import javax.swing.AbstractButton;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.JScrollBar;
/*  15:    */ import javax.swing.JScrollPane;
/*  16:    */ import javax.swing.UIManager;
/*  17:    */ import javax.swing.border.Border;
/*  18:    */ import javax.swing.plaf.ComponentUI;
/*  19:    */ import javax.swing.plaf.basic.BasicButtonUI;
/*  20:    */ import javax.swing.plaf.basic.BasicScrollBarUI;
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public class WindowsOutlookBarUI
/*  41:    */   extends BasicOutlookBarUI
/*  42:    */ {
/*  43:    */   private Border tabButtonBorder;
/*  44:    */   
/*  45:    */   public static ComponentUI createUI(JComponent c)
/*  46:    */   {
/*  47: 47 */     return new WindowsOutlookBarUI();
/*  48:    */   }
/*  49:    */   
/*  50:    */ 
/*  51:    */   public JScrollPane makeScrollPane(Component component)
/*  52:    */   {
/*  53: 53 */     JScrollPane scroll = super.makeScrollPane(component);
/*  54: 54 */     scroll.setHorizontalScrollBarPolicy(31);
/*  55: 55 */     scroll.getVerticalScrollBar().setUI(new ThinScrollBarUI());
/*  56: 56 */     return scroll;
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected void installDefaults() {
/*  60: 60 */     super.installDefaults();
/*  61: 61 */     tabButtonBorder = UIManager.getBorder("OutlookBar.tabButtonBorder");
/*  62:    */   }
/*  63:    */   
/*  64:    */   protected BasicOutlookBarUI.TabButton createTabButton() {
/*  65: 65 */     BasicOutlookBarUI.TabButton button = new BasicOutlookBarUI.TabButton();
/*  66: 66 */     button.setUI(new BasicButtonUI());
/*  67: 67 */     button.setBorder(tabButtonBorder);
/*  68: 68 */     return button;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static class WindowsTabButtonBorder extends ButtonBorder {
/*  72:    */     FourLineBorder normalBorder;
/*  73:    */     FourLineBorder pressedBorder;
/*  74:    */     
/*  75: 75 */     public WindowsTabButtonBorder(Color color1, Color color2) { normalBorder = new FourLineBorder(color1, color1, color2, color2);
/*  76: 76 */       pressedBorder = new FourLineBorder(color2, color2, color1, color1);
/*  77:    */     }
/*  78:    */     
/*  79:    */     protected void paintNormal(AbstractButton b, Graphics g, int x, int y, int width, int height) {
/*  80: 80 */       normalBorder.paintBorder(b, g, x, y, width, height);
/*  81:    */     }
/*  82:    */     
/*  83:    */     protected void paintDisabled(AbstractButton b, Graphics g, int x, int y, int width, int height) {
/*  84: 84 */       normalBorder.paintBorder(b, g, x, y, width, height);
/*  85:    */     }
/*  86:    */     
/*  87:    */     protected void paintRollover(AbstractButton b, Graphics g, int x, int y, int width, int height) {
/*  88: 88 */       normalBorder.paintBorder(b, g, x, y, width, height);
/*  89:    */     }
/*  90:    */     
/*  91:    */     protected void paintPressed(AbstractButton b, Graphics g, int x, int y, int width, int height) {
/*  92: 92 */       pressedBorder.paintBorder(b, g, x, y, width, height);
/*  93:    */     }
/*  94:    */     
/*  95: 95 */     public Insets getBorderInsets(Component c) { return normalBorder.getBorderInsets(c); }
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static class ThinScrollBarUI extends BasicScrollBarUI
/*  99:    */   {
/* 100:    */     public Dimension getPreferredSize(JComponent c) {
/* 101:101 */       return scrollbar.getOrientation() == 1 ? new Dimension(8, 48) : new Dimension(48, 8);
/* 102:    */     }
/* 103:    */   }
/* 104:    */ }
