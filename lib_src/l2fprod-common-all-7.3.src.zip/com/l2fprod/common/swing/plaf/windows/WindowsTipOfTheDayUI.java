/*   1:    */ package com.l2fprod.common.swing.plaf.windows;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JTipOfTheDay;
/*   4:    */ import com.l2fprod.common.swing.JTipOfTheDay.ShowOnStartupChoice;
/*   5:    */ import com.l2fprod.common.swing.plaf.basic.BasicTipOfTheDayUI;
/*   6:    */ import java.awt.BorderLayout;
/*   7:    */ import java.awt.Color;
/*   8:    */ import java.awt.Component;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.Font;
/*  11:    */ import java.awt.Graphics;
/*  12:    */ import java.awt.Insets;
/*  13:    */ import javax.swing.BorderFactory;
/*  14:    */ import javax.swing.JComponent;
/*  15:    */ import javax.swing.JDialog;
/*  16:    */ import javax.swing.JLabel;
/*  17:    */ import javax.swing.JPanel;
/*  18:    */ import javax.swing.UIManager;
/*  19:    */ import javax.swing.border.Border;
/*  20:    */ import javax.swing.border.CompoundBorder;
/*  21:    */ import javax.swing.plaf.ComponentUI;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public class WindowsTipOfTheDayUI
/*  41:    */   extends BasicTipOfTheDayUI
/*  42:    */ {
/*  43:    */   public static ComponentUI createUI(JComponent c)
/*  44:    */   {
/*  45: 45 */     return new WindowsTipOfTheDayUI((JTipOfTheDay)c);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public WindowsTipOfTheDayUI(JTipOfTheDay tipPane) {
/*  49: 49 */     super(tipPane);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public JDialog createDialog(Component parentComponent, JTipOfTheDay.ShowOnStartupChoice choice)
/*  53:    */   {
/*  54: 54 */     return createDialog(parentComponent, choice, false);
/*  55:    */   }
/*  56:    */   
/*  57:    */   protected void installComponents() {
/*  58: 58 */     tipPane.setLayout(new BorderLayout());
/*  59:    */     
/*  60:    */ 
/*  61: 61 */     JLabel tipIcon = new JLabel();
/*  62: 62 */     tipIcon.setPreferredSize(new Dimension(60, 100));
/*  63: 63 */     tipIcon.setIcon(UIManager.getIcon("TipOfTheDay.icon"));
/*  64: 64 */     tipIcon.setHorizontalAlignment(0);
/*  65: 65 */     tipIcon.setVerticalAlignment(1);
/*  66: 66 */     tipIcon.setBorder(BorderFactory.createEmptyBorder(24, 0, 0, 0));
/*  67: 67 */     tipPane.add("West", tipIcon);
/*  68:    */     
/*  69:    */ 
/*  70: 70 */     JPanel rightPane = new JPanel(new BorderLayout());
/*  71: 71 */     JLabel didYouKnow = new JLabel(UIManager.getString("TipOfTheDay.didYouKnowText"));
/*  72:    */     
/*  73: 73 */     didYouKnow.setPreferredSize(new Dimension(50, 32));
/*  74: 74 */     didYouKnow.setOpaque(true);
/*  75: 75 */     didYouKnow.setBackground(UIManager.getColor("TextArea.background"));
/*  76: 76 */     didYouKnow.setBorder(new CompoundBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, tipPane.getBackground()), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
/*  77:    */     
/*  78:    */ 
/*  79: 79 */     didYouKnow.setFont(tipPane.getFont().deriveFont(1, 15.0F));
/*  80: 80 */     rightPane.add("North", didYouKnow);
/*  81:    */     
/*  82: 82 */     tipArea = new JPanel(new BorderLayout());
/*  83: 83 */     tipArea.setOpaque(true);
/*  84: 84 */     tipArea.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
/*  85: 85 */     tipArea.setBackground(UIManager.getColor("TextArea.background"));
/*  86: 86 */     rightPane.add("Center", tipArea);
/*  87:    */     
/*  88: 88 */     tipPane.add("Center", rightPane);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static class TipAreaBorder implements Border {
/*  92:    */     public Insets getBorderInsets(Component c) {
/*  93: 93 */       return new Insets(2, 2, 2, 2);
/*  94:    */     }
/*  95:    */     
/*  96: 96 */     public boolean isBorderOpaque() { return false; }
/*  97:    */     
/*  98:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*  99:    */     {
/* 100:100 */       g.setColor(UIManager.getColor("TipOfTheDay.background"));
/* 101:101 */       g.drawLine(x, y, x + width - 1, y);
/* 102:102 */       g.drawLine(x, y, x, y + height - 1);
/* 103:    */       
/* 104:104 */       g.setColor(Color.black);
/* 105:105 */       g.drawLine(x + 1, y + 1, x + width - 3, y + 1);
/* 106:106 */       g.drawLine(x + 1, y + 1, x + 1, y + height - 3);
/* 107:    */       
/* 108:108 */       g.setColor(Color.white);
/* 109:109 */       g.drawLine(x, y + height - 1, x + width, y + height - 1);
/* 110:110 */       g.drawLine(x + width - 1, y, x + width - 1, y + height - 1);
/* 111:    */     }
/* 112:    */   }
/* 113:    */ }
