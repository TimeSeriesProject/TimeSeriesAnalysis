package com.l2fprod.common.swing.plaf.windows;

public class WindowsClassicLookAndFeelAddons
  extends WindowsLookAndFeelAddons
{}
