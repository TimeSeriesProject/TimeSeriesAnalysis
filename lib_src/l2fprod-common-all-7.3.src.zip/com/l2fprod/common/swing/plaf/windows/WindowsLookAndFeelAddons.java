package com.l2fprod.common.swing.plaf.windows;

import com.l2fprod.common.swing.plaf.basic.BasicLookAndFeelAddons;

public class WindowsLookAndFeelAddons
  extends BasicLookAndFeelAddons
{
  public static final String HOMESTEAD_VISUAL_STYLE = "HomeStead";
  public static final String SILVER_VISUAL_STYLE = "Metallic";
}
