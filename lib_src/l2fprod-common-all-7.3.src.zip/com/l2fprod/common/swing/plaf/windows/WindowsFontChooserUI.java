/*   1:    */ package com.l2fprod.common.swing.plaf.windows;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.FontChooserModel;
/*   4:    */ import com.l2fprod.common.swing.JFontChooser;
/*   5:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   6:    */ import com.l2fprod.common.swing.PercentLayout;
/*   7:    */ import com.l2fprod.common.swing.plaf.FontChooserUI;
/*   8:    */ import java.awt.Dimension;
/*   9:    */ import java.awt.Font;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.font.TextAttribute;
/*  12:    */ import java.beans.PropertyChangeEvent;
/*  13:    */ import java.beans.PropertyChangeListener;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.ResourceBundle;
/*  16:    */ import javax.swing.JComboBox;
/*  17:    */ import javax.swing.JComponent;
/*  18:    */ import javax.swing.JLabel;
/*  19:    */ import javax.swing.JList;
/*  20:    */ import javax.swing.JPanel;
/*  21:    */ import javax.swing.JScrollPane;
/*  22:    */ import javax.swing.JSplitPane;
/*  23:    */ import javax.swing.JTextArea;
/*  24:    */ import javax.swing.JTextField;
/*  25:    */ import javax.swing.SwingUtilities;
/*  26:    */ import javax.swing.event.DocumentEvent;
/*  27:    */ import javax.swing.event.ListSelectionEvent;
/*  28:    */ import javax.swing.event.ListSelectionListener;
/*  29:    */ import javax.swing.plaf.ComponentUI;
/*  30:    */ import javax.swing.text.Document;
/*  31:    */ 
/*  32:    */ public class WindowsFontChooserUI extends FontChooserUI
/*  33:    */ {
/*  34:    */   private JFontChooser chooser;
/*  35:    */   private JPanel fontPanel;
/*  36:    */   private JTextField fontField;
/*  37:    */   private JList fontList;
/*  38:    */   private JTextField fontEffectField;
/*  39:    */   private JList fontEffectList;
/*  40:    */   private JPanel fontSizePanel;
/*  41:    */   private JTextField fontSizeField;
/*  42:    */   private JList fontSizeList;
/*  43:    */   private JTextArea previewPanel;
/*  44:    */   private JComboBox charSetCombo;
/*  45:    */   private PropertyChangeListener propertyListener;
/*  46:    */   
/*  47:    */   public static ComponentUI createUI(JComponent component)
/*  48:    */   {
/*  49: 49 */     return new WindowsFontChooserUI();
/*  50:    */   }
/*  51:    */   
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */   public void installUI(JComponent c)
/*  70:    */   {
/*  71: 71 */     super.installUI(c);
/*  72:    */     
/*  73: 73 */     chooser = ((JFontChooser)c);
/*  74:    */     
/*  75: 75 */     installComponents();
/*  76: 76 */     installListeners();
/*  77:    */   }
/*  78:    */   
/*  79:    */ 
/*  80:    */   protected void installComponents()
/*  81:    */   {
/*  82: 82 */     ResourceBundle bundle = ResourceBundle.getBundle(FontChooserUI.class.getName() + "RB");
/*  83:    */     
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87: 87 */     fontPanel = new JPanel(new PercentLayout(1, 2));
/*  88: 88 */     fontPanel.add(label = new JLabel(bundle.getString("FontChooserUI.fontLabel")));
/*  89:    */     
/*  90: 90 */     fontPanel.add(this.fontField = new JTextField(25));
/*  91: 91 */     fontField.setEditable(false);
/*  92: 92 */     fontPanel.add(new JScrollPane(this.fontList = new JList()), "*");
/*  93: 93 */     label.setLabelFor(fontList);
/*  94: 94 */     label.setDisplayedMnemonic(bundle.getString("FontChooserUI.fontLabel.mnemonic").charAt(0));
/*  95:    */     
/*  96: 96 */     fontList.setSelectionMode(0);
/*  97:    */     
/*  98: 98 */     String[] fontFamilies = chooser.getModel().getFontFamilies(null);
/*  99: 99 */     fontList.setListData(fontFamilies);
/* 100:    */     
/* 101:    */ 
/* 102:102 */     JPanel fontEffectPanel = new JPanel(new PercentLayout(1, 2));
/* 103:    */     
/* 104:104 */     fontEffectPanel.add(label = new JLabel(bundle.getString("FontChooserUI.styleLabel")));
/* 105:    */     
/* 106:106 */     fontEffectPanel.add(this.fontEffectField = new JTextField(10));
/* 107:107 */     fontEffectField.setEditable(false);
/* 108:108 */     fontEffectPanel.add(new JScrollPane(this.fontEffectList = new JList()), "*");
/* 109:109 */     label.setLabelFor(fontEffectList);
/* 110:110 */     label.setDisplayedMnemonic(bundle.getString("FontChooserUI.styleLabel.mnemonic").charAt(0));
/* 111:    */     
/* 112:112 */     fontEffectList.setSelectionMode(0);
/* 113:    */     
/* 114:114 */     FontStyle[] fontStyles = { new FontStyle(0, bundle.getString("FontChooserUI.style.plain")), new FontStyle(1, bundle.getString("FontChooserUI.style.bold")), new FontStyle(2, bundle.getString("FontChooserUI.style.italic")), new FontStyle(3, bundle.getString("FontChooserUI.style.bolditalic")) };
/* 115:    */     
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:121 */     fontEffectList.setListData(fontStyles);
/* 122:    */     
/* 123:    */ 
/* 124:124 */     fontSizePanel = new JPanel(new PercentLayout(1, 2));
/* 125:125 */     fontSizePanel.add(label = new JLabel(bundle.getString("FontChooserUI.sizeLabel")));
/* 126:    */     
/* 127:    */ 
/* 128:128 */     label.setDisplayedMnemonic(bundle.getString("FontChooserUI.sizeLabel.mnemonic").charAt(0));
/* 129:    */     
/* 130:    */ 
/* 131:131 */     fontSizePanel.add(this.fontSizeField = new JTextField(5));
/* 132:132 */     label.setLabelFor(fontSizeField);
/* 133:133 */     fontSizePanel.add(new JScrollPane(this.fontSizeList = new JList()), "*");
/* 134:    */     
/* 135:135 */     int[] defaultFontSizes = chooser.getModel().getDefaultSizes();
/* 136:136 */     String[] sizes = new String[defaultFontSizes.length];
/* 137:137 */     int i = 0; for (int c = sizes.length; i < c; i++) {
/* 138:138 */       sizes[i] = String.valueOf(defaultFontSizes[i]);
/* 139:    */     }
/* 140:140 */     fontSizeList.setPrototypeCellValue("012345");
/* 141:141 */     fontSizeList.setListData(sizes);
/* 142:142 */     fontSizeList.setSelectionMode(0);
/* 143:143 */     fontSizeList.setVisibleRowCount(2);
/* 144:    */     
/* 145:145 */     chooser.setLayout(LookAndFeelTweaks.createBorderLayout());
/* 146:146 */     JPanel panel = new JPanel();
/* 147:147 */     panel.setLayout(LookAndFeelTweaks.createHorizontalPercentLayout());
/* 148:148 */     panel.add(fontPanel, "*");
/* 149:149 */     panel.add(fontEffectPanel);
/* 150:150 */     panel.add(fontSizePanel);
/* 151:    */     
/* 152:152 */     previewPanel = new JTextArea();
/* 153:153 */     previewPanel.setText(chooser.getModel().getPreviewMessage(null));
/* 154:154 */     JScrollPane scroll = new JScrollPane(previewPanel);
/* 155:    */     
/* 156:156 */     JSplitPane split = new JSplitPane(0);
/* 157:157 */     split.setBorder(null);
/* 158:158 */     split.setTopComponent(panel);
/* 159:159 */     split.setBottomComponent(scroll);
/* 160:160 */     split.setDividerLocation(0.5D);
/* 161:161 */     split.setOneTouchExpandable(true);
/* 162:162 */     chooser.add("Center", split);
/* 163:    */     
/* 164:    */ 
/* 165:165 */     panel.setMinimumSize(new Dimension(0, 0));
/* 166:    */     
/* 167:167 */     JPanel charSetPanel = new JPanel(new PercentLayout(0, 2));
/* 168:    */     
/* 169:169 */     JLabel label = new JLabel("CHARSET");
/* 170:170 */     label.setHorizontalAlignment(4);
/* 171:171 */     charSetPanel.add(label, "*");
/* 172:    */     
/* 173:173 */     charSetCombo = new JComboBox(chooser.getModel().getCharSets());
/* 174:174 */     charSetPanel.add(charSetCombo);
/* 175:    */   }
/* 176:    */   
/* 177:    */ 
/* 178:    */   protected void installListeners()
/* 179:    */   {
/* 180:180 */     SelectedFontUpdater listener = new SelectedFontUpdater(null);
/* 181:181 */     fontList.addListSelectionListener(listener);
/* 182:182 */     fontEffectList.addListSelectionListener(listener);
/* 183:183 */     fontSizeList.addListSelectionListener(listener);
/* 184:184 */     fontSizeField.getDocument().addDocumentListener(listener);
/* 185:    */     
/* 186:186 */     propertyListener = createPropertyChangeListener();
/* 187:187 */     chooser.addPropertyChangeListener("selectedFont", propertyListener);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void uninstallUI(JComponent c)
/* 191:    */   {
/* 192:192 */     chooser.remove(fontPanel);
/* 193:193 */     chooser.remove(fontSizePanel);
/* 194:    */     
/* 195:195 */     super.uninstallUI(c);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void uninstallListeners() {
/* 199:199 */     chooser.removePropertyChangeListener(propertyListener);
/* 200:    */   }
/* 201:    */   
/* 202:    */   protected PropertyChangeListener createPropertyChangeListener() {
/* 203:203 */     new PropertyChangeListener()
/* 204:    */     {
/* 205:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 206:206 */         WindowsFontChooserUI.this.updateDisplay();
/* 207:    */       }
/* 208:    */     };
/* 209:    */   }
/* 210:    */   
/* 211:    */   private void updateDisplay() {
/* 212:212 */     Font selected = chooser.getSelectedFont();
/* 213:213 */     if (selected != null)
/* 214:    */     {
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:224 */       previewPanel.setFont(selected);
/* 225:225 */       fontList.setSelectedValue(selected.getName(), true);
/* 226:226 */       fontSizeField.setText(String.valueOf(selected.getSize()));
/* 227:227 */       fontSizeList.setSelectedValue(String.valueOf(selected.getSize()), true);
/* 228:    */       
/* 229:229 */       FontStyle style = new FontStyle(selected.getStyle(), null);
/* 230:230 */       fontEffectList.setSelectedValue(style, true);
/* 231:231 */       style = (FontStyle)fontEffectList.getSelectedValue();
/* 232:232 */       fontEffectField.setText(style.toString());
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   private void updateSelectedFont() {
/* 237:237 */     Font currentFont = chooser.getSelectedFont();
/* 238:238 */     String fontFamily = currentFont == null ? "SansSerif" : currentFont.getName();
/* 239:239 */     int fontSize = currentFont == null ? 11 : currentFont.getSize();
/* 240:    */     
/* 241:241 */     if (fontList.getSelectedIndex() >= 0) {
/* 242:242 */       fontFamily = (String)fontList.getSelectedValue();
/* 243:    */     }
/* 244:    */     
/* 245:245 */     if (fontSizeField.getText().trim().length() > 0) {
/* 246:    */       try {
/* 247:247 */         fontSize = Integer.parseInt(fontSizeField.getText().trim());
/* 248:    */       }
/* 249:    */       catch (Exception e) {}
/* 250:    */     }
/* 251:    */     
/* 252:    */ 
/* 253:253 */     Map attributes = new java.util.HashMap();
/* 254:254 */     attributes.put(TextAttribute.SIZE, new Float(fontSize));
/* 255:255 */     attributes.put(TextAttribute.FAMILY, fontFamily);
/* 256:    */     
/* 257:257 */     FontStyle style = (FontStyle)fontEffectList.getSelectedValue();
/* 258:258 */     if (style != null) {
/* 259:259 */       if (style.isBold()) {
/* 260:260 */         attributes.put(TextAttribute.WEIGHT, TextAttribute.WEIGHT_BOLD);
/* 261:    */       }
/* 262:262 */       if (style.isItalic()) {
/* 263:263 */         attributes.put(TextAttribute.POSTURE, TextAttribute.POSTURE_OBLIQUE);
/* 264:    */       }
/* 265:    */     }
/* 266:    */     
/* 267:267 */     Font font = Font.getFont(attributes);
/* 268:268 */     if (!font.equals(currentFont)) {
/* 269:269 */       chooser.setSelectedFont(font);
/* 270:270 */       previewPanel.setFont(font);
/* 271:    */     }
/* 272:    */   }
/* 273:    */   
/* 274:274 */   private class SelectedFontUpdater implements ListSelectionListener, javax.swing.event.DocumentListener, java.awt.event.ActionListener { SelectedFontUpdater(WindowsFontChooserUI.1 x1) { this(); }
/* 275:    */     
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */     public void valueChanged(ListSelectionEvent e)
/* 280:    */     {
/* 281:281 */       if ((fontList == e.getSource()) && (fontList.getSelectedValue() != null)) {
/* 282:282 */         fontField.setText((String)fontList.getSelectedValue());
/* 283:    */       }
/* 284:284 */       if ((fontSizeList == e.getSource()) && (fontSizeList.getSelectedValue() != null))
/* 285:    */       {
/* 286:286 */         fontSizeField.setText((String)fontSizeList.getSelectedValue());
/* 287:    */       }
/* 288:288 */       WindowsFontChooserUI.this.updateSelectedFont();
/* 289:    */     }
/* 290:    */     
/* 291:    */     public void changedUpdate(DocumentEvent e) {
/* 292:292 */       updateLater();
/* 293:    */     }
/* 294:    */     
/* 295:    */     public void insertUpdate(DocumentEvent e) {
/* 296:296 */       updateLater();
/* 297:    */     }
/* 298:    */     
/* 299:    */     public void removeUpdate(DocumentEvent e) {
/* 300:300 */       updateLater();
/* 301:    */     }
/* 302:    */     
/* 303:    */     public void actionPerformed(ActionEvent e) {
/* 304:304 */       updateLater();
/* 305:    */     }
/* 306:    */     
/* 307:    */     void updateLater() {
/* 308:308 */       SwingUtilities.invokeLater(new WindowsFontChooserUI.2(this));
/* 309:    */     }
/* 310:    */     
/* 311:    */ 
/* 312:    */     private SelectedFontUpdater() {}
/* 313:    */   }
/* 314:    */   
/* 315:    */ 
/* 316:    */   private static class FontStyle
/* 317:    */   {
/* 318:    */     String display;
/* 319:    */     int value;
/* 320:    */     
/* 321:    */     public FontStyle(int value, String display)
/* 322:    */     {
/* 323:323 */       this.value = value;
/* 324:324 */       this.display = display;
/* 325:    */     }
/* 326:    */     
/* 327:    */     public int value() {
/* 328:328 */       return value;
/* 329:    */     }
/* 330:    */     
/* 331:    */     public String toString() {
/* 332:332 */       return display;
/* 333:    */     }
/* 334:    */     
/* 335:    */     public boolean isBold() {
/* 336:336 */       return (value & 0x1) != 0;
/* 337:    */     }
/* 338:    */     
/* 339:    */     public boolean isItalic() {
/* 340:340 */       return (value & 0x2) != 0;
/* 341:    */     }
/* 342:    */     
/* 343:    */     public int hashCode() {
/* 344:344 */       return value;
/* 345:    */     }
/* 346:    */     
/* 347:    */     public boolean equals(Object obj) {
/* 348:348 */       return ((obj instanceof FontStyle)) && (value == value);
/* 349:    */     }
/* 350:    */   }
/* 351:    */ }
