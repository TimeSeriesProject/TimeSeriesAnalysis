/*  1:   */ package com.l2fprod.common.swing.plaf.windows;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.basic.BasicLinkButtonUI;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import javax.swing.AbstractButton;
/*  6:   */ import javax.swing.JComponent;
/*  7:   */ import javax.swing.plaf.ComponentUI;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ public class WindowsLinkButtonUI
/* 31:   */   extends BasicLinkButtonUI
/* 32:   */ {
/* 33:33 */   private static WindowsLinkButtonUI buttonUI = new WindowsLinkButtonUI();
/* 34:   */   
/* 35:   */   public static ComponentUI createUI(JComponent c) {
/* 36:36 */     return buttonUI;
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected void paintButtonPressed(Graphics g, AbstractButton b) {
/* 40:40 */     setTextShiftOffset();
/* 41:   */   }
/* 42:   */ }
