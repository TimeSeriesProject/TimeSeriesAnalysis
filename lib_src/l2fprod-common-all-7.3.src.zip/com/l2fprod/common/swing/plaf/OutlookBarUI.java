package com.l2fprod.common.swing.plaf;

import java.awt.Component;
import javax.swing.JScrollPane;

public abstract interface OutlookBarUI
{
  public abstract JScrollPane makeScrollPane(Component paramComponent);
}
