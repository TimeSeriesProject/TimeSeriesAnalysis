/*  1:   */ package com.l2fprod.common.swing.plaf;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.border.FourLineBorder;
/*  4:   */ import com.l2fprod.common.swing.plaf.basic.BasicOutlookButtonUI;
/*  5:   */ import com.l2fprod.common.swing.plaf.basic.BasicOutlookButtonUI.OutlookButtonBorder;
/*  6:   */ import com.l2fprod.common.swing.plaf.windows.WindowsOutlookBarUI;
/*  7:   */ import com.l2fprod.common.swing.plaf.windows.WindowsOutlookBarUI.WindowsTabButtonBorder;
/*  8:   */ import java.awt.Color;
/*  9:   */ import java.util.Arrays;
/* 10:   */ import java.util.List;
/* 11:   */ import javax.swing.BorderFactory;
/* 12:   */ import javax.swing.UIManager;
/* 13:   */ import javax.swing.border.Border;
/* 14:   */ import javax.swing.border.CompoundBorder;
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ public class JOutlookBarAddon
/* 38:   */   extends AbstractComponentAddon
/* 39:   */ {
/* 40:   */   public JOutlookBarAddon()
/* 41:   */   {
/* 42:42 */     super("JOutlookBar");
/* 43:   */   }
/* 44:   */   
/* 45:   */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/* 46:46 */     Color barBackground = new Color(167, 166, 170);
/* 47:   */     
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:52 */     Color background = UIManager.getColor("Button.background");
/* 53:53 */     if (background == null)
/* 54:   */     {
/* 55:55 */       background = UIManager.getColor("control");
/* 56:   */     }
/* 57:57 */     if (background == null) {
/* 58:58 */       background = new Color(238, 238, 238);
/* 59:   */     }
/* 60:60 */     Color color1 = background.brighter();
/* 61:61 */     Color color2 = background.darker();
/* 62:   */     
/* 63:63 */     Border outlookBarButtonBorder = new WindowsOutlookBarUI.WindowsTabButtonBorder(color1, color2);
/* 64:   */     
/* 65:65 */     outlookBarButtonBorder = new CompoundBorder(outlookBarButtonBorder, BorderFactory.createEmptyBorder(3, 3, 3, 3));
/* 66:   */     
/* 67:   */ 
/* 68:68 */     Border outlookBarBorder = new FourLineBorder(color2, color2, color1, color1);
/* 69:   */     
/* 70:   */ 
/* 71:   */ 
/* 72:   */ 
/* 73:   */ 
/* 74:74 */     Color color1 = barBackground.brighter();
/* 75:75 */     Color color2 = barBackground.darker();
/* 76:   */     
/* 77:77 */     Border outlookButtonBorder = new BasicOutlookButtonUI.OutlookButtonBorder(color1, color2);
/* 78:   */     
/* 79:79 */     outlookButtonBorder = new CompoundBorder(outlookButtonBorder, BorderFactory.createEmptyBorder(3, 3, 3, 3));
/* 80:   */     
/* 81:   */ 
/* 82:   */ 
/* 83:83 */     defaults.addAll(Arrays.asList(new Object[] { "OutlookBarUI", WindowsOutlookBarUI.class.getName(), "OutlookButtonUI", BasicOutlookButtonUI.class.getName(), "OutlookBar.background", barBackground, "OutlookBar.border", outlookBarBorder, "OutlookBar.tabButtonBorder", outlookBarButtonBorder, "OutlookButton.border", outlookButtonBorder, "OutlookBar.tabAlignment", new Integer(0) }));
/* 84:   */   }
/* 85:   */ }
