package com.l2fprod.common.swing.plaf;

import javax.swing.plaf.ComponentUI;

public class TaskPaneUI
  extends ComponentUI
{}
