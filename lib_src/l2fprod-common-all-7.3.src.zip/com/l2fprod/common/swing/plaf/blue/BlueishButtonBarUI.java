/*  1:   */ package com.l2fprod.common.swing.plaf.blue;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JButtonBar;
/*  4:   */ import com.l2fprod.common.swing.plaf.ButtonBarButtonUI;
/*  5:   */ import com.l2fprod.common.swing.plaf.basic.BasicButtonBarUI;
/*  6:   */ import java.awt.Color;
/*  7:   */ import javax.swing.AbstractButton;
/*  8:   */ import javax.swing.BorderFactory;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.UIManager;
/* 11:   */ import javax.swing.border.Border;
/* 12:   */ import javax.swing.border.CompoundBorder;
/* 13:   */ import javax.swing.plaf.BorderUIResource;
/* 14:   */ import javax.swing.plaf.ColorUIResource;
/* 15:   */ import javax.swing.plaf.ComponentUI;
/* 16:   */ import javax.swing.plaf.UIResource;
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ public class BlueishButtonBarUI
/* 40:   */   extends BasicButtonBarUI
/* 41:   */ {
/* 42:   */   public static ComponentUI createUI(JComponent c)
/* 43:   */   {
/* 44:44 */     return new BlueishButtonBarUI();
/* 45:   */   }
/* 46:   */   
/* 47:   */   protected void installDefaults() {
/* 48:48 */     Border b = bar.getBorder();
/* 49:49 */     if ((b == null) || ((b instanceof UIResource))) {
/* 50:50 */       bar.setBorder(new BorderUIResource(new CompoundBorder(BorderFactory.createLineBorder(UIManager.getColor("controlDkShadow")), BorderFactory.createEmptyBorder(1, 1, 1, 1))));
/* 51:   */     }
/* 52:   */     
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:58 */     Color color = bar.getBackground();
/* 59:59 */     if ((color == null) || ((color instanceof ColorUIResource))) {
/* 60:60 */       bar.setOpaque(true);
/* 61:61 */       bar.setBackground(new ColorUIResource(Color.white));
/* 62:   */     }
/* 63:   */   }
/* 64:   */   
/* 65:   */   public void installButtonBarUI(AbstractButton button) {
/* 66:66 */     button.setUI(new BlueishButtonBarButtonUI());
/* 67:67 */     button.setHorizontalTextPosition(0);
/* 68:68 */     button.setVerticalTextPosition(3);
/* 69:69 */     button.setOpaque(false);
/* 70:   */   }
/* 71:   */   
/* 72:   */   static class BlueishButtonBarButtonUI
/* 73:   */     extends BlueishButtonUI
/* 74:   */     implements ButtonBarButtonUI
/* 75:   */   {}
/* 76:   */ }
