/*  1:   */ package com.l2fprod.common.swing.plaf.blue;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import javax.swing.AbstractButton;
/*  6:   */ import javax.swing.BorderFactory;
/*  7:   */ import javax.swing.ButtonModel;
/*  8:   */ import javax.swing.JComponent;
/*  9:   */ import javax.swing.plaf.basic.BasicButtonUI;
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ public class BlueishButtonUI
/* 33:   */   extends BasicButtonUI
/* 34:   */ {
/* 35:35 */   private static Color blueishBackgroundOver = new Color(224, 232, 246);
/* 36:36 */   private static Color blueishBorderOver = new Color(152, 180, 226);
/* 37:   */   
/* 38:38 */   private static Color blueishBackgroundSelected = new Color(193, 210, 238);
/* 39:39 */   private static Color blueishBorderSelected = new Color(49, 106, 197);
/* 40:   */   
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */   public void installUI(JComponent c)
/* 45:   */   {
/* 46:46 */     super.installUI(c);
/* 47:   */     
/* 48:48 */     AbstractButton button = (AbstractButton)c;
/* 49:49 */     button.setRolloverEnabled(true);
/* 50:50 */     button.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void paint(Graphics g, JComponent c) {
/* 54:54 */     AbstractButton button = (AbstractButton)c;
/* 55:55 */     if ((button.getModel().isRollover()) || (button.getModel().isArmed()) || (button.getModel().isSelected()))
/* 56:   */     {
/* 57:   */ 
/* 58:58 */       Color oldColor = g.getColor();
/* 59:59 */       if (button.getModel().isSelected()) {
/* 60:60 */         g.setColor(blueishBackgroundSelected);
/* 61:   */       } else {
/* 62:62 */         g.setColor(blueishBackgroundOver);
/* 63:   */       }
/* 64:64 */       g.fillRect(0, 0, c.getWidth() - 1, c.getHeight() - 1);
/* 65:   */       
/* 66:66 */       if (button.getModel().isSelected()) {
/* 67:67 */         g.setColor(blueishBorderSelected);
/* 68:   */       } else {
/* 69:69 */         g.setColor(blueishBorderOver);
/* 70:   */       }
/* 71:71 */       g.drawRect(0, 0, c.getWidth() - 1, c.getHeight() - 1);
/* 72:   */       
/* 73:73 */       g.setColor(oldColor);
/* 74:   */     }
/* 75:   */     
/* 76:76 */     super.paint(g, c);
/* 77:   */   }
/* 78:   */ }
