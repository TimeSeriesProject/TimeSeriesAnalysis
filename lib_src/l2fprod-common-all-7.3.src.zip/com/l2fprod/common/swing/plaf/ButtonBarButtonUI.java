package com.l2fprod.common.swing.plaf;

public abstract interface ButtonBarButtonUI {}
