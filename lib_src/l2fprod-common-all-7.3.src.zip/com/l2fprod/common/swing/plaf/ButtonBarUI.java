package com.l2fprod.common.swing.plaf;

import javax.swing.AbstractButton;
import javax.swing.plaf.ComponentUI;

public abstract class ButtonBarUI
  extends ComponentUI
{
  public void installButtonBarUI(AbstractButton button) {}
}
