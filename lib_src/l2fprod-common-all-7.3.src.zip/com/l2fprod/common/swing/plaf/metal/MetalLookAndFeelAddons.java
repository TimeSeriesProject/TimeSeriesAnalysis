/*  1:   */ package com.l2fprod.common.swing.plaf.metal;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.basic.BasicLookAndFeelAddons;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ public class MetalLookAndFeelAddons
/* 55:   */   extends BasicLookAndFeelAddons
/* 56:   */ {
/* 57:   */   public void initialize()
/* 58:   */   {
/* 59:59 */     super.initialize();
/* 60:60 */     loadDefaults(getDefaults());
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void uninitialize() {
/* 64:64 */     super.uninitialize();
/* 65:65 */     unloadDefaults(getDefaults());
/* 66:   */   }
/* 67:   */   
/* 68:   */   private Object[] getDefaults() {
/* 69:69 */     Object[] defaults = { "DirectoryChooserUI", "com.l2fprod.common.swing.plaf.windows.WindowsDirectoryChooserUI" };
/* 70:   */     
/* 71:   */ 
/* 72:   */ 
/* 73:   */ 
/* 74:74 */     return defaults;
/* 75:   */   }
/* 76:   */ }
