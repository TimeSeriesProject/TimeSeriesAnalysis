/*  1:   */ package com.l2fprod.common.swing.plaf.metal;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JTaskPaneGroup;
/*  4:   */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI;
/*  5:   */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI.PaneBorder;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ import java.awt.Graphics2D;
/*  8:   */ import java.awt.RenderingHints;
/*  9:   */ import javax.swing.JComponent;
/* 10:   */ import javax.swing.border.Border;
/* 11:   */ import javax.swing.plaf.ComponentUI;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ public class MetalTaskPaneGroupUI
/* 35:   */   extends BasicTaskPaneGroupUI
/* 36:   */ {
/* 37:   */   public static ComponentUI createUI(JComponent c)
/* 38:   */   {
/* 39:39 */     return new MetalTaskPaneGroupUI();
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected void installDefaults() {
/* 43:43 */     super.installDefaults();
/* 44:44 */     group.setOpaque(false);
/* 45:   */   }
/* 46:   */   
/* 47:   */   protected Border createPaneBorder() {
/* 48:48 */     return new MetalPaneBorder();
/* 49:   */   }
/* 50:   */   
/* 51:   */   class MetalPaneBorder
/* 52:   */     extends BasicTaskPaneGroupUI.PaneBorder
/* 53:   */   {
/* 54:   */     MetalPaneBorder()
/* 55:   */     {
/* 56:56 */       super();
/* 57:   */     }
/* 58:   */     
/* 59:   */     protected void paintExpandedControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height) {
/* 60:60 */       ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 61:   */       
/* 62:   */ 
/* 63:   */ 
/* 64:64 */       g.setColor(getPaintColor(group));
/* 65:65 */       paintRectAroundControls(group, g, x, y, width, height, g.getColor(), g.getColor());
/* 66:   */       
/* 67:67 */       paintChevronControls(group, g, x, y, width, height);
/* 68:   */       
/* 69:69 */       ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/* 70:   */     }
/* 71:   */     
/* 72:   */ 
/* 73:   */     protected boolean isMouseOverBorder()
/* 74:   */     {
/* 75:75 */       return true;
/* 76:   */     }
/* 77:   */   }
/* 78:   */ }
