/*   1:    */ package com.l2fprod.common.swing.plaf.misc;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JTaskPaneGroup;
/*   4:    */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI;
/*   5:    */ import com.l2fprod.common.swing.plaf.basic.BasicTaskPaneGroupUI.PaneBorder;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.GradientPaint;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Graphics2D;
/*  10:    */ import java.awt.Paint;
/*  11:    */ import java.awt.Rectangle;
/*  12:    */ import java.awt.RenderingHints;
/*  13:    */ import java.awt.Shape;
/*  14:    */ import javax.swing.JComponent;
/*  15:    */ import javax.swing.border.Border;
/*  16:    */ import javax.swing.plaf.ComponentUI;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class GlossyTaskPaneGroupUI
/*  37:    */   extends BasicTaskPaneGroupUI
/*  38:    */ {
/*  39:    */   public static ComponentUI createUI(JComponent c)
/*  40:    */   {
/*  41: 41 */     return new GlossyTaskPaneGroupUI();
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected Border createPaneBorder() {
/*  45: 45 */     return new GlossyPaneBorder();
/*  46:    */   }
/*  47:    */   
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */   public void update(Graphics g, JComponent c)
/*  52:    */   {
/*  53: 53 */     if (c.isOpaque()) {
/*  54: 54 */       g.setColor(c.getParent().getBackground());
/*  55: 55 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*  56: 56 */       g.setColor(c.getBackground());
/*  57: 57 */       g.fillRect(0, ROUND_HEIGHT, c.getWidth(), c.getHeight() - ROUND_HEIGHT);
/*  58:    */     }
/*  59: 59 */     paint(g, c);
/*  60:    */   }
/*  61:    */   
/*  62:    */ 
/*  63:    */ 
/*  64:    */   class GlossyPaneBorder
/*  65:    */     extends BasicTaskPaneGroupUI.PaneBorder
/*  66:    */   {
/*  67: 67 */     GlossyPaneBorder() { super(); }
/*  68:    */     
/*  69:    */     protected void paintTitleBackground(JTaskPaneGroup group, Graphics g) {
/*  70: 70 */       if (group.isSpecial()) {
/*  71: 71 */         g.setColor(specialTitleBackground);
/*  72: 72 */         g.fillRoundRect(0, 0, group.getWidth(), GlossyTaskPaneGroupUI.ROUND_HEIGHT * 2, GlossyTaskPaneGroupUI.ROUND_HEIGHT, GlossyTaskPaneGroupUI.ROUND_HEIGHT);
/*  73:    */         
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79: 79 */         g.fillRect(0, GlossyTaskPaneGroupUI.ROUND_HEIGHT, group.getWidth(), GlossyTaskPaneGroupUI.TITLE_HEIGHT - GlossyTaskPaneGroupUI.ROUND_HEIGHT);
/*  80:    */ 
/*  81:    */       }
/*  82:    */       else
/*  83:    */       {
/*  84:    */ 
/*  85: 85 */         Paint oldPaint = ((Graphics2D)g).getPaint();
/*  86: 86 */         GradientPaint gradient = new GradientPaint(0.0F, 0.0F, titleBackgroundGradientStart, 0.0F, GlossyTaskPaneGroupUI.TITLE_HEIGHT, titleBackgroundGradientEnd);
/*  87:    */         
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95: 95 */         ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
/*  96:    */         
/*  97:    */ 
/*  98: 98 */         ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*  99:    */         
/* 100:    */ 
/* 101:101 */         ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
/* 102:    */         
/* 103:    */ 
/* 104:104 */         ((Graphics2D)g).setPaint(gradient);
/* 105:    */         
/* 106:106 */         g.fillRoundRect(0, 0, group.getWidth(), GlossyTaskPaneGroupUI.ROUND_HEIGHT * 2, GlossyTaskPaneGroupUI.ROUND_HEIGHT, GlossyTaskPaneGroupUI.ROUND_HEIGHT);
/* 107:    */         
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:113 */         g.fillRect(0, GlossyTaskPaneGroupUI.ROUND_HEIGHT, group.getWidth(), GlossyTaskPaneGroupUI.TITLE_HEIGHT - GlossyTaskPaneGroupUI.ROUND_HEIGHT);
/* 114:    */         
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:118 */         ((Graphics2D)g).setPaint(oldPaint);
/* 119:    */       }
/* 120:    */       
/* 121:121 */       Shape oldClip = g.getClip();
/* 122:122 */       Rectangle clip = new Rectangle(0, 0, group.getWidth(), GlossyTaskPaneGroupUI.TITLE_HEIGHT);
/* 123:123 */       g.setClip(clip.intersection(oldClip.getBounds()));
/* 124:124 */       g.setColor(borderColor);
/* 125:125 */       g.drawRoundRect(0, 0, group.getWidth() - 1, GlossyTaskPaneGroupUI.TITLE_HEIGHT + GlossyTaskPaneGroupUI.ROUND_HEIGHT, GlossyTaskPaneGroupUI.ROUND_HEIGHT, GlossyTaskPaneGroupUI.ROUND_HEIGHT);
/* 126:    */       
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:132 */       g.drawLine(0, GlossyTaskPaneGroupUI.TITLE_HEIGHT - 1, group.getWidth(), GlossyTaskPaneGroupUI.TITLE_HEIGHT - 1);
/* 133:133 */       g.setClip(oldClip);
/* 134:    */     }
/* 135:    */     
/* 136:    */     protected void paintExpandedControls(JTaskPaneGroup group, Graphics g, int x, int y, int width, int height)
/* 137:    */     {
/* 138:138 */       ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 139:    */       
/* 140:    */ 
/* 141:    */ 
/* 142:142 */       paintOvalAroundControls(group, g, x, y, width, height);
/* 143:143 */       g.setColor(getPaintColor(group));
/* 144:144 */       paintChevronControls(group, g, x, y, width, height);
/* 145:    */       
/* 146:146 */       ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/* 147:    */     }
/* 148:    */     
/* 149:    */ 
/* 150:    */     protected boolean isMouseOverBorder()
/* 151:    */     {
/* 152:152 */       return true;
/* 153:    */     }
/* 154:    */   }
/* 155:    */ }
