/*   1:    */ package com.l2fprod.common.swing.plaf.misc;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JButtonBar;
/*   4:    */ import com.l2fprod.common.swing.plaf.ButtonBarButtonUI;
/*   5:    */ import com.l2fprod.common.swing.plaf.basic.BasicButtonBarUI;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.FontMetrics;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Rectangle;
/*  10:    */ import javax.swing.AbstractButton;
/*  11:    */ import javax.swing.BorderFactory;
/*  12:    */ import javax.swing.ButtonModel;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.border.Border;
/*  15:    */ import javax.swing.border.CompoundBorder;
/*  16:    */ import javax.swing.plaf.BorderUIResource;
/*  17:    */ import javax.swing.plaf.ColorUIResource;
/*  18:    */ import javax.swing.plaf.ComponentUI;
/*  19:    */ import javax.swing.plaf.UIResource;
/*  20:    */ import javax.swing.plaf.basic.BasicButtonUI;
/*  21:    */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public class IconPackagerButtonBarUI
/*  47:    */   extends BasicButtonBarUI
/*  48:    */ {
/*  49:    */   public static ComponentUI createUI(JComponent c)
/*  50:    */   {
/*  51: 51 */     return new IconPackagerButtonBarUI();
/*  52:    */   }
/*  53:    */   
/*  54:    */   protected void installDefaults() {
/*  55: 55 */     Border b = bar.getBorder();
/*  56: 56 */     if ((b == null) || ((b instanceof UIResource))) {
/*  57: 57 */       bar.setBorder(new BorderUIResource(new CompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(2, 2, 2, 2))));
/*  58:    */     }
/*  59:    */     
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64: 64 */     if ((bar.getBackground() == null) || ((bar.getBackground() instanceof UIResource)))
/*  65:    */     {
/*  66: 66 */       bar.setBackground(new ColorUIResource(128, 128, 128));
/*  67: 67 */       bar.setOpaque(true);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void installButtonBarUI(AbstractButton button) {
/*  72: 72 */     button.setUI(new ButtonUI());
/*  73: 73 */     button.setHorizontalTextPosition(0);
/*  74: 74 */     button.setVerticalTextPosition(3);
/*  75:    */   }
/*  76:    */   
/*  77:    */   static class ButtonUI extends BasicButtonUI implements ButtonBarButtonUI {
/*  78: 78 */     private static Color selectedBackground = Color.white;
/*  79: 79 */     private static Color selectedBorder = Color.black;
/*  80:    */     
/*  81: 81 */     private static Color selectedForeground = Color.black;
/*  82: 82 */     private static Color unselectedForeground = Color.white;
/*  83:    */     
/*  84:    */     public void installUI(JComponent c) {
/*  85: 85 */       super.installUI(c);
/*  86:    */       
/*  87: 87 */       AbstractButton button = (AbstractButton)c;
/*  88: 88 */       button.setOpaque(false);
/*  89: 89 */       button.setRolloverEnabled(true);
/*  90: 90 */       button.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
/*  91:    */     }
/*  92:    */     
/*  93:    */     public void paint(Graphics g, JComponent c) {
/*  94: 94 */       AbstractButton button = (AbstractButton)c;
/*  95:    */       
/*  96: 96 */       if (button.getModel().isSelected()) {
/*  97: 97 */         Color oldColor = g.getColor();
/*  98: 98 */         g.setColor(selectedBackground);
/*  99: 99 */         g.fillRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 5, 5);
/* 100:    */         
/* 101:101 */         g.setColor(selectedBorder);
/* 102:102 */         g.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 5, 5);
/* 103:    */         
/* 104:104 */         g.setColor(oldColor);
/* 105:    */       }
/* 106:    */       
/* 107:    */ 
/* 108:    */ 
/* 109:109 */       if (c.getClientProperty("html") != null) {
/* 110:110 */         ButtonModel model = button.getModel();
/* 111:111 */         if (model.isEnabled()) {
/* 112:112 */           if (model.isSelected()) {
/* 113:113 */             button.setForeground(selectedForeground);
/* 114:    */           } else {
/* 115:115 */             button.setForeground(unselectedForeground);
/* 116:    */           }
/* 117:    */         } else {
/* 118:118 */           button.setForeground(unselectedForeground.darker());
/* 119:    */         }
/* 120:    */       }
/* 121:    */       
/* 122:122 */       super.paint(g, c);
/* 123:    */     }
/* 124:    */     
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */     protected void paintText(Graphics g, AbstractButton b, Rectangle textRect, String text)
/* 129:    */     {
/* 130:130 */       ButtonModel model = b.getModel();
/* 131:131 */       FontMetrics fm = g.getFontMetrics();
/* 132:132 */       int mnemonicIndex = b.getDisplayedMnemonicIndex();
/* 133:    */       
/* 134:134 */       Color oldColor = g.getColor();
/* 135:    */       
/* 136:    */ 
/* 137:137 */       if (model.isEnabled())
/* 138:    */       {
/* 139:139 */         if (model.isSelected()) {
/* 140:140 */           g.setColor(selectedForeground);
/* 141:    */         } else {
/* 142:142 */           g.setColor(unselectedForeground);
/* 143:    */         }
/* 144:    */       } else {
/* 145:145 */         g.setColor(unselectedForeground.darker());
/* 146:    */       }
/* 147:    */       
/* 148:    */ 
/* 149:149 */       BasicGraphicsUtils.drawStringUnderlineCharAt(g, text, mnemonicIndex, x + getTextShiftOffset(), y + fm.getAscent() + getTextShiftOffset());
/* 150:    */       
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:172 */       g.setColor(oldColor);
/* 173:    */     }
/* 174:    */   }
/* 175:    */ }
