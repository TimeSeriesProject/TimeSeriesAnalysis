/*  1:   */ package com.l2fprod.common.swing.plaf;
/*  2:   */ 
/*  3:   */ import java.util.Arrays;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class JLinkButtonAddon
/* 28:   */   extends AbstractComponentAddon
/* 29:   */ {
/* 30:   */   public JLinkButtonAddon()
/* 31:   */   {
/* 32:32 */     super("JLinkButton");
/* 33:   */   }
/* 34:   */   
/* 35:   */   protected void addBasicDefaults(LookAndFeelAddons addon, List defaults) {
/* 36:36 */     defaults.addAll(Arrays.asList(new Object[] { "LinkButtonUI", "com.l2fprod.common.swing.plaf.basic.BasicLinkButtonUI" }));
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected void addWindowsDefaults(LookAndFeelAddons addon, List defaults)
/* 40:   */   {
/* 41:41 */     defaults.addAll(Arrays.asList(new Object[] { "LinkButtonUI", "com.l2fprod.common.swing.plaf.windows.WindowsLinkButtonUI" }));
/* 42:   */   }
/* 43:   */ }
