/*  1:   */ package com.l2fprod.common.swing.tips;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.TipModel;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ import java.util.List;
/*  6:   */ import java.util.Properties;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ public class TipLoader
/* 46:   */ {
/* 47:   */   public static TipModel load(Properties props)
/* 48:   */   {
/* 49:49 */     List tips = new ArrayList();
/* 50:   */     
/* 51:51 */     int count = 1;
/* 52:   */     for (;;) {
/* 53:53 */       String nameKey = "tip." + count + ".name";
/* 54:54 */       String nameValue = props.getProperty(nameKey);
/* 55:   */       
/* 56:56 */       String descriptionKey = "tip." + count + ".description";
/* 57:57 */       String descriptionValue = props.getProperty(descriptionKey);
/* 58:   */       
/* 59:59 */       if ((nameValue != null) && (descriptionValue == null)) {
/* 60:60 */         throw new IllegalArgumentException("No description for name " + nameValue);
/* 61:   */       }
/* 62:   */       
/* 63:   */ 
/* 64:64 */       if (descriptionValue == null) {
/* 65:   */         break;
/* 66:   */       }
/* 67:   */       
/* 68:68 */       DefaultTip tip = new DefaultTip(nameValue, descriptionValue);
/* 69:69 */       tips.add(tip);
/* 70:   */       
/* 71:71 */       count++;
/* 72:   */     }
/* 73:   */     
/* 74:74 */     return new DefaultTipModel(tips);
/* 75:   */   }
/* 76:   */ }
