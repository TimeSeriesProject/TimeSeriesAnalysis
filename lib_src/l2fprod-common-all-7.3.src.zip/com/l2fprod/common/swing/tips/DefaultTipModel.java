/*  1:   */ package com.l2fprod.common.swing.tips;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.TipModel;
/*  4:   */ import com.l2fprod.common.swing.TipModel.Tip;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import java.util.Collection;
/*  8:   */ import java.util.List;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public class DefaultTipModel
/* 27:   */   implements TipModel
/* 28:   */ {
/* 29:29 */   private List tips = new ArrayList();
/* 30:   */   
/* 31:   */   public DefaultTipModel() {}
/* 32:   */   
/* 33:   */   public DefaultTipModel(TipModel.Tip[] tips) {
/* 34:34 */     this(Arrays.asList(tips));
/* 35:   */   }
/* 36:   */   
/* 37:   */   public DefaultTipModel(Collection tips) {
/* 38:38 */     this.tips.addAll(tips);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public TipModel.Tip getTipAt(int index) {
/* 42:42 */     return (TipModel.Tip)tips.get(index);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public int getTipCount() {
/* 46:46 */     return tips.size();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void add(TipModel.Tip tip) {
/* 50:50 */     tips.add(tip);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void remove(TipModel.Tip tip) {
/* 54:54 */     tips.remove(tip);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public TipModel.Tip[] getTips() {
/* 58:58 */     return (TipModel.Tip[])tips.toArray(new TipModel.Tip[tips.size()]);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setTips(TipModel.Tip[] tips) {
/* 62:62 */     this.tips.clear();
/* 63:63 */     this.tips.addAll(Arrays.asList(tips));
/* 64:   */   }
/* 65:   */ }
