/*  1:   */ package com.l2fprod.common.swing.tips;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.TipModel.Tip;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ public class DefaultTip
/* 21:   */   implements TipModel.Tip
/* 22:   */ {
/* 23:   */   private String name;
/* 24:   */   private Object tip;
/* 25:   */   
/* 26:   */   public DefaultTip() {}
/* 27:   */   
/* 28:   */   public DefaultTip(String name, Object tip)
/* 29:   */   {
/* 30:30 */     this.name = name;
/* 31:31 */     this.tip = tip;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Object getTip() {
/* 35:35 */     return tip;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setTip(Object tip) {
/* 39:39 */     this.tip = tip;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getTipName() {
/* 43:43 */     return name;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setTipName(String name) {
/* 47:47 */     this.name = name;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public String toString() {
/* 51:51 */     return getTipName();
/* 52:   */   }
/* 53:   */ }
