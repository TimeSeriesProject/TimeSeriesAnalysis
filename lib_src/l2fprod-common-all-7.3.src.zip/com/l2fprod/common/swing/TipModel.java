package com.l2fprod.common.swing;

public abstract interface TipModel
{
  public abstract int getTipCount();
  
  public abstract Tip getTipAt(int paramInt);
  
  public static abstract interface Tip
  {
    public abstract String getTipName();
    
    public abstract Object getTip();
  }
}
