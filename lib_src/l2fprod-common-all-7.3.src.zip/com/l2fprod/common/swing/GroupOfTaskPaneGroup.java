/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeEvent;
/*  4:   */ import java.beans.PropertyChangeListener;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ public class GroupOfTaskPaneGroup
/* 35:   */   implements PropertyChangeListener
/* 36:   */ {
/* 37:   */   private JTaskPaneGroup selection;
/* 38:   */   
/* 39:   */   public void add(JTaskPaneGroup taskpaneGroup)
/* 40:   */   {
/* 41:41 */     register(taskpaneGroup);
/* 42:   */     
/* 43:43 */     if (selection == null)
/* 44:   */     {
/* 45:45 */       if (taskpaneGroup.isExpanded())
/* 46:   */       {
/* 47:47 */         selection = taskpaneGroup;
/* 48:   */       }
/* 49:   */     }
/* 50:   */     else {
/* 51:51 */       taskpaneGroup.setExpanded(false);
/* 52:   */     }
/* 53:   */     
/* 54:54 */     maybeUpdateSelection(taskpaneGroup);
/* 55:   */   }
/* 56:   */   
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */   public void remove(JTaskPaneGroup taskpaneGroup)
/* 62:   */   {
/* 63:63 */     unregister(taskpaneGroup);
/* 64:   */     
/* 65:   */ 
/* 66:66 */     if (selection == taskpaneGroup) {
/* 67:67 */       selection = null;
/* 68:   */     }
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void propertyChange(PropertyChangeEvent event)
/* 72:   */   {
/* 73:73 */     JTaskPaneGroup taskpaneGroup = (JTaskPaneGroup)event.getSource();
/* 74:74 */     maybeUpdateSelection(taskpaneGroup);
/* 75:   */   }
/* 76:   */   
/* 77:   */   private void maybeUpdateSelection(JTaskPaneGroup taskpaneGroup) {
/* 78:78 */     if ((selection != taskpaneGroup) && (taskpaneGroup.isExpanded())) {
/* 79:79 */       if (selection != null) {
/* 80:80 */         selection.setExpanded(false);
/* 81:   */       }
/* 82:82 */       selection = taskpaneGroup;
/* 83:   */     }
/* 84:   */   }
/* 85:   */   
/* 86:   */   private void register(JTaskPaneGroup taskpaneGroup) {
/* 87:87 */     taskpaneGroup.addPropertyChangeListener("expanded", this);
/* 88:   */   }
/* 89:   */   
/* 90:   */   private void unregister(JTaskPaneGroup taskpaneGroup)
/* 91:   */   {
/* 92:92 */     taskpaneGroup.removePropertyChangeListener("expanded", this);
/* 93:   */   }
/* 94:   */ }
