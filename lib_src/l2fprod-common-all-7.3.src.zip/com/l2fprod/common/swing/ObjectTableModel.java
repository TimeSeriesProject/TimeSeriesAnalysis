package com.l2fprod.common.swing;

import javax.swing.table.TableModel;

public abstract interface ObjectTableModel
  extends TableModel
{
  public abstract Object getObject(int paramInt);
}
