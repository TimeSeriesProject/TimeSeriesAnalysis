/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.AlphaComposite;
/*   4:    */ import java.awt.BorderLayout;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Composite;
/*   7:    */ import java.awt.Container;
/*   8:    */ import java.awt.Dimension;
/*   9:    */ import java.awt.Graphics;
/*  10:    */ import java.awt.Graphics2D;
/*  11:    */ import java.awt.GraphicsConfiguration;
/*  12:    */ import java.awt.LayoutManager;
/*  13:    */ import java.awt.Rectangle;
/*  14:    */ import java.awt.event.ActionEvent;
/*  15:    */ import java.awt.event.ActionListener;
/*  16:    */ import java.awt.image.BufferedImage;
/*  17:    */ import java.beans.PropertyChangeEvent;
/*  18:    */ import java.beans.PropertyChangeListener;
/*  19:    */ import javax.swing.AbstractAction;
/*  20:    */ import javax.swing.ActionMap;
/*  21:    */ import javax.swing.JComponent;
/*  22:    */ import javax.swing.JPanel;
/*  23:    */ import javax.swing.SwingUtilities;
/*  24:    */ import javax.swing.Timer;
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ public class JCollapsiblePane
/* 132:    */   extends JPanel
/* 133:    */ {
/* 134:    */   public static final String ANIMATION_STATE_KEY = "animationState";
/* 135:    */   public static final String TOGGLE_ACTION = "toggle";
/* 136:    */   public static final String COLLAPSE_ICON = "collapseIcon";
/* 137:    */   public static final String EXPAND_ICON = "expandIcon";
/* 138:138 */   private boolean collapsed = false;
/* 139:    */   
/* 140:    */ 
/* 141:    */   private Timer animateTimer;
/* 142:    */   
/* 143:    */   private AnimationListener animator;
/* 144:    */   
/* 145:145 */   private int currentHeight = -1;
/* 146:    */   private WrapperContainer wrapper;
/* 147:147 */   private boolean useAnimation = true;
/* 148:    */   
/* 149:    */ 
/* 150:    */   private AnimationParams animationParams;
/* 151:    */   
/* 152:    */ 
/* 153:    */   public JCollapsiblePane()
/* 154:    */   {
/* 155:155 */     super.setLayout(new BorderLayout(0, 0));
/* 156:    */     
/* 157:157 */     JPanel panel = new JPanel();
/* 158:158 */     panel.setLayout(new PercentLayout(1, 2));
/* 159:159 */     setContentPane(panel);
/* 160:    */     
/* 161:161 */     animator = new AnimationListener(null);
/* 162:162 */     setAnimationParams(new AnimationParams(30, 8, 0.01F, 1.0F));
/* 163:    */     
/* 164:    */ 
/* 165:165 */     getActionMap().put("toggle", new ToggleAction());
/* 166:    */   }
/* 167:    */   
/* 168:    */ 
/* 169:    */   private class ToggleAction
/* 170:    */     extends AbstractAction
/* 171:    */     implements PropertyChangeListener
/* 172:    */   {
/* 173:    */     public ToggleAction()
/* 174:    */     {
/* 175:175 */       super();
/* 176:176 */       updateIcon();
/* 177:    */       
/* 178:    */ 
/* 179:179 */       addPropertyChangeListener("collapsed", this);
/* 180:    */     }
/* 181:    */     
/* 182:182 */     public void putValue(String key, Object newValue) { super.putValue(key, newValue);
/* 183:183 */       if (("expandIcon".equals(key)) || ("collapseIcon".equals(key)))
/* 184:184 */         updateIcon();
/* 185:    */     }
/* 186:    */     
/* 187:    */     public void actionPerformed(ActionEvent e) {
/* 188:188 */       setCollapsed(!isCollapsed());
/* 189:    */     }
/* 190:    */     
/* 191:191 */     public void propertyChange(PropertyChangeEvent evt) { updateIcon(); }
/* 192:    */     
/* 193:    */     void updateIcon() {
/* 194:194 */       if (isCollapsed()) {
/* 195:195 */         putValue("SmallIcon", getValue("expandIcon"));
/* 196:    */       } else {
/* 197:197 */         putValue("SmallIcon", getValue("collapseIcon"));
/* 198:    */       }
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */   public void setContentPane(Container contentPanel)
/* 210:    */   {
/* 211:211 */     if (contentPanel == null) {
/* 212:212 */       throw new IllegalArgumentException("Content pane can't be null");
/* 213:    */     }
/* 214:    */     
/* 215:215 */     if (wrapper != null) {
/* 216:216 */       super.remove(wrapper);
/* 217:    */     }
/* 218:218 */     wrapper = new WrapperContainer(contentPanel);
/* 219:219 */     super.addImpl(wrapper, "Center", -1);
/* 220:    */   }
/* 221:    */   
/* 222:    */ 
/* 223:    */ 
/* 224:    */   public Container getContentPane()
/* 225:    */   {
/* 226:226 */     return wrapper.c;
/* 227:    */   }
/* 228:    */   
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */   public void setLayout(LayoutManager mgr)
/* 233:    */   {
/* 234:234 */     if (wrapper != null) {
/* 235:235 */       getContentPane().setLayout(mgr);
/* 236:    */     }
/* 237:    */   }
/* 238:    */   
/* 239:    */ 
/* 240:    */ 
/* 241:    */   protected void addImpl(Component comp, Object constraints, int index)
/* 242:    */   {
/* 243:243 */     getContentPane().add(comp, constraints, index);
/* 244:    */   }
/* 245:    */   
/* 246:    */ 
/* 247:    */ 
/* 248:    */   public void remove(Component comp)
/* 249:    */   {
/* 250:250 */     getContentPane().remove(comp);
/* 251:    */   }
/* 252:    */   
/* 253:    */ 
/* 254:    */ 
/* 255:    */   public void remove(int index)
/* 256:    */   {
/* 257:257 */     getContentPane().remove(index);
/* 258:    */   }
/* 259:    */   
/* 260:    */ 
/* 261:    */ 
/* 262:    */   public void removeAll()
/* 263:    */   {
/* 264:264 */     getContentPane().removeAll();
/* 265:    */   }
/* 266:    */   
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */ 
/* 272:    */ 
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */   public void setAnimated(boolean animated)
/* 285:    */   {
/* 286:286 */     if (animated != useAnimation) {
/* 287:287 */       useAnimation = animated;
/* 288:288 */       firePropertyChange("animated", !useAnimation, useAnimation);
/* 289:    */     }
/* 290:    */   }
/* 291:    */   
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */   public boolean isAnimated()
/* 296:    */   {
/* 297:297 */     return useAnimation;
/* 298:    */   }
/* 299:    */   
/* 300:    */ 
/* 301:    */ 
/* 302:    */   public boolean isCollapsed()
/* 303:    */   {
/* 304:304 */     return collapsed;
/* 305:    */   }
/* 306:    */   
/* 307:    */ 
/* 308:    */ 
/* 309:    */ 
/* 310:    */ 
/* 311:    */ 
/* 312:    */ 
/* 313:    */ 
/* 314:    */ 
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */ 
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:    */ 
/* 327:    */   public void setCollapsed(boolean val)
/* 328:    */   {
/* 329:329 */     if (collapsed != val) {
/* 330:330 */       collapsed = val;
/* 331:331 */       if (isAnimated()) {
/* 332:332 */         if (collapsed) {
/* 333:333 */           setAnimationParams(new AnimationParams(30, Math.max(8, wrapper.getHeight() / 10), 1.0F, 0.01F));
/* 334:    */           
/* 335:335 */           animator.reinit(wrapper.getHeight(), 0);
/* 336:336 */           animateTimer.start();
/* 337:    */         } else {
/* 338:338 */           setAnimationParams(new AnimationParams(30, Math.max(8, getContentPane()getPreferredSize()height / 10), 0.01F, 1.0F));
/* 339:    */           
/* 340:340 */           animator.reinit(wrapper.getHeight(), getContentPane()getPreferredSize()height);
/* 341:    */           
/* 342:342 */           animateTimer.start();
/* 343:    */         }
/* 344:    */       } else {
/* 345:345 */         wrapper.c.setVisible(!collapsed);
/* 346:346 */         invalidate();
/* 347:347 */         doLayout();
/* 348:    */       }
/* 349:349 */       repaint();
/* 350:350 */       firePropertyChange("collapsed", !collapsed, collapsed);
/* 351:    */     }
/* 352:    */   }
/* 353:    */   
/* 354:    */   public Dimension getMinimumSize() {
/* 355:355 */     return getPreferredSize();
/* 356:    */   }
/* 357:    */   
/* 358:    */ 
/* 359:    */ 
/* 360:    */ 
/* 361:    */ 
/* 362:    */ 
/* 363:    */   public Dimension getPreferredSize()
/* 364:    */   {
/* 365:    */     Dimension dim;
/* 366:    */     
/* 367:    */ 
/* 368:    */ 
/* 369:    */ 
/* 370:    */ 
/* 371:    */     Dimension dim;
/* 372:    */     
/* 373:    */ 
/* 374:    */ 
/* 375:    */ 
/* 376:    */ 
/* 377:377 */     if (!isAnimated()) { Dimension dim;
/* 378:378 */       if (getContentPane().isVisible()) {
/* 379:379 */         dim = getContentPane().getPreferredSize();
/* 380:    */       } else {
/* 381:381 */         dim = super.getPreferredSize();
/* 382:    */       }
/* 383:    */     } else {
/* 384:384 */       dim = new Dimension(getContentPane().getPreferredSize());
/* 385:385 */       if ((!getContentPane().isVisible()) && (currentHeight != -1)) {
/* 386:386 */         height = currentHeight;
/* 387:    */       }
/* 388:    */     }
/* 389:389 */     return dim;
/* 390:    */   }
/* 391:    */   
/* 392:    */ 
/* 393:    */ 
/* 394:    */ 
/* 395:    */ 
/* 396:    */ 
/* 397:    */ 
/* 398:    */   private void setAnimationParams(AnimationParams params)
/* 399:    */   {
/* 400:400 */     if (params == null) { throw new IllegalArgumentException("params can't be null");
/* 401:    */     }
/* 402:402 */     if (animateTimer != null) {
/* 403:403 */       animateTimer.stop();
/* 404:    */     }
/* 405:405 */     animationParams = params;
/* 406:406 */     animateTimer = new Timer(animationParams.waitTime, animator);
/* 407:407 */     animateTimer.setInitialDelay(0);
/* 408:    */   }
/* 409:    */   
/* 410:    */ 
/* 411:    */ 
/* 412:    */ 
/* 413:    */ 
/* 414:    */   public static abstract interface JCollapsiblePaneContainer
/* 415:    */   {
/* 416:    */     public abstract Container getValidatingContainer();
/* 417:    */   }
/* 418:    */   
/* 419:    */ 
/* 420:    */ 
/* 421:    */ 
/* 422:    */ 
/* 423:    */   private static class AnimationParams
/* 424:    */   {
/* 425:    */     final int waitTime;
/* 426:    */     
/* 427:    */ 
/* 428:    */ 
/* 429:    */     final int deltaY;
/* 430:    */     
/* 431:    */ 
/* 432:    */ 
/* 433:    */     final float alphaStart;
/* 434:    */     
/* 435:    */ 
/* 436:    */ 
/* 437:    */     final float alphaEnd;
/* 438:    */     
/* 439:    */ 
/* 440:    */ 
/* 441:    */ 
/* 442:    */     public AnimationParams(int waitTime, int deltaY, float alphaStart, float alphaEnd)
/* 443:    */     {
/* 444:444 */       this.waitTime = waitTime;
/* 445:445 */       this.deltaY = deltaY;
/* 446:446 */       this.alphaStart = alphaStart;
/* 447:447 */       this.alphaEnd = alphaEnd;
/* 448:    */     }
/* 449:    */   }
/* 450:    */   
/* 451:    */ 
/* 452:    */ 
/* 453:    */ 
/* 454:    */ 
/* 455:    */   private final class AnimationListener
/* 456:    */     implements ActionListener
/* 457:    */   {
/* 458:    */     AnimationListener(JCollapsiblePane.1 x1)
/* 459:    */     {
/* 460:460 */       this();
/* 461:    */     }
/* 462:    */     
/* 463:    */ 
/* 464:    */ 
/* 465:465 */     private final Object ANIMATION_MUTEX = "Animation Synchronization Mutex";
/* 466:    */     
/* 467:    */ 
/* 468:    */ 
/* 469:    */ 
/* 470:    */ 
/* 471:471 */     private int startHeight = 0;
/* 472:    */     
/* 473:    */ 
/* 474:    */ 
/* 475:    */ 
/* 476:476 */     private int finalHeight = 0;
/* 477:    */     
/* 478:    */ 
/* 479:    */ 
/* 480:480 */     private float animateAlpha = 1.0F;
/* 481:    */     
/* 482:    */ 
/* 483:    */ 
/* 484:    */ 
/* 485:    */ 
/* 486:    */ 
/* 487:    */ 
/* 488:    */     public void actionPerformed(ActionEvent e)
/* 489:    */     {
/* 490:490 */       synchronized (ANIMATION_MUTEX) {
/* 491:491 */         if (startHeight == finalHeight) {
/* 492:492 */           animateTimer.stop();
/* 493:493 */           animateAlpha = animationParams.alphaEnd;
/* 494:    */           
/* 495:    */ 
/* 496:496 */           if (finalHeight > 0) {
/* 497:497 */             wrapper.showContent();
/* 498:498 */             validate();
/* 499:499 */             firePropertyChange("animationState", null, "expanded");
/* 500:    */             
/* 501:501 */             return;
/* 502:    */           }
/* 503:    */         }
/* 504:    */         
/* 505:505 */         boolean contracting = startHeight > finalHeight;
/* 506:506 */         int delta_y = contracting ? -1 * animationParams.deltaY : animationParams.deltaY;
/* 507:    */         
/* 508:508 */         int newHeight = wrapper.getHeight() + delta_y;
/* 509:509 */         if (contracting) {
/* 510:510 */           if (newHeight < finalHeight) {
/* 511:511 */             newHeight = finalHeight;
/* 512:    */           }
/* 513:    */         }
/* 514:514 */         else if (newHeight > finalHeight) {
/* 515:515 */           newHeight = finalHeight;
/* 516:    */         }
/* 517:    */         
/* 518:518 */         animateAlpha = (newHeight / access$400c.getPreferredSize().height);
/* 519:    */         
/* 520:    */ 
/* 521:521 */         Rectangle bounds = wrapper.getBounds();
/* 522:522 */         int oldHeight = height;
/* 523:523 */         height = newHeight;
/* 524:524 */         wrapper.setBounds(bounds);
/* 525:525 */         bounds = getBounds();
/* 526:526 */         height = (height - oldHeight + newHeight);
/* 527:527 */         currentHeight = height;
/* 528:528 */         setBounds(bounds);
/* 529:529 */         startHeight = newHeight;
/* 530:    */         
/* 531:    */ 
/* 532:    */ 
/* 533:    */ 
/* 534:534 */         if (contracting)
/* 535:    */         {
/* 536:536 */           if (animateAlpha < animationParams.alphaEnd) {
/* 537:537 */             animateAlpha = animationParams.alphaEnd;
/* 538:    */           }
/* 539:539 */           if (animateAlpha > animationParams.alphaStart) {
/* 540:540 */             animateAlpha = animationParams.alphaStart;
/* 541:    */           }
/* 542:    */         }
/* 543:    */         else {
/* 544:544 */           if (animateAlpha > animationParams.alphaEnd) {
/* 545:545 */             animateAlpha = animationParams.alphaEnd;
/* 546:    */           }
/* 547:547 */           if (animateAlpha < animationParams.alphaStart) {
/* 548:548 */             animateAlpha = animationParams.alphaStart;
/* 549:    */           }
/* 550:    */         }
/* 551:551 */         wrapper.alpha = animateAlpha;
/* 552:    */         
/* 553:553 */         validate();
/* 554:    */       }
/* 555:    */     }
/* 556:    */     
/* 557:    */     void validate() {
/* 558:558 */       Container parent = SwingUtilities.getAncestorOfClass(JCollapsiblePane.JCollapsiblePaneContainer.class, JCollapsiblePane.this);
/* 559:    */       
/* 560:560 */       if (parent != null) {
/* 561:561 */         parent = ((JCollapsiblePane.JCollapsiblePaneContainer)parent).getValidatingContainer();
/* 562:    */       } else {
/* 563:563 */         parent = getParent();
/* 564:    */       }
/* 565:    */       
/* 566:566 */       if (parent != null) {
/* 567:567 */         if ((parent instanceof JComponent)) {
/* 568:568 */           ((JComponent)parent).revalidate();
/* 569:    */         } else {
/* 570:570 */           parent.invalidate();
/* 571:    */         }
/* 572:572 */         parent.doLayout();
/* 573:573 */         parent.repaint();
/* 574:    */       }
/* 575:    */     }
/* 576:    */     
/* 577:    */ 
/* 578:    */ 
/* 579:    */ 
/* 580:    */ 
/* 581:    */ 
/* 582:    */ 
/* 583:    */ 
/* 584:    */     public void reinit(int startHeight, int stopHeight)
/* 585:    */     {
/* 586:586 */       synchronized (ANIMATION_MUTEX) {
/* 587:587 */         firePropertyChange("animationState", null, "reinit");
/* 588:    */         
/* 589:589 */         this.startHeight = startHeight;
/* 590:590 */         finalHeight = stopHeight;
/* 591:591 */         animateAlpha = animationParams.alphaStart;
/* 592:592 */         currentHeight = -1;
/* 593:593 */         wrapper.showImage();
/* 594:    */       }
/* 595:    */     }
/* 596:    */     
/* 597:    */     private AnimationListener() {} }
/* 598:    */   
/* 599:    */   private final class WrapperContainer extends JPanel { private BufferedImage img;
/* 600:    */     private Container c;
/* 601:601 */     float alpha = 1.0F;
/* 602:    */     
/* 603:    */     public WrapperContainer(Container c) {
/* 604:604 */       super();
/* 605:605 */       this.c = c;
/* 606:606 */       add(c, "Center");
/* 607:    */       
/* 608:    */ 
/* 609:    */ 
/* 610:    */ 
/* 611:611 */       if (((c instanceof JComponent)) && (!((JComponent)c).isOpaque())) {
/* 612:612 */         ((JComponent)c).setOpaque(true);
/* 613:    */       }
/* 614:    */     }
/* 615:    */     
/* 616:    */     public void showImage()
/* 617:    */     {
/* 618:618 */       makeImage();
/* 619:619 */       c.setVisible(false);
/* 620:    */     }
/* 621:    */     
/* 622:    */     public void showContent() {
/* 623:623 */       currentHeight = -1;
/* 624:624 */       c.setVisible(true);
/* 625:    */     }
/* 626:    */     
/* 627:    */     void makeImage()
/* 628:    */     {
/* 629:629 */       if ((getGraphicsConfiguration() != null) && (getWidth() > 0)) {
/* 630:630 */         Dimension dim = c.getPreferredSize();
/* 631:    */         
/* 632:632 */         if (height > 0) {
/* 633:633 */           img = getGraphicsConfiguration().createCompatibleImage(getWidth(), height);
/* 634:    */           
/* 635:635 */           c.setSize(getWidth(), height);
/* 636:636 */           c.paint(img.getGraphics());
/* 637:    */         } else {
/* 638:638 */           img = null;
/* 639:    */         }
/* 640:    */       }
/* 641:    */     }
/* 642:    */     
/* 643:    */     public void paintComponent(Graphics g) {
/* 644:644 */       if ((!useAnimation) || (c.isVisible())) {
/* 645:645 */         super.paintComponent(g);
/* 646:    */       }
/* 647:    */       else
/* 648:    */       {
/* 649:649 */         if (img == null) {
/* 650:650 */           makeImage();
/* 651:    */         }
/* 652:    */         
/* 653:    */ 
/* 654:654 */         if ((g != null) && (img != null))
/* 655:    */         {
/* 656:656 */           g.drawImage(img, 0, getHeight() - img.getHeight(), null);
/* 657:    */         }
/* 658:    */       }
/* 659:    */     }
/* 660:    */     
/* 661:    */     public void paint(Graphics g) {
/* 662:662 */       Graphics2D g2d = (Graphics2D)g;
/* 663:663 */       Composite oldComp = g2d.getComposite();
/* 664:664 */       Composite alphaComp = AlphaComposite.getInstance(3, alpha);
/* 665:    */       
/* 666:666 */       g2d.setComposite(alphaComp);
/* 667:667 */       super.paint(g2d);
/* 668:668 */       g2d.setComposite(oldComp);
/* 669:    */     }
/* 670:    */   }
/* 671:    */ }
