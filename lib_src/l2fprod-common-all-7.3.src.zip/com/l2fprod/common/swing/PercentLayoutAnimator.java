/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.event.ActionEvent;
/*   6:    */ import java.awt.event.ActionListener;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ import javax.swing.Timer;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public class PercentLayoutAnimator
/*  33:    */   implements ActionListener
/*  34:    */ {
/*  35:    */   private Timer animatorTimer;
/*  36: 36 */   private List tasks = new ArrayList();
/*  37:    */   private PercentLayout layout;
/*  38:    */   private Container container;
/*  39:    */   
/*  40:    */   public PercentLayoutAnimator(Container container, PercentLayout layout) {
/*  41: 41 */     this.container = container;
/*  42: 42 */     this.layout = layout;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setTargetPercent(Component component, float percent) {
/*  46: 46 */     PercentLayout.Constraint oldConstraint = layout.getConstraint(component);
/*  47: 47 */     if ((oldConstraint instanceof PercentLayout.PercentConstraint)) {
/*  48: 48 */       setTargetPercent(component, ((PercentLayout.PercentConstraint)oldConstraint).floatValue(), percent);
/*  49:    */     }
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setTargetPercent(Component component, float startPercent, float endPercent)
/*  53:    */   {
/*  54: 54 */     tasks.add(new PercentTask(component, startPercent, endPercent));
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void start() {
/*  58: 58 */     animatorTimer = new Timer(15, this);
/*  59: 59 */     animatorTimer.start();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void stop() {
/*  63: 63 */     animatorTimer.stop();
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected void complete() {
/*  67: 67 */     animatorTimer.stop();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void actionPerformed(ActionEvent e) {
/*  71: 71 */     boolean allCompleted = true;
/*  72:    */     
/*  73: 73 */     for (Iterator iter = tasks.iterator(); iter.hasNext();) {
/*  74: 74 */       PercentTask element = (PercentTask)iter.next();
/*  75: 75 */       if (!element.isCompleted()) {
/*  76: 76 */         allCompleted = false;
/*  77: 77 */         element.execute();
/*  78:    */       }
/*  79:    */     }
/*  80:    */     
/*  81: 81 */     container.invalidate();
/*  82: 82 */     container.doLayout();
/*  83: 83 */     container.repaint();
/*  84:    */     
/*  85: 85 */     if (allCompleted) {
/*  86: 86 */       complete();
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */ 
/*  91:    */   class PercentTask
/*  92:    */   {
/*  93:    */     Component component;
/*  94:    */     
/*  95:    */     float targetPercent;
/*  96:    */     float currentPercent;
/*  97:    */     boolean completed;
/*  98:    */     boolean incrementing;
/*  99:    */     float delta;
/* 100:    */     
/* 101:    */     public PercentTask(Component component, float currentPercent, float targetPercent)
/* 102:    */     {
/* 103:103 */       this.component = component;
/* 104:104 */       this.currentPercent = currentPercent;
/* 105:105 */       this.targetPercent = targetPercent;
/* 106:    */       
/* 107:107 */       float diff = targetPercent - currentPercent;
/* 108:108 */       incrementing = (diff > 0.0F);
/* 109:109 */       delta = (diff / 10.0F);
/* 110:    */     }
/* 111:    */     
/* 112:    */     public void execute() {
/* 113:113 */       currentPercent += delta;
/* 114:114 */       if (incrementing) {
/* 115:115 */         if (currentPercent > targetPercent) {
/* 116:116 */           currentPercent = targetPercent;
/* 117:117 */           completed = true;
/* 118:    */         }
/* 119:    */       }
/* 120:120 */       else if (currentPercent < targetPercent) {
/* 121:121 */         currentPercent = targetPercent;
/* 122:122 */         completed = true;
/* 123:    */       }
/* 124:    */       
/* 125:    */ 
/* 126:126 */       layout.setConstraint(component, new PercentLayout.PercentConstraint(currentPercent));
/* 127:    */     }
/* 128:    */     
/* 129:    */     public boolean isCompleted()
/* 130:    */     {
/* 131:131 */       return completed;
/* 132:    */     }
/* 133:    */   }
/* 134:    */ }
