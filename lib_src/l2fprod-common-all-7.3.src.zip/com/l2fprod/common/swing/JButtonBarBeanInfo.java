/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Image;
/*   5:    */ import java.beans.BeanDescriptor;
/*   6:    */ import java.beans.BeanInfo;
/*   7:    */ import java.beans.IntrospectionException;
/*   8:    */ import java.beans.Introspector;
/*   9:    */ import java.beans.MethodDescriptor;
/*  10:    */ import java.beans.PropertyDescriptor;
/*  11:    */ import java.beans.SimpleBeanInfo;
/*  12:    */ import java.util.Vector;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ public class JButtonBarBeanInfo
/*  18:    */   extends SimpleBeanInfo
/*  19:    */ {
/*  20: 20 */   protected BeanDescriptor bd = new BeanDescriptor(JButtonBar.class);
/*  21:    */   
/*  22:    */ 
/*  23: 23 */   protected Image iconMono16 = loadImage("JButtonBar16-mono.gif");
/*  24:    */   
/*  25: 25 */   protected Image iconColor16 = loadImage("JButtonBar16.gif");
/*  26:    */   
/*  27: 27 */   protected Image iconMono32 = loadImage("JButtonBar32-mono.gif");
/*  28:    */   
/*  29: 29 */   protected Image iconColor32 = loadImage("JButtonBar32.gif");
/*  30:    */   
/*  31:    */   public JButtonBarBeanInfo()
/*  32:    */     throws IntrospectionException
/*  33:    */   {
/*  34: 34 */     bd.setName("JButtonBar");
/*  35:    */     
/*  36: 36 */     bd.setShortDescription("JButtonBar helps organizing buttons together (as seen in Mozilla Firefox or IntelliJ).");
/*  37:    */     
/*  38:    */ 
/*  39: 39 */     BeanInfo info = Introspector.getBeanInfo(getBeanDescriptor().getBeanClass().getSuperclass());
/*  40:    */     
/*  41: 41 */     String order = info.getBeanDescriptor().getValue("propertyorder") == null ? "" : (String)info.getBeanDescriptor().getValue("propertyorder");
/*  42:    */     
/*  43: 43 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  44: 44 */     for (int i = 0; i != pd.length; i++) {
/*  45: 45 */       if (order.indexOf(pd[i].getName()) == -1) {
/*  46: 46 */         order = order + (order.length() == 0 ? "" : ":") + pd[i].getName();
/*  47:    */       }
/*  48:    */     }
/*  49: 49 */     getBeanDescriptor().setValue("propertyorder", order);
/*  50:    */   }
/*  51:    */   
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */   public BeanInfo[] getAdditionalBeanInfo()
/*  57:    */   {
/*  58: 58 */     Vector bi = new Vector();
/*  59: 59 */     BeanInfo[] biarr = null;
/*  60:    */     try {
/*  61: 61 */       for (Class cl = JButtonBar.class.getSuperclass(); !cl.equals(Component.class.getSuperclass()); 
/*  62: 62 */           cl = cl.getSuperclass())
/*  63:    */       {
/*  64: 64 */         bi.addElement(Introspector.getBeanInfo(cl));
/*  65:    */       }
/*  66: 66 */       biarr = new BeanInfo[bi.size()];
/*  67: 67 */       bi.copyInto(biarr);
/*  68:    */     }
/*  69:    */     catch (Exception e) {}
/*  70:    */     
/*  71: 71 */     return biarr;
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */   public BeanDescriptor getBeanDescriptor()
/*  79:    */   {
/*  80: 80 */     return bd;
/*  81:    */   }
/*  82:    */   
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */   public int getDefaultPropertyIndex()
/*  88:    */   {
/*  89: 89 */     String defName = "";
/*  90: 90 */     if (defName.equals("")) return -1;
/*  91: 91 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  92: 92 */     for (int i = 0; i < pd.length; i++) {
/*  93: 93 */       if (pd[i].getName().equals(defName)) return i;
/*  94:    */     }
/*  95: 95 */     return -1;
/*  96:    */   }
/*  97:    */   
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */   public Image getIcon(int type)
/* 105:    */   {
/* 106:106 */     if (type == 1) return iconColor16;
/* 107:107 */     if (type == 3) return iconMono16;
/* 108:108 */     if (type == 2) return iconColor32;
/* 109:109 */     if (type == 4) return iconMono32;
/* 110:110 */     return null;
/* 111:    */   }
/* 112:    */   
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */   public PropertyDescriptor[] getPropertyDescriptors()
/* 118:    */   {
/* 119:119 */     return new PropertyDescriptor[0];
/* 120:    */   }
/* 121:    */   
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */   public MethodDescriptor[] getMethodDescriptors()
/* 127:    */   {
/* 128:128 */     return new MethodDescriptor[0];
/* 129:    */   }
/* 130:    */ }
