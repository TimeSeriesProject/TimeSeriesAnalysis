/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.ButtonBarButtonUI;
/*   4:    */ import com.l2fprod.common.swing.plaf.ButtonBarUI;
/*   5:    */ import com.l2fprod.common.swing.plaf.JButtonBarAddon;
/*   6:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.event.ContainerAdapter;
/*   9:    */ import java.awt.event.ContainerEvent;
/*  10:    */ import java.awt.event.ContainerListener;
/*  11:    */ import java.beans.PropertyChangeEvent;
/*  12:    */ import java.beans.PropertyChangeListener;
/*  13:    */ import javax.swing.AbstractButton;
/*  14:    */ import javax.swing.JComponent;
/*  15:    */ import javax.swing.SwingConstants;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ public class JButtonBar
/*  48:    */   extends JComponent
/*  49:    */   implements SwingConstants
/*  50:    */ {
/*  51:    */   public static final String UI_CLASS_ID = "ButtonBarUI";
/*  52:    */   public static final String ORIENTATION_CHANGED_KEY = "orientation";
/*  53:    */   private int orientation;
/*  54:    */   
/*  55:    */   static
/*  56:    */   {
/*  57: 57 */     LookAndFeelAddons.contribute(new JButtonBarAddon());
/*  58:    */   }
/*  59:    */   
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */   public JButtonBar()
/*  64:    */   {
/*  65: 65 */     this(0);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public JButtonBar(int orientation) {
/*  69: 69 */     this.orientation = orientation;
/*  70: 70 */     updateUI();
/*  71: 71 */     addContainerListener(buttonTracker);
/*  72:    */   }
/*  73:    */   
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */   public void updateUI()
/*  80:    */   {
/*  81: 81 */     setUI((ButtonBarUI)LookAndFeelAddons.getUI(this, ButtonBarUI.class));
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */   public ButtonBarUI getUI()
/*  90:    */   {
/*  91: 91 */     return (ButtonBarUI)ui;
/*  92:    */   }
/*  93:    */   
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */   public void setUI(ButtonBarUI ui)
/* 103:    */   {
/* 104:104 */     super.setUI(ui);
/* 105:105 */     Component[] components = getComponents();
/* 106:    */     
/* 107:107 */     int i = 0; for (int c = components.length; i < c; i++) {
/* 108:108 */       if ((components[i] instanceof AbstractButton)) {
/* 109:109 */         ui.installButtonBarUI((AbstractButton)components[i]);
/* 110:    */       }
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */   public String getUIClassID()
/* 121:    */   {
/* 122:122 */     return "ButtonBarUI";
/* 123:    */   }
/* 124:    */   
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */   public void setOrientation(int orientation)
/* 137:    */   {
/* 138:138 */     if ((orientation != 0) && (orientation != 1)) {
/* 139:139 */       throw new IllegalArgumentException("orientation must be one of: VERTICAL, HORIZONTAL");
/* 140:    */     }
/* 141:    */     
/* 142:    */ 
/* 143:143 */     if (this.orientation != orientation) {
/* 144:144 */       int oldOrientation = this.orientation;
/* 145:145 */       this.orientation = orientation;
/* 146:146 */       firePropertyChange("orientation", oldOrientation, this.orientation);
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */ 
/* 151:    */ 
/* 152:    */   public int getOrientation()
/* 153:    */   {
/* 154:154 */     return orientation;
/* 155:    */   }
/* 156:    */   
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:162 */   private static PropertyChangeListener uiUpdater = new PropertyChangeListener()
/* 163:    */   {
/* 164:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 165:165 */       if ((evt.getSource() instanceof AbstractButton)) {
/* 166:166 */         AbstractButton button = (AbstractButton)evt.getSource();
/* 167:167 */         if (((button.getParent() instanceof JButtonBar)) && (!(button.getUI() instanceof ButtonBarButtonUI)))
/* 168:    */         {
/* 169:169 */           ((ButtonBarUI)getParent()ui).installButtonBarUI(button);
/* 170:    */         }
/* 171:    */       }
/* 172:    */     }
/* 173:    */   };
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:183 */   private static ContainerListener buttonTracker = new ContainerAdapter() {
/* 184:    */     public void componentAdded(ContainerEvent e) {
/* 185:185 */       JButtonBar container = (JButtonBar)e.getContainer();
/* 186:186 */       if ((e.getChild() instanceof AbstractButton)) {
/* 187:187 */         ((ButtonBarUI)ui).installButtonBarUI((AbstractButton)e.getChild());
/* 188:    */         
/* 189:189 */         ((AbstractButton)e.getChild()).addPropertyChangeListener("UI", JButtonBar.uiUpdater);
/* 190:    */       }
/* 191:    */     }
/* 192:    */     
/* 193:    */     public void componentRemoved(ContainerEvent e)
/* 194:    */     {
/* 195:195 */       if ((e.getChild() instanceof AbstractButton)) {
/* 196:196 */         ((AbstractButton)e.getChild()).removePropertyChangeListener("UI", JButtonBar.uiUpdater);
/* 197:    */       }
/* 198:    */     }
/* 199:    */   };
/* 200:    */ }
