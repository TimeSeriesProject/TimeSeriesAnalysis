/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.editor.FixedButton;
/*  4:   */ import javax.swing.JButton;
/*  5:   */ import javax.swing.JComboBox;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public abstract interface ComponentFactory
/* 26:   */ {
/* 27:   */   public abstract JButton createMiniButton();
/* 28:   */   
/* 29:   */   public abstract JComboBox createComboBox();
/* 30:   */   
/* 31:   */   public static class Helper
/* 32:   */   {
/* 33:33 */     static ComponentFactory factory = new ComponentFactory.DefaultComponentFactory();
/* 34:   */     
/* 35:   */     public static ComponentFactory getFactory() {
/* 36:36 */       return factory;
/* 37:   */     }
/* 38:   */     
/* 39:   */     public static void setFactory(ComponentFactory factory) {
/* 40:40 */       factory = factory;
/* 41:   */     }
/* 42:   */   }
/* 43:   */   
/* 44:   */   public static class DefaultComponentFactory implements ComponentFactory {
/* 45:   */     public JButton createMiniButton() {
/* 46:46 */       return new FixedButton();
/* 47:   */     }
/* 48:   */     
/* 49:49 */     public JComboBox createComboBox() { return new JComboBox(); }
/* 50:   */   }
/* 51:   */ }
