/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.awt.LayoutManager2;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Hashtable;
/*  10:    */ import java.util.Iterator;
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ public class PercentLayout
/*  51:    */   implements LayoutManager2
/*  52:    */ {
/*  53:    */   public static final int HORIZONTAL = 0;
/*  54:    */   public static final int VERTICAL = 1;
/*  55:    */   
/*  56:    */   static class Constraint
/*  57:    */   {
/*  58:    */     protected Object value;
/*  59:    */     
/*  60:    */     Constraint(Object x0, PercentLayout.1 x1)
/*  61:    */     {
/*  62: 62 */       this(x0);
/*  63:    */     }
/*  64:    */     
/*  65: 65 */     private Constraint(Object value) { this.value = value; }
/*  66:    */   }
/*  67:    */   
/*  68:    */   static class NumberConstraint extends PercentLayout.Constraint
/*  69:    */   {
/*  70:    */     public NumberConstraint(int d) {
/*  71: 71 */       this(new Integer(d));
/*  72:    */     }
/*  73:    */     
/*  74: 74 */     public NumberConstraint(Integer d) { super(null); }
/*  75:    */     
/*  76:    */     public int intValue() {
/*  77: 77 */       return ((Integer)value).intValue();
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   static class PercentConstraint extends PercentLayout.Constraint {
/*  82:    */     public PercentConstraint(float d) {
/*  83: 83 */       super(null);
/*  84:    */     }
/*  85:    */     
/*  86: 86 */     public float floatValue() { return ((Float)value).floatValue(); }
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90: 90 */   private static final Constraint REMAINING_SPACE = new Constraint("*", null);
/*  91:    */   
/*  92: 92 */   private static final Constraint PREFERRED_SIZE = new Constraint("", null);
/*  93:    */   
/*  94:    */   private int orientation;
/*  95:    */   
/*  96:    */   private int gap;
/*  97:    */   
/*  98:    */   private Hashtable m_ComponentToConstraint;
/*  99:    */   
/* 100:    */ 
/* 101:    */   public PercentLayout()
/* 102:    */   {
/* 103:103 */     this(0, 0);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public PercentLayout(int orientation, int gap) {
/* 107:107 */     setOrientation(orientation);
/* 108:108 */     this.gap = gap;
/* 109:    */     
/* 110:110 */     m_ComponentToConstraint = new Hashtable();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setGap(int gap) {
/* 114:114 */     this.gap = gap;
/* 115:    */   }
/* 116:    */   
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */   public int getGap()
/* 122:    */   {
/* 123:123 */     return gap;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setOrientation(int orientation) {
/* 127:127 */     if ((orientation != 0) && (orientation != 1)) {
/* 128:128 */       throw new IllegalArgumentException("Orientation must be one of HORIZONTAL or VERTICAL");
/* 129:    */     }
/* 130:130 */     this.orientation = orientation;
/* 131:    */   }
/* 132:    */   
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */   public int getOrientation()
/* 138:    */   {
/* 139:139 */     return orientation;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public Constraint getConstraint(Component component) {
/* 143:143 */     return (Constraint)m_ComponentToConstraint.get(component);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void setConstraint(Component component, Object constraints) {
/* 147:147 */     if ((constraints instanceof Constraint)) {
/* 148:148 */       m_ComponentToConstraint.put(component, constraints);
/* 149:149 */     } else if ((constraints instanceof Number)) {
/* 150:150 */       setConstraint(component, new NumberConstraint(((Number)constraints).intValue()));
/* 151:    */ 
/* 152:    */     }
/* 153:153 */     else if ("*".equals(constraints)) {
/* 154:154 */       setConstraint(component, REMAINING_SPACE);
/* 155:155 */     } else if ("".equals(constraints)) {
/* 156:156 */       setConstraint(component, PREFERRED_SIZE);
/* 157:157 */     } else if ((constraints instanceof String)) {
/* 158:158 */       String s = (String)constraints;
/* 159:159 */       if (s.endsWith("%")) {
/* 160:160 */         float value = Float.valueOf(s.substring(0, s.length() - 1)).floatValue() / 100.0F;
/* 161:    */         
/* 162:162 */         if ((value > 1.0F) || (value < 0.0F))
/* 163:163 */           throw new IllegalArgumentException("percent value must be >= 0 and <= 100");
/* 164:164 */         setConstraint(component, new PercentConstraint(value));
/* 165:    */       } else {
/* 166:166 */         setConstraint(component, new NumberConstraint(Integer.valueOf(s)));
/* 167:    */       }
/* 168:168 */     } else if (constraints == null)
/* 169:    */     {
/* 170:170 */       setConstraint(component, PREFERRED_SIZE);
/* 171:    */     } else {
/* 172:172 */       throw new IllegalArgumentException("Invalid Constraint");
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public void addLayoutComponent(Component component, Object constraints) {
/* 177:177 */     setConstraint(component, constraints);
/* 178:    */   }
/* 179:    */   
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */   public float getLayoutAlignmentX(Container target)
/* 186:    */   {
/* 187:187 */     return 0.5F;
/* 188:    */   }
/* 189:    */   
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */   public float getLayoutAlignmentY(Container target)
/* 196:    */   {
/* 197:197 */     return 0.5F;
/* 198:    */   }
/* 199:    */   
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */   public void invalidateLayout(Container target) {}
/* 207:    */   
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */   public void addLayoutComponent(String name, Component comp) {}
/* 214:    */   
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */   public void removeLayoutComponent(Component comp)
/* 221:    */   {
/* 222:222 */     m_ComponentToConstraint.remove(comp);
/* 223:    */   }
/* 224:    */   
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */   public Dimension minimumLayoutSize(Container parent)
/* 232:    */   {
/* 233:233 */     return preferredLayoutSize(parent);
/* 234:    */   }
/* 235:    */   
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */   public Dimension maximumLayoutSize(Container parent)
/* 243:    */   {
/* 244:244 */     return new Dimension(2147483647, 2147483647);
/* 245:    */   }
/* 246:    */   
/* 247:    */   public Dimension preferredLayoutSize(Container parent) {
/* 248:248 */     Component[] components = parent.getComponents();
/* 249:249 */     Insets insets = parent.getInsets();
/* 250:250 */     int width = 0;
/* 251:251 */     int height = 0;
/* 252:    */     
/* 253:253 */     boolean firstVisibleComponent = true;
/* 254:254 */     int i = 0; for (int c = components.length; i < c; i++) {
/* 255:255 */       if (components[i].isVisible()) {
/* 256:256 */         Dimension componentPreferredSize = components[i].getPreferredSize();
/* 257:257 */         if (orientation == 0) {
/* 258:258 */           height = Math.max(height, height);
/* 259:259 */           width += width;
/* 260:260 */           if (firstVisibleComponent) {
/* 261:261 */             firstVisibleComponent = false;
/* 262:    */           } else {
/* 263:263 */             width += gap;
/* 264:    */           }
/* 265:    */         } else {
/* 266:266 */           height += height;
/* 267:267 */           width = Math.max(width, width);
/* 268:268 */           if (firstVisibleComponent) {
/* 269:269 */             firstVisibleComponent = false;
/* 270:    */           } else {
/* 271:271 */             height += gap;
/* 272:    */           }
/* 273:    */         }
/* 274:    */       }
/* 275:    */     }
/* 276:276 */     return new Dimension(width + right + left, height + top + bottom);
/* 277:    */   }
/* 278:    */   
/* 279:    */ 
/* 280:    */   public void layoutContainer(Container parent)
/* 281:    */   {
/* 282:282 */     Insets insets = parent.getInsets();
/* 283:283 */     Dimension d = parent.getSize();
/* 284:    */     
/* 285:    */ 
/* 286:286 */     width = (width - left - right);
/* 287:287 */     height = (height - top - bottom);
/* 288:    */     
/* 289:    */ 
/* 290:290 */     Component[] components = parent.getComponents();
/* 291:291 */     int[] sizes = new int[components.length];
/* 292:    */     
/* 293:    */ 
/* 294:294 */     int totalSize = (0 == orientation ? width : height) - (components.length - 1) * gap;
/* 295:    */     
/* 296:    */ 
/* 297:297 */     int availableSize = totalSize;
/* 298:    */     
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:304 */     int i = 0; for (int c = components.length; i < c; i++) {
/* 305:305 */       if (components[i].isVisible()) {
/* 306:306 */         Constraint constraint = (Constraint)m_ComponentToConstraint.get(components[i]);
/* 307:    */         
/* 308:308 */         if ((constraint == null) || (constraint == PREFERRED_SIZE)) {
/* 309:309 */           sizes[i] = (0 == orientation ? getPreferredSize()width : getPreferredSize()height);
/* 310:    */           
/* 311:    */ 
/* 312:    */ 
/* 313:313 */           availableSize -= sizes[i];
/* 314:314 */         } else if ((constraint instanceof NumberConstraint)) {
/* 315:315 */           sizes[i] = ((NumberConstraint)constraint).intValue();
/* 316:316 */           availableSize -= sizes[i];
/* 317:    */         }
/* 318:    */       }
/* 319:    */     }
/* 320:    */     
/* 321:    */ 
/* 322:    */ 
/* 323:323 */     int remainingSize = availableSize;
/* 324:324 */     int i = 0; for (int c = components.length; i < c; i++) {
/* 325:325 */       if (components[i].isVisible()) {
/* 326:326 */         Constraint constraint = (Constraint)m_ComponentToConstraint.get(components[i]);
/* 327:    */         
/* 328:328 */         if ((constraint instanceof PercentConstraint)) {
/* 329:329 */           sizes[i] = ((int)(remainingSize * ((PercentConstraint)constraint).floatValue()));
/* 330:    */           
/* 331:331 */           availableSize -= sizes[i];
/* 332:    */         }
/* 333:    */       }
/* 334:    */     }
/* 335:    */     
/* 336:    */ 
/* 337:337 */     ArrayList remaining = new ArrayList();
/* 338:338 */     int i = 0; for (int c = components.length; i < c; i++)
/* 339:339 */       if (components[i].isVisible()) {
/* 340:340 */         Constraint constraint = (Constraint)m_ComponentToConstraint.get(components[i]);
/* 341:    */         
/* 342:342 */         if (constraint == REMAINING_SPACE) {
/* 343:343 */           remaining.add(new Integer(i));
/* 344:344 */           sizes[i] = 0;
/* 345:    */         }
/* 346:    */       }
/* 347:    */     int rest;
/* 348:    */     Iterator iter;
/* 349:349 */     if (remaining.size() > 0) {
/* 350:350 */       rest = availableSize / remaining.size();
/* 351:351 */       for (iter = remaining.iterator(); iter.hasNext();) {
/* 352:352 */         sizes[((Integer)iter.next()).intValue()] = rest;
/* 353:    */       }
/* 354:    */     }
/* 355:    */     
/* 356:    */ 
/* 357:357 */     int currentOffset = 0 == orientation ? left : top;
/* 358:    */     
/* 359:359 */     int i = 0; for (int c = components.length; i < c; i++) {
/* 360:360 */       if (components[i].isVisible()) {
/* 361:361 */         if (0 == orientation) {
/* 362:362 */           components[i].setBounds(currentOffset, top, sizes[i], height);
/* 363:    */ 
/* 364:    */         }
/* 365:    */         else
/* 366:    */         {
/* 367:    */ 
/* 368:368 */           components[i].setBounds(left, currentOffset, width, sizes[i]);
/* 369:    */         }
/* 370:    */         
/* 371:    */ 
/* 372:    */ 
/* 373:    */ 
/* 374:374 */         currentOffset += gap + sizes[i];
/* 375:    */       }
/* 376:    */     }
/* 377:    */   }
/* 378:    */ }
