/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.FontChooserUI;
/*   4:    */ import com.l2fprod.common.swing.plaf.JFontChooserAddon;
/*   5:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   6:    */ import java.awt.BorderLayout;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.Container;
/*   9:    */ import java.awt.Dialog;
/*  10:    */ import java.awt.Font;
/*  11:    */ import java.awt.Frame;
/*  12:    */ import java.awt.Window;
/*  13:    */ import javax.swing.JComponent;
/*  14:    */ import javax.swing.JOptionPane;
/*  15:    */ import javax.swing.SwingUtilities;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ public class JFontChooser
/*  51:    */   extends JComponent
/*  52:    */ {
/*  53:    */   public static final String SELECTED_FONT_CHANGED_KEY = "selectedFont";
/*  54:    */   protected Font selectedFont;
/*  55:    */   private FontChooserModel model;
/*  56:    */   
/*  57:    */   static
/*  58:    */   {
/*  59: 59 */     LookAndFeelAddons.contribute(new JFontChooserAddon());
/*  60:    */   }
/*  61:    */   
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */   public JFontChooser()
/*  72:    */   {
/*  73: 73 */     this(new DefaultFontChooserModel());
/*  74:    */   }
/*  75:    */   
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */   public JFontChooser(FontChooserModel model)
/*  83:    */   {
/*  84: 84 */     this.model = model;
/*  85: 85 */     selectedFont = getFont();
/*  86: 86 */     updateUI();
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */   public void updateUI()
/*  96:    */   {
/*  97: 97 */     setUI((FontChooserUI)LookAndFeelAddons.getUI(this, FontChooserUI.class));
/*  98:    */   }
/*  99:    */   
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */   public void setUI(FontChooserUI ui)
/* 111:    */   {
/* 112:112 */     super.setUI(ui);
/* 113:    */   }
/* 114:    */   
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */   public String getUIClassID()
/* 122:    */   {
/* 123:123 */     return "FontChooserUI";
/* 124:    */   }
/* 125:    */   
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */   public void setSelectedFont(Font f)
/* 138:    */   {
/* 139:139 */     Font oldFont = selectedFont;
/* 140:140 */     selectedFont = f;
/* 141:141 */     firePropertyChange("selectedFont", oldFont, selectedFont);
/* 142:    */   }
/* 143:    */   
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */   public Font getSelectedFont()
/* 149:    */   {
/* 150:150 */     return selectedFont;
/* 151:    */   }
/* 152:    */   
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */   public FontChooserModel getModel()
/* 158:    */   {
/* 159:159 */     return model;
/* 160:    */   }
/* 161:    */   
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */   public Font showFontDialog(Component parent, String title)
/* 179:    */   {
/* 180:180 */     BaseDialog dialog = createDialog(parent, title);
/* 181:181 */     if (dialog.ask()) {
/* 182:182 */       return getSelectedFont();
/* 183:    */     }
/* 184:184 */     return null;
/* 185:    */   }
/* 186:    */   
/* 187:    */ 
/* 188:    */   protected BaseDialog createDialog(Component parent, String title)
/* 189:    */   {
/* 190:190 */     Window window = parent == null ? JOptionPane.getRootFrame() : SwingUtilities.windowForComponent(parent);
/* 191:    */     BaseDialog dialog;
/* 192:192 */     BaseDialog dialog; if ((window instanceof Frame)) {
/* 193:193 */       dialog = new BaseDialog((Frame)window, title, true);
/* 194:    */     } else {
/* 195:195 */       dialog = new BaseDialog((Dialog)window, title, true);
/* 196:    */     }
/* 197:197 */     dialog.setDialogMode(0);
/* 198:198 */     dialog.getBanner().setVisible(false);
/* 199:    */     
/* 200:200 */     dialog.getContentPane().setLayout(new BorderLayout());
/* 201:201 */     dialog.getContentPane().add("Center", this);
/* 202:202 */     dialog.pack();
/* 203:203 */     dialog.setLocationRelativeTo(parent);
/* 204:    */     
/* 205:205 */     return dialog;
/* 206:    */   }
/* 207:    */   
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */   public static Font showDialog(Component parent, String title, Font initialFont)
/* 227:    */   {
/* 228:228 */     JFontChooser chooser = new JFontChooser();
/* 229:229 */     chooser.setSelectedFont(initialFont);
/* 230:230 */     return chooser.showFontDialog(parent, title);
/* 231:    */   }
/* 232:    */ }
