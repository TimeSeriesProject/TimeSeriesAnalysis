/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.FontChooserUI;
/*  4:   */ import java.awt.GraphicsEnvironment;
/*  5:   */ import java.nio.charset.Charset;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import java.util.Iterator;
/*  8:   */ import java.util.ResourceBundle;
/*  9:   */ import java.util.Set;
/* 10:   */ import java.util.SortedMap;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ public class DefaultFontChooserModel
/* 33:   */   implements FontChooserModel
/* 34:   */ {
/* 35:35 */   public static final int[] DEFAULT_FONT_SIZES = { 6, 8, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 40, 48, 56, 64, 72 };
/* 36:   */   
/* 37:   */   protected String[] fontFamilies;
/* 38:   */   private String[] charSets;
/* 39:   */   private int[] defaultFontSizes;
/* 40:   */   private String previewMessage;
/* 41:   */   
/* 42:   */   public DefaultFontChooserModel()
/* 43:   */   {
/* 44:44 */     ResourceBundle bundle = ResourceBundle.getBundle(FontChooserUI.class.getName() + "RB");
/* 45:   */     
/* 46:   */ 
/* 47:47 */     setPreviewMessage(bundle.getString("FontChooserUI.previewText"));
/* 48:   */     
/* 49:49 */     String[] fontFamilies = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
/* 50:   */     
/* 51:51 */     Arrays.sort(fontFamilies);
/* 52:52 */     setFontFamilies(fontFamilies);
/* 53:   */     
/* 54:54 */     SortedMap map = Charset.availableCharsets();
/* 55:55 */     String[] charSets = new String[map.size()];
/* 56:56 */     int i = 0;
/* 57:57 */     for (Iterator iter = map.keySet().iterator(); iter.hasNext(); i++) {
/* 58:58 */       charSets[i] = ((String)iter.next());
/* 59:   */     }
/* 60:60 */     setCharSets(charSets);
/* 61:   */     
/* 62:62 */     setDefaultFontSizes(DEFAULT_FONT_SIZES);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public void setFontFamilies(String[] fontFamilies) {
/* 66:66 */     this.fontFamilies = fontFamilies;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public String[] getFontFamilies(String charSetName) {
/* 70:70 */     return fontFamilies;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void setDefaultFontSizes(int[] defaultFontSizes) {
/* 74:74 */     this.defaultFontSizes = defaultFontSizes;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public int[] getDefaultSizes() {
/* 78:78 */     return defaultFontSizes;
/* 79:   */   }
/* 80:   */   
/* 81:   */   public void setCharSets(String[] charSets) {
/* 82:82 */     this.charSets = charSets;
/* 83:   */   }
/* 84:   */   
/* 85:   */   public String[] getCharSets() {
/* 86:86 */     return charSets;
/* 87:   */   }
/* 88:   */   
/* 89:   */   public void setPreviewMessage(String previewMessage) {
/* 90:90 */     this.previewMessage = previewMessage;
/* 91:   */   }
/* 92:   */   
/* 93:   */   public String getPreviewMessage(String charSetName) {
/* 94:94 */     return previewMessage;
/* 95:   */   }
/* 96:   */ }
