/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Image;
/*   5:    */ import java.beans.BeanDescriptor;
/*   6:    */ import java.beans.BeanInfo;
/*   7:    */ import java.beans.IntrospectionException;
/*   8:    */ import java.beans.Introspector;
/*   9:    */ import java.beans.MethodDescriptor;
/*  10:    */ import java.beans.PropertyDescriptor;
/*  11:    */ import java.beans.SimpleBeanInfo;
/*  12:    */ import java.util.Vector;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ public class JCollapsiblePaneBeanInfo
/*  20:    */   extends SimpleBeanInfo
/*  21:    */ {
/*  22: 22 */   protected BeanDescriptor bd = new BeanDescriptor(JCollapsiblePane.class);
/*  23:    */   
/*  24:    */   protected Image iconMono16;
/*  25:    */   
/*  26:    */   protected Image iconColor16;
/*  27:    */   
/*  28:    */   protected Image iconMono32;
/*  29:    */   
/*  30:    */   protected Image iconColor32;
/*  31:    */   
/*  32:    */ 
/*  33:    */   public JCollapsiblePaneBeanInfo()
/*  34:    */     throws IntrospectionException
/*  35:    */   {
/*  36: 36 */     bd.setName("JCollapsiblePane");
/*  37:    */     
/*  38: 38 */     bd.setShortDescription("A pane which hides its content with an animation.");
/*  39:    */     
/*  40: 40 */     bd.setValue("isContainer", Boolean.TRUE);
/*  41: 41 */     bd.setValue("containerDelegate", "getContentPane");
/*  42:    */     
/*  43: 43 */     BeanInfo info = Introspector.getBeanInfo(getBeanDescriptor().getBeanClass().getSuperclass());
/*  44:    */     
/*  45: 45 */     String order = info.getBeanDescriptor().getValue("propertyorder") == null ? "" : (String)info.getBeanDescriptor().getValue("propertyorder");
/*  46:    */     
/*  47: 47 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  48: 48 */     for (int i = 0; i != pd.length; i++) {
/*  49: 49 */       if (order.indexOf(pd[i].getName()) == -1) {
/*  50: 50 */         order = order + (order.length() == 0 ? "" : ":") + pd[i].getName();
/*  51:    */       }
/*  52:    */     }
/*  53: 53 */     getBeanDescriptor().setValue("propertyorder", order);
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */   public BeanInfo[] getAdditionalBeanInfo()
/*  61:    */   {
/*  62: 62 */     Vector bi = new Vector();
/*  63: 63 */     BeanInfo[] biarr = null;
/*  64:    */     try {
/*  65: 65 */       for (Class cl = JCollapsiblePane.class.getSuperclass(); 
/*  66: 66 */           !cl.equals(Component.class.getSuperclass()); cl = cl.getSuperclass())
/*  67:    */       {
/*  68: 68 */         bi.addElement(Introspector.getBeanInfo(cl));
/*  69:    */       }
/*  70: 70 */       biarr = new BeanInfo[bi.size()];
/*  71: 71 */       bi.copyInto(biarr);
/*  72:    */     }
/*  73:    */     catch (Exception e) {}
/*  74:    */     
/*  75: 75 */     return biarr;
/*  76:    */   }
/*  77:    */   
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */   public BeanDescriptor getBeanDescriptor()
/*  83:    */   {
/*  84: 84 */     return bd;
/*  85:    */   }
/*  86:    */   
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */   public int getDefaultPropertyIndex()
/*  92:    */   {
/*  93: 93 */     String defName = "";
/*  94: 94 */     if (defName.equals("")) return -1;
/*  95: 95 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  96: 96 */     for (int i = 0; i < pd.length; i++) {
/*  97: 97 */       if (pd[i].getName().equals(defName)) return i;
/*  98:    */     }
/*  99: 99 */     return -1;
/* 100:    */   }
/* 101:    */   
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */   public Image getIcon(int type)
/* 109:    */   {
/* 110:110 */     if (type == 1) return iconColor16;
/* 111:111 */     if (type == 3) return iconMono16;
/* 112:112 */     if (type == 2) return iconColor32;
/* 113:113 */     if (type == 4) return iconMono32;
/* 114:114 */     return null;
/* 115:    */   }
/* 116:    */   
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */   public PropertyDescriptor[] getPropertyDescriptors()
/* 121:    */   {
/* 122:    */     try
/* 123:    */     {
/* 124:124 */       Vector descriptors = new Vector();
/* 125:125 */       PropertyDescriptor descriptor = null;
/* 126:    */       try
/* 127:    */       {
/* 128:128 */         descriptor = new PropertyDescriptor("animated", JCollapsiblePane.class);
/* 129:    */       }
/* 130:    */       catch (IntrospectionException e) {
/* 131:131 */         descriptor = new PropertyDescriptor("animated", JCollapsiblePane.class, "getAnimated", null);
/* 132:    */       }
/* 133:    */       
/* 134:    */ 
/* 135:135 */       descriptor.setPreferred(true);
/* 136:    */       
/* 137:137 */       descriptor.setBound(true);
/* 138:    */       
/* 139:139 */       descriptors.add(descriptor);
/* 140:    */       try {
/* 141:141 */         descriptor = new PropertyDescriptor("collapsed", JCollapsiblePane.class);
/* 142:    */       }
/* 143:    */       catch (IntrospectionException e) {
/* 144:144 */         descriptor = new PropertyDescriptor("collapsed", JCollapsiblePane.class, "getCollapsed", null);
/* 145:    */       }
/* 146:    */       
/* 147:    */ 
/* 148:148 */       descriptor.setPreferred(true);
/* 149:    */       
/* 150:150 */       descriptor.setBound(true);
/* 151:    */       
/* 152:152 */       descriptors.add(descriptor);
/* 153:    */       
/* 154:154 */       return (PropertyDescriptor[])descriptors.toArray(new PropertyDescriptor[descriptors.size()]);
/* 155:    */ 
/* 156:    */ 
/* 157:    */     }
/* 158:    */     catch (Exception e)
/* 159:    */     {
/* 160:    */ 
/* 161:161 */       e.printStackTrace();
/* 162:    */     }
/* 163:163 */     return null;
/* 164:    */   }
/* 165:    */   
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */   public MethodDescriptor[] getMethodDescriptors()
/* 171:    */   {
/* 172:172 */     return new MethodDescriptor[0];
/* 173:    */   }
/* 174:    */ }
