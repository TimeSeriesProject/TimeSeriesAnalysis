/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Image;
/*   4:    */ import java.beans.BeanDescriptor;
/*   5:    */ import java.beans.BeanInfo;
/*   6:    */ import java.beans.IntrospectionException;
/*   7:    */ import java.beans.Introspector;
/*   8:    */ import java.beans.PropertyDescriptor;
/*   9:    */ import java.beans.SimpleBeanInfo;
/*  10:    */ import java.util.Vector;
/*  11:    */ import javax.swing.JTabbedPane;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ public class JOutlookBarBeanInfo
/*  19:    */   extends SimpleBeanInfo
/*  20:    */ {
/*  21: 21 */   protected BeanDescriptor bd = new BeanDescriptor(JOutlookBar.class);
/*  22:    */   
/*  23:    */ 
/*  24: 24 */   protected Image iconMono16 = loadImage("JOutlookBar16-mono.gif");
/*  25:    */   
/*  26: 26 */   protected Image iconColor16 = loadImage("JOutlookBar16.gif");
/*  27:    */   
/*  28: 28 */   protected Image iconMono32 = loadImage("JOutlookBar32-mono.gif");
/*  29:    */   
/*  30: 30 */   protected Image iconColor32 = loadImage("JOutlookBar32.gif");
/*  31:    */   
/*  32:    */   public JOutlookBarBeanInfo()
/*  33:    */     throws IntrospectionException
/*  34:    */   {
/*  35: 35 */     bd.setName("JOutlookBar");
/*  36:    */     
/*  37: 37 */     bd.setShortDescription("JOutlookBar brings the famous Outlook component to Swing");
/*  38:    */     
/*  39:    */ 
/*  40: 40 */     BeanInfo info = Introspector.getBeanInfo(getBeanDescriptor().getBeanClass().getSuperclass());
/*  41:    */     
/*  42: 42 */     String order = info.getBeanDescriptor().getValue("propertyorder") == null ? "" : (String)info.getBeanDescriptor().getValue("propertyorder");
/*  43:    */     
/*  44: 44 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  45: 45 */     for (int i = 0; i != pd.length; i++) {
/*  46: 46 */       if (order.indexOf(pd[i].getName()) == -1) {
/*  47: 47 */         order = order + (order.length() == 0 ? "" : ":") + pd[i].getName();
/*  48:    */       }
/*  49:    */     }
/*  50: 50 */     getBeanDescriptor().setValue("propertyorder", order);
/*  51:    */   }
/*  52:    */   
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */   public BeanInfo[] getAdditionalBeanInfo()
/*  58:    */   {
/*  59: 59 */     Vector bi = new Vector();
/*  60: 60 */     BeanInfo[] biarr = null;
/*  61:    */     try {
/*  62: 62 */       for (Class cl = JOutlookBar.class.getSuperclass(); 
/*  63: 63 */           !cl.equals(JTabbedPane.class.getSuperclass()); 
/*  64: 64 */           cl = cl.getSuperclass()) {
/*  65: 65 */         bi.addElement(Introspector.getBeanInfo(cl));
/*  66:    */       }
/*  67: 67 */       biarr = new BeanInfo[bi.size()];
/*  68: 68 */       bi.copyInto(biarr);
/*  69:    */     }
/*  70:    */     catch (Exception e) {}
/*  71:    */     
/*  72: 72 */     return biarr;
/*  73:    */   }
/*  74:    */   
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */   public BeanDescriptor getBeanDescriptor()
/*  80:    */   {
/*  81: 81 */     return bd;
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   public int getDefaultPropertyIndex()
/*  89:    */   {
/*  90: 90 */     String defName = "";
/*  91: 91 */     if (defName.equals("")) return -1;
/*  92: 92 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  93: 93 */     for (int i = 0; i < pd.length; i++) {
/*  94: 94 */       if (pd[i].getName().equals(defName)) return i;
/*  95:    */     }
/*  96: 96 */     return -1;
/*  97:    */   }
/*  98:    */   
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */   public Image getIcon(int type)
/* 106:    */   {
/* 107:107 */     if (type == 1) return iconColor16;
/* 108:108 */     if (type == 3) return iconMono16;
/* 109:109 */     if (type == 2) return iconColor32;
/* 110:110 */     if (type == 4) return iconMono32;
/* 111:111 */     return null;
/* 112:    */   }
/* 113:    */   
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */   public PropertyDescriptor[] getPropertyDescriptors()
/* 118:    */   {
/* 119:    */     try
/* 120:    */     {
/* 121:121 */       Vector descriptors = new Vector();
/* 122:122 */       PropertyDescriptor descriptor = null;
/* 123:    */       try
/* 124:    */       {
/* 125:125 */         descriptor = new PropertyDescriptor("animated", JOutlookBar.class);
/* 126:    */       }
/* 127:    */       catch (IntrospectionException e) {
/* 128:128 */         descriptor = new PropertyDescriptor("animated", JOutlookBar.class, "getAnimated", null);
/* 129:    */       }
/* 130:    */       
/* 131:    */ 
/* 132:132 */       descriptor.setPreferred(true);
/* 133:    */       
/* 134:134 */       descriptor.setBound(true);
/* 135:    */       
/* 136:136 */       descriptors.add(descriptor);
/* 137:    */       
/* 138:138 */       return (PropertyDescriptor[])descriptors.toArray(new PropertyDescriptor[descriptors.size()]);
/* 139:    */ 
/* 140:    */ 
/* 141:    */     }
/* 142:    */     catch (Exception e)
/* 143:    */     {
/* 144:    */ 
/* 145:145 */       e.printStackTrace();
/* 146:    */     }
/* 147:147 */     return null;
/* 148:    */   }
/* 149:    */ }
