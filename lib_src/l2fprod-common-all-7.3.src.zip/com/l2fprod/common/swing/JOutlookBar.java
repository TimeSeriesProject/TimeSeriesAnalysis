/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.JOutlookBarAddon;
/*   4:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.swing.plaf.OutlookBarUI;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.WeakHashMap;
/*  12:    */ import javax.swing.Icon;
/*  13:    */ import javax.swing.JScrollPane;
/*  14:    */ import javax.swing.JTabbedPane;
/*  15:    */ import javax.swing.UIManager;
/*  16:    */ import javax.swing.plaf.TabbedPaneUI;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ public class JOutlookBar
/*  58:    */   extends JTabbedPane
/*  59:    */ {
/*  60:    */   public static final String UI_CLASS_ID = "OutlookBarUI";
/*  61:    */   public static final String ANIMATED_CHANGED_KEY = "animated";
/*  62:    */   protected Map extendedPages;
/*  63:    */   
/*  64:    */   static
/*  65:    */   {
/*  66: 66 */     LookAndFeelAddons.contribute(new JOutlookBarAddon());
/*  67:    */   }
/*  68:    */   
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75: 75 */   private boolean animated = true;
/*  76:    */   
/*  77:    */ 
/*  78:    */ 
/*  79:    */   public JOutlookBar()
/*  80:    */   {
/*  81: 81 */     this(2);
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */   public JOutlookBar(int tabPlacement)
/*  87:    */   {
/*  88: 88 */     super(tabPlacement, 0);
/*  89: 89 */     extendedPages = new WeakHashMap();
/*  90: 90 */     updateUI();
/*  91:    */   }
/*  92:    */   
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */   public void updateUI()
/* 100:    */   {
/* 101:101 */     setUI((OutlookBarUI)LookAndFeelAddons.getUI(this, OutlookBarUI.class));
/* 102:    */   }
/* 103:    */   
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */   public void setUI(OutlookBarUI ui)
/* 113:    */   {
/* 114:114 */     super.setUI((TabbedPaneUI)ui);
/* 115:    */   }
/* 116:    */   
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */   public String getUIClassID()
/* 124:    */   {
/* 125:125 */     return "OutlookBarUI";
/* 126:    */   }
/* 127:    */   
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */   public void setAnimated(boolean animated)
/* 136:    */   {
/* 137:137 */     if (this.animated != animated) {
/* 138:138 */       this.animated = animated;
/* 139:139 */       firePropertyChange("animated", !animated, animated);
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */   public boolean isAnimated()
/* 147:    */   {
/* 148:148 */     return animated;
/* 149:    */   }
/* 150:    */   
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */   public JScrollPane makeScrollPane(Component component)
/* 163:    */   {
/* 164:164 */     return ((OutlookBarUI)getUI()).makeScrollPane(component);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void removeTabAt(int index) {
/* 168:168 */     checkIndex(index);
/* 169:169 */     removeExtendedPage(index);
/* 170:170 */     super.removeTabAt(index);
/* 171:    */   }
/* 172:    */   
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */   public void setAllTabsAlignment(int alignment)
/* 181:    */   {
/* 182:182 */     for (Iterator iter = extendedPages.values().iterator(); iter.hasNext();) {
/* 183:183 */       ExtendedPage page = (ExtendedPage)iter.next();
/* 184:184 */       page.setTabAlignment(alignment);
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */   public void setAlignmentAt(int index, int alignment)
/* 197:    */   {
/* 198:198 */     getExtendedPage(index).setTabAlignment(alignment);
/* 199:    */   }
/* 200:    */   
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */   public int getAlignmentAt(int index)
/* 205:    */   {
/* 206:206 */     return getExtendedPage(index).getTabAlignment();
/* 207:    */   }
/* 208:    */   
/* 209:    */ 
/* 210:    */ 
/* 211:    */   public void setTitleAt(int index, String title)
/* 212:    */   {
/* 213:213 */     super.setTitleAt(index, title);
/* 214:214 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 215:    */   }
/* 216:    */   
/* 217:    */ 
/* 218:    */ 
/* 219:    */   public void setIconAt(int index, Icon icon)
/* 220:    */   {
/* 221:221 */     super.setIconAt(index, icon);
/* 222:222 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 223:    */   }
/* 224:    */   
/* 225:    */   public Color getBackgroundAt(int index) {
/* 226:226 */     return getExtendedPage(index).getBackground();
/* 227:    */   }
/* 228:    */   
/* 229:    */ 
/* 230:    */ 
/* 231:    */   public void setBackgroundAt(int index, Color background)
/* 232:    */   {
/* 233:233 */     getExtendedPage(index).setBackground(background);
/* 234:234 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 235:    */   }
/* 236:    */   
/* 237:    */   public Color getForegroundAt(int index) {
/* 238:238 */     return getExtendedPage(index).getForeground();
/* 239:    */   }
/* 240:    */   
/* 241:    */ 
/* 242:    */ 
/* 243:    */   public void setForegroundAt(int index, Color foreground)
/* 244:    */   {
/* 245:245 */     getExtendedPage(index).setForeground(foreground);
/* 246:246 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 247:    */   }
/* 248:    */   
/* 249:    */ 
/* 250:    */ 
/* 251:    */   public void setToolTipTextAt(int index, String toolTipText)
/* 252:    */   {
/* 253:253 */     super.setToolTipTextAt(index, toolTipText);
/* 254:254 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 255:    */   }
/* 256:    */   
/* 257:    */ 
/* 258:    */ 
/* 259:    */   public void setDisplayedMnemonicIndexAt(int tabIndex, int mnemonicIndex)
/* 260:    */   {
/* 261:261 */     super.setDisplayedMnemonicIndexAt(tabIndex, mnemonicIndex);
/* 262:262 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(tabIndex));
/* 263:    */   }
/* 264:    */   
/* 265:    */ 
/* 266:    */ 
/* 267:    */   public void setMnemonicAt(int index, int mnemonic)
/* 268:    */   {
/* 269:269 */     super.setMnemonicAt(index, mnemonic);
/* 270:270 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 271:    */   }
/* 272:    */   
/* 273:    */ 
/* 274:    */ 
/* 275:    */   public void setDisabledIconAt(int index, Icon disabledIcon)
/* 276:    */   {
/* 277:277 */     super.setDisabledIconAt(index, disabledIcon);
/* 278:278 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 279:    */   }
/* 280:    */   
/* 281:    */ 
/* 282:    */ 
/* 283:    */   public void setEnabledAt(int index, boolean enabled)
/* 284:    */   {
/* 285:285 */     super.setEnabledAt(index, enabled);
/* 286:286 */     firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(index));
/* 287:    */   }
/* 288:    */   
/* 289:    */   protected void addImpl(Component comp, Object constraints, int index) {
/* 290:290 */     if (index != -1) {
/* 291:291 */       super.addImpl(comp, constraints, index);
/* 292:    */ 
/* 293:    */     }
/* 294:    */     else
/* 295:    */     {
/* 296:    */ 
/* 297:297 */       int pageIndex = indexOfComponent(comp);
/* 298:298 */       if (pageIndex == -1) {
/* 299:299 */         super.addImpl(comp, constraints, index);
/* 300:    */       }
/* 301:    */       else
/* 302:    */       {
/* 303:303 */         super.addImpl(comp, constraints, pageIndex * 2);
/* 304:    */       }
/* 305:    */     }
/* 306:    */   }
/* 307:    */   
/* 308:    */   protected void removeExtendedPage(int index) {
/* 309:309 */     Component component = getComponentAt(index);
/* 310:310 */     extendedPages.remove(component);
/* 311:    */   }
/* 312:    */   
/* 313:    */   protected ExtendedPage getExtendedPage(int index) {
/* 314:314 */     checkIndex(index);
/* 315:    */     
/* 316:316 */     Component component = getComponentAt(index);
/* 317:317 */     ExtendedPage page = (ExtendedPage)extendedPages.get(component);
/* 318:318 */     if (page == null) {
/* 319:319 */       page = new ExtendedPage(null);
/* 320:320 */       component = component;
/* 321:321 */       extendedPages.put(component, page);
/* 322:    */     }
/* 323:323 */     return page;
/* 324:    */   }
/* 325:    */   
/* 326:    */   private void checkIndex(int index) {
/* 327:327 */     if ((index < 0) || (index >= getTabCount()))
/* 328:328 */       throw new IndexOutOfBoundsException("Index: " + index + ", Tab count: " + getTabCount());
/* 329:    */   }
/* 330:    */   
/* 331:    */   private class ExtendedPage { Component component;
/* 332:    */     
/* 333:333 */     ExtendedPage(JOutlookBar.1 x1) { this(); }
/* 334:    */     
/* 335:    */ 
/* 336:336 */     int alignment = UIManager.getInt("OutlookBar.tabAlignment");
/* 337:337 */     Color background = null;
/* 338:338 */     Color foreground = null;
/* 339:    */     
/* 340:    */     public void setTabAlignment(int alignment) {
/* 341:341 */       if (this.alignment != alignment) {
/* 342:342 */         this.alignment = alignment;
/* 343:343 */         firePropertyChange("tabPropertyChangedAtIndex", null, new Integer(getIndex()));
/* 344:    */       }
/* 345:    */     }
/* 346:    */     
/* 347:    */     public int getIndex()
/* 348:    */     {
/* 349:349 */       return indexOfComponent(component);
/* 350:    */     }
/* 351:    */     
/* 352:    */     public int getTabAlignment() {
/* 353:353 */       return alignment;
/* 354:    */     }
/* 355:    */     
/* 356:    */     public Color getBackground() {
/* 357:357 */       return background;
/* 358:    */     }
/* 359:    */     
/* 360:    */     public void setBackground(Color background) {
/* 361:361 */       this.background = background;
/* 362:    */     }
/* 363:    */     
/* 364:    */     public Color getForeground() {
/* 365:365 */       return foreground;
/* 366:    */     }
/* 367:    */     
/* 368:    */     public void setForeground(Color foreground) {
/* 369:369 */       this.foreground = foreground;
/* 370:    */     }
/* 371:    */     
/* 372:    */     private ExtendedPage() {}
/* 373:    */   }
/* 374:    */ }
