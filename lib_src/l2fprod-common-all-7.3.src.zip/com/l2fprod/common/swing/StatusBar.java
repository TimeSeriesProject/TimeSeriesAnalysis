/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.util.Hashtable;
/*   6:    */ import javax.swing.BorderFactory;
/*   7:    */ import javax.swing.JComponent;
/*   8:    */ import javax.swing.JLabel;
/*   9:    */ import javax.swing.border.Border;
/*  10:    */ import javax.swing.border.CompoundBorder;
/*  11:    */ import javax.swing.border.EmptyBorder;
/*  12:    */ import javax.swing.plaf.UIResource;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ public class StatusBar
/*  43:    */   extends JComponent
/*  44:    */ {
/*  45:    */   public static final String DEFAULT_ZONE = "default";
/*  46:    */   private Hashtable idToZones;
/*  47:    */   private Border zoneBorder;
/*  48:    */   
/*  49:    */   public StatusBar()
/*  50:    */   {
/*  51: 51 */     setLayout(LookAndFeelTweaks.createHorizontalPercentLayout());
/*  52: 52 */     idToZones = new Hashtable();
/*  53: 53 */     setZoneBorder(BorderFactory.createLineBorder(Color.lightGray));
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setZoneBorder(Border border) {
/*  57: 57 */     zoneBorder = border;
/*  58:    */   }
/*  59:    */   
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */   public void addZone(String id, Component zone, String constraints)
/*  69:    */   {
/*  70: 70 */     Component previousZone = getZone(id);
/*  71: 71 */     if (previousZone != null) {
/*  72: 72 */       remove(previousZone);
/*  73: 73 */       idToZones.remove(id);
/*  74:    */     }
/*  75:    */     
/*  76: 76 */     if ((zone instanceof JComponent)) {
/*  77: 77 */       JComponent jc = (JComponent)zone;
/*  78: 78 */       if ((jc.getBorder() == null) || ((jc.getBorder() instanceof UIResource))) {
/*  79: 79 */         if ((jc instanceof JLabel)) {
/*  80: 80 */           jc.setBorder(new CompoundBorder(zoneBorder, new EmptyBorder(0, 2, 0, 2)));
/*  81:    */           
/*  82: 82 */           ((JLabel)jc).setText(" ");
/*  83:    */         } else {
/*  84: 84 */           jc.setBorder(zoneBorder);
/*  85:    */         }
/*  86:    */       }
/*  87:    */     }
/*  88:    */     
/*  89: 89 */     add(zone, constraints);
/*  90: 90 */     idToZones.put(id, zone);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Component getZone(String id) {
/*  94: 94 */     return (Component)idToZones.get(id);
/*  95:    */   }
/*  96:    */   
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */   public void setZones(String[] ids, Component[] zones, String[] constraints)
/* 114:    */   {
/* 115:115 */     removeAll();
/* 116:116 */     idToZones.clear();
/* 117:117 */     int i = 0; for (int c = zones.length; i < c; i++) {
/* 118:118 */       addZone(ids[i], zones[i], constraints[i]);
/* 119:    */     }
/* 120:    */   }
/* 121:    */ }
