/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.JTipOfTheDayAddon;
/*   4:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   5:    */ import com.l2fprod.common.swing.plaf.TipOfTheDayUI;
/*   6:    */ import com.l2fprod.common.swing.tips.DefaultTipModel;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.HeadlessException;
/*   9:    */ import java.util.prefs.Preferences;
/*  10:    */ import javax.swing.JComponent;
/*  11:    */ import javax.swing.JDialog;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ public class JTipOfTheDay
/*  51:    */   extends JComponent
/*  52:    */ {
/*  53:    */   public static final String uiClassID = "l2fprod/TipOfTheDayUI";
/*  54:    */   public static final String PREFERENCE_KEY = "ShowTipOnStartup";
/*  55:    */   public static final String CURRENT_TIP_CHANGED_KEY = "currentTip";
/*  56:    */   private TipModel model;
/*  57:    */   
/*  58:    */   static
/*  59:    */   {
/*  60: 60 */     LookAndFeelAddons.contribute(new JTipOfTheDayAddon());
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74: 74 */   private int currentTip = 0;
/*  75:    */   
/*  76:    */   public JTipOfTheDay() {
/*  77: 77 */     this(new DefaultTipModel(new TipModel.Tip[0]));
/*  78:    */   }
/*  79:    */   
/*  80:    */   public JTipOfTheDay(TipModel model) {
/*  81: 81 */     this.model = model;
/*  82: 82 */     updateUI();
/*  83:    */   }
/*  84:    */   
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */   public void updateUI()
/*  92:    */   {
/*  93: 93 */     setUI((TipOfTheDayUI)LookAndFeelAddons.getUI(this, TipOfTheDayUI.class));
/*  94:    */   }
/*  95:    */   
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */   public void setUI(TipOfTheDayUI ui)
/* 106:    */   {
/* 107:107 */     super.setUI(ui);
/* 108:    */   }
/* 109:    */   
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */   public TipOfTheDayUI getUI()
/* 115:    */   {
/* 116:116 */     return (TipOfTheDayUI)ui;
/* 117:    */   }
/* 118:    */   
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */   public String getUIClassID()
/* 126:    */   {
/* 127:127 */     return "l2fprod/TipOfTheDayUI";
/* 128:    */   }
/* 129:    */   
/* 130:    */   public TipModel getModel() {
/* 131:131 */     return model;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setModel(TipModel model) {
/* 135:135 */     TipModel old = this.model;
/* 136:136 */     this.model = model;
/* 137:137 */     firePropertyChange("model", old, model);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public int getCurrentTip() {
/* 141:141 */     return currentTip;
/* 142:    */   }
/* 143:    */   
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */   public void setCurrentTip(int currentTip)
/* 151:    */   {
/* 152:152 */     if ((currentTip < 0) || (currentTip >= getModel().getTipCount())) { throw new IllegalArgumentException("Current tip must be within the bounds [0, " + getModel().getTipCount() + "[");
/* 153:    */     }
/* 154:    */     
/* 155:    */ 
/* 156:156 */     int oldTip = this.currentTip;
/* 157:157 */     this.currentTip = currentTip;
/* 158:158 */     firePropertyChange("currentTip", oldTip, currentTip);
/* 159:    */   }
/* 160:    */   
/* 161:    */ 
/* 162:    */ 
/* 163:    */   public void nextTip()
/* 164:    */   {
/* 165:165 */     int count = getModel().getTipCount();
/* 166:166 */     if (count == 0) { return;
/* 167:    */     }
/* 168:168 */     int nextTip = currentTip + 1;
/* 169:169 */     if (nextTip >= count) {
/* 170:170 */       nextTip = 0;
/* 171:    */     }
/* 172:172 */     setCurrentTip(nextTip);
/* 173:    */   }
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */   public void previousTip()
/* 178:    */   {
/* 179:179 */     int count = getModel().getTipCount();
/* 180:180 */     if (count == 0) { return;
/* 181:    */     }
/* 182:182 */     int previousTip = currentTip - 1;
/* 183:183 */     if (previousTip < 0) {
/* 184:184 */       previousTip = count - 1;
/* 185:    */     }
/* 186:186 */     setCurrentTip(previousTip);
/* 187:    */   }
/* 188:    */   
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */   public void showDialog(Component parentComponent)
/* 196:    */     throws HeadlessException
/* 197:    */   {
/* 198:198 */     showDialog(parentComponent, (ShowOnStartupChoice)null);
/* 199:    */   }
/* 200:    */   
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */   public boolean showDialog(Component parentComponent, Preferences showOnStartupPref)
/* 215:    */     throws HeadlessException
/* 216:    */   {
/* 217:217 */     return showDialog(parentComponent, showOnStartupPref, false);
/* 218:    */   }
/* 219:    */   
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */   public boolean showDialog(Component parentComponent, Preferences showOnStartupPref, boolean force)
/* 238:    */     throws HeadlessException
/* 239:    */   {
/* 240:240 */     if (showOnStartupPref == null) { throw new IllegalArgumentException("Preferences can not be null");
/* 241:    */     }
/* 242:    */     
/* 243:243 */     ShowOnStartupChoice store = new ShowOnStartupChoice() { private final Preferences val$showOnStartupPref;
/* 244:    */       
/* 245:245 */       public boolean isShowingOnStartup() { return val$showOnStartupPref.getBoolean("ShowTipOnStartup", true); }
/* 246:    */       
/* 247:    */       public void setShowingOnStartup(boolean showOnStartup)
/* 248:    */       {
/* 249:249 */         if (!showOnStartup) {
/* 250:250 */           val$showOnStartupPref.putBoolean("ShowTipOnStartup", showOnStartup);
/* 251:    */         }
/* 252:    */       }
/* 253:253 */     };
/* 254:254 */     return showDialog(parentComponent, store, force);
/* 255:    */   }
/* 256:    */   
/* 257:    */ 
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */ 
/* 272:    */ 
/* 273:    */ 
/* 274:    */   public boolean showDialog(Component parentComponent, ShowOnStartupChoice choice)
/* 275:    */   {
/* 276:276 */     return showDialog(parentComponent, choice, false);
/* 277:    */   }
/* 278:    */   
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */   public boolean showDialog(Component parentComponent, ShowOnStartupChoice choice, boolean force)
/* 301:    */   {
/* 302:302 */     if (choice == null) {
/* 303:303 */       JDialog dialog = createDialog(parentComponent, choice);
/* 304:304 */       dialog.setVisible(true);
/* 305:305 */       dialog.dispose();
/* 306:306 */       return true; }
/* 307:307 */     if ((force) || (choice.isShowingOnStartup())) {
/* 308:308 */       JDialog dialog = createDialog(parentComponent, choice);
/* 309:309 */       dialog.setVisible(true);
/* 310:310 */       dialog.dispose();
/* 311:311 */       return choice.isShowingOnStartup();
/* 312:    */     }
/* 313:313 */     return false;
/* 314:    */   }
/* 315:    */   
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */   public static boolean isShowingOnStartup(Preferences showOnStartupPref)
/* 321:    */   {
/* 322:322 */     return showOnStartupPref.getBoolean("ShowTipOnStartup", true);
/* 323:    */   }
/* 324:    */   
/* 325:    */ 
/* 326:    */ 
/* 327:    */ 
/* 328:    */ 
/* 329:    */ 
/* 330:    */ 
/* 331:    */   public static void forceShowOnStartup(Preferences showOnStartupPref)
/* 332:    */   {
/* 333:333 */     showOnStartupPref.remove("ShowTipOnStartup");
/* 334:    */   }
/* 335:    */   
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */   protected JDialog createDialog(Component parentComponent, ShowOnStartupChoice choice)
/* 345:    */   {
/* 346:346 */     return getUI().createDialog(parentComponent, choice);
/* 347:    */   }
/* 348:    */   
/* 349:    */   public static abstract interface ShowOnStartupChoice
/* 350:    */   {
/* 351:    */     public abstract void setShowingOnStartup(boolean paramBoolean);
/* 352:    */     
/* 353:    */     public abstract boolean isShowingOnStartup();
/* 354:    */   }
/* 355:    */ }
