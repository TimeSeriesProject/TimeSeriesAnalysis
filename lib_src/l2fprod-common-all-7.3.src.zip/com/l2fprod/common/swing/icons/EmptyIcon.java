/*  1:   */ package com.l2fprod.common.swing.icons;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import javax.swing.Icon;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public final class EmptyIcon
/* 27:   */   implements Icon
/* 28:   */ {
/* 29:   */   private int width;
/* 30:   */   private int height;
/* 31:   */   
/* 32:   */   public EmptyIcon()
/* 33:   */   {
/* 34:34 */     this(0, 0);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public EmptyIcon(int width, int height) {
/* 38:38 */     this.width = width;
/* 39:39 */     this.height = height;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int getIconHeight() {
/* 43:43 */     return height;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int getIconWidth() {
/* 47:47 */     return width;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void paintIcon(Component c, Graphics g, int x, int y) {}
/* 51:   */ }
