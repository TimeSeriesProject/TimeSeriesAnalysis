/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Image;
/*   4:    */ import java.beans.BeanDescriptor;
/*   5:    */ import java.beans.BeanInfo;
/*   6:    */ import java.beans.IntrospectionException;
/*   7:    */ import java.beans.Introspector;
/*   8:    */ import java.beans.PropertyDescriptor;
/*   9:    */ import java.beans.SimpleBeanInfo;
/*  10:    */ import java.util.Vector;
/*  11:    */ import javax.swing.JComponent;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ public class JFontChooserBeanInfo
/*  19:    */   extends SimpleBeanInfo
/*  20:    */ {
/*  21: 21 */   protected BeanDescriptor bd = new BeanDescriptor(JFontChooser.class);
/*  22:    */   
/*  23:    */ 
/*  24: 24 */   protected Image iconMono16 = loadImage("JFontChooser16-mono.gif");
/*  25:    */   
/*  26: 26 */   protected Image iconColor16 = loadImage("JFontChooser16.gif");
/*  27:    */   
/*  28: 28 */   protected Image iconMono32 = loadImage("JFontChooser32-mono.gif");
/*  29:    */   
/*  30: 30 */   protected Image iconColor32 = loadImage("JFontChooser32.gif");
/*  31:    */   
/*  32:    */   public JFontChooserBeanInfo()
/*  33:    */     throws IntrospectionException
/*  34:    */   {
/*  35: 35 */     bd.setName("JFontChooser");
/*  36:    */     
/*  37: 37 */     bd.setShortDescription("A component that supports selecting a Font.");
/*  38:    */     
/*  39: 39 */     bd.setValue("isContainer", Boolean.FALSE);
/*  40:    */     
/*  41: 41 */     BeanInfo info = Introspector.getBeanInfo(getBeanDescriptor().getBeanClass().getSuperclass());
/*  42:    */     
/*  43: 43 */     String order = info.getBeanDescriptor().getValue("propertyorder") == null ? "" : (String)info.getBeanDescriptor().getValue("propertyorder");
/*  44:    */     
/*  45: 45 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  46: 46 */     for (int i = 0; i != pd.length; i++) {
/*  47: 47 */       if (order.indexOf(pd[i].getName()) == -1) {
/*  48: 48 */         order = order + (order.length() == 0 ? "" : ":") + pd[i].getName();
/*  49:    */       }
/*  50:    */     }
/*  51: 51 */     getBeanDescriptor().setValue("propertyorder", order);
/*  52:    */   }
/*  53:    */   
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */   public BeanInfo[] getAdditionalBeanInfo()
/*  59:    */   {
/*  60: 60 */     Vector bi = new Vector();
/*  61: 61 */     BeanInfo[] biarr = null;
/*  62:    */     try {
/*  63: 63 */       for (Class cl = JFontChooser.class.getSuperclass(); 
/*  64: 64 */           !cl.equals(JComponent.class.getSuperclass()); 
/*  65: 65 */           cl = cl.getSuperclass()) {
/*  66: 66 */         bi.addElement(Introspector.getBeanInfo(cl));
/*  67:    */       }
/*  68: 68 */       biarr = new BeanInfo[bi.size()];
/*  69: 69 */       bi.copyInto(biarr);
/*  70:    */     }
/*  71:    */     catch (Exception e) {}
/*  72:    */     
/*  73: 73 */     return biarr;
/*  74:    */   }
/*  75:    */   
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */   public BeanDescriptor getBeanDescriptor()
/*  81:    */   {
/*  82: 82 */     return bd;
/*  83:    */   }
/*  84:    */   
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */   public int getDefaultPropertyIndex()
/*  90:    */   {
/*  91: 91 */     String defName = "";
/*  92: 92 */     if (defName.equals("")) return -1;
/*  93: 93 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  94: 94 */     for (int i = 0; i < pd.length; i++) {
/*  95: 95 */       if (pd[i].getName().equals(defName)) return i;
/*  96:    */     }
/*  97: 97 */     return -1;
/*  98:    */   }
/*  99:    */   
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */   public Image getIcon(int type)
/* 107:    */   {
/* 108:108 */     if (type == 1) return iconColor16;
/* 109:109 */     if (type == 3) return iconMono16;
/* 110:110 */     if (type == 2) return iconColor32;
/* 111:111 */     if (type == 4) return iconMono32;
/* 112:112 */     return null;
/* 113:    */   }
/* 114:    */   
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */   public PropertyDescriptor[] getPropertyDescriptors()
/* 119:    */   {
/* 120:    */     try
/* 121:    */     {
/* 122:122 */       Vector descriptors = new Vector();
/* 123:123 */       PropertyDescriptor descriptor = null;
/* 124:    */       try
/* 125:    */       {
/* 126:126 */         descriptor = new PropertyDescriptor("selectedFont", JFontChooser.class);
/* 127:    */       }
/* 128:    */       catch (IntrospectionException e) {
/* 129:129 */         descriptor = new PropertyDescriptor("selectedFont", JFontChooser.class, "getSelectedFont", null);
/* 130:    */       }
/* 131:    */       
/* 132:    */ 
/* 133:133 */       descriptor.setShortDescription("The current font the chooser is to display");
/* 134:    */       
/* 135:    */ 
/* 136:136 */       descriptor.setPreferred(true);
/* 137:    */       
/* 138:138 */       descriptor.setBound(true);
/* 139:    */       
/* 140:140 */       descriptors.add(descriptor);
/* 141:    */       
/* 142:142 */       return (PropertyDescriptor[])descriptors.toArray(new PropertyDescriptor[descriptors.size()]);
/* 143:    */ 
/* 144:    */ 
/* 145:    */     }
/* 146:    */     catch (Exception e)
/* 147:    */     {
/* 148:    */ 
/* 149:149 */       e.printStackTrace();
/* 150:    */     }
/* 151:151 */     return null;
/* 152:    */   }
/* 153:    */ }
