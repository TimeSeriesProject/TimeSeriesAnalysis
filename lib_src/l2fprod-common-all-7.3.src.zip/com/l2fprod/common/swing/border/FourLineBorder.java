/*  1:   */ package com.l2fprod.common.swing.border;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Graphics;
/*  6:   */ import java.awt.Insets;
/*  7:   */ import javax.swing.border.Border;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public class FourLineBorder
/* 30:   */   implements Border
/* 31:   */ {
/* 32:   */   private Color top;
/* 33:   */   private Color left;
/* 34:   */   private Color bottom;
/* 35:   */   private Color right;
/* 36:   */   
/* 37:   */   public FourLineBorder(Color top, Color left, Color bottom, Color right)
/* 38:   */   {
/* 39:39 */     this.top = top;
/* 40:40 */     this.left = left;
/* 41:41 */     this.bottom = bottom;
/* 42:42 */     this.right = right;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Insets getBorderInsets(Component c) {
/* 46:46 */     return new Insets(top == null ? 0 : 1, left == null ? 0 : 1, bottom == null ? 0 : 1, right == null ? 0 : 1);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public boolean isBorderOpaque()
/* 50:   */   {
/* 51:51 */     return true;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 55:   */   {
/* 56:56 */     if (bottom != null) {
/* 57:57 */       g.setColor(bottom);
/* 58:58 */       g.drawLine(x, y + height - 1, x + width - 1, y + height - 1);
/* 59:   */     }
/* 60:   */     
/* 61:61 */     if (right != null) {
/* 62:62 */       g.setColor(right);
/* 63:63 */       g.drawLine(x + width - 1, y, x + width - 1, y + height - 1);
/* 64:   */     }
/* 65:   */     
/* 66:66 */     if (top != null) {
/* 67:67 */       g.setColor(top);
/* 68:68 */       g.drawLine(x, y, x + width - 1, y);
/* 69:   */     }
/* 70:   */     
/* 71:71 */     if (left != null) {
/* 72:72 */       g.setColor(left);
/* 73:73 */       g.drawLine(x, y, x, y + height - 1);
/* 74:   */     }
/* 75:   */   }
/* 76:   */ }
