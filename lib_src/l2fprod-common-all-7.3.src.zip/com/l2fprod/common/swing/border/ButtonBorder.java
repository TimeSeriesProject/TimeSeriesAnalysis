/*  1:   */ package com.l2fprod.common.swing.border;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ import java.awt.Insets;
/*  6:   */ import javax.swing.AbstractButton;
/*  7:   */ import javax.swing.ButtonModel;
/*  8:   */ import javax.swing.border.AbstractBorder;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ public class ButtonBorder
/* 32:   */   extends AbstractBorder
/* 33:   */ {
/* 34:   */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 35:   */   {
/* 36:36 */     if ((c instanceof AbstractButton)) {
/* 37:37 */       AbstractButton b = (AbstractButton)c;
/* 38:38 */       ButtonModel model = b.getModel();
/* 39:   */       
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:44 */       boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 45:45 */       boolean isRollover = (b.isRolloverEnabled()) && (model.isRollover());
/* 46:46 */       boolean isEnabled = b.isEnabled();
/* 47:   */       
/* 48:48 */       if (!isEnabled) {
/* 49:49 */         paintDisabled(b, g, x, y, width, height);
/* 50:   */       }
/* 51:51 */       else if (isPressed) {
/* 52:52 */         paintPressed(b, g, x, y, width, height);
/* 53:53 */       } else if (isRollover) {
/* 54:54 */         paintRollover(b, g, x, y, width, height);
/* 55:   */       } else {
/* 56:56 */         paintNormal(b, g, x, y, width, height);
/* 57:   */       }
/* 58:   */     }
/* 59:   */   }
/* 60:   */   
/* 61:   */ 
/* 62:   */   protected void paintNormal(AbstractButton b, Graphics g, int x, int y, int width, int height) {}
/* 63:   */   
/* 64:   */ 
/* 65:   */   protected void paintDisabled(AbstractButton b, Graphics g, int x, int y, int width, int height) {}
/* 66:   */   
/* 67:   */ 
/* 68:   */   protected void paintRollover(AbstractButton b, Graphics g, int x, int y, int width, int height) {}
/* 69:   */   
/* 70:   */ 
/* 71:   */   protected void paintPressed(AbstractButton b, Graphics g, int x, int y, int width, int height) {}
/* 72:   */   
/* 73:   */   public Insets getBorderInsets(Component c)
/* 74:   */   {
/* 75:75 */     return getBorderInsets(c, new Insets(0, 0, 0, 0));
/* 76:   */   }
/* 77:   */   
/* 78:   */   public Insets getBorderInsets(Component c, Insets insets) {
/* 79:79 */     return insets;
/* 80:   */   }
/* 81:   */ }
