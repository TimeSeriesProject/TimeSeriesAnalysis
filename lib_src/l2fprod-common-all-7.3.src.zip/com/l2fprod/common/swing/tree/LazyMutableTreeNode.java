/*  1:   */ package com.l2fprod.common.swing.tree;
/*  2:   */ 
/*  3:   */ import javax.swing.tree.DefaultMutableTreeNode;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ public abstract class LazyMutableTreeNode
/* 26:   */   extends DefaultMutableTreeNode
/* 27:   */ {
/* 28:28 */   private boolean loaded = false;
/* 29:   */   
/* 30:   */ 
/* 31:   */   public LazyMutableTreeNode() {}
/* 32:   */   
/* 33:   */   public LazyMutableTreeNode(Object userObject)
/* 34:   */   {
/* 35:35 */     super(userObject);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public LazyMutableTreeNode(Object userObject, boolean allowsChildren) {
/* 39:39 */     super(userObject, allowsChildren);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int getChildCount() {
/* 43:43 */     synchronized (this) {
/* 44:44 */       if (!loaded) {
/* 45:45 */         loaded = true;
/* 46:46 */         loadChildren();
/* 47:   */       }
/* 48:   */     }
/* 49:49 */     return super.getChildCount();
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void clear() {
/* 53:53 */     removeAllChildren();
/* 54:54 */     loaded = false;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public boolean isLoaded() {
/* 58:58 */     return loaded;
/* 59:   */   }
/* 60:   */   
/* 61:   */   protected abstract void loadChildren();
/* 62:   */ }
