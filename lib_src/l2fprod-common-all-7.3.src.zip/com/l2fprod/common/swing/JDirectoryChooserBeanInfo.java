/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Image;
/*   4:    */ import java.beans.BeanDescriptor;
/*   5:    */ import java.beans.BeanInfo;
/*   6:    */ import java.beans.IntrospectionException;
/*   7:    */ import java.beans.Introspector;
/*   8:    */ import java.beans.MethodDescriptor;
/*   9:    */ import java.beans.PropertyDescriptor;
/*  10:    */ import java.beans.SimpleBeanInfo;
/*  11:    */ import java.util.Vector;
/*  12:    */ import javax.swing.JFileChooser;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ public class JDirectoryChooserBeanInfo
/*  20:    */   extends SimpleBeanInfo
/*  21:    */ {
/*  22: 22 */   protected BeanDescriptor bd = new BeanDescriptor(JDirectoryChooser.class);
/*  23:    */   
/*  24:    */ 
/*  25: 25 */   protected Image iconMono16 = loadImage("JDirectoryChooser16-mono.gif");
/*  26:    */   
/*  27: 27 */   protected Image iconColor16 = loadImage("JDirectoryChooser16.gif");
/*  28:    */   
/*  29: 29 */   protected Image iconMono32 = loadImage("JDirectoryChooser32-mono.gif");
/*  30:    */   
/*  31: 31 */   protected Image iconColor32 = loadImage("JDirectoryChooser32.gif");
/*  32:    */   
/*  33:    */   public JDirectoryChooserBeanInfo()
/*  34:    */     throws IntrospectionException
/*  35:    */   {
/*  36: 36 */     bd.setName("JDirectoryChooser");
/*  37:    */     
/*  38: 38 */     bd.setShortDescription("JDirectoryChooser allows to select one or more directories.");
/*  39:    */     
/*  40:    */ 
/*  41: 41 */     BeanInfo info = Introspector.getBeanInfo(getBeanDescriptor().getBeanClass().getSuperclass());
/*  42:    */     
/*  43: 43 */     String order = info.getBeanDescriptor().getValue("propertyorder") == null ? "" : (String)info.getBeanDescriptor().getValue("propertyorder");
/*  44:    */     
/*  45: 45 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  46: 46 */     for (int i = 0; i != pd.length; i++) {
/*  47: 47 */       if (order.indexOf(pd[i].getName()) == -1) {
/*  48: 48 */         order = order + (order.length() == 0 ? "" : ":") + pd[i].getName();
/*  49:    */       }
/*  50:    */     }
/*  51: 51 */     getBeanDescriptor().setValue("propertyorder", order);
/*  52:    */   }
/*  53:    */   
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */   public BeanInfo[] getAdditionalBeanInfo()
/*  59:    */   {
/*  60: 60 */     Vector bi = new Vector();
/*  61: 61 */     BeanInfo[] biarr = null;
/*  62:    */     try {
/*  63: 63 */       for (Class cl = JDirectoryChooser.class.getSuperclass(); 
/*  64: 64 */           !cl.equals(JFileChooser.class.getSuperclass()); 
/*  65: 65 */           cl = cl.getSuperclass()) {
/*  66: 66 */         bi.addElement(Introspector.getBeanInfo(cl));
/*  67:    */       }
/*  68: 68 */       biarr = new BeanInfo[bi.size()];
/*  69: 69 */       bi.copyInto(biarr);
/*  70:    */     }
/*  71:    */     catch (Exception e) {}
/*  72:    */     
/*  73: 73 */     return biarr;
/*  74:    */   }
/*  75:    */   
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */   public BeanDescriptor getBeanDescriptor()
/*  81:    */   {
/*  82: 82 */     return bd;
/*  83:    */   }
/*  84:    */   
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */   public int getDefaultPropertyIndex()
/*  90:    */   {
/*  91: 91 */     String defName = "";
/*  92: 92 */     if (defName.equals("")) return -1;
/*  93: 93 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  94: 94 */     for (int i = 0; i < pd.length; i++) {
/*  95: 95 */       if (pd[i].getName().equals(defName)) return i;
/*  96:    */     }
/*  97: 97 */     return -1;
/*  98:    */   }
/*  99:    */   
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */   public Image getIcon(int type)
/* 107:    */   {
/* 108:108 */     if (type == 1) return iconColor16;
/* 109:109 */     if (type == 3) return iconMono16;
/* 110:110 */     if (type == 2) return iconColor32;
/* 111:111 */     if (type == 4) return iconMono32;
/* 112:112 */     return null;
/* 113:    */   }
/* 114:    */   
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */   public PropertyDescriptor[] getPropertyDescriptors()
/* 119:    */   {
/* 120:    */     try
/* 121:    */     {
/* 122:122 */       Vector descriptors = new Vector();
/* 123:123 */       PropertyDescriptor descriptor = null;
/* 124:    */       try
/* 125:    */       {
/* 126:126 */         descriptor = new PropertyDescriptor("showingCreateDirectory", JDirectoryChooser.class);
/* 127:    */       }
/* 128:    */       catch (IntrospectionException e) {
/* 129:129 */         descriptor = new PropertyDescriptor("showingCreateDirectory", JDirectoryChooser.class, "isShowingCreateDirectory", null);
/* 130:    */       }
/* 131:    */       
/* 132:    */ 
/* 133:133 */       descriptor.setPreferred(true);
/* 134:134 */       descriptor.setBound(true);
/* 135:135 */       descriptors.add(descriptor);
/* 136:    */       
/* 137:137 */       return (PropertyDescriptor[])descriptors.toArray(new PropertyDescriptor[descriptors.size()]);
/* 138:    */ 
/* 139:    */ 
/* 140:    */     }
/* 141:    */     catch (Exception e)
/* 142:    */     {
/* 143:    */ 
/* 144:144 */       e.printStackTrace();
/* 145:    */     }
/* 146:146 */     return null;
/* 147:    */   }
/* 148:    */   
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */   public MethodDescriptor[] getMethodDescriptors()
/* 154:    */   {
/* 155:155 */     return new MethodDescriptor[0];
/* 156:    */   }
/* 157:    */ }
