/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.util.converter.ConverterRegistry;
/*   4:    */ import java.awt.Rectangle;
/*   5:    */ import java.awt.Window;
/*   6:    */ import java.awt.event.ComponentAdapter;
/*   7:    */ import java.awt.event.ComponentEvent;
/*   8:    */ import java.awt.event.ComponentListener;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import java.io.File;
/*  12:    */ import java.util.prefs.Preferences;
/*  13:    */ import javax.swing.JFileChooser;
/*  14:    */ import javax.swing.JSplitPane;
/*  15:    */ import javax.swing.event.DocumentEvent;
/*  16:    */ import javax.swing.event.DocumentListener;
/*  17:    */ import javax.swing.text.Document;
/*  18:    */ import javax.swing.text.JTextComponent;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public class UserPreferences
/*  47:    */ {
/*  48:    */   public static JFileChooser getDefaultFileChooser()
/*  49:    */   {
/*  50: 50 */     return getFileChooser("default");
/*  51:    */   }
/*  52:    */   
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */   public static JFileChooser getDefaultDirectoryChooser()
/*  59:    */   {
/*  60: 60 */     return getDirectoryChooser("default");
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */   public static JFileChooser getFileChooser(String id)
/*  70:    */   {
/*  71: 71 */     JFileChooser chooser = new JFileChooser();
/*  72: 72 */     track(chooser, "FileChooser." + id + ".path");
/*  73: 73 */     return chooser;
/*  74:    */   }
/*  75:    */   
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */   public static JFileChooser getDirectoryChooser(String id)
/*  80:    */   {
/*  81:    */     JFileChooser chooser;
/*  82:    */     
/*  83:    */ 
/*  84:    */     try
/*  85:    */     {
/*  86: 86 */       Class directoryChooserClass = Class.forName("com.l2fprod.common.swing.JDirectoryChooser");
/*  87:    */       
/*  88: 88 */       chooser = (JFileChooser)directoryChooserClass.newInstance();
/*  89:    */     } catch (Exception e) { JFileChooser chooser;
/*  90: 90 */       chooser = new JFileChooser();
/*  91: 91 */       chooser.setFileSelectionMode(1);
/*  92:    */     }
/*  93: 93 */     track(chooser, "DirectoryChooser." + id + ".path");
/*  94: 94 */     return chooser;
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static void track(JFileChooser chooser, String key)
/*  98:    */   {
/*  99: 99 */     String path = node().get(key, null);
/* 100:100 */     if (path != null) {
/* 101:101 */       File file = new File(path);
/* 102:102 */       if (file.exists()) {
/* 103:103 */         chooser.setCurrentDirectory(file);
/* 104:    */       }
/* 105:    */     }
/* 106:    */     
/* 107:107 */     PropertyChangeListener trackPath = new PropertyChangeListener() {
/* 108:    */       private final String val$key;
/* 109:    */       
/* 110:110 */       public void propertyChange(PropertyChangeEvent evt) { if ((evt.getNewValue() instanceof File)) {
/* 111:111 */           UserPreferences.access$000().put(val$key, ((File)evt.getNewValue()).getAbsolutePath());
/* 112:    */         }
/* 113:    */         
/* 114:    */       }
/* 115:115 */     };
/* 116:116 */     chooser.addPropertyChangeListener("directoryChanged", trackPath);
/* 117:    */   }
/* 118:    */   
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */   public static void track(Window window)
/* 127:    */   {
/* 128:128 */     Preferences prefs = node().node("Windows");
/* 129:    */     
/* 130:130 */     String bounds = prefs.get(window.getName() + ".bounds", null);
/* 131:131 */     if (bounds != null) {
/* 132:132 */       Rectangle rect = (Rectangle)ConverterRegistry.instance().convert(Rectangle.class, bounds);
/* 133:    */       
/* 134:    */ 
/* 135:    */ 
/* 136:136 */       window.setBounds(rect);
/* 137:    */     }
/* 138:    */     
/* 139:139 */     window.addComponentListener(windowDimension);
/* 140:    */   }
/* 141:    */   
/* 142:142 */   private static ComponentListener windowDimension = new ComponentAdapter() {
/* 143:    */     public void componentMoved(ComponentEvent e) {
/* 144:144 */       store((Window)e.getComponent());
/* 145:    */     }
/* 146:    */     
/* 147:147 */     public void componentResized(ComponentEvent e) { store((Window)e.getComponent()); }
/* 148:    */     
/* 149:    */     private void store(Window w) {
/* 150:150 */       String bounds = (String)ConverterRegistry.instance().convert(String.class, w.getBounds());
/* 151:    */       
/* 152:    */ 
/* 153:    */ 
/* 154:154 */       UserPreferences.access$000().node("Windows").put(w.getName() + ".bounds", bounds);
/* 155:    */     }
/* 156:    */   };
/* 157:    */   
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:164 */   public static void track(JTextComponent text) { new TextListener(text); }
/* 165:    */   
/* 166:    */   private static class TextListener implements DocumentListener {
/* 167:    */     private JTextComponent text;
/* 168:    */     
/* 169:    */     public TextListener(JTextComponent text) {
/* 170:170 */       this.text = text;
/* 171:171 */       restore();
/* 172:172 */       text.getDocument().addDocumentListener(this); }
/* 173:    */     
/* 174:174 */     public void changedUpdate(DocumentEvent e) { store(); }
/* 175:175 */     public void insertUpdate(DocumentEvent e) { store(); }
/* 176:176 */     public void removeUpdate(DocumentEvent e) { store(); }
/* 177:    */     
/* 178:178 */     void restore() { Preferences prefs = UserPreferences.access$000().node("JTextComponent");
/* 179:179 */       text.setText(prefs.get(text.getName(), ""));
/* 180:    */     }
/* 181:    */     
/* 182:182 */     void store() { Preferences prefs = UserPreferences.access$000().node("JTextComponent");
/* 183:183 */       prefs.put(text.getName(), text.getText());
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static void track(JSplitPane split) {
/* 188:188 */     Preferences prefs = node().node("JSplitPane");
/* 189:    */     
/* 190:    */ 
/* 191:191 */     int dividerLocation = prefs.getInt(split.getName() + ".dividerLocation", -1);
/* 192:    */     
/* 193:193 */     if (dividerLocation >= 0) {
/* 194:194 */       split.setDividerLocation(dividerLocation);
/* 195:    */     }
/* 196:    */     
/* 197:    */ 
/* 198:198 */     split.addPropertyChangeListener("dividerLocation", splitPaneListener);
/* 199:    */   }
/* 200:    */   
/* 201:    */ 
/* 202:    */ 
/* 203:203 */   private static PropertyChangeListener splitPaneListener = new PropertyChangeListener()
/* 204:    */   {
/* 205:    */     public void propertyChange(PropertyChangeEvent evt) {
/* 206:206 */       JSplitPane split = (JSplitPane)evt.getSource();
/* 207:207 */       UserPreferences.access$000().node("JSplitPane").put(split.getName() + ".dividerLocation", String.valueOf(split.getDividerLocation()));
/* 208:    */     }
/* 209:    */   };
/* 210:    */   
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */   private static Preferences node()
/* 216:    */   {
/* 217:217 */     return Preferences.userNodeForPackage(UserPreferences.class).node("UserPreferences");
/* 218:    */   }
/* 219:    */ }
