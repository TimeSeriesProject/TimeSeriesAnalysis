/*  1:   */ package com.l2fprod.common.swing.renderer;
/*  2:   */ 
/*  3:   */ import java.awt.Component;
/*  4:   */ import javax.swing.JCheckBox;
/*  5:   */ import javax.swing.JList;
/*  6:   */ import javax.swing.JTable;
/*  7:   */ import javax.swing.ListCellRenderer;
/*  8:   */ import javax.swing.table.TableCellRenderer;
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ public class BooleanCellRenderer
/* 39:   */   extends JCheckBox
/* 40:   */   implements TableCellRenderer, ListCellRenderer
/* 41:   */ {
/* 42:   */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 43:   */   {
/* 44:44 */     if (isSelected) {
/* 45:45 */       setBackground(table.getSelectionBackground());
/* 46:46 */       setForeground(table.getSelectionForeground());
/* 47:   */     } else {
/* 48:48 */       setBackground(table.getBackground());
/* 49:49 */       setForeground(table.getForeground());
/* 50:   */     }
/* 51:   */     
/* 52:52 */     setSelected(Boolean.TRUE.equals(value));
/* 53:   */     
/* 54:54 */     return this;
/* 55:   */   }
/* 56:   */   
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */ 
/* 62:   */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/* 63:   */   {
/* 64:64 */     if (isSelected) {
/* 65:65 */       setBackground(list.getSelectionBackground());
/* 66:66 */       setForeground(list.getSelectionForeground());
/* 67:   */     } else {
/* 68:68 */       setBackground(list.getBackground());
/* 69:69 */       setForeground(list.getForeground());
/* 70:   */     }
/* 71:   */     
/* 72:72 */     setSelected(Boolean.TRUE.equals(value));
/* 73:   */     
/* 74:74 */     return this;
/* 75:   */   }
/* 76:   */ }
