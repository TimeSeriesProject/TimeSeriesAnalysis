/*  1:   */ package com.l2fprod.common.swing.renderer;
/*  2:   */ 
/*  3:   */ import java.text.DateFormat;
/*  4:   */ import java.text.SimpleDateFormat;
/*  5:   */ import java.util.Date;
/*  6:   */ import java.util.Locale;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class DateRenderer
/* 29:   */   extends DefaultCellRenderer
/* 30:   */ {
/* 31:   */   private DateFormat dateFormat;
/* 32:   */   
/* 33:   */   public DateRenderer()
/* 34:   */   {
/* 35:35 */     this(DateFormat.getDateInstance(3));
/* 36:   */   }
/* 37:   */   
/* 38:   */   public DateRenderer(String formatString) {
/* 39:39 */     this(formatString, Locale.getDefault());
/* 40:   */   }
/* 41:   */   
/* 42:   */   public DateRenderer(Locale l) {
/* 43:43 */     this(DateFormat.getDateInstance(3, l));
/* 44:   */   }
/* 45:   */   
/* 46:   */   public DateRenderer(String formatString, Locale l) {
/* 47:47 */     this(new SimpleDateFormat(formatString, l));
/* 48:   */   }
/* 49:   */   
/* 50:   */   public DateRenderer(DateFormat dateFormat) {
/* 51:51 */     this.dateFormat = dateFormat;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void setValue(Object value) {
/* 55:55 */     if (value == null) {
/* 56:56 */       setText("");
/* 57:   */     } else {
/* 58:58 */       setText(dateFormat.format((Date)value));
/* 59:   */     }
/* 60:   */   }
/* 61:   */ }
