/*   1:    */ package com.l2fprod.common.swing.renderer;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.model.DefaultObjectRenderer;
/*   4:    */ import com.l2fprod.common.model.ObjectRenderer;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.SystemColor;
/*   8:    */ import javax.swing.Icon;
/*   9:    */ import javax.swing.JList;
/*  10:    */ import javax.swing.JTable;
/*  11:    */ import javax.swing.ListCellRenderer;
/*  12:    */ import javax.swing.table.DefaultTableCellRenderer;
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ public class DefaultCellRenderer
/*  38:    */   extends DefaultTableCellRenderer
/*  39:    */   implements ListCellRenderer
/*  40:    */ {
/*  41: 41 */   private ObjectRenderer objectRenderer = new DefaultObjectRenderer();
/*  42:    */   
/*  43: 43 */   private Color oddBackgroundColor = SystemColor.window;
/*  44: 44 */   private Color evenBackgroundColor = SystemColor.window;
/*  45: 45 */   private boolean showOddAndEvenRows = true;
/*  46:    */   
/*  47:    */   public void setOddBackgroundColor(Color c) {
/*  48: 48 */     oddBackgroundColor = c;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setEvenBackgroundColor(Color c) {
/*  52: 52 */     evenBackgroundColor = c;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setShowOddAndEvenRows(boolean b) {
/*  56: 56 */     showOddAndEvenRows = b;
/*  57:    */   }
/*  58:    */   
/*  59:    */ 
/*  60:    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*  61:    */   {
/*  62: 62 */     setBorder(null);
/*  63:    */     
/*  64: 64 */     if (isSelected) {
/*  65: 65 */       setBackground(list.getSelectionBackground());
/*  66: 66 */       setForeground(list.getSelectionForeground());
/*  67:    */     } else {
/*  68: 68 */       setBackground(list.getBackground());
/*  69: 69 */       setForeground(list.getForeground());
/*  70:    */     }
/*  71:    */     
/*  72: 72 */     setValue(value);
/*  73:    */     
/*  74: 74 */     return this;
/*  75:    */   }
/*  76:    */   
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*  83:    */   {
/*  84: 84 */     super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/*  85:    */     
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92: 92 */     if ((showOddAndEvenRows) && (!isSelected)) {
/*  93: 93 */       if (row % 2 == 0) {
/*  94: 94 */         setBackground(oddBackgroundColor);
/*  95:    */       } else {
/*  96: 96 */         setBackground(evenBackgroundColor);
/*  97:    */       }
/*  98:    */     }
/*  99:    */     
/* 100:100 */     setValue(value);
/* 101:    */     
/* 102:102 */     return this;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setValue(Object value) {
/* 106:106 */     String text = convertToString(value);
/* 107:107 */     Icon icon = convertToIcon(value);
/* 108:    */     
/* 109:109 */     setText(text == null ? "" : text);
/* 110:110 */     setIcon(icon);
/* 111:111 */     setDisabledIcon(icon);
/* 112:    */   }
/* 113:    */   
/* 114:    */   protected String convertToString(Object value) {
/* 115:115 */     return objectRenderer.getText(value);
/* 116:    */   }
/* 117:    */   
/* 118:    */   protected Icon convertToIcon(Object value) {
/* 119:119 */     return null;
/* 120:    */   }
/* 121:    */ }
