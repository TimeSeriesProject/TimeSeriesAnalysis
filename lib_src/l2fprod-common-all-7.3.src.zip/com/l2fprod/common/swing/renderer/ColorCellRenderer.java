/*   1:    */ package com.l2fprod.common.swing.renderer;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.Graphics2D;
/*   7:    */ import java.awt.Paint;
/*   8:    */ import javax.swing.Icon;
/*   9:    */ import javax.swing.UIManager;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public class ColorCellRenderer
/*  31:    */   extends DefaultCellRenderer
/*  32:    */ {
/*  33:    */   public static String toHex(Color color)
/*  34:    */   {
/*  35: 35 */     String red = Integer.toHexString(color.getRed());
/*  36: 36 */     String green = Integer.toHexString(color.getGreen());
/*  37: 37 */     String blue = Integer.toHexString(color.getBlue());
/*  38:    */     
/*  39: 39 */     if (red.length() == 1) {
/*  40: 40 */       red = "0" + red;
/*  41:    */     }
/*  42: 42 */     if (green.length() == 1) {
/*  43: 43 */       green = "0" + green;
/*  44:    */     }
/*  45: 45 */     if (blue.length() == 1) {
/*  46: 46 */       blue = "0" + blue;
/*  47:    */     }
/*  48: 48 */     return ("#" + red + green + blue).toUpperCase();
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected String convertToString(Object value) {
/*  52: 52 */     if ((value instanceof Integer)) {
/*  53: 53 */       value = new Color(((Integer)value).intValue());
/*  54:    */     }
/*  55: 55 */     if (!(value instanceof Color)) { return null;
/*  56:    */     }
/*  57: 57 */     Color color = (Color)value;
/*  58: 58 */     return "R:" + color.getRed() + " G:" + color.getGreen() + " B:" + color.getBlue() + " - " + toHex(color);
/*  59:    */   }
/*  60:    */   
/*  61:    */   protected Icon convertToIcon(Object value)
/*  62:    */   {
/*  63: 63 */     if (value == null) return null;
/*  64: 64 */     if ((value instanceof Integer)) {
/*  65: 65 */       value = new Color(((Integer)value).intValue());
/*  66:    */     }
/*  67: 67 */     return new PaintIcon((Paint)value);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static class PaintIcon implements Icon {
/*  71:    */     private final Paint color;
/*  72:    */     private final int width;
/*  73:    */     private final int height;
/*  74:    */     
/*  75:    */     public PaintIcon(Paint color) {
/*  76: 76 */       this(color, 20, 10);
/*  77:    */     }
/*  78:    */     
/*  79:    */     public PaintIcon(Paint color, int width, int height) {
/*  80: 80 */       this.color = color;
/*  81: 81 */       this.width = width;
/*  82: 82 */       this.height = height;
/*  83:    */     }
/*  84:    */     
/*  85:    */     public int getIconHeight() {
/*  86: 86 */       return height;
/*  87:    */     }
/*  88:    */     
/*  89: 89 */     public int getIconWidth() { return width; }
/*  90:    */     
/*  91:    */     public void paintIcon(Component c, Graphics g, int x, int y) {
/*  92: 92 */       Graphics2D g2d = (Graphics2D)g;
/*  93: 93 */       Paint oldPaint = g2d.getPaint();
/*  94:    */       
/*  95: 95 */       if (color != null) {
/*  96: 96 */         g2d.setPaint(color);
/*  97: 97 */         g.fillRect(x, y, getIconWidth(), getIconHeight());
/*  98:    */       }
/*  99:    */       
/* 100:100 */       g.setColor(UIManager.getColor("controlDkShadow"));
/* 101:101 */       g.drawRect(x, y, getIconWidth(), getIconHeight());
/* 102:    */       
/* 103:103 */       g2d.setPaint(oldPaint);
/* 104:    */     }
/* 105:    */   }
/* 106:    */ }
