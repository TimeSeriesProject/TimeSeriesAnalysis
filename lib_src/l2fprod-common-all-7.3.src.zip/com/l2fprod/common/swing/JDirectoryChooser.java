/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.plaf.DirectoryChooserUI;
/*   4:    */ import com.l2fprod.common.swing.plaf.JDirectoryChooserAddon;
/*   5:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.HeadlessException;
/*   8:    */ import java.io.File;
/*   9:    */ import javax.swing.JComponent;
/*  10:    */ import javax.swing.JDialog;
/*  11:    */ import javax.swing.JFileChooser;
/*  12:    */ import javax.swing.filechooser.FileSystemView;
/*  13:    */ import javax.swing.plaf.ComponentUI;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ public class JDirectoryChooser
/*  46:    */   extends JFileChooser
/*  47:    */ {
/*  48:    */   public static final String UI_CLASS_ID = "l2fprod/DirectoryChooserUI";
/*  49:    */   private boolean showingCreateDirectory;
/*  50:    */   public static final String SHOWING_CREATE_DIRECTORY_CHANGED_KEY = "showingCreateDirectory";
/*  51:    */   
/*  52:    */   static
/*  53:    */   {
/*  54: 54 */     LookAndFeelAddons.contribute(new JDirectoryChooserAddon());
/*  55:    */   }
/*  56:    */   
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */   public JDirectoryChooser()
/*  68:    */   {
/*  69: 69 */     setShowingCreateDirectory(true);
/*  70:    */   }
/*  71:    */   
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */   public JDirectoryChooser(File currentDirectory)
/*  77:    */   {
/*  78: 78 */     super(currentDirectory);
/*  79: 79 */     setShowingCreateDirectory(true);
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */   public JDirectoryChooser(File currentDirectory, FileSystemView fsv)
/*  89:    */   {
/*  90: 90 */     super(currentDirectory, fsv);
/*  91: 91 */     setShowingCreateDirectory(true);
/*  92:    */   }
/*  93:    */   
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */   public JDirectoryChooser(FileSystemView fsv)
/*  99:    */   {
/* 100:100 */     super(fsv);
/* 101:101 */     setShowingCreateDirectory(true);
/* 102:    */   }
/* 103:    */   
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */   public JDirectoryChooser(String currentDirectoryPath)
/* 109:    */   {
/* 110:110 */     super(currentDirectoryPath);
/* 111:111 */     setShowingCreateDirectory(true);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public JDirectoryChooser(String currentDirectoryPath, FileSystemView fsv) {
/* 115:115 */     super(currentDirectoryPath, fsv);
/* 116:116 */     setShowingCreateDirectory(true);
/* 117:    */   }
/* 118:    */   
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */   public void updateUI()
/* 125:    */   {
/* 126:126 */     setUI((DirectoryChooserUI)LookAndFeelAddons.getUI(this, DirectoryChooserUI.class));
/* 127:    */   }
/* 128:    */   
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:    */   public void setUI(DirectoryChooserUI ui)
/* 139:    */   {
/* 140:140 */     super.setUI((ComponentUI)ui);
/* 141:    */   }
/* 142:    */   
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */   public String getUIClassID()
/* 150:    */   {
/* 151:151 */     return "l2fprod/DirectoryChooserUI";
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */   public boolean isShowingCreateDirectory()
/* 158:    */   {
/* 159:159 */     return showingCreateDirectory;
/* 160:    */   }
/* 161:    */   
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */   public void setShowingCreateDirectory(boolean showingCreateDirectory)
/* 171:    */   {
/* 172:172 */     this.showingCreateDirectory = showingCreateDirectory;
/* 173:173 */     firePropertyChange("showingCreateDirectory", !showingCreateDirectory, showingCreateDirectory);
/* 174:    */   }
/* 175:    */   
/* 176:    */   protected JDialog createDialog(Component parent) throws HeadlessException
/* 177:    */   {
/* 178:178 */     JDialog dialog = super.createDialog(parent);
/* 179:179 */     ((JComponent)dialog.getContentPane()).setBorder(LookAndFeelTweaks.WINDOW_BORDER);
/* 180:    */     
/* 181:181 */     return dialog;
/* 182:    */   }
/* 183:    */ }
