/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import java.awt.Dimension;
/*  4:   */ import java.awt.Toolkit;
/*  5:   */ import java.awt.Window;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ public class UIUtilities
/* 28:   */ {
/* 29:   */   public static void centerOnScreen(Window window)
/* 30:   */   {
/* 31:31 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 32:32 */     Dimension size = window.getSize();
/* 33:33 */     window.setLocation((width - width) / 2, (height - height) / 2);
/* 34:   */   }
/* 35:   */ }
