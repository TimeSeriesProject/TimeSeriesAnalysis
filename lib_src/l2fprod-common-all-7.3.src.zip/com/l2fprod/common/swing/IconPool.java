/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import java.net.URL;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.Map;
/*  6:   */ import javax.swing.Icon;
/*  7:   */ import javax.swing.ImageIcon;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ public class IconPool
/* 32:   */ {
/* 33:33 */   private static IconPool iconPool = new IconPool();
/* 34:   */   private Map pool;
/* 35:   */   
/* 36:   */   public IconPool()
/* 37:   */   {
/* 38:38 */     pool = new HashMap();
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static IconPool shared() {
/* 42:42 */     return iconPool;
/* 43:   */   }
/* 44:   */   
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */   public Icon get(String url)
/* 52:   */   {
/* 53:53 */     StackTraceElement[] stacks = new Exception().getStackTrace();
/* 54:   */     try {
/* 55:55 */       Class callerClazz = Class.forName(stacks[1].getClassName());
/* 56:56 */       return get(callerClazz.getResource(url));
/* 57:   */     } catch (ClassNotFoundException e) {
/* 58:58 */       throw new RuntimeException(e);
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   public synchronized Icon get(URL url) {
/* 63:63 */     if (url == null) {
/* 64:64 */       return null;
/* 65:   */     }
/* 66:   */     
/* 67:67 */     Icon icon = (Icon)pool.get(url.toString());
/* 68:68 */     if (icon == null) {
/* 69:69 */       icon = new ImageIcon(url);
/* 70:70 */       pool.put(url.toString(), icon);
/* 71:   */     }
/* 72:72 */     return icon;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public synchronized void clear() {
/* 76:76 */     pool.clear();
/* 77:   */   }
/* 78:   */ }
