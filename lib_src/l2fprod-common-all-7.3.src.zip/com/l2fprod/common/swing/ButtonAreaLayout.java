/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.awt.LayoutManager;
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ public final class ButtonAreaLayout
/*  29:    */   implements LayoutManager
/*  30:    */ {
/*  31:    */   private int gap;
/*  32:    */   
/*  33:    */   public ButtonAreaLayout(int gap)
/*  34:    */   {
/*  35: 35 */     this.gap = gap;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void addLayoutComponent(String string, Component comp) {}
/*  39:    */   
/*  40:    */   public void layoutContainer(Container container)
/*  41:    */   {
/*  42: 42 */     Insets insets = container.getInsets();
/*  43: 43 */     Component[] children = container.getComponents();
/*  44:    */     
/*  45:    */ 
/*  46: 46 */     int maxWidth = 0;
/*  47: 47 */     int maxHeight = 0;
/*  48: 48 */     int visibleCount = 0;
/*  49:    */     
/*  50:    */ 
/*  51: 51 */     int i = 0; for (int c = children.length; i < c; i++) {
/*  52: 52 */       if (children[i].isVisible()) {
/*  53: 53 */         Dimension componentPreferredSize = children[i].getPreferredSize();
/*  54: 54 */         maxWidth = Math.max(maxWidth, width);
/*  55: 55 */         maxHeight = Math.max(maxHeight, height);
/*  56: 56 */         visibleCount++;
/*  57:    */       }
/*  58:    */     }
/*  59:    */     
/*  60: 60 */     int usedWidth = maxWidth * visibleCount + gap * (visibleCount - 1);
/*  61:    */     
/*  62: 62 */     visibleCount = 0;
/*  63: 63 */     int i = 0; for (int c = children.length; i < c; i++) {
/*  64: 64 */       if (children[i].isVisible()) {
/*  65: 65 */         children[i].setBounds(container.getWidth() - right - usedWidth + (maxWidth + gap) * visibleCount, top, maxWidth, maxHeight);
/*  66:    */         
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73: 73 */         visibleCount++;
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Dimension minimumLayoutSize(Container c) {
/*  79: 79 */     return preferredLayoutSize(c);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public Dimension preferredLayoutSize(Container container) {
/*  83: 83 */     Insets insets = container.getInsets();
/*  84: 84 */     Component[] children = container.getComponents();
/*  85:    */     
/*  86:    */ 
/*  87: 87 */     int maxWidth = 0;
/*  88: 88 */     int maxHeight = 0;
/*  89: 89 */     int visibleCount = 0;
/*  90:    */     
/*  91:    */ 
/*  92: 92 */     int i = 0; for (int c = children.length; i < c; i++) {
/*  93: 93 */       if (children[i].isVisible()) {
/*  94: 94 */         Dimension componentPreferredSize = children[i].getPreferredSize();
/*  95: 95 */         maxWidth = Math.max(maxWidth, width);
/*  96: 96 */         maxHeight = Math.max(maxHeight, height);
/*  97: 97 */         visibleCount++;
/*  98:    */       }
/*  99:    */     }
/* 100:    */     
/* 101:101 */     int usedWidth = maxWidth * visibleCount + gap * (visibleCount - 1);
/* 102:    */     
/* 103:103 */     return new Dimension(left + usedWidth + right, top + maxHeight + bottom);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void removeLayoutComponent(Component c) {}
/* 107:    */ }
