/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.ComponentOrientation;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Cursor;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.Point;
/*   8:    */ import java.awt.Rectangle;
/*   9:    */ import java.awt.event.MouseEvent;
/*  10:    */ import javax.swing.JScrollPane;
/*  11:    */ import javax.swing.JTable;
/*  12:    */ import javax.swing.JViewport;
/*  13:    */ import javax.swing.event.MouseInputAdapter;
/*  14:    */ import javax.swing.table.JTableHeader;
/*  15:    */ import javax.swing.table.TableColumn;
/*  16:    */ import javax.swing.table.TableColumnModel;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ public class HeaderlessColumnResizer
/*  39:    */   extends MouseInputAdapter
/*  40:    */ {
/*  41: 41 */   private static Cursor resizeCursor = Cursor.getPredefinedCursor(11);
/*  42:    */   
/*  43:    */   private int mouseXOffset;
/*  44:    */   
/*  45: 45 */   private Cursor otherCursor = resizeCursor;
/*  46:    */   private JTable table;
/*  47:    */   
/*  48:    */   public HeaderlessColumnResizer(JTable table)
/*  49:    */   {
/*  50: 50 */     this.table = table;
/*  51: 51 */     table.addMouseListener(this);
/*  52: 52 */     table.addMouseMotionListener(this);
/*  53:    */   }
/*  54:    */   
/*  55:    */   private boolean canResize(TableColumn column) {
/*  56: 56 */     return (column != null) && (table.getTableHeader().getResizingAllowed()) && (column.getResizable());
/*  57:    */   }
/*  58:    */   
/*  59:    */ 
/*  60:    */   private TableColumn getResizingColumn(Point p)
/*  61:    */   {
/*  62: 62 */     return getResizingColumn(p, table.columnAtPoint(p));
/*  63:    */   }
/*  64:    */   
/*  65:    */   private TableColumn getResizingColumn(Point p, int column) {
/*  66: 66 */     if (column == -1) {
/*  67: 67 */       return null;
/*  68:    */     }
/*  69: 69 */     int row = table.rowAtPoint(p);
/*  70: 70 */     Rectangle r = table.getCellRect(row, column, true);
/*  71: 71 */     r.grow(-3, 0);
/*  72: 72 */     if (r.contains(p)) {
/*  73: 73 */       return null;
/*  74:    */     }
/*  75: 75 */     int midPoint = x + width / 2;
/*  76:    */     int columnIndex;
/*  77: 77 */     int columnIndex; if (table.getTableHeader().getComponentOrientation().isLeftToRight()) {
/*  78: 78 */       columnIndex = x < midPoint ? column - 1 : column;
/*  79:    */     } else {
/*  80: 80 */       columnIndex = x < midPoint ? column : column - 1;
/*  81:    */     }
/*  82: 82 */     if (columnIndex == -1) {
/*  83: 83 */       return null;
/*  84:    */     }
/*  85: 85 */     return table.getTableHeader().getColumnModel().getColumn(columnIndex);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void mousePressed(MouseEvent e) {
/*  89: 89 */     table.getTableHeader().setDraggedColumn(null);
/*  90: 90 */     table.getTableHeader().setResizingColumn(null);
/*  91: 91 */     table.getTableHeader().setDraggedDistance(0);
/*  92:    */     
/*  93: 93 */     Point p = e.getPoint();
/*  94:    */     
/*  95:    */ 
/*  96: 96 */     int index = table.columnAtPoint(p);
/*  97:    */     
/*  98: 98 */     if (index != -1)
/*  99:    */     {
/* 100:100 */       TableColumn resizingColumn = getResizingColumn(p, index);
/* 101:101 */       if (canResize(resizingColumn)) {
/* 102:102 */         table.getTableHeader().setResizingColumn(resizingColumn);
/* 103:103 */         if (table.getTableHeader().getComponentOrientation().isLeftToRight()) {
/* 104:104 */           mouseXOffset = (x - resizingColumn.getWidth());
/* 105:    */         } else {
/* 106:106 */           mouseXOffset = (x + resizingColumn.getWidth());
/* 107:    */         }
/* 108:    */       }
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   private void swapCursor() {
/* 113:113 */     Cursor tmp = table.getCursor();
/* 114:114 */     table.setCursor(otherCursor);
/* 115:115 */     otherCursor = tmp;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void mouseMoved(MouseEvent e) {
/* 119:119 */     if (canResize(getResizingColumn(e.getPoint())) != (table.getCursor() == resizeCursor))
/* 120:    */     {
/* 121:121 */       swapCursor();
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void mouseDragged(MouseEvent e) {
/* 126:126 */     int mouseX = e.getX();
/* 127:    */     
/* 128:128 */     TableColumn resizingColumn = table.getTableHeader().getResizingColumn();
/* 129:    */     
/* 130:130 */     boolean headerLeftToRight = table.getTableHeader().getComponentOrientation().isLeftToRight();
/* 131:    */     
/* 132:    */ 
/* 133:133 */     if (resizingColumn != null) {
/* 134:134 */       int oldWidth = resizingColumn.getWidth();
/* 135:    */       int newWidth;
/* 136:136 */       int newWidth; if (headerLeftToRight) {
/* 137:137 */         newWidth = mouseX - mouseXOffset;
/* 138:    */       } else {
/* 139:139 */         newWidth = mouseXOffset - mouseX;
/* 140:    */       }
/* 141:141 */       resizingColumn.setWidth(newWidth);
/* 142:    */       
/* 143:    */       Container container;
/* 144:144 */       if ((table.getTableHeader().getParent() == null) || ((container = table.getTableHeader().getParent().getParent()) == null) || (!(container instanceof JScrollPane))) {
/* 145:    */         return;
/* 146:    */       }
/* 147:    */       
/* 148:    */       Container container;
/* 149:    */       
/* 150:150 */       if ((!container.getComponentOrientation().isLeftToRight()) && (!headerLeftToRight))
/* 151:    */       {
/* 152:152 */         if (table != null) {
/* 153:153 */           JViewport viewport = ((JScrollPane)container).getViewport();
/* 154:154 */           int viewportWidth = viewport.getWidth();
/* 155:155 */           int diff = newWidth - oldWidth;
/* 156:156 */           int newHeaderWidth = table.getWidth() + diff;
/* 157:    */           
/* 158:    */ 
/* 159:159 */           Dimension tableSize = table.getSize();
/* 160:160 */           width += diff;
/* 161:161 */           table.setSize(tableSize);
/* 162:    */           
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:167 */           if ((newHeaderWidth >= viewportWidth) && (table.getAutoResizeMode() == 0))
/* 168:    */           {
/* 169:169 */             Point p = viewport.getViewPosition();
/* 170:170 */             x = Math.max(0, Math.min(newHeaderWidth - viewportWidth, x + diff));
/* 171:    */             
/* 172:172 */             viewport.setViewPosition(p);
/* 173:    */             
/* 174:    */ 
/* 175:175 */             mouseXOffset += diff;
/* 176:    */           }
/* 177:    */         }
/* 178:    */       }
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */ 
/* 183:    */   public void mouseReleased(MouseEvent e)
/* 184:    */   {
/* 185:185 */     table.getTableHeader().setResizingColumn(null);
/* 186:186 */     table.getTableHeader().setDraggedColumn(null);
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void mouseEntered(MouseEvent e) {}
/* 190:    */   
/* 191:    */   public void mouseExited(MouseEvent e) {}
/* 192:    */ }
