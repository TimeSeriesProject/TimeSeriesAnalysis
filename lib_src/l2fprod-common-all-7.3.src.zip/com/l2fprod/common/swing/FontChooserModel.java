package com.l2fprod.common.swing;

public abstract interface FontChooserModel
{
  public abstract String[] getFontFamilies(String paramString);
  
  public abstract int[] getDefaultSizes();
  
  public abstract String[] getCharSets();
  
  public abstract String getPreviewMessage(String paramString);
}
