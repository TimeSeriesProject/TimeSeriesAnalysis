/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import java.awt.GraphicsEnvironment;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ import java.util.Arrays;
/*  6:   */ import java.util.List;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public class MonospacedFontChooserModel
/* 30:   */   extends DefaultFontChooserModel
/* 31:   */ {
/* 32:   */   public MonospacedFontChooserModel()
/* 33:   */   {
/* 34:34 */     List monospaces = new ArrayList();
/* 35:35 */     String[] fontFamilies = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
/* 36:   */     
/* 37:37 */     Arrays.sort(fontFamilies);
/* 38:38 */     int i = 0; for (int c = fontFamilies.length; i < c; i++) {
/* 39:39 */       if (isMonospaced(fontFamilies[i])) {
/* 40:40 */         monospaces.add(fontFamilies[i]);
/* 41:   */       }
/* 42:   */     }
/* 43:   */     
/* 44:44 */     setFontFamilies((String[])monospaces.toArray(new String[monospaces.size()]));
/* 45:   */   }
/* 46:   */   
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */   protected boolean isMonospaced(String fontFamily)
/* 53:   */   {
/* 54:54 */     String lower = fontFamily.toLowerCase();
/* 55:55 */     return (lower.indexOf("fixed") >= 0) || (lower.indexOf("monospaced") >= 0) || (lower.indexOf("profont") >= 0) || (lower.indexOf("console") >= 0) || (lower.indexOf("typewriter") >= 0);
/* 56:   */   }
/* 57:   */ }
