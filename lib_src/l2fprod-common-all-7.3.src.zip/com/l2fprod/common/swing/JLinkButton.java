/*  1:   */ package com.l2fprod.common.swing;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.plaf.JLinkButtonAddon;
/*  4:   */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*  5:   */ import javax.swing.Action;
/*  6:   */ import javax.swing.Icon;
/*  7:   */ import javax.swing.JButton;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ public class JLinkButton
/* 48:   */   extends JButton
/* 49:   */ {
/* 50:   */   public static final String UI_CLASS_ID = "LinkButtonUI";
/* 51:   */   
/* 52:   */   static
/* 53:   */   {
/* 54:54 */     LookAndFeelAddons.contribute(new JLinkButtonAddon());
/* 55:   */   }
/* 56:   */   
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */   public JLinkButton(String text)
/* 61:   */   {
/* 62:62 */     super(text);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public JLinkButton(String text, Icon icon) {
/* 66:66 */     super(text, icon);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public JLinkButton(Action a) {
/* 70:70 */     super(a);
/* 71:   */   }
/* 72:   */   
/* 73:   */   public JLinkButton(Icon icon) {
/* 74:74 */     super(icon);
/* 75:   */   }
/* 76:   */   
/* 77:   */ 
/* 78:   */ 
/* 79:   */ 
/* 80:   */ 
/* 81:   */ 
/* 82:   */ 
/* 83:   */   public String getUIClassID()
/* 84:   */   {
/* 85:85 */     return "LinkButtonUI";
/* 86:   */   }
/* 87:   */   
/* 88:   */   public JLinkButton() {}
/* 89:   */ }
