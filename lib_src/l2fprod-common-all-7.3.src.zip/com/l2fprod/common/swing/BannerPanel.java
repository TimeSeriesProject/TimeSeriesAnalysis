/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import javax.swing.Icon;
/*   7:    */ import javax.swing.JEditorPane;
/*   8:    */ import javax.swing.JLabel;
/*   9:    */ import javax.swing.JPanel;
/*  10:    */ import javax.swing.UIManager;
/*  11:    */ import javax.swing.border.CompoundBorder;
/*  12:    */ import javax.swing.border.EtchedBorder;
/*  13:    */ import javax.swing.text.JTextComponent;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ public class BannerPanel
/*  38:    */   extends JPanel
/*  39:    */ {
/*  40:    */   private JLabel titleLabel;
/*  41:    */   private JTextComponent subtitleLabel;
/*  42:    */   private JLabel iconLabel;
/*  43:    */   
/*  44:    */   public BannerPanel()
/*  45:    */   {
/*  46: 46 */     setBorder(new CompoundBorder(new EtchedBorder(), LookAndFeelTweaks.PANEL_BORDER));
/*  47:    */     
/*  48:    */ 
/*  49: 49 */     setOpaque(true);
/*  50: 50 */     setBackground(UIManager.getColor("Table.background"));
/*  51:    */     
/*  52: 52 */     titleLabel = new JLabel();
/*  53: 53 */     titleLabel.setOpaque(false);
/*  54:    */     
/*  55: 55 */     subtitleLabel = new JEditorPane("text/html", "<html>");
/*  56: 56 */     subtitleLabel.setFont(titleLabel.getFont());
/*  57:    */     
/*  58: 58 */     LookAndFeelTweaks.makeBold(titleLabel);
/*  59: 59 */     LookAndFeelTweaks.makeMultilineLabel(subtitleLabel);
/*  60: 60 */     LookAndFeelTweaks.htmlize(subtitleLabel);
/*  61:    */     
/*  62: 62 */     iconLabel = new JLabel();
/*  63: 63 */     iconLabel.setPreferredSize(new Dimension(50, 50));
/*  64:    */     
/*  65: 65 */     setLayout(new BorderLayout());
/*  66:    */     
/*  67: 67 */     JPanel nestedPane = new JPanel(new BorderLayout());
/*  68: 68 */     nestedPane.setOpaque(false);
/*  69: 69 */     nestedPane.add("North", titleLabel);
/*  70: 70 */     nestedPane.add("Center", subtitleLabel);
/*  71: 71 */     add("Center", nestedPane);
/*  72: 72 */     add("East", iconLabel);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setTitleColor(Color color) {
/*  76: 76 */     titleLabel.setForeground(color);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Color getTitleColor() {
/*  80: 80 */     return titleLabel.getForeground();
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setSubtitleColor(Color color) {
/*  84: 84 */     subtitleLabel.setForeground(color);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Color getSubtitleColor() {
/*  88: 88 */     return subtitleLabel.getForeground();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setTitle(String title) {
/*  92: 92 */     titleLabel.setText(title);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public String getTitle() {
/*  96: 96 */     return titleLabel.getText();
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setSubtitle(String subtitle) {
/* 100:100 */     subtitleLabel.setText(subtitle);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getSubtitle() {
/* 104:104 */     return subtitleLabel.getText();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setSubtitleVisible(boolean b) {
/* 108:108 */     subtitleLabel.setVisible(b);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean isSubtitleVisible() {
/* 112:112 */     return subtitleLabel.isVisible();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setIcon(Icon icon) {
/* 116:116 */     iconLabel.setIcon(icon);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public Icon getIcon() {
/* 120:120 */     return iconLabel.getIcon();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void setIconVisible(boolean b) {
/* 124:124 */     iconLabel.setVisible(b);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean isIconVisible() {
/* 128:128 */     return iconLabel.isVisible();
/* 129:    */   }
/* 130:    */ }
