/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.Font;
/*   6:    */ import java.io.StringReader;
/*   7:    */ import javax.swing.BorderFactory;
/*   8:    */ import javax.swing.JComponent;
/*   9:    */ import javax.swing.JEditorPane;
/*  10:    */ import javax.swing.JPanel;
/*  11:    */ import javax.swing.JTextArea;
/*  12:    */ import javax.swing.UIManager;
/*  13:    */ import javax.swing.border.Border;
/*  14:    */ import javax.swing.border.CompoundBorder;
/*  15:    */ import javax.swing.text.JTextComponent;
/*  16:    */ import javax.swing.text.View;
/*  17:    */ import javax.swing.text.html.HTMLDocument;
/*  18:    */ import javax.swing.text.html.StyleSheet;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public class LookAndFeelTweaks
/*  41:    */ {
/*  42: 42 */   public static final Border PANEL_BORDER = BorderFactory.createEmptyBorder(3, 3, 3, 3);
/*  43:    */   
/*  44:    */ 
/*  45: 45 */   public static final Border WINDOW_BORDER = BorderFactory.createEmptyBorder(4, 10, 10, 10);
/*  46:    */   
/*  47:    */ 
/*  48: 48 */   public static final Border EMPTY_BORDER = BorderFactory.createEmptyBorder();
/*  49:    */   
/*  50:    */   public static void tweak()
/*  51:    */   {
/*  52: 52 */     Object listFont = UIManager.get("List.font");
/*  53: 53 */     UIManager.put("Table.font", listFont);
/*  54: 54 */     UIManager.put("ToolTip.font", listFont);
/*  55: 55 */     UIManager.put("TextField.font", listFont);
/*  56: 56 */     UIManager.put("FormattedTextField.font", listFont);
/*  57: 57 */     UIManager.put("Viewport.background", "Table.background");
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static PercentLayout createVerticalPercentLayout() {
/*  61: 61 */     return new PercentLayout(1, 8);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static PercentLayout createHorizontalPercentLayout() {
/*  65: 65 */     return new PercentLayout(0, 8);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static ButtonAreaLayout createButtonAreaLayout() {
/*  69: 69 */     return new ButtonAreaLayout(6);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static BorderLayout createBorderLayout() {
/*  73: 73 */     return new BorderLayout(8, 8);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static void setBorder(JComponent component) {
/*  77: 77 */     if ((component instanceof JPanel)) {
/*  78: 78 */       component.setBorder(PANEL_BORDER);
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static void setBorderLayout(Container container) {
/*  83: 83 */     container.setLayout(new BorderLayout(3, 3));
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static void makeBold(JComponent component) {
/*  87: 87 */     component.setFont(component.getFont().deriveFont(1));
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static void makeMultilineLabel(JTextComponent area) {
/*  91: 91 */     area.setFont(UIManager.getFont("Label.font"));
/*  92: 92 */     area.setEditable(false);
/*  93: 93 */     area.setOpaque(false);
/*  94: 94 */     if ((area instanceof JTextArea)) {
/*  95: 95 */       ((JTextArea)area).setWrapStyleWord(true);
/*  96: 96 */       ((JTextArea)area).setLineWrap(true);
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static void htmlize(JComponent component) {
/* 101:101 */     htmlize(component, UIManager.getFont("Button.font"));
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static void htmlize(JComponent component, Font font) {
/* 105:105 */     String stylesheet = "body { margin-top: 0; margin-bottom: 0; margin-left: 0; margin-right: 0; font-family: " + font.getName() + "; font-size: " + font.getSize() + "pt;\t}" + "a, p, li { margin-top: 0; margin-bottom: 0; margin-left: 0; margin-right: 0; font-family: " + font.getName() + "; font-size: " + font.getSize() + "pt;\t}";
/* 106:    */     
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */     try
/* 117:    */     {
/* 118:118 */       HTMLDocument doc = null;
/* 119:119 */       if ((component instanceof JEditorPane)) {
/* 120:120 */         if ((((JEditorPane)component).getDocument() instanceof HTMLDocument)) {
/* 121:121 */           doc = (HTMLDocument)((JEditorPane)component).getDocument();
/* 122:    */         }
/* 123:    */       } else {
/* 124:124 */         View v = (View)component.getClientProperty("html");
/* 125:    */         
/* 126:    */ 
/* 127:127 */         if ((v != null) && ((v.getDocument() instanceof HTMLDocument))) {
/* 128:128 */           doc = (HTMLDocument)v.getDocument();
/* 129:    */         }
/* 130:    */       }
/* 131:131 */       if (doc != null) {
/* 132:132 */         doc.getStyleSheet().loadRules(new StringReader(stylesheet), null);
/* 133:    */       }
/* 134:    */     }
/* 135:    */     catch (Exception e)
/* 136:    */     {
/* 137:137 */       e.printStackTrace();
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static Border addMargin(Border border) {
/* 142:142 */     return new CompoundBorder(border, PANEL_BORDER);
/* 143:    */   }
/* 144:    */ }
