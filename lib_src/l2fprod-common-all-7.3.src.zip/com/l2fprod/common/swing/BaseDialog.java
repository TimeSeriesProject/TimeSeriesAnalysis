/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.util.ResourceManager;
/*   4:    */ import java.awt.BorderLayout;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Dialog;
/*   8:    */ import java.awt.Frame;
/*   9:    */ import java.awt.GraphicsConfiguration;
/*  10:    */ import java.awt.HeadlessException;
/*  11:    */ import java.awt.Window;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.event.WindowAdapter;
/*  14:    */ import java.awt.event.WindowEvent;
/*  15:    */ import javax.swing.AbstractAction;
/*  16:    */ import javax.swing.Action;
/*  17:    */ import javax.swing.JButton;
/*  18:    */ import javax.swing.JComponent;
/*  19:    */ import javax.swing.JDialog;
/*  20:    */ import javax.swing.JPanel;
/*  21:    */ import javax.swing.JRootPane;
/*  22:    */ import javax.swing.KeyStroke;
/*  23:    */ import javax.swing.SwingUtilities;
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ public class BaseDialog
/*  70:    */   extends JDialog
/*  71:    */ {
/*  72:    */   public static final int OK_CANCEL_DIALOG = 0;
/*  73:    */   public static final int CLOSE_DIALOG = 1;
/*  74:    */   private BannerPanel banner;
/*  75:    */   private JPanel contentPane;
/*  76:    */   private JPanel buttonPane;
/*  77:    */   private boolean cancelClicked;
/*  78:    */   private JButton okButton;
/*  79:    */   private JButton cancelOrCloseButton;
/*  80:    */   private int mode;
/*  81: 81 */   private Action okAction = new AbstractAction() {
/*  82:    */     public void actionPerformed(ActionEvent e) {
/*  83: 83 */       ok();
/*  84:    */     }
/*  85:    */   };
/*  86:    */   
/*  87: 87 */   private Action cancelOrCloseAction = new AbstractAction() {
/*  88:    */     public void actionPerformed(ActionEvent e) {
/*  89: 89 */       cancel();
/*  90:    */     }
/*  91:    */   };
/*  92:    */   
/*  93:    */   public BaseDialog() throws HeadlessException
/*  94:    */   {
/*  95: 95 */     buildUI();
/*  96:    */   }
/*  97:    */   
/*  98:    */   public BaseDialog(Dialog owner) throws HeadlessException {
/*  99: 99 */     super(owner);
/* 100:100 */     buildUI();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static BaseDialog newBaseDialog(Component parent) {
/* 104:104 */     Window window = (parent instanceof Window) ? (Window)parent : (Window)SwingUtilities.getAncestorOfClass(Window.class, parent);
/* 105:    */     
/* 106:    */ 
/* 107:107 */     if ((window instanceof Frame))
/* 108:108 */       return new BaseDialog((Frame)window);
/* 109:109 */     if ((window instanceof Dialog)) {
/* 110:110 */       return new BaseDialog((Dialog)window);
/* 111:    */     }
/* 112:112 */     return new BaseDialog();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public BaseDialog(Dialog owner, boolean modal) throws HeadlessException
/* 116:    */   {
/* 117:117 */     super(owner, modal);
/* 118:118 */     buildUI();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public BaseDialog(Frame owner) throws HeadlessException {
/* 122:122 */     super(owner);
/* 123:123 */     buildUI();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public BaseDialog(Frame owner, boolean modal) throws HeadlessException {
/* 127:127 */     super(owner, modal);
/* 128:128 */     buildUI();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public BaseDialog(Dialog owner, String title) throws HeadlessException {
/* 132:132 */     super(owner, title);
/* 133:133 */     buildUI();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public BaseDialog(Dialog owner, String title, boolean modal) throws HeadlessException
/* 137:    */   {
/* 138:138 */     super(owner, title, modal);
/* 139:139 */     buildUI();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public BaseDialog(Frame owner, String title) throws HeadlessException {
/* 143:143 */     super(owner, title);
/* 144:144 */     buildUI();
/* 145:    */   }
/* 146:    */   
/* 147:    */   public BaseDialog(Frame owner, String title, boolean modal) throws HeadlessException
/* 148:    */   {
/* 149:149 */     super(owner, title, modal);
/* 150:150 */     buildUI();
/* 151:    */   }
/* 152:    */   
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */   public BaseDialog(Dialog owner, String title, boolean modal, GraphicsConfiguration gc)
/* 157:    */     throws HeadlessException
/* 158:    */   {
/* 159:159 */     super(owner, title, modal, gc);
/* 160:160 */     buildUI();
/* 161:    */   }
/* 162:    */   
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */   public BaseDialog(Frame owner, String title, boolean modal, GraphicsConfiguration gc)
/* 167:    */   {
/* 168:168 */     super(owner, title, modal, gc);
/* 169:169 */     buildUI();
/* 170:    */   }
/* 171:    */   
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */   public final BannerPanel getBanner()
/* 179:    */   {
/* 180:180 */     return banner;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public final Container getContentPane() {
/* 184:184 */     return contentPane;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public final Container getButtonPane() {
/* 188:188 */     return buttonPane;
/* 189:    */   }
/* 190:    */   
/* 191:    */ 
/* 192:    */ 
/* 193:    */   public boolean ask()
/* 194:    */   {
/* 195:195 */     setVisible(true);
/* 196:196 */     dispose();
/* 197:197 */     return !cancelClicked;
/* 198:    */   }
/* 199:    */   
/* 200:    */ 
/* 201:    */ 
/* 202:    */   public void ok()
/* 203:    */   {
/* 204:204 */     cancelClicked = false;
/* 205:205 */     setVisible(false);
/* 206:    */   }
/* 207:    */   
/* 208:    */ 
/* 209:    */ 
/* 210:    */   public void cancel()
/* 211:    */   {
/* 212:212 */     cancelClicked = true;
/* 213:213 */     setVisible(false);
/* 214:    */   }
/* 215:    */   
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */   public void setDialogMode(int mode)
/* 223:    */   {
/* 224:224 */     if ((mode != 0) && (mode != 1)) {
/* 225:225 */       throw new IllegalArgumentException("invalid dialog mode");
/* 226:    */     }
/* 227:    */     
/* 228:228 */     if (okButton != null) {
/* 229:229 */       buttonPane.remove(okButton);
/* 230:230 */       okButton = null;
/* 231:    */     }
/* 232:232 */     if (cancelOrCloseButton != null) {
/* 233:233 */       buttonPane.remove(cancelOrCloseButton);
/* 234:234 */       cancelOrCloseButton = null;
/* 235:    */     }
/* 236:    */     
/* 237:237 */     switch (mode) {
/* 238:    */     case 0: 
/* 239:239 */       okButton = new JButton(ResourceManager.all(BaseDialog.class).getString("ok"));
/* 240:    */       
/* 241:241 */       okButton.addActionListener(okAction);
/* 242:242 */       buttonPane.add(okButton);
/* 243:243 */       cancelOrCloseButton = new JButton(ResourceManager.all(BaseDialog.class).getString("cancel"));
/* 244:    */       
/* 245:    */ 
/* 246:246 */       cancelOrCloseButton.addActionListener(cancelOrCloseAction);
/* 247:247 */       buttonPane.add(cancelOrCloseButton);
/* 248:248 */       getRootPane().setDefaultButton(okButton);
/* 249:249 */       break;
/* 250:    */     case 1: 
/* 251:251 */       cancelOrCloseButton = new JButton(ResourceManager.all(BaseDialog.class).getString("close"));
/* 252:    */       
/* 253:253 */       cancelOrCloseButton.addActionListener(cancelOrCloseAction);
/* 254:254 */       buttonPane.add(cancelOrCloseButton);
/* 255:    */     }
/* 256:    */     
/* 257:    */     
/* 258:258 */     this.mode = mode;
/* 259:    */   }
/* 260:    */   
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */   public int getDialogMode()
/* 266:    */   {
/* 267:267 */     return mode;
/* 268:    */   }
/* 269:    */   
/* 270:    */ 
/* 271:    */ 
/* 272:    */   public void centerOnScreen()
/* 273:    */   {
/* 274:274 */     UIUtilities.centerOnScreen(this);
/* 275:    */   }
/* 276:    */   
/* 277:    */   protected String paramString() {
/* 278:278 */     return super.paramString() + ",dialogMode=" + (mode == 0 ? "OK_CANCEL_DIALOG" : "CLOSE_DIALOG");
/* 279:    */   }
/* 280:    */   
/* 281:    */ 
/* 282:    */   private void buildUI()
/* 283:    */   {
/* 284:284 */     Container container = super.getContentPane();
/* 285:285 */     container.setLayout(new BorderLayout(0, 0));
/* 286:    */     
/* 287:287 */     banner = new BannerPanel();
/* 288:288 */     container.add("North", banner);
/* 289:    */     
/* 290:290 */     JPanel contentPaneAndButtons = new JPanel();
/* 291:291 */     contentPaneAndButtons.setLayout(LookAndFeelTweaks.createVerticalPercentLayout());
/* 292:    */     
/* 293:293 */     contentPaneAndButtons.setBorder(LookAndFeelTweaks.WINDOW_BORDER);
/* 294:294 */     container.add("Center", contentPaneAndButtons);
/* 295:    */     
/* 296:296 */     contentPane = new JPanel();
/* 297:297 */     LookAndFeelTweaks.setBorderLayout(contentPane);
/* 298:298 */     LookAndFeelTweaks.setBorder(contentPane);
/* 299:299 */     contentPaneAndButtons.add(contentPane, "*");
/* 300:    */     
/* 301:301 */     buttonPane = new JPanel();
/* 302:302 */     buttonPane.setLayout(LookAndFeelTweaks.createButtonAreaLayout());
/* 303:303 */     LookAndFeelTweaks.setBorder(buttonPane);
/* 304:304 */     contentPaneAndButtons.add(buttonPane);
/* 305:    */     
/* 306:    */ 
/* 307:    */ 
/* 308:308 */     setDefaultCloseOperation(0);
/* 309:    */     
/* 310:310 */     ((JComponent)container).registerKeyboardAction(cancelOrCloseAction, KeyStroke.getKeyStroke(27, 0), 2);
/* 311:    */     
/* 312:    */ 
/* 313:    */ 
/* 314:    */ 
/* 315:315 */     addWindowListener(new WindowAdapter() {
/* 316:    */       public void windowClosing(WindowEvent e) {
/* 317:317 */         cancel();
/* 318:    */       }
/* 319:    */       
/* 320:    */ 
/* 321:321 */     });
/* 322:322 */     setDialogMode(0);
/* 323:    */   }
/* 324:    */ }
