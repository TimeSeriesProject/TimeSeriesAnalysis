/*   1:    */ package com.l2fprod.common.swing;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Image;
/*   5:    */ import java.beans.BeanDescriptor;
/*   6:    */ import java.beans.BeanInfo;
/*   7:    */ import java.beans.IntrospectionException;
/*   8:    */ import java.beans.Introspector;
/*   9:    */ import java.beans.PropertyDescriptor;
/*  10:    */ import java.beans.SimpleBeanInfo;
/*  11:    */ import java.util.Vector;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ public class JTaskPaneGroupBeanInfo
/*  19:    */   extends SimpleBeanInfo
/*  20:    */ {
/*  21: 21 */   protected BeanDescriptor bd = new BeanDescriptor(JTaskPaneGroup.class);
/*  22:    */   
/*  23:    */ 
/*  24: 24 */   protected Image iconMono16 = loadImage("JTaskPaneGroup16-mono.gif");
/*  25:    */   
/*  26: 26 */   protected Image iconColor16 = loadImage("JTaskPaneGroup16.gif");
/*  27:    */   
/*  28: 28 */   protected Image iconMono32 = loadImage("JTaskPaneGroup32-mono.gif");
/*  29:    */   
/*  30: 30 */   protected Image iconColor32 = loadImage("JTaskPaneGroup32.gif");
/*  31:    */   
/*  32:    */   public JTaskPaneGroupBeanInfo()
/*  33:    */     throws IntrospectionException
/*  34:    */   {
/*  35: 35 */     bd.setName("JTaskPaneGroup");
/*  36:    */     
/*  37: 37 */     bd.setShortDescription("JTaskPaneGroup is a container for tasks and other arbitrary components.");
/*  38:    */     
/*  39:    */ 
/*  40: 40 */     bd.setValue("isContainer", Boolean.TRUE);
/*  41: 41 */     bd.setValue("containerDelegate", "getContentPane");
/*  42:    */     
/*  43: 43 */     BeanInfo info = Introspector.getBeanInfo(getBeanDescriptor().getBeanClass().getSuperclass());
/*  44:    */     
/*  45: 45 */     String order = info.getBeanDescriptor().getValue("propertyorder") == null ? "" : (String)info.getBeanDescriptor().getValue("propertyorder");
/*  46:    */     
/*  47: 47 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  48: 48 */     for (int i = 0; i != pd.length; i++) {
/*  49: 49 */       if (order.indexOf(pd[i].getName()) == -1) {
/*  50: 50 */         order = order + (order.length() == 0 ? "" : ":") + pd[i].getName();
/*  51:    */       }
/*  52:    */     }
/*  53: 53 */     getBeanDescriptor().setValue("propertyorder", order);
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */   public BeanInfo[] getAdditionalBeanInfo()
/*  61:    */   {
/*  62: 62 */     Vector bi = new Vector();
/*  63: 63 */     BeanInfo[] biarr = null;
/*  64:    */     try {
/*  65: 65 */       for (Class cl = JTaskPaneGroup.class.getSuperclass(); 
/*  66: 66 */           !cl.equals(Component.class.getSuperclass()); cl = cl.getSuperclass())
/*  67:    */       {
/*  68: 68 */         bi.addElement(Introspector.getBeanInfo(cl));
/*  69:    */       }
/*  70: 70 */       biarr = new BeanInfo[bi.size()];
/*  71: 71 */       bi.copyInto(biarr);
/*  72:    */     }
/*  73:    */     catch (Exception e) {}
/*  74:    */     
/*  75: 75 */     return biarr;
/*  76:    */   }
/*  77:    */   
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */   public BeanDescriptor getBeanDescriptor()
/*  83:    */   {
/*  84: 84 */     return bd;
/*  85:    */   }
/*  86:    */   
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */   public int getDefaultPropertyIndex()
/*  92:    */   {
/*  93: 93 */     String defName = "";
/*  94: 94 */     if (defName.equals("")) return -1;
/*  95: 95 */     PropertyDescriptor[] pd = getPropertyDescriptors();
/*  96: 96 */     for (int i = 0; i < pd.length; i++) {
/*  97: 97 */       if (pd[i].getName().equals(defName)) return i;
/*  98:    */     }
/*  99: 99 */     return -1;
/* 100:    */   }
/* 101:    */   
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */   public Image getIcon(int type)
/* 109:    */   {
/* 110:110 */     if (type == 1) return iconColor16;
/* 111:111 */     if (type == 3) return iconMono16;
/* 112:112 */     if (type == 2) return iconColor32;
/* 113:113 */     if (type == 4) return iconMono32;
/* 114:114 */     return null;
/* 115:    */   }
/* 116:    */   
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */   public PropertyDescriptor[] getPropertyDescriptors()
/* 121:    */   {
/* 122:    */     try
/* 123:    */     {
/* 124:124 */       Vector descriptors = new Vector();
/* 125:125 */       PropertyDescriptor descriptor = null;
/* 126:    */       try
/* 127:    */       {
/* 128:128 */         descriptor = new PropertyDescriptor("title", JTaskPaneGroup.class);
/* 129:    */       }
/* 130:    */       catch (IntrospectionException e) {
/* 131:131 */         descriptor = new PropertyDescriptor("title", JTaskPaneGroup.class, "getTitle", null);
/* 132:    */       }
/* 133:    */       
/* 134:    */ 
/* 135:135 */       descriptor.setPreferred(true);
/* 136:    */       
/* 137:137 */       descriptor.setBound(true);
/* 138:    */       
/* 139:139 */       descriptors.add(descriptor);
/* 140:    */       try {
/* 141:141 */         descriptor = new PropertyDescriptor("icon", JTaskPaneGroup.class);
/* 142:    */       }
/* 143:    */       catch (IntrospectionException e) {
/* 144:144 */         descriptor = new PropertyDescriptor("icon", JTaskPaneGroup.class, "getIcon", null);
/* 145:    */       }
/* 146:    */       
/* 147:    */ 
/* 148:148 */       descriptor.setPreferred(true);
/* 149:    */       
/* 150:150 */       descriptor.setBound(true);
/* 151:    */       
/* 152:152 */       descriptors.add(descriptor);
/* 153:    */       try {
/* 154:154 */         descriptor = new PropertyDescriptor("special", JTaskPaneGroup.class);
/* 155:    */       }
/* 156:    */       catch (IntrospectionException e) {
/* 157:157 */         descriptor = new PropertyDescriptor("special", JTaskPaneGroup.class, "getSpecial", null);
/* 158:    */       }
/* 159:    */       
/* 160:    */ 
/* 161:161 */       descriptor.setPreferred(true);
/* 162:    */       
/* 163:163 */       descriptor.setBound(true);
/* 164:    */       
/* 165:165 */       descriptors.add(descriptor);
/* 166:    */       try {
/* 167:167 */         descriptor = new PropertyDescriptor("scrollOnExpand", JTaskPaneGroup.class);
/* 168:    */       }
/* 169:    */       catch (IntrospectionException e) {
/* 170:170 */         descriptor = new PropertyDescriptor("scrollOnExpand", JTaskPaneGroup.class, "getScrollOnExpand", null);
/* 171:    */       }
/* 172:    */       
/* 173:    */ 
/* 174:    */ 
/* 175:175 */       descriptor.setPreferred(true);
/* 176:    */       
/* 177:177 */       descriptor.setBound(true);
/* 178:    */       
/* 179:179 */       descriptors.add(descriptor);
/* 180:    */       try {
/* 181:181 */         descriptor = new PropertyDescriptor("expanded", JTaskPaneGroup.class);
/* 182:    */       }
/* 183:    */       catch (IntrospectionException e) {
/* 184:184 */         descriptor = new PropertyDescriptor("expanded", JTaskPaneGroup.class, "getExpanded", null);
/* 185:    */       }
/* 186:    */       
/* 187:    */ 
/* 188:188 */       descriptor.setPreferred(true);
/* 189:    */       
/* 190:190 */       descriptor.setBound(true);
/* 191:    */       
/* 192:192 */       descriptors.add(descriptor);
/* 193:    */       try {
/* 194:194 */         descriptor = new PropertyDescriptor("collapsable", JTaskPaneGroup.class);
/* 195:    */       }
/* 196:    */       catch (IntrospectionException e) {
/* 197:197 */         descriptor = new PropertyDescriptor("collapsable", JTaskPaneGroup.class, "getCollapsable", null);
/* 198:    */       }
/* 199:    */       
/* 200:    */ 
/* 201:201 */       descriptor.setPreferred(true);
/* 202:    */       
/* 203:203 */       descriptor.setBound(true);
/* 204:    */       
/* 205:205 */       descriptors.add(descriptor);
/* 206:    */       try {
/* 207:207 */         descriptor = new PropertyDescriptor("animated", JTaskPaneGroup.class);
/* 208:    */       }
/* 209:    */       catch (IntrospectionException e) {
/* 210:210 */         descriptor = new PropertyDescriptor("animated", JTaskPaneGroup.class, "getAnimated", null);
/* 211:    */       }
/* 212:    */       
/* 213:    */ 
/* 214:214 */       descriptor.setPreferred(true);
/* 215:    */       
/* 216:216 */       descriptor.setBound(true);
/* 217:    */       
/* 218:218 */       descriptors.add(descriptor);
/* 219:    */       
/* 220:220 */       return (PropertyDescriptor[])descriptors.toArray(new PropertyDescriptor[descriptors.size()]);
/* 221:    */ 
/* 222:    */ 
/* 223:    */     }
/* 224:    */     catch (Exception e)
/* 225:    */     {
/* 226:    */ 
/* 227:227 */       e.printStackTrace();
/* 228:    */     }
/* 229:229 */     return null;
/* 230:    */   }
/* 231:    */ }
