package com.l2fprod.common.model;

public abstract interface ObjectRenderer
{
  public abstract String getText(Object paramObject);
}
