/*  1:   */ package com.l2fprod.common.model;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.beans.BeanInfoResolver;
/*  4:   */ import java.beans.BeanInfo;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ public class DefaultBeanInfoResolver
/* 61:   */   implements BeanInfoResolver
/* 62:   */ {
/* 63:   */   public BeanInfo getBeanInfo(Object object)
/* 64:   */   {
/* 65:65 */     if (object == null) {
/* 66:66 */       return null;
/* 67:   */     }
/* 68:   */     
/* 69:69 */     return getBeanInfo(object.getClass());
/* 70:   */   }
/* 71:   */   
/* 72:   */   public BeanInfo getBeanInfo(Class clazz) {
/* 73:73 */     if (clazz == null) {
/* 74:74 */       return null;
/* 75:   */     }
/* 76:   */     
/* 77:77 */     String classname = clazz.getName();
/* 78:   */     
/* 79:   */ 
/* 80:80 */     int index = classname.indexOf(".impl.basic");
/* 81:81 */     if ((index != -1) && (classname.endsWith("Basic"))) {
/* 82:82 */       classname = classname.substring(0, index) + classname.substring(index + ".impl.basic".length(), classname.lastIndexOf("Basic"));
/* 83:   */       
/* 84:   */ 
/* 85:   */ 
/* 86:   */       try
/* 87:   */       {
/* 88:88 */         return getBeanInfo(Class.forName(classname));
/* 89:   */       } catch (ClassNotFoundException e) {
/* 90:90 */         return null;
/* 91:   */       }
/* 92:   */     }
/* 93:   */     try {
/* 94:94 */       return (BeanInfo)Class.forName(classname + "BeanInfo").newInstance();
/* 95:   */     }
/* 96:   */     catch (Exception e) {}
/* 97:   */     
/* 98:98 */     return null;
/* 99:   */   }
/* :0:   */ }
