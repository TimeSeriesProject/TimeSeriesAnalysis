package com.l2fprod.common.model;

public abstract interface TitledObject
{
  public abstract String getTitle();
  
  public abstract void setTitle(String paramString);
}
