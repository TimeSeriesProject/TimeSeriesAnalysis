/*  1:   */ package com.l2fprod.common.model;
/*  2:   */ 
/*  3:   */ import java.util.Observable;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ public class BaseObject
/* 54:   */   extends Observable
/* 55:   */   implements HasId
/* 56:   */ {
/* 57:   */   private Object id;
/* 58:   */   
/* 59:   */   public void setId(Object id)
/* 60:   */   {
/* 61:61 */     this.id = id;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public Object getId() {
/* 65:65 */     return id;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public String toString() {
/* 69:69 */     return super.toString() + "[" + paramString() + "]";
/* 70:   */   }
/* 71:   */   
/* 72:   */   protected String paramString()
/* 73:   */   {
/* 74:74 */     return "id=" + getId();
/* 75:   */   }
/* 76:   */ }
