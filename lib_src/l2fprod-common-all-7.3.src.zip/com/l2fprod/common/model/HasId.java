package com.l2fprod.common.model;

public abstract interface HasId
{
  public abstract void setId(Object paramObject);
  
  public abstract Object getId();
}
