/*  1:   */ package com.l2fprod.common.model;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.util.ResourceManager;
/*  4:   */ import com.l2fprod.common.util.converter.ConverterRegistry;
/*  5:   */ import java.io.File;
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ public class DefaultObjectRenderer
/* 49:   */   implements ObjectRenderer
/* 50:   */ {
/* 51:51 */   private boolean idVisible = false;
/* 52:   */   
/* 53:   */   public void setIdVisible(boolean b) {
/* 54:54 */     idVisible = b;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public String getText(Object object) {
/* 58:58 */     if (object == null) {
/* 59:59 */       return null;
/* 60:   */     }
/* 61:   */     
/* 62:   */     try
/* 63:   */     {
/* 64:64 */       return (String)ConverterRegistry.instance().convert(String.class, object);
/* 65:   */     }
/* 66:   */     catch (IllegalArgumentException e)
/* 67:   */     {
/* 68:68 */       if ((object instanceof Boolean)) {
/* 69:69 */         return Boolean.TRUE.equals(object) ? ResourceManager.common().getString("true") : ResourceManager.common().getString("false");
/* 70:   */       }
/* 71:   */       
/* 72:   */ 
/* 73:   */ 
/* 74:74 */       if ((object instanceof File)) {
/* 75:75 */         return ((File)object).getAbsolutePath();
/* 76:   */       }
/* 77:   */       
/* 78:78 */       StringBuffer buffer = new StringBuffer();
/* 79:79 */       if ((idVisible) && ((object instanceof HasId))) {
/* 80:80 */         buffer.append(((HasId)object).getId());
/* 81:   */       }
/* 82:82 */       if ((object instanceof TitledObject)) {
/* 83:83 */         buffer.append(((TitledObject)object).getTitle());
/* 84:   */       }
/* 85:85 */       if ((!(object instanceof HasId)) && (!(object instanceof TitledObject))) {
/* 86:86 */         buffer.append(String.valueOf(object));
/* 87:   */       }
/* 88:88 */       return buffer.toString();
/* 89:   */     }
/* 90:   */   }
/* 91:   */ }
