package com.l2fprod.common.model;

public abstract interface Openable
{
  public abstract void open();
}
