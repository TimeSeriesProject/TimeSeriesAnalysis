/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.ObjectTableModel;
/*   4:    */ import java.beans.PropertyChangeEvent;
/*   5:    */ import java.beans.PropertyChangeListener;
/*   6:    */ import java.beans.PropertyChangeSupport;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import javax.swing.table.AbstractTableModel;
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public class PropertySheetTableModel
/*  41:    */   extends AbstractTableModel
/*  42:    */   implements PropertyChangeListener, PropertySheet, ObjectTableModel
/*  43:    */ {
/*  44:    */   public static final int NAME_COLUMN = 0;
/*  45:    */   public static final int VALUE_COLUMN = 1;
/*  46:    */   public static final int NUM_COLUMNS = 2;
/*  47: 47 */   private PropertyChangeSupport listeners = new PropertyChangeSupport(this);
/*  48:    */   private List model;
/*  49:    */   private List publishedModel;
/*  50:    */   private List properties;
/*  51:    */   private int mode;
/*  52:    */   private boolean sortingCategories;
/*  53:    */   private boolean sortingProperties;
/*  54:    */   private boolean restoreToggleStates;
/*  55:    */   private Comparator categorySortingComparator;
/*  56:    */   private Comparator propertySortingComparator;
/*  57:    */   private Map toggleStates;
/*  58:    */   
/*  59:    */   public PropertySheetTableModel() {
/*  60: 60 */     model = new ArrayList();
/*  61: 61 */     publishedModel = new ArrayList();
/*  62: 62 */     properties = new ArrayList();
/*  63: 63 */     mode = 0;
/*  64: 64 */     sortingCategories = false;
/*  65: 65 */     sortingProperties = false;
/*  66: 66 */     restoreToggleStates = false;
/*  67: 67 */     toggleStates = new HashMap();
/*  68:    */   }
/*  69:    */   
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */   public void setProperties(Property[] newProperties)
/*  74:    */   {
/*  75: 75 */     for (Iterator iter = properties.iterator(); iter.hasNext();) {
/*  76: 76 */       Property prop = (Property)iter.next();
/*  77: 77 */       prop.removePropertyChangeListener(this);
/*  78:    */     }
/*  79:    */     
/*  80:    */ 
/*  81: 81 */     properties.clear();
/*  82: 82 */     properties.addAll(Arrays.asList(newProperties));
/*  83:    */     
/*  84:    */ 
/*  85: 85 */     for (Iterator iter = properties.iterator(); iter.hasNext();) {
/*  86: 86 */       Property prop = (Property)iter.next();
/*  87: 87 */       prop.addPropertyChangeListener(this);
/*  88:    */     }
/*  89:    */     
/*  90: 90 */     buildModel();
/*  91:    */   }
/*  92:    */   
/*  93:    */ 
/*  94:    */ 
/*  95:    */   public Property[] getProperties()
/*  96:    */   {
/*  97: 97 */     return (Property[])properties.toArray(new Property[properties.size()]);
/*  98:    */   }
/*  99:    */   
/* 100:    */ 
/* 101:    */ 
/* 102:    */   public void addProperty(Property property)
/* 103:    */   {
/* 104:104 */     properties.add(property);
/* 105:105 */     property.addPropertyChangeListener(this);
/* 106:106 */     buildModel();
/* 107:    */   }
/* 108:    */   
/* 109:    */ 
/* 110:    */ 
/* 111:    */   public void addProperty(int index, Property property)
/* 112:    */   {
/* 113:113 */     properties.add(index, property);
/* 114:114 */     property.addPropertyChangeListener(this);
/* 115:115 */     buildModel();
/* 116:    */   }
/* 117:    */   
/* 118:    */ 
/* 119:    */ 
/* 120:    */   public void removeProperty(Property property)
/* 121:    */   {
/* 122:122 */     properties.remove(property);
/* 123:123 */     property.removePropertyChangeListener(this);
/* 124:124 */     buildModel();
/* 125:    */   }
/* 126:    */   
/* 127:    */ 
/* 128:    */ 
/* 129:    */   public int getPropertyCount()
/* 130:    */   {
/* 131:131 */     return properties.size();
/* 132:    */   }
/* 133:    */   
/* 134:    */ 
/* 135:    */ 
/* 136:    */   public Iterator propertyIterator()
/* 137:    */   {
/* 138:138 */     return properties.iterator();
/* 139:    */   }
/* 140:    */   
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */   public void setMode(int mode)
/* 145:    */   {
/* 146:146 */     if (this.mode == mode) {
/* 147:147 */       return;
/* 148:    */     }
/* 149:149 */     this.mode = mode;
/* 150:150 */     buildModel();
/* 151:    */   }
/* 152:    */   
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */   public int getMode()
/* 157:    */   {
/* 158:158 */     return mode;
/* 159:    */   }
/* 160:    */   
/* 161:    */ 
/* 162:    */ 
/* 163:    */   public Class getColumnClass(int columnIndex)
/* 164:    */   {
/* 165:165 */     return super.getColumnClass(columnIndex);
/* 166:    */   }
/* 167:    */   
/* 168:    */ 
/* 169:    */ 
/* 170:    */   public int getColumnCount()
/* 171:    */   {
/* 172:172 */     return 2;
/* 173:    */   }
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */   public int getRowCount()
/* 178:    */   {
/* 179:179 */     return publishedModel.size();
/* 180:    */   }
/* 181:    */   
/* 182:    */ 
/* 183:    */ 
/* 184:    */   public Object getObject(int rowIndex)
/* 185:    */   {
/* 186:186 */     return getPropertySheetElement(rowIndex);
/* 187:    */   }
/* 188:    */   
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */   public Item getPropertySheetElement(int rowIndex)
/* 193:    */   {
/* 194:194 */     return (Item)publishedModel.get(rowIndex);
/* 195:    */   }
/* 196:    */   
/* 197:    */ 
/* 198:    */ 
/* 199:    */   public boolean isSortingCategories()
/* 200:    */   {
/* 201:201 */     return sortingCategories;
/* 202:    */   }
/* 203:    */   
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */   public void setSortingCategories(boolean value)
/* 208:    */   {
/* 209:209 */     boolean old = sortingCategories;
/* 210:210 */     sortingCategories = value;
/* 211:211 */     if (sortingCategories != old) {
/* 212:212 */       buildModel();
/* 213:    */     }
/* 214:    */   }
/* 215:    */   
/* 216:    */ 
/* 217:    */   public boolean isSortingProperties()
/* 218:    */   {
/* 219:219 */     return sortingProperties;
/* 220:    */   }
/* 221:    */   
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */   public void setSortingProperties(boolean value)
/* 226:    */   {
/* 227:227 */     boolean old = sortingProperties;
/* 228:228 */     sortingProperties = value;
/* 229:229 */     if (sortingProperties != old) {
/* 230:230 */       buildModel();
/* 231:    */     }
/* 232:    */   }
/* 233:    */   
/* 234:    */ 
/* 235:    */ 
/* 236:    */   public void setCategorySortingComparator(Comparator comp)
/* 237:    */   {
/* 238:238 */     Comparator old = categorySortingComparator;
/* 239:239 */     categorySortingComparator = comp;
/* 240:240 */     if (categorySortingComparator != old) {
/* 241:241 */       buildModel();
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */ 
/* 246:    */ 
/* 247:    */   public void setPropertySortingComparator(Comparator comp)
/* 248:    */   {
/* 249:249 */     Comparator old = propertySortingComparator;
/* 250:250 */     propertySortingComparator = comp;
/* 251:251 */     if (propertySortingComparator != old) {
/* 252:252 */       buildModel();
/* 253:    */     }
/* 254:    */   }
/* 255:    */   
/* 256:    */ 
/* 257:    */ 
/* 258:    */   public void setRestoreToggleStates(boolean value)
/* 259:    */   {
/* 260:260 */     restoreToggleStates = value;
/* 261:261 */     if (!restoreToggleStates) {
/* 262:262 */       toggleStates.clear();
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */ 
/* 267:    */ 
/* 268:    */   public boolean isRestoreToggleStates()
/* 269:    */   {
/* 270:270 */     return restoreToggleStates;
/* 271:    */   }
/* 272:    */   
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */   public Map getToggleStates()
/* 277:    */   {
/* 278:278 */     visibilityChanged(restoreToggleStates);
/* 279:279 */     return toggleStates;
/* 280:    */   }
/* 281:    */   
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */   public void setToggleStates(Map toggleStates)
/* 289:    */   {
/* 290:290 */     setRestoreToggleStates(true);
/* 291:291 */     this.toggleStates.clear();
/* 292:292 */     this.toggleStates.putAll(toggleStates);
/* 293:    */   }
/* 294:    */   
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */   public Object getValueAt(int rowIndex, int columnIndex)
/* 304:    */   {
/* 305:305 */     Object result = null;
/* 306:306 */     Item item = getPropertySheetElement(rowIndex);
/* 307:    */     
/* 308:308 */     if (item.isProperty()) {
/* 309:309 */       switch (columnIndex) {
/* 310:    */       case 0: 
/* 311:311 */         result = item;
/* 312:312 */         break;
/* 313:    */       case 1: 
/* 314:    */         try
/* 315:    */         {
/* 316:316 */           result = item.getProperty().getValue();
/* 317:    */         } catch (Exception e) {
/* 318:318 */           e.printStackTrace();
/* 319:    */         }
/* 320:    */       
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */       }
/* 325:    */       
/* 326:    */     } else {
/* 327:327 */       result = item;
/* 328:    */     }
/* 329:329 */     return result;
/* 330:    */   }
/* 331:    */   
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */   public void setValueAt(Object value, int rowIndex, int columnIndex)
/* 339:    */   {
/* 340:340 */     Item item = getPropertySheetElement(rowIndex);
/* 341:341 */     if ((item.isProperty()) && 
/* 342:342 */       (columnIndex == 1)) {
/* 343:    */       try {
/* 344:344 */         item.getProperty().setValue(value);
/* 345:    */       } catch (Exception e) {
/* 346:346 */         e.printStackTrace();
/* 347:    */       }
/* 348:    */     }
/* 349:    */   }
/* 350:    */   
/* 351:    */ 
/* 352:    */ 
/* 353:    */ 
/* 354:    */   public void addPropertyChangeListener(PropertyChangeListener listener)
/* 355:    */   {
/* 356:356 */     listeners.addPropertyChangeListener(listener);
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 360:360 */     listeners.removePropertyChangeListener(listener);
/* 361:    */   }
/* 362:    */   
/* 363:    */   public void propertyChange(PropertyChangeEvent evt)
/* 364:    */   {
/* 365:365 */     listeners.firePropertyChange(evt);
/* 366:    */   }
/* 367:    */   
/* 368:    */   protected void visibilityChanged(boolean restoreOldStates) {
/* 369:    */     Iterator iter;
/* 370:370 */     if (restoreOldStates) {
/* 371:371 */       for (iter = publishedModel.iterator(); iter.hasNext();) {
/* 372:372 */         Item item = (Item)iter.next();
/* 373:373 */         toggleStates.put(item.getKey(), item.isVisible() ? Boolean.TRUE : Boolean.FALSE);
/* 374:    */       }
/* 375:    */     }
/* 376:376 */     publishedModel.clear();
/* 377:377 */     for (Iterator iter = model.iterator(); iter.hasNext();) {
/* 378:378 */       Item item = (Item)iter.next();
/* 379:379 */       Item parent = item.getParent();
/* 380:380 */       if (restoreOldStates) {
/* 381:381 */         Boolean oldState = (Boolean)toggleStates.get(item.getKey());
/* 382:382 */         if (oldState != null) {
/* 383:383 */           item.setVisible(oldState.booleanValue());
/* 384:    */         }
/* 385:385 */         if (parent != null) {
/* 386:386 */           oldState = (Boolean)toggleStates.get(parent.getKey());
/* 387:387 */           if (oldState != null) {
/* 388:388 */             parent.setVisible(oldState.booleanValue());
/* 389:    */           }
/* 390:    */         }
/* 391:    */       }
/* 392:392 */       if ((parent == null) || (parent.isVisible()))
/* 393:393 */         publishedModel.add(item);
/* 394:    */     }
/* 395:    */   }
/* 396:    */   
/* 397:    */   private void buildModel() {
/* 398:398 */     model.clear();
/* 399:    */     
/* 400:400 */     if ((properties != null) && (properties.size() > 0)) {
/* 401:401 */       List sortedProperties = sortProperties(properties);
/* 402:    */       Iterator iter;
/* 403:403 */       switch (mode)
/* 404:    */       {
/* 405:    */       case 0: 
/* 406:406 */         addPropertiesToModel(sortedProperties, null);
/* 407:407 */         break;
/* 408:    */       
/* 409:    */ 
/* 410:    */       case 1: 
/* 411:411 */         List categories = sortCategories(getPropertyCategories(sortedProperties));
/* 412:    */         
/* 413:413 */         for (iter = categories.iterator(); iter.hasNext();) {
/* 414:414 */           String category = (String)iter.next();
/* 415:415 */           Item categoryItem = new Item(category, null, null);
/* 416:416 */           model.add(categoryItem);
/* 417:417 */           addPropertiesToModel(sortProperties(getPropertiesForCategory(properties, category)), categoryItem);
/* 418:    */         }
/* 419:    */         
/* 420:    */ 
/* 421:421 */         break;
/* 422:    */       }
/* 423:    */       
/* 424:    */     }
/* 425:    */     
/* 426:    */ 
/* 427:    */ 
/* 428:    */ 
/* 429:429 */     visibilityChanged(restoreToggleStates);
/* 430:430 */     fireTableDataChanged();
/* 431:    */   }
/* 432:    */   
/* 433:    */   protected List sortProperties(List localProperties) {
/* 434:434 */     List sortedProperties = new ArrayList(localProperties);
/* 435:435 */     if (sortingProperties) {
/* 436:436 */       if (propertySortingComparator == null)
/* 437:    */       {
/* 438:438 */         propertySortingComparator = new PropertyComparator();
/* 439:    */       }
/* 440:440 */       Collections.sort(sortedProperties, propertySortingComparator);
/* 441:    */     }
/* 442:442 */     return sortedProperties;
/* 443:    */   }
/* 444:    */   
/* 445:    */   protected List sortCategories(List localCategories) {
/* 446:446 */     List sortedCategories = new ArrayList(localCategories);
/* 447:447 */     if (sortingCategories) {
/* 448:448 */       if (categorySortingComparator == null)
/* 449:    */       {
/* 450:450 */         categorySortingComparator = STRING_COMPARATOR;
/* 451:    */       }
/* 452:452 */       Collections.sort(sortedCategories, categorySortingComparator);
/* 453:    */     }
/* 454:454 */     return sortedCategories;
/* 455:    */   }
/* 456:    */   
/* 457:    */   protected List getPropertyCategories(List localProperties) {
/* 458:458 */     List categories = new ArrayList();
/* 459:459 */     for (Iterator iter = localProperties.iterator(); iter.hasNext();) {
/* 460:460 */       Property property = (Property)iter.next();
/* 461:461 */       if (!categories.contains(property.getCategory()))
/* 462:462 */         categories.add(property.getCategory());
/* 463:    */     }
/* 464:464 */     return categories;
/* 465:    */   }
/* 466:    */   
/* 467:    */ 
/* 468:    */ 
/* 469:    */ 
/* 470:    */ 
/* 471:    */ 
/* 472:    */   private void addPropertiesToModel(List localProperties, Item parent)
/* 473:    */   {
/* 474:474 */     for (Iterator iter = localProperties.iterator(); iter.hasNext();) {
/* 475:475 */       Property property = (Property)iter.next();
/* 476:476 */       Item propertyItem = new Item(property, parent, null);
/* 477:477 */       model.add(propertyItem);
/* 478:    */       
/* 479:    */ 
/* 480:480 */       Property[] subProperties = property.getSubProperties();
/* 481:481 */       if ((subProperties != null) && (subProperties.length > 0)) {
/* 482:482 */         addPropertiesToModel(Arrays.asList(subProperties), propertyItem);
/* 483:    */       }
/* 484:    */     }
/* 485:    */   }
/* 486:    */   
/* 487:    */ 
/* 488:    */   private List getPropertiesForCategory(List localProperties, String category)
/* 489:    */   {
/* 490:490 */     List categoryProperties = new ArrayList();
/* 491:491 */     for (Iterator iter = localProperties.iterator(); iter.hasNext();) {
/* 492:492 */       Property property = (Property)iter.next();
/* 493:493 */       if ((category == property.getCategory()) || ((category != null) && (category.equals(property.getCategory()))))
/* 494:    */       {
/* 495:495 */         categoryProperties.add(property);
/* 496:    */       }
/* 497:    */     }
/* 498:498 */     return categoryProperties; }
/* 499:    */   
/* 500:    */   public class Item { private String name; private Property property;
/* 501:501 */     Item(String x1, Item x2, PropertySheetTableModel.1 x3) { this(x1, x2); } Item(Property x1, Item x2, PropertySheetTableModel.1 x3) { this(x1, x2); }
/* 502:    */     
/* 503:    */ 
/* 504:    */     private Item parent;
/* 505:505 */     private boolean hasToggle = true;
/* 506:506 */     private boolean visible = true;
/* 507:    */     
/* 508:    */     private Item(String name, Item parent) {
/* 509:509 */       this.name = name;
/* 510:510 */       this.parent = parent;
/* 511:    */       
/* 512:512 */       hasToggle = true;
/* 513:    */     }
/* 514:    */     
/* 515:    */     private Item(Property property, Item parent) {
/* 516:516 */       name = property.getDisplayName();
/* 517:517 */       this.property = property;
/* 518:518 */       this.parent = parent;
/* 519:519 */       visible = (property == null);
/* 520:    */       
/* 521:    */ 
/* 522:522 */       Property[] subProperties = property.getSubProperties();
/* 523:523 */       hasToggle = ((subProperties != null) && (subProperties.length > 0));
/* 524:    */     }
/* 525:    */     
/* 526:    */     public String getName() {
/* 527:527 */       return name;
/* 528:    */     }
/* 529:    */     
/* 530:    */     public boolean isProperty() {
/* 531:531 */       return property != null;
/* 532:    */     }
/* 533:    */     
/* 534:    */     public Property getProperty() {
/* 535:535 */       return property;
/* 536:    */     }
/* 537:    */     
/* 538:    */     public Item getParent() {
/* 539:539 */       return parent;
/* 540:    */     }
/* 541:    */     
/* 542:    */     public int getDepth() {
/* 543:543 */       int depth = 0;
/* 544:544 */       if (parent != null) {
/* 545:545 */         depth = parent.getDepth();
/* 546:546 */         if (parent.isProperty())
/* 547:547 */           depth++;
/* 548:    */       }
/* 549:549 */       return depth;
/* 550:    */     }
/* 551:    */     
/* 552:    */     public boolean hasToggle() {
/* 553:553 */       return hasToggle;
/* 554:    */     }
/* 555:    */     
/* 556:    */     public void toggle() {
/* 557:557 */       if (hasToggle()) {
/* 558:558 */         visible = (!visible);
/* 559:559 */         visibilityChanged(false);
/* 560:560 */         fireTableDataChanged();
/* 561:    */       }
/* 562:    */     }
/* 563:    */     
/* 564:    */     public void setVisible(boolean visible) {
/* 565:565 */       this.visible = visible;
/* 566:    */     }
/* 567:    */     
/* 568:    */     public boolean isVisible() {
/* 569:569 */       return ((parent == null) || (parent.isVisible())) && ((!hasToggle) || (visible));
/* 570:    */     }
/* 571:    */     
/* 572:    */     public String getKey() {
/* 573:573 */       StringBuffer key = new StringBuffer(name);
/* 574:574 */       Item itemParent = parent;
/* 575:575 */       while (itemParent != null) {
/* 576:576 */         key.append(":");
/* 577:577 */         key.append(itemParent.getName());
/* 578:578 */         itemParent = itemParent.getParent();
/* 579:    */       }
/* 580:580 */       return key.toString();
/* 581:    */     }
/* 582:    */   }
/* 583:    */   
/* 584:    */ 
/* 585:    */ 
/* 586:    */   public static class PropertyComparator
/* 587:    */     implements Comparator
/* 588:    */   {
/* 589:    */     public int compare(Object o1, Object o2)
/* 590:    */     {
/* 591:591 */       if (((o1 instanceof Property)) && ((o2 instanceof Property))) {
/* 592:592 */         Property prop1 = (Property)o1;
/* 593:593 */         Property prop2 = (Property)o2;
/* 594:594 */         if (prop1 == null) {
/* 595:595 */           return prop2 == null ? 0 : -1;
/* 596:    */         }
/* 597:597 */         return PropertySheetTableModel.STRING_COMPARATOR.compare(prop1.getDisplayName() == null ? null : prop1.getDisplayName().toLowerCase(), prop2.getDisplayName() == null ? null : prop2.getDisplayName().toLowerCase());
/* 598:    */       }
/* 599:    */       
/* 600:    */ 
/* 601:601 */       return 0;
/* 602:    */     }
/* 603:    */   }
/* 604:    */   
/* 605:    */ 
/* 606:606 */   private static final Comparator STRING_COMPARATOR = new NaturalOrderStringComparator();
/* 607:    */   
/* 608:    */   public static class NaturalOrderStringComparator implements Comparator
/* 609:    */   {
/* 610:    */     public int compare(Object o1, Object o2) {
/* 611:611 */       String s1 = (String)o1;
/* 612:612 */       String s2 = (String)o2;
/* 613:613 */       if (s1 == null) {
/* 614:614 */         return s2 == null ? 0 : -1;
/* 615:    */       }
/* 616:616 */       if (s2 == null) {
/* 617:617 */         return 1;
/* 618:    */       }
/* 619:619 */       return s1.compareTo(s2);
/* 620:    */     }
/* 621:    */   }
/* 622:    */ }
