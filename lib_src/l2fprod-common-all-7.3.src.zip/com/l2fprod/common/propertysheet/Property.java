package com.l2fprod.common.propertysheet;

import java.beans.PropertyChangeListener;
import java.io.Serializable;

public abstract interface Property
  extends Serializable, Cloneable
{
  public abstract String getName();
  
  public abstract String getDisplayName();
  
  public abstract String getShortDescription();
  
  public abstract Class getType();
  
  public abstract Object getValue();
  
  public abstract void setValue(Object paramObject);
  
  public abstract boolean isEditable();
  
  public abstract String getCategory();
  
  public abstract void readFromObject(Object paramObject);
  
  public abstract void writeToObject(Object paramObject);
  
  public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract Object clone();
  
  public abstract Property getParentProperty();
  
  public abstract Property[] getSubProperties();
}
