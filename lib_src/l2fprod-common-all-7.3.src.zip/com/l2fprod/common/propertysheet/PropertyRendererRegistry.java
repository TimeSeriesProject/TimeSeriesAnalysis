/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.ExtendedPropertyDescriptor;
/*   4:    */ import com.l2fprod.common.swing.renderer.BooleanCellRenderer;
/*   5:    */ import com.l2fprod.common.swing.renderer.ColorCellRenderer;
/*   6:    */ import com.l2fprod.common.swing.renderer.DateRenderer;
/*   7:    */ import com.l2fprod.common.swing.renderer.DefaultCellRenderer;
/*   8:    */ import java.awt.Color;
/*   9:    */ import java.beans.PropertyDescriptor;
/*  10:    */ import java.util.Date;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.Map;
/*  13:    */ import javax.swing.table.TableCellRenderer;
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ public class PropertyRendererRegistry
/*  36:    */   implements PropertyRendererFactory
/*  37:    */ {
/*  38:    */   private Map typeToRenderer;
/*  39:    */   private Map propertyToRenderer;
/*  40:    */   
/*  41:    */   public PropertyRendererRegistry()
/*  42:    */   {
/*  43: 43 */     typeToRenderer = new HashMap();
/*  44: 44 */     propertyToRenderer = new HashMap();
/*  45: 45 */     registerDefaults();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public TableCellRenderer createTableCellRenderer(Property property) {
/*  49: 49 */     return getRenderer(property);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public TableCellRenderer createTableCellRenderer(Class type) {
/*  53: 53 */     return getRenderer(type);
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */   public synchronized TableCellRenderer getRenderer(Property property)
/*  78:    */   {
/*  79: 79 */     TableCellRenderer renderer = null;
/*  80: 80 */     if ((property instanceof PropertyDescriptorAdapter)) {
/*  81: 81 */       PropertyDescriptor descriptor = ((PropertyDescriptorAdapter)property).getDescriptor();
/*  82: 82 */       if (((descriptor instanceof ExtendedPropertyDescriptor)) && 
/*  83: 83 */         (((ExtendedPropertyDescriptor)descriptor).getPropertyTableRendererClass() != null)) {
/*  84:    */         try {
/*  85: 85 */           return (TableCellRenderer)((ExtendedPropertyDescriptor)descriptor).getPropertyTableRendererClass().newInstance();
/*  86:    */         }
/*  87:    */         catch (Exception ex) {
/*  88: 88 */           ex.printStackTrace();
/*  89:    */         }
/*  90:    */       }
/*  91:    */     }
/*  92:    */     
/*  93: 93 */     Object value = propertyToRenderer.get(property);
/*  94: 94 */     if ((value instanceof TableCellRenderer)) {
/*  95: 95 */       renderer = (TableCellRenderer)value;
/*  96: 96 */     } else if ((value instanceof Class)) {
/*  97:    */       try {
/*  98: 98 */         renderer = (TableCellRenderer)((Class)value).newInstance();
/*  99:    */       } catch (Exception e) {
/* 100:100 */         e.printStackTrace();
/* 101:    */       }
/* 102:    */     } else {
/* 103:103 */       renderer = getRenderer(property.getType());
/* 104:    */     }
/* 105:105 */     return renderer;
/* 106:    */   }
/* 107:    */   
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */   public synchronized TableCellRenderer getRenderer(Class type)
/* 125:    */   {
/* 126:126 */     TableCellRenderer renderer = null;
/* 127:127 */     Object value = typeToRenderer.get(type);
/* 128:128 */     if ((value instanceof TableCellRenderer)) {
/* 129:129 */       renderer = (TableCellRenderer)value;
/* 130:130 */     } else if ((value instanceof Class)) {
/* 131:    */       try {
/* 132:132 */         renderer = (TableCellRenderer)((Class)value).newInstance();
/* 133:    */       } catch (Exception e) {
/* 134:134 */         e.printStackTrace();
/* 135:    */       }
/* 136:    */     }
/* 137:137 */     return renderer;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public synchronized void registerRenderer(Class type, Class rendererClass) {
/* 141:141 */     typeToRenderer.put(type, rendererClass);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public synchronized void registerRenderer(Class type, TableCellRenderer renderer) {
/* 145:145 */     typeToRenderer.put(type, renderer);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public synchronized void unregisterRenderer(Class type) {
/* 149:149 */     typeToRenderer.remove(type);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public synchronized void registerRenderer(Property property, Class rendererClass) {
/* 153:153 */     propertyToRenderer.put(property, rendererClass);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public synchronized void registerRenderer(Property property, TableCellRenderer renderer)
/* 157:    */   {
/* 158:158 */     propertyToRenderer.put(property, renderer);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public synchronized void unregisterRenderer(Property property) {
/* 162:162 */     propertyToRenderer.remove(property);
/* 163:    */   }
/* 164:    */   
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */   public void registerDefaults()
/* 172:    */   {
/* 173:173 */     typeToRenderer.clear();
/* 174:174 */     propertyToRenderer.clear();
/* 175:    */     
/* 176:    */ 
/* 177:177 */     DefaultCellRenderer renderer = new DefaultCellRenderer();
/* 178:178 */     renderer.setShowOddAndEvenRows(false);
/* 179:    */     
/* 180:180 */     ColorCellRenderer colorRenderer = new ColorCellRenderer();
/* 181:181 */     colorRenderer.setShowOddAndEvenRows(false);
/* 182:    */     
/* 183:183 */     BooleanCellRenderer booleanRenderer = new BooleanCellRenderer();
/* 184:    */     
/* 185:185 */     DateRenderer dateRenderer = new DateRenderer();
/* 186:186 */     dateRenderer.setShowOddAndEvenRows(false);
/* 187:    */     
/* 188:188 */     registerRenderer(Object.class, renderer);
/* 189:189 */     registerRenderer(Color.class, colorRenderer);
/* 190:190 */     registerRenderer(Boolean.TYPE, booleanRenderer);
/* 191:191 */     registerRenderer(Boolean.class, booleanRenderer);
/* 192:192 */     registerRenderer(Byte.TYPE, renderer);
/* 193:193 */     registerRenderer(Byte.class, renderer);
/* 194:194 */     registerRenderer(Character.TYPE, renderer);
/* 195:195 */     registerRenderer(Character.class, renderer);
/* 196:196 */     registerRenderer(Double.TYPE, renderer);
/* 197:197 */     registerRenderer(Double.class, renderer);
/* 198:198 */     registerRenderer(Float.TYPE, renderer);
/* 199:199 */     registerRenderer(Float.class, renderer);
/* 200:200 */     registerRenderer(Integer.TYPE, renderer);
/* 201:201 */     registerRenderer(Integer.class, renderer);
/* 202:202 */     registerRenderer(Long.TYPE, renderer);
/* 203:203 */     registerRenderer(Long.class, renderer);
/* 204:204 */     registerRenderer(Short.TYPE, renderer);
/* 205:205 */     registerRenderer(Short.class, renderer);
/* 206:206 */     registerRenderer(Date.class, dateRenderer);
/* 207:    */   }
/* 208:    */ }
