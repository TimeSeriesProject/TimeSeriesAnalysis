/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.editor.BooleanAsCheckBoxPropertyEditor;
/*   4:    */ import com.l2fprod.common.beans.editor.ColorPropertyEditor;
/*   5:    */ import com.l2fprod.common.beans.editor.DimensionPropertyEditor;
/*   6:    */ import com.l2fprod.common.beans.editor.DoublePropertyEditor;
/*   7:    */ import com.l2fprod.common.beans.editor.FilePropertyEditor;
/*   8:    */ import com.l2fprod.common.beans.editor.FloatPropertyEditor;
/*   9:    */ import com.l2fprod.common.beans.editor.InsetsPropertyEditor;
/*  10:    */ import com.l2fprod.common.beans.editor.IntegerPropertyEditor;
/*  11:    */ import com.l2fprod.common.beans.editor.LongPropertyEditor;
/*  12:    */ import com.l2fprod.common.beans.editor.RectanglePropertyEditor;
/*  13:    */ import com.l2fprod.common.beans.editor.ShortPropertyEditor;
/*  14:    */ import com.l2fprod.common.beans.editor.StringPropertyEditor;
/*  15:    */ import java.awt.Color;
/*  16:    */ import java.awt.Dimension;
/*  17:    */ import java.awt.Font;
/*  18:    */ import java.awt.Insets;
/*  19:    */ import java.awt.Rectangle;
/*  20:    */ import java.beans.PropertyDescriptor;
/*  21:    */ import java.beans.PropertyEditor;
/*  22:    */ import java.beans.PropertyEditorManager;
/*  23:    */ import java.io.File;
/*  24:    */ import java.util.Date;
/*  25:    */ import java.util.HashMap;
/*  26:    */ import java.util.Map;
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class PropertyEditorRegistry
/*  37:    */   implements PropertyEditorFactory
/*  38:    */ {
/*  39:    */   private Map typeToEditor;
/*  40:    */   private Map propertyToEditor;
/*  41:    */   
/*  42:    */   public PropertyEditorRegistry()
/*  43:    */   {
/*  44: 44 */     typeToEditor = new HashMap();
/*  45: 45 */     propertyToEditor = new HashMap();
/*  46: 46 */     registerDefaults();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public PropertyEditor createPropertyEditor(Property property) {
/*  50: 50 */     return getEditor(property);
/*  51:    */   }
/*  52:    */   
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */   public synchronized PropertyEditor getEditor(Property property)
/*  74:    */   {
/*  75: 75 */     PropertyEditor editor = null;
/*  76: 76 */     if ((property instanceof PropertyDescriptorAdapter)) {
/*  77: 77 */       PropertyDescriptor descriptor = ((PropertyDescriptorAdapter)property).getDescriptor();
/*  78: 78 */       if (descriptor != null) {
/*  79: 79 */         Class clz = descriptor.getPropertyEditorClass();
/*  80: 80 */         if (clz != null) {
/*  81: 81 */           editor = loadPropertyEditor(clz);
/*  82:    */         }
/*  83:    */       }
/*  84:    */     }
/*  85: 85 */     if (editor == null) {
/*  86: 86 */       Object value = propertyToEditor.get(property);
/*  87: 87 */       if ((value instanceof PropertyEditor)) {
/*  88: 88 */         editor = (PropertyEditor)value;
/*  89: 89 */       } else if ((value instanceof Class)) {
/*  90: 90 */         editor = loadPropertyEditor((Class)value);
/*  91:    */       } else {
/*  92: 92 */         editor = getEditor(property.getType());
/*  93:    */       }
/*  94:    */     }
/*  95: 95 */     if ((editor == null) && ((property instanceof PropertyDescriptorAdapter))) {
/*  96: 96 */       PropertyDescriptor descriptor = ((PropertyDescriptorAdapter)property).getDescriptor();
/*  97: 97 */       Class clz = descriptor.getPropertyType();
/*  98: 98 */       editor = PropertyEditorManager.findEditor(clz);
/*  99:    */     }
/* 100:100 */     return editor;
/* 101:    */   }
/* 102:    */   
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */   private PropertyEditor loadPropertyEditor(Class clz)
/* 108:    */   {
/* 109:109 */     PropertyEditor editor = null;
/* 110:    */     try {
/* 111:111 */       editor = (PropertyEditor)clz.newInstance();
/* 112:    */     } catch (Exception e) {
/* 113:113 */       e.printStackTrace();
/* 114:    */     }
/* 115:115 */     return editor;
/* 116:    */   }
/* 117:    */   
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */   public synchronized PropertyEditor getEditor(Class type)
/* 135:    */   {
/* 136:136 */     PropertyEditor editor = null;
/* 137:137 */     Object value = typeToEditor.get(type);
/* 138:138 */     if ((value instanceof PropertyEditor)) {
/* 139:139 */       editor = (PropertyEditor)value;
/* 140:140 */     } else if ((value instanceof Class)) {
/* 141:    */       try {
/* 142:142 */         editor = (PropertyEditor)((Class)value).newInstance();
/* 143:    */       } catch (Exception e) {
/* 144:144 */         e.printStackTrace();
/* 145:    */       }
/* 146:    */     }
/* 147:147 */     return editor;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public synchronized void registerEditor(Class type, Class editorClass) {
/* 151:151 */     typeToEditor.put(type, editorClass);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public synchronized void registerEditor(Class type, PropertyEditor editor) {
/* 155:155 */     typeToEditor.put(type, editor);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public synchronized void unregisterEditor(Class type) {
/* 159:159 */     typeToEditor.remove(type);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public synchronized void registerEditor(Property property, Class editorClass) {
/* 163:163 */     propertyToEditor.put(property, editorClass);
/* 164:    */   }
/* 165:    */   
/* 166:    */   public synchronized void registerEditor(Property property, PropertyEditor editor)
/* 167:    */   {
/* 168:168 */     propertyToEditor.put(property, editor);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public synchronized void unregisterEditor(Property property) {
/* 172:172 */     propertyToEditor.remove(property);
/* 173:    */   }
/* 174:    */   
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */   public void registerDefaults()
/* 182:    */   {
/* 183:183 */     typeToEditor.clear();
/* 184:184 */     propertyToEditor.clear();
/* 185:    */     
/* 186:    */ 
/* 187:187 */     registerEditor(String.class, StringPropertyEditor.class);
/* 188:    */     
/* 189:189 */     registerEditor(Double.TYPE, DoublePropertyEditor.class);
/* 190:190 */     registerEditor(Double.class, DoublePropertyEditor.class);
/* 191:    */     
/* 192:192 */     registerEditor(Float.TYPE, FloatPropertyEditor.class);
/* 193:193 */     registerEditor(Float.class, FloatPropertyEditor.class);
/* 194:    */     
/* 195:195 */     registerEditor(Integer.TYPE, IntegerPropertyEditor.class);
/* 196:196 */     registerEditor(Integer.class, IntegerPropertyEditor.class);
/* 197:    */     
/* 198:198 */     registerEditor(Long.TYPE, LongPropertyEditor.class);
/* 199:199 */     registerEditor(Long.class, LongPropertyEditor.class);
/* 200:    */     
/* 201:201 */     registerEditor(Short.TYPE, ShortPropertyEditor.class);
/* 202:202 */     registerEditor(Short.class, ShortPropertyEditor.class);
/* 203:    */     
/* 204:204 */     registerEditor(Boolean.TYPE, BooleanAsCheckBoxPropertyEditor.class);
/* 205:205 */     registerEditor(Boolean.class, BooleanAsCheckBoxPropertyEditor.class);
/* 206:    */     
/* 207:207 */     registerEditor(File.class, FilePropertyEditor.class);
/* 208:    */     
/* 209:    */ 
/* 210:210 */     registerEditor(Color.class, ColorPropertyEditor.class);
/* 211:211 */     registerEditor(Dimension.class, DimensionPropertyEditor.class);
/* 212:212 */     registerEditor(Insets.class, InsetsPropertyEditor.class);
/* 213:    */     try {
/* 214:214 */       Class fontEditor = Class.forName("com.l2fprod.common.beans.editor.FontPropertyEditor");
/* 215:    */       
/* 216:216 */       registerEditor(Font.class, fontEditor);
/* 217:    */     }
/* 218:    */     catch (Exception e) {}
/* 219:    */     
/* 220:220 */     registerEditor(Rectangle.class, RectanglePropertyEditor.class);
/* 221:    */     
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */ 
/* 226:    */ 
/* 227:227 */     boolean foundDateEditor = false;
/* 228:    */     
/* 229:    */ 
/* 230:    */     try
/* 231:    */     {
/* 232:232 */       Class.forName("com.toedter.calendar.JDateChooser");
/* 233:233 */       registerEditor(Date.class, Class.forName("com.l2fprod.common.beans.editor.JCalendarDatePropertyEditor"));
/* 234:    */       
/* 235:235 */       foundDateEditor = true;
/* 236:    */     }
/* 237:    */     catch (ClassNotFoundException e) {}
/* 238:    */     
/* 239:    */ 
/* 240:240 */     if (!foundDateEditor) {
/* 241:    */       try
/* 242:    */       {
/* 243:243 */         Class.forName("net.sf.nachocalendar.components.DateField");
/* 244:244 */         registerEditor(Date.class, Class.forName("com.l2fprod.common.beans.editor.NachoCalendarDatePropertyEditor"));
/* 245:    */         
/* 246:    */ 
/* 247:    */ 
/* 248:248 */         foundDateEditor = true;
/* 249:    */       }
/* 250:    */       catch (ClassNotFoundException e) {}
/* 251:    */     }
/* 252:    */   }
/* 253:    */ }
