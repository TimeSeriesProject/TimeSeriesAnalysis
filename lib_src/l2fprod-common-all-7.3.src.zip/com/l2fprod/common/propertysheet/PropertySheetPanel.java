/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.IconPool;
/*   4:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   5:    */ import com.l2fprod.common.swing.plaf.blue.BlueishButtonUI;
/*   6:    */ import com.l2fprod.common.util.ResourceManager;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.FlowLayout;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import java.beans.BeanInfo;
/*  11:    */ import java.beans.PropertyChangeEvent;
/*  12:    */ import java.beans.PropertyChangeListener;
/*  13:    */ import java.beans.PropertyDescriptor;
/*  14:    */ import java.util.Comparator;
/*  15:    */ import java.util.Iterator;
/*  16:    */ import java.util.Map;
/*  17:    */ import javax.swing.AbstractAction;
/*  18:    */ import javax.swing.BorderFactory;
/*  19:    */ import javax.swing.JEditorPane;
/*  20:    */ import javax.swing.JPanel;
/*  21:    */ import javax.swing.JScrollPane;
/*  22:    */ import javax.swing.JSplitPane;
/*  23:    */ import javax.swing.JToggleButton;
/*  24:    */ import javax.swing.JViewport;
/*  25:    */ import javax.swing.ListSelectionModel;
/*  26:    */ import javax.swing.UIManager;
/*  27:    */ import javax.swing.event.ListSelectionEvent;
/*  28:    */ import javax.swing.event.ListSelectionListener;
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ public class PropertySheetPanel
/*  60:    */   extends JPanel
/*  61:    */   implements PropertySheet, PropertyChangeListener
/*  62:    */ {
/*  63:    */   private PropertySheetTable table;
/*  64:    */   private PropertySheetTableModel model;
/*  65:    */   private JScrollPane tableScroll;
/*  66: 66 */   private ListSelectionListener selectionListener = new SelectionListener();
/*  67:    */   
/*  68:    */   private JPanel actionPanel;
/*  69:    */   
/*  70:    */   private JToggleButton sortButton;
/*  71:    */   private JToggleButton asCategoryButton;
/*  72:    */   private JToggleButton descriptionButton;
/*  73:    */   private JSplitPane split;
/*  74:    */   private int lastDescriptionHeight;
/*  75:    */   private JEditorPane descriptionPanel;
/*  76:    */   private JScrollPane descriptionScrollPane;
/*  77:    */   
/*  78:    */   public PropertySheetPanel()
/*  79:    */   {
/*  80: 80 */     this(new PropertySheetTable());
/*  81:    */   }
/*  82:    */   
/*  83:    */   public PropertySheetPanel(PropertySheetTable table) {
/*  84: 84 */     buildUI();
/*  85: 85 */     setTable(table);
/*  86:    */   }
/*  87:    */   
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */   public void setTable(PropertySheetTable table)
/*  98:    */   {
/*  99: 99 */     if (table == null) {
/* 100:100 */       throw new IllegalArgumentException("table must not be null");
/* 101:    */     }
/* 102:    */     
/* 103:    */ 
/* 104:104 */     if (model != null) {
/* 105:105 */       model.removePropertyChangeListener(this);
/* 106:    */     }
/* 107:    */     
/* 108:108 */     model = ((PropertySheetTableModel)table.getModel());
/* 109:109 */     model.addPropertyChangeListener(this);
/* 110:    */     
/* 111:    */ 
/* 112:112 */     if (this.table != null) {
/* 113:113 */       this.table.getSelectionModel().removeListSelectionListener(selectionListener);
/* 114:    */     }
/* 115:    */     
/* 116:    */ 
/* 117:117 */     table.getSelectionModel().addListSelectionListener(selectionListener);
/* 118:118 */     tableScroll.getViewport().setView(table);
/* 119:    */     
/* 120:    */ 
/* 121:121 */     this.table = table;
/* 122:    */   }
/* 123:    */   
/* 124:    */ 
/* 125:    */ 
/* 126:    */   public void propertyChange(PropertyChangeEvent evt)
/* 127:    */   {
/* 128:128 */     repaint();
/* 129:    */   }
/* 130:    */   
/* 131:    */ 
/* 132:    */ 
/* 133:    */   public PropertySheetTable getTable()
/* 134:    */   {
/* 135:135 */     return table;
/* 136:    */   }
/* 137:    */   
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */   public void setDescriptionVisible(boolean visible)
/* 143:    */   {
/* 144:144 */     if (visible) {
/* 145:145 */       add("Center", split);
/* 146:146 */       split.setTopComponent(tableScroll);
/* 147:147 */       split.setBottomComponent(descriptionScrollPane);
/* 148:    */       
/* 149:149 */       split.setDividerLocation(split.getHeight() - lastDescriptionHeight);
/* 150:    */     }
/* 151:    */     else {
/* 152:152 */       lastDescriptionHeight = (split.getHeight() - split.getDividerLocation());
/* 153:153 */       remove(split);
/* 154:154 */       add("Center", tableScroll);
/* 155:    */     }
/* 156:156 */     descriptionButton.setSelected(visible);
/* 157:157 */     revalidate();
/* 158:    */   }
/* 159:    */   
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */   public void setToolBarVisible(boolean visible)
/* 165:    */   {
/* 166:166 */     actionPanel.setVisible(visible);
/* 167:167 */     revalidate();
/* 168:    */   }
/* 169:    */   
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */   public void setMode(int mode)
/* 174:    */   {
/* 175:175 */     model.setMode(mode);
/* 176:176 */     asCategoryButton.setSelected(1 == mode);
/* 177:    */   }
/* 178:    */   
/* 179:    */   public void setProperties(Property[] properties) {
/* 180:180 */     model.setProperties(properties);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public Property[] getProperties() {
/* 184:184 */     return model.getProperties();
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void addProperty(Property property) {
/* 188:188 */     model.addProperty(property);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void addProperty(int index, Property property) {
/* 192:192 */     model.addProperty(index, property);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void removeProperty(Property property) {
/* 196:196 */     model.removeProperty(property);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public int getPropertyCount() {
/* 200:200 */     return model.getPropertyCount();
/* 201:    */   }
/* 202:    */   
/* 203:    */   public Iterator propertyIterator() {
/* 204:204 */     return model.propertyIterator();
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setBeanInfo(BeanInfo beanInfo) {
/* 208:208 */     setProperties(beanInfo.getPropertyDescriptors());
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void setProperties(PropertyDescriptor[] descriptors) {
/* 212:212 */     Property[] properties = new Property[descriptors.length];
/* 213:213 */     int i = 0; for (int c = descriptors.length; i < c; i++) {
/* 214:214 */       properties[i] = new PropertyDescriptorAdapter(descriptors[i]);
/* 215:    */     }
/* 216:216 */     setProperties(properties);
/* 217:    */   }
/* 218:    */   
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */ 
/* 224:    */ 
/* 225:    */   public void readFromObject(Object data)
/* 226:    */   {
/* 227:227 */     getTable().cancelEditing();
/* 228:    */     
/* 229:229 */     Property[] properties = model.getProperties();
/* 230:230 */     int i = 0; for (int c = properties.length; i < c; i++) {
/* 231:231 */       properties[i].readFromObject(data);
/* 232:    */     }
/* 233:233 */     repaint();
/* 234:    */   }
/* 235:    */   
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */   public void writeToObject(Object data)
/* 243:    */   {
/* 244:244 */     getTable().commitEditing();
/* 245:    */     
/* 246:246 */     Property[] properties = getProperties();
/* 247:247 */     int i = 0; for (int c = properties.length; i < c; i++) {
/* 248:248 */       properties[i].writeToObject(data);
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   public void addPropertySheetChangeListener(PropertyChangeListener listener) {
/* 253:253 */     model.addPropertyChangeListener(listener);
/* 254:    */   }
/* 255:    */   
/* 256:    */   public void removePropertySheetChangeListener(PropertyChangeListener listener) {
/* 257:257 */     model.removePropertyChangeListener(listener);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void setEditorFactory(PropertyEditorFactory factory) {
/* 261:261 */     table.setEditorFactory(factory);
/* 262:    */   }
/* 263:    */   
/* 264:    */   public PropertyEditorFactory getEditorFactory() {
/* 265:265 */     return table.getEditorFactory();
/* 266:    */   }
/* 267:    */   
/* 268:    */   /**
/* 269:    */    * @deprecated
/* 270:    */    */
/* 271:    */   public void setEditorRegistry(PropertyEditorRegistry registry)
/* 272:    */   {
/* 273:273 */     table.setEditorFactory(registry);
/* 274:    */   }
/* 275:    */   
/* 276:    */   /**
/* 277:    */    * @deprecated
/* 278:    */    */
/* 279:    */   public PropertyEditorRegistry getEditorRegistry() {
/* 280:280 */     return (PropertyEditorRegistry)table.getEditorFactory();
/* 281:    */   }
/* 282:    */   
/* 283:    */   public void setRendererFactory(PropertyRendererFactory factory) {
/* 284:284 */     table.setRendererFactory(factory);
/* 285:    */   }
/* 286:    */   
/* 287:    */   public PropertyRendererFactory getRendererFactory() {
/* 288:288 */     return table.getRendererFactory();
/* 289:    */   }
/* 290:    */   
/* 291:    */   /**
/* 292:    */    * @deprecated
/* 293:    */    */
/* 294:    */   public void setRendererRegistry(PropertyRendererRegistry registry)
/* 295:    */   {
/* 296:296 */     table.setRendererRegistry(registry);
/* 297:    */   }
/* 298:    */   
/* 299:    */   /**
/* 300:    */    * @deprecated
/* 301:    */    */
/* 302:    */   public PropertyRendererRegistry getRendererRegistry() {
/* 303:303 */     return table.getRendererRegistry();
/* 304:    */   }
/* 305:    */   
/* 306:    */ 
/* 307:    */ 
/* 308:    */ 
/* 309:    */ 
/* 310:    */   public void setSortingCategories(boolean value)
/* 311:    */   {
/* 312:312 */     model.setSortingCategories(value);
/* 313:313 */     sortButton.setSelected(isSorting());
/* 314:    */   }
/* 315:    */   
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */   public boolean isSortingCategories()
/* 321:    */   {
/* 322:322 */     return model.isSortingCategories();
/* 323:    */   }
/* 324:    */   
/* 325:    */ 
/* 326:    */ 
/* 327:    */ 
/* 328:    */ 
/* 329:    */   public void setSortingProperties(boolean value)
/* 330:    */   {
/* 331:331 */     model.setSortingProperties(value);
/* 332:332 */     sortButton.setSelected(isSorting());
/* 333:    */   }
/* 334:    */   
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */   public boolean isSortingProperties()
/* 340:    */   {
/* 341:341 */     return model.isSortingProperties();
/* 342:    */   }
/* 343:    */   
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:    */   public void setSorting(boolean value)
/* 349:    */   {
/* 350:350 */     model.setSortingCategories(value);
/* 351:351 */     model.setSortingProperties(value);
/* 352:352 */     sortButton.setSelected(value);
/* 353:    */   }
/* 354:    */   
/* 355:    */ 
/* 356:    */ 
/* 357:    */   public boolean isSorting()
/* 358:    */   {
/* 359:359 */     return (model.isSortingCategories()) || (model.isSortingProperties());
/* 360:    */   }
/* 361:    */   
/* 362:    */ 
/* 363:    */ 
/* 364:    */ 
/* 365:    */ 
/* 366:    */ 
/* 367:    */   public void setCategorySortingComparator(Comparator comp)
/* 368:    */   {
/* 369:369 */     model.setCategorySortingComparator(comp);
/* 370:    */   }
/* 371:    */   
/* 372:    */ 
/* 373:    */ 
/* 374:    */ 
/* 375:    */ 
/* 376:    */   public void setPropertySortingComparator(Comparator comp)
/* 377:    */   {
/* 378:378 */     model.setPropertySortingComparator(comp);
/* 379:    */   }
/* 380:    */   
/* 381:    */ 
/* 382:    */ 
/* 383:    */ 
/* 384:    */ 
/* 385:    */ 
/* 386:    */   public void setRestoreToggleStates(boolean value)
/* 387:    */   {
/* 388:388 */     model.setRestoreToggleStates(value);
/* 389:    */   }
/* 390:    */   
/* 391:    */ 
/* 392:    */ 
/* 393:    */   public boolean isRestoreToggleStates()
/* 394:    */   {
/* 395:395 */     return model.isRestoreToggleStates();
/* 396:    */   }
/* 397:    */   
/* 398:    */ 
/* 399:    */ 
/* 400:    */   public Map getToggleStates()
/* 401:    */   {
/* 402:402 */     return model.getToggleStates();
/* 403:    */   }
/* 404:    */   
/* 405:    */ 
/* 406:    */ 
/* 407:    */ 
/* 408:    */ 
/* 409:    */   public void setToggleStates(Map toggleStates)
/* 410:    */   {
/* 411:411 */     model.setToggleStates(toggleStates);
/* 412:    */   }
/* 413:    */   
/* 414:    */   private void buildUI() {
/* 415:415 */     LookAndFeelTweaks.setBorderLayout(this);
/* 416:416 */     LookAndFeelTweaks.setBorder(this);
/* 417:    */     
/* 418:418 */     actionPanel = new JPanel(new FlowLayout(3, 2, 0));
/* 419:419 */     actionPanel.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
/* 420:420 */     actionPanel.setOpaque(false);
/* 421:421 */     add("North", actionPanel);
/* 422:    */     
/* 423:423 */     sortButton = new JToggleButton(new ToggleSortingAction());
/* 424:424 */     sortButton.setUI(new BlueishButtonUI());
/* 425:425 */     sortButton.setText(null);
/* 426:426 */     sortButton.setOpaque(false);
/* 427:427 */     actionPanel.add(sortButton);
/* 428:    */     
/* 429:429 */     asCategoryButton = new JToggleButton(new ToggleModeAction());
/* 430:430 */     asCategoryButton.setUI(new BlueishButtonUI());
/* 431:431 */     asCategoryButton.setText(null);
/* 432:432 */     asCategoryButton.setOpaque(false);
/* 433:433 */     actionPanel.add(asCategoryButton);
/* 434:    */     
/* 435:435 */     descriptionButton = new JToggleButton(new ToggleDescriptionAction());
/* 436:436 */     descriptionButton.setUI(new BlueishButtonUI());
/* 437:437 */     descriptionButton.setText(null);
/* 438:438 */     descriptionButton.setOpaque(false);
/* 439:439 */     actionPanel.add(descriptionButton);
/* 440:    */     
/* 441:441 */     split = new JSplitPane(0);
/* 442:442 */     split.setBorder(null);
/* 443:443 */     split.setResizeWeight(1.0D);
/* 444:444 */     split.setContinuousLayout(true);
/* 445:445 */     add("Center", split);
/* 446:    */     
/* 447:447 */     tableScroll = new JScrollPane();
/* 448:448 */     tableScroll.setBorder(BorderFactory.createEmptyBorder());
/* 449:449 */     split.setTopComponent(tableScroll);
/* 450:    */     
/* 451:451 */     descriptionPanel = new JEditorPane("text/html", "<html>");
/* 452:452 */     descriptionPanel.setBorder(BorderFactory.createEmptyBorder());
/* 453:453 */     descriptionPanel.setEditable(false);
/* 454:454 */     descriptionPanel.setBackground(UIManager.getColor("Panel.background"));
/* 455:455 */     LookAndFeelTweaks.htmlize(descriptionPanel);
/* 456:    */     
/* 457:457 */     selectionListener = new SelectionListener();
/* 458:    */     
/* 459:459 */     descriptionScrollPane = new JScrollPane(descriptionPanel);
/* 460:460 */     descriptionScrollPane.setBorder(LookAndFeelTweaks.addMargin(BorderFactory.createLineBorder(UIManager.getColor("controlDkShadow"))));
/* 461:    */     
/* 462:462 */     descriptionScrollPane.getViewport().setBackground(descriptionPanel.getBackground());
/* 463:    */     
/* 464:464 */     descriptionScrollPane.setMinimumSize(new Dimension(50, 50));
/* 465:465 */     split.setBottomComponent(descriptionScrollPane);
/* 466:    */     
/* 467:    */ 
/* 468:468 */     setDescriptionVisible(false);
/* 469:469 */     setToolBarVisible(true);
/* 470:    */   }
/* 471:    */   
/* 472:    */   class SelectionListener implements ListSelectionListener {
/* 473:    */     SelectionListener() {}
/* 474:    */     
/* 475:475 */     public void valueChanged(ListSelectionEvent e) { int row = table.getSelectedRow();
/* 476:476 */       Property prop = null;
/* 477:477 */       if ((row >= 0) && (table.getRowCount() > row))
/* 478:478 */         prop = model.getPropertySheetElement(row).getProperty();
/* 479:479 */       if (prop != null) {
/* 480:480 */         descriptionPanel.setText("<html><b>" + (prop.getDisplayName() == null ? "" : prop.getDisplayName()) + "</b><br>" + (prop.getShortDescription() == null ? "" : prop.getShortDescription()));
/* 481:    */ 
/* 482:    */ 
/* 483:    */       }
/* 484:    */       else
/* 485:    */       {
/* 486:    */ 
/* 487:487 */         descriptionPanel.setText("<html>");
/* 488:    */       }
/* 489:    */       
/* 490:    */ 
/* 491:491 */       descriptionPanel.setCaretPosition(0);
/* 492:    */     }
/* 493:    */   }
/* 494:    */   
/* 495:    */   class ToggleModeAction extends AbstractAction
/* 496:    */   {
/* 497:    */     public ToggleModeAction() {
/* 498:498 */       super(IconPool.shared().get(PropertySheet.class.getResource("icons/category.gif")));
/* 499:    */       
/* 500:500 */       putValue("ShortDescription", ResourceManager.get(PropertySheet.class).getString("PropertySheetPanel.category.shortDescription"));
/* 501:    */     }
/* 502:    */     
/* 503:    */ 
/* 504:    */     public void actionPerformed(ActionEvent e)
/* 505:    */     {
/* 506:506 */       if (asCategoryButton.isSelected()) {
/* 507:507 */         model.setMode(1);
/* 508:    */       } else {
/* 509:509 */         model.setMode(0);
/* 510:    */       }
/* 511:    */     }
/* 512:    */   }
/* 513:    */   
/* 514:    */   class ToggleDescriptionAction extends AbstractAction
/* 515:    */   {
/* 516:    */     public ToggleDescriptionAction() {
/* 517:517 */       super(IconPool.shared().get(PropertySheet.class.getResource("icons/description.gif")));
/* 518:    */       
/* 519:519 */       putValue("ShortDescription", ResourceManager.get(PropertySheet.class).getString("PropertySheetPanel.description.shortDescription"));
/* 520:    */     }
/* 521:    */     
/* 522:    */ 
/* 523:    */     public void actionPerformed(ActionEvent e)
/* 524:    */     {
/* 525:525 */       setDescriptionVisible(descriptionButton.isSelected());
/* 526:    */     }
/* 527:    */   }
/* 528:    */   
/* 529:    */   class ToggleSortingAction extends AbstractAction
/* 530:    */   {
/* 531:    */     public ToggleSortingAction() {
/* 532:532 */       super(IconPool.shared().get(PropertySheet.class.getResource("icons/sort.gif")));
/* 533:    */       
/* 534:534 */       putValue("ShortDescription", ResourceManager.get(PropertySheet.class).getString("PropertySheetPanel.sort.shortDescription"));
/* 535:    */     }
/* 536:    */     
/* 537:    */ 
/* 538:    */     public void actionPerformed(ActionEvent e)
/* 539:    */     {
/* 540:540 */       setSorting(sortButton.isSelected());
/* 541:    */     }
/* 542:    */   }
/* 543:    */ }
