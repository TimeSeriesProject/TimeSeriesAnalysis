package com.l2fprod.common.propertysheet;

import java.beans.PropertyEditor;

public abstract interface PropertyEditorFactory
{
  public abstract PropertyEditor createPropertyEditor(Property paramProperty);
}
