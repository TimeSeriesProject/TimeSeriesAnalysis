/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.BeanUtils;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ public class DefaultProperty
/*  33:    */   extends AbstractProperty
/*  34:    */ {
/*  35:    */   private String name;
/*  36:    */   private String displayName;
/*  37:    */   private String shortDescription;
/*  38:    */   private Class type;
/*  39: 39 */   private boolean editable = true;
/*  40:    */   private String category;
/*  41:    */   private Property parent;
/*  42: 42 */   private List subProperties = new ArrayList();
/*  43:    */   
/*  44:    */   public String getName() {
/*  45: 45 */     return name;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setName(String name) {
/*  49: 49 */     this.name = name;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public String getDisplayName() {
/*  53: 53 */     return displayName;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setDisplayName(String displayName) {
/*  57: 57 */     this.displayName = displayName;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getShortDescription() {
/*  61: 61 */     return shortDescription;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setShortDescription(String shortDescription) {
/*  65: 65 */     this.shortDescription = shortDescription;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Class getType() {
/*  69: 69 */     return type;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setType(Class type) {
/*  73: 73 */     this.type = type;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isEditable() {
/*  77: 77 */     return editable;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setEditable(boolean editable) {
/*  81: 81 */     this.editable = editable;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public String getCategory() {
/*  85: 85 */     return category;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void setCategory(String category) {
/*  89: 89 */     this.category = category;
/*  90:    */   }
/*  91:    */   
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */   public void readFromObject(Object object)
/*  96:    */   {
/*  97:    */     try
/*  98:    */     {
/*  99: 99 */       Method method = BeanUtils.getReadMethod(object.getClass(), getName());
/* 100:100 */       if (method != null) {
/* 101:101 */         value = method.invoke(object, null);
/* 102:102 */         initializeValue(value);
/* 103:103 */         if (value != null)
/* 104:104 */           for (iter = subProperties.iterator(); iter.hasNext();) {
/* 105:105 */             Property subProperty = (Property)iter.next();
/* 106:106 */             subProperty.readFromObject(value);
/* 107:    */           }
/* 108:    */       }
/* 109:    */     } catch (Exception e) { Object value;
/* 110:    */       Iterator iter;
/* 111:111 */       throw new RuntimeException(e);
/* 112:    */     }
/* 113:    */   }
/* 114:    */   
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */   public void writeToObject(Object object)
/* 119:    */   {
/* 120:    */     try
/* 121:    */     {
/* 122:122 */       Method method = BeanUtils.getWriteMethod(object.getClass(), getName(), getType());
/* 123:    */       
/* 124:124 */       if (method != null) {
/* 125:125 */         method.invoke(object, new Object[] { getValue() });
/* 126:    */       }
/* 127:    */     } catch (Exception e) {
/* 128:128 */       throw new RuntimeException(e);
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */ 
/* 133:    */ 
/* 134:    */   public void setValue(Object value)
/* 135:    */   {
/* 136:136 */     super.setValue(value);
/* 137:137 */     if (parent != null) {
/* 138:138 */       Object parentValue = parent.getValue();
/* 139:139 */       if (parentValue != null) {
/* 140:140 */         writeToObject(parentValue);
/* 141:141 */         parent.setValue(parentValue);
/* 142:    */       } }
/* 143:    */     Iterator iter;
/* 144:144 */     if (value != null) {
/* 145:145 */       for (iter = subProperties.iterator(); iter.hasNext();) {
/* 146:146 */         Property subProperty = (Property)iter.next();
/* 147:147 */         subProperty.readFromObject(value);
/* 148:    */       }
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   public int hashCode() {
/* 153:153 */     return 28 + (name != null ? name.hashCode() : 3) + (displayName != null ? displayName.hashCode() : 94) + (shortDescription != null ? shortDescription.hashCode() : 394) + (category != null ? category.hashCode() : 34) + (type != null ? type.hashCode() : 39) + Boolean.valueOf(editable).hashCode();
/* 154:    */   }
/* 155:    */   
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */   public boolean equals(Object other)
/* 167:    */   {
/* 168:168 */     if ((other == null) || (getClass() != other.getClass())) {
/* 169:169 */       return false;
/* 170:    */     }
/* 171:    */     
/* 172:172 */     if (other == this) {
/* 173:173 */       return true;
/* 174:    */     }
/* 175:    */     
/* 176:176 */     DefaultProperty dp = (DefaultProperty)other;
/* 177:    */     
/* 178:178 */     return (compare(name, name)) && (compare(displayName, displayName)) && (compare(shortDescription, shortDescription)) && (compare(category, category)) && (compare(type, type)) && (editable == editable);
/* 179:    */   }
/* 180:    */   
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */   private boolean compare(Object o1, Object o2)
/* 186:    */   {
/* 187:187 */     return o2 == null ? true : o1 != null ? o1.equals(o2) : false;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public String toString() {
/* 191:191 */     return "name=" + getName() + ", displayName=" + getDisplayName() + ", type=" + getType() + ", category=" + getCategory() + ", editable=" + isEditable() + ", value=" + getValue();
/* 192:    */   }
/* 193:    */   
/* 194:    */ 
/* 195:    */   public Property getParentProperty()
/* 196:    */   {
/* 197:197 */     return parent;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void setParentProperty(Property parent) {
/* 201:201 */     this.parent = parent;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public Property[] getSubProperties() {
/* 205:205 */     return (Property[])subProperties.toArray(new Property[subProperties.size()]);
/* 206:    */   }
/* 207:    */   
/* 208:    */   public void clearSubProperties() {
/* 209:209 */     for (Iterator iter = subProperties.iterator(); iter.hasNext();) {
/* 210:210 */       Property subProp = (Property)iter.next();
/* 211:211 */       if ((subProp instanceof DefaultProperty))
/* 212:212 */         ((DefaultProperty)subProp).setParentProperty(null);
/* 213:    */     }
/* 214:214 */     subProperties.clear();
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void addSubProperties(Collection subProperties) {
/* 218:218 */     this.subProperties.addAll(subProperties);
/* 219:219 */     for (Iterator iter = this.subProperties.iterator(); iter.hasNext();) {
/* 220:220 */       Property subProp = (Property)iter.next();
/* 221:221 */       if ((subProp instanceof DefaultProperty))
/* 222:222 */         ((DefaultProperty)subProp).setParentProperty(this);
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   public void addSubProperties(Property[] subProperties) {
/* 227:227 */     addSubProperties(Arrays.asList(subProperties));
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void addSubProperty(Property subProperty) {
/* 231:231 */     subProperties.add(subProperty);
/* 232:232 */     if ((subProperty instanceof DefaultProperty)) {
/* 233:233 */       ((DefaultProperty)subProperty).setParentProperty(this);
/* 234:    */     }
/* 235:    */   }
/* 236:    */ }
