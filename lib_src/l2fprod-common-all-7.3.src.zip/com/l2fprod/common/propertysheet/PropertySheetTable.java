/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.HeaderlessColumnResizer;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Insets;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.MouseAdapter;
/*  12:    */ import java.awt.event.MouseEvent;
/*  13:    */ import java.beans.PropertyEditor;
/*  14:    */ import javax.swing.AbstractAction;
/*  15:    */ import javax.swing.ActionMap;
/*  16:    */ import javax.swing.CellEditor;
/*  17:    */ import javax.swing.Icon;
/*  18:    */ import javax.swing.InputMap;
/*  19:    */ import javax.swing.JTable;
/*  20:    */ import javax.swing.KeyStroke;
/*  21:    */ import javax.swing.ListSelectionModel;
/*  22:    */ import javax.swing.UIManager;
/*  23:    */ import javax.swing.border.Border;
/*  24:    */ import javax.swing.event.TableModelEvent;
/*  25:    */ import javax.swing.event.TableModelListener;
/*  26:    */ import javax.swing.table.DefaultTableCellRenderer;
/*  27:    */ import javax.swing.table.JTableHeader;
/*  28:    */ import javax.swing.table.TableCellEditor;
/*  29:    */ import javax.swing.table.TableCellRenderer;
/*  30:    */ import javax.swing.table.TableColumn;
/*  31:    */ import javax.swing.table.TableColumnModel;
/*  32:    */ import javax.swing.table.TableModel;
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ public class PropertySheetTable
/*  58:    */   extends JTable
/*  59:    */ {
/*  60:    */   private static final int HOTSPOT_SIZE = 18;
/*  61:    */   private static final String TREE_EXPANDED_ICON_KEY = "Tree.expandedIcon";
/*  62:    */   private static final String TREE_COLLAPSED_ICON_KEY = "Tree.collapsedIcon";
/*  63:    */   private static final String TABLE_BACKGROUND_COLOR_KEY = "Table.background";
/*  64:    */   private static final String TABLE_FOREGROUND_COLOR_KEY = "Table.foreground";
/*  65:    */   private static final String TABLE_SELECTED_BACKGROUND_COLOR_KEY = "Table.selectionBackground";
/*  66:    */   private static final String TABLE_SELECTED_FOREGROUND_COLOR_KEY = "Table.selectionForeground";
/*  67:    */   private static final String PANEL_BACKGROUND_COLOR_KEY = "Panel.background";
/*  68:    */   private PropertyEditorFactory editorFactory;
/*  69:    */   private PropertyRendererFactory rendererFactory;
/*  70:    */   private TableCellRenderer nameRenderer;
/*  71: 71 */   private boolean wantsExtraIndent = false;
/*  72:    */   
/*  73:    */   private TableModelListener cancelEditing;
/*  74:    */   
/*  75:    */   private Color categoryBackground;
/*  76:    */   
/*  77:    */   private Color categoryForeground;
/*  78:    */   
/*  79:    */   private Color propertyBackground;
/*  80:    */   
/*  81:    */   private Color propertyForeground;
/*  82:    */   private Color selectedPropertyBackground;
/*  83:    */   private Color selectedPropertyForeground;
/*  84:    */   private Color selectedCategoryBackground;
/*  85:    */   private Color selectedCategoryForeground;
/*  86:    */   
/*  87:    */   public PropertySheetTable()
/*  88:    */   {
/*  89: 89 */     this(new PropertySheetTableModel());
/*  90:    */   }
/*  91:    */   
/*  92:    */   public PropertySheetTable(PropertySheetTableModel dm) {
/*  93: 93 */     super(dm);
/*  94: 94 */     initDefaultColors();
/*  95:    */     
/*  96:    */ 
/*  97: 97 */     getSelectionModel().setSelectionMode(0);
/*  98:    */     
/*  99:    */ 
/* 100:100 */     Dimension nullSize = new Dimension(0, 0);
/* 101:101 */     getTableHeader().setPreferredSize(nullSize);
/* 102:102 */     getTableHeader().setMinimumSize(nullSize);
/* 103:103 */     getTableHeader().setMaximumSize(nullSize);
/* 104:104 */     getTableHeader().setVisible(false);
/* 105:    */     
/* 106:    */ 
/* 107:107 */     new HeaderlessColumnResizer(this);
/* 108:    */     
/* 109:    */ 
/* 110:110 */     setRendererFactory(new PropertyRendererRegistry());
/* 111:111 */     setEditorFactory(new PropertyEditorRegistry());
/* 112:    */     
/* 113:113 */     nameRenderer = new NameRenderer();
/* 114:    */     
/* 115:    */ 
/* 116:116 */     putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
/* 117:    */     
/* 118:    */ 
/* 119:119 */     setColumnSelectionAllowed(false);
/* 120:120 */     setRowSelectionAllowed(true);
/* 121:    */     
/* 122:    */ 
/* 123:123 */     getActionMap().put("startEditing", new StartEditingAction(null));
/* 124:    */     
/* 125:    */ 
/* 126:126 */     getInputMap().put(KeyStroke.getKeyStroke(9, 0), "selectNextRowCell");
/* 127:    */     
/* 128:128 */     getInputMap().put(KeyStroke.getKeyStroke(9, 64), "selectPreviousRowCell");
/* 129:    */     
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:133 */     getActionMap().put("toggle", new ToggleAction(null));
/* 134:134 */     getInputMap().put(KeyStroke.getKeyStroke(32, 0), "toggle");
/* 135:    */     
/* 136:136 */     addMouseListener(new ToggleMouseHandler(null));
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */ 
/* 149:    */ 
/* 150:    */   private void initDefaultColors()
/* 151:    */   {
/* 152:152 */     categoryBackground = UIManager.getColor("Panel.background");
/* 153:153 */     categoryForeground = UIManager.getColor("Table.foreground").darker().darker().darker();
/* 154:    */     
/* 155:155 */     selectedCategoryBackground = categoryBackground.darker();
/* 156:156 */     selectedCategoryForeground = categoryForeground;
/* 157:    */     
/* 158:158 */     propertyBackground = UIManager.getColor("Table.background");
/* 159:159 */     propertyForeground = UIManager.getColor("Table.foreground");
/* 160:    */     
/* 161:161 */     selectedPropertyBackground = UIManager.getColor("Table.selectionBackground");
/* 162:    */     
/* 163:163 */     selectedPropertyForeground = UIManager.getColor("Table.selectionForeground");
/* 164:    */     
/* 165:    */ 
/* 166:166 */     setGridColor(categoryBackground);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public Color getCategoryBackground()
/* 170:    */   {
/* 171:171 */     return categoryBackground;
/* 172:    */   }
/* 173:    */   
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */   public void setCategoryBackground(Color categoryBackground)
/* 179:    */   {
/* 180:180 */     this.categoryBackground = categoryBackground;
/* 181:181 */     repaint();
/* 182:    */   }
/* 183:    */   
/* 184:    */   public Color getCategoryForeground() {
/* 185:185 */     return categoryForeground;
/* 186:    */   }
/* 187:    */   
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */   public void setCategoryForeground(Color categoryForeground)
/* 193:    */   {
/* 194:194 */     this.categoryForeground = categoryForeground;
/* 195:195 */     repaint();
/* 196:    */   }
/* 197:    */   
/* 198:    */   public Color getSelectedCategoryBackground() {
/* 199:199 */     return selectedCategoryBackground;
/* 200:    */   }
/* 201:    */   
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */   public void setSelectedCategoryBackground(Color selectedCategoryBackground)
/* 207:    */   {
/* 208:208 */     this.selectedCategoryBackground = selectedCategoryBackground;
/* 209:209 */     repaint();
/* 210:    */   }
/* 211:    */   
/* 212:    */   public Color getSelectedCategoryForeground() {
/* 213:213 */     return selectedCategoryForeground;
/* 214:    */   }
/* 215:    */   
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:    */ 
/* 220:    */   public void setSelectedCategoryForeground(Color selectedCategoryForeground)
/* 221:    */   {
/* 222:222 */     this.selectedCategoryForeground = selectedCategoryForeground;
/* 223:223 */     repaint();
/* 224:    */   }
/* 225:    */   
/* 226:    */   public Color getPropertyBackground() {
/* 227:227 */     return propertyBackground;
/* 228:    */   }
/* 229:    */   
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */   public void setPropertyBackground(Color propertyBackground)
/* 235:    */   {
/* 236:236 */     this.propertyBackground = propertyBackground;
/* 237:237 */     repaint();
/* 238:    */   }
/* 239:    */   
/* 240:    */   public Color getPropertyForeground() {
/* 241:241 */     return propertyForeground;
/* 242:    */   }
/* 243:    */   
/* 244:    */ 
/* 245:    */ 
/* 246:    */ 
/* 247:    */ 
/* 248:    */   public void setPropertyForeground(Color propertyForeground)
/* 249:    */   {
/* 250:250 */     this.propertyForeground = propertyForeground;
/* 251:251 */     repaint();
/* 252:    */   }
/* 253:    */   
/* 254:    */   public Color getSelectedPropertyBackground() {
/* 255:255 */     return selectedPropertyBackground;
/* 256:    */   }
/* 257:    */   
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */   public void setSelectedPropertyBackground(Color selectedPropertyBackground)
/* 263:    */   {
/* 264:264 */     this.selectedPropertyBackground = selectedPropertyBackground;
/* 265:265 */     repaint();
/* 266:    */   }
/* 267:    */   
/* 268:    */   public Color getSelectedPropertyForeground() {
/* 269:269 */     return selectedPropertyForeground;
/* 270:    */   }
/* 271:    */   
/* 272:    */ 
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */   public void setSelectedPropertyForeground(Color selectedPropertyForeground)
/* 277:    */   {
/* 278:278 */     this.selectedPropertyForeground = selectedPropertyForeground;
/* 279:279 */     repaint();
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void setEditorFactory(PropertyEditorFactory factory) {
/* 283:283 */     editorFactory = factory;
/* 284:    */   }
/* 285:    */   
/* 286:    */   public final PropertyEditorFactory getEditorFactory() {
/* 287:287 */     return editorFactory;
/* 288:    */   }
/* 289:    */   
/* 290:    */   /**
/* 291:    */    * @deprecated
/* 292:    */    */
/* 293:    */   public void setEditorRegistry(PropertyEditorRegistry registry)
/* 294:    */   {
/* 295:295 */     setEditorFactory(registry);
/* 296:    */   }
/* 297:    */   
/* 298:    */ 
/* 299:    */   /**
/* 300:    */    * @deprecated
/* 301:    */    */
/* 302:    */   public PropertyEditorRegistry getEditorRegistry()
/* 303:    */   {
/* 304:304 */     return (PropertyEditorRegistry)editorFactory;
/* 305:    */   }
/* 306:    */   
/* 307:    */   public void setRendererFactory(PropertyRendererFactory factory) {
/* 308:308 */     rendererFactory = factory;
/* 309:    */   }
/* 310:    */   
/* 311:    */   public PropertyRendererFactory getRendererFactory() {
/* 312:312 */     return rendererFactory;
/* 313:    */   }
/* 314:    */   
/* 315:    */   /**
/* 316:    */    * @deprecated
/* 317:    */    */
/* 318:    */   public void setRendererRegistry(PropertyRendererRegistry registry)
/* 319:    */   {
/* 320:320 */     setRendererFactory(registry);
/* 321:    */   }
/* 322:    */   
/* 323:    */ 
/* 324:    */   /**
/* 325:    */    * @deprecated
/* 326:    */    */
/* 327:    */   public PropertyRendererRegistry getRendererRegistry()
/* 328:    */   {
/* 329:329 */     return (PropertyRendererRegistry)getRendererFactory();
/* 330:    */   }
/* 331:    */   
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */   public boolean isCellEditable(int row, int column)
/* 336:    */   {
/* 337:337 */     if (column == 0) { return false;
/* 338:    */     }
/* 339:339 */     PropertySheetTableModel.Item item = getSheetModel().getPropertySheetElement(row);
/* 340:340 */     return (item.isProperty()) && (item.getProperty().isEditable());
/* 341:    */   }
/* 342:    */   
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */   public TableCellEditor getCellEditor(int row, int column)
/* 348:    */   {
/* 349:349 */     if (column == 0) { return null;
/* 350:    */     }
/* 351:351 */     PropertySheetTableModel.Item item = getSheetModel().getPropertySheetElement(row);
/* 352:352 */     if (!item.isProperty()) {
/* 353:353 */       return null;
/* 354:    */     }
/* 355:355 */     TableCellEditor result = null;
/* 356:356 */     Property propery = item.getProperty();
/* 357:357 */     PropertyEditor editor = getEditorFactory().createPropertyEditor(propery);
/* 358:358 */     if (editor != null) {
/* 359:359 */       result = new CellEditorAdapter(editor);
/* 360:    */     }
/* 361:361 */     return result;
/* 362:    */   }
/* 363:    */   
/* 364:    */ 
/* 365:    */ 
/* 366:    */   public TableCellRenderer getCellRenderer(int row, int column)
/* 367:    */   {
/* 368:368 */     PropertySheetTableModel.Item item = getSheetModel().getPropertySheetElement(row);
/* 369:    */     
/* 370:    */ 
/* 371:371 */     switch (column)
/* 372:    */     {
/* 373:    */     case 0: 
/* 374:374 */       return nameRenderer;
/* 375:    */     
/* 376:    */     case 1: 
/* 377:377 */       if (!item.isProperty()) {
/* 378:378 */         return nameRenderer;
/* 379:    */       }
/* 380:    */       
/* 381:381 */       Property property = item.getProperty();
/* 382:382 */       TableCellRenderer renderer = getRendererFactory().createTableCellRenderer(property);
/* 383:383 */       if (renderer == null)
/* 384:384 */         renderer = getCellRenderer(property.getType());
/* 385:385 */       return renderer;
/* 386:    */     }
/* 387:    */     
/* 388:    */     
/* 389:389 */     return super.getCellRenderer(row, column);
/* 390:    */   }
/* 391:    */   
/* 392:    */ 
/* 393:    */ 
/* 394:    */ 
/* 395:    */ 
/* 396:    */ 
/* 397:    */ 
/* 398:    */   private TableCellRenderer getCellRenderer(Class type)
/* 399:    */   {
/* 400:400 */     TableCellRenderer renderer = getRendererFactory().createTableCellRenderer(type);
/* 401:    */     
/* 402:    */ 
/* 403:403 */     if ((renderer == null) && (type != null)) {
/* 404:404 */       renderer = getCellRenderer(type.getSuperclass());
/* 405:    */     }
/* 406:    */     
/* 407:407 */     if (renderer == null) {
/* 408:408 */       renderer = super.getDefaultRenderer(Object.class);
/* 409:    */     }
/* 410:410 */     return renderer;
/* 411:    */   }
/* 412:    */   
/* 413:    */   public final PropertySheetTableModel getSheetModel() {
/* 414:414 */     return (PropertySheetTableModel)getModel();
/* 415:    */   }
/* 416:    */   
/* 417:    */ 
/* 418:    */ 
/* 419:    */ 
/* 420:    */ 
/* 421:    */ 
/* 422:    */ 
/* 423:    */   public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
/* 424:    */   {
/* 425:425 */     Object value = getValueAt(row, column);
/* 426:426 */     boolean isSelected = isCellSelected(row, column);
/* 427:427 */     Component component = renderer.getTableCellRendererComponent(this, value, isSelected, false, row, column);
/* 428:    */     
/* 429:    */ 
/* 430:430 */     PropertySheetTableModel.Item item = getSheetModel().getPropertySheetElement(row);
/* 431:    */     
/* 432:432 */     if (item.isProperty()) {
/* 433:433 */       component.setEnabled(item.getProperty().isEditable());
/* 434:    */     }
/* 435:435 */     return component;
/* 436:    */   }
/* 437:    */   
/* 438:    */ 
/* 439:    */ 
/* 440:    */ 
/* 441:    */ 
/* 442:    */ 
/* 443:    */ 
/* 444:    */ 
/* 445:    */   public void setModel(TableModel newModel)
/* 446:    */   {
/* 447:447 */     if (!(newModel instanceof PropertySheetTableModel)) {
/* 448:448 */       throw new IllegalArgumentException("dataModel must be of type " + PropertySheetTableModel.class.getName());
/* 449:    */     }
/* 450:    */     
/* 451:    */ 
/* 452:452 */     if (cancelEditing == null) {
/* 453:453 */       cancelEditing = new CancelEditing(null);
/* 454:    */     }
/* 455:    */     
/* 456:456 */     TableModel oldModel = getModel();
/* 457:457 */     if (oldModel != null) {
/* 458:458 */       oldModel.removeTableModelListener(cancelEditing);
/* 459:    */     }
/* 460:460 */     super.setModel(newModel);
/* 461:461 */     newModel.addTableModelListener(cancelEditing);
/* 462:    */     
/* 463:    */ 
/* 464:464 */     getColumnModel().getColumn(1).setResizable(false);
/* 465:    */   }
/* 466:    */   
/* 467:    */ 
/* 468:    */ 
/* 469:    */   public boolean getWantsExtraIndent()
/* 470:    */   {
/* 471:471 */     return wantsExtraIndent;
/* 472:    */   }
/* 473:    */   
/* 474:    */ 
/* 475:    */ 
/* 476:    */ 
/* 477:    */ 
/* 478:    */ 
/* 479:    */ 
/* 480:    */ 
/* 481:    */ 
/* 482:    */   public void setWantsExtraIndent(boolean wantsExtraIndent)
/* 483:    */   {
/* 484:484 */     this.wantsExtraIndent = wantsExtraIndent;
/* 485:485 */     repaint();
/* 486:    */   }
/* 487:    */   
/* 488:    */ 
/* 489:    */ 
/* 490:    */ 
/* 491:    */   public boolean getScrollableTracksViewportHeight()
/* 492:    */   {
/* 493:493 */     return getPreferredSize()height < getParent().getHeight();
/* 494:    */   }
/* 495:    */   
/* 496:    */ 
/* 497:    */ 
/* 498:    */   public void commitEditing()
/* 499:    */   {
/* 500:500 */     TableCellEditor editor = getCellEditor();
/* 501:501 */     if (editor != null) {
/* 502:502 */       editor.stopCellEditing();
/* 503:    */     }
/* 504:    */   }
/* 505:    */   
/* 506:    */ 
/* 507:    */ 
/* 508:    */   public void cancelEditing()
/* 509:    */   {
/* 510:510 */     TableCellEditor editor = getCellEditor();
/* 511:511 */     if (editor != null) {
/* 512:512 */       editor.cancelCellEditing();
/* 513:    */     }
/* 514:    */   }
/* 515:    */   
/* 516:    */   private class CancelEditing implements TableModelListener
/* 517:    */   {
/* 518:    */     CancelEditing(PropertySheetTable.1 x1) {
/* 519:519 */       this();
/* 520:    */     }
/* 521:    */     
/* 522:    */ 
/* 523:    */ 
/* 524:    */ 
/* 525:    */ 
/* 526:    */ 
/* 527:    */ 
/* 528:    */     public void tableChanged(TableModelEvent e)
/* 529:    */     {
/* 530:530 */       if (e.getType() == 0) {
/* 531:531 */         int first = e.getFirstRow();
/* 532:532 */         int last = e.getLastRow();
/* 533:533 */         int editingRow = getEditingRow();
/* 534:    */         
/* 535:535 */         TableCellEditor editor = getCellEditor();
/* 536:536 */         if ((editor != null) && (first <= editingRow) && (editingRow <= last)) {
/* 537:537 */           editor.cancelCellEditing();
/* 538:    */         }
/* 539:    */       }
/* 540:    */     }
/* 541:    */     
/* 542:    */     private CancelEditing() {}
/* 543:    */   }
/* 544:    */   
/* 545:    */   private static class StartEditingAction
/* 546:    */     extends AbstractAction {
/* 547:547 */     StartEditingAction(PropertySheetTable.1 x0) { this(); }
/* 548:    */     
/* 549:549 */     public void actionPerformed(ActionEvent e) { JTable table = (JTable)e.getSource();
/* 550:550 */       if (!table.hasFocus()) {
/* 551:551 */         CellEditor cellEditor = table.getCellEditor();
/* 552:552 */         if ((cellEditor != null) && (!cellEditor.stopCellEditing())) return;
/* 553:553 */         table.requestFocus();
/* 554:554 */         return;
/* 555:    */       }
/* 556:556 */       ListSelectionModel rsm = table.getSelectionModel();
/* 557:557 */       int anchorRow = rsm.getAnchorSelectionIndex();
/* 558:558 */       table.editCellAt(anchorRow, 1);
/* 559:559 */       Component editorComp = table.getEditorComponent();
/* 560:560 */       if (editorComp != null) {
/* 561:561 */         editorComp.requestFocus();
/* 562:    */       }
/* 563:    */     }
/* 564:    */     
/* 565:    */     private StartEditingAction() {}
/* 566:    */   }
/* 567:    */   
/* 568:    */   private class ToggleAction
/* 569:    */     extends AbstractAction {
/* 570:570 */     ToggleAction(PropertySheetTable.1 x1) { this(); }
/* 571:    */     
/* 572:572 */     public void actionPerformed(ActionEvent e) { int row = getSelectedRow();
/* 573:573 */       PropertySheetTableModel.Item item = getSheetModel().getPropertySheetElement(row);
/* 574:    */       
/* 575:575 */       item.toggle();
/* 576:576 */       addRowSelectionInterval(row, row);
/* 577:    */     }
/* 578:    */     
/* 579:579 */     public boolean isEnabled() { int row = getSelectedRow();
/* 580:580 */       if (row != -1) {
/* 581:581 */         PropertySheetTableModel.Item item = getSheetModel().getPropertySheetElement(row);
/* 582:    */         
/* 583:583 */         return item.hasToggle();
/* 584:    */       }
/* 585:585 */       return false;
/* 586:    */     }
/* 587:    */     
/* 588:    */     private ToggleAction() {}
/* 589:    */   }
/* 590:    */   
/* 591:    */   private static class ToggleMouseHandler
/* 592:    */     extends MouseAdapter {
/* 593:593 */     ToggleMouseHandler(PropertySheetTable.1 x0) { this(); }
/* 594:    */     
/* 595:595 */     public void mouseReleased(MouseEvent event) { PropertySheetTable table = (PropertySheetTable)event.getComponent();
/* 596:596 */       int row = table.rowAtPoint(event.getPoint());
/* 597:597 */       int column = table.columnAtPoint(event.getPoint());
/* 598:598 */       if ((row != -1) && (column == 0))
/* 599:    */       {
/* 600:600 */         PropertySheetTableModel.Item item = table.getSheetModel().getPropertySheetElement(row);
/* 601:601 */         int x = event.getX() - PropertySheetTable.getIndent(table, item);
/* 602:602 */         if ((x > 0) && (x < 18)) {
/* 603:603 */           item.toggle();
/* 604:    */         }
/* 605:    */       }
/* 606:    */     }
/* 607:    */     
/* 608:    */     private ToggleMouseHandler() {}
/* 609:    */   }
/* 610:    */   
/* 611:    */   static int getIndent(PropertySheetTable table, PropertySheetTableModel.Item item)
/* 612:    */   {
/* 613:613 */     int indent = 0;
/* 614:    */     
/* 615:615 */     if (item.isProperty())
/* 616:    */     {
/* 617:617 */       if (((item.getParent() == null) || (!item.getParent().isProperty())) && (!item.hasToggle()))
/* 618:    */       {
/* 619:619 */         indent = table.getWantsExtraIndent() ? 18 : 0;
/* 620:    */ 
/* 621:    */       }
/* 622:622 */       else if (item.hasToggle()) {
/* 623:623 */         indent = item.getDepth() * 18;
/* 624:    */       } else {
/* 625:625 */         indent = (item.getDepth() + 1) * 18;
/* 626:    */       }
/* 627:    */       
/* 628:    */ 
/* 629:629 */       if ((table.getSheetModel().getMode() == 1) && (table.getWantsExtraIndent()))
/* 630:    */       {
/* 631:631 */         indent += 18;
/* 632:    */       }
/* 633:    */     }
/* 634:    */     else
/* 635:    */     {
/* 636:636 */       indent = 0;
/* 637:    */     }
/* 638:638 */     return indent;
/* 639:    */   }
/* 640:    */   
/* 641:    */ 
/* 642:    */   private static class CellBorder
/* 643:    */     implements Border
/* 644:    */   {
/* 645:    */     private int indentWidth;
/* 646:    */     
/* 647:    */     private boolean showToggle;
/* 648:    */     
/* 649:    */     private boolean toggleState;
/* 650:    */     private Icon expandedIcon;
/* 651:    */     private Icon collapsedIcon;
/* 652:652 */     private Insets insets = new Insets(1, 0, 1, 1);
/* 653:    */     private boolean isProperty;
/* 654:    */     
/* 655:    */     public CellBorder() {
/* 656:656 */       expandedIcon = ((Icon)UIManager.get("Tree.expandedIcon"));
/* 657:657 */       collapsedIcon = ((Icon)UIManager.get("Tree.collapsedIcon"));
/* 658:658 */       if (expandedIcon == null) {
/* 659:659 */         expandedIcon = new PropertySheetTable.ExpandedIcon(null);
/* 660:    */       }
/* 661:661 */       if (collapsedIcon == null) {
/* 662:662 */         collapsedIcon = new PropertySheetTable.CollapsedIcon(null);
/* 663:    */       }
/* 664:    */     }
/* 665:    */     
/* 666:    */     public void configure(PropertySheetTable table, PropertySheetTableModel.Item item) {
/* 667:667 */       isProperty = item.isProperty();
/* 668:668 */       toggleState = item.isVisible();
/* 669:669 */       showToggle = item.hasToggle();
/* 670:    */       
/* 671:671 */       indentWidth = PropertySheetTable.getIndent(table, item);
/* 672:672 */       insets.left = (indentWidth + (showToggle ? 18 : 0) + 2);
/* 673:    */     }
/* 674:    */     
/* 675:    */     public Insets getBorderInsets(Component c) {
/* 676:676 */       return insets;
/* 677:    */     }
/* 678:    */     
/* 679:    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/* 680:    */     {
/* 681:681 */       if (!isProperty) {
/* 682:682 */         Color oldColor = g.getColor();
/* 683:683 */         g.setColor(c.getBackground());
/* 684:684 */         g.fillRect(x, y, x + 18 - 2, y + height);
/* 685:685 */         g.setColor(oldColor);
/* 686:    */       }
/* 687:    */       
/* 688:688 */       if (showToggle) {
/* 689:689 */         Icon drawIcon = toggleState ? expandedIcon : collapsedIcon;
/* 690:690 */         drawIcon.paintIcon(c, g, x + indentWidth + (16 - drawIcon.getIconWidth()) / 2, y + (height - drawIcon.getIconHeight()) / 2);
/* 691:    */       }
/* 692:    */     }
/* 693:    */     
/* 694:    */ 
/* 695:    */     public boolean isBorderOpaque()
/* 696:    */     {
/* 697:697 */       return true;
/* 698:    */     }
/* 699:    */   }
/* 700:    */   
/* 701:    */   private static class ExpandedIcon implements Icon {
/* 702:702 */     ExpandedIcon(PropertySheetTable.1 x0) { this(); }
/* 703:    */     
/* 704:704 */     public void paintIcon(Component c, Graphics g, int x, int y) { Color backgroundColor = c.getBackground();
/* 705:    */       
/* 706:706 */       if (backgroundColor != null)
/* 707:707 */         g.setColor(backgroundColor); else
/* 708:708 */         g.setColor(Color.white);
/* 709:709 */       g.fillRect(x, y, 8, 8);
/* 710:710 */       g.setColor(Color.gray);
/* 711:711 */       g.drawRect(x, y, 8, 8);
/* 712:712 */       g.setColor(Color.black);
/* 713:713 */       g.drawLine(x + 2, y + 4, x + 6, y + 4);
/* 714:    */     }
/* 715:    */     
/* 716:716 */     public int getIconWidth() { return 9; }
/* 717:    */     
/* 718:    */ 
/* 719:719 */     public int getIconHeight() { return 9; }
/* 720:    */     
/* 721:    */     private ExpandedIcon() {} }
/* 722:    */   
/* 723:723 */   private static class CollapsedIcon extends PropertySheetTable.ExpandedIcon { CollapsedIcon(PropertySheetTable.1 x0) { this(); } private CollapsedIcon() { super(); }
/* 724:    */     
/* 725:725 */     public void paintIcon(Component c, Graphics g, int x, int y) { super.paintIcon(c, g, x, y);
/* 726:726 */       g.drawLine(x + 4, y + 2, x + 4, y + 6);
/* 727:    */     }
/* 728:    */   }
/* 729:    */   
/* 730:    */ 
/* 731:    */   private class NameRenderer
/* 732:    */     extends DefaultTableCellRenderer
/* 733:    */   {
/* 734:    */     private PropertySheetTable.CellBorder border;
/* 735:    */     
/* 736:    */     public NameRenderer()
/* 737:    */     {
/* 738:738 */       border = new PropertySheetTable.CellBorder();
/* 739:    */     }
/* 740:    */     
/* 741:    */     private Color getForeground(boolean isProperty, boolean isSelected) {
/* 742:742 */       return isSelected ? selectedCategoryForeground : isProperty ? propertyForeground : isSelected ? selectedPropertyForeground : categoryForeground;
/* 743:    */     }
/* 744:    */     
/* 745:    */     private Color getBackground(boolean isProperty, boolean isSelected)
/* 746:    */     {
/* 747:747 */       return isSelected ? selectedCategoryBackground : isProperty ? propertyBackground : isSelected ? selectedPropertyBackground : categoryBackground;
/* 748:    */     }
/* 749:    */     
/* 750:    */ 
/* 751:    */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 752:    */     {
/* 753:753 */       super.getTableCellRendererComponent(table, value, isSelected, false, row, column);
/* 754:754 */       PropertySheetTableModel.Item item = (PropertySheetTableModel.Item)value;
/* 755:    */       
/* 756:    */ 
/* 757:757 */       if ((column == 1) && (!item.isProperty())) {
/* 758:758 */         setBackground(getBackground(item.isProperty(), isSelected));
/* 759:759 */         setText("");
/* 760:760 */         return this;
/* 761:    */       }
/* 762:    */       
/* 763:763 */       setBorder(border);
/* 764:    */       
/* 765:    */ 
/* 766:766 */       border.configure((PropertySheetTable)table, item);
/* 767:    */       
/* 768:768 */       setBackground(getBackground(item.isProperty(), isSelected));
/* 769:769 */       setForeground(getForeground(item.isProperty(), isSelected));
/* 770:    */       
/* 771:771 */       setEnabled((isSelected) || (!item.isProperty()) ? true : item.getProperty().isEditable());
/* 772:772 */       setText(item.getName());
/* 773:    */       
/* 774:774 */       return this;
/* 775:    */     }
/* 776:    */   }
/* 777:    */ }
