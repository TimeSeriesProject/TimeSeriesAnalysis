/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.ExtendedPropertyDescriptor;
/*   4:    */ import java.beans.PropertyDescriptor;
/*   5:    */ import java.beans.PropertyVetoException;
/*   6:    */ import java.lang.reflect.InvocationTargetException;
/*   7:    */ import java.lang.reflect.Method;
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ class PropertyDescriptorAdapter
/*  32:    */   extends AbstractProperty
/*  33:    */ {
/*  34:    */   private PropertyDescriptor descriptor;
/*  35:    */   
/*  36:    */   public PropertyDescriptorAdapter() {}
/*  37:    */   
/*  38:    */   public PropertyDescriptorAdapter(PropertyDescriptor descriptor)
/*  39:    */   {
/*  40: 40 */     this();
/*  41: 41 */     setDescriptor(descriptor);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setDescriptor(PropertyDescriptor descriptor) {
/*  45: 45 */     this.descriptor = descriptor;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public PropertyDescriptor getDescriptor() {
/*  49: 49 */     return descriptor;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public String getName() {
/*  53: 53 */     return descriptor.getName();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getDisplayName() {
/*  57: 57 */     return descriptor.getDisplayName();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getShortDescription() {
/*  61: 61 */     return descriptor.getShortDescription();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public Class getType() {
/*  65: 65 */     return descriptor.getPropertyType();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Object clone() {
/*  69: 69 */     PropertyDescriptorAdapter clone = new PropertyDescriptorAdapter(descriptor);
/*  70: 70 */     clone.setValue(getValue());
/*  71: 71 */     return clone;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void readFromObject(Object object) {
/*  75:    */     try {
/*  76: 76 */       Method method = descriptor.getReadMethod();
/*  77: 77 */       if (method != null) {
/*  78: 78 */         setValue(method.invoke(object, null));
/*  79:    */       }
/*  80:    */     } catch (Exception e) {
/*  81: 81 */       String message = "Got exception when reading property " + getName();
/*  82: 82 */       if (object == null) {
/*  83: 83 */         message = message + ", object was 'null'";
/*  84:    */       } else {
/*  85: 85 */         message = message + ", object was " + String.valueOf(object);
/*  86:    */       }
/*  87: 87 */       throw new RuntimeException(message, e);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void writeToObject(Object object) {
/*  92:    */     try {
/*  93: 93 */       Method method = descriptor.getWriteMethod();
/*  94: 94 */       if (method != null) {
/*  95: 95 */         method.invoke(object, new Object[] { getValue() });
/*  96:    */       }
/*  97:    */     }
/*  98:    */     catch (Exception e) {
/*  99: 99 */       if (((e instanceof InvocationTargetException)) && ((((InvocationTargetException)e).getTargetException() instanceof PropertyVetoException)))
/* 100:    */       {
/* 101:101 */         throw new RuntimeException(((InvocationTargetException)e).getTargetException());
/* 102:    */       }
/* 103:    */       
/* 104:104 */       String message = "Got exception when writing property " + getName();
/* 105:105 */       if (object == null) {
/* 106:106 */         message = message + ", object was 'null'";
/* 107:    */       } else {
/* 108:108 */         message = message + ", object was " + String.valueOf(object);
/* 109:    */       }
/* 110:110 */       throw new RuntimeException(message, e);
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   public boolean isEditable() {
/* 115:115 */     return descriptor.getWriteMethod() != null;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public String getCategory() {
/* 119:119 */     if ((descriptor instanceof ExtendedPropertyDescriptor)) {
/* 120:120 */       return ((ExtendedPropertyDescriptor)descriptor).getCategory();
/* 121:    */     }
/* 122:122 */     return null;
/* 123:    */   }
/* 124:    */ }
