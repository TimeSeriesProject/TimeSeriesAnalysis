/*  1:   */ package com.l2fprod.common.propertysheet;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.BaseDialog;
/*  4:   */ import java.awt.Dialog;
/*  5:   */ import java.awt.Frame;
/*  6:   */ import java.awt.GraphicsConfiguration;
/*  7:   */ import java.awt.HeadlessException;
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ public class PropertySheetDialog
/* 29:   */   extends BaseDialog
/* 30:   */ {
/* 31:   */   public PropertySheetDialog()
/* 32:   */     throws HeadlessException
/* 33:   */   {}
/* 34:   */   
/* 35:   */   public PropertySheetDialog(Dialog owner)
/* 36:   */     throws HeadlessException
/* 37:   */   {
/* 38:38 */     super(owner);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public PropertySheetDialog(Dialog owner, boolean modal) throws HeadlessException
/* 42:   */   {
/* 43:43 */     super(owner, modal);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public PropertySheetDialog(Frame owner) throws HeadlessException {
/* 47:47 */     super(owner);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public PropertySheetDialog(Frame owner, boolean modal) throws HeadlessException
/* 51:   */   {
/* 52:52 */     super(owner, modal);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public PropertySheetDialog(Dialog owner, String title) throws HeadlessException
/* 56:   */   {
/* 57:57 */     super(owner, title);
/* 58:   */   }
/* 59:   */   
/* 60:   */   public PropertySheetDialog(Dialog owner, String title, boolean modal) throws HeadlessException
/* 61:   */   {
/* 62:62 */     super(owner, title, modal);
/* 63:   */   }
/* 64:   */   
/* 65:   */   public PropertySheetDialog(Frame owner, String title) throws HeadlessException
/* 66:   */   {
/* 67:67 */     super(owner, title);
/* 68:   */   }
/* 69:   */   
/* 70:   */   public PropertySheetDialog(Frame owner, String title, boolean modal) throws HeadlessException
/* 71:   */   {
/* 72:72 */     super(owner, title, modal);
/* 73:   */   }
/* 74:   */   
/* 75:   */ 
/* 76:   */ 
/* 77:   */ 
/* 78:   */   public PropertySheetDialog(Dialog owner, String title, boolean modal, GraphicsConfiguration gc)
/* 79:   */     throws HeadlessException
/* 80:   */   {
/* 81:81 */     super(owner, title, modal, gc);
/* 82:   */   }
/* 83:   */   
/* 84:   */ 
/* 85:   */ 
/* 86:   */ 
/* 87:   */   public PropertySheetDialog(Frame owner, String title, boolean modal, GraphicsConfiguration gc)
/* 88:   */   {
/* 89:89 */     super(owner, title, modal, gc);
/* 90:   */   }
/* 91:   */ }
