/*   1:    */ package com.l2fprod.common.propertysheet;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.event.ActionEvent;
/*   5:    */ import java.awt.event.ActionListener;
/*   6:    */ import java.awt.event.FocusEvent;
/*   7:    */ import java.awt.event.FocusListener;
/*   8:    */ import java.awt.event.MouseEvent;
/*   9:    */ import java.beans.PropertyChangeEvent;
/*  10:    */ import java.beans.PropertyChangeListener;
/*  11:    */ import java.beans.PropertyEditor;
/*  12:    */ import java.util.EventObject;
/*  13:    */ import javax.swing.AbstractCellEditor;
/*  14:    */ import javax.swing.JTable;
/*  15:    */ import javax.swing.JTextField;
/*  16:    */ import javax.swing.JTree;
/*  17:    */ import javax.swing.KeyStroke;
/*  18:    */ import javax.swing.SwingUtilities;
/*  19:    */ import javax.swing.table.TableCellEditor;
/*  20:    */ import javax.swing.tree.TreeCellEditor;
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ public class CellEditorAdapter
/*  46:    */   extends AbstractCellEditor
/*  47:    */   implements TableCellEditor, TreeCellEditor
/*  48:    */ {
/*  49:    */   protected PropertyEditor editor;
/*  50: 50 */   protected int clickCountToStart = 1;
/*  51:    */   
/*  52:    */   class CommitEditing implements ActionListener { CommitEditing() {}
/*  53:    */     
/*  54: 54 */     public void actionPerformed(ActionEvent e) { stopCellEditing(); }
/*  55:    */   }
/*  56:    */   
/*  57:    */   class CancelEditing implements ActionListener {
/*  58:    */     CancelEditing() {}
/*  59:    */     
/*  60: 60 */     public void actionPerformed(ActionEvent e) { cancelCellEditing(); }
/*  61:    */   }
/*  62:    */   
/*  63:    */   class SelectOnFocus implements FocusListener
/*  64:    */   {
/*  65:    */     SelectOnFocus() {}
/*  66:    */     
/*  67:    */     public void focusGained(FocusEvent e)
/*  68:    */     {
/*  69: 69 */       if (!(e.getSource() instanceof JTextField))
/*  70: 70 */         return;
/*  71: 71 */       SwingUtilities.invokeLater(new CellEditorAdapter.1(this, e));
/*  72:    */     }
/*  73:    */     
/*  74:    */ 
/*  75:    */ 
/*  76:    */     public void focusLost(FocusEvent e)
/*  77:    */     {
/*  78: 78 */       if (!(e.getSource() instanceof JTextField))
/*  79: 79 */         return;
/*  80: 80 */       SwingUtilities.invokeLater(new CellEditorAdapter.2(this, e));
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */   public CellEditorAdapter(PropertyEditor editor)
/*  88:    */   {
/*  89: 89 */     this.editor = editor;
/*  90: 90 */     Component component = editor.getCustomEditor();
/*  91: 91 */     if ((component instanceof JTextField)) {
/*  92: 92 */       JTextField field = (JTextField)component;
/*  93: 93 */       field.addFocusListener(new SelectOnFocus());
/*  94: 94 */       field.addActionListener(new CommitEditing());
/*  95: 95 */       field.registerKeyboardAction(new CancelEditing(), KeyStroke.getKeyStroke(27, 0), 0);
/*  96:    */     }
/*  97:    */     
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:102 */     editor.addPropertyChangeListener(new PropertyChangeListener() {
/* 103:    */       public void propertyChange(PropertyChangeEvent evt) {
/* 104:104 */         stopCellEditing();
/* 105:    */       }
/* 106:    */     });
/* 107:    */   }
/* 108:    */   
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */   public Component getTreeCellEditorComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row)
/* 115:    */   {
/* 116:116 */     return getEditor(value);
/* 117:    */   }
/* 118:    */   
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */   public Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int row, int column)
/* 124:    */   {
/* 125:125 */     return getEditor(value);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setClickCountToStart(int count) {
/* 129:129 */     clickCountToStart = count;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public int getClickCountToStart() {
/* 133:133 */     return clickCountToStart;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public Object getCellEditorValue() {
/* 137:137 */     return editor.getValue();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public boolean isCellEditable(EventObject event) {
/* 141:141 */     if ((event instanceof MouseEvent)) {
/* 142:142 */       return ((MouseEvent)event).getClickCount() >= clickCountToStart;
/* 143:    */     }
/* 144:144 */     return true;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public boolean shouldSelectCell(EventObject event) {
/* 148:148 */     return true;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean stopCellEditing() {
/* 152:152 */     fireEditingStopped();
/* 153:153 */     return true;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void cancelCellEditing() {
/* 157:157 */     fireEditingCanceled();
/* 158:    */   }
/* 159:    */   
/* 160:    */   private Component getEditor(Object value) {
/* 161:161 */     editor.setValue(value);
/* 162:    */     
/* 163:163 */     Component cellEditor = editor.getCustomEditor();
/* 164:    */     
/* 165:    */ 
/* 166:    */ 
/* 167:167 */     SwingUtilities.invokeLater(new Runnable() { private final Component val$cellEditor;
/* 168:    */       
/* 169:169 */       public void run() { val$cellEditor.requestFocus();
/* 170:    */       }
/* 171:    */ 
/* 172:172 */     });
/* 173:173 */     return cellEditor;
/* 174:    */   }
/* 175:    */ }
