/*  1:   */ package com.l2fprod.common.propertysheet;
/*  2:   */ 
/*  3:   */ import java.beans.PropertyChangeListener;
/*  4:   */ import java.beans.PropertyChangeSupport;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.ObjectInputStream;
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ public abstract class AbstractProperty
/* 30:   */   implements Property
/* 31:   */ {
/* 32:   */   private Object value;
/* 33:33 */   private transient PropertyChangeSupport listeners = new PropertyChangeSupport(this);
/* 34:   */   
/* 35:   */   public Object getValue()
/* 36:   */   {
/* 37:37 */     return value;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Object clone() {
/* 41:41 */     AbstractProperty clone = null;
/* 42:   */     try {
/* 43:43 */       return (AbstractProperty)super.clone();
/* 44:   */     }
/* 45:   */     catch (CloneNotSupportedException e) {
/* 46:46 */       throw new RuntimeException(e);
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void setValue(Object value) {
/* 51:51 */     Object oldValue = this.value;
/* 52:52 */     this.value = value;
/* 53:53 */     if ((value != oldValue) && ((value == null) || (!value.equals(oldValue))))
/* 54:54 */       firePropertyChange(oldValue, getValue());
/* 55:   */   }
/* 56:   */   
/* 57:   */   protected void initializeValue(Object value) {
/* 58:58 */     this.value = value;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 62:62 */     listeners.addPropertyChangeListener(listener);
/* 63:63 */     Property[] subProperties = getSubProperties();
/* 64:64 */     if (subProperties != null)
/* 65:65 */       for (int i = 0; i < subProperties.length; i++)
/* 66:66 */         subProperties[i].addPropertyChangeListener(listener);
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 70:70 */     listeners.removePropertyChangeListener(listener);
/* 71:71 */     Property[] subProperties = getSubProperties();
/* 72:72 */     if (subProperties != null)
/* 73:73 */       for (int i = 0; i < subProperties.length; i++)
/* 74:74 */         subProperties[i].removePropertyChangeListener(listener);
/* 75:   */   }
/* 76:   */   
/* 77:   */   protected void firePropertyChange(Object oldValue, Object newValue) {
/* 78:78 */     listeners.firePropertyChange("value", oldValue, newValue);
/* 79:   */   }
/* 80:   */   
/* 81:   */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/* 82:   */   {
/* 83:83 */     in.defaultReadObject();
/* 84:84 */     listeners = new PropertyChangeSupport(this);
/* 85:   */   }
/* 86:   */   
/* 87:   */   public Property getParentProperty() {
/* 88:88 */     return null;
/* 89:   */   }
/* 90:   */   
/* 91:   */   public Property[] getSubProperties() {
/* 92:92 */     return null;
/* 93:   */   }
/* 94:   */ }
