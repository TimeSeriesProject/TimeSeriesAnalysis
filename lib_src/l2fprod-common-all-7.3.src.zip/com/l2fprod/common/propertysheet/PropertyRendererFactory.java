package com.l2fprod.common.propertysheet;

import javax.swing.table.TableCellRenderer;

public abstract interface PropertyRendererFactory
{
  public abstract TableCellRenderer createTableCellRenderer(Property paramProperty);
  
  public abstract TableCellRenderer createTableCellRenderer(Class paramClass);
}
