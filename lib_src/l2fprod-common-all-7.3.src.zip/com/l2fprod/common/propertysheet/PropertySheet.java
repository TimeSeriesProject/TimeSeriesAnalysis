package com.l2fprod.common.propertysheet;

import java.util.Iterator;

public abstract interface PropertySheet
{
  public static final int VIEW_AS_FLAT_LIST = 0;
  public static final int VIEW_AS_CATEGORIES = 1;
  
  public abstract void setProperties(Property[] paramArrayOfProperty);
  
  public abstract Property[] getProperties();
  
  public abstract void addProperty(Property paramProperty);
  
  public abstract void addProperty(int paramInt, Property paramProperty);
  
  public abstract void removeProperty(Property paramProperty);
  
  public abstract int getPropertyCount();
  
  public abstract Iterator propertyIterator();
}
