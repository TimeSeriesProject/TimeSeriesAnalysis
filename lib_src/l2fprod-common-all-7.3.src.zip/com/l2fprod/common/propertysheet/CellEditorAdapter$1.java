/*  1:   */ package com.l2fprod.common.propertysheet;
/*  2:   */ 
/*  3:   */ import java.awt.event.FocusEvent;
/*  4:   */ import javax.swing.JTextField;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:   */ 
/* 59:   */ 
/* 60:   */ 
/* 61:   */ 
/* 62:   */ 
/* 63:   */ 
/* 64:   */ class CellEditorAdapter$1
/* 65:   */   implements Runnable
/* 66:   */ {
/* 67:   */   private final FocusEvent val$e;
/* 68:   */   private final CellEditorAdapter.SelectOnFocus this$1;
/* 69:   */   
/* 70:   */   CellEditorAdapter$1(CellEditorAdapter.SelectOnFocus this$1, FocusEvent val$e)
/* 71:   */   {
/* 72:72 */     this.this$1 = this$1;this.val$e = val$e; }
/* 73:73 */   public void run() { ((JTextField)val$e.getSource()).selectAll(); }
/* 74:   */ }
