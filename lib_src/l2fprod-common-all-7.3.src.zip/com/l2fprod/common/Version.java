/*  1:   */ package com.l2fprod.common;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ public class Version
/* 15:   */ {
/* 16:16 */   private static Date buildDate = new Date(1174140814898L);
/* 17:   */   
/* 18:   */ 
/* 19:   */ 
/* 20:   */   public static final Date getBuildDate()
/* 21:   */   {
/* 22:22 */     return buildDate;
/* 23:   */   }
/* 24:   */   
/* 25:   */ 
/* 26:26 */   private static String buildTimestamp = new String("03/17/2007 03:13 PM");
/* 27:   */   
/* 28:   */ 
/* 29:   */ 
/* 30:   */   public static final String getBuildTimestamp()
/* 31:   */   {
/* 32:32 */     return buildTimestamp;
/* 33:   */   }
/* 34:   */   
/* 35:   */ 
/* 36:36 */   private static String year = new String("2005-2007");
/* 37:   */   
/* 38:   */ 
/* 39:   */ 
/* 40:   */   public static final String getYear()
/* 41:   */   {
/* 42:42 */     return year;
/* 43:   */   }
/* 44:   */   
/* 45:   */ 
/* 46:46 */   private static String version = new String("7.3");
/* 47:   */   
/* 48:   */ 
/* 49:   */ 
/* 50:   */   public static final String getVersion()
/* 51:   */   {
/* 52:52 */     return version;
/* 53:   */   }
/* 54:   */   
/* 55:   */ 
/* 56:56 */   private static String project = new String("l2fprod-common");
/* 57:   */   
/* 58:   */ 
/* 59:   */ 
/* 60:   */   public static final String getProject()
/* 61:   */   {
/* 62:62 */     return project;
/* 63:   */   }
/* 64:   */ }
