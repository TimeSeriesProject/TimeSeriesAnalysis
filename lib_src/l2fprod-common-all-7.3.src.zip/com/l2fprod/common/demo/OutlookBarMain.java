/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JOutlookBar;
/*   4:    */ import com.l2fprod.common.swing.PercentLayout;
/*   5:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   6:    */ import com.l2fprod.common.swing.plaf.metal.MetalLookAndFeelAddons;
/*   7:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*   8:    */ import java.awt.BorderLayout;
/*   9:    */ import java.awt.Container;
/*  10:    */ import javax.swing.ImageIcon;
/*  11:    */ import javax.swing.JButton;
/*  12:    */ import javax.swing.JFrame;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.JScrollPane;
/*  15:    */ import javax.swing.JTabbedPane;
/*  16:    */ import javax.swing.JTree;
/*  17:    */ import javax.swing.UIManager;
/*  18:    */ import javax.swing.plaf.ButtonUI;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public class OutlookBarMain
/*  41:    */   extends JPanel
/*  42:    */ {
/*  43:    */   public OutlookBarMain()
/*  44:    */     throws Exception
/*  45:    */   {
/*  46: 46 */     setLayout(new BorderLayout());
/*  47:    */     
/*  48: 48 */     JTabbedPane tabs = new JTabbedPane();
/*  49:    */     
/*  50:    */ 
/*  51: 51 */     UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
/*  52:    */     
/*  53: 53 */     LookAndFeelAddons.setAddon(MetalLookAndFeelAddons.class);
/*  54: 54 */     tabs.addTab("Metal L&F", makeOutlookPanel(0));
/*  55:    */     
/*  56:    */ 
/*  57: 57 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*  58:    */     
/*  59:    */ 
/*  60: 60 */     LookAndFeelAddons.setAddon(WindowsLookAndFeelAddons.class);
/*  61: 61 */     tabs.addTab("Windows L&F", makeOutlookPanel(2));
/*  62:    */     
/*  63:    */ 
/*  64: 64 */     add("Center", tabs);
/*  65:    */   }
/*  66:    */   
/*  67:    */   JPanel makeOutlookPanel(int alignment) {
/*  68: 68 */     JOutlookBar outlook = new JOutlookBar();
/*  69: 69 */     outlook.setTabPlacement(2);
/*  70: 70 */     addTab(outlook, "Folders");
/*  71: 71 */     addTab(outlook, "Backup");
/*  72:    */     
/*  73:    */ 
/*  74: 74 */     JTree tree = new JTree();
/*  75: 75 */     outlook.addTab("A JTree", outlook.makeScrollPane(tree));
/*  76:    */     
/*  77: 77 */     outlook.addTab("Disabled", new JButton());
/*  78: 78 */     outlook.setEnabledAt(3, false);
/*  79: 79 */     outlook.setAllTabsAlignment(alignment);
/*  80:    */     
/*  81: 81 */     JPanel panel = new JPanel(new PercentLayout(0, 3));
/*  82: 82 */     panel.add(outlook, "100");
/*  83: 83 */     return panel;
/*  84:    */   }
/*  85:    */   
/*  86:    */   void addTab(JOutlookBar tabs, String title) {
/*  87: 87 */     JPanel panel = new JPanel();
/*  88: 88 */     panel.setLayout(new PercentLayout(1, 0));
/*  89: 89 */     panel.setOpaque(false);
/*  90:    */     
/*  91: 91 */     String[] buttons = { "Inbox", "icons/outlook-inbox.gif", "Outbox", "icons/outlook-outbox.gif", "Drafts", "icons/outlook-inbox.gif", "Templates", "icons/outlook-inbox.gif", "Deleted Items", "icons/outlook-trash.gif" };
/*  92:    */     
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96: 96 */     int i = 0; for (int c = buttons.length; i < c; i += 2) {
/*  97: 97 */       JButton button = new JButton(buttons[i]);
/*  98:    */       try {
/*  99: 99 */         button.setUI((ButtonUI)Class.forName((String)UIManager.get("OutlookButtonUI")).newInstance());
/* 100:    */       }
/* 101:    */       catch (Exception e) {
/* 102:102 */         e.printStackTrace();
/* 103:    */       }
/* 104:104 */       button.setIcon(new ImageIcon(OutlookBarMain.class.getResource(buttons[(i + 1)])));
/* 105:    */       
/* 106:106 */       panel.add(button);
/* 107:    */     }
/* 108:    */     
/* 109:109 */     JScrollPane scroll = tabs.makeScrollPane(panel);
/* 110:110 */     tabs.addTab("", scroll);
/* 111:    */     
/* 112:    */ 
/* 113:113 */     int index = tabs.indexOfComponent(scroll);
/* 114:114 */     tabs.setTitleAt(index, title);
/* 115:115 */     tabs.setToolTipTextAt(index, title + " Tooltip");
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static void main(String[] args) throws Exception {
/* 119:119 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 120:    */     
/* 121:121 */     JFrame frame = new JFrame("JOutlookBar");
/* 122:122 */     frame.getContentPane().setLayout(new BorderLayout());
/* 123:123 */     frame.getContentPane().add("Center", new OutlookBarMain());
/* 124:124 */     frame.setDefaultCloseOperation(3);
/* 125:125 */     frame.pack();
/* 126:126 */     frame.setLocation(100, 100);
/* 127:127 */     frame.setVisible(true);
/* 128:    */   }
/* 129:    */ }
