/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JTaskPane;
/*   4:    */ import com.l2fprod.common.swing.JTaskPaneGroup;
/*   5:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   6:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   7:    */ import com.l2fprod.common.swing.plaf.aqua.AquaLookAndFeelAddons;
/*   8:    */ import com.l2fprod.common.swing.plaf.metal.MetalLookAndFeelAddons;
/*   9:    */ import com.l2fprod.common.swing.plaf.windows.WindowsClassicLookAndFeelAddons;
/*  10:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*  11:    */ import com.l2fprod.common.util.ResourceManager;
/*  12:    */ import java.awt.BorderLayout;
/*  13:    */ import java.awt.Container;
/*  14:    */ import javax.swing.Action;
/*  15:    */ import javax.swing.ImageIcon;
/*  16:    */ import javax.swing.JEditorPane;
/*  17:    */ import javax.swing.JFrame;
/*  18:    */ import javax.swing.JPanel;
/*  19:    */ import javax.swing.JScrollPane;
/*  20:    */ import javax.swing.JTabbedPane;
/*  21:    */ import javax.swing.UIManager;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ public class TaskPaneMain
/*  47:    */   extends JPanel
/*  48:    */ {
/*  49: 49 */   static ResourceManager RESOURCE = ResourceManager.get(TaskPaneMain.class);
/*  50:    */   
/*  51:    */   public TaskPaneMain() throws Exception {
/*  52: 52 */     setLayout(new BorderLayout());
/*  53:    */     
/*  54: 54 */     JTabbedPane tabs = new JTabbedPane();
/*  55:    */     
/*  56:    */ 
/*  57: 57 */     UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
/*  58: 58 */     LookAndFeelAddons.setAddon(MetalLookAndFeelAddons.class);
/*  59: 59 */     DemoPanel demo = new DemoPanel();
/*  60: 60 */     tabs.addTab("Metal L&F", demo);
/*  61:    */     
/*  62:    */ 
/*  63: 63 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*  64:    */     
/*  65:    */ 
/*  66: 66 */     UIManager.put("win.xpstyle.name", "luna");
/*  67: 67 */     LookAndFeelAddons.setAddon(WindowsLookAndFeelAddons.class);
/*  68: 68 */     DemoPanel demo = new DemoPanel();
/*  69: 69 */     tabs.addTab("Windows L&F (Luna)", demo);
/*  70:    */     
/*  71:    */ 
/*  72:    */ 
/*  73: 73 */     UIManager.put("win.xpstyle.name", "homestead");
/*  74: 74 */     LookAndFeelAddons.setAddon(WindowsLookAndFeelAddons.class);
/*  75: 75 */     DemoPanel demo = new DemoPanel();
/*  76: 76 */     tabs.addTab("Windows L&F (Homestead)", demo);
/*  77:    */     
/*  78:    */ 
/*  79:    */ 
/*  80: 80 */     UIManager.put("win.xpstyle.name", "metallic");
/*  81: 81 */     LookAndFeelAddons.setAddon(WindowsLookAndFeelAddons.class);
/*  82: 82 */     DemoPanel demo = new DemoPanel();
/*  83: 83 */     tabs.addTab("Windows L&F (Metallic)", demo);
/*  84:    */     
/*  85:    */ 
/*  86: 86 */     UIManager.put("win.xpstyle.name", null);
/*  87:    */     
/*  88:    */ 
/*  89: 89 */     LookAndFeelAddons.setAddon(WindowsClassicLookAndFeelAddons.class);
/*  90: 90 */     DemoPanel demo = new DemoPanel();
/*  91: 91 */     tabs.addTab("Windows L&F (Classic)", demo);
/*  92:    */     
/*  93:    */ 
/*  94:    */ 
/*  95: 95 */     LookAndFeelAddons.setAddon(AquaLookAndFeelAddons.class);
/*  96: 96 */     DemoPanel demo = new DemoPanel();
/*  97: 97 */     tabs.addTab("Glossy", demo);
/*  98:    */     
/*  99:    */ 
/* 100:    */     try
/* 101:    */     {
/* 102:102 */       Class.forName("com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
/* 103:103 */       UIManager.setLookAndFeel("com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
/* 104:104 */       LookAndFeelAddons.setAddon(LookAndFeelAddons.getBestMatchAddonClassName());
/* 105:105 */       DemoPanel demo = new DemoPanel();
/* 106:106 */       tabs.addTab("JGoodies Plastic3D", demo);
/* 107:    */     }
/* 108:    */     catch (Exception e) {}
/* 109:    */     
/* 110:110 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 111:    */     
/* 112:112 */     add("Center", tabs);
/* 113:    */   }
/* 114:    */   
/* 115:    */   static class DemoPanel extends JTaskPane
/* 116:    */   {
/* 117:    */     public DemoPanel() {
/* 118:118 */       JTaskPane taskPane = new JTaskPane();
/* 119:    */       
/* 120:    */ 
/* 121:121 */       JTaskPaneGroup systemGroup = new JTaskPaneGroup();
/* 122:122 */       systemGroup.setTitle(TaskPaneMain.RESOURCE.getString("Main.tasks.systemGroup"));
/* 123:123 */       systemGroup.setToolTipText(TaskPaneMain.RESOURCE.getString("Main.tasks.systemGroup.tooltip"));
/* 124:    */       
/* 125:125 */       systemGroup.setSpecial(true);
/* 126:126 */       systemGroup.setIcon(new ImageIcon(TaskPaneMain.class.getResource("icons/tasks-email.png")));
/* 127:    */       
/* 128:    */ 
/* 129:129 */       systemGroup.add(makeAction(TaskPaneMain.RESOURCE.getString("Main.tasks.email"), "", "icons/tasks-email.png"));
/* 130:    */       
/* 131:131 */       systemGroup.add(makeAction(TaskPaneMain.RESOURCE.getString("Main.tasks.delete"), "", "icons/tasks-recycle.png"));
/* 132:    */       
/* 133:    */ 
/* 134:134 */       taskPane.add(systemGroup);
/* 135:    */       
/* 136:    */ 
/* 137:137 */       JTaskPaneGroup officeGroup = new JTaskPaneGroup();
/* 138:138 */       officeGroup.setTitle(TaskPaneMain.RESOURCE.getString("Main.tasks.office"));
/* 139:139 */       officeGroup.add(makeAction(TaskPaneMain.RESOURCE.getString("Main.tasks.word"), "", "icons/tasks-writedoc.png"));
/* 140:    */       
/* 141:141 */       officeGroup.setExpanded(false);
/* 142:142 */       officeGroup.setScrollOnExpand(true);
/* 143:    */       
/* 144:144 */       taskPane.add(officeGroup);
/* 145:    */       
/* 146:    */ 
/* 147:147 */       JTaskPaneGroup seeAlsoGroup = new JTaskPaneGroup();
/* 148:    */       
/* 149:149 */       seeAlsoGroup.setCollapsable(false);
/* 150:150 */       seeAlsoGroup.setTitle(TaskPaneMain.RESOURCE.getString("Main.tasks.seealso"));
/* 151:151 */       seeAlsoGroup.add(makeAction("The Internet", TaskPaneMain.RESOURCE.getString("Main.tasks.internet.tooltip"), "icons/tasks-internet.png"));
/* 152:    */       
/* 153:    */ 
/* 154:154 */       seeAlsoGroup.add(makeAction(TaskPaneMain.RESOURCE.getString("Main.tasks.help"), TaskPaneMain.RESOURCE.getString("Main.tasks.help.tooltip"), "icons/tasks-question.png"));
/* 155:    */       
/* 156:    */ 
/* 157:    */ 
/* 158:158 */       taskPane.add(seeAlsoGroup);
/* 159:    */       
/* 160:    */ 
/* 161:161 */       JTaskPaneGroup detailsGroup = new JTaskPaneGroup();
/* 162:162 */       detailsGroup.setTitle(TaskPaneMain.RESOURCE.getString("Main.tasks.details"));
/* 163:163 */       detailsGroup.setScrollOnExpand(true);
/* 164:    */       
/* 165:165 */       JEditorPane detailsText = new JEditorPane("text/html", "<html>");
/* 166:166 */       LookAndFeelTweaks.makeMultilineLabel(detailsText);
/* 167:167 */       LookAndFeelTweaks.htmlize(detailsText);
/* 168:168 */       detailsText.setText(TaskPaneMain.RESOURCE.getString("Main.tasks.details.message"));
/* 169:169 */       detailsGroup.add(detailsText);
/* 170:    */       
/* 171:171 */       taskPane.add(detailsGroup);
/* 172:    */       
/* 173:173 */       JScrollPane scroll = new JScrollPane(taskPane);
/* 174:174 */       scroll.setBorder(null);
/* 175:    */       
/* 176:176 */       setLayout(new BorderLayout());
/* 177:177 */       add("Center", scroll);
/* 178:    */       
/* 179:179 */       setBorder(null);
/* 180:    */     }
/* 181:    */     
/* 182:    */     Action makeAction(String title, String tooltiptext, String iconPath) {
/* 183:183 */       Action action = new TaskPaneMain.1(this, title);
/* 184:    */       
/* 185:    */ 
/* 186:186 */       action.putValue("SmallIcon", new ImageIcon(TaskPaneMain.class.getResource(iconPath)));
/* 187:    */       
/* 188:188 */       action.putValue("ShortDescription", tooltiptext);
/* 189:189 */       return action;
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static void main(String[] args) throws Exception {
/* 194:194 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 195:    */     
/* 196:196 */     JFrame frame = new JFrame("JTaskPane / JTaskPaneGroup");
/* 197:197 */     frame.getContentPane().setLayout(new BorderLayout());
/* 198:198 */     frame.getContentPane().add("Center", new TaskPaneMain());
/* 199:199 */     frame.setDefaultCloseOperation(3);
/* 200:200 */     frame.pack();
/* 201:201 */     frame.setLocation(100, 100);
/* 202:202 */     frame.setVisible(true);
/* 203:    */   }
/* 204:    */ }
