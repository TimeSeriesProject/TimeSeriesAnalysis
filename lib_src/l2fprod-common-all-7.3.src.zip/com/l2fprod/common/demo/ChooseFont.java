/*  1:   */ package com.l2fprod.common.demo;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.JFontChooser;
/*  4:   */ import com.l2fprod.common.swing.PercentLayout;
/*  5:   */ import java.awt.Component;
/*  6:   */ import java.awt.Font;
/*  7:   */ import java.awt.event.ActionEvent;
/*  8:   */ import java.awt.event.ActionListener;
/*  9:   */ import javax.swing.JButton;
/* 10:   */ import javax.swing.JOptionPane;
/* 11:   */ import javax.swing.JPanel;
/* 12:   */ import javax.swing.UIManager;
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ public class ChooseFont
/* 35:   */   extends JPanel
/* 36:   */ {
/* 37:   */   public ChooseFont()
/* 38:   */   {
/* 39:39 */     setLayout(new PercentLayout(1, 3));
/* 40:   */     
/* 41:41 */     JFontChooser chooser = new JFontChooser();
/* 42:42 */     chooser.setSelectedFont(new Font("Dialog", 3, 56));
/* 43:43 */     add("*", chooser);
/* 44:   */     
/* 45:45 */     JButton button = new JButton("Click here to show JFontChooser");
/* 46:46 */     button.addActionListener(new ActionListener() {
/* 47:   */       public void actionPerformed(ActionEvent e) {
/* 48:48 */         ChooseFont.selectFont(ChooseFont.this);
/* 49:   */       }
/* 50:50 */     });
/* 51:51 */     add(button);
/* 52:   */   }
/* 53:   */   
/* 54:   */   private static void selectFont(Component parent) {
/* 55:55 */     Font selectedFont = JFontChooser.showDialog(parent, "Choose Font", null);
/* 56:56 */     if (selectedFont == null) {
/* 57:57 */       JOptionPane.showMessageDialog(parent, "You clicked 'Cancel'");
/* 58:   */     } else {
/* 59:59 */       JOptionPane.showMessageDialog(parent, "You selected '" + selectedFont.getName() + "'");
/* 60:   */     }
/* 61:   */   }
/* 62:   */   
/* 63:   */   public static void main(String[] args) throws Exception
/* 64:   */   {
/* 65:65 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 66:66 */     selectFont(null);
/* 67:67 */     System.exit(0);
/* 68:   */   }
/* 69:   */ }
