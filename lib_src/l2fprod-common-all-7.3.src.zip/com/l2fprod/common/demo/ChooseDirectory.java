/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JDirectoryChooser;
/*   4:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   5:    */ import com.l2fprod.common.swing.PercentLayout;
/*   6:    */ import com.l2fprod.common.util.ResourceManager;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.io.File;
/*  11:    */ import javax.swing.JButton;
/*  12:    */ import javax.swing.JOptionPane;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.JTextArea;
/*  15:    */ import javax.swing.UIManager;
/*  16:    */ import javax.swing.filechooser.FileSystemView;
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ public class ChooseDirectory
/*  39:    */   extends JPanel
/*  40:    */ {
/*  41: 41 */   public static final ResourceManager RESOURCE = ResourceManager.get(ChooseDirectory.class);
/*  42:    */   
/*  43:    */   public ChooseDirectory()
/*  44:    */   {
/*  45: 45 */     setLayout(new PercentLayout(1, 3));
/*  46:    */     
/*  47: 47 */     if (System.getProperty("javawebstart.version") != null) {
/*  48: 48 */       JTextArea area = new JTextArea(RESOURCE.getString("message.webstart"));
/*  49: 49 */       LookAndFeelTweaks.makeMultilineLabel(area);
/*  50: 50 */       area.setFocusable(false);
/*  51: 51 */       add(area);
/*  52:    */     }
/*  53:    */     
/*  54: 54 */     JButton button = new JButton(RESOURCE.getString("selectDirectory"));
/*  55: 55 */     add(button);
/*  56: 56 */     button.addActionListener(new ActionListener() { private final JButton val$button;
/*  57:    */       
/*  58: 58 */       public void actionPerformed(ActionEvent e) { ChooseDirectory.selectDirectory(val$button, null); }
/*  59:    */     });
/*  60:    */   }
/*  61:    */   
/*  62:    */ 
/*  63:    */   static void selectDirectory(Component parent, String selectedFile)
/*  64:    */   {
/*  65:    */     JDirectoryChooser chooser;
/*  66: 66 */     if (System.getProperty("javawebstart.version") != null) {
/*  67: 67 */       JDirectoryChooser chooser = new JDirectoryChooser(new FakeFileSystemView())
/*  68:    */       {
/*  69:    */         public void rescanCurrentDirectory() {}
/*  70:    */         
/*  71:    */         public void setCurrentDirectory(File dir) {}
/*  72: 72 */       };
/*  73: 73 */       chooser.setShowingCreateDirectory(false);
/*  74:    */     } else {
/*  75: 75 */       chooser = new JDirectoryChooser();
/*  76: 76 */       if (selectedFile != null) {
/*  77: 77 */         chooser.setSelectedFile(new File(selectedFile));
/*  78:    */       }
/*  79:    */     }
/*  80:    */     
/*  81: 81 */     JTextArea accessory = new JTextArea(RESOURCE.getString("selectDirectory.message"));
/*  82:    */     
/*  83: 83 */     accessory.setLineWrap(true);
/*  84: 84 */     accessory.setWrapStyleWord(true);
/*  85: 85 */     accessory.setEditable(false);
/*  86: 86 */     accessory.setOpaque(false);
/*  87: 87 */     accessory.setFont(UIManager.getFont("Tree.font"));
/*  88: 88 */     accessory.setFocusable(false);
/*  89: 89 */     chooser.setAccessory(accessory);
/*  90:    */     
/*  91: 91 */     chooser.setMultiSelectionEnabled(true);
/*  92:    */     
/*  93: 93 */     int choice = chooser.showOpenDialog(parent);
/*  94: 94 */     if (choice == 0) {
/*  95: 95 */       String filenames = "";
/*  96: 96 */       File[] selectedFiles = chooser.getSelectedFiles();
/*  97: 97 */       int i = 0; for (int c = selectedFiles.length; i < c; i++) {
/*  98: 98 */         filenames = filenames + "\n" + selectedFiles[i];
/*  99:    */       }
/* 100:100 */       JOptionPane.showMessageDialog(parent, RESOURCE.getString("selectDirectory.confirm", new Object[] { filenames }));
/* 101:    */     }
/* 102:    */     else {
/* 103:103 */       JOptionPane.showMessageDialog(parent, RESOURCE.getString("selectDirectory.cancel"));
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static void main(String[] args) throws Exception
/* 108:    */   {
/* 109:109 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 110:    */     
/* 111:111 */     if (args.length > 0) {
/* 112:112 */       selectDirectory(null, args[0]);
/* 113:    */     } else {
/* 114:114 */       selectDirectory(null, null);
/* 115:    */     }
/* 116:    */     
/* 117:117 */     System.exit(0);
/* 118:    */   }
/* 119:    */ }
