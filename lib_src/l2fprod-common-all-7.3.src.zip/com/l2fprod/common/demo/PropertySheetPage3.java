/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.propertysheet.DefaultProperty;
/*   4:    */ import com.l2fprod.common.propertysheet.Property;
/*   5:    */ import com.l2fprod.common.propertysheet.PropertySheetPanel;
/*   6:    */ import com.l2fprod.common.propertysheet.PropertySheetTable;
/*   7:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   8:    */ import com.l2fprod.common.util.ResourceManager;
/*   9:    */ import java.awt.Color;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.beans.PropertyChangeEvent;
/*  12:    */ import java.beans.PropertyChangeListener;
/*  13:    */ import java.io.PrintStream;
/*  14:    */ import javax.swing.AbstractAction;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JTextArea;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class PropertySheetPage3
/*  37:    */   extends JPanel
/*  38:    */ {
/*  39: 39 */   private static final Class THIS_CLASS = PropertySheetPage3.class;
/*  40: 40 */   static ResourceManager RESOURCE = ResourceManager.get(THIS_CLASS);
/*  41:    */   
/*  42:    */   public PropertySheetPage3()
/*  43:    */   {
/*  44: 44 */     setLayout(LookAndFeelTweaks.createVerticalPercentLayout());
/*  45:    */     
/*  46: 46 */     JTextArea message = new JTextArea();
/*  47: 47 */     message.setText(PropertySheetMain.RESOURCE.getString("Main.sheet1.message"));
/*  48: 48 */     LookAndFeelTweaks.makeMultilineLabel(message);
/*  49: 49 */     add(message);
/*  50:    */     
/*  51: 51 */     Colorful data = new Colorful();
/*  52: 52 */     data.setColor(new Color(255, 153, 102));
/*  53:    */     
/*  54: 54 */     DefaultProperty level0 = new NoReadWriteProperty();
/*  55: 55 */     level0.setDisplayName("Level 0");
/*  56: 56 */     level0.setCategory("A category");
/*  57: 57 */     DefaultProperty level1 = new NoReadWriteProperty();
/*  58: 58 */     level1.setDisplayName("Level 1");
/*  59: 59 */     level1.setCategory("Another category");
/*  60: 60 */     level0.addSubProperty(level1);
/*  61: 61 */     DefaultProperty level2 = new NoReadWriteProperty();
/*  62: 62 */     level2.setDisplayName("Level 2");
/*  63: 63 */     level1.addSubProperty(level2);
/*  64: 64 */     DefaultProperty level21 = new NoReadWriteProperty();
/*  65: 65 */     level21.setDisplayName("Level 3");
/*  66: 66 */     level1.addSubProperty(level21);
/*  67:    */     
/*  68: 68 */     DefaultProperty level211 = new NoReadWriteProperty();
/*  69: 69 */     level211.setDisplayName("Level 3.1");
/*  70: 70 */     level21.addSubProperty(level211);
/*  71:    */     
/*  72: 72 */     DefaultProperty root = new NoReadWriteProperty();
/*  73: 73 */     root.setDisplayName("Root");
/*  74:    */     
/*  75: 75 */     PropertySheetPanel sheet = new PropertySheetPanel();
/*  76: 76 */     sheet.setMode(0);
/*  77: 77 */     sheet.setProperties(new Property[] { new ColorProperty(), level0, root });
/*  78: 78 */     sheet.readFromObject(data);
/*  79: 79 */     sheet.setDescriptionVisible(true);
/*  80: 80 */     sheet.setSortingCategories(true);
/*  81: 81 */     sheet.setSortingProperties(true);
/*  82: 82 */     add(sheet, "*");
/*  83:    */     
/*  84:    */ 
/*  85: 85 */     PropertyChangeListener listener = new PropertyChangeListener() {
/*  86:    */       private final PropertySheetPage3.Colorful val$data;
/*  87:    */       
/*  88: 88 */       public void propertyChange(PropertyChangeEvent evt) { Property prop = (Property)evt.getSource();
/*  89: 89 */         prop.writeToObject(val$data);
/*  90: 90 */         System.out.println("Updated object to " + val$data);
/*  91:    */       }
/*  92: 92 */     };
/*  93: 93 */     sheet.addPropertySheetChangeListener(listener);
/*  94:    */     
/*  95: 95 */     JButton button = new JButton(new AbstractAction("Click to setWantsExtraIndent(true)") { private final PropertySheetPanel val$sheet;
/*  96:    */       
/*  97: 97 */       public void actionPerformed(ActionEvent e) { val$sheet.getTable().setWantsExtraIndent(!val$sheet.getTable().getWantsExtraIndent());
/*  98: 98 */         putValue("Name", "Click to setWantsExtraIndent(" + (!val$sheet.getTable().getWantsExtraIndent()) + ")");
/*  99:    */       }
/* 100:100 */     });
/* 101:101 */     add(button);
/* 102:    */   }
/* 103:    */   
/* 104:    */   static class NoReadWriteProperty extends DefaultProperty
/* 105:    */   {
/* 106:    */     public void readFromObject(Object object) {}
/* 107:    */     
/* 108:    */     public void writeToObject(Object object) {}
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static class Colorful
/* 112:    */   {
/* 113:    */     private Color color;
/* 114:    */     
/* 115:    */     public Color getColor()
/* 116:    */     {
/* 117:117 */       return color;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public void setColor(Color color)
/* 121:    */     {
/* 122:122 */       this.color = color;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public int getRed()
/* 126:    */     {
/* 127:127 */       return color.getRed();
/* 128:    */     }
/* 129:    */     
/* 130:    */     public void setRed(int red)
/* 131:    */     {
/* 132:132 */       color = new Color(red, getGreen(), getBlue());
/* 133:    */     }
/* 134:    */     
/* 135:    */     public int getGreen()
/* 136:    */     {
/* 137:137 */       return color.getGreen();
/* 138:    */     }
/* 139:    */     
/* 140:    */     public void setGreen(int green)
/* 141:    */     {
/* 142:142 */       color = new Color(getRed(), green, getBlue());
/* 143:    */     }
/* 144:    */     
/* 145:    */     public int getBlue()
/* 146:    */     {
/* 147:147 */       return color.getBlue();
/* 148:    */     }
/* 149:    */     
/* 150:    */     public void setBlue(int blue)
/* 151:    */     {
/* 152:152 */       color = new Color(getRed(), getGreen(), blue);
/* 153:    */     }
/* 154:    */     
/* 155:    */     public String toString()
/* 156:    */     {
/* 157:157 */       return color.toString();
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   public static class ColorProperty extends DefaultProperty
/* 162:    */   {
/* 163:    */     public ColorProperty()
/* 164:    */     {
/* 165:165 */       setName("color");
/* 166:166 */       setCategory(PropertySheetPage3.RESOURCE.getString("color.cat"));
/* 167:167 */       setDisplayName(PropertySheetPage3.RESOURCE.getString("color.name"));
/* 168:168 */       setShortDescription(PropertySheetPage3.RESOURCE.getString("color.desc"));
/* 169:169 */       setType(Color.class);
/* 170:    */       
/* 171:171 */       addSubProperty(new PropertySheetPage3.ColorComponentProperty("red"));
/* 172:172 */       addSubProperty(new PropertySheetPage3.ColorComponentProperty("green"));
/* 173:173 */       addSubProperty(new PropertySheetPage3.ColorComponentProperty("blue"));
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static class ColorComponentProperty extends DefaultProperty
/* 178:    */   {
/* 179:    */     public ColorComponentProperty(String name)
/* 180:    */     {
/* 181:181 */       setName(name);
/* 182:182 */       setDisplayName(PropertySheetPage3.RESOURCE.getString(name + ".name"));
/* 183:183 */       setShortDescription(PropertySheetPage3.RESOURCE.getString(name + ".desc"));
/* 184:184 */       setType(Integer.TYPE);
/* 185:    */     }
/* 186:    */   }
/* 187:    */ }
