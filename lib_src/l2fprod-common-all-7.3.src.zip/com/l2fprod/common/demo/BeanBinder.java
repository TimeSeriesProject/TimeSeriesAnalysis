/*  1:   */ package com.l2fprod.common.demo;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.model.DefaultBeanInfoResolver;
/*  4:   */ import com.l2fprod.common.propertysheet.Property;
/*  5:   */ import com.l2fprod.common.propertysheet.PropertySheetPanel;
/*  6:   */ import java.beans.BeanInfo;
/*  7:   */ import java.beans.PropertyChangeEvent;
/*  8:   */ import java.beans.PropertyChangeListener;
/*  9:   */ import java.beans.PropertyVetoException;
/* 10:   */ import javax.swing.LookAndFeel;
/* 11:   */ import javax.swing.UIManager;
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ public class BeanBinder
/* 36:   */ {
/* 37:   */   private final Object bean;
/* 38:   */   private final PropertySheetPanel sheet;
/* 39:   */   private final PropertyChangeListener listener;
/* 40:   */   
/* 41:   */   public BeanBinder(Object bean, PropertySheetPanel sheet)
/* 42:   */   {
/* 43:43 */     this(bean, sheet, new DefaultBeanInfoResolver().getBeanInfo(bean));
/* 44:   */   }
/* 45:   */   
/* 46:   */   public BeanBinder(Object bean, PropertySheetPanel sheet, BeanInfo beanInfo) {
/* 47:47 */     this.bean = bean;
/* 48:48 */     this.sheet = sheet;
/* 49:   */     
/* 50:50 */     sheet.setProperties(beanInfo.getPropertyDescriptors());
/* 51:51 */     sheet.readFromObject(bean);
/* 52:   */     
/* 53:   */ 
/* 54:54 */     listener = new PropertyChangeListener() {
/* 55:   */       public void propertyChange(PropertyChangeEvent evt) {
/* 56:56 */         Property prop = (Property)evt.getSource();
/* 57:   */         try {
/* 58:58 */           prop.writeToObject(bean);
/* 59:   */         }
/* 60:   */         catch (RuntimeException e) {
/* 61:61 */           if ((e.getCause() instanceof PropertyVetoException)) {
/* 62:62 */             UIManager.getLookAndFeel().provideErrorFeedback(sheet);
/* 63:   */             
/* 64:64 */             prop.setValue(evt.getOldValue());
/* 65:   */           }
/* 66:   */         }
/* 67:   */       }
/* 68:68 */     };
/* 69:69 */     sheet.addPropertySheetChangeListener(listener);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public void unbind() {
/* 73:73 */     sheet.removePropertyChangeListener(listener);
/* 74:74 */     sheet.setProperties(new Property[0]);
/* 75:   */   }
/* 76:   */ }
