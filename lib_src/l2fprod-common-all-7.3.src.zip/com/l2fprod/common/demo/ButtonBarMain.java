/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JButtonBar;
/*   4:    */ import com.l2fprod.common.swing.plaf.blue.BlueishButtonBarUI;
/*   5:    */ import com.l2fprod.common.swing.plaf.misc.IconPackagerButtonBarUI;
/*   6:    */ import com.l2fprod.common.util.ResourceManager;
/*   7:    */ import java.awt.BorderLayout;
/*   8:    */ import java.awt.Color;
/*   9:    */ import java.awt.Component;
/*  10:    */ import java.awt.Container;
/*  11:    */ import java.awt.Dimension;
/*  12:    */ import java.awt.Font;
/*  13:    */ import javax.swing.Action;
/*  14:    */ import javax.swing.BorderFactory;
/*  15:    */ import javax.swing.ButtonGroup;
/*  16:    */ import javax.swing.ImageIcon;
/*  17:    */ import javax.swing.JFrame;
/*  18:    */ import javax.swing.JLabel;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.JTabbedPane;
/*  21:    */ import javax.swing.JToggleButton;
/*  22:    */ import javax.swing.UIManager;
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ public class ButtonBarMain
/*  37:    */   extends JPanel
/*  38:    */ {
/*  39: 39 */   static ResourceManager RESOURCE = ResourceManager.get(ButtonBarMain.class);
/*  40:    */   
/*  41:    */   public ButtonBarMain() {
/*  42: 42 */     setLayout(new BorderLayout());
/*  43:    */     
/*  44: 44 */     JTabbedPane tabs = new JTabbedPane();
/*  45: 45 */     add("Center", tabs);
/*  46:    */     
/*  47:    */ 
/*  48: 48 */     JButtonBar toolbar = new JButtonBar(1);
/*  49: 49 */     toolbar.setUI(new BlueishButtonBarUI());
/*  50: 50 */     tabs.addTab("Mozilla L&F", new ButtonBarPanel(toolbar));
/*  51:    */     
/*  52:    */ 
/*  53:    */ 
/*  54: 54 */     JButtonBar toolbar = new JButtonBar(1);
/*  55: 55 */     toolbar.setUI(new IconPackagerButtonBarUI());
/*  56: 56 */     tabs.addTab("Icon Packager L&F", new ButtonBarPanel(toolbar));
/*  57:    */   }
/*  58:    */   
/*  59:    */   static class ButtonBarPanel extends JPanel
/*  60:    */   {
/*  61:    */     private Component currentComponent;
/*  62:    */     
/*  63:    */     public ButtonBarPanel(JButtonBar toolbar)
/*  64:    */     {
/*  65: 65 */       setLayout(new BorderLayout());
/*  66:    */       
/*  67: 67 */       add("West", toolbar);
/*  68:    */       
/*  69: 69 */       ButtonGroup group = new ButtonGroup();
/*  70:    */       
/*  71: 71 */       addButton(ButtonBarMain.RESOURCE.getString("Main.welcome"), "icons/welcome32x32.png", makePanel(ButtonBarMain.RESOURCE.getString("Main.welcome")), toolbar, group);
/*  72:    */       
/*  73:    */ 
/*  74: 74 */       addButton(ButtonBarMain.RESOURCE.getString("Main.settings"), "icons/propertysheet32x32.png", makePanel(ButtonBarMain.RESOURCE.getString("Main.settings")), toolbar, group);
/*  75:    */       
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80: 80 */       addButton(ButtonBarMain.RESOURCE.getString("Main.sounds"), "icons/fonts32x32.png", makePanel(ButtonBarMain.RESOURCE.getString("Main.sounds")), toolbar, group);
/*  81:    */       
/*  82:    */ 
/*  83: 83 */       addButton(ButtonBarMain.RESOURCE.getString("Main.stats"), "icons/folder32x32.png", makePanel(ButtonBarMain.RESOURCE.getString("Main.stats")), toolbar, group);
/*  84:    */     }
/*  85:    */     
/*  86:    */     private JPanel makePanel(String title)
/*  87:    */     {
/*  88: 88 */       JPanel panel = new JPanel(new BorderLayout());
/*  89: 89 */       JLabel top = new JLabel(title);
/*  90: 90 */       top.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
/*  91: 91 */       top.setFont(top.getFont().deriveFont(1));
/*  92: 92 */       top.setOpaque(true);
/*  93: 93 */       top.setBackground(panel.getBackground().brighter());
/*  94: 94 */       panel.add("North", top);
/*  95: 95 */       panel.setPreferredSize(new Dimension(400, 300));
/*  96: 96 */       panel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
/*  97: 97 */       return panel;
/*  98:    */     }
/*  99:    */     
/* 100:    */     private void show(Component component) {
/* 101:101 */       if (currentComponent != null) {
/* 102:102 */         remove(currentComponent);
/* 103:    */       }
/* 104:104 */       add("Center", this.currentComponent = component);
/* 105:105 */       revalidate();
/* 106:106 */       repaint();
/* 107:    */     }
/* 108:    */     
/* 109:    */     private void addButton(String title, String iconUrl, Component component, JButtonBar bar, ButtonGroup group)
/* 110:    */     {
/* 111:111 */       Action action = new ButtonBarMain.1(this, title, new ImageIcon(ButtonBarMain.class.getResource(iconUrl)), component);
/* 112:    */       
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:118 */       JToggleButton button = new JToggleButton(action);
/* 119:119 */       bar.add(button);
/* 120:    */       
/* 121:121 */       group.add(button);
/* 122:    */       
/* 123:123 */       if (group.getSelection() == null) {
/* 124:124 */         button.setSelected(true);
/* 125:125 */         show(component);
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static void main(String[] args) throws Exception {
/* 131:131 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 132:    */     
/* 133:133 */     JFrame frame = new JFrame("ButtonBar");
/* 134:134 */     frame.getContentPane().setLayout(new BorderLayout());
/* 135:135 */     frame.getContentPane().add("Center", new ButtonBarMain());
/* 136:136 */     frame.setDefaultCloseOperation(3);
/* 137:137 */     frame.pack();
/* 138:138 */     frame.setLocation(100, 100);
/* 139:139 */     frame.setVisible(true);
/* 140:    */   }
/* 141:    */ }
