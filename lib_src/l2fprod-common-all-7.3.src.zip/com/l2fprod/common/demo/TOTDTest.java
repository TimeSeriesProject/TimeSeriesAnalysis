/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.swing.JTipOfTheDay;
/*   4:    */ import com.l2fprod.common.swing.JTipOfTheDay.ShowOnStartupChoice;
/*   5:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   6:    */ import com.l2fprod.common.swing.plaf.basic.BasicLookAndFeelAddons;
/*   7:    */ import com.l2fprod.common.swing.plaf.basic.BasicTipOfTheDayUI;
/*   8:    */ import com.l2fprod.common.swing.plaf.windows.WindowsLookAndFeelAddons;
/*   9:    */ import com.l2fprod.common.swing.tips.DefaultTip;
/*  10:    */ import com.l2fprod.common.swing.tips.DefaultTipModel;
/*  11:    */ import java.awt.Container;
/*  12:    */ import java.awt.GridLayout;
/*  13:    */ import java.awt.event.ActionEvent;
/*  14:    */ import java.awt.event.ActionListener;
/*  15:    */ import javax.swing.ImageIcon;
/*  16:    */ import javax.swing.JButton;
/*  17:    */ import javax.swing.JFrame;
/*  18:    */ import javax.swing.JOptionPane;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.JTree;
/*  21:    */ import javax.swing.UIManager;
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ public class TOTDTest
/*  28:    */   extends JPanel
/*  29:    */ {
/*  30:    */   public TOTDTest()
/*  31:    */   {
/*  32: 32 */     setLayout(new GridLayout(2, 1));
/*  33:    */     try
/*  34:    */     {
/*  35: 35 */       add(makeAction("Windows Look And Feel", UIManager.getSystemLookAndFeelClassName(), WindowsLookAndFeelAddons.class.getName()));
/*  36:    */       
/*  37:    */ 
/*  38: 38 */       add(makeAction("Other Look And Feel", UIManager.getCrossPlatformLookAndFeelClassName(), BasicLookAndFeelAddons.class.getName()));
/*  39:    */     }
/*  40:    */     catch (Exception e) {}
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static void main(String[] args)
/*  44:    */     throws Exception
/*  45:    */   {
/*  46: 46 */     LookAndFeelAddons.setTrackingLookAndFeelChanges(false);
/*  47:    */     
/*  48: 48 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*  49:    */     
/*  50: 50 */     JFrame frame = new JFrame("Tip of the Day Testbed");
/*  51: 51 */     frame.getContentPane().add("Center", new TOTDTest());
/*  52: 52 */     frame.pack();
/*  53: 53 */     frame.setLocationRelativeTo(null);
/*  54: 54 */     frame.setDefaultCloseOperation(3);
/*  55: 55 */     frame.setVisible(true);
/*  56:    */   }
/*  57:    */   
/*  58:    */   static JButton makeAction(String title, String lnf, String addon) throws Exception
/*  59:    */   {
/*  60: 60 */     JTipOfTheDay.ShowOnStartupChoice fake = new JTipOfTheDay.ShowOnStartupChoice() {
/*  61: 61 */       private boolean value = true;
/*  62:    */       
/*  63:    */       public boolean isShowingOnStartup() {
/*  64: 64 */         return value;
/*  65:    */       }
/*  66:    */       
/*  67: 67 */       public void setShowingOnStartup(boolean showOnStartup) { value = showOnStartup;
/*  68:    */       }
/*  69:    */ 
/*  70: 70 */     };
/*  71: 71 */     ActionListener action = new ActionListener() {
/*  72:    */       private final String val$lnf;
/*  73:    */       
/*  74: 74 */       public void actionPerformed(ActionEvent e) { try { UIManager.setLookAndFeel(val$lnf);
/*  75: 75 */           LookAndFeelAddons.setAddon(val$addon);
/*  76:    */         }
/*  77:    */         catch (Exception ex) {}
/*  78:    */         
/*  79:    */ 
/*  80: 80 */         if ((!val$fake.isShowingOnStartup()) && 
/*  81: 81 */           (0 == JOptionPane.showConfirmDialog(null, "You previously choose to not show tips on startup.\nDo you want to cancel this choice?", "Question", 0)))
/*  82:    */         {
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86: 86 */           val$fake.setShowingOnStartup(true);
/*  87:    */         }
/*  88:    */         
/*  89:    */ 
/*  90: 90 */         DefaultTipModel tips = new DefaultTipModel();
/*  91:    */         
/*  92:    */ 
/*  93: 93 */         tips.add(new DefaultTip("tip1", "This is the first tip This is the first tip This is the first tip This is the first tip This is the first tip This is the first tip\nThis is the first tip This is the first tip"));
/*  94:    */         
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99: 99 */         tips.add(new DefaultTip("tip2", "<html>This is an html <b>TIP</b><br><center><table border=\"1\"><tr><td>1</td><td>entry 1</td></tr><tr><td>2</td><td>entry 2</td></tr><tr><td>3</td><td>entry 3</td></tr></table>"));
/* 100:    */         
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:106 */         tips.add(new DefaultTip("tip3", new JTree()));
/* 107:    */         
/* 108:    */ 
/* 109:109 */         tips.add(new DefaultTip("tip 4", new ImageIcon(BasicTipOfTheDayUI.class.getResource("TipOfTheDay24.gif"))));
/* 110:    */         
/* 111:    */ 
/* 112:112 */         JTipOfTheDay totd = new JTipOfTheDay(tips);
/* 113:113 */         totd.setCurrentTip(0);
/* 114:    */         
/* 115:115 */         totd.showDialog(new JFrame("title"), val$fake);
/* 116:    */       }
/* 117:    */       
/* 118:118 */     };
/* 119:119 */     JButton button = new JButton(title);
/* 120:120 */     button.addActionListener(action);
/* 121:121 */     return button;
/* 122:    */   }
/* 123:    */   
/* 124:    */   private final String val$addon;
/* 125:    */   private final JTipOfTheDay.ShowOnStartupChoice val$fake;
/* 126:    */ }
