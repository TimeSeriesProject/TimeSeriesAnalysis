/*  1:   */ package com.l2fprod.common.demo;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.propertysheet.Property;
/*  4:   */ import com.l2fprod.common.propertysheet.PropertySheetPanel;
/*  5:   */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*  6:   */ import com.l2fprod.common.util.ResourceManager;
/*  7:   */ import java.beans.BeanInfo;
/*  8:   */ import java.beans.IntrospectionException;
/*  9:   */ import java.beans.Introspector;
/* 10:   */ import java.beans.PropertyChangeEvent;
/* 11:   */ import java.beans.PropertyChangeListener;
/* 12:   */ import java.beans.SimpleBeanInfo;
/* 13:   */ import javax.swing.JButton;
/* 14:   */ import javax.swing.JPanel;
/* 15:   */ import javax.swing.JTextArea;
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:   */ public class PropertySheetPage2
/* 39:   */   extends JPanel
/* 40:   */ {
/* 41:   */   public PropertySheetPage2()
/* 42:   */   {
/* 43:43 */     setLayout(LookAndFeelTweaks.createVerticalPercentLayout());
/* 44:   */     
/* 45:45 */     JButton button = new JButton();
/* 46:46 */     button.setText("Change my properties!");
/* 47:47 */     BeanInfo beanInfo = new SimpleBeanInfo();
/* 48:   */     try {
/* 49:49 */       beanInfo = Introspector.getBeanInfo(JButton.class);
/* 50:   */     } catch (IntrospectionException e) {
/* 51:51 */       e.printStackTrace();
/* 52:   */     }
/* 53:53 */     PropertySheetPanel sheet = new PropertySheetPanel();
/* 54:54 */     sheet.setMode(0);
/* 55:55 */     sheet.setToolBarVisible(false);
/* 56:56 */     sheet.setDescriptionVisible(false);
/* 57:57 */     sheet.setBeanInfo(beanInfo);
/* 58:   */     
/* 59:59 */     JPanel panel = new JPanel(LookAndFeelTweaks.createBorderLayout());
/* 60:60 */     panel.add("Center", sheet);
/* 61:61 */     panel.add("East", button);
/* 62:   */     
/* 63:   */ 
/* 64:   */ 
/* 65:   */ 
/* 66:   */ 
/* 67:   */ 
/* 68:   */ 
/* 69:69 */     Property[] properties = sheet.getProperties();
/* 70:70 */     int i = 0; for (int c = properties.length; i < c; i++) {
/* 71:   */       try {
/* 72:72 */         properties[i].readFromObject(button);
/* 73:   */       }
/* 74:   */       catch (Exception e) {}
/* 75:   */     }
/* 76:   */     
/* 77:   */ 
/* 78:78 */     PropertyChangeListener listener = new PropertyChangeListener() { private final JButton val$button;
/* 79:   */       
/* 80:80 */       public void propertyChange(PropertyChangeEvent evt) { Property prop = (Property)evt.getSource();
/* 81:81 */         prop.writeToObject(val$button);
/* 82:82 */         val$button.repaint();
/* 83:   */       }
/* 84:84 */     };
/* 85:85 */     sheet.addPropertySheetChangeListener(listener);
/* 86:   */     
/* 87:87 */     JTextArea message = new JTextArea();
/* 88:88 */     message.setText(PropertySheetMain.RESOURCE.getString("Main.sheet2.message"));
/* 89:89 */     LookAndFeelTweaks.makeMultilineLabel(message);
/* 90:90 */     panel.add("North", message);
/* 91:   */     
/* 92:92 */     add(panel, "*");
/* 93:   */   }
/* 94:   */ }
