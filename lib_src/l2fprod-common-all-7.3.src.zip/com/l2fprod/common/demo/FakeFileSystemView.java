/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import javax.swing.Icon;
/*   7:    */ import javax.swing.filechooser.FileSystemView;
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ public class FakeFileSystemView
/*  31:    */   extends FileSystemView
/*  32:    */ {
/*  33: 33 */   private Map files = new HashMap();
/*  34:    */   
/*  35:    */   public FakeFileSystemView() {
/*  36: 36 */     files.put("desktop", new FakeFile("Desktop"));
/*  37: 37 */     files.put("computer", new FakeFile("My Computer"));
/*  38: 38 */     files.put("A", new FakeFile("A"));
/*  39: 39 */     files.put("C", new FakeFile("C"));
/*  40: 40 */     files.put("D", new FakeFile("D"));
/*  41: 41 */     files.put("getFiles(My Computer)", new File[] { (File)files.get("A"), (File)files.get("C"), (File)files.get("D") });
/*  42:    */     
/*  43: 43 */     files.put("network", new FakeFile("My Network Places"));
/*  44: 44 */     files.put("getRoots", new File[] { (File)files.get("desktop") });
/*  45: 45 */     files.put("getFiles(Desktop)", new File[] { (File)files.get("computer"), (File)files.get("network") });
/*  46:    */     
/*  47:    */ 
/*  48: 48 */     FakeFile[] folders = { new FakeFile("Folder 1"), new FakeFile("Folder 2"), new FakeFile("Folder 3") };
/*  49:    */     
/*  50: 50 */     files.put("getFiles(C)", folders);
/*  51: 51 */     files.put("getFiles(D)", folders);
/*  52:    */   }
/*  53:    */   
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */   public File createNewFolder(File containingDir)
/*  59:    */   {
/*  60: 60 */     return null;
/*  61:    */   }
/*  62:    */   
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */   public File createFileObject(File dir, String filename)
/*  69:    */   {
/*  70: 70 */     return super.createFileObject(dir, filename);
/*  71:    */   }
/*  72:    */   
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */   public File createFileObject(String path)
/*  78:    */   {
/*  79: 79 */     return super.createFileObject(path);
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */   protected File createFileSystemRoot(File f)
/*  87:    */   {
/*  88: 88 */     return super.createFileSystemRoot(f);
/*  89:    */   }
/*  90:    */   
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */   public File getChild(File parent, String fileName)
/*  97:    */   {
/*  98: 98 */     return super.getChild(parent, fileName);
/*  99:    */   }
/* 100:    */   
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */   public File getDefaultDirectory()
/* 106:    */   {
/* 107:107 */     return new FakeFile("Default");
/* 108:    */   }
/* 109:    */   
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */   public File[] getFiles(File dir, boolean useFileHiding)
/* 116:    */   {
/* 117:117 */     if (dir.getName().startsWith("Folder")) {
/* 118:118 */       return new FakeFile[] { new FakeFile(dir.getName() + ".1"), new FakeFile(dir.getName() + ".2"), new FakeFile(dir.getName() + ".3") };
/* 119:    */     }
/* 120:    */     
/* 121:121 */     File[] children = (File[])files.get("getFiles(" + dir.getName() + ")");
/* 122:122 */     if (children == null) {
/* 123:123 */       return new File[0];
/* 124:    */     }
/* 125:125 */     return children;
/* 126:    */   }
/* 127:    */   
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */   public File getHomeDirectory()
/* 135:    */   {
/* 136:136 */     return new FakeFile("Home");
/* 137:    */   }
/* 138:    */   
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */   public File getParentDirectory(File dir)
/* 144:    */   {
/* 145:145 */     return null;
/* 146:    */   }
/* 147:    */   
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */   public File[] getRoots()
/* 153:    */   {
/* 154:154 */     return (File[])files.get("getRoots");
/* 155:    */   }
/* 156:    */   
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */   public String getSystemDisplayName(File f)
/* 161:    */   {
/* 162:162 */     return f.getName();
/* 163:    */   }
/* 164:    */   
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */   public Icon getSystemIcon(File f)
/* 170:    */   {
/* 171:171 */     return null;
/* 172:    */   }
/* 173:    */   
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */   public String getSystemTypeDescription(File f)
/* 179:    */   {
/* 180:180 */     return "Description";
/* 181:    */   }
/* 182:    */   
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */   public boolean isComputerNode(File dir)
/* 188:    */   {
/* 189:189 */     return files.get("computer") == dir;
/* 190:    */   }
/* 191:    */   
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:    */ 
/* 196:    */   public boolean isDrive(File dir)
/* 197:    */   {
/* 198:198 */     return ("C".equals(dir.getName())) || ("D".equals(dir.getName()));
/* 199:    */   }
/* 200:    */   
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */   public boolean isFileSystem(File f)
/* 206:    */   {
/* 207:207 */     return false;
/* 208:    */   }
/* 209:    */   
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */   public boolean isFileSystemRoot(File dir)
/* 215:    */   {
/* 216:216 */     return false;
/* 217:    */   }
/* 218:    */   
/* 219:    */ 
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:    */   public boolean isFloppyDrive(File dir)
/* 224:    */   {
/* 225:225 */     return "A".equals(dir.getName());
/* 226:    */   }
/* 227:    */   
/* 228:    */ 
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */   public boolean isHiddenFile(File f)
/* 233:    */   {
/* 234:234 */     return false;
/* 235:    */   }
/* 236:    */   
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */   public boolean isParent(File folder, File file)
/* 243:    */   {
/* 244:244 */     return false;
/* 245:    */   }
/* 246:    */   
/* 247:    */ 
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */   public boolean isRoot(File f)
/* 252:    */   {
/* 253:253 */     return files.get("desktop") == f;
/* 254:    */   }
/* 255:    */   
/* 256:    */ 
/* 257:    */ 
/* 258:    */ 
/* 259:    */ 
/* 260:    */   public Boolean isTraversable(File f)
/* 261:    */   {
/* 262:262 */     return Boolean.TRUE;
/* 263:    */   }
/* 264:    */   
/* 265:    */   static class FakeFile extends File {
/* 266:    */     public FakeFile(String s) {
/* 267:267 */       super();
/* 268:    */     }
/* 269:    */     
/* 270:270 */     public boolean isDirectory() { return true; }
/* 271:    */   }
/* 272:    */ }
