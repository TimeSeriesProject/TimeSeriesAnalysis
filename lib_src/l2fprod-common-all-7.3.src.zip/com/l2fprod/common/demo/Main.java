/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.Version;
/*   4:    */ import com.l2fprod.common.swing.plaf.LookAndFeelAddons;
/*   5:    */ import java.awt.BorderLayout;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Container;
/*   8:    */ import java.awt.Graphics;
/*   9:    */ import java.awt.Graphics2D;
/*  10:    */ import java.awt.RenderingHints;
/*  11:    */ import javax.swing.BorderFactory;
/*  12:    */ import javax.swing.JComponent;
/*  13:    */ import javax.swing.JEditorPane;
/*  14:    */ import javax.swing.JFrame;
/*  15:    */ import javax.swing.JPanel;
/*  16:    */ import javax.swing.JTabbedPane;
/*  17:    */ import javax.swing.UIManager;
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ public class Main
/*  39:    */   extends JPanel
/*  40:    */ {
/*  41:    */   public Main()
/*  42:    */   {
/*  43: 43 */     setLayout(new BorderLayout());
/*  44:    */     
/*  45: 45 */     JTabbedPane tabs = new JTabbedPane();
/*  46: 46 */     add("Center", tabs);
/*  47:    */     
/*  48: 48 */     addDemo(tabs, "JButtonBar", "ButtonBarMain");
/*  49: 49 */     addDemo(tabs, "JDirectoryChooser", "ChooseDirectory");
/*  50: 50 */     addDemo(tabs, "JFontChooser", "ChooseFont");
/*  51: 51 */     addDemo(tabs, "JOutlookBar", "OutlookBarMain");
/*  52: 52 */     addDemo(tabs, "JTaskPane", "TaskPaneMain");
/*  53: 53 */     addDemo(tabs, "PropertySheet", "PropertySheetMain");
/*  54: 54 */     addDemo(tabs, "JTipOfTheDay", "TOTDTest");
/*  55:    */     try
/*  56:    */     {
/*  57: 57 */       JEditorPane pane = new JEditorPane("text/html", "<html>") {
/*  58:    */         protected void paintComponent(Graphics g) {
/*  59: 59 */           Graphics2D g2d = (Graphics2D)g;
/*  60: 60 */           g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*  61:    */           
/*  62: 62 */           super.paintComponent(g);
/*  63:    */         }
/*  64: 64 */       };
/*  65: 65 */       pane.setPage(Main.class.getResource("demo.html"));
/*  66: 66 */       pane.setBackground(Color.white);
/*  67: 67 */       pane.setEditable(false);
/*  68: 68 */       pane.setOpaque(true);
/*  69: 69 */       add("South", pane);
/*  70:    */     }
/*  71:    */     catch (Exception e) {}
/*  72:    */   }
/*  73:    */   
/*  74:    */   void addDemo(JTabbedPane tabs, String title, String demoClass) {
/*  75: 75 */     String prefix = "com.l2fprod.common.demo.";
/*  76: 76 */     LookAndFeelAddons addon = LookAndFeelAddons.getAddon();
/*  77:    */     try {
/*  78: 78 */       JComponent component = (JComponent)Class.forName(prefix + demoClass).newInstance();
/*  79:    */       
/*  80: 80 */       component.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/*  81: 81 */       tabs.addTab(title, component);
/*  82:    */     }
/*  83:    */     catch (Exception e) {}finally {
/*  84:    */       try {
/*  85: 85 */         LookAndFeelAddons.setAddon(addon.getClass());
/*  86:    */       } catch (InstantiationException e1) {
/*  87: 87 */         e1.printStackTrace();
/*  88:    */       } catch (IllegalAccessException e1) {
/*  89: 89 */         e1.printStackTrace();
/*  90:    */       }
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static void main(String[] args) throws Exception {
/*  95: 95 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*  96:    */     
/*  97: 97 */     JFrame frame = new JFrame("L2FProd.com Common Components " + Version.getVersion() + " (build " + Version.getBuildTimestamp() + ")");
/*  98:    */     
/*  99: 99 */     frame.getContentPane().setLayout(new BorderLayout());
/* 100:100 */     frame.getContentPane().add("Center", new Main());
/* 101:101 */     frame.setDefaultCloseOperation(3);
/* 102:102 */     frame.setSize(450, 550);
/* 103:103 */     frame.setLocation(100, 100);
/* 104:104 */     frame.setVisible(true);
/* 105:    */   }
/* 106:    */ }
