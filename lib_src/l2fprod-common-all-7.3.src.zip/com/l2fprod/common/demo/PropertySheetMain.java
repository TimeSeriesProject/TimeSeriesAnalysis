/*  1:   */ package com.l2fprod.common.demo;
/*  2:   */ 
/*  3:   */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*  4:   */ import com.l2fprod.common.util.ResourceManager;
/*  5:   */ import java.awt.BorderLayout;
/*  6:   */ import java.awt.Container;
/*  7:   */ import javax.swing.JFrame;
/*  8:   */ import javax.swing.JPanel;
/*  9:   */ import javax.swing.JTabbedPane;
/* 10:   */ import javax.swing.UIManager;
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ public class PropertySheetMain
/* 34:   */   extends JPanel
/* 35:   */ {
/* 36:36 */   static ResourceManager RESOURCE = ResourceManager.get(PropertySheetMain.class);
/* 37:   */   
/* 38:   */   public PropertySheetMain() {
/* 39:39 */     setLayout(new BorderLayout());
/* 40:   */     
/* 41:41 */     JTabbedPane tabs = new JTabbedPane();
/* 42:42 */     tabs.add("Sheet 1", new PropertySheetPage());
/* 43:43 */     tabs.add("Sheet 2", new PropertySheetPage2());
/* 44:44 */     tabs.add("Sheet 3", new PropertySheetPage3());
/* 45:   */     
/* 46:46 */     add("Center", tabs);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public static void main(String[] args) throws Exception {
/* 50:50 */     UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 51:51 */     LookAndFeelTweaks.tweak();
/* 52:   */     
/* 53:53 */     JFrame frame = new JFrame("PropertySheet");
/* 54:54 */     frame.getContentPane().setLayout(new BorderLayout());
/* 55:55 */     frame.getContentPane().add("Center", new PropertySheetMain());
/* 56:56 */     frame.setDefaultCloseOperation(3);
/* 57:57 */     frame.pack();
/* 58:58 */     frame.setLocation(100, 100);
/* 59:59 */     frame.setVisible(true);
/* 60:   */   }
/* 61:   */ }
