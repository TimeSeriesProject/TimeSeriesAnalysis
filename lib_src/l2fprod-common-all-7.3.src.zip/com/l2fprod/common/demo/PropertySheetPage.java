/*   1:    */ package com.l2fprod.common.demo;
/*   2:    */ 
/*   3:    */ import com.l2fprod.common.beans.BaseBeanInfo;
/*   4:    */ import com.l2fprod.common.beans.ExtendedPropertyDescriptor;
/*   5:    */ import com.l2fprod.common.beans.editor.ComboBoxPropertyEditor;
/*   6:    */ import com.l2fprod.common.propertysheet.PropertySheetPanel;
/*   7:    */ import com.l2fprod.common.swing.LookAndFeelTweaks;
/*   8:    */ import com.l2fprod.common.util.ResourceManager;
/*   9:    */ import java.awt.Color;
/*  10:    */ import java.beans.PropertyChangeEvent;
/*  11:    */ import java.beans.PropertyVetoException;
/*  12:    */ import java.io.File;
/*  13:    */ import java.util.Arrays;
/*  14:    */ import java.util.ListResourceBundle;
/*  15:    */ import javax.swing.Icon;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JTextArea;
/*  18:    */ import javax.swing.UIManager;
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ public class PropertySheetPage
/*  41:    */   extends JPanel
/*  42:    */ {
/*  43:    */   public PropertySheetPage()
/*  44:    */   {
/*  45: 45 */     setLayout(LookAndFeelTweaks.createVerticalPercentLayout());
/*  46:    */     
/*  47: 47 */     JTextArea message = new JTextArea();
/*  48: 48 */     message.setText(PropertySheetMain.RESOURCE.getString("Main.sheet1.message"));
/*  49: 49 */     LookAndFeelTweaks.makeMultilineLabel(message);
/*  50: 50 */     add(message);
/*  51:    */     
/*  52: 52 */     Bean data = new Bean();
/*  53: 53 */     data.setName("John Smith");
/*  54: 54 */     data.setText("Any text here");
/*  55: 55 */     data.setColor(Color.green);
/*  56: 56 */     data.setPath(new File("."));
/*  57: 57 */     data.setVisible(true);
/*  58: 58 */     data.setTime(System.currentTimeMillis());
/*  59:    */     
/*  60: 60 */     PropertySheetPanel sheet = new PropertySheetPanel();
/*  61: 61 */     sheet.setMode(1);
/*  62: 62 */     sheet.setDescriptionVisible(true);
/*  63: 63 */     sheet.setSortingCategories(true);
/*  64: 64 */     sheet.setSortingProperties(true);
/*  65: 65 */     sheet.setRestoreToggleStates(true);
/*  66: 66 */     add(sheet, "*");
/*  67:    */     
/*  68:    */ 
/*  69: 69 */     new BeanBinder(data, sheet);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static class Bean {
/*  73:    */     private String name;
/*  74:    */     private String text;
/*  75:    */     private long time;
/*  76:    */     
/*  77: 77 */     public String getName() { return name; }
/*  78:    */     
/*  79:    */     public void setName(String name)
/*  80:    */     {
/*  81: 81 */       this.name = name;
/*  82:    */     }
/*  83:    */     
/*  84:    */     private boolean visible;
/*  85:    */     private int id;
/*  86:    */     private File path;
/*  87: 87 */     public String getText() { return text; }
/*  88:    */     
/*  89:    */ 
/*  90:    */     public void setText(String text) {
/*  91: 91 */       this.text = text;
/*  92:    */     }
/*  93:    */     
/*  94:    */ 
/*  95:    */     public long getTime()
/*  96:    */     {
/*  97: 97 */       return time;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public void setTime(long time) {
/* 101:101 */       this.time = time;
/* 102:    */     }
/* 103:    */     
/* 104:    */     public String getVersion() {
/* 105:105 */       return "1.0";
/* 106:    */     }
/* 107:    */     
/* 108:    */ 
/* 109:    */     public boolean isVisible()
/* 110:    */     {
/* 111:111 */       return visible;
/* 112:    */     }
/* 113:    */     
/* 114:    */     public void setVisible(boolean visible) {
/* 115:115 */       this.visible = visible;
/* 116:    */     }
/* 117:    */     
/* 118:    */ 
/* 119:    */     public int getId()
/* 120:    */     {
/* 121:121 */       return id;
/* 122:    */     }
/* 123:    */     
/* 124:    */     public void setId(int id) {
/* 125:125 */       this.id = id;
/* 126:    */     }
/* 127:    */     
/* 128:    */ 
/* 129:    */     public File getPath()
/* 130:    */     {
/* 131:131 */       return path;
/* 132:    */     }
/* 133:    */     
/* 134:    */     public void setPath(File path) {
/* 135:135 */       this.path = path;
/* 136:    */     }
/* 137:    */     
/* 138:138 */     private Color color = Color.blue;
/* 139:    */     
/* 140:    */     public Color getColor() {
/* 141:141 */       return color;
/* 142:    */     }
/* 143:    */     
/* 144:    */     public void setColor(Color color) {
/* 145:145 */       this.color = color;
/* 146:    */     }
/* 147:    */     
/* 148:148 */     private double doubleValue = 121210.4343543D;
/* 149:    */     private String season;
/* 150:    */     
/* 151:151 */     public void setADouble(double d) { doubleValue = d; }
/* 152:    */     
/* 153:    */     public double getADouble()
/* 154:    */     {
/* 155:155 */       return doubleValue;
/* 156:    */     }
/* 157:    */     
/* 158:    */ 
/* 159:    */     public void setSeason(String s)
/* 160:    */     {
/* 161:161 */       season = s;
/* 162:    */     }
/* 163:    */     
/* 164:    */     public String getSeason() {
/* 165:165 */       return season;
/* 166:    */     }
/* 167:    */     
/* 168:    */ 
/* 169:    */     public String getConstrained()
/* 170:    */     {
/* 171:171 */       return constrained;
/* 172:    */     }
/* 173:    */     
/* 174:    */     public void setConstrained(String constrained) throws PropertyVetoException {
/* 175:175 */       if ("blah".equals(constrained)) {
/* 176:176 */         throw new PropertyVetoException("e", new PropertyChangeEvent(this, "constrained", this.constrained, constrained));
/* 177:    */       }
/* 178:    */       
/* 179:    */ 
/* 180:180 */       this.constrained = constrained;
/* 181:    */     }
/* 182:    */     
/* 183:    */     public String toString() {
/* 184:184 */       return "[name=" + getName() + ",text=" + getText() + ",time=" + getTime() + ",version=" + getVersion() + ",visible=" + isVisible() + ",id=" + getId() + ",path=" + getPath() + ",aDouble=" + getADouble() + ",season=" + getSeason() + "]";
/* 185:    */     }
/* 186:    */     
/* 187:    */     private String constrained;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static class BeanBeanInfo
/* 191:    */     extends BaseBeanInfo
/* 192:    */   {
/* 193:    */     public BeanBeanInfo()
/* 194:    */     {
/* 195:195 */       super();
/* 196:196 */       addProperty("id").setCategory("General");
/* 197:197 */       addProperty("name").setCategory("General");
/* 198:198 */       addProperty("text").setCategory("General");
/* 199:199 */       addProperty("visible").setCategory("General");
/* 200:    */       
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:204 */       if (System.getProperty("javawebstart.version") == null) {
/* 205:205 */         addProperty("path").setCategory("Details");
/* 206:    */       }
/* 207:    */       
/* 208:208 */       addProperty("time").setCategory("Details");
/* 209:209 */       addProperty("color").setCategory("Details");
/* 210:210 */       addProperty("aDouble").setCategory("Numbers");
/* 211:211 */       addProperty("season").setCategory("Details").setPropertyEditorClass(PropertySheetPage.SeasonEditor.class);
/* 212:    */       
/* 213:    */ 
/* 214:214 */       addProperty("version");
/* 215:    */       
/* 216:216 */       addProperty("constrained");
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static class SeasonEditor extends ComboBoxPropertyEditor
/* 221:    */   {
/* 222:    */     public SeasonEditor() {
/* 223:223 */       setAvailableValues(new String[] { "Spring", "Summer", "Fall", "Winter" });
/* 224:224 */       Icon[] icons = new Icon[4];
/* 225:225 */       Arrays.fill(icons, UIManager.getIcon("Tree.openIcon"));
/* 226:226 */       setAvailableIcons(icons);
/* 227:    */     }
/* 228:    */   }
/* 229:    */   
/* 230:    */   public static class BeanRB extends ListResourceBundle
/* 231:    */   {
/* 232:    */     protected Object[][] getContents() {
/* 233:233 */       return new Object[][] { { "name", "Name" }, { "name.shortDescription", "The name of this object<br>Here I'm using multple lines<br>for the property<br>so scrollbars will get enabled" }, { "text", "Text" }, { "time", "Time" }, { "color", "Background" }, { "aDouble", "a double" }, { "season", "Season" }, { "constrained.shortDescription", "This property is constrained. Try using <b>blah</b> as the value, the previous value will be restored" } };
/* 234:    */     }
/* 235:    */   }
/* 236:    */ }
