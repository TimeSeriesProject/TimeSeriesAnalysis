package com.l2fprod.common.util.converter;

public abstract interface Converter
{
  public abstract Object convert(Class paramClass, Object paramObject);
}
