/*  1:   */ package com.l2fprod.common.util.converter;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:   */ 
/* 26:   */ public class ConverterRegistry
/* 27:   */   implements Converter
/* 28:   */ {
/* 29:29 */   private static ConverterRegistry sharedInstance = new ConverterRegistry();
/* 30:   */   private Map fromMap;
/* 31:   */   
/* 32:   */   public ConverterRegistry()
/* 33:   */   {
/* 34:34 */     fromMap = new HashMap();
/* 35:   */     
/* 36:36 */     new BooleanConverter().register(this);
/* 37:37 */     new AWTConverters().register(this);
/* 38:38 */     new NumberConverters().register(this);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void addConverter(Class from, Class to, Converter converter) {
/* 42:42 */     Map toMap = (Map)fromMap.get(from);
/* 43:43 */     if (toMap == null) {
/* 44:44 */       toMap = new HashMap();
/* 45:45 */       fromMap.put(from, toMap);
/* 46:   */     }
/* 47:47 */     toMap.put(to, converter);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public Converter getConverter(Class from, Class to) {
/* 51:51 */     Map toMap = (Map)fromMap.get(from);
/* 52:52 */     if (toMap != null) {
/* 53:53 */       return (Converter)toMap.get(to);
/* 54:   */     }
/* 55:55 */     return null;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public Object convert(Class targetType, Object value)
/* 59:   */   {
/* 60:60 */     if (value == null) {
/* 61:61 */       return null;
/* 62:   */     }
/* 63:   */     
/* 64:64 */     Converter converter = getConverter(value.getClass(), targetType);
/* 65:65 */     if (converter == null) {
/* 66:66 */       throw new IllegalArgumentException("No converter from " + value.getClass() + " to " + targetType.getName());
/* 67:   */     }
/* 68:   */     
/* 69:69 */     return converter.convert(targetType, value);
/* 70:   */   }
/* 71:   */   
/* 72:   */   public static ConverterRegistry instance()
/* 73:   */   {
/* 74:74 */     return sharedInstance;
/* 75:   */   }
/* 76:   */ }
