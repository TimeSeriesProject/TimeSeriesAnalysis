/*   1:    */ package com.l2fprod.common.util.converter;
/*   2:    */ 
/*   3:    */ import java.text.NumberFormat;
/*   4:    */ 
/*   5:    */ 
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ public class NumberConverters
/*  40:    */   implements Converter
/*  41:    */ {
/*  42:    */   private static NumberFormat defaultFormat;
/*  43:    */   private NumberFormat format;
/*  44:    */   
/*  45:    */   public NumberConverters()
/*  46:    */   {
/*  47: 47 */     this(getDefaultFormat());
/*  48:    */   }
/*  49:    */   
/*  50:    */   public NumberConverters(NumberFormat format) {
/*  51: 51 */     this.format = format;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static NumberFormat getDefaultFormat() {
/*  55: 55 */     synchronized (NumberConverters.class) {
/*  56: 56 */       if (defaultFormat == null) {
/*  57: 57 */         defaultFormat = NumberFormat.getNumberInstance();
/*  58: 58 */         defaultFormat.setMinimumIntegerDigits(1);
/*  59: 59 */         defaultFormat.setMaximumIntegerDigits(64);
/*  60: 60 */         defaultFormat.setMinimumFractionDigits(0);
/*  61: 61 */         defaultFormat.setMaximumFractionDigits(64);
/*  62:    */       }
/*  63:    */     }
/*  64: 64 */     return defaultFormat;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void register(ConverterRegistry registry) {
/*  68: 68 */     registry.addConverter(Number.class, Double.class, this);
/*  69: 69 */     registry.addConverter(Number.class, Float.class, this);
/*  70: 70 */     registry.addConverter(Number.class, Integer.class, this);
/*  71: 71 */     registry.addConverter(Number.class, Long.class, this);
/*  72: 72 */     registry.addConverter(Number.class, Short.class, this);
/*  73:    */     
/*  74: 74 */     registry.addConverter(Double.class, Double.class, this);
/*  75: 75 */     registry.addConverter(Double.class, Float.class, this);
/*  76: 76 */     registry.addConverter(Double.class, Integer.class, this);
/*  77: 77 */     registry.addConverter(Double.class, Long.class, this);
/*  78: 78 */     registry.addConverter(Double.class, Short.class, this);
/*  79: 79 */     registry.addConverter(Double.class, String.class, this);
/*  80:    */     
/*  81: 81 */     registry.addConverter(Float.class, Double.class, this);
/*  82: 82 */     registry.addConverter(Float.class, Float.class, this);
/*  83: 83 */     registry.addConverter(Float.class, Integer.class, this);
/*  84: 84 */     registry.addConverter(Float.class, Long.class, this);
/*  85: 85 */     registry.addConverter(Float.class, Short.class, this);
/*  86: 86 */     registry.addConverter(Float.class, String.class, this);
/*  87:    */     
/*  88: 88 */     registry.addConverter(Integer.class, Double.class, this);
/*  89: 89 */     registry.addConverter(Integer.class, Float.class, this);
/*  90: 90 */     registry.addConverter(Integer.class, Integer.class, this);
/*  91: 91 */     registry.addConverter(Integer.class, Long.class, this);
/*  92: 92 */     registry.addConverter(Integer.class, Short.class, this);
/*  93: 93 */     registry.addConverter(Integer.class, String.class, this);
/*  94:    */     
/*  95: 95 */     registry.addConverter(Long.class, Double.class, this);
/*  96: 96 */     registry.addConverter(Long.class, Float.class, this);
/*  97: 97 */     registry.addConverter(Long.class, Integer.class, this);
/*  98: 98 */     registry.addConverter(Long.class, Long.class, this);
/*  99: 99 */     registry.addConverter(Long.class, Short.class, this);
/* 100:100 */     registry.addConverter(Long.class, String.class, this);
/* 101:    */     
/* 102:102 */     registry.addConverter(Short.class, Double.class, this);
/* 103:103 */     registry.addConverter(Short.class, Float.class, this);
/* 104:104 */     registry.addConverter(Short.class, Integer.class, this);
/* 105:105 */     registry.addConverter(Short.class, Long.class, this);
/* 106:106 */     registry.addConverter(Short.class, Short.class, this);
/* 107:107 */     registry.addConverter(Short.class, String.class, this);
/* 108:    */     
/* 109:109 */     registry.addConverter(String.class, Double.class, this);
/* 110:110 */     registry.addConverter(String.class, Float.class, this);
/* 111:111 */     registry.addConverter(String.class, Integer.class, this);
/* 112:112 */     registry.addConverter(String.class, Long.class, this);
/* 113:113 */     registry.addConverter(String.class, Short.class, this);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public Object convert(Class targetType, Object value)
/* 117:    */   {
/* 118:118 */     if (((value instanceof Number)) && (Number.class.isAssignableFrom(targetType))) {
/* 119:119 */       if (Double.class.equals(targetType))
/* 120:120 */         return new Double(((Number)value).doubleValue());
/* 121:121 */       if (Float.class.equals(targetType))
/* 122:122 */         return new Float(((Number)value).floatValue());
/* 123:123 */       if (Integer.class.equals(targetType))
/* 124:124 */         return new Integer(((Number)value).intValue());
/* 125:125 */       if (Long.class.equals(targetType))
/* 126:126 */         return new Long(((Number)value).longValue());
/* 127:127 */       if (Short.class.equals(targetType)) {
/* 128:128 */         return new Short(((Number)value).shortValue());
/* 129:    */       }
/* 130:130 */       throw new IllegalArgumentException("this code must not be reached");
/* 131:    */     }
/* 132:132 */     if (((value instanceof Number)) && (String.class.equals(targetType))) {
/* 133:133 */       if (((value instanceof Double)) || ((value instanceof Float))) {
/* 134:134 */         return format.format(((Number)value).doubleValue());
/* 135:    */       }
/* 136:136 */       return format.format(((Number)value).longValue());
/* 137:    */     }
/* 138:138 */     if (((value instanceof String)) && (Number.class.isAssignableFrom(targetType))) {
/* 139:139 */       if (Double.class.equals(targetType))
/* 140:140 */         return new Double((String)value);
/* 141:141 */       if (Float.class.equals(targetType))
/* 142:142 */         return new Float((String)value);
/* 143:143 */       if (Integer.class.equals(targetType))
/* 144:144 */         return new Integer((String)value);
/* 145:145 */       if (Long.class.equals(targetType))
/* 146:146 */         return new Long((String)value);
/* 147:147 */       if (Short.class.equals(targetType)) {
/* 148:148 */         return new Short((String)value);
/* 149:    */       }
/* 150:150 */       throw new IllegalArgumentException("this code must not be reached");
/* 151:    */     }
/* 152:    */     
/* 153:153 */     throw new IllegalArgumentException("no conversion supported");
/* 154:    */   }
/* 155:    */ }
