/*  1:   */ package com.l2fprod.common.util.converter;
/*  2:   */ 
/*  3:   */ 
/*  4:   */ 
/*  5:   */ 
/*  6:   */ 
/*  7:   */ 
/*  8:   */ 
/*  9:   */ 
/* 10:   */ 
/* 11:   */ 
/* 12:   */ 
/* 13:   */ 
/* 14:   */ 
/* 15:   */ 
/* 16:   */ 
/* 17:   */ 
/* 18:   */ 
/* 19:   */ 
/* 20:   */ 
/* 21:   */ public class BooleanConverter
/* 22:   */   implements Converter
/* 23:   */ {
/* 24:   */   public void register(ConverterRegistry registry)
/* 25:   */   {
/* 26:26 */     registry.addConverter(String.class, Boolean.TYPE, this);
/* 27:27 */     registry.addConverter(String.class, Boolean.class, this);
/* 28:28 */     registry.addConverter(Boolean.class, String.class, this);
/* 29:29 */     registry.addConverter(Boolean.TYPE, String.class, this);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Object convert(Class type, Object value) {
/* 33:33 */     if ((String.class.equals(type)) && (Boolean.class.equals(value.getClass())))
/* 34:34 */       return String.valueOf(value);
/* 35:35 */     if ((Boolean.TYPE.equals(type)) || (Boolean.class.equals(type))) {
/* 36:36 */       return Boolean.valueOf(String.valueOf(value));
/* 37:   */     }
/* 38:38 */     throw new IllegalArgumentException("Can't convert " + value + " to " + type.getName());
/* 39:   */   }
/* 40:   */ }
