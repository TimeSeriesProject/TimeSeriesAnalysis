/*   1:    */ package com.l2fprod.common.util.converter;
/*   2:    */ 
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.Insets;
/*   6:    */ import java.awt.Point;
/*   7:    */ import java.awt.Rectangle;
/*   8:    */ import java.util.StringTokenizer;
/*   9:    */ import javax.swing.plaf.DimensionUIResource;
/*  10:    */ import javax.swing.plaf.FontUIResource;
/*  11:    */ import javax.swing.plaf.InsetsUIResource;
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:    */ 
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ public class AWTConverters
/*  74:    */   implements Converter
/*  75:    */ {
/*  76:    */   public void register(ConverterRegistry registry)
/*  77:    */   {
/*  78: 78 */     registry.addConverter(Dimension.class, String.class, this);
/*  79: 79 */     registry.addConverter(String.class, Dimension.class, this);
/*  80: 80 */     registry.addConverter(DimensionUIResource.class, String.class, this);
/*  81:    */     
/*  82: 82 */     registry.addConverter(Insets.class, String.class, this);
/*  83: 83 */     registry.addConverter(String.class, Insets.class, this);
/*  84: 84 */     registry.addConverter(InsetsUIResource.class, String.class, this);
/*  85:    */     
/*  86: 86 */     registry.addConverter(Point.class, String.class, this);
/*  87: 87 */     registry.addConverter(String.class, Point.class, this);
/*  88:    */     
/*  89: 89 */     registry.addConverter(Rectangle.class, String.class, this);
/*  90: 90 */     registry.addConverter(String.class, Rectangle.class, this);
/*  91:    */     
/*  92: 92 */     registry.addConverter(Font.class, String.class, this);
/*  93: 93 */     registry.addConverter(FontUIResource.class, String.class, this);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Object convert(Class type, Object value) {
/*  97: 97 */     if (String.class.equals(type)) {
/*  98: 98 */       if ((value instanceof Rectangle)) {
/*  99: 99 */         return ((Rectangle)value).getX() + " " + ((Rectangle)value).getY() + " " + ((Rectangle)value).getWidth() + " " + ((Rectangle)value).getHeight();
/* 100:    */       }
/* 101:    */       
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:106 */       if ((value instanceof Insets)) {
/* 107:107 */         return top + " " + left + " " + bottom + " " + right;
/* 108:    */       }
/* 109:    */       
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:114 */       if ((value instanceof Dimension)) {
/* 115:115 */         return ((Dimension)value).getWidth() + " x " + ((Dimension)value).getHeight();
/* 116:    */       }
/* 117:    */       
/* 118:118 */       if (Point.class.equals(value.getClass()))
/* 119:119 */         return ((Point)value).getX() + " " + ((Point)value).getY();
/* 120:120 */       if ((value instanceof Font)) {
/* 121:121 */         return ((Font)value).getFontName() + ", " + ((Font)value).getStyle() + ", " + ((Font)value).getSize();
/* 122:    */       }
/* 123:    */     }
/* 124:    */     
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:129 */     if ((value instanceof String)) {
/* 130:130 */       if (Rectangle.class.equals(type)) {
/* 131:131 */         double[] values = convert((String)value, 4, " ");
/* 132:132 */         if (values == null) {
/* 133:133 */           throw new IllegalArgumentException("Invalid format");
/* 134:    */         }
/* 135:135 */         Rectangle rect = new Rectangle();
/* 136:136 */         rect.setFrame(values[0], values[1], values[2], values[3]);
/* 137:137 */         return rect; }
/* 138:138 */       if (Insets.class.equals(type)) {
/* 139:139 */         double[] values = convert((String)value, 4, " ");
/* 140:140 */         if (values == null) {
/* 141:141 */           throw new IllegalArgumentException("Invalid format");
/* 142:    */         }
/* 143:143 */         return new Insets((int)values[0], (int)values[1], (int)values[2], (int)values[3]);
/* 144:    */       }
/* 145:    */       
/* 146:    */ 
/* 147:    */ 
/* 148:148 */       if (Dimension.class.equals(type)) {
/* 149:149 */         double[] values = convert((String)value, 2, "x");
/* 150:150 */         if (values == null) {
/* 151:151 */           throw new IllegalArgumentException("Invalid format");
/* 152:    */         }
/* 153:153 */         Dimension dim = new Dimension();
/* 154:154 */         dim.setSize(values[0], values[1]);
/* 155:155 */         return dim; }
/* 156:156 */       if (Point.class.equals(type)) {
/* 157:157 */         double[] values = convert((String)value, 2, " ");
/* 158:158 */         if (values == null) {
/* 159:159 */           throw new IllegalArgumentException("Invalid format");
/* 160:    */         }
/* 161:161 */         Point p = new Point();
/* 162:162 */         p.setLocation(values[0], values[1]);
/* 163:163 */         return p;
/* 164:    */       }
/* 165:    */     }
/* 166:166 */     return null;
/* 167:    */   }
/* 168:    */   
/* 169:    */   private double[] convert(String text, int tokenCount, String delimiters) {
/* 170:170 */     StringTokenizer tokenizer = new StringTokenizer(text, delimiters);
/* 171:171 */     if (tokenizer.countTokens() != tokenCount) {
/* 172:172 */       return null;
/* 173:    */     }
/* 174:    */     try
/* 175:    */     {
/* 176:176 */       double[] values = new double[tokenCount];
/* 177:177 */       for (int i = 0; tokenizer.hasMoreTokens(); i++) {
/* 178:178 */         values[i] = Double.parseDouble(tokenizer.nextToken());
/* 179:    */       }
/* 180:180 */       return values;
/* 181:    */     } catch (Exception e) {}
/* 182:182 */     return null;
/* 183:    */   }
/* 184:    */ }
