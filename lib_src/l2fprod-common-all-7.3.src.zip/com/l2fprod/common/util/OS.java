/*   1:    */ package com.l2fprod.common.util;
/*   2:    */ 
/*   3:    */ import java.awt.Toolkit;
/*   4:    */ import javax.swing.UIManager;
/*   5:    */ 
/*   6:    */ 
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ public class OS
/*  27:    */ {
/*  28:    */   private static final boolean osIsMacOsX;
/*  29:    */   private static final boolean osIsWindows;
/*  30:    */   private static final boolean osIsWindowsXP;
/*  31:    */   private static final boolean osIsWindows2003;
/*  32:    */   private static final boolean osIsWindowsVista;
/*  33:    */   private static final boolean osIsLinux;
/*  34:    */   
/*  35:    */   static
/*  36:    */   {
/*  37: 37 */     String os = System.getProperty("os.name").toLowerCase();
/*  38:    */     
/*  39: 39 */     osIsMacOsX = "mac os x".equals(os);
/*  40: 40 */     osIsWindows = os.indexOf("windows") != -1;
/*  41: 41 */     osIsWindowsXP = "windows xp".equals(os);
/*  42: 42 */     osIsWindows2003 = "windows 2003".equals(os);
/*  43: 43 */     osIsWindowsVista = "windows vista".equals(os);
/*  44: 44 */     osIsLinux = (os != null) && (os.indexOf("linux") != -1);
/*  45:    */   }
/*  46:    */   
/*  47:    */ 
/*  48:    */ 
/*  49:    */   public static boolean isMacOSX()
/*  50:    */   {
/*  51: 51 */     return osIsMacOsX;
/*  52:    */   }
/*  53:    */   
/*  54:    */ 
/*  55:    */ 
/*  56:    */   public static boolean isWindows()
/*  57:    */   {
/*  58: 58 */     return osIsWindows;
/*  59:    */   }
/*  60:    */   
/*  61:    */ 
/*  62:    */ 
/*  63:    */   public static boolean isWindowsXP()
/*  64:    */   {
/*  65: 65 */     return osIsWindowsXP;
/*  66:    */   }
/*  67:    */   
/*  68:    */ 
/*  69:    */ 
/*  70:    */   public static boolean isWindows2003()
/*  71:    */   {
/*  72: 72 */     return osIsWindows2003;
/*  73:    */   }
/*  74:    */   
/*  75:    */ 
/*  76:    */ 
/*  77:    */   public static boolean isWindowsVista()
/*  78:    */   {
/*  79: 79 */     return osIsWindowsVista;
/*  80:    */   }
/*  81:    */   
/*  82:    */ 
/*  83:    */ 
/*  84:    */   public static boolean isLinux()
/*  85:    */   {
/*  86: 86 */     return osIsLinux;
/*  87:    */   }
/*  88:    */   
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */   public static boolean isUsingWindowsVisualStyles()
/*  93:    */   {
/*  94: 94 */     if (!isWindows()) {
/*  95: 95 */       return false;
/*  96:    */     }
/*  97:    */     
/*  98: 98 */     boolean xpthemeActive = Boolean.TRUE.equals(Toolkit.getDefaultToolkit().getDesktopProperty("win.xpstyle.themeActive"));
/*  99:    */     
/* 100:100 */     if (!xpthemeActive) {
/* 101:101 */       return false;
/* 102:    */     }
/* 103:    */     try {
/* 104:104 */       return System.getProperty("swing.noxp") == null;
/* 105:    */     } catch (RuntimeException e) {}
/* 106:106 */     return true;
/* 107:    */   }
/* 108:    */   
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */   public static String getWindowsVisualStyle()
/* 120:    */   {
/* 121:121 */     String style = UIManager.getString("win.xpstyle.name");
/* 122:122 */     if (style == null)
/* 123:    */     {
/* 124:    */ 
/* 125:    */ 
/* 126:126 */       style = (String)Toolkit.getDefaultToolkit().getDesktopProperty("win.xpstyle.colorName");
/* 127:    */     }
/* 128:    */     
/* 129:129 */     return style;
/* 130:    */   }
/* 131:    */ }
