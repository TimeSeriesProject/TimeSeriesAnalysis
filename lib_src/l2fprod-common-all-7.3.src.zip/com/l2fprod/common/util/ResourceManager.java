/*   1:    */ package com.l2fprod.common.util;
/*   2:    */ 
/*   3:    */ import java.text.MessageFormat;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.ResourceBundle;
/*   7:    */ 
/*   8:    */ 
/*   9:    */ 
/*  10:    */ 
/*  11:    */ 
/*  12:    */ 
/*  13:    */ 
/*  14:    */ 
/*  15:    */ 
/*  16:    */ 
/*  17:    */ 
/*  18:    */ 
/*  19:    */ 
/*  20:    */ 
/*  21:    */ 
/*  22:    */ 
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28:    */ public class ResourceManager
/*  29:    */ {
/*  30: 30 */   static Map nameToRM = new HashMap();
/*  31:    */   
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */   private ResourceBundle bundle;
/*  37:    */   
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42:    */   public static ResourceManager get(Class clazz)
/*  43:    */   {
/*  44: 44 */     String bundleName = clazz.getName() + "RB";
/*  45: 45 */     return get(bundleName);
/*  46:    */   }
/*  47:    */   
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */   public static ResourceManager get(String bundleName)
/*  54:    */   {
/*  55: 55 */     ResourceManager rm = (ResourceManager)nameToRM.get(bundleName);
/*  56: 56 */     if (rm == null) {
/*  57: 57 */       ResourceBundle rb = ResourceBundle.getBundle(bundleName);
/*  58: 58 */       rm = new ResourceManager(rb);
/*  59: 59 */       nameToRM.put(bundleName, rm);
/*  60:    */     }
/*  61: 61 */     return rm;
/*  62:    */   }
/*  63:    */   
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */   public static ResourceManager all(Class clazz)
/*  68:    */   {
/*  69: 69 */     return get(getPackage(clazz) + ".AllRB");
/*  70:    */   }
/*  71:    */   
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */   public static ResourceManager common()
/*  80:    */   {
/*  81: 81 */     return all(ResourceManager.class);
/*  82:    */   }
/*  83:    */   
/*  84:    */ 
/*  85:    */ 
/*  86:    */   public static ResourceManager ui()
/*  87:    */   {
/*  88: 88 */     return get("com.l2fprod.common.swing.AllRB");
/*  89:    */   }
/*  90:    */   
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */   public static String resolve(String rbAndProperty)
/* 102:    */   {
/* 103:103 */     return common().resolve0(rbAndProperty);
/* 104:    */   }
/* 105:    */   
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */   public static String resolve(String rbAndProperty, Object[] args)
/* 115:    */   {
/* 116:116 */     String value = common().resolve0(rbAndProperty);
/* 117:117 */     return MessageFormat.format(value, args);
/* 118:    */   }
/* 119:    */   
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */   private ResourceManager(ResourceBundle bundle)
/* 125:    */   {
/* 126:126 */     this.bundle = bundle;
/* 127:    */   }
/* 128:    */   
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */   public String getString(String key)
/* 136:    */   {
/* 137:137 */     return resolve0(String.valueOf(bundle.getObject(key)));
/* 138:    */   }
/* 139:    */   
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:    */   public String getString(String key, Object[] args)
/* 149:    */   {
/* 150:150 */     String value = getString(key);
/* 151:151 */     return MessageFormat.format(value, args);
/* 152:    */   }
/* 153:    */   
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */   public char getChar(String key)
/* 162:    */   {
/* 163:163 */     String s = getString(key);
/* 164:164 */     if ((s == null) || (s.trim().length() == 0)) {
/* 165:165 */       return '\000';
/* 166:    */     }
/* 167:167 */     return s.charAt(0);
/* 168:    */   }
/* 169:    */   
/* 170:    */   private String resolve0(String property)
/* 171:    */   {
/* 172:172 */     String result = property;
/* 173:173 */     if (property != null) {
/* 174:174 */       int index = property.indexOf("${");
/* 175:175 */       if (index != -1) {
/* 176:176 */         int endIndex = property.indexOf("}", index);
/* 177:177 */         String sub = property.substring(index + 2, endIndex);
/* 178:    */         
/* 179:179 */         int colon = sub.indexOf(":");
/* 180:180 */         if (colon != -1) {
/* 181:181 */           String rbName = sub.substring(0, colon);
/* 182:182 */           String keyName = sub.substring(colon + 1);
/* 183:183 */           sub = get(rbName).getString(keyName);
/* 184:    */         }
/* 185:    */         else {
/* 186:186 */           sub = getString(sub);
/* 187:    */         }
/* 188:188 */         result = property.substring(0, index) + sub + resolve0(property.substring(endIndex + 1));
/* 189:    */       }
/* 190:    */     }
/* 191:    */     
/* 192:192 */     return result;
/* 193:    */   }
/* 194:    */   
/* 195:    */   private static String getPackage(Class clazz) {
/* 196:196 */     String pck = clazz.getName();
/* 197:197 */     int index = pck.lastIndexOf('.');
/* 198:198 */     if (index != -1) {
/* 199:199 */       pck = pck.substring(0, index);
/* 200:    */     } else {
/* 201:201 */       pck = "";
/* 202:    */     }
/* 203:203 */     return pck;
/* 204:    */   }
/* 205:    */ }
