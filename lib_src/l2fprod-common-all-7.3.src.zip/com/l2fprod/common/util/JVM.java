/*   1:    */ package com.l2fprod.common.util;
/*   2:    */ 
/*   3:    */ 
/*   4:    */ 
/*   5:    */ 
/*   6:    */ public class JVM
/*   7:    */ {
/*   8:    */   public static final int JDK1_0 = 10;
/*   9:    */   
/*  10:    */ 
/*  11:    */ 
/*  12:    */   public static final int JDK1_1 = 11;
/*  13:    */   
/*  14:    */ 
/*  15:    */ 
/*  16:    */   public static final int JDK1_2 = 12;
/*  17:    */   
/*  18:    */ 
/*  19:    */ 
/*  20:    */   public static final int JDK1_3 = 13;
/*  21:    */   
/*  22:    */ 
/*  23:    */ 
/*  24:    */   public static final int JDK1_4 = 14;
/*  25:    */   
/*  26:    */ 
/*  27:    */ 
/*  28:    */   public static final int JDK1_5 = 15;
/*  29:    */   
/*  30:    */ 
/*  31:    */ 
/*  32:    */   public static final int JDK1_6 = 16;
/*  33:    */   
/*  34:    */ 
/*  35: 35 */   private static JVM current = new JVM();
/*  36:    */   
/*  37:    */   private int jdkVersion;
/*  38:    */   
/*  39:    */ 
/*  40:    */   public static JVM current()
/*  41:    */   {
/*  42: 42 */     return current;
/*  43:    */   }
/*  44:    */   
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */   public JVM()
/*  52:    */   {
/*  53: 53 */     this(System.getProperty("java.version"));
/*  54:    */   }
/*  55:    */   
/*  56:    */ 
/*  57:    */ 
/*  58:    */   public JVM(String p_JavaVersion)
/*  59:    */   {
/*  60: 60 */     if (p_JavaVersion.startsWith("1.6.")) {
/*  61: 61 */       jdkVersion = 16;
/*  62: 62 */     } else if (p_JavaVersion.startsWith("1.5.")) {
/*  63: 63 */       jdkVersion = 15;
/*  64: 64 */     } else if (p_JavaVersion.startsWith("1.4.")) {
/*  65: 65 */       jdkVersion = 14;
/*  66: 66 */     } else if (p_JavaVersion.startsWith("1.3.")) {
/*  67: 67 */       jdkVersion = 13;
/*  68: 68 */     } else if (p_JavaVersion.startsWith("1.2.")) {
/*  69: 69 */       jdkVersion = 12;
/*  70: 70 */     } else if (p_JavaVersion.startsWith("1.1.")) {
/*  71: 71 */       jdkVersion = 11;
/*  72: 72 */     } else if (p_JavaVersion.startsWith("1.0.")) {
/*  73: 73 */       jdkVersion = 10;
/*  74:    */     }
/*  75:    */     else {
/*  76: 76 */       jdkVersion = 13;
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isOrLater(int p_Version) {
/*  81: 81 */     return jdkVersion >= p_Version;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isOneDotOne() {
/*  85: 85 */     return jdkVersion == 11;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean isOneDotTwo() {
/*  89: 89 */     return jdkVersion == 12;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isOneDotThree() {
/*  93: 93 */     return jdkVersion == 13;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean isOneDotFour() {
/*  97: 97 */     return jdkVersion == 14;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isOneDotFive() {
/* 101:101 */     return jdkVersion == 15;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean isOneDotSix() {
/* 105:105 */     return jdkVersion == 16;
/* 106:    */   }
/* 107:    */ }
