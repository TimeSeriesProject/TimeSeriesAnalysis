package org.jnetpcap;

import java.nio.ByteBuffer;

public abstract interface ByteBufferHandler<T>
{
  public abstract void nextPacket(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer, T paramT);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.ByteBufferHandler
 * JD-Core Version:    0.7.0.1
 */