package org.jnetpcap.nio;

import java.nio.ByteBuffer;

public class JStruct
  extends JMemory
{
  private final String structName;
  
  public JStruct(String paramString, JMemory.Type paramType)
  {
    super(paramType);
    this.structName = paramString;
  }
  
  public JStruct(String paramString, ByteBuffer paramByteBuffer)
  {
    super(paramByteBuffer);
    this.structName = paramString;
  }
  
  public JStruct(String paramString, int paramInt)
  {
    super(paramInt);
    this.structName = paramString;
  }
  
  public JStruct(String paramString, JMemory paramJMemory)
  {
    super(paramJMemory);
    this.structName = paramString;
  }
  
  public final String getStructName()
  {
    return this.structName;
  }
  
  public String toString()
  {
    return "struct " + this.structName;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JStruct
 * JD-Core Version:    0.7.0.1
 */