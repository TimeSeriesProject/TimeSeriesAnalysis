package org.jnetpcap.nio;

import java.lang.ref.PhantomReference;

public abstract class DisposableReference
  extends PhantomReference<Object>
  implements Disposable, Link<DisposableReference>
{
  private static final DisposableGC gc = ;
  private Link<DisposableReference> linkNext;
  private Link<DisposableReference> linkPrev;
  private long ts = System.currentTimeMillis();
  private LinkSequence<DisposableReference> linkCollection;
  
  public DisposableReference(Object paramObject)
  {
    super(paramObject, gc.refQueue);
    synchronized (gc.g0)
    {
      gc.g0.add(this);
    }
    if (!gc.isCleanupThreadActive()) {
      gc.drainRefQueueBounded();
    }
  }
  
  public void dispose() {}
  
  public DisposableReference linkElement()
  {
    return this;
  }
  
  public LinkSequence<DisposableReference> linkCollection()
  {
    return this.linkCollection;
  }
  
  public void linkCollection(LinkSequence<DisposableReference> paramLinkSequence)
  {
    this.linkCollection = paramLinkSequence;
  }
  
  public Link<DisposableReference> linkNext()
  {
    return this.linkNext;
  }
  
  public void linkNext(Link<DisposableReference> paramLink)
  {
    this.linkNext = paramLink;
  }
  
  public Link<DisposableReference> linkPrev()
  {
    return this.linkPrev;
  }
  
  public void linkPrev(Link<DisposableReference> paramLink)
  {
    this.linkPrev = paramLink;
  }
  
  public String toString()
  {
    return String.format("prev=%s, next=%s", new Object[] { this.linkPrev, this.linkNext });
  }
  
  public void remove()
  {
    linkCollection().remove(this);
    super.clear();
  }
  
  public int size()
  {
    return 0;
  }
  
  public long getTs()
  {
    return this.ts;
  }
  
  public void setTs(long paramLong)
  {
    this.ts = paramLong;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.DisposableReference
 * JD-Core Version:    0.7.0.1
 */