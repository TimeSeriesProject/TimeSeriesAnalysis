package org.jnetpcap.nio;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.jnetpcap.packet.PeeringException;

public class JBuffer
  extends JMemory
{
  private volatile boolean order = ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN;
  private boolean readonly = false;
  
  private static native void initIds();
  
  public JBuffer(JMemory.Type paramType)
  {
    super(paramType);
  }
  
  public JBuffer(ByteBuffer paramByteBuffer)
  {
    super(paramByteBuffer);
  }
  
  public JBuffer(int paramInt)
  {
    super(paramInt);
  }
  
  public JBuffer(JMemory paramJMemory)
  {
    super(paramJMemory);
  }
  
  private final int check(int paramInt1, int paramInt2, long paramLong)
  {
    if (paramLong == 0L) {
      throw new NullPointerException();
    }
    if ((paramInt1 < 0) || (paramInt1 + paramInt2 > this.size)) {
      throw new BufferUnderflowException();
    }
    return paramInt1;
  }
  
  public JBuffer(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte.length);
    setByteArray(0, paramArrayOfByte);
  }
  
  public byte getByte(int paramInt)
  {
    return getByte0(this.physical, check(paramInt, 1, this.physical));
  }
  
  private static native byte getByte0(long paramLong, int paramInt);
  
  public byte[] getByteArray(int paramInt, byte[] paramArrayOfByte)
  {
    return getByteArray(paramInt, paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public byte[] getByteArray(int paramInt1, int paramInt2)
  {
    return getByteArray(paramInt1, new byte[paramInt2], 0, paramInt2);
  }
  
  public byte[] getByteArray(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    if (paramArrayOfByte == null) {
      throw new NullPointerException();
    }
    if ((paramInt2 < 0) || (paramInt2 + paramInt3 > paramArrayOfByte.length)) {
      throw new ArrayIndexOutOfBoundsException();
    }
    return getByteArray0(this.physical, check(paramInt1, paramInt3, this.physical), paramArrayOfByte, paramArrayOfByte.length, paramInt2, paramInt3);
  }
  
  private static native byte[] getByteArray0(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4);
  
  public double getDouble(int paramInt)
  {
    return getDouble0(this.physical, this.order, check(paramInt, 8, this.physical));
  }
  
  private static native double getDouble0(long paramLong, boolean paramBoolean, int paramInt);
  
  public float getFloat(int paramInt)
  {
    return getFloat0(this.physical, this.order, check(paramInt, 4, this.physical));
  }
  
  private static native float getFloat0(long paramLong, boolean paramBoolean, int paramInt);
  
  public int getInt(int paramInt)
  {
    return getInt0(this.physical, this.order, check(paramInt, 4, this.physical));
  }
  
  private static native int getInt0(long paramLong, boolean paramBoolean, int paramInt);
  
  public long getLong(int paramInt)
  {
    return getLong0(this.physical, this.order, check(paramInt, 8, this.physical));
  }
  
  private static native long getLong0(long paramLong, boolean paramBoolean, int paramInt);
  
  public short getShort(int paramInt)
  {
    return getShort0(this.physical, this.order, check(paramInt, 2, this.physical));
  }
  
  private static native short getShort0(long paramLong, boolean paramBoolean, int paramInt);
  
  public int getUByte(int paramInt)
  {
    return getUByte0(this.physical, check(paramInt, 1, this.physical));
  }
  
  private static native int getUByte0(long paramLong, int paramInt);
  
  public long getUInt(int paramInt)
  {
    return getUInt0(this.physical, this.order, check(paramInt, 4, this.physical));
  }
  
  private static native long getUInt0(long paramLong, boolean paramBoolean, int paramInt);
  
  public int getUShort(int paramInt)
  {
    return getUShort0(this.physical, this.order, check(paramInt, 2, this.physical));
  }
  
  private static native int getUShort0(long paramLong, boolean paramBoolean, int paramInt);
  
  public int findUTF8String(int paramInt, char... paramVarArgs)
  {
    int i = size();
    int j = 0;
    int k = 0;
    for (int m = paramInt; m < i; m++)
    {
      char c1 = getUTF8Char(m);
      char c2 = paramVarArgs[k];
      if (!Character.isDefined(c1)) {
        break;
      }
      if (c2 == c1)
      {
        k++;
        if (k == paramVarArgs.length)
        {
          j = m - paramInt + 1;
          break;
        }
      }
      else
      {
        k = 0;
      }
    }
    return j;
  }
  
  public StringBuilder getUTF8String(int paramInt, StringBuilder paramStringBuilder, char... paramVarArgs)
  {
    int i = size();
    int j = paramInt + i;
    int k = 0;
    for (int m = paramInt; m < j; m++)
    {
      if (m >= i) {
        return paramStringBuilder;
      }
      if (k == paramVarArgs.length) {
        break;
      }
      char c = getUTF8Char(m);
      paramStringBuilder.append(c);
      if (paramVarArgs[k] == c) {
        k++;
      } else {
        k = 0;
      }
    }
    return paramStringBuilder;
  }
  
  public String getUTF8String(int paramInt, char... paramVarArgs)
  {
    StringBuilder localStringBuilder = getUTF8String(paramInt, new StringBuilder(), paramVarArgs);
    return localStringBuilder.toString();
  }
  
  public StringBuilder getUTF8String(int paramInt1, StringBuilder paramStringBuilder, int paramInt2)
  {
    int i = paramInt1 + (size() < paramInt2 ? size() : paramInt2);
    for (int j = paramInt1; j < i; j++)
    {
      char c = getUTF8Char(j);
      paramStringBuilder.append(c);
    }
    return paramStringBuilder;
  }
  
  public String getUTF8String(int paramInt1, int paramInt2)
  {
    return getUTF8String(paramInt1, new StringBuilder(), paramInt2).toString();
  }
  
  public char getUTF8Char(int paramInt)
  {
    return (char)getUByte(paramInt);
  }
  
  public boolean isReadonly()
  {
    return this.readonly;
  }
  
  public ByteOrder order()
  {
    return this.order ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN;
  }
  
  public void order(ByteOrder paramByteOrder)
  {
    this.order = (paramByteOrder == ByteOrder.BIG_ENDIAN);
  }
  
  public int peer(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    setReadonly(paramByteBuffer.isReadOnly());
    return super.peer(paramByteBuffer);
  }
  
  public int peer(JBuffer paramJBuffer)
  {
    setReadonly(paramJBuffer.isReadonly());
    return super.peer(paramJBuffer);
  }
  
  public int peer(JBuffer paramJBuffer, int paramInt1, int paramInt2)
    throws IndexOutOfBoundsException
  {
    setReadonly(paramJBuffer.isReadonly());
    return super.peer(paramJBuffer, paramInt1, paramInt2);
  }
  
  public void setByte(int paramInt, byte paramByte)
  {
    setByte0(this.physical, check(paramInt, 1, this.physical), paramByte);
  }
  
  private static native void setByte0(long paramLong, int paramInt, byte paramByte);
  
  public void setByteArray(int paramInt, byte[] paramArrayOfByte)
  {
    setByteArray0(this.physical, check(paramInt, paramArrayOfByte.length, this.physical), paramArrayOfByte, paramArrayOfByte.length);
  }
  
  private static native void setByteArray0(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public void setDouble(int paramInt, double paramDouble)
  {
    setDouble0(this.physical, this.order, check(paramInt, 8, this.physical), paramDouble);
  }
  
  private static native void setDouble0(long paramLong, boolean paramBoolean, int paramInt, double paramDouble);
  
  public void setFloat(int paramInt, float paramFloat)
  {
    setFloat0(this.physical, this.order, check(paramInt, 4, this.physical), paramFloat);
  }
  
  private static native void setFloat0(long paramLong, boolean paramBoolean, int paramInt, float paramFloat);
  
  public void setInt(int paramInt1, int paramInt2)
  {
    setInt0(this.physical, this.order, check(paramInt1, 4, this.physical), paramInt2);
  }
  
  private static native void setInt0(long paramLong, boolean paramBoolean, int paramInt1, int paramInt2);
  
  public void setLong(int paramInt, long paramLong)
  {
    setLong0(this.physical, this.order, check(paramInt, 8, this.physical), paramLong);
  }
  
  private static native void setLong0(long paramLong1, boolean paramBoolean, int paramInt, long paramLong2);
  
  public void setShort(int paramInt, short paramShort)
  {
    setShort0(this.physical, this.order, check(paramInt, 2, this.physical), paramShort);
  }
  
  public static native void setShort0(long paramLong, boolean paramBoolean, int paramInt, short paramShort);
  
  public void setUByte(int paramInt1, int paramInt2)
  {
    setUByte0(this.physical, check(paramInt1, 1, this.physical), paramInt2);
  }
  
  private static native void setUByte0(long paramLong, int paramInt1, int paramInt2);
  
  public void setUInt(int paramInt, long paramLong)
  {
    setUInt0(this.physical, this.order, check(paramInt, 4, this.physical), paramLong);
  }
  
  private static native void setUInt0(long paramLong1, boolean paramBoolean, int paramInt, long paramLong2);
  
  public void setUShort(int paramInt1, int paramInt2)
  {
    setUShort0(this.physical, this.order, check(paramInt1, 2, this.physical), paramInt2);
  }
  
  private static native void setUShort0(long paramLong, boolean paramBoolean, int paramInt1, int paramInt2);
  
  public int transferFrom(byte[] paramArrayOfByte)
  {
    return super.transferFrom(paramArrayOfByte);
  }
  
  public int transferFrom(ByteBuffer paramByteBuffer, int paramInt)
  {
    return super.transferFrom(paramByteBuffer, paramInt);
  }
  
  public int transferFrom(JBuffer paramJBuffer)
  {
    return paramJBuffer.transferTo(this);
  }
  
  public int transferTo(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
  {
    return super.transferTo(paramByteBuffer, paramInt1, paramInt2);
  }
  
  public int transferTo(JBuffer paramJBuffer)
  {
    return super.transferTo(paramJBuffer);
  }
  
  public int transferTo(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3)
  {
    return super.transferTo(paramJBuffer, paramInt1, paramInt2, paramInt3);
  }
  
  private final void setReadonly(boolean paramBoolean)
  {
    this.readonly = paramBoolean;
  }
  
  public native void setByteBuffer(int paramInt, ByteBuffer paramByteBuffer);
  
  public int peer(JMemory paramJMemory)
  {
    return super.peer(paramJMemory);
  }
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JBuffer
 * JD-Core Version:    0.7.0.1
 */