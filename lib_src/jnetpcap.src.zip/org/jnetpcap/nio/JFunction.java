package org.jnetpcap.nio;

public class JFunction
  extends JMemory
{
  private final String name;
  
  public JFunction(String paramString)
  {
    super(JMemory.Type.POINTER);
    this.name = paramString;
  }
  
  public final String getName()
  {
    return this.name;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JFunction
 * JD-Core Version:    0.7.0.1
 */