package org.jnetpcap.nio;

import java.nio.ByteBuffer;

public class JNumber
  extends JMemory
{
  private static final int BYTE_ORDINAL = 0;
  private static final int CHAR_ORDINAL = 1;
  private static final int INT_ORDINAL = 2;
  private static final int SHORT_ORDINAL = 3;
  private static final int LONG_ORDINAL = 4;
  private static final int LONG_LONG_ORDINAL = 5;
  private static final int FLOAT_ORDINAL = 6;
  private static final int DOUBLE_ORDINAL = 7;
  private static final int MAX_SIZE_ORDINAL = 8;
  
  public JNumber()
  {
    super(Type.getBiggestSize());
  }
  
  public JNumber(Type paramType)
  {
    super(paramType.size);
  }
  
  public JNumber(JMemory.Type paramType)
  {
    super(paramType);
  }
  
  private static native int sizeof(int paramInt);
  
  public native int intValue();
  
  public native void intValue(int paramInt);
  
  public native byte byteValue();
  
  public native void byteValue(byte paramByte);
  
  public native short shortValue();
  
  public native void shortValue(short paramShort);
  
  public native long longValue();
  
  public native void longValue(long paramLong);
  
  public native float floatValue();
  
  public native void floatValue(float paramFloat);
  
  public native double doubleValue();
  
  public native void doubleValue(double paramDouble);
  
  public int peer(JNumber paramJNumber)
  {
    return super.peer(paramJNumber);
  }
  
  public int peer(JBuffer paramJBuffer)
  {
    return super.peer(paramJBuffer, 0, size());
  }
  
  public int peer(JBuffer paramJBuffer, int paramInt)
  {
    return super.peer(paramJBuffer, paramInt, size());
  }
  
  public int transferFrom(ByteBuffer paramByteBuffer)
  {
    return super.transferFrom(paramByteBuffer);
  }
  
  public static enum Type
  {
    BYTE,  CHAR,  INT,  SHORT,  LONG,  FLOAT,  DOUBLE;
    
    public final int size = JNumber.sizeof(ordinal());
    private static int biggestSize = 0;
    
    private Type() {}
    
    public static int getBiggestSize()
    {
      if (biggestSize == 0) {
        for (Type localType : values()) {
          if (localType.size > biggestSize) {
            biggestSize = localType.size;
          }
        }
      }
      return biggestSize;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JNumber
 * JD-Core Version:    0.7.0.1
 */