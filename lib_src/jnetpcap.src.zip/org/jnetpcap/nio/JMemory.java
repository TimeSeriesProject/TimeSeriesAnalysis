package org.jnetpcap.nio;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Properties;
import org.jnetpcap.Pcap;
import org.jnetpcap.packet.PeeringException;
import org.jnetpcap.packet.format.FormatUtils;

public abstract class JMemory
{
  private static long directMemory;
  private static long directMemorySoft;
  public static final String JNETPCAP_LIBRARY_NAME = "jnetpcap";
  public static final long MAX_DIRECT_MEMORY_DEFAULT = 67108864L;
  public static final Type POINTER = Type.POINTER;
  private Object keeper = null;
  private boolean owner = false;
  long physical;
  private JMemoryReference ref = null;
  int size;
  
  private static native long allocate0(int paramInt);
  
  public static native long availableDirectMemory();
  
  private static native void initIDs();
  
  public static long maxDirectMemory()
  {
    if (directMemory != 0L) {
      return directMemory;
    }
    Properties localProperties = System.getProperties();
    String str = localProperties.getProperty("org.jnetsoft.nio.MaxDirectMemorySize");
    str = str == null ? localProperties.getProperty("nio.MaxDirectMemorySize") : str;
    str = str == null ? localProperties.getProperty("org.jnetsoft.nio.mx") : str;
    str = str == null ? localProperties.getProperty("nio.mx") : str;
    if (str != null) {
      directMemory = parseSize(str);
    }
    if (directMemory == 0L) {
      directMemory = maxDirectoryMemoryDefault();
    }
    return directMemory;
  }
  
  private static void maxDirectMemoryBreached()
  {
    DisposableGC.getDefault().invokeSystemGCAndWait();
  }
  
  private static long maxDirectoryMemoryDefault()
  {
    long l = Runtime.getRuntime().maxMemory();
    if (l > 67108864L) {
      l = 67108864L;
    }
    return l;
  }
  
  static long parseSize(String paramString)
  {
    paramString = paramString.trim().toLowerCase();
    long l1 = 1L;
    if (paramString.endsWith("tb"))
    {
      l1 = 1099511627776L;
      paramString = paramString.substring(0, paramString.length() - 2);
    }
    else if (paramString.endsWith("gb"))
    {
      l1 = 1073741824L;
      paramString = paramString.substring(0, paramString.length() - 2);
    }
    else if (paramString.endsWith("mb"))
    {
      l1 = 1048576L;
      paramString = paramString.substring(0, paramString.length() - 2);
    }
    else if (paramString.endsWith("kb"))
    {
      l1 = 1024L;
      paramString = paramString.substring(0, paramString.length() - 2);
    }
    long l2 = Long.parseLong(paramString) * l1;
    return l2;
  }
  
  public static native long reservedDirectMemory();
  
  private static native void setMaxDirectMemorySize(long paramLong);
  
  private static native void setSoftDirectMemorySize(long paramLong);
  
  public static long softDirectMemory()
  {
    if (directMemorySoft != 0L) {
      return directMemorySoft;
    }
    Properties localProperties = System.getProperties();
    String str = localProperties.getProperty("org.jnetsoft.nio.SoftDirectMemorySize");
    str = str == null ? localProperties.getProperty("nio.SoftDirectMemorySize") : str;
    str = str == null ? localProperties.getProperty("org.jnetsoft.nio.ms") : str;
    str = str == null ? localProperties.getProperty("nio.ms") : str;
    if (str != null) {
      directMemorySoft = parseSize(str);
    }
    if (directMemorySoft == 0L) {
      directMemorySoft = maxDirectMemory();
    }
    return directMemorySoft;
  }
  
  private static void softDirectMemoryBreached()
  {
    DisposableGC.getDefault().invokeSystemGCWithMarker();
  }
  
  public static long totalActiveAllocated()
  {
    return totalAllocated() - totalDeAllocated();
  }
  
  public static native long totalAllocateCalls();
  
  public static native long totalAllocated();
  
  public static native long totalAllocatedSegments0To255Bytes();
  
  public static native long totalAllocatedSegments256OrAbove();
  
  public static native long totalDeAllocateCalls();
  
  public static native long totalDeAllocated();
  
  protected static native int transferTo0(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3);
  
  public JMemory(ByteBuffer paramByteBuffer)
  {
    this(paramByteBuffer.limit() - paramByteBuffer.position());
    transferFrom(paramByteBuffer);
  }
  
  public JMemory(int paramInt)
  {
    if (paramInt <= 0) {
      throw new IllegalArgumentException("size must be greater than 0");
    }
    allocate(paramInt);
  }
  
  public JMemory(JMemory paramJMemory)
  {
    allocate(paramJMemory.size);
    paramJMemory.transferTo(this);
  }
  
  public JMemory(Type paramType)
  {
    if (paramType != Type.POINTER) {
      throw new IllegalArgumentException("Only POINTER types are supported");
    }
  }
  
  private long allocate(int paramInt)
  {
    this.physical = allocate0(paramInt);
    this.size = paramInt;
    this.owner = true;
    this.keeper = this;
    this.ref = createReference(this.physical, paramInt);
    return this.physical;
  }
  
  public void check()
    throws IllegalStateException
  {
    if (this.physical == 0L) {
      throw new IllegalStateException("peered object not synchronized with native structure");
    }
  }
  
  private final int check(int paramInt1, int paramInt2, long paramLong)
  {
    if (paramLong == 0L) {
      throw new NullPointerException();
    }
    if ((paramInt1 < 0) || (paramInt1 + paramInt2 > this.size)) {
      throw new IndexOutOfBoundsException(String.format("index=%d, len=%d, size=%d", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(this.size) }));
    }
    return paramInt1;
  }
  
  protected void cleanup()
  {
    if (this.ref != null)
    {
      this.ref.dispose();
      if (this.ref != null) {
        this.ref.remove();
      }
      this.ref = null;
    }
    this.owner = false;
    this.keeper = null;
    this.physical = 0L;
    this.size = 0;
  }
  
  protected JMemoryReference createReference(long paramLong1, long paramLong2)
  {
    return new JMemoryReference(this, paramLong1, paramLong2);
  }
  
  public boolean isInitialized()
  {
    return this.physical != 0L;
  }
  
  public boolean isJMemoryBasedOwner()
  {
    return (this.physical != 0L) && ((this.owner) || ((this.keeper instanceof JMemory)));
  }
  
  public final boolean isOwner()
  {
    return this.owner;
  }
  
  protected native int peer(ByteBuffer paramByteBuffer)
    throws PeeringException;
  
  protected int peer(JMemory paramJMemory)
  {
    return peer(paramJMemory, 0, paramJMemory.size);
  }
  
  protected int peer(JMemory paramJMemory, int paramInt1, int paramInt2)
    throws IndexOutOfBoundsException
  {
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 + paramInt2 > paramJMemory.size)) {
      throw new IndexOutOfBoundsException("Invalid [" + paramInt1 + "," + (paramInt1 + paramInt2) + "," + paramInt2 + ") range.");
    }
    return peer0(paramJMemory.physical + paramInt1, paramInt2, paramJMemory.keeper);
  }
  
  private int peer0(long paramLong, int paramInt, Object paramObject)
    throws IndexOutOfBoundsException
  {
    if (paramLong != this.physical) {
      cleanup();
    }
    this.physical = paramLong;
    this.size = paramInt;
    this.keeper = paramObject;
    return this.size;
  }
  
  public void setSize(int paramInt)
  {
    if (paramInt > this.size) {
      throw new IllegalArgumentException(String.format("size (%d) parameter must be less then buffer size (%d)", new Object[] { Integer.valueOf(paramInt), Integer.valueOf(this.size) }));
    }
    if (paramInt < 0) {
      throw new IllegalArgumentException("negative size parameter");
    }
    this.size = paramInt;
  }
  
  private void setSize0(int paramInt)
  {
    this.size = paramInt;
  }
  
  public int size()
  {
    if (!isInitialized()) {
      throw new NullPointerException("jmemory not initialized");
    }
    return this.size;
  }
  
  public String toDebugString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("JMemory: JMemory@").append(Long.toHexString(this.physical)).append(getClass().toString()).append(": ");
    localStringBuilder.append("size=").append(this.size).append(" bytes");
    if (!this.owner)
    {
      localStringBuilder.append("\n");
      localStringBuilder.append("JMemory: owner=").append(this.keeper == null ? "null" : this.keeper.getClass().getName().replaceAll("org.jnetpcap.", ""));
      localStringBuilder.append(".class");
      if ((this.keeper instanceof JMemory))
      {
        JMemory localJMemory = (JMemory)this.keeper;
        localStringBuilder.append("(size=").append(localJMemory.size);
        localStringBuilder.append("/offset=").append(this.physical - localJMemory.physical);
        localStringBuilder.append(')');
      }
    }
    else
    {
      localStringBuilder.append("\n").append("JMemory: isOwner=").append(this.owner);
    }
    return localStringBuilder.toString();
  }
  
  public String toHexdump()
  {
    JBuffer localJBuffer = new JBuffer(Type.POINTER);
    localJBuffer.peer(this);
    return FormatUtils.hexdumpCombined(localJBuffer.getByteArray(0, this.size), 0, 0, true, true, true);
  }
  
  public String toHexdump(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    paramInt = paramInt < this.size ? paramInt : this.size;
    JBuffer localJBuffer = new JBuffer(Type.POINTER);
    localJBuffer.peer(this);
    return FormatUtils.hexdumpCombined(localJBuffer.getByteArray(0, paramInt), 0, 0, paramBoolean1, paramBoolean2, paramBoolean3);
  }
  
  protected int transferFrom(byte[] paramArrayOfByte)
  {
    return transferFrom(paramArrayOfByte, 0, paramArrayOfByte.length, 0);
  }
  
  protected native int transferFrom(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3);
  
  protected int transferFrom(ByteBuffer paramByteBuffer)
  {
    return transferFrom(paramByteBuffer, 0);
  }
  
  protected int transferFrom(ByteBuffer paramByteBuffer, int paramInt)
  {
    if (paramByteBuffer.isDirect()) {
      return transferFromDirect(paramByteBuffer, 0);
    }
    return transferFrom(paramByteBuffer.array(), paramByteBuffer.position(), paramByteBuffer.limit() - paramByteBuffer.position(), 0);
  }
  
  protected native int transferFromDirect(ByteBuffer paramByteBuffer, int paramInt);
  
  protected boolean transferOwnership(JMemory paramJMemory)
  {
    if ((!paramJMemory.owner) || (this.physical == 0L) || (this.physical != paramJMemory.physical)) {
      return false;
    }
    paramJMemory.owner = false;
    this.owner = true;
    this.keeper = null;
    if (this.ref != null) {
      throw new IllegalStateException("Can not transfer ownership when already own memory");
    }
    this.ref = createReference(paramJMemory.ref.address, paramJMemory.ref.size);
    paramJMemory.ref.remove();
    paramJMemory.ref = null;
    return true;
  }
  
  protected int transferTo(byte[] paramArrayOfByte)
  {
    return transferTo(paramArrayOfByte, 0, paramArrayOfByte.length, 0);
  }
  
  protected int transferTo(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramArrayOfByte == null) {
      throw new NullPointerException();
    }
    if ((paramInt3 < 0) || (paramInt3 + paramInt2 > paramArrayOfByte.length)) {
      throw new ArrayIndexOutOfBoundsException();
    }
    return transferTo0(this.physical, paramArrayOfByte, check(paramInt1, paramInt2, this.physical), paramInt2, paramInt3);
  }
  
  public int transferTo(ByteBuffer paramByteBuffer)
  {
    return transferTo(paramByteBuffer, 0, this.size);
  }
  
  public int transferTo(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
  {
    if (paramByteBuffer.isDirect()) {
      return transferToDirect(paramByteBuffer, paramInt1, paramInt2);
    }
    int i = transferTo(paramByteBuffer.array(), paramInt1, paramInt2, paramByteBuffer.position());
    paramByteBuffer.position(paramByteBuffer.position() + i);
    return i;
  }
  
  public int transferTo(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3)
  {
    return transferTo(paramJBuffer, paramInt1, paramInt2, paramInt3);
  }
  
  protected int transferTo(JMemory paramJMemory)
  {
    return transferTo(paramJMemory, 0, this.size, 0);
  }
  
  protected native int transferTo(JMemory paramJMemory, int paramInt1, int paramInt2, int paramInt3);
  
  private native int transferToDirect(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
  
  static
  {
    try
    {
      System.loadLibrary("jnetpcap");
      Pcap.isInjectSupported();
      initIDs();
      setMaxDirectMemorySize(maxDirectMemory());
      setSoftDirectMemorySize(softDirectMemory());
      Class.forName("org.jnetpcap.nio.JMemoryReference");
    }
    catch (Exception localException)
    {
      System.err.println(localException.getClass().getName() + ": " + localException.getLocalizedMessage());
      throw new ExceptionInInitializerError(localException);
    }
  }
  
  public static enum Type
  {
    POINTER;
    
    private Type() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JMemory
 * JD-Core Version:    0.7.0.1
 */