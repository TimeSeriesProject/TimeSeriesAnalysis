package org.jnetpcap.nio;

import java.util.Iterator;

public class LinkSequence<T>
  implements Iterable<T>
{
  private final String name;
  private Link<T> first;
  private Link<T> last;
  private int size;
  
  public LinkSequence()
  {
    this.name = super.toString();
  }
  
  public LinkSequence(String paramString)
  {
    this.name = paramString;
  }
  
  public void add(Link<T> paramLink)
  {
    if ((paramLink.linkNext() != null) || (paramLink.linkPrev() != null)) {
      throw new IllegalStateException("link element already part of list");
    }
    if (this.last == null)
    {
      this.first = paramLink;
      this.last = paramLink;
    }
    else
    {
      this.last.linkNext(paramLink);
      paramLink.linkPrev(this.last);
      this.last = paramLink;
    }
    this.size += 1;
    paramLink.linkCollection(this);
  }
  
  public boolean isEmpty()
  {
    return this.size == 0;
  }
  
  public void remove(Link<T> paramLink)
  {
    Link localLink1 = paramLink.linkPrev();
    Link localLink2 = paramLink.linkNext();
    if ((localLink1 == null) && (localLink2 == null))
    {
      this.first = null;
      this.last = null;
    }
    else if (localLink1 == null)
    {
      this.first = localLink2;
      this.first.linkPrev(null);
    }
    else if (localLink2 == null)
    {
      this.last = localLink1;
      this.last.linkNext(null);
    }
    else
    {
      localLink1.linkNext(localLink2);
      localLink2.linkPrev(localLink1);
    }
    paramLink.linkNext(null);
    paramLink.linkPrev(null);
    paramLink.linkCollection(null);
    this.size -= 1;
    if (this.size < 0)
    {
      Object localObject = paramLink.linkElement();
      String str1 = localObject == null ? null : localObject.getClass().getSimpleName();
      String str2 = String.format("%s:: size < 0 :: culprit=%s[%s]", new Object[] { this.name, str1, String.valueOf(localObject) });
      throw new IllegalStateException(str2);
    }
  }
  
  public synchronized int size()
  {
    return this.size;
  }
  
  public synchronized T get(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.size)) {
      throw new IndexOutOfBoundsException(String.format("index=%d, size=%d", new Object[] { Integer.valueOf(paramInt), Integer.valueOf(this.size) }));
    }
    Link localLink = this.first;
    for (int i = 0; i < paramInt; i++) {
      localLink = localLink.linkNext();
    }
    return localLink == null ? null : localLink.linkElement();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append('[');
    for (Link localLink = this.first; localLink != null; localLink = localLink.linkNext())
    {
      if (localLink != this.first) {
        localStringBuilder.append(',');
      }
      localStringBuilder.append(localLink.toString());
    }
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
  
  public Iterator<T> iterator()
  {
    new Iterator()
    {
      Link<T> node = LinkSequence.this.first;
      
      public boolean hasNext()
      {
        return this.node != null;
      }
      
      public T next()
      {
        Link localLink = this.node;
        this.node = this.node.linkNext();
        return localLink.linkElement();
      }
      
      public void remove()
      {
        throw new UnsupportedOperationException();
      }
    };
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.LinkSequence
 * JD-Core Version:    0.7.0.1
 */