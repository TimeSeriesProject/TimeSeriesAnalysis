package org.jnetpcap.nio;

import java.io.IOException;
import java.io.InputStream;

public class JBufferInputStream
  extends InputStream
{
  private final JBuffer in;
  private int position;
  private final int end;
  private int mark = -1;
  
  public JBufferInputStream(JBuffer paramJBuffer)
  {
    this(paramJBuffer, 0, paramJBuffer.size());
  }
  
  public JBufferInputStream(JBuffer paramJBuffer, int paramInt1, int paramInt2)
  {
    paramInt2 = paramInt1 + paramInt2 > paramJBuffer.size() ? paramJBuffer.size() - paramInt1 : paramInt2;
    this.in = paramJBuffer;
    this.position = paramInt1;
    this.end = (paramInt1 + paramInt2);
  }
  
  public int read()
    throws IOException
  {
    if (this.position == this.end) {
      return -1;
    }
    return this.in.getUByte(this.position++);
  }
  
  public int available()
    throws IOException
  {
    return this.end - this.position;
  }
  
  public void close()
    throws IOException
  {
    this.position = this.end;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = max(paramInt2);
    this.in.getByteArray(this.position, paramArrayOfByte, paramInt1, i);
    return i;
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return read(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public long skip(long paramLong)
    throws IOException
  {
    long l = max((int)paramLong);
    this.position += max((int)paramLong);
    return l;
  }
  
  public synchronized void mark(int paramInt)
  {
    this.mark = this.position;
  }
  
  public boolean markSupported()
  {
    return true;
  }
  
  public synchronized void reset()
    throws IOException
  {
    if (this.mark != -1)
    {
      this.position = this.mark;
      this.mark = -1;
    }
  }
  
  private int max(int paramInt)
  {
    int i = this.end - this.position;
    int j = paramInt > i ? i : paramInt;
    return j;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JBufferInputStream
 * JD-Core Version:    0.7.0.1
 */