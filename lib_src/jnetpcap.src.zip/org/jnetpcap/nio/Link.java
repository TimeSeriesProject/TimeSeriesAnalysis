package org.jnetpcap.nio;

public abstract interface Link<T>
{
  public abstract Link<T> linkNext();
  
  public abstract void linkNext(Link<T> paramLink);
  
  public abstract Link<T> linkPrev();
  
  public abstract void linkPrev(Link<T> paramLink);
  
  public abstract T linkElement();
  
  public abstract LinkSequence<T> linkCollection();
  
  public abstract void linkCollection(LinkSequence<T> paramLinkSequence);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.Link
 * JD-Core Version:    0.7.0.1
 */