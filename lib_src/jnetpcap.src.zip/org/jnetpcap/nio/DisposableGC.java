package org.jnetpcap.nio;

import java.io.PrintStream;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.sql.Time;
import java.util.Iterator;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class DisposableGC
{
  private static final long DEFAULT_CLEANUP_THREAD_TIMEOUT = 20L;
  private static DisposableGC defaultGC = new DisposableGC();
  private static final long G10 = 10000L;
  private static final long G60 = 60000L;
  private static final int MANUAL_DRAING_MAX = 2;
  static final int MIN_MEMORY_RELEASE = 2097152;
  static final long MIN_SYSTEM_GC_INVOKE_TIMEOUT = 200L;
  static final long OUT_OF_MEMORY_TIMEOUT = 15000L;
  private Thread cleanupThread;
  private final AtomicBoolean cleanupThreadActive = new AtomicBoolean(false);
  private final AtomicBoolean cleanupThreadProcessing = new AtomicBoolean(false);
  private final AtomicLong cleanupTimeout = new AtomicLong(20L);
  private long deltaCount;
  private long deltaSize;
  final LinkSequence<DisposableReference> g0 = new LinkSequence("g0");
  final LinkSequence<DisposableReference> g10 = new LinkSequence("g10");
  final LinkSequence<DisposableReference> g60 = new LinkSequence("g60");
  private long lastSystemGCInvoke = 0L;
  private long firstSystemGCNeeded = 0L;
  final ReferenceQueue<Object> markerQueue = new ReferenceQueue();
  private Reference<Object> markerReference;
  private final Semaphore memorySemaphore = new Semaphore(2097152);
  final ReferenceQueue<Object> refQueue = new ReferenceQueue();
  private long totalDisposed = 1L;
  private long totalSize;
  private boolean verbose = false;
  private boolean vverbose = false;
  private boolean vvverbose = false;
  
  public static DisposableGC getDefault()
  {
    return defaultGC;
  }
  
  private static long mem(LinkSequence<DisposableReference> paramLinkSequence)
  {
    long l = 0L;
    Iterator localIterator = paramLinkSequence.iterator();
    while (localIterator.hasNext())
    {
      DisposableReference localDisposableReference = (DisposableReference)localIterator.next();
      l += localDisposableReference.size();
    }
    return l;
  }
  
  private DisposableGC()
  {
    startCleanupThread();
    try
    {
      setVerbose(Boolean.parseBoolean(System.getProperty("nio.verbose", "false")));
      setVVerbose(Boolean.parseBoolean(System.getProperty("nio.vverbose", "false")));
      setVVVerbose(Boolean.parseBoolean(System.getProperty("nio.vvverbose", "false")));
    }
    catch (Exception localException) {}
  }
  
  private void dispose(DisposableReference paramDisposableReference)
  {
    synchronized (this.g0)
    {
      this.memorySemaphore.release(paramDisposableReference.size());
      this.totalDisposed += 1L;
      this.totalSize += paramDisposableReference.size();
      paramDisposableReference.dispose();
      paramDisposableReference.remove();
      if ((this.g0.isEmpty()) && (this.g10.isEmpty()) && (this.g60.isEmpty())) {
        this.g0.notifyAll();
      }
    }
  }
  
  public void drainRefQueue()
  {
    for (;;)
    {
      DisposableReference localDisposableReference = (DisposableReference)this.refQueue.poll();
      if (localDisposableReference == null) {
        break;
      }
      dispose(localDisposableReference);
    }
  }
  
  public void drainRefQueue(long paramLong)
    throws IllegalArgumentException, InterruptedException
  {
    this.memorySemaphore.acquire(this.memorySemaphore.availablePermits());
    long l = paramLong / 100L;
    while (this.memorySemaphore.availablePermits() < 2097152)
    {
      DisposableReference localDisposableReference = (DisposableReference)this.refQueue.remove(paramLong);
      if ((localDisposableReference != null) || (l++ >= 100L))
      {
        if (localDisposableReference == null) {
          break;
        }
        dispose(localDisposableReference);
      }
    }
  }
  
  void drainRefQueueBounded()
  {
    for (int i = 0; i < 2; i++)
    {
      DisposableReference localDisposableReference = (DisposableReference)this.refQueue.poll();
      if (localDisposableReference == null) {
        break;
      }
      dispose(localDisposableReference);
    }
  }
  
  void drainRefQueueLoop()
    throws InterruptedException
  {
    this.deltaCount = 0L;
    this.deltaSize = 0L;
    long l1 = this.cleanupTimeout.get();
    long l2 = System.currentTimeMillis();
    for (;;)
    {
      DisposableReference localDisposableReference = (DisposableReference)this.refQueue.remove(l1);
      if (localDisposableReference != null)
      {
        if (this.deltaCount == 0L)
        {
          if ((this.vvverbose) && (!this.cleanupThreadProcessing.get())) {
            logBusy();
          }
          this.cleanupThreadProcessing.set(true);
          synchronized (this.cleanupThreadProcessing)
          {
            this.cleanupThreadProcessing.notifyAll();
          }
        }
        this.deltaCount += 1L;
        this.deltaSize += localDisposableReference.size();
        if ((this.vverbose) && (this.deltaCount % 10000L == 0L))
        {
          sortGenerations();
          logUsage();
        }
      }
      else if ((this.deltaCount != 0L) && (System.currentTimeMillis() - l2 >= 1000L))
      {
        l2 = System.currentTimeMillis();
        sortGenerations();
        if ((this.verbose) && (this.deltaCount > 0L)) {
          logUsage();
        }
        this.deltaCount = 0L;
        this.deltaSize = 0L;
        this.cleanupThreadProcessing.set(false);
        synchronized (this.cleanupThreadProcessing)
        {
          this.cleanupThreadProcessing.notifyAll();
        }
        if (this.vvverbose) {
          logIdle();
        }
      }
      if (localDisposableReference == null)
      {
        if (this.cleanupThreadActive.get())
        {
          if (this.memorySemaphore.hasQueuedThreads()) {
            invokeSystemGC();
          }
        }
        else
        {
          if (!this.verbose) {
            break;
          }
          logFinished();
          break;
        }
      }
      else {
        dispose(localDisposableReference);
      }
    }
    if ((this.verbose) && (this.deltaCount != 0L))
    {
      System.out.printf("DisposableGC: disposed of %d entries [total=%dM]%n", new Object[] { Long.valueOf(this.deltaCount), Long.valueOf(this.totalDisposed / 1000000L) });
      this.deltaCount = 0L;
    }
  }
  
  private String f(long paramLong)
  {
    return f(paramLong, -1, "");
  }
  
  private String f(long paramLong, int paramInt)
  {
    return f(paramLong, paramInt, "");
  }
  
  private String f(long paramLong, int paramInt, String paramString)
  {
    String str1 = "";
    double d = paramLong;
    int i = 0;
    if (paramLong > 1099511627776L)
    {
      str1 = "t";
      d /= 3.0D;
      i = 4;
    }
    else if (paramLong > 1073741824L)
    {
      str1 = "g";
      d /= 1073741824.0D;
      i = 2;
    }
    else if (paramLong > 1048576L)
    {
      str1 = "m";
      d /= 1048576.0D;
      i = 1;
    }
    else if (paramLong > 1024L)
    {
      str1 = "k";
      d /= 1024.0D;
      i = 0;
    }
    else
    {
      i = 0;
    }
    if (paramInt != -1) {
      i = paramInt;
    }
    String str2 = String.format("%%.%df%%s%%s", new Object[] { Integer.valueOf(i) });
    return String.format(str2, new Object[] { Double.valueOf(d), str1, paramString });
  }
  
  private String fb(long paramLong)
  {
    return f(paramLong, -1, "b");
  }
  
  private String fb(long paramLong, int paramInt)
  {
    return f(paramLong, paramInt, "b");
  }
  
  public long getCleanupThreadTimeout()
  {
    return this.cleanupTimeout.get();
  }
  
  private boolean invokeSystemGC()
  {
    if (System.currentTimeMillis() - this.lastSystemGCInvoke < 200L) {
      return false;
    }
    if (this.vverbose) {
      logSystemGC();
    }
    System.gc();
    this.lastSystemGCInvoke = System.currentTimeMillis();
    this.firstSystemGCNeeded = 0L;
    return true;
  }
  
  public synchronized void invokeSystemGCAndWait()
  {
    long l1 = System.currentTimeMillis();
    long l2 = JMemory.availableDirectMemory();
    try
    {
      if (isCleanupThreadActive())
      {
        this.memorySemaphore.acquire(this.memorySemaphore.availablePermits());
        this.memorySemaphore.tryAcquire(2097152, 15000L, TimeUnit.MILLISECONDS);
      }
      else
      {
        invokeSystemGC();
        drainRefQueue(15000L);
      }
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}catch (InterruptedException localInterruptedException) {}
    if (this.vverbose) {
      System.out.printf("DisposableGC: waiting for System.gc to finish: %dms, freed=%dMbytes%n", new Object[] { Long.valueOf(System.currentTimeMillis() - l1), Long.valueOf((JMemory.availableDirectMemory() - l2) / 1048576L) });
    }
  }
  
  public synchronized void invokeSystemGCWithMarker()
  {
    if (((this.markerReference != null) && (this.markerReference.get() != null)) || (!isSystemGCReady())) {
      return;
    }
    if (this.vvverbose) {
      logMarker();
    }
    this.markerReference = new WeakReference(new Object() {});
    invokeSystemGC();
  }
  
  public boolean isCleanupComplete()
  {
    synchronized (this.g0)
    {
      return this.g0.isEmpty();
    }
  }
  
  public boolean isCleanupThreadActive()
  {
    return (this.cleanupThreadActive.get()) && (this.cleanupThread.isAlive());
  }
  
  private final boolean isSystemGCReady()
  {
    if (this.firstSystemGCNeeded == 0L) {
      this.firstSystemGCNeeded = System.currentTimeMillis();
    }
    return (!this.cleanupThreadProcessing.get()) && (System.currentTimeMillis() - this.lastSystemGCInvoke > 200L);
  }
  
  public boolean isVerbose()
  {
    return this.verbose;
  }
  
  public boolean isVVerbose()
  {
    return this.vverbose;
  }
  
  public boolean isVVVerbose()
  {
    return this.vvverbose;
  }
  
  private void logBusy()
  {
    System.out.printf("DisposableGC: busy%n", new Object[0]);
  }
  
  private void logFinished()
  {
    System.out.printf("DisposableGC: finished%n", new Object[0]);
  }
  
  private void logIdle()
  {
    System.out.printf("DisposableGC: idle - waiting for system GC to collect more objects%n", new Object[0]);
  }
  
  private void logLimits()
  {
    System.out.printf("DisposableGC: current native memory allocation limits are max=%s, soft=%s%n", new Object[] { fb(JMemory.maxDirectMemory()), fb(JMemory.softDirectMemory()) });
  }
  
  private void logMarker()
  {
    long l1 = System.currentTimeMillis();
    long l2 = l1 - l1 / 1000L * 1000L;
    System.out.printf("DisposableGC: soft limit breached, issued a marker at %s.%d, minimum delay=%dms%n", new Object[] { new Time(l1), Long.valueOf(l2), Long.valueOf(200L) });
  }
  
  private void logSystemGC()
  {
    long l1 = System.currentTimeMillis();
    long l2 = l1 - l1 / 1000L * 1000L;
    long l3 = l1 - this.firstSystemGCNeeded;
    System.out.printf("DisposableGC: issued JVM GC request %s.%d waited=%dms (reserved=%s, available=%s)%n", new Object[] { new Time(l1), Long.valueOf(l2), Long.valueOf(l3), fb(JMemory.reservedDirectMemory()), fb(JMemory.availableDirectMemory()) });
  }
  
  private void logUsage()
  {
    System.out.printf("DisposableGC: [immediate=%3s(%4s)]=%3s(%7s) [0sec=%3s(%6s),10sec=%3s(%6s),60sec=%3s(%6s)]=%6s%n", new Object[] { f(this.deltaCount), fb(this.deltaSize, 0), f(this.totalDisposed), fb(this.totalSize), f(this.g0.size()), fb(mem(this.g0)), f(this.g10.size()), fb(mem(this.g10)), f(this.g60.size()), fb(mem(this.g60)), fb(memoryHeldInRefCollection()) });
  }
  
  private long memoryHeldInRefCollection()
  {
    long l = 0L;
    l += mem(this.g0);
    l += mem(this.g10);
    l += mem(this.g60);
    return l;
  }
  
  public void setCleanupThreadTimeout(long paramLong)
  {
    this.cleanupTimeout.set(paramLong);
  }
  
  public void setVerbose(boolean paramBoolean)
  {
    this.verbose = paramBoolean;
    if (!paramBoolean)
    {
      setVVerbose(false);
      setVVVerbose(false);
    }
    else
    {
      logLimits();
    }
  }
  
  public void setVVerbose(boolean paramBoolean)
  {
    if (paramBoolean) {
      setVerbose(true);
    } else {
      setVVVerbose(false);
    }
    this.vverbose = paramBoolean;
  }
  
  public void setVVVerbose(boolean paramBoolean)
  {
    if (paramBoolean) {
      setVVerbose(true);
    }
    this.vvverbose = paramBoolean;
  }
  
  private void sortGenerations()
  {
    long l = System.currentTimeMillis();
    Iterator localIterator = this.g10.iterator();
    DisposableReference localDisposableReference;
    while (localIterator.hasNext())
    {
      localDisposableReference = (DisposableReference)localIterator.next();
      if (l - localDisposableReference.getTs() <= 60000L) {
        break;
      }
      this.g10.remove(localDisposableReference);
      this.g60.add(localDisposableReference);
    }
    localIterator = this.g0.iterator();
    while (localIterator.hasNext())
    {
      localDisposableReference = (DisposableReference)localIterator.next();
      if (l - localDisposableReference.getTs() <= 10000L) {
        break;
      }
      this.g0.remove(localDisposableReference);
      this.g10.add(localDisposableReference);
    }
  }
  
  public synchronized void startCleanupThread()
  {
    if (isCleanupThreadActive()) {
      return;
    }
    this.cleanupThread = new Thread(new Runnable()
    {
      public void run()
      {
        try
        {
          DisposableGC.this.drainRefQueueLoop();
        }
        catch (InterruptedException ???)
        {
          Thread.UncaughtExceptionHandler localUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
          localUncaughtExceptionHandler.uncaughtException(Thread.currentThread(), ???);
        }
        finally
        {
          DisposableGC.this.cleanupThreadActive.set(false);
          DisposableGC.this.cleanupThread = null;
          synchronized (this)
          {
            notifyAll();
          }
        }
      }
    }, "DisposableGC");
    this.cleanupThreadActive.set(true);
    this.cleanupThread.setDaemon(true);
    this.cleanupThread.setPriority(this.cleanupThread.getPriority() - 1);
    this.cleanupThread.start();
  }
  
  public void stopCleanupThread()
    throws InterruptedException
  {
    if (isCleanupThreadActive()) {
      synchronized (this.cleanupThread)
      {
        this.cleanupThreadActive.set(false);
        if (this.cleanupThread != null) {
          this.cleanupThread.wait();
        }
      }
    }
  }
  
  public void waitForForcableCleanup()
    throws InterruptedException
  {
    
    while (!waitForFullCleanup(5000L)) {
      if ((this.verbose) && (!this.cleanupThreadProcessing.get()))
      {
        System.out.printf("DisposableGC: waiting on %d elements%n", new Object[] { Integer.valueOf(this.g0.size()) });
        for (int i = 0; i < this.g0.size(); i++)
        {
          DisposableReference localDisposableReference = (DisposableReference)this.g0.get(i);
          if ((localDisposableReference != null) && (localDisposableReference.get() != null)) {
            System.out.printf("DisposableGC:#%d: %s%n", new Object[] { Integer.valueOf(i), localDisposableReference.get() });
          }
        }
      }
    }
  }
  
  public boolean waitForForcableCleanup(long paramLong)
    throws InterruptedException
  {
    int i = (int)(paramLong / 100L) + 1;
    while ((i-- >= 0) && (!waitForFullCleanup(100L))) {
      invokeSystemGC();
    }
    return isCleanupComplete();
  }
  
  public void waitForFullCleanup()
    throws InterruptedException
  {
    synchronized (this.g0)
    {
      while (!this.g0.isEmpty()) {
        if (isCleanupThreadActive()) {
          this.g0.wait();
        } else {
          drainRefQueue();
        }
      }
    }
  }
  
  public boolean waitForFullCleanup(long paramLong)
    throws InterruptedException
  {
    synchronized (this.g0)
    {
      if (!this.g0.isEmpty()) {
        if (isCleanupThreadActive())
        {
          this.g0.wait(paramLong);
        }
        else
        {
          drainRefQueue();
          if (!this.g0.isEmpty())
          {
            Thread.sleep(paramLong);
            drainRefQueue();
          }
        }
      }
      return this.g0.isEmpty();
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.DisposableGC
 * JD-Core Version:    0.7.0.1
 */