package org.jnetpcap.nio;

public class JMemoryReference
  extends DisposableReference
{
  long address;
  long size;
  
  public JMemoryReference(Object paramObject, long paramLong1, long paramLong2)
  {
    super(paramObject);
    this.address = paramLong1;
    this.size = paramLong2;
  }
  
  public void dispose()
  {
    disposeNative(this.size);
  }
  
  protected void disposeNative(long paramLong)
  {
    disposeNative0(this.address, paramLong);
  }
  
  private native void disposeNative0(long paramLong1, long paramLong2);
  
  public void remove()
  {
    this.address = 0L;
    this.size = 0L;
    super.remove();
  }
  
  public int size()
  {
    return (int)this.size;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JMemoryReference
 * JD-Core Version:    0.7.0.1
 */