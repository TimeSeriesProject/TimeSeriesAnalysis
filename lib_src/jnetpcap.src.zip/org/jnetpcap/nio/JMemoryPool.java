package org.jnetpcap.nio;

import java.nio.ByteBuffer;
import java.sql.Time;
import java.util.Properties;

public class JMemoryPool
{
  private static final int BUS_WIDTH = JNumber.Type.INT.size;
  public static final int DEFAULT_BLOCK_SIZE = 32768;
  private static JMemoryPool defaultPool;
  private Block block;
  private int blockSize;
  
  public static JBuffer buffer(int paramInt)
  {
    JBuffer localJBuffer = new JBuffer(JMemory.Type.POINTER);
    defaultMemoryPool().allocate(paramInt, localJBuffer);
    return localJBuffer;
  }
  
  public static void malloc(int paramInt, JMemory paramJMemory)
  {
    defaultMemoryPool().allocate(paramInt, paramJMemory);
  }
  
  public JMemoryPool()
  {
    this.blockSize = getBlockSize();
  }
  
  public JMemoryPool(int paramInt)
  {
    this.blockSize = paramInt;
  }
  
  public synchronized void allocate(int paramInt, JMemory paramJMemory)
  {
    Block localBlock = getBlock(paramInt);
    int i = localBlock.allocate(paramInt);
    paramJMemory.peer(localBlock, i, paramInt);
  }
  
  public JMemory allocateExclusive(int paramInt)
  {
    new JMemory(paramInt) {};
  }
  
  public synchronized int duplicate(JMemory paramJMemory1, JMemory paramJMemory2)
  {
    Block localBlock = getBlock(paramJMemory1.size);
    int i = localBlock.allocate(paramJMemory1.size);
    paramJMemory1.transferTo(localBlock, 0, paramJMemory1.size, i);
    paramJMemory2.peer(localBlock, i, paramJMemory1.size);
    return paramJMemory1.size;
  }
  
  public synchronized int duplicate2(JMemory paramJMemory1, JMemory paramJMemory2, JMemory paramJMemory3, JMemory paramJMemory4)
  {
    int i = paramJMemory1.size;
    int j = paramJMemory2.size;
    int k = paramJMemory1.size + paramJMemory2.size;
    Block localBlock = getBlock(k);
    int m = localBlock.allocate(k);
    int n = paramJMemory1.transferTo(localBlock, 0, i, m);
    paramJMemory2.transferTo(localBlock, 0, j, m + n);
    paramJMemory3.peer(localBlock, m, i);
    paramJMemory4.peer(localBlock, m + n, j);
    return k;
  }
  
  public synchronized int duplicate2(JMemory paramJMemory1, ByteBuffer paramByteBuffer, JMemory paramJMemory2, JMemory paramJMemory3)
  {
    int i = paramJMemory1.size;
    int j = paramByteBuffer.limit() - paramByteBuffer.position();
    int k = i + j;
    Block localBlock = getBlock(k);
    int m = localBlock.allocate(k);
    int n = paramJMemory1.transferTo(localBlock, 0, i, m);
    localBlock.transferFrom(paramByteBuffer, m + n);
    paramJMemory2.peer(localBlock, m, i);
    paramJMemory3.peer(localBlock, m + n, j);
    return k;
  }
  
  public synchronized int duplicate(ByteBuffer paramByteBuffer, JMemory paramJMemory)
  {
    int i = paramByteBuffer.limit() - paramByteBuffer.position();
    Block localBlock = getBlock(i);
    int j = localBlock.allocate(i);
    localBlock.transferFrom(paramByteBuffer, j);
    paramJMemory.peer(localBlock, j, i);
    return i;
  }
  
  public Block getBlock(int paramInt)
  {
    paramInt += paramInt % BUS_WIDTH;
    if ((this.block == null) || (this.block.available < paramInt)) {
      this.block = newBlock(paramInt);
    }
    return this.block;
  }
  
  private Block newBlock(int paramInt)
  {
    return new Block(paramInt > this.blockSize ? paramInt : this.blockSize);
  }
  
  public static JMemoryPool defaultMemoryPool()
  {
    if (defaultPool == null) {
      defaultPool = new JMemoryPool();
    }
    return defaultPool;
  }
  
  public static void shutdown()
  {
    if (defaultPool != null)
    {
      defaultPool.block = null;
      defaultPool = null;
    }
  }
  
  public int getBlockSize()
  {
    if (this.blockSize != 0) {
      return this.blockSize;
    }
    Properties localProperties = System.getProperties();
    String str = localProperties.getProperty("org.jnetsoft.nio.BlockSize");
    str = str == null ? localProperties.getProperty("nio.BlockSize") : str;
    str = str == null ? localProperties.getProperty("org.jnetsoft.nio.blocksize") : str;
    str = str == null ? localProperties.getProperty("nio.blocksize") : str;
    str = str == null ? localProperties.getProperty("nio.bs") : str;
    if (str != null) {
      this.blockSize = ((int)JMemory.parseSize(str));
    }
    if (this.blockSize == 0) {
      this.blockSize = 32768;
    }
    return this.blockSize;
  }
  
  public void setBlockSize(int paramInt)
  {
    this.blockSize = paramInt;
  }
  
  public static class Block
    extends JMemory
  {
    private int available = 0;
    private int current = 0;
    private final long createdOn;
    
    Block(int paramInt)
    {
      super();
      this.available = paramInt;
      this.createdOn = System.currentTimeMillis();
    }
    
    Block(JMemory paramJMemory)
    {
      super();
      this.createdOn = System.currentTimeMillis();
    }
    
    public synchronized int allocate(int paramInt)
    {
      paramInt += paramInt % JMemoryPool.BUS_WIDTH;
      if (paramInt > this.available) {
        return -1;
      }
      int i = this.current;
      this.available -= paramInt;
      this.current += paramInt;
      return i;
    }
    
    public void free(int paramInt1, int paramInt2) {}
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(80);
      localStringBuilder.append("JMemoryPool::Block");
      localStringBuilder.append('[');
      localStringBuilder.append("capacity=").append(size());
      localStringBuilder.append(',');
      localStringBuilder.append("available=").append(this.current);
      localStringBuilder.append(',');
      localStringBuilder.append("createdOn=").append(new Time(this.createdOn).toString());
      localStringBuilder.append(']');
      return localStringBuilder.toString();
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.JMemoryPool
 * JD-Core Version:    0.7.0.1
 */