package org.jnetpcap.nio;

public abstract interface Disposable
{
  public abstract void dispose();
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.nio.Disposable
 * JD-Core Version:    0.7.0.1
 */