package org.jnetpcap.protocol.application;

import java.awt.Image;
import java.awt.Toolkit;
import java.io.InputStream;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JBufferInputStream;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.annotate.Bind;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.protocol.tcpip.Http;
import org.jnetpcap.protocol.tcpip.Http.ContentType;

@Header
public class WebImage
  extends JHeader
{
  private byte[] data;
  
  @Bind(to=Http.class)
  public static boolean bind2Http(JPacket paramJPacket, Http paramHttp)
  {
    Http.ContentType localContentType = paramHttp.contentTypeEnum();
    switch (1.$SwitchMap$org$jnetpcap$protocol$tcpip$Http$ContentType[localContentType.ordinal()])
    {
    case 1: 
    case 2: 
    case 3: 
      return true;
    }
    return false;
  }
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    return paramJBuffer.size() - paramInt;
  }
  
  protected void decodeHeader()
  {
    this.data = null;
  }
  
  public Image getAWTImage()
  {
    if (this.data == null) {
      this.data = super.getByteArray(0, size());
    }
    return Toolkit.getDefaultToolkit().createImage(this.data);
  }
  
  public InputStream getInputStream()
  {
    return new JBufferInputStream(this);
  }
  
  public int length()
  {
    return size();
  }
  
  public static enum Type
  {
    BMP,  GIF,  JPEG,  SVG;
    
    private Type() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.application.WebImage
 * JD-Core Version:    0.7.0.1
 */