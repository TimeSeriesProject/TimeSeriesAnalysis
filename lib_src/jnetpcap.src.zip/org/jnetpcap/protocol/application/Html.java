package org.jnetpcap.protocol.application;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.annotate.Bind;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.packet.annotate.ProtocolSuite;
import org.jnetpcap.protocol.tcpip.Http;
import org.jnetpcap.util.JThreadLocal;

@Header(nicname="Html", suite=ProtocolSuite.APPLICATION)
public class Html
  extends JHeader
{
  private String page;
  private static final JThreadLocal<StringBuilder> stringLocal = new JThreadLocal(StringBuilder.class);
  private static final JThreadLocal<HtmlParser> parserLocal = new JThreadLocal(HtmlParser.class);
  private HtmlTag[] tags;
  private HtmlTag[] links;
  
  @Bind(to=Http.class, stringValue={"text/html"})
  public static boolean bind2Http(JPacket paramJPacket, Http paramHttp)
  {
    return (paramHttp.hasContentType()) && (paramHttp.contentType().startsWith("text/html;"));
  }
  
  @Bind(to=Http.class, stringValue={"text/css"})
  public static boolean bind2HttpAsCSS(JPacket paramJPacket, Http paramHttp)
  {
    return (paramHttp.hasContentType()) && (paramHttp.contentType().startsWith("text/css;"));
  }
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    return paramJBuffer.size() - paramInt;
  }
  
  protected void decodeHeader()
  {
    StringBuilder localStringBuilder = (StringBuilder)stringLocal.get();
    localStringBuilder.setLength(0);
    super.getUTF8String(0, localStringBuilder, size());
    this.page = localStringBuilder.toString();
    this.tags = null;
    this.links = null;
  }
  
  @Field(offset=0, format="#textdump#")
  public String page()
  {
    return this.page;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int pageLength()
  {
    return size() * 8;
  }
  
  public HtmlTag[] tags()
  {
    if (this.tags == null) {
      this.tags = ((HtmlParser)parserLocal.get()).decodeAllTags(this.page);
    }
    return this.tags;
  }
  
  public HtmlTag[] links()
  {
    if (this.links == null) {
      this.links = ((HtmlParser)parserLocal.get()).decodeLinks(tags());
    }
    return this.links;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (HtmlTag localHtmlTag : tags()) {
      localStringBuilder.append(localHtmlTag.toString()).append("\n");
    }
    return localStringBuilder.toString();
  }
  
  public static enum Tag
  {
    A(new String[0]),  B(new String[0]),  BODY(new String[0]),  BUTTON(new String[0]),  CAPTION(new String[0]),  CENTER(new String[0]),  DIV(new String[0]),  EM(new String[0]),  FORM(new String[0]),  H1(new String[0]),  H2(new String[0]),  H3(new String[0]),  H4(new String[0]),  H5(new String[0]),  H6(new String[0]),  HEAD(new String[0]),  HTML(new String[0]),  I(new String[0]),  IFRAME(new String[0]),  IMG(new String[0]),  INPUT(new String[0]),  LABEL(new String[0]),  LI(new String[0]),  LINK(new String[] { "rel", "type", "href" }),  META(new String[0]),  NOSCRIPT(new String[0]),  OBJECT(new String[0]),  OL(new String[0]),  P(new String[0]),  REL(new String[0]),  SCRIPT(new String[0]),  SPAN(new String[0]),  TABLE(new String[0]),  TBODY(new String[0]),  TD(new String[0]),  TEXT(new String[0]),  TH(new String[0]),  TITLE(new String[0]),  TR(new String[0]),  U(new String[0]),  UL(new String[0]),  UNKNOWN(new String[0]);
    
    private final String[] params;
    
    public static Tag parseStringPrefix(String paramString)
    {
      for (Tag localTag : ) {
        if (paramString.toUpperCase().startsWith(localTag.name())) {
          return localTag;
        }
      }
      return UNKNOWN;
    }
    
    private Tag(String... paramVarArgs)
    {
      int j = 0;
      for (String str : paramVarArgs) {
        paramVarArgs[(j++)] = str.trim().toUpperCase();
      }
      this.params = paramVarArgs;
    }
    
    public final String[] getParams()
    {
      return this.params;
    }
    
    public static enum Param
    {
      ALT,  CLASS,  HEIGHT,  HREF,  ID,  SRC,  TITLE,  TYPE,  UNKNOWN,  WIDTH;
      
      private Param() {}
      
      public static Param parseStringPrefix(String paramString)
      {
        for (Param localParam : ) {
          if (paramString.toUpperCase().startsWith(localParam.name())) {
            return localParam;
          }
        }
        return UNKNOWN;
      }
    }
  }
  
  public static class HtmlTag
  {
    private final int end;
    private Map<Html.Tag.Param, String> params = Collections.emptyMap();
    private final String source;
    private final int start;
    private Html.Tag tag;
    private final String tagString;
    final Type type;
    
    public HtmlTag(Html.Tag paramTag, Type paramType, String paramString1, String paramString2, int paramInt1, int paramInt2)
    {
      this.tag = paramTag;
      this.type = paramType;
      this.tagString = paramString1;
      this.source = paramString2;
      this.start = paramInt1;
      this.end = paramInt2;
      if (paramType != Type.ATOMIC) {
        parseTag(paramTag, paramString1);
      }
    }
    
    public final int getEnd()
    {
      return this.end;
    }
    
    public final Map<Html.Tag.Param, String> getParams()
    {
      return this.params;
    }
    
    public final String getSource()
    {
      return this.source;
    }
    
    public final int getStart()
    {
      return this.start;
    }
    
    public final Html.Tag getTag()
    {
      return this.tag;
    }
    
    public String getTagString()
    {
      return this.tagString;
    }
    
    public final Type getType()
    {
      return this.type;
    }
    
    private void parseTag(Html.Tag paramTag, String paramString)
    {
      String[] arrayOfString1 = paramString.split(" ");
      if (arrayOfString1.length > 1) {
        this.params = new HashMap(arrayOfString1.length - 1);
      }
      for (String str : arrayOfString1)
      {
        str = str.trim();
        String[] arrayOfString3 = str.split("=");
        if (arrayOfString3.length == 2)
        {
          if ((arrayOfString3[1].charAt(0) == '"') || (arrayOfString3[1].charAt(0) == '"')) {
            arrayOfString3[1] = arrayOfString3[1].substring(1, arrayOfString3[1].length() - 2);
          }
          this.params.put(Html.Tag.Param.parseStringPrefix(arrayOfString3[0]), arrayOfString3[1]);
        }
      }
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      switch (Html.1.$SwitchMap$org$jnetpcap$protocol$application$Html$HtmlTag$Type[this.type.ordinal()])
      {
      case 1: 
        break;
      case 2: 
        localStringBuilder.append(this.tag.name()).append("/>");
        break;
      case 3: 
        localStringBuilder.append(this.tag.name()).append('<');
      }
      if (this.tag == Html.Tag.TEXT)
      {
        localStringBuilder.append('"');
        localStringBuilder.append(((HtmlParser)Html.parserLocal.get()).format(this.tagString));
        localStringBuilder.append('"');
      }
      else if (!this.params.isEmpty())
      {
        localStringBuilder.append('=');
        localStringBuilder.append(this.params.toString());
      }
      return localStringBuilder.toString();
    }
    
    public static enum Type
    {
      ATOMIC,  CLOSE,  OPEN;
      
      private Type() {}
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.application.Html
 * JD-Core Version:    0.7.0.1
 */