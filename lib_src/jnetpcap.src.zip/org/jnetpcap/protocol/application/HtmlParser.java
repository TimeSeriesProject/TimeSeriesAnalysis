package org.jnetpcap.protocol.application;

import java.util.ArrayList;
import java.util.List;
import org.jnetpcap.util.JThreadLocal;

public class HtmlParser
{
  private int e = 0;
  private int s = 0;
  private String str = null;
  private static final JThreadLocal<ArrayList> listLocal = new JThreadLocal(ArrayList.class);
  
  public Html.HtmlTag[] decodeAllTags(String paramString)
  {
    this.e = 0;
    this.s = this.e;
    List localList = (List)listLocal.get();
    localList.clear();
    int i = 0;
    for (;;)
    {
      Html.HtmlTag localHtmlTag = nextTag(paramString, '<', '>');
      if (localHtmlTag == null) {
        break;
      }
      if (i != this.s)
      {
        String str1 = paramString.substring(i, this.s);
        if (str1.length() != 0) {
          localList.add(new Html.HtmlTag(Html.Tag.TEXT, Html.HtmlTag.Type.ATOMIC, str1, paramString, i, this.s));
        }
      }
      i = this.e + 1;
      localList.add(localHtmlTag);
    }
    return (Html.HtmlTag[])localList.toArray(new Html.HtmlTag[localList.size()]);
  }
  
  public Html.HtmlTag[] decodeLinks(Html.HtmlTag[] paramArrayOfHtmlTag)
  {
    List localList = (List)listLocal.get();
    localList.clear();
    for (Html.HtmlTag localHtmlTag : paramArrayOfHtmlTag) {
      switch (1.$SwitchMap$org$jnetpcap$protocol$application$Html$Tag[localHtmlTag.getTag().ordinal()])
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        if (localHtmlTag.type == Html.HtmlTag.Type.OPEN) {
          localList.add(localHtmlTag);
        }
        break;
      }
    }
    return (Html.HtmlTag[])localList.toArray(new Html.HtmlTag[localList.size()]);
  }
  
  private String extractBounded(String paramString, char paramChar1, char paramChar2)
  {
    if (this.str != paramString)
    {
      this.s = 0;
      this.e = 0;
      this.str = paramString;
    }
    this.s = paramString.indexOf('<', this.e);
    this.e = paramString.indexOf('>', this.s);
    return (this.s == -1) || (this.e == -1) ? null : paramString.substring(this.s + 1, this.e).trim().replace("\r\n", "");
  }
  
  private Html.HtmlTag nextTag(String paramString, char paramChar1, char paramChar2)
  {
    String str1 = extractBounded(paramString, paramChar1, paramChar2);
    if (str1 == null) {
      return null;
    }
    Html.HtmlTag.Type localType = Html.HtmlTag.Type.OPEN;
    if (str1.charAt(0) == '/')
    {
      str1 = str1.substring(1);
      localType = Html.HtmlTag.Type.CLOSE;
    }
    Html.Tag localTag = Html.Tag.parseStringPrefix(str1);
    if (localTag == null) {
      return null;
    }
    Html.HtmlTag localHtmlTag = new Html.HtmlTag(localTag, localType, str1, this.str, this.s, this.e);
    return localHtmlTag;
  }
  
  public String format(String paramString)
  {
    paramString = paramString.replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    return paramString;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.application.HtmlParser
 * JD-Core Version:    0.7.0.1
 */