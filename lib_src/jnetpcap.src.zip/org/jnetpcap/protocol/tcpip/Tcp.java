package org.jnetpcap.protocol.tcpip;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeaderChecksum;
import org.jnetpcap.packet.JHeaderMap;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JSubHeader;
import org.jnetpcap.packet.annotate.BindingVariable;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.FlowKey;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.util.checksum.Checksum;

@Header
public class Tcp
  extends JHeaderMap<Tcp>
  implements JHeaderChecksum
{
  private static final int FLAG_ACK = 16;
  private static final int FLAG_CONG = 128;
  private static final int FLAG_CWR = 128;
  private static final int FLAG_ECE = 64;
  private static final int FLAG_ECN = 64;
  private static final int FLAG_FIN = 1;
  private static final int FLAG_PSH = 8;
  private static final int FLAG_RST = 4;
  private static final int FLAG_SYN = 2;
  private static final int FLAG_URG = 32;
  public static final int ID = 4;
  private int biDirectionalHashcode;
  private final Ip4 ip = new Ip4();
  private int uniDirectionalHashcode;
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    int i = (paramJBuffer.getUByte(paramInt + 12) & 0xF0) >> 4;
    return i * 4;
  }
  
  @Field(offset=64, length=16, format="%x")
  public long ack()
  {
    return getUInt(8);
  }
  
  public void ack(long paramLong)
  {
    super.setUInt(8, paramLong);
  }
  
  public int calculateChecksum()
  {
    if (getIndex() == -1) {
      throw new IllegalStateException("Oops index not set");
    }
    int i = getPreviousHeaderOffset();
    return Checksum.inChecksumShouldBe(checksum(), Checksum.pseudoTcp(this.packet, i, getOffset()));
  }
  
  @Field(offset=128, length=16, format="%x")
  public int checksum()
  {
    return getUShort(16);
  }
  
  public void checksum(int paramInt)
  {
    super.setUShort(16, paramInt);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String checksumDescription()
  {
    if (isFragmented()) {
      return "supressed for fragments";
    }
    if (isPayloadTruncated()) {
      return "supressed for truncated packets";
    }
    int i = calculateChecksum();
    if (checksum() == i) {
      return "correct";
    }
    return "incorrect: 0x" + Integer.toHexString(i).toUpperCase();
  }
  
  private void clearFlag(int paramInt)
  {
    super.setUByte(13, flags() & (paramInt ^ 0xFFFFFFFF));
  }
  
  protected void decodeHeader()
  {
    if ((getPacket() != null) && (getPacket().hasHeader(this.ip)))
    {
      this.biDirectionalHashcode = (this.ip.destinationToInt() + destination() ^ this.ip.sourceToInt() + source());
      this.uniDirectionalHashcode = (this.ip.destinationToInt() + destination());
    }
    else
    {
      this.biDirectionalHashcode = super.hashCode();
    }
    this.optionsBitmap = 0L;
    int i = hlen() * 4;
    for (int j = 20; j < i; j++)
    {
      int k = getUByte(j);
      this.optionsOffsets[k] = j;
      this.optionsBitmap |= 1 << k;
      Tcp.TcpOption.OptionCode localOptionCode = Tcp.TcpOption.OptionCode.valueOf(k);
      if (localOptionCode == null) {
        break;
      }
      switch (1.$SwitchMap$org$jnetpcap$protocol$tcpip$Tcp$TcpOption$OptionCode[localOptionCode.ordinal()])
      {
      case 1: 
        this.optionsLength[k] = 1;
        break;
      case 2: 
        this.optionsLength[k] = (i - j);
        j = i;
        break;
      default: 
        int m = getUByte(j + 1);
        j += m - 1;
        this.optionsLength[k] = m;
      }
    }
  }
  
  @Field(offset=16, length=16)
  @FlowKey(index=2, reversable=true)
  @BindingVariable
  public int destination()
  {
    return getUShort(2);
  }
  
  public void destination(int paramInt)
  {
    super.setUShort(2, paramInt);
  }
  
  @Field(offset=104, length=8, format="%x")
  public int flags()
  {
    return getUByte(13);
  }
  
  public void flags(int paramInt)
  {
    super.setUByte(13, paramInt);
  }
  
  @Field(parent="flags", offset=4, length=1, format="%b", display="ack", description="acknowledgment")
  public boolean flags_ACK()
  {
    return (flags() & 0x10) != 0;
  }
  
  public void flags_ACK(boolean paramBoolean)
  {
    setFlag(paramBoolean, 16);
  }
  
  @Field(parent="flags", offset=7, length=1, format="%b", display="cwr", description="reduced (cwr)")
  public boolean flags_CWR()
  {
    return (flags() & 0x80) != 0;
  }
  
  public void flags_CWR(boolean paramBoolean)
  {
    setFlag(paramBoolean, 128);
  }
  
  @Field(parent="flags", offset=6, length=1, format="%b", display="ece", description="ECN echo flag")
  public boolean flags_ECE()
  {
    return (flags() & 0x40) != 0;
  }
  
  public void flags_ECE(boolean paramBoolean)
  {
    setFlag(paramBoolean, 64);
  }
  
  @Field(parent="flags", offset=0, length=1, format="%b", display="fin", description="closing down connection")
  public boolean flags_FIN()
  {
    return (flags() & 0x1) != 0;
  }
  
  public void flags_FIN(boolean paramBoolean)
  {
    setFlag(paramBoolean, 1);
  }
  
  @Field(parent="flags", offset=3, length=1, format="%b", display="ack", description="push current segment of data")
  public boolean flags_PSH()
  {
    return (flags() & 0x8) != 0;
  }
  
  public void flags_PSH(boolean paramBoolean)
  {
    setFlag(paramBoolean, 8);
  }
  
  @Field(parent="flags", offset=2, length=1, format="%b", display="ack", description="reset connection")
  public boolean flags_RST()
  {
    return (flags() & 0x4) != 0;
  }
  
  public void flags_RST(boolean paramBoolean)
  {
    setFlag(paramBoolean, 4);
  }
  
  @Field(parent="flags", offset=1, length=1, format="%b", display="ack", description="synchronize connection, startup")
  public boolean flags_SYN()
  {
    return (flags() & 0x2) != 0;
  }
  
  public void flags_SYN(boolean paramBoolean)
  {
    setFlag(paramBoolean, 2);
  }
  
  @Field(parent="flags", offset=5, length=1, format="%b", display="ack", description="urgent, out-of-band data")
  public boolean flags_URG()
  {
    return (flags() & 0x20) != 0;
  }
  
  public void flags_URG(boolean paramBoolean)
  {
    setFlag(paramBoolean, 32);
  }
  
  public String flagsCompactString()
  {
    return Flag.toCompactString(flags());
  }
  
  public Set<Flag> flagsEnum()
  {
    return Flag.asSet(flags());
  }
  
  public int hashCode()
  {
    return this.biDirectionalHashcode;
  }
  
  @Field(offset=96, length=4)
  public int hlen()
  {
    return (getUByte(12) & 0xF0) >> 4;
  }
  
  public void hlen(int paramInt)
  {
    super.setUByte(12, getUByte(12) & 0xF | paramInt << 4);
  }
  
  public boolean isChecksumValid()
  {
    if (isFragmented()) {
      return true;
    }
    if (getIndex() == -1) {
      throw new IllegalStateException("Oops index not set");
    }
    int i = getPreviousHeaderOffset();
    return Checksum.pseudoTcp(this.packet, i, getOffset()) == 0;
  }
  
  @Field(offset=100, length=4)
  public int reserved()
  {
    return getUByte(12) & 0xF;
  }
  
  public void reserved(int paramInt)
  {
    setUByte(12, paramInt & 0xF);
  }
  
  @Field(offset=32, length=16, format="%x")
  public long seq()
  {
    return getUInt(4);
  }
  
  public void seq(long paramLong)
  {
    super.setUInt(4, paramLong);
  }
  
  private void setFlag(boolean paramBoolean, int paramInt)
  {
    if (paramBoolean) {
      setFlag(paramInt);
    } else {
      clearFlag(paramInt);
    }
  }
  
  private void setFlag(int paramInt)
  {
    super.setUByte(13, flags() | paramInt);
  }
  
  @Field(offset=0, length=16)
  @FlowKey(index=2, reversable=true)
  @BindingVariable
  public int source()
  {
    return getUShort(0);
  }
  
  public void source(int paramInt)
  {
    super.setUShort(0, paramInt);
  }
  
  public int uniHashCode()
  {
    return this.uniDirectionalHashcode;
  }
  
  @Field(offset=144, length=16)
  public int urgent()
  {
    return getUShort(18);
  }
  
  public void urgent(int paramInt)
  {
    super.setUShort(18, paramInt);
  }
  
  @Field(offset=112, length=16)
  public int window()
  {
    return getUShort(14);
  }
  
  public void window(int paramInt)
  {
    super.setUShort(14, paramInt);
  }
  
  public int windowScaled()
  {
    return window() << 6;
  }
  
  @Header(id=3)
  public static class WindowScale
    extends Tcp.TcpOption
  {
    @Field(offset=16, length=8)
    public int scale()
    {
      return getUByte(2);
    }
    
    public void scale(int paramInt)
    {
      setUByte(2, paramInt);
    }
  }
  
  @Header(id=8)
  public static class Timestamp
    extends Tcp.TcpOption
  {
    @Field(offset=48, length=32)
    public long tsecr()
    {
      return getUInt(6);
    }
    
    public void tsecr(long paramLong)
    {
      setUInt(6, paramLong);
    }
    
    @Field(offset=16, length=32)
    public long tsval()
    {
      return getUInt(2);
    }
    
    public void tsval(long paramLong)
    {
      setUInt(2, paramLong);
    }
  }
  
  public static abstract class TcpOption
    extends JSubHeader<Tcp>
  {
    @Field(offset=0, length=8)
    public int code()
    {
      return getUByte(0);
    }
    
    public void code(int paramInt)
    {
      setUByte(0, paramInt);
    }
    
    @Field(offset=8, length=8)
    public int length()
    {
      return lengthCheck(null) ? getUByte(1) : 1;
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String lengthDescription()
    {
      return lengthCheck(null) ? null : "implied length from option type";
    }
    
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
    
    @Dynamic(field="length", value=Field.Property.CHECK)
    public boolean lengthCheck(String paramString)
    {
      return code() > 1;
    }
    
    public static enum OptionCode
    {
      ALTERNATE_CHECKSUM(15),  ALTERNATE_CHECKSUM_REQUEST(14),  END_OF_OPTION_LIST(0),  MAXIMUM_SEGMENT_SIZE(2),  NO_OP(1),  SACK(5),  SACK_PERMITTED(4),  TIMESTAP(8),  WINDOW_SCALE(3);
      
      public final int id;
      
      public static OptionCode valueOf(int paramInt)
      {
        for (OptionCode localOptionCode : ) {
          if (localOptionCode.id == paramInt) {
            return localOptionCode;
          }
        }
        return null;
      }
      
      private OptionCode(int paramInt)
      {
        this.id = paramInt;
      }
    }
  }
  
  @Header(id=4)
  public static class SACK_PERMITTED
    extends Tcp.TcpOption
  {}
  
  @Header(id=5)
  public static class SACK
    extends Tcp.TcpOption
  {
    public int blockCount()
    {
      return (size() - 2) / 8;
    }
    
    @Dynamic(Field.Property.LENGTH)
    public int blocksLength()
    {
      return blockCount() * 64;
    }
    
    @Field(offset=16)
    public long[] blocks()
    {
      return blocksToArray(new long[blockCount() * 2]);
    }
    
    public void blocks(long[] paramArrayOfLong)
    {
      int i = paramArrayOfLong.length / 2;
      for (int j = 0; j < i; j++) {
        setUInt(j * 4 + 2, paramArrayOfLong[j]);
      }
      length(paramArrayOfLong.length * 4 + 2);
    }
    
    public long[] blocksToArray(long[] paramArrayOfLong)
    {
      int i = paramArrayOfLong.length < blockCount() * 2 ? paramArrayOfLong.length : blockCount() * 2;
      for (int j = 0; j < i; j++) {
        paramArrayOfLong[j] = getUInt(j * 4 + 2);
      }
      return paramArrayOfLong;
    }
  }
  
  @Header(id=1)
  public static class NoOp
    extends Tcp.TcpOption
  {}
  
  @Header(id=2, description="Maximum Segment Size")
  public static class MSS
    extends Tcp.TcpOption
  {
    @Field(offset=16, length=16)
    public int mss()
    {
      return getUShort(2);
    }
    
    public void mss(int paramInt)
    {
      setUShort(2, paramInt);
    }
  }
  
  public static enum Flag
  {
    ACK,  CWR,  ECE,  FIN,  PSH,  RST,  SYN,  URG;
    
    private Flag() {}
    
    public static Set<Flag> asSet(int paramInt)
    {
      EnumSet localEnumSet = EnumSet.noneOf(Flag.class);
      int i = values().length;
      for (int j = 0; j < i; j++) {
        if ((paramInt & 1 << j) > 0) {
          localEnumSet.add(values()[j]);
        }
      }
      return localEnumSet;
    }
    
    public static String toCompactString(int paramInt)
    {
      return toCompactString(asSet(paramInt));
    }
    
    public static String toCompactString(Set<Flag> paramSet)
    {
      StringBuilder localStringBuilder = new StringBuilder(values().length);
      Iterator localIterator = paramSet.iterator();
      while (localIterator.hasNext())
      {
        Flag localFlag = (Flag)localIterator.next();
        localStringBuilder.append(localFlag.name().charAt(0));
      }
      return localStringBuilder.toString();
    }
  }
  
  @Header(id=14)
  public static class AlternateChecksumRequest
    extends Tcp.TcpOption
  {
    @Field(offset=16, length=8)
    public int algorithm()
    {
      return getUByte(2);
    }
    
    public Algorithm algorithmEnum()
    {
      return Algorithm.valueOf(algorithm());
    }
    
    public void algorithm(int paramInt)
    {
      setUByte(2, paramInt);
    }
    
    public static enum Algorithm
    {
      TCP_CHECKSUM(0),  FLETCHER_8BIT(1),  FLETCHER_16BIT(2),  AVOIDANCE(3);
      
      public final int type;
      
      private Algorithm(int paramInt)
      {
        this.type = paramInt;
      }
      
      public static Algorithm valueOf(int paramInt)
      {
        for (Algorithm localAlgorithm : ) {
          if (paramInt == localAlgorithm.type) {
            return localAlgorithm;
          }
        }
        return null;
      }
    }
  }
  
  @Header(id=15)
  public static class AlternateChecksum
    extends Tcp.TcpOption
  {
    @Field(offset=16, format="#hexdump#")
    public byte[] data()
    {
      return getByteArray(2, dataLength() / 8);
    }
    
    public byte[] dataToArray(byte[] paramArrayOfByte)
    {
      return getByteArray(2, paramArrayOfByte);
    }
    
    @Dynamic(Field.Property.LENGTH)
    public int dataLength()
    {
      return (length() - 2) * 8;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.tcpip.Tcp
 * JD-Core Version:    0.7.0.1
 */