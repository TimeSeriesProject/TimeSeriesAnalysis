package org.jnetpcap.protocol.tcpip;

import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JHeaderChecksum;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.FlowKey;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.util.checksum.Checksum;

@Header(length=8)
public class Udp
  extends JHeader
  implements JHeaderChecksum
{
  public static final int ID = 5;
  
  public int calculateChecksum()
  {
    if (getIndex() == -1) {
      throw new IllegalStateException("Oops index not set");
    }
    int i = getPreviousHeaderOffset();
    return Checksum.inChecksumShouldBe(checksum(), Checksum.pseudoUdp(this.packet, i, getOffset()));
  }
  
  @Field(offset=48, length=16, format="%x")
  public int checksum()
  {
    return getUShort(6);
  }
  
  public void checksum(int paramInt)
  {
    super.setUShort(6, paramInt);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String checksumDescription()
  {
    if (isFragmented()) {
      return "supressed for fragments";
    }
    if (isPayloadTruncated()) {
      return "supressed for truncated packets";
    }
    int i = checksum();
    if (i == 0) {
      return "omitted";
    }
    int j = calculateChecksum();
    if (i == j) {
      return "correct";
    }
    return "incorrect: 0x" + Integer.toHexString(j).toUpperCase();
  }
  
  @Field(offset=16, length=16)
  @FlowKey(index=2, reversable=true)
  public int destination()
  {
    return getUShort(2);
  }
  
  public void destination(int paramInt)
  {
    setUShort(2, paramInt);
  }
  
  public boolean isChecksumValid()
  {
    if (isFragmented()) {
      return true;
    }
    if (getIndex() == -1) {
      throw new IllegalStateException("Oops index not set");
    }
    int i = getPreviousHeaderOffset();
    return Checksum.pseudoUdp(this.packet, i, getOffset()) == 0;
  }
  
  @Field(offset=32, length=16)
  public int length()
  {
    return getUShort(4);
  }
  
  public void length(int paramInt)
  {
    setUShort(4, paramInt);
  }
  
  @Field(offset=0, length=16)
  @FlowKey(index=2, reversable=true)
  public int source()
  {
    return getUShort(0);
  }
  
  public void source(int paramInt)
  {
    setUShort(0, paramInt);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.tcpip.Udp
 * JD-Core Version:    0.7.0.1
 */