package org.jnetpcap.protocol.tcpip;

public abstract interface HttpOptions
{
  public abstract boolean skipFragments(boolean paramBoolean);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.tcpip.HttpOptions
 * JD-Core Version:    0.7.0.1
 */