package org.jnetpcap.protocol.tcpip;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.packet.AbstractMessageHeader;
import org.jnetpcap.packet.AbstractMessageHeader.MessageType;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.ProtocolSuite;

@Header(suite=ProtocolSuite.TCP_IP)
public class Http
  extends AbstractMessageHeader
{
  public static final int ID = 13;
  
  public String contentType()
  {
    return fieldValue(Response.Content_Type);
  }
  
  public ContentType contentTypeEnum()
  {
    return ContentType.parseContentType(contentType());
  }
  
  public boolean hasChuncks()
  {
    return false;
  }
  
  public Chunk[] chunks()
  {
    return new Chunk[0];
  }
  
  protected void decodeFirstLine(String paramString)
  {
    String[] arrayOfString = paramString.split(" ");
    if (arrayOfString.length < 3) {
      return;
    }
    if (arrayOfString[0].startsWith("HTTP"))
    {
      super.setMessageType(AbstractMessageHeader.MessageType.RESPONSE);
      super.addField(Response.RequestVersion, arrayOfString[0], paramString.indexOf(arrayOfString[0]));
      super.addField(Response.ResponseCode, arrayOfString[1], paramString.indexOf(arrayOfString[1]));
      super.addField(Response.ResponseCodeMsg, arrayOfString[2], paramString.indexOf(arrayOfString[2]));
    }
    else
    {
      super.setMessageType(AbstractMessageHeader.MessageType.REQUEST);
      super.addField(Request.RequestMethod, arrayOfString[0], paramString.indexOf(arrayOfString[0]));
      super.addField(Request.RequestUrl, arrayOfString[1], paramString.indexOf(arrayOfString[1]));
      super.addField(Request.RequestVersion, arrayOfString[2], paramString.indexOf(arrayOfString[2]));
    }
  }
  
  public String fieldValue(Request paramRequest)
  {
    return (String)super.fieldValue(String.class, paramRequest);
  }
  
  public String fieldValue(Response paramResponse)
  {
    return (String)super.fieldValue(String.class, paramResponse);
  }
  
  public boolean hasContent()
  {
    return (hasField(Response.Content_Type)) || (hasField(Request.Content_Type));
  }
  
  public boolean hasContentType()
  {
    return hasField(Response.Content_Type);
  }
  
  public boolean hasField(Request paramRequest)
  {
    return super.hasField(paramRequest);
  }
  
  public boolean hasField(Response paramResponse)
  {
    return super.hasField(paramResponse);
  }
  
  public boolean isResponse()
  {
    return getMessageType() == AbstractMessageHeader.MessageType.RESPONSE;
  }
  
  public String header()
  {
    return this.rawHeader;
  }
  
  public static class Chunk
    extends JBuffer
  {
    public Chunk(JMemory.Type paramType)
    {
      super();
    }
  }
  
  @Field
  public static enum Response
  {
    Accept_Ranges,  Age,  Allow,  Cache_Control,  Content_Disposition,  Content_Encoding,  Content_Length,  Content_Location,  Content_MD5,  Content_Range,  Content_Type,  Expires,  Server,  Set_Cookie,  RequestUrl,  RequestVersion,  ResponseCode,  ResponseCodeMsg;
    
    private Response() {}
  }
  
  @Field
  public static enum Request
  {
    Accept,  Accept_Charset,  Accept_Encoding,  Accept_Ranges,  Accept_Language,  UA_CPU,  Proxy_Connection,  Authorization,  Cache_Control,  Connection,  Cookie,  Date,  Host,  If_Modified_Since,  If_None_Match,  Referer,  RequestMethod,  RequestUrl,  RequestVersion,  User_Agent,  Content_Length,  Content_Type;
    
    private Request() {}
  }
  
  public static enum ContentType
  {
    GIF(new String[] { "image/gif" }),  HTML(new String[] { "text/html" }),  JPEG(new String[] { "image/jpeg" }),  PNG(new String[] { "image/png" }),  OTHER(new String[0]);
    
    private final String[] magic;
    
    public static ContentType parseContentType(String paramString)
    {
      if (paramString == null) {
        return OTHER;
      }
      for (ContentType localContentType : values())
      {
        if (localContentType.name().equalsIgnoreCase(paramString)) {
          return localContentType;
        }
        for (String str : localContentType.magic) {
          if (paramString.startsWith(str)) {
            return localContentType;
          }
        }
      }
      return OTHER;
    }
    
    private ContentType(String... paramVarArgs)
    {
      this.magic = paramVarArgs;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.tcpip.Http
 * JD-Core Version:    0.7.0.1
 */