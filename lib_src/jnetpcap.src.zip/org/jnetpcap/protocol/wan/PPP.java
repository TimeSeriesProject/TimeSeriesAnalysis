package org.jnetpcap.protocol.wan;

import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Header;

@Header(length=5, dlt={org.jnetpcap.PcapDLT.PPP})
public class PPP
  extends JHeader
{
  public static final int ID = 11;
  
  @Field(offset=0, length=8)
  public int address()
  {
    return getUByte(0);
  }
  
  @Field(offset=8, length=8)
  public int control()
  {
    return getUByte(1);
  }
  
  @Field(offset=16, length=16, format="%x")
  public int protocol()
  {
    return getUShort(2);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.wan.PPP
 * JD-Core Version:    0.7.0.1
 */