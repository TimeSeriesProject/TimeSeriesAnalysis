package org.jnetpcap.protocol.lan;

import java.nio.ByteOrder;
import java.util.List;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.FlowKey;
import org.jnetpcap.packet.annotate.Format;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.Header.Layer;
import org.jnetpcap.packet.structure.JField;
import org.jnetpcap.util.checksum.Checksum;

@Header(length=14, dlt={org.jnetpcap.PcapDLT.EN10MB, org.jnetpcap.PcapDLT.FDDI}, osi=Header.Layer.DATALINK, characteristics={org.jnetpcap.packet.annotate.Header.Characteristic.CSMA_CD}, nicname="Eth", description="Ethernet", url="http://en.wikipedia.org/wiki/Ethernet")
public class Ethernet
  extends JHeader
{
  public static final int ADDRESS_IG_BIT = 64;
  public static final int ADDRESS_LG_BIT = 128;
  public static final int ID = 1;
  public static final int LENGTH = 14;
  public static final String ORG_IEEE = "IEEE Ethernet2";
  
  @Field(offset=0, length=48, format="#mac#", mask=281470681743360L)
  public byte[] destination()
  {
    return getByteArray(0, 6);
  }
  
  @Field(parent="destination", offset=40, length=1, display="IG bit")
  @FlowKey(index=0)
  public long destination_IG()
  {
    return (getUByte(0) & 0x40) >> 5;
  }
  
  @Field(parent="destination", offset=41, length=1, display="LG bit")
  public long destination_LG()
  {
    return (getUByte(0) & 0x80) >> 6;
  }
  
  public void destination(byte[] paramArrayOfByte)
  {
    setByteArray(0, paramArrayOfByte);
  }
  
  public byte[] destinationToByteArray(byte[] paramArrayOfByte)
  {
    return getByteArray(0, paramArrayOfByte);
  }
  
  @Field(offset=48, length=48, format="#mac#", mask=281470681743360L)
  @FlowKey(index=0)
  public byte[] source()
  {
    return getByteArray(6, 6);
  }
  
  @Field(parent="source", offset=40, length=1, display="IG bit")
  public long source_IG()
  {
    return (getUByte(0) & 0x40) >> 5;
  }
  
  @Field(parent="source", offset=41, length=1, display="LG bit")
  public long source_LG()
  {
    return (getUByte(0) & 0x80) >> 6;
  }
  
  public void source(byte[] paramArrayOfByte)
  {
    setByteArray(6, paramArrayOfByte);
  }
  
  public byte[] sourceToByteArray(byte[] paramArrayOfByte)
  {
    return getByteArray(6, paramArrayOfByte);
  }
  
  @Field(offset=96, length=16, format="%x")
  @FlowKey(index=1)
  public int type()
  {
    return getUShort(12);
  }
  
  public void type(int paramInt)
  {
    setUShort(12, paramInt);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String typeDescription()
  {
    return EthernetType.toString(type());
  }
  
  @Format
  public void formatHeader(List<JField> paramList) {}
  
  public EthernetType typeEnum()
  {
    return EthernetType.valueOf(type());
  }
  
  @Dynamic(field="checksum", value=Field.Property.CHECK)
  public boolean checksumCheck()
  {
    return getPostfixLength() >= 4;
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int checksumOffset()
  {
    return getPostfixOffset() * 8;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String checksumDescription()
  {
    long l = calculateChecksum();
    if (checksum() == l) {
      return "correct";
    }
    return "incorrect: 0x" + Long.toHexString(l).toUpperCase();
  }
  
  @Field(length=32, format="%x", display="FCS")
  public long checksum()
  {
    JPacket localJPacket = getPacket();
    localJPacket.order(ByteOrder.BIG_ENDIAN);
    return localJPacket.getUInt(getPostfixOffset());
  }
  
  public boolean checksum(long paramLong)
  {
    if (getPostfixLength() < 4) {
      return false;
    }
    JPacket localJPacket = getPacket();
    localJPacket.order(ByteOrder.BIG_ENDIAN);
    localJPacket.setUInt(localJPacket.size() - 4, paramLong);
    return true;
  }
  
  public long calculateChecksum()
  {
    JPacket localJPacket = getPacket();
    return Checksum.crc32IEEE802(localJPacket, 0, getHeaderLength() + getPayloadLength());
  }
  
  public static enum EthernetType
  {
    IEEE_802DOT1Q(33024, "vlan - IEEE 802.1q"),  IP4(2048, "ip version 4"),  IP6(34525, "ip version 6");
    
    private final String description;
    private final int id;
    
    public static String toString(int paramInt)
    {
      for (EthernetType localEthernetType : ) {
        if (localEthernetType.id == paramInt) {
          return localEthernetType.description;
        }
      }
      return null;
    }
    
    public static EthernetType valueOf(int paramInt)
    {
      for (EthernetType localEthernetType : ) {
        if (localEthernetType.id == paramInt) {
          return localEthernetType;
        }
      }
      return null;
    }
    
    private EthernetType(int paramInt)
    {
      this.id = paramInt;
      this.description = name().toLowerCase();
    }
    
    private EthernetType(int paramInt, String paramString)
    {
      this.id = paramInt;
      this.description = paramString;
    }
    
    public final String getDescription()
    {
      return this.description;
    }
    
    public final int getId()
    {
      return this.id;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.lan.Ethernet
 * JD-Core Version:    0.7.0.1
 */