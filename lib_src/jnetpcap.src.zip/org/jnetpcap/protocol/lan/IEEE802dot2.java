package org.jnetpcap.protocol.lan;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;

@Header(nicname="llc")
public class IEEE802dot2
  extends JHeader
{
  public static final int ID = 7;
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    return (paramJBuffer.getUShort(paramInt + 2) & 0x3) == 3 ? 4 : 5;
  }
  
  @Field(offset=0, format="%x")
  public int control()
  {
    int i = getUByte(2);
    if ((i & 0x3) == 3) {
      return i;
    }
    return getUShort(2);
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int controlLength()
  {
    return (super.getUByte(2) & 0x3) == 3 ? 8 : 16;
  }
  
  @Field(offset=0, length=8, format="%x")
  public int dsap()
  {
    return getUByte(0);
  }
  
  @Field(offset=8, length=8, format="%x")
  public int ssap()
  {
    return getUByte(1);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.lan.IEEE802dot2
 * JD-Core Version:    0.7.0.1
 */