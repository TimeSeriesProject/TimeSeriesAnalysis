package org.jnetpcap.protocol.lan;

import java.nio.ByteOrder;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.util.checksum.Checksum;

@Header(length=14, dlt={org.jnetpcap.PcapDLT.IEEE802})
public class IEEE802dot3
  extends JHeader
{
  public static final int ID = 6;
  
  @Field(offset=0, length=48, format="#mac#")
  public byte[] destination()
  {
    return getByteArray(0, 6);
  }
  
  public byte[] destinationToByteArray(byte[] paramArrayOfByte)
  {
    return getByteArray(0, paramArrayOfByte);
  }
  
  public void destination(byte[] paramArrayOfByte)
  {
    setByteArray(0, paramArrayOfByte);
  }
  
  @Field(offset=48, length=48, format="#mac#")
  public byte[] source()
  {
    return getByteArray(6, 6);
  }
  
  public void source(byte[] paramArrayOfByte)
  {
    setByteArray(6, paramArrayOfByte);
  }
  
  public byte[] sourceToByteArray(byte[] paramArrayOfByte)
  {
    return getByteArray(6, paramArrayOfByte);
  }
  
  @Field(offset=96, length=16, format="%d")
  public int length()
  {
    return getUShort(12);
  }
  
  public void length(int paramInt)
  {
    setUShort(12, paramInt);
  }
  
  @Dynamic(field="checksum", value=Field.Property.CHECK)
  public boolean checksumCheck()
  {
    return getPostfixLength() >= 4;
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int checksumOffset()
  {
    return getPostfixOffset() * 8;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String checksumDescription()
  {
    long l = calculateChecksum();
    if (checksum() == l) {
      return "correct";
    }
    return "incorrect: 0x" + Long.toHexString(l).toUpperCase();
  }
  
  @Field(length=32, format="%x", display="FCS")
  public long checksum()
  {
    JPacket localJPacket = getPacket();
    localJPacket.order(ByteOrder.BIG_ENDIAN);
    return localJPacket.getUInt(getPostfixOffset());
  }
  
  public long calculateChecksum()
  {
    if (getPostfixLength() < 4) {
      return 0L;
    }
    JPacket localJPacket = getPacket();
    return Checksum.crc32IEEE802(localJPacket, 0, localJPacket.size() - 4);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.lan.IEEE802dot3
 * JD-Core Version:    0.7.0.1
 */