package org.jnetpcap.protocol.lan;

import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;

@Header(length=5, nicname="snap")
public class IEEESnap
  extends JHeader
{
  public static final int ID = 8;
  
  @Field(offset=0, length=24, format="%x")
  public long oui()
  {
    return getUInt(0) & 0xFFFFFF;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String pidDescription()
  {
    return Ethernet.EthernetType.toString(pid());
  }
  
  @Field(offset=24, length=16, format="%x")
  public int pid()
  {
    return getUShort(3);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.lan.IEEESnap
 * JD-Core Version:    0.7.0.1
 */