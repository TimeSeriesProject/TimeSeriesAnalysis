package org.jnetpcap.protocol.lan;

import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;

@Header(length=4, nicname="vlan")
public class IEEE802dot1q
  extends JHeader
{
  public static final int ID = 9;
  
  @Field(offset=0, length=3, format="%d")
  public int priority()
  {
    return (getUByte(0) & 0xE0) >> 5;
  }
  
  @Field(offset=3, length=1, format="%x")
  public int cfi()
  {
    return (getUByte(0) & 0x10) >> 4;
  }
  
  @Field(offset=4, length=12, format="%x")
  public int id()
  {
    return getUShort(0) & 0xFFF;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String typeDescription()
  {
    return Ethernet.EthernetType.toString(type());
  }
  
  @Field(offset=16, length=16, format="%x")
  public int type()
  {
    return getUShort(2);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.lan.IEEE802dot1q
 * JD-Core Version:    0.7.0.1
 */