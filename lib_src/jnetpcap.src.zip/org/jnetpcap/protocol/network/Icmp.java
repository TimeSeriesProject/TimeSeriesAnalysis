package org.jnetpcap.protocol.network;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeaderChecksum;
import org.jnetpcap.packet.JHeaderMap;
import org.jnetpcap.packet.JSubHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.util.checksum.Checksum;

@Header
public class Icmp
  extends JHeaderMap<Icmp>
  implements JHeaderChecksum
{
  public static final int ID = 12;
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    switch (paramJBuffer.getUByte(paramInt))
    {
    case 0: 
    case 8: 
      return paramJBuffer.size() - paramInt - 4;
    }
    return 4;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String checksumDescription()
  {
    if (isFragmented()) {
      return "supressed for fragments";
    }
    if (isPayloadTruncated()) {
      return "supressed for truncated packets";
    }
    int i = calculateChecksum();
    if (checksum() == i) {
      return "correct";
    }
    return "incorrect: 0x" + Integer.toHexString(i).toUpperCase();
  }
  
  @Field(offset=16, length=16, format="%x")
  public int checksum()
  {
    return super.getUShort(2);
  }
  
  @Field(offset=8, length=8, format="%x")
  public int code()
  {
    return super.getUByte(1);
  }
  
  public IcmpCode codeEnum()
  {
    return IcmpCode.valueOf(type(), code());
  }
  
  protected void decodeHeader()
  {
    int i = type();
    this.optionsOffsets[i] = 4;
    this.optionsBitmap = (1 << i);
    this.optionsLength[i] = (getLength() - 4);
  }
  
  @Field(offset=0, length=8, format="%x")
  public int type()
  {
    return super.getUByte(0);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String typeDescription()
  {
    return IcmpType.valueOf(type()).getDescription();
  }
  
  public IcmpType typeEnum()
  {
    return IcmpType.valueOf(type());
  }
  
  public int calculateChecksum()
  {
    if (getIndex() == -1) {
      throw new IllegalStateException("Oops index not set");
    }
    int i = getPreviousHeaderOffset();
    return Checksum.inChecksumShouldBe(checksum(), Checksum.icmp(this.packet, i, getOffset()));
  }
  
  public boolean isChecksumValid()
  {
    if (isFragmented()) {
      return true;
    }
    if (getIndex() == -1) {
      throw new IllegalStateException("Oops index not set");
    }
    int i = getPreviousHeaderOffset();
    return Checksum.icmp(this.packet, i, getOffset()) == 0;
  }
  
  @Header(length=4, id=4)
  public static class SourceQuench
    extends Icmp.Reserved
  {}
  
  public static abstract class Reserved
    extends JSubHeader<Icmp>
  {
    public long reserved()
    {
      return getUInt(0);
    }
  }
  
  @Header(length=4, id=5)
  public static class Redirect
    extends JSubHeader<Icmp>
  {
    public byte[] gateway()
    {
      return getByteArray(0, 4);
    }
  }
  
  @Header(length=4, id=12)
  public static class ParamProblem
    extends JSubHeader<Icmp>
  {
    @Field(offset=0, length=8)
    public int pointer()
    {
      return getUByte(0);
    }
    
    @Field(offset=8, length=24)
    public int reserved()
    {
      return (int)(getUInt(0) & 0xFFFFFF);
    }
  }
  
  public static enum IcmpType
  {
    DESTINATION_UNREACHABLE(3, "destination unreachable"),  ECHO_REPLY(0, "echo reply"),  ECHO_REQUEST(8, "echo request"),  INFO_REQUEST(15, "info request"),  INFO_RESPONSE(16, "info response"),  PARAM_PROBLEM(12, "parameter problem"),  REDIRECT(5, "redirect"),  SOURCE_QUENCH(4, "source quench"),  TIME_EXCEEDED(11, "time exceeded"),  TIMESTAMP_REQUEST(13, "timestamp request"),  TIMESTAMP_RESPONSE(14, "timestamp response");
    
    public static final int DESTINATION_UNREACHABLE_ID = 3;
    public static final int ECHO_REPLY_ID = 0;
    public static final int ECHO_REQUEST_ID = 8;
    public static final int INFO_REQUEST_ID = 15;
    public static final int INFO_RESPONSE_ID = 16;
    public static final int PARAM_PROBLEM_ID = 12;
    public static final int REDIRECT_ID = 5;
    public static final int SOURCE_QUENCH_ID = 4;
    public static final int TIME_EXCEEDED_ID = 11;
    public static final int TIMESTAMP_REQUEST_ID = 13;
    public static final int TIMESTAMP_RESPONSE_ID = 14;
    private final String description;
    public final int id;
    
    public static String toString(int paramInt)
    {
      for (IcmpType localIcmpType : ) {
        if (localIcmpType.id == paramInt) {
          return localIcmpType.description;
        }
      }
      return null;
    }
    
    public static IcmpType valueOf(int paramInt)
    {
      for (IcmpType localIcmpType : ) {
        if (localIcmpType.id == paramInt) {
          return localIcmpType;
        }
      }
      return null;
    }
    
    private IcmpType(int paramInt)
    {
      this.id = paramInt;
      this.description = name().toLowerCase().replace('_', ' ');
    }
    
    private IcmpType(int paramInt, String paramString)
    {
      this.id = paramInt;
      this.description = paramString;
    }
    
    public final String getDescription()
    {
      return this.description;
    }
    
    public final int getId()
    {
      return this.id;
    }
  }
  
  public static enum IcmpCode
  {
    DESTINATION_HOST_ADMIN_PROHIBITED(Icmp.IcmpType.DESTINATION_UNREACHABLE, 10),  DESTINATION_HOST_ISOLATED(Icmp.IcmpType.DESTINATION_UNREACHABLE, 8),  DESTINATION_HOST_UNKNOWN(Icmp.IcmpType.DESTINATION_UNREACHABLE, 7),  DESTINATION_HOST_UNREACHABLE_FOR_SERVICE(Icmp.IcmpType.DESTINATION_UNREACHABLE, 12),  DESTINATION_NETWORK_ADMIN_PROHIBITED(Icmp.IcmpType.DESTINATION_UNREACHABLE, 9),  DESTINATION_NETWORK_REDIRECT(Icmp.IcmpType.DESTINATION_UNREACHABLE, 0),  DESTINATION_NETWORK_UNREACHABLE(Icmp.IcmpType.DESTINATION_UNREACHABLE, 6),  DESTINATION_NETWORK_UNREACHABLE_FOR_SERVICE(Icmp.IcmpType.DESTINATION_UNREACHABLE, 11),  DESTINATION_NO_FRAG(Icmp.IcmpType.DESTINATION_UNREACHABLE, 4),  DESTINATION_PORT_UNREACHABLE(Icmp.IcmpType.DESTINATION_UNREACHABLE, 3),  DESTINATION_PROTOCOL_UNREACHABLE(Icmp.IcmpType.DESTINATION_UNREACHABLE, 1),  DESTINATION_SOURCE_ROUTE(Icmp.IcmpType.DESTINATION_UNREACHABLE, 5),  PARAMETER_PROBLEM_MISSING_OPTION(Icmp.IcmpType.PARAM_PROBLEM, 1),  PARAMETER_PROBLEM_WITH_DATAGRAM(Icmp.IcmpType.PARAM_PROBLEM, 0),  REDIRECT_HOST(Icmp.IcmpType.REDIRECT, 1),  REDIRECT_NETWORK(Icmp.IcmpType.REDIRECT, 0),  REDIRECT_SERVICE_AND_HOST(Icmp.IcmpType.REDIRECT, 3),  REDIRECT_SERVICE_AND_NETWORK(Icmp.IcmpType.REDIRECT, 2),  TIME_EXCEEDED_DURING_FRAG_REASSEMBLY(Icmp.IcmpType.TIME_EXCEEDED, 1),  TIME_EXCEEDED_IN_TRANSIT(Icmp.IcmpType.TIME_EXCEEDED, 1);
    
    private final int code;
    private final String description;
    private final Icmp.IcmpType type;
    
    public static String toString(int paramInt1, int paramInt2)
    {
      for (IcmpCode localIcmpCode : ) {
        if ((localIcmpCode.type.id == paramInt1) && (localIcmpCode.code == paramInt2)) {
          return localIcmpCode.description;
        }
      }
      return null;
    }
    
    public static IcmpCode valueOf(int paramInt1, int paramInt2)
    {
      for (IcmpCode localIcmpCode : ) {
        if ((localIcmpCode.type.id == paramInt1) && (localIcmpCode.code == paramInt2)) {
          return localIcmpCode;
        }
      }
      return null;
    }
    
    private IcmpCode(Icmp.IcmpType paramIcmpType, int paramInt)
    {
      this.type = paramIcmpType;
      this.code = paramInt;
      this.description = name().toString().toLowerCase().replace('_', ' ');
    }
    
    private IcmpCode(Icmp.IcmpType paramIcmpType, int paramInt, String paramString)
    {
      this.type = paramIcmpType;
      this.code = paramInt;
      this.description = paramString;
    }
    
    public final int getCode()
    {
      return this.code;
    }
    
    public final String getDescription()
    {
      return this.description;
    }
    
    public final Icmp.IcmpType getType()
    {
      return this.type;
    }
  }
  
  @Header(id=8, length=4, nicname="request")
  public static class EchoRequest
    extends Icmp.Echo
  {}
  
  @Header(id=0, length=4, nicname="reply")
  public static class EchoReply
    extends Icmp.Echo
  {}
  
  public static abstract class Echo
    extends JSubHeader<Icmp>
  {
    @Field(offset=0, length=16, format="%x")
    public int id()
    {
      return super.getUShort(0);
    }
    
    @Field(offset=16, length=16, format="%x")
    public int sequence()
    {
      return super.getUShort(2);
    }
  }
  
  @Header(length=4, id=3, nicname="unreach")
  public static class DestinationUnreachable
    extends Icmp.Reserved
  {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Icmp
 * JD-Core Version:    0.7.0.1
 */