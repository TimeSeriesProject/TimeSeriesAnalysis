package org.jnetpcap.protocol.network;

import java.util.EnumSet;
import java.util.Set;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeaderChecksum;
import org.jnetpcap.packet.JHeaderMap;
import org.jnetpcap.packet.JHeaderType;
import org.jnetpcap.packet.JSubHeader;
import org.jnetpcap.packet.annotate.BindingVariable;
import org.jnetpcap.packet.annotate.BindingVariable.MatchType;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.FieldSetter;
import org.jnetpcap.packet.annotate.FlowKey;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.Header.Layer;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.packet.annotate.Protocol;
import org.jnetpcap.packet.annotate.Protocol.Suite;
import org.jnetpcap.packet.annotate.ProtocolSuite;
import org.jnetpcap.util.checksum.Checksum;

@Protocol(suite=Protocol.Suite.NETWORK)
@Header(name="Ip4", nicname="Ip", osi=Header.Layer.NETWORK, suite=ProtocolSuite.NETWORK, spec={"RFC792"}, description="ip version 4")
public class Ip4
  extends JHeaderMap<Ip4>
  implements JHeaderChecksum
{
  public static final int DIFF_CODEPOINT = 252;
  public static final int DIFF_ECE = 1;
  public static final int DIFF_ECT = 2;
  public static final int FLAG_DONT_FRAGMENT = 2;
  public static final int FLAG_MORE_FRAGMENTS = 1;
  public static final int FLAG_RESERVED = 4;
  public static final int ID = 2;
  private int hashcode;
  
  @HeaderLength
  public static int getHeaderLength(JBuffer paramJBuffer, int paramInt)
  {
    return (paramJBuffer.getUByte(paramInt) & 0xF) * 4;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String checksumDescription()
  {
    int i = calculateChecksum();
    if (checksum() == i) {
      return "correct";
    }
    return "incorrect: 0x" + Integer.toHexString(i).toUpperCase();
  }
  
  @Field(offset=80, length=16, format="%x")
  public int checksum()
  {
    return getUShort(10);
  }
  
  @FieldSetter
  public void checksum(int paramInt)
  {
    setUShort(10, paramInt);
  }
  
  @BindingVariable(BindingVariable.MatchType.FUNCTION)
  public boolean checkType(int paramInt)
  {
    return (type() == paramInt) && (offset() == 0);
  }
  
  public void clearFlags(int paramInt)
  {
    int i = getUByte(6);
    i &= (paramInt << 5 ^ 0xFFFFFFFF);
    setUByte(6, i);
  }
  
  protected void decodeHeader()
  {
    this.optionsBitmap = 0L;
    this.hashcode = (id() << 16 ^ sourceToInt() ^ destinationToInt() ^ type());
    int i = hlen() * 4;
    for (int j = 20; j < i; j++)
    {
      int k = getUByte(j) & 0x1F;
      this.optionsOffsets[k] = j;
      this.optionsBitmap |= 1 << k;
      Ip4.IpOption.OptionCode localOptionCode = Ip4.IpOption.OptionCode.valueOf(k);
      if (localOptionCode == null) {
        break;
      }
      switch (1.$SwitchMap$org$jnetpcap$protocol$network$Ip4$IpOption$OptionCode[localOptionCode.ordinal()])
      {
      case 1: 
        this.optionsLength[k] = 1;
        break;
      case 2: 
        this.optionsLength[k] = (i - j);
        j = i;
        break;
      default: 
        int m = getUByte(j + 1);
        j += m;
        this.optionsLength[k] = m;
      }
    }
  }
  
  @Field(offset=128, length=32, format="#ip4#")
  @FlowKey(index=0)
  public byte[] destination()
  {
    return getByteArray(16, 4);
  }
  
  @FieldSetter
  public void destination(byte[] paramArrayOfByte)
  {
    setByteArray(16, paramArrayOfByte);
  }
  
  public byte[] destinationToByteArray(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length != 4) {
      throw new IllegalArgumentException("address must be 4 byte long");
    }
    return getByteArray(16, paramArrayOfByte);
  }
  
  public int destinationToInt()
  {
    return getInt(16);
  }
  
  @Field(offset=48, length=3, format="%x")
  public int flags()
  {
    return getUByte(6) >> 5;
  }
  
  public Set<Flag> flagsEnum()
  {
    EnumSet localEnumSet = EnumSet.noneOf(Flag.class);
    if (flags_DF() > 0) {
      localEnumSet.add(Flag.DF);
    }
    if (flags_MF() > 0) {
      localEnumSet.add(Flag.MF);
    }
    return localEnumSet;
  }
  
  @FieldSetter
  public void flags(int paramInt)
  {
    int i = getUByte(6) & 0x1F;
    i |= paramInt << 5;
    setUByte(6, i);
  }
  
  @Field(parent="flags", offset=2, length=1, display="reserved")
  public int flags_Reserved()
  {
    return (flags() & 0x4) >> 3;
  }
  
  @Field(parent="flags", offset=1, length=1, display="DF: do not fragment")
  public int flags_DF()
  {
    return (flags() & 0x2) >> 1;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String flags_DFDescription()
  {
    return flags_DF() > 0 ? "set" : "not set";
  }
  
  @Field(parent="flags", offset=0, length=1, display="MF: more fragments", nicname="M")
  public int flags_MF()
  {
    return flags() & 0x1;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String flags_MFDescription()
  {
    return flags_MF() > 0 ? "set" : "not set";
  }
  
  public int hashCode()
  {
    return this.hashcode;
  }
  
  @Field(offset=4, length=4, format="%d")
  public int hlen()
  {
    return getUByte(0) & 0xF;
  }
  
  @FieldSetter
  public void hlen(int paramInt)
  {
    int i = getUByte(0) & 0xF0;
    i |= paramInt & 0xF;
    setUByte(0, i);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String hlenDescription()
  {
    String str = "" + hlen() + " * 4 = " + hlen() * 4 + " bytes";
    return str + ", Ip Options Present";
  }
  
  @Field(offset=32, length=16, format="%x")
  public int id()
  {
    return getUShort(4);
  }
  
  @FieldSetter
  public void id(int paramInt)
  {
    setUShort(4, paramInt);
  }
  
  public boolean isFragment()
  {
    return (offset() != 0) || (flags_MF() > 0);
  }
  
  @Field(offset=16, length=16, format="%d")
  public int length()
  {
    return getUShort(2);
  }
  
  @FieldSetter
  public void length(int paramInt)
  {
    setUShort(2, paramInt);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String offsetDescription()
  {
    return "" + offset() + " * 8 = " + offset() * 8 + " bytes";
  }
  
  @Field(offset=51, length=13, format="%d")
  public int offset()
  {
    return getUShort(6) & 0x1FFF;
  }
  
  @FieldSetter
  public void offset(int paramInt)
  {
    int i = getUShort(6) & 0xFFFFE000;
    i |= paramInt & 0x1FFF;
    setUShort(6, i);
  }
  
  @Field(offset=96, length=32, format="#ip4#")
  @FlowKey(index=0)
  public byte[] source()
  {
    return getByteArray(12, 4);
  }
  
  @FieldSetter
  public void source(byte[] paramArrayOfByte)
  {
    setByteArray(12, paramArrayOfByte);
  }
  
  public byte[] sourceToByteArray(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length != 4) {
      throw new IllegalArgumentException("address must be 4 byte long");
    }
    return getByteArray(12, paramArrayOfByte);
  }
  
  public int sourceToInt()
  {
    return getInt(12);
  }
  
  @Field(offset=8, length=8, format="%x", display="diffserv")
  public int tos()
  {
    return getUByte(1);
  }
  
  @FieldSetter
  public void tos(int paramInt)
  {
    setUByte(1, paramInt);
  }
  
  @Field(parent="tos", offset=2, length=6, display="code point")
  public int tos_Codepoint()
  {
    return (tos() & 0xFC) >> 2;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String tos_CodepointDescription()
  {
    return tos_Codepoint() > 0 ? "code point " + tos_Codepoint() : "not set";
  }
  
  @Field(parent="tos", offset=0, length=1, display="ECE bit")
  public int tos_ECE()
  {
    return (tos() & 0x1) >> 0;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String tos_ECEDescription()
  {
    return tos_ECE() > 0 ? "set" : "not set";
  }
  
  @Field(parent="tos", offset=1, length=1, display="ECN bit")
  public int tos_ECN()
  {
    return (tos() & 0x2) >> 1;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String tos_ECNDescription()
  {
    return tos_ECN() > 0 ? "set" : "not set";
  }
  
  @Field(offset=64, length=8, format="%d", description="time to live")
  public int ttl()
  {
    return getUByte(8);
  }
  
  @FieldSetter
  public void ttl(int paramInt)
  {
    setUByte(8, paramInt);
  }
  
  @Field(offset=72, length=8, format="%d")
  @FlowKey(index=1)
  public int type()
  {
    return getUByte(9);
  }
  
  @FieldSetter
  public void type(int paramInt)
  {
    setUByte(9, paramInt);
  }
  
  public void type(Ip4Type paramIp4Type)
  {
    setUByte(9, paramIp4Type.typeValues[0]);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String typeDescription()
  {
    String str = Ip4Type.toString(type());
    return "ip fragment" + (str == null ? "" : new StringBuilder().append(" of ").append(str).append(" PDU").toString());
  }
  
  public Ip4Type typeEnum()
  {
    return Ip4Type.valueOf(type());
  }
  
  @Field(offset=0, length=4, format="%d")
  public int version()
  {
    return getUByte(0) >> 4;
  }
  
  @FieldSetter
  public void version(int paramInt)
  {
    setUByte(0, hlen() | paramInt << 4);
  }
  
  public int calculateChecksum()
  {
    return Checksum.inChecksumShouldBe(checksum(), Checksum.inChecksum(this, 0, size()));
  }
  
  public boolean isChecksumValid()
  {
    return Checksum.inChecksum(this, 0, size()) == 0;
  }
  
  @Header(id=21)
  public static class SelectiveDirectedBroadcastMode
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=20)
  public static class RouterAlert
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String actionDescription()
    {
      return actionEnum().toString();
    }
    
    @Field(offset=16, length=16)
    public int action()
    {
      return super.getUShort(2);
    }
    
    public Action actionEnum()
    {
      return Action.valueOf(action());
    }
    
    public static enum Action
    {
      EXAMINE_PACKET(0);
      
      private final int value;
      
      private Action(int paramInt)
      {
        this.value = paramInt;
      }
      
      public int value()
      {
        return this.value;
      }
      
      public static Action valueOf(int paramInt)
      {
        for (Action localAction : ) {
          if (localAction.value == paramInt) {
            return localAction;
          }
        }
        return null;
      }
    }
  }
  
  @Header(id=19)
  public static class AddressExtension
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=18)
  public static class Traceroute
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=17)
  public static class ExtendedIp
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=16)
  public static class IMITrafficDescriptor
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=15)
  public static class Encode
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=14)
  public static class ExperimentalAccessControl
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=13)
  public static class ExperimentalFlowControl
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=12)
  public static class MtuReply
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=11)
  public static class MtuProbe
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=10)
  public static class ExperimentalMeasurement
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
  }
  
  @Header(id=4)
  public static class Timestamp
    extends Ip4.IpOption
  {
    public static final int FLAG_TIMESTAMP_WITH_IP = 1;
    public static final int FLAG_TIMESTAMPS_PRESPECIFIED = 2;
    public static final int MASK_FLAGS = 15;
    public static final int MASK_OVERFLOW = 240;
    
    @HeaderLength
    public static int headerLength(JBuffer paramJBuffer, int paramInt)
    {
      return paramJBuffer.getUByte(1);
    }
    
    public byte[] address(int paramInt)
    {
      if ((flags() & 0x1) == 0) {
        return null;
      }
      return getByteArray(paramInt * 4 + 4, 4);
    }
    
    @Dynamic(Field.Property.LENGTH)
    public int entriesLength()
    {
      return (length() - 4) * 8;
    }
    
    @Field(offset=32, format="%s")
    public Entry[] entries()
    {
      int i = flags();
      if ((i & 0x1) == 0) {
        return entriesTimestampOnly();
      }
      return entriesWithIp();
    }
    
    private Entry[] entriesTimestampOnly()
    {
      int i = length() - 4;
      Entry[] arrayOfEntry = new Entry[i / 4];
      int j = 4;
      for (int k = 0; j < i; k++)
      {
        Entry localEntry = arrayOfEntry[k] =  = new Entry();
        localEntry.address = getByteArray(j, 4);
        localEntry.timestamp = getUInt(j + 4);
        j += 8;
      }
      return arrayOfEntry;
    }
    
    private Entry[] entriesWithIp()
    {
      int i = length() - 4;
      Entry[] arrayOfEntry = new Entry[i / 4];
      int j = 4;
      for (int k = 0; j < i; k++)
      {
        Entry localEntry = arrayOfEntry[k] =  = new Entry();
        localEntry.timestamp = getUInt(j + 4);
        j += 4;
      }
      return arrayOfEntry;
    }
    
    @Field(offset=28, length=4)
    public int flags()
    {
      return getUByte(3) & 0xF;
    }
    
    @FieldSetter
    public void flags(int paramInt)
    {
      setUByte(3, paramInt & 0xF);
    }
    
    public Set<Flag> flagsEnum()
    {
      EnumSet localEnumSet = EnumSet.noneOf(Flag.class);
      int i = flags();
      if ((i & 0x1) == 1) {
        localEnumSet.add(Flag.TIMESTAMP_WITH_IP);
      }
      if ((i & 0x2) == 2) {
        localEnumSet.add(Flag.TIMESTAMPS_PRESPECIFIED);
      }
      return localEnumSet;
    }
    
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
    
    @Field(offset=16, length=16)
    public int offset()
    {
      return getUByte(2);
    }
    
    @FieldSetter
    public void offset(int paramInt)
    {
      setUByte(2, paramInt);
    }
    
    @Field(offset=24, length=4)
    public int overflow()
    {
      return (getUByte(3) & 0xF0) >> 4;
    }
    
    @FieldSetter
    public void overflow(int paramInt)
    {
      setUByte(3, paramInt << 4 | flags());
    }
    
    public long timestamp(int paramInt)
    {
      if ((flags() & 0x1) == 0) {
        return getUInt(paramInt * 4 + 4);
      }
      return getUInt(paramInt * 4 + 8);
    }
    
    public int timestampsCount()
    {
      if ((flags() & 0x1) == 0) {
        return (length() - 4) / 4;
      }
      return (length() - 4) / 8;
    }
    
    public static enum Flag
    {
      TIMESTAMP_WITH_IP,  TIMESTAMPS_PRESPECIFIED;
      
      private Flag() {}
    }
    
    public static class Entry
    {
      public byte[] address;
      public long timestamp;
    }
  }
  
  @Header(id=9)
  public static class StrictSourceRoute
    extends Ip4.Routing
  {}
  
  @Header(id=8)
  public static class StreamId
    extends Ip4.IpOption
  {
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
    
    @Field(offset=16, length=16, format="%x")
    public int streamId()
    {
      return getUShort(2);
    }
    
    @FieldSetter
    public void streamId(int paramInt)
    {
      setUShort(2, paramInt);
    }
  }
  
  @Header(id=2)
  public static class Security
    extends Ip4.IpOption
  {
    @Field(offset=32, length=16)
    public int compartments()
    {
      return getUShort(4);
    }
    
    @FieldSetter
    public void compartments(int paramInt)
    {
      setUShort(4, paramInt);
    }
    
    @Field(offset=64, length=24)
    public int control()
    {
      return getUShort(8) << 8 | getUByte(10);
    }
    
    @FieldSetter
    public void control(int paramInt)
    {
      throw new UnsupportedOperationException("Not implemented yet");
    }
    
    @Field(offset=48, length=16)
    public int handling()
    {
      return getUShort(6);
    }
    
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
    
    @Field(offset=16, length=16)
    public int security()
    {
      return getUShort(2);
    }
    
    @FieldSetter
    public void security(int paramInt)
    {
      setUShort(2, paramInt);
    }
    
    public void security(SecurityType paramSecurityType)
    {
      security(paramSecurityType.type);
    }
    
    public SecurityType securityEnum()
    {
      return SecurityType.valueOf(security());
    }
    
    public static enum SecurityType
    {
      CONFIDENTIAL(61749),  EFTO(30874),  MMMM(48205),  PROG(24102),  RESTRICTED(44819),  SECRET(55176),  UNCLASSIFIED(0);
      
      private final int type;
      
      public static SecurityType valueOf(int paramInt)
      {
        for (SecurityType localSecurityType : ) {
          if (localSecurityType.getType() == paramInt) {
            return localSecurityType;
          }
        }
        return null;
      }
      
      private SecurityType(int paramInt)
      {
        this.type = paramInt;
      }
      
      public final int getType()
      {
        return this.type;
      }
    }
  }
  
  public static abstract class Routing
    extends Ip4.IpOption
  {
    @FieldSetter
    public void address(byte[][] paramArrayOfByte)
    {
      for (int i = 0; i < paramArrayOfByte.length; i++) {
        address(i, paramArrayOfByte[i]);
      }
    }
    
    public byte[] address(int paramInt)
    {
      return getByteArray(paramInt * 4 + 3, 4);
    }
    
    public void address(int paramInt, byte[] paramArrayOfByte)
    {
      setByteArray(paramInt * 4 + 3, paramArrayOfByte);
    }
    
    @Field(offset=24, length=0, format="#ip4[]#")
    public byte[][] addressArray()
    {
      byte[][] arrayOfByte = new byte[addressCount()][];
      for (int i = 0; i < addressCount(); i++) {
        arrayOfByte[i] = address(i);
      }
      return arrayOfByte;
    }
    
    public int addressCount()
    {
      return (length() - 3) / 4;
    }
    
    @Field(offset=8, length=8)
    public int length()
    {
      return getUByte(1);
    }
    
    @FieldSetter
    public void length(int paramInt)
    {
      setUByte(1, paramInt);
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String lengthDescription()
    {
      return "(" + length() + " - 3)/" + 4 + " = " + addressCount() + " routes";
    }
    
    @Field(offset=16, length=8)
    public int offset()
    {
      return getUByte(2);
    }
    
    @FieldSetter
    public void offset(int paramInt)
    {
      setUByte(2, paramInt);
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String offsetDescription()
    {
      return "offset points at route #" + (offset() / 4 - 1) + "";
    }
  }
  
  @Header(id=7)
  public static class RecordRoute
    extends Ip4.Routing
  {}
  
  @Header(id=1)
  public static class NoOp
    extends Ip4.IpOption
  {}
  
  @Header(id=3)
  public static class LooseSourceRoute
    extends Ip4.Routing
  {}
  
  public static abstract class IpOption
    extends JSubHeader<Ip4>
  {
    @HeaderLength
    public static int headerLength(JBuffer paramJBuffer, int paramInt)
    {
      return paramJBuffer.getUByte(1);
    }
    
    @Field(offset=0, length=8, format="%d")
    public int code()
    {
      return getUByte(0);
    }
    
    @FieldSetter
    public void code(int paramInt)
    {
      setUByte(0, code() & 0xE0 | paramInt & 0x1F);
    }
    
    @Field(parent="code", offset=7, length=1, display="copy", format="%d")
    public int code_Copy()
    {
      return (code() & 0x80) >> 7;
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String code_CopyDescription()
    {
      return code_Copy() > 0 ? "copy to all fragments" : "do not copy to fragments";
    }
    
    @Field(parent="code", offset=5, length=2, display="class", format="%d")
    public int code_Class()
    {
      return (code() & 0x60) >> 5;
    }
    
    public CodeClass code_ClassEnum()
    {
      return CodeClass.valueOf(code_Class());
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String code_ClassDescription()
    {
      return code_ClassEnum().toString();
    }
    
    @Field(parent="code", offset=0, length=5, display="type", format="%d")
    public int code_Type()
    {
      return code() & 0x1F;
    }
    
    @Dynamic(Field.Property.DESCRIPTION)
    public String code_TypeDescription()
    {
      return OptionCode.valueOf(code() & 0x1F).toString();
    }
    
    public OptionCode codeEnum()
    {
      return OptionCode.values()[(getUByte(0) & 0x1F)];
    }
    
    public void optionCode(OptionCode paramOptionCode)
    {
      code(paramOptionCode.ordinal());
    }
    
    public static enum CodeClass
    {
      CONTROL(0),  RESERVED1(1),  DEBUG(2),  RESERVED2(3);
      
      private final int cl;
      
      private CodeClass(int paramInt)
      {
        this.cl = paramInt;
      }
      
      public static CodeClass valueOf(int paramInt)
      {
        for (CodeClass localCodeClass : ) {
          if (paramInt == localCodeClass.cl) {
            return localCodeClass;
          }
        }
        return null;
      }
    }
    
    public static enum OptionCode
    {
      END_OF_OPTION_LIST(0),  LOOSE_SOURCE_ROUTE(3),  NO_OP(1),  RECORD_ROUTE(7),  SECURITY(2),  STREAM_ID(8),  STRICT_SOURCE_ROUTE(9),  TIMESTAMP(4),  UNASSIGNED1(5),  UNASSIGNED2(6),  EXPERIMENTAL_MEASUREMENT(10),  MTU_PROBE(11),  MTU_REPLY(12),  EXPERIMENTAL_FLOW_CONTROL(13),  EXPERIMENTAL_ACCESS_CONTROL(14),  ENCODE(15),  IMI_TRAFFIC_DESCRIPTOR(16),  EXTENDED_IP(17),  TRACEROUTE(18),  ADDRESS_EXTENSION(19),  ROUTER_ALERT(20),  SELECTIVE_DIRECTED_BROADCAST_MOST(21),  DYNAMIC_PACKET_STATE(23),  UPSTREAM_MULTICAST_PACKET(24),  QUICK_START(25);
      
      public final int id;
      
      private OptionCode(int paramInt)
      {
        this.id = paramInt;
      }
      
      public static OptionCode valueOf(int paramInt)
      {
        for (OptionCode localOptionCode : ) {
          if (localOptionCode.id == paramInt) {
            return localOptionCode;
          }
        }
        return null;
      }
    }
  }
  
  public static enum Ip4Type
    implements JHeaderType
  {
    HOPORT("IPv6 Hop-by-Hop Option", new int[] { 0 }),  ICMP("Internet Control Message", new int[] { 1 }),  IGMP("Internet Group Management", new int[] { 2 }),  GGP("Gateway-to-Gateway", new int[] { 3 }),  IP("IP in IP (encapsulation)", new int[] { 4 }),  ST("Stream", new int[] { 5 }),  TCP("Transmission Control", new int[] { 6 }),  CBT("CBT", new int[] { 7 }),  EGP("Exterior Gateway Protocol", new int[] { 8 }),  IGP("any private interior gateway", new int[] { 9 }),  BBN_RCC_MON("BBN RCC Monitoring", new int[] { 10 }),  NVP_II("Network Voice Protocol", new int[] { 11 }),  PUP("PUP", new int[] { 12 }),  ARGUS("ARGUS", new int[] { 13 }),  EMCON("EMCON", new int[] { 14 }),  XNET("Cross Net Debugger", new int[] { 15 }),  CHAOS("Chaos", new int[] { 16 }),  UDP("User Datagram", new int[] { 17 }),  MUX("Multiplexing", new int[] { 18 }),  DCN_MEAS("DCN Measurement Subsystems", new int[] { 19 }),  HMP("Host Monitoring", new int[] { 20 }),  PRM("Packet Radio Measurement", new int[] { 21 }),  XNS_IDP("XEROX NS IDP", new int[] { 22 }),  TRUNK_1("Trunk-1", new int[] { 23 }),  TRUNK_2("Trunk-2", new int[] { 24 }),  LEAF_1("Leaf-1", new int[] { 25 }),  LEAF_2("Leaf-2", new int[] { 26 }),  RDP("Reliable Data Protocol", new int[] { 27 }),  IRTP("Internet Reliable Transaction", new int[] { 28 }),  ISO_TP4("ISO Transport Protocol Class 4", new int[] { 29 }),  NETBLT("Bulk Data Transfer Protocol", new int[] { 30 }),  MFE_NSP("MFE Network Services Protocol", new int[] { 31 }),  MERIT_INP("MERIT Internodal Protocol", new int[] { 32 }),  DCCP("Datagram Congestion Control Protocol", new int[] { 33 }),  THIRD_PC("Third Party Connect Protocol", new int[] { 34 }),  IDPR("Inter-Domain Policy Routing Protocol", new int[] { 35 }),  XTP("XTP", new int[] { 36 }),  DDP("Datagram Delivery Protocol", new int[] { 37 }),  IDPR_CMTP("IDPR Control Message Transport Proto", new int[] { 38 }),  TP_PLUS("TP++ Transport Protocol", new int[] { 39 }),  IL("IL Transport Protocol", new int[] { 40 }),  IPv6("Ipv6", new int[] { 41 }),  SDRP("Source Demand Routing Protocol", new int[] { 42 }),  IPv6_ROUTE("Ipv6", new int[] { 43 }),  IPv6_FRAG("Fragment Header for IPv6", new int[] { 44 }),  IDRP("Inter-Domain Routing Protocol", new int[] { 45 }),  RSVP("Reservation Protocol", new int[] { 46 }),  GRE("General Routing Encapsulation", new int[] { 47 }),  DSR("Dynamic Source Routing Protocol", new int[] { 48 }),  BNA("BNA", new int[] { 49 }),  ESP("Encap Security Payload", new int[] { 50 }),  AH("Authentication Header", new int[] { 51 }),  I_NLSP("Integrated Net Layer Security  TUBA", new int[] { 52 }),  SWIPE("IP with Encryption", new int[] { 53 }),  NARP("NBMA Address Resolution Protocol", new int[] { 54 }),  MOBILE("IP Mobility", new int[] { 55 }),  TLSP("Transport Layer Security Protocol", new int[] { 56 }),  SKIP("SKIP", new int[] { 57 }),  IPv6_ICMP("ICMP for IPv6", new int[] { 58 }),  IPv6_NoNxt("No Next Header for IPv6", new int[] { 59 }),  IPv6_Opts("Destination Options for IPv6", new int[] { 60 }),  ANY_LOC("any host internal protocol", new int[] { 61 }),  IPIP("IP-within-IP Encapsulation Protocol", new int[] { 94 }),  PIM("Protocol Independent Multicast", new int[] { 103 }),  IPX_In_IP("IPX in IP", new int[] { 111 }),  STP("Schedule Transfer Protocol", new int[] { 118 }),  FC("Fibre Channel", new int[] { 133 }),  MPLS_in_IP("MPLS-in-IP", new int[] { 137 });
    
    private final String description;
    private final int[] typeValues;
    
    public static String toString(int paramInt)
    {
      for (Ip4Type localIp4Type : ) {
        for (int n : localIp4Type.typeValues) {
          if (n == paramInt) {
            return localIp4Type.description;
          }
        }
      }
      return Integer.toString(paramInt);
    }
    
    public static Ip4Type valueOf(int paramInt)
    {
      for (Ip4Type localIp4Type : ) {
        for (int n : localIp4Type.typeValues) {
          if (n == paramInt) {
            return localIp4Type;
          }
        }
      }
      return null;
    }
    
    private Ip4Type(int... paramVarArgs)
    {
      this.typeValues = paramVarArgs;
      this.description = name().toLowerCase();
    }
    
    private Ip4Type(String paramString, int... paramVarArgs)
    {
      this.typeValues = paramVarArgs;
      this.description = paramString;
    }
    
    public final String getDescription()
    {
      return this.description;
    }
    
    public final int[] getTypeValues()
    {
      return this.typeValues;
    }
  }
  
  public static enum Flag
  {
    DF,  MF;
    
    private Flag() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Ip4
 * JD-Core Version:    0.7.0.1
 */