package org.jnetpcap.protocol.network;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.annotate.Bind;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.packet.annotate.ProtocolSuite;
import org.jnetpcap.protocol.tcpip.Udp;

@Header(suite=ProtocolSuite.TCP_IP, description="Routing Information Protocol")
public abstract class Rip
  extends JHeader
{
  protected int count;
  
  @Bind(to=Udp.class)
  public static boolean bindToUdp(JPacket paramJPacket, Udp paramUdp)
  {
    return (paramUdp.destination() == 520) || (paramUdp.source() == 520);
  }
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    return paramJBuffer.size() - paramInt;
  }
  
  @Field(offset=0, length=8)
  public int command()
  {
    return super.getUByte(0);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String commandDescription()
  {
    return commandEnum().toString();
  }
  
  public Command commandEnum()
  {
    return Command.valueOf(command());
  }
  
  public int count()
  {
    return this.count;
  }
  
  protected void decodeHeader()
  {
    this.count = ((size() - 4) / 20);
  }
  
  @Field(offset=8, length=8)
  public int version()
  {
    return super.getUByte(1);
  }
  
  public static enum Command
  {
    REQUEST,  REPLY,  TRACE_ON,  TRACE_OFF,  SUN,  TRIGGERED_REQUEST,  TRIGGERED_RESPONSE,  TRIGGERED_ACK,  UPDATE_REQUEST,  UPDATE_RESPONSE,  UPDATE_ACK;
    
    private Command() {}
    
    public static Command valueOf(int paramInt)
    {
      return paramInt < values().length ? values()[paramInt] : null;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Rip
 * JD-Core Version:    0.7.0.1
 */