package org.jnetpcap.protocol.network;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;

@Header
public class Arp
  extends JHeader
{
  private int shaOffset;
  private int spaOffset;
  private int thaOffset;
  private int tpaOffset;
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    int i = paramJBuffer.getUByte(paramInt + 4);
    int j = paramJBuffer.getUByte(paramInt + 5);
    return (i + j) * 2 + 8;
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String hardwareTypeDescription()
  {
    return hardwareTypeEnum().toString();
  }
  
  @Field(offset=0, length=16)
  public int hardwareType()
  {
    return super.getUShort(0);
  }
  
  public HardwareType hardwareTypeEnum()
  {
    return HardwareType.valueOf(hardwareType());
  }
  
  @Field(offset=16, format="%x", length=16)
  public int protocolType()
  {
    return super.getUShort(2);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String protocolTypeDescription()
  {
    return protocolTypeEnum().toString();
  }
  
  public ProtocolType protocolTypeEnum()
  {
    return ProtocolType.valueOf(protocolType());
  }
  
  @Field(offset=32, length=8, units="bytes", display="hardware size")
  public int hlen()
  {
    return super.getUByte(4);
  }
  
  @Field(offset=40, length=8, units="bytes", display="protocol size")
  public int plen()
  {
    return super.getUByte(5);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  public String operationDescription()
  {
    return operationEnum().toString();
  }
  
  @Field(offset=48, length=16, display="op code")
  public int operation()
  {
    return super.getUShort(6);
  }
  
  public OpCode operationEnum()
  {
    return OpCode.valueOf(operation());
  }
  
  @Field(offset=64, format="#mac#", display="sender MAC")
  public byte[] sha()
  {
    return super.getByteArray(this.shaOffset, hlen());
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int shaLength()
  {
    return hlen() * 8;
  }
  
  @Field(format="#ip4#", display="sender IP")
  public byte[] spa()
  {
    return super.getByteArray(this.spaOffset, plen());
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int spaOffset()
  {
    return this.spaOffset * 8;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int spaLength()
  {
    return plen() * 8;
  }
  
  @Field(format="#mac#", display="target MAC")
  public byte[] tha()
  {
    return super.getByteArray(this.thaOffset, hlen());
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int thaOffset()
  {
    return this.thaOffset * 8;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int thaLength()
  {
    return hlen() * 8;
  }
  
  @Field(format="#ip4#", display="target IP")
  public byte[] tpa()
  {
    return super.getByteArray(this.tpaOffset, plen());
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int tpaOffset()
  {
    return this.tpaOffset * 8;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int tpaLength()
  {
    return plen() * 8;
  }
  
  protected void decodeHeader()
  {
    int i = hlen();
    int j = plen();
    this.shaOffset = 8;
    this.spaOffset = (this.shaOffset + i);
    this.thaOffset = (this.spaOffset + j);
    this.tpaOffset = (this.thaOffset + i);
  }
  
  public static enum OpCode
  {
    RESERVED1,  REQUEST,  REPLY,  REQUEST_REVERSE,  REPLY_REVERSE,  DRARP_REQUEST,  DRARP_REPLY,  DRARP_ERROR,  IN_ARP_REQUEST,  IN_ARP_REPLY,  ARP_NAK,  MARS_REQUEST,  MARS_MULTI,  MARS_MSERV,  MARS_JOIN,  MARS_LEAVE,  MARS_NAK,  MARS_UNSERV,  MARS_SJOIN,  MARS_SLEAVE,  MARS_GROUP_LIST_REQUEST,  MARS_GROUP_LIST_REPLAY,  MARS_REDIRECT_MAP,  MAPOS_UNARP,  OP_EXP1,  OP_EXP2;
    
    private OpCode() {}
    
    public static OpCode valueOf(int paramInt)
    {
      return values()[paramInt];
    }
  }
  
  public static enum ProtocolType
  {
    IP(2048);
    
    private final int value;
    
    private ProtocolType(int paramInt)
    {
      this.value = paramInt;
    }
    
    public static ProtocolType valueOf(int paramInt)
    {
      if (paramInt == 2048) {
        return IP;
      }
      return null;
    }
  }
  
  public static enum HardwareType
  {
    RESERVED1,  ETHERNET,  EXSPERIMENTAL_ETHERNET,  AMATEUR_RADIO_AX_25,  PROTEON_PRO_NET_TOKEN_RING,  CHAOS,  IEEE802,  ARCNET,  HYPERCHANNEL,  LANSTAR,  AUTONET_SHORT_ADDRESS,  LOCAL_TALK,  LOCAL_NET,  ULTRA_LINK,  SMDS,  FRAME_RELAY,  ATM1,  SERIAL_LINE,  ATM2,  MIL_STD_188_220,  METRICOM,  IEEE1395,  MAPOS,  TWINAXIAL,  EUI64,  HIPARP,  ISO7816_3,  ARPSEC,  IPSEC_TUNNEL,  INFINIBAND,  CAI,  WIEGAND_INTERFACE,  PURE_ID,  HW_EXP1;
    
    private HardwareType() {}
    
    public static HardwareType valueOf(int paramInt)
    {
      return values()[paramInt];
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Arp
 * JD-Core Version:    0.7.0.1
 */