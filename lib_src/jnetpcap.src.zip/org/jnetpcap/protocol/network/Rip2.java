package org.jnetpcap.protocol.network;

import org.jnetpcap.packet.annotate.Field;

public abstract class Rip2
  extends Rip1
{
  private EntryV2[] routingTable;
  
  @Field(offset=32)
  public EntryV2[] routingTable()
  {
    if (this.routingTable == null) {
      decodeRoutingTable();
    }
    return this.routingTable;
  }
  
  private void decodeRoutingTable()
  {
    this.routingTable = new EntryV2[this.count];
    for (int i = 0; i < this.count; i++)
    {
      EntryV2 localEntryV2 = new EntryV2();
      this.routingTable[i] = localEntryV2;
      localEntryV2.peer(this, 4 + i * 20, 20);
    }
  }
  
  public static class EntryV2
    extends Rip1.EntryV1
  {
    @Field(offset=16, length=16)
    public int tag()
    {
      return super.getUShort(2);
    }
    
    @Field(offset=64, length=32)
    public byte[] subnet()
    {
      return super.getByteArray(8, 4);
    }
    
    @Field(offset=96, length=32)
    public byte[] nextHop()
    {
      return super.getByteArray(12, 4);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Rip2
 * JD-Core Version:    0.7.0.1
 */