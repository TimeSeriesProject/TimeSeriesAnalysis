package org.jnetpcap.protocol.network;

import org.jnetpcap.packet.JSubHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;

public class Rip1
  extends Rip
{
  private EntryV1[] routingTable;
  
  protected void decodeHeader()
  {
    super.decodeHeader();
    this.routingTable = null;
  }
  
  private void decodeRoutingTable()
  {
    this.routingTable = new EntryV1[this.count];
    for (int i = 0; i < this.count; i++)
    {
      EntryV1 localEntryV1 = new EntryV1();
      this.routingTable[i] = localEntryV1;
      localEntryV1.peer(this, 4 + i * 20, 20);
    }
  }
  
  @Field(offset=32, format="%RIP")
  public EntryV1[] routingTable()
  {
    if (this.routingTable == null) {
      decodeRoutingTable();
    }
    return this.routingTable;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int routingTableLength()
  {
    return this.count * 20 * 8;
  }
  
  @Header
  public static class EntryV1
    extends JSubHeader<Rip1>
  {
    @Field(offset=32, length=32)
    public byte[] address()
    {
      return super.getByteArray(4, 4);
    }
    
    @Field(offset=0, length=16)
    public int family()
    {
      return super.getUShort(0);
    }
    
    @Field(offset=128, length=32)
    public int metric()
    {
      return super.getInt(16);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Rip1
 * JD-Core Version:    0.7.0.1
 */