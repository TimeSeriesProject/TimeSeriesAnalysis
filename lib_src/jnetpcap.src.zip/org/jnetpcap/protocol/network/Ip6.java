package org.jnetpcap.protocol.network;

import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.FlowKey;
import org.jnetpcap.packet.annotate.Header;

@Header(length=40)
public class Ip6
  extends JHeader
{
  public static final int ID = 3;
  
  @Field(offset=0, length=4)
  public int version()
  {
    return getUByte(0) >> 4;
  }
  
  @Field(offset=4, length=8)
  public int trafficClass()
  {
    return getUShort(0) & 0xFFF;
  }
  
  @Field(offset=12, length=20)
  public int flowLabel()
  {
    return getInt(0) & 0xFFFFF;
  }
  
  @Field(offset=32, length=16)
  public int length()
  {
    return getUShort(4);
  }
  
  @Field(offset=48, length=8)
  @FlowKey(index=1)
  public int next()
  {
    return getUByte(6);
  }
  
  @Field(offset=56, length=8)
  public int hopLimit()
  {
    return getUByte(7);
  }
  
  @Field(offset=64, length=128, format="#ip6#")
  @FlowKey(index=0)
  public byte[] source()
  {
    return getByteArray(8, 16);
  }
  
  public byte[] sourceToByteArray(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length != 16) {
      throw new IllegalArgumentException("address must be 16 byte long");
    }
    return getByteArray(8, paramArrayOfByte);
  }
  
  @Field(offset=64, length=128, format="#ip6#")
  @FlowKey(index=0)
  public byte[] destination()
  {
    return getByteArray(24, 16);
  }
  
  public byte[] destinationToByteArray(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length != 16) {
      throw new IllegalArgumentException("address must be 16 byte long");
    }
    return getByteArray(24, paramArrayOfByte);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.network.Ip6
 * JD-Core Version:    0.7.0.1
 */