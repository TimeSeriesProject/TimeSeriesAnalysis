package org.jnetpcap.protocol.vpn;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;

@Header
public class L2TP
  extends JHeader
{
  public static final int FLAG_L = 16384;
  public static final int FLAG_O = 512;
  public static final int FLAG_P = 256;
  public static final int FLAG_S = 2048;
  public static final int FLAG_T = 32768;
  public static final int ID = 10;
  public static final int MASK_VERSION = 14;
  public static final int MASK_FLAGS = 65521;
  private int offId;
  private int offLength;
  private int offOffset;
  private int offSequence;
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    int i = paramJBuffer.getUShort(0);
    int j = 6;
    if ((i & 0x4000) != 0) {
      j += 2;
    }
    if ((i & 0x800) != 0) {
      j += 4;
    }
    if ((i & 0x200) != 0) {
      j += 4;
    }
    return j;
  }
  
  public void decodeHeader()
  {
    int i = flags();
    int j = 2;
    if (isSet(i, 16384))
    {
      this.offLength = 2;
      j += 2;
    }
    else
    {
      this.offLength = 0;
    }
    this.offId = j;
    j += 4;
    if (isSet(i, 2048))
    {
      this.offSequence = j;
      j += 4;
    }
    else
    {
      this.offSequence = 0;
    }
    if (isSet(i, 512))
    {
      this.offOffset = j;
      j += 4;
    }
    else
    {
      this.offOffset = 0;
    }
  }
  
  @Field(offset=0, length=12, format="%x")
  public int flags()
  {
    return getUShort(0) & 0xFFF1;
  }
  
  @Dynamic(Field.Property.CHECK)
  public boolean hasLength()
  {
    return isSet(flags(), 16384);
  }
  
  @Dynamic(Field.Property.CHECK)
  public boolean hasN()
  {
    return isSet(flags(), 2048);
  }
  
  @Dynamic(Field.Property.CHECK)
  public boolean hasOffset()
  {
    return isSet(flags(), 512);
  }
  
  private boolean isSet(int paramInt1, int paramInt2)
  {
    return (paramInt1 & paramInt2) != 0;
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int lengthOffset()
  {
    return this.offLength * 8;
  }
  
  @Field(length=16)
  public int length()
  {
    return getUShort(this.offLength);
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int nrOffset()
  {
    return (this.offSequence + 2) * 8;
  }
  
  @Field(length=16)
  public int nr()
  {
    return getUShort(this.offSequence + 2);
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int nsOffset()
  {
    return this.offSequence * 8;
  }
  
  @Field(length=16)
  public int ns()
  {
    return getUShort(this.offSequence);
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int offsetOffset()
  {
    return this.offOffset * 8;
  }
  
  @Field(length=16)
  public int offset()
  {
    return getUShort(this.offOffset);
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int padOffset()
  {
    return (this.offLength + 2) * 8;
  }
  
  @Field(length=16)
  public int pad()
  {
    return getUShort(this.offOffset + 2);
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int sessionIdOffset()
  {
    return this.offId * 2 * 8;
  }
  
  @Field(length=16)
  public int sessionId()
  {
    return getUShort(this.offId + 2);
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int tunnelIdOffset()
  {
    return this.offId * 8;
  }
  
  @Field(length=16)
  public int tunnelId()
  {
    return getUShort(this.offId);
  }
  
  @Field(offset=13, length=3)
  public int version()
  {
    return getUShort(0) & 0xE;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.vpn.L2TP
 * JD-Core Version:    0.7.0.1
 */