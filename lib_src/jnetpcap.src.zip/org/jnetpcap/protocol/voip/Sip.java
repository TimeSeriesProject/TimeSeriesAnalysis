package org.jnetpcap.protocol.voip;

import org.jnetpcap.packet.AbstractMessageHeader;
import org.jnetpcap.packet.AbstractMessageHeader.MessageType;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Header;

@Header
public class Sip
  extends AbstractMessageHeader
{
  public static int ID = 17;
  
  public int contentLength()
  {
    if (hasField(Fields.Content_Length)) {
      return Integer.parseInt((String)super.fieldValue(String.class, Fields.Content_Length));
    }
    return 0;
  }
  
  public String contentType()
  {
    return fieldValue(Fields.Content_Type);
  }
  
  public ContentType contentTypeEnum()
  {
    return ContentType.parseContentType(contentType());
  }
  
  protected void decodeFirstLine(String paramString)
  {
    String[] arrayOfString = paramString.split(" ");
    if (arrayOfString.length < 3) {
      return;
    }
    if (arrayOfString[0].startsWith("SIP"))
    {
      super.setMessageType(AbstractMessageHeader.MessageType.RESPONSE);
      super.addField(Response.RequestVersion, arrayOfString[0], paramString.indexOf(arrayOfString[0]));
      super.addField(Response.ResponseCode, arrayOfString[1], paramString.indexOf(arrayOfString[1]));
      super.addField(Response.ResponseCodeMsg, arrayOfString[2], paramString.indexOf(arrayOfString[2]));
    }
    else
    {
      super.setMessageType(AbstractMessageHeader.MessageType.REQUEST);
      super.addField(Request.RequestMethod, arrayOfString[0], paramString.indexOf(arrayOfString[0]));
      super.addField(Request.RequestUrl, arrayOfString[1], paramString.indexOf(arrayOfString[1]));
      super.addField(Request.RequestVersion, arrayOfString[2], paramString.indexOf(arrayOfString[2]));
    }
  }
  
  public String fieldValue(Fields paramFields)
  {
    return (String)super.fieldValue(String.class, paramFields);
  }
  
  public String fieldValue(Request paramRequest)
  {
    return (String)super.fieldValue(String.class, paramRequest);
  }
  
  public String fieldValue(Response paramResponse)
  {
    return (String)super.fieldValue(String.class, paramResponse);
  }
  
  public boolean hasContent()
  {
    return (hasField(Fields.Content_Type)) || (hasField(Fields.Content_Type));
  }
  
  public boolean hasContentType()
  {
    return hasField(Fields.Content_Type);
  }
  
  public boolean hasField(Fields paramFields)
  {
    return super.hasField(paramFields);
  }
  
  public String header()
  {
    return this.rawHeader;
  }
  
  public boolean isResponse()
  {
    return getMessageType() == AbstractMessageHeader.MessageType.RESPONSE;
  }
  
  @Field
  public static enum Response
  {
    RequestUrl,  RequestVersion,  ResponseCode,  ResponseCodeMsg;
    
    private Response() {}
  }
  
  @Field
  public static enum Request
  {
    RequestMethod,  RequestUrl,  RequestVersion,  User_Agent;
    
    private Request() {}
  }
  
  @Field
  public static enum Fields
  {
    Accept,  Accept_Encoding,  Accept_Language,  Alert_Info,  Allow,  Authentication_Info,  Authorization,  Call_ID,  Call_Info,  Contact,  Content_Disposition,  Content_Encoding,  Content_Language,  Content_Length,  Content_Type,  CSeq,  Date,  Error_Info,  Expires,  From,  In_Reply_To,  Max_Forwards,  MIME_Version,  Min_Expires,  Organization,  Priority,  Proxy_Authenticate,  Proxy_Authorization,  Proxy_Require,  Record_Route,  Reply_To,  Require,  Retry_After,  Route,  Server,  Subject,  Supported,  Timestamp,  To,  Unsupported,  User_Agent,  Via,  Warning,  WWW_Authenticate;
    
    private Fields() {}
  }
  
  public static enum ContentType
  {
    OTHER(new String[0]),  PKCS7_MIME(new String[] { "application/pkcs7-mime" }),  PKCS7_SIGNATURE(new String[] { "application/pkcs7-signature" }),  SPD(new String[] { "application/SPD" });
    
    private final String[] magic;
    
    public static ContentType parseContentType(String paramString)
    {
      if (paramString == null) {
        return OTHER;
      }
      for (ContentType localContentType : values())
      {
        if (localContentType.name().equalsIgnoreCase(paramString)) {
          return localContentType;
        }
        for (String str : localContentType.magic) {
          if (paramString.startsWith(str)) {
            return localContentType;
          }
        }
      }
      return OTHER;
    }
    
    private ContentType(String... paramVarArgs)
    {
      this.magic = paramVarArgs;
    }
  }
  
  public static enum Code
  {
    Address_Incomplete(484, "Address Incomplete"),  Alternative_Service(380, "Alternative Service"),  Ambiguous(485, "Ambiguous"),  Bad_Extension(420, "Bad Extension"),  Bad_Gateway(502, "Bad Gateway"),  Bad_Request(400, "Bad Request"),  Busy_Everywhere(600, "Busy Everywhere"),  Busy_Here(486, "Busy Here"),  Call_Leg_Transaction_Does_Not_Exist(481, "Call Leg/Transaction Does Not Exist"),  Decline(603, "Decline"),  Does_not_exist_anywhere(604, "Does not exist anywhere"),  Extension_Required(421, "Extension Required"),  Forbidden(403, "Forbidden"),  Gone(410, "Gone"),  Internal_Server_Error(500, "Internal Server Error"),  Interval_Too_Brief(423, "Interval Too Brief"),  Loop_Detected(482, "Loop Detected"),  Message_Too_Large(513, "Message Too Large"),  Method_Not_Allowed(405, "Method Not Allowed"),  Moved_Permanently(301, "Moved Permanently"),  Moved_Temporarily(302, "Moved Temporarily"),  MULTIPLE_CHOICES(300, "Multiple Choices"),  Not_Acceptable_Here(488, "Not Acceptable Here"),  Not_Acceptable400(406, "Not Acceptable"),  Not_Acceptable600(606, "Not Acceptable"),  Not_Found(404, "Not Found"),  Not_Implemented(501, "Not Implemented"),  OK(200, "OK"),  Payment_Required(402, "Payment Required"),  Proxy_Authentication_Required(407, "Proxy Authentication Required"),  Request_Entity_Too_Large(413, "Request Entity Too Large"),  Request_Pending(491, "Request Pending"),  Request_Terminated(487, "Request Terminated"),  Request_Timeout(408, "Request Timeout"),  Request_URI_Too_Large(414, "Request-URI Too Large"),  Server_Time_out(504, "Server Time-out"),  Service_Unavailable(503, "Service Unavailable"),  SIP_Version_not_supported(505, "SIP Version not supported"),  Temporarily_not_available(480, "Temporarily not available"),  Too_Many_Hops(483, "Too Many Hops"),  Unauthorized(401, "Unauthorized"),  Undecipherable(493, "Undecipherable"),  Unsupported_Media_Type(415, "Unsupported Media Type"),  Unsupported_URI_Scheme(416, "Unsupported URI Scheme"),  Use_Proxy(305, "Use Proxy");
    
    private final int code;
    private final String description;
    
    private Code(int paramInt, String paramString)
    {
      this.code = paramInt;
      this.description = paramString;
    }
    
    public final int getCode()
    {
      return this.code;
    }
    
    public final String getDescription()
    {
      return this.description;
    }
    
    public Code valueOf(int paramInt)
    {
      for (Code localCode : ) {
        if (localCode.code == paramInt) {
          return localCode;
        }
      }
      return null;
    }
    
    public Code valueOfUsingCode(String paramString)
    {
      return valueOf(Integer.parseInt(paramString));
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.voip.Sip
 * JD-Core Version:    0.7.0.1
 */