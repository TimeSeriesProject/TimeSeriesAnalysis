package org.jnetpcap.protocol.voip;

import java.util.ArrayList;
import java.util.List;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JMappedHeader;
import org.jnetpcap.packet.JRegistry;
import org.jnetpcap.packet.RegistryHeaderErrors;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;

@Header
public class Sdp
  extends JMappedHeader
{
  public static int ID = 18;
  private String[] attributes;
  private int attributesLength;
  private int attributesOffset;
  private String text;
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    return paramJBuffer.size() - paramInt;
  }
  
  @Field(offset=0, length=10, format="%s[]")
  public String[] attributes()
  {
    return this.attributes;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int attributesLength()
  {
    return this.attributesLength;
  }
  
  @Dynamic(Field.Property.OFFSET)
  public int attributesOffset()
  {
    return this.attributesOffset;
  }
  
  protected void decodeHeader()
  {
    this.text = super.getUTF8String(0, size());
    String[] arrayOfString1 = this.text.split("\r\n");
    ArrayList localArrayList = new ArrayList(10);
    int i = 0;
    for (String str : arrayOfString1)
    {
      int m = str.charAt(0);
      str = str.substring(2).trim();
      int n = str.length() * 8;
      switch (m)
      {
      case 118: 
        super.addField(Fields.Version, str, i, n);
        break;
      case 111: 
        super.addField(Fields.Owner, str, i, n);
        break;
      case 115: 
        super.addField(Fields.SessionName, str, i, n);
        break;
      case 99: 
        super.addField(Fields.ConnectionInfo, str, i, n);
        break;
      case 116: 
        super.addField(Fields.Time, str, i, n);
        break;
      case 109: 
        super.addField(Fields.Media, str, i, n);
        break;
      case 97: 
        localArrayList.add(str);
      }
      i += (str.length() + 2) * 8;
    }
    this.attributesOffset = i;
    this.attributesLength = ((size() - i / 8) * 8);
    this.attributes = ((String[])localArrayList.toArray(new String[localArrayList.size()]));
  }
  
  public String text()
  {
    return this.text;
  }
  
  public int textLength()
  {
    return size() * 8;
  }
  
  static
  {
    try
    {
      ID = JRegistry.register(Sdp.class);
    }
    catch (RegistryHeaderErrors localRegistryHeaderErrors)
    {
      localRegistryHeaderErrors.printStackTrace();
    }
  }
  
  @Field
  public static enum Fields
  {
    ConnectionInfo,  Media,  Owner,  SessionName,  Time,  Version;
    
    private Fields() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.protocol.voip.Sdp
 * JD-Core Version:    0.7.0.1
 */