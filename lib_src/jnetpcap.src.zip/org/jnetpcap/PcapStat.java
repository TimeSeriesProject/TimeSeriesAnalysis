package org.jnetpcap;

public class PcapStat
{
  protected static final StringBuilder out = new StringBuilder();
  private long recv;
  private long drop;
  private long ifDrop;
  protected long capt;
  protected long sent;
  protected long netdrop;
  
  private static native void initIDs();
  
  public final long getRecv()
  {
    return this.recv;
  }
  
  public final long getDrop()
  {
    return this.drop;
  }
  
  public final long getIfDrop()
  {
    return this.ifDrop;
  }
  
  public String toString()
  {
    out.setLength(0);
    out.append("recv=").append(this.recv);
    out.append(", drop=").append(this.drop);
    out.append(", ifdrop=").append(this.ifDrop);
    return out.toString();
  }
  
  static
  {
    System.loadLibrary("jnetpcap");
    initIDs();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapStat
 * JD-Core Version:    0.7.0.1
 */