package org.jnetpcap;

/**
 * @deprecated
 */
public class PcapPktHdr
{
  private volatile long seconds;
  private volatile int useconds;
  private volatile int caplen;
  private volatile int len;
  
  private static native void initIDs();
  
  public PcapPktHdr()
  {
    this.seconds = (System.currentTimeMillis() / 1000L);
    this.useconds = ((int)(System.nanoTime() / 1000L));
    this.caplen = 0;
    this.len = 0;
  }
  
  public PcapPktHdr(int paramInt1, int paramInt2)
  {
    this.caplen = paramInt1;
    this.len = paramInt2;
    this.seconds = (System.currentTimeMillis() / 1000L);
    this.useconds = ((int)(System.nanoTime() / 1000L));
  }
  
  public PcapPktHdr(long paramLong, int paramInt1, int paramInt2, int paramInt3)
  {
    this.seconds = paramLong;
    this.useconds = paramInt1;
    this.caplen = paramInt2;
    this.len = paramInt3;
  }
  
  public final long getSeconds()
  {
    return this.seconds;
  }
  
  public final int getUseconds()
  {
    return this.useconds;
  }
  
  public final int getCaplen()
  {
    return this.caplen;
  }
  
  public final int getLen()
  {
    return this.len;
  }
  
  public final void setSeconds(long paramLong)
  {
    this.seconds = paramLong;
  }
  
  public final void setUseconds(int paramInt)
  {
    this.useconds = paramInt;
  }
  
  public final void setCaplen(int paramInt)
  {
    this.caplen = paramInt;
  }
  
  public final void setLen(int paramInt)
  {
    this.len = paramInt;
  }
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapPktHdr
 * JD-Core Version:    0.7.0.1
 */