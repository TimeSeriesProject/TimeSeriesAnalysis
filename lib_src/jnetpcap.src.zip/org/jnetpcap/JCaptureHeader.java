package org.jnetpcap;

public abstract interface JCaptureHeader
{
  public abstract int caplen();
  
  public abstract int wirelen();
  
  public abstract long seconds();
  
  public abstract long nanos();
  
  public abstract long timestampInMillis();
  
  public abstract long timestampInNanos();
  
  public abstract long timestampInMicros();
  
  public abstract void seconds(long paramLong);
  
  public abstract void nanos(long paramLong);
  
  public abstract void caplen(int paramInt);
  
  public abstract void wirelen(int paramInt);
  
  public abstract void initFrom(JCaptureHeader paramJCaptureHeader);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.JCaptureHeader
 * JD-Core Version:    0.7.0.1
 */