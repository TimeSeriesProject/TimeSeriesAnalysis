package org.jnetpcap.packet;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jnetpcap.PcapDLT;
import org.jnetpcap.packet.structure.AnnotatedBinding;
import org.jnetpcap.packet.structure.AnnotatedHeader;
import org.jnetpcap.packet.structure.AnnotatedScannerMethod;
import org.jnetpcap.packet.structure.HeaderDefinitionError;
import org.jnetpcap.protocol.JProtocol;
import org.jnetpcap.util.resolver.Resolver;
import org.jnetpcap.util.resolver.Resolver.ResolverType;

public final class JRegistry
{
  private static final int A_MAX_ID_COUNT = 64;
  public static final int CORE_ID_COUNT = JProtocol.values().length;
  private static final int[] DLTS_TO_IDS;
  private static List<HeaderDefinitionError> errors = new ArrayList();
  public static final int FLAG_HEURISTIC_BINDING = 16;
  public static final int FLAG_HEURISTIC_PRE_BINDING = 32;
  public static final int FLAG_OVERRIDE_BINDING = 2;
  public static final int FLAG_OVERRIDE_LENGTH = 1;
  private static final int[] headerFlags = new int[64];
  private static final int[] IDS_TO_DLTS;
  private static int LAST_ID = JProtocol.values().length;
  private static final Entry[] MAP_BY_ID = new Entry[64];
  private static Map<String, Entry> mapByClassName = new HashMap();
  private static Map<String, AnnotatedHeader> mapSubsByClassName = new HashMap(50);
  private static final int MAX_DLT_COUNT = 512;
  public static final int MAX_ID_COUNT = 64;
  public static final int NO_DLT_MAPPING = -1;
  private static final Map<Object, Resolver> resolvers = new HashMap();
  private static final JHeaderScanner[] scanners = new JHeaderScanner[64];
  
  public static void addBindings(Class<?> paramClass)
  {
    
    if (JHeader.class.isAssignableFrom(paramClass)) {
      addBindings(AnnotatedBinding.inspectJHeaderClass(paramClass, errors));
    } else {
      addBindings(AnnotatedBinding.inspectClass(paramClass, errors));
    }
  }
  
  public static void addBindings(JBinding... paramVarArgs)
  {
    for (JBinding localJBinding : paramVarArgs) {
      scanners[localJBinding.getTargetId()].addBindings(new JBinding[] { localJBinding });
    }
  }
  
  public static void addBindings(Object paramObject)
  {
    if ((paramObject instanceof JBinding))
    {
      addBindings(new JBinding[] { (JBinding)paramObject });
      return;
    }
    clearErrors();
    addBindings(AnnotatedBinding.inspectObject(paramObject, errors));
  }
  
  public static void clearErrors()
  {
    errors.clear();
  }
  
  public static void clearFlags(int paramInt1, int paramInt2)
  {
    headerFlags[paramInt1] &= (paramInt2 ^ 0xFFFFFFFF);
  }
  
  public static void clearScanners(Class<? extends JHeader>... paramVarArgs)
  {
    for (Class<? extends JHeader> localClass : paramVarArgs)
    {
      int k = lookupId(localClass);
      scanners[k].setScannerMethod(null);
    }
  }
  
  public static void clearScanners(int... paramVarArgs)
  {
    for (int k : paramVarArgs) {
      scanners[k].setScannerMethod(null);
    }
  }
  
  public static void clearScanners(Object paramObject)
  {
    AnnotatedScannerMethod[] arrayOfAnnotatedScannerMethod = AnnotatedScannerMethod.inspectObject(paramObject);
    int[] arrayOfInt = new int[arrayOfAnnotatedScannerMethod.length];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = arrayOfAnnotatedScannerMethod[i].getId();
    }
    clearScanners(arrayOfInt);
  }
  
  private static Entry createNewEntry(Class<? extends JHeader> paramClass)
  {
    int i = LAST_ID;
    Entry localEntry;
    mapByClassName.put(paramClass.getCanonicalName(), localEntry = new Entry(i, paramClass));
    MAP_BY_ID[i] = localEntry;
    LAST_ID += 1;
    return localEntry;
  }
  
  public static JBinding[] getBindings(int paramInt)
  {
    return scanners[paramInt].getBindings();
  }
  
  public static HeaderDefinitionError[] getErrors()
  {
    return (HeaderDefinitionError[])errors.toArray(new HeaderDefinitionError[errors.size()]);
  }
  
  public static int getFlags(int paramInt)
  {
    return headerFlags[paramInt];
  }
  
  public static int[] getAllFlags()
  {
    int[] arrayOfInt = new int[headerFlags.length];
    System.arraycopy(headerFlags, 0, arrayOfInt, 0, arrayOfInt.length);
    return arrayOfInt;
  }
  
  public static void setAllFlags(int[] paramArrayOfInt)
  {
    System.arraycopy(paramArrayOfInt, 0, headerFlags, 0, paramArrayOfInt.length);
  }
  
  public static JHeaderScanner[] getHeaderScanners()
  {
    JHeaderScanner[] arrayOfJHeaderScanner = new JHeaderScanner[64];
    System.arraycopy(scanners, 0, arrayOfJHeaderScanner, 0, 64);
    return arrayOfJHeaderScanner;
  }
  
  public static Resolver getResolver(Object paramObject)
  {
    Resolver localResolver = (Resolver)resolvers.get(paramObject);
    localResolver.initializeIfNeeded();
    return localResolver;
  }
  
  public static Resolver getResolver(Resolver.ResolverType paramResolverType)
  {
    return getResolver(paramResolverType);
  }
  
  public static boolean hasDltMapping(int paramInt)
  {
    return (paramInt >= 0) && (paramInt < DLTS_TO_IDS.length) && (DLTS_TO_IDS[paramInt] != -1);
  }
  
  public static boolean hasErrors()
  {
    return errors.isEmpty();
  }
  
  public static boolean hasResolver(Object paramObject)
  {
    return resolvers.containsKey(paramObject);
  }
  
  public static boolean hasResolver(Resolver.ResolverType paramResolverType)
  {
    return resolvers.containsKey(paramResolverType);
  }
  
  public static AnnotatedHeader inspect(Class<? extends JHeader> paramClass, List<HeaderDefinitionError> paramList)
  {
    return AnnotatedHeader.inspectJHeaderClass(paramClass, paramList);
  }
  
  public static Object[] listResolvers()
  {
    return resolvers.keySet().toArray(new Object[resolvers.size()]);
  }
  
  public static AnnotatedHeader lookupAnnotatedHeader(Class<? extends JHeader> paramClass)
    throws UnregisteredHeaderException
  {
    if (JSubHeader.class.isAssignableFrom(paramClass)) {
      return lookupAnnotatedSubHeader(paramClass);
    }
    return lookupAnnotatedHeader(lookupIdNoCreate(paramClass));
  }
  
  public static AnnotatedHeader lookupAnnotatedHeader(int paramInt)
    throws UnregisteredHeaderException
  {
    if ((MAP_BY_ID[paramInt] == null) || (MAP_BY_ID[paramInt].annotatedHeader == null)) {
      throw new UnregisteredHeaderException("header [" + paramInt + "] not registered");
    }
    return MAP_BY_ID[paramInt].annotatedHeader;
  }
  
  public static AnnotatedHeader lookupAnnotatedHeader(JProtocol paramJProtocol)
  {
    Class localClass = paramJProtocol.getHeaderClass();
    Entry localEntry = MAP_BY_ID[paramJProtocol.getId()];
    if (localEntry.annotatedHeader == null)
    {
      errors.clear();
      localEntry.annotatedHeader = inspect(localClass, errors);
      registerAnnotatedSubHeaders(localEntry.annotatedHeader.getHeaders());
    }
    return localEntry.annotatedHeader;
  }
  
  static AnnotatedHeader lookupAnnotatedSubHeader(Class<? extends JSubHeader<? extends JSubHeader<?>>> paramClass)
  {
    if (!mapSubsByClassName.containsKey(paramClass.getCanonicalName())) {
      throw new UnregisteredHeaderException("sub header [" + paramClass.getName() + "] not registered, most likely parent not registered as well");
    }
    return (AnnotatedHeader)mapSubsByClassName.get(paramClass.getCanonicalName());
  }
  
  public static Class<? extends JHeader> lookupClass(int paramInt)
    throws UnregisteredHeaderException
  {
    if (paramInt > LAST_ID) {
      throw new UnregisteredHeaderException("invalid id " + paramInt);
    }
    Entry localEntry = MAP_BY_ID[paramInt];
    if (localEntry == null) {
      throw new UnregisteredHeaderException("invalid id " + paramInt);
    }
    return localEntry.getHeaderClass();
  }
  
  public static int lookupId(Class<? extends JHeader> paramClass)
  {
    if (JSubHeader.class.isAssignableFrom(paramClass))
    {
      localObject = lookupAnnotatedSubHeader(paramClass);
      return ((AnnotatedHeader)localObject).getId();
    }
    Object localObject = (Entry)mapByClassName.get(paramClass.getCanonicalName());
    if (localObject == null) {
      localObject = createNewEntry(paramClass);
    }
    return ((Entry)localObject).id;
  }
  
  public static int lookupId(JProtocol paramJProtocol)
  {
    return paramJProtocol.getId();
  }
  
  private static int lookupIdNoCreate(Class<? extends JHeader> paramClass)
    throws UnregisteredHeaderException
  {
    if (!mapByClassName.containsKey(paramClass.getCanonicalName())) {
      throw new UnregisteredHeaderException("header [" + paramClass.getName() + "] not registered");
    }
    return ((Entry)mapByClassName.get(paramClass.getCanonicalName())).id;
  }
  
  public static JHeaderScanner lookupScanner(int paramInt)
  {
    return scanners[paramInt];
  }
  
  public static int mapDLTToId(int paramInt)
  {
    return DLTS_TO_IDS[paramInt];
  }
  
  public static int mapIdToDLT(int paramInt)
  {
    return IDS_TO_DLTS[paramInt];
  }
  
  public static PcapDLT mapIdToPcapDLT(int paramInt)
  {
    return PcapDLT.valueOf(IDS_TO_DLTS[paramInt]);
  }
  
  public static int register(Class<? extends JHeader> paramClass)
    throws RegistryHeaderErrors
  {
    ArrayList localArrayList = new ArrayList();
    int i = register(paramClass, localArrayList);
    if (!localArrayList.isEmpty()) {
      throw new RegistryHeaderErrors(paramClass, localArrayList, "while trying to register " + paramClass.getSimpleName() + " class");
    }
    return i;
  }
  
  public static int register(Class<? extends JHeader> paramClass, List<HeaderDefinitionError> paramList)
  {
    AnnotatedHeader localAnnotatedHeader = inspect(paramClass, paramList);
    if (!paramList.isEmpty()) {
      return -1;
    }
    Entry localEntry = (Entry)mapByClassName.get(paramClass.getCanonicalName());
    if (localEntry == null) {
      localEntry = createNewEntry(paramClass);
    }
    int i = localEntry.id;
    localEntry.annotatedHeader = localAnnotatedHeader;
    scanners[i] = new JHeaderScanner(paramClass);
    registerAnnotatedSubHeaders(localAnnotatedHeader.getHeaders());
    JBinding[] arrayOfJBinding = AnnotatedBinding.inspectJHeaderClass(paramClass, paramList);
    if (!paramList.isEmpty()) {
      return -1;
    }
    addBindings(arrayOfJBinding);
    for (PcapDLT localPcapDLT : localAnnotatedHeader.getDlt()) {
      registerDLT(localPcapDLT, i);
    }
    return i;
  }
  
  static int register(JProtocol paramJProtocol)
  {
    Entry localEntry = new Entry(paramJProtocol.getId(), paramJProtocol.getHeaderClassName());
    mapByClassName.put(paramJProtocol.getHeaderClassName(), localEntry);
    MAP_BY_ID[paramJProtocol.getId()] = localEntry;
    try
    {
      scanners[paramJProtocol.getId()] = new JHeaderScanner(paramJProtocol);
    }
    catch (UnregisteredHeaderException localUnregisteredHeaderException)
    {
      register(paramJProtocol.getClazz(), errors);
    }
    for (PcapDLT localPcapDLT : paramJProtocol.getDlt()) {
      registerDLT(localPcapDLT, paramJProtocol.getId());
    }
    return paramJProtocol.getId();
  }
  
  private static void registerAnnotatedSubHeaders(AnnotatedHeader[] paramArrayOfAnnotatedHeader)
  {
    for (AnnotatedHeader localAnnotatedHeader : paramArrayOfAnnotatedHeader)
    {
      mapSubsByClassName.put(localAnnotatedHeader.getHeaderClass().getCanonicalName(), localAnnotatedHeader);
      registerAnnotatedSubHeaders(localAnnotatedHeader.getHeaders());
    }
  }
  
  public static void registerDLT(int paramInt1, int paramInt2)
  {
    DLTS_TO_IDS[paramInt1] = paramInt2;
    IDS_TO_DLTS[paramInt2] = paramInt1;
  }
  
  public static void registerDLT(PcapDLT paramPcapDLT, int paramInt)
  {
    registerDLT(paramPcapDLT.getValue(), paramInt);
  }
  
  public static void registerResolver(Object paramObject, Resolver paramResolver)
  {
    resolvers.put(paramObject, paramResolver);
  }
  
  public static void registerResolver(Resolver.ResolverType paramResolverType, Resolver paramResolver)
  {
    resolvers.put(paramResolverType, paramResolver);
  }
  
  public static void resetBindings(int paramInt)
  {
    scanners[paramInt].clearBindings();
  }
  
  public static void setFlags(int paramInt1, int paramInt2)
  {
    headerFlags[paramInt1] |= paramInt2;
  }
  
  public static void setScanners(AnnotatedScannerMethod... paramVarArgs)
  {
    for (AnnotatedScannerMethod localAnnotatedScannerMethod : paramVarArgs)
    {
      JHeaderScanner localJHeaderScanner = scanners[localAnnotatedScannerMethod.getId()];
      localJHeaderScanner.setScannerMethod(localAnnotatedScannerMethod);
    }
  }
  
  public static void setScanners(Class<?> paramClass)
  {
    if (JHeader.class.isAssignableFrom(paramClass)) {
      setScanners(AnnotatedScannerMethod.inspectJHeaderClass(paramClass));
    } else {
      setScanners(AnnotatedScannerMethod.inspectClass(paramClass));
    }
  }
  
  public static void setScanners(Object paramObject)
  {
    AnnotatedScannerMethod[] arrayOfAnnotatedScannerMethod = AnnotatedScannerMethod.inspectObject(paramObject);
    setScanners(arrayOfAnnotatedScannerMethod);
  }
  
  public static void shutdown()
    throws IOException
  {
    Iterator localIterator = resolvers.values().iterator();
    while (localIterator.hasNext())
    {
      Resolver localResolver = (Resolver)localIterator.next();
      if (localResolver != null) {
        localResolver.saveCache();
      }
    }
    resolvers.clear();
  }
  
  public static String toDebugString()
  {
    Formatter localFormatter = new Formatter();
    Object localObject2;
    try
    {
      for (int i = 0; i < 64; i++) {
        if (scanners[i] != null) {
          localFormatter.format("scanner[%-2d] class=%-15s %s\n", new Object[] { Integer.valueOf(i), lookupClass(i).getSimpleName(), scanners[i].toString() });
        }
      }
      for (i = 0; i < 512; i++) {
        if (hasDltMapping(i))
        {
          int j = mapDLTToId(i);
          localObject2 = lookupClass(j);
          localFormatter.format("libpcap::%-24s => header::%s.class(%d)\n", new Object[] { PcapDLT.valueOf(i).toString() + "(" + i + ")", ((Class)localObject2).getSimpleName(), Integer.valueOf(j) });
        }
      }
    }
    catch (UnregisteredHeaderException localUnregisteredHeaderException)
    {
      throw new IllegalStateException(localUnregisteredHeaderException);
    }
    Iterator localIterator = resolvers.keySet().iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      localObject2 = (Resolver)resolvers.get(localObject1);
      ((Resolver)localObject2).initializeIfNeeded();
      localFormatter.format("Resolver %s: %s\n", new Object[] { String.valueOf(localObject1), localObject2.toString() });
    }
    return localFormatter.toString();
  }
  
  static
  {
    DLTS_TO_IDS = new int[512];
    IDS_TO_DLTS = new int[64];
    Arrays.fill(DLTS_TO_IDS, -1);
    Arrays.fill(IDS_TO_DLTS, -1);
    JProtocol localJProtocol;
    for (localJProtocol : JProtocol.values()) {
      try
      {
        register(localJProtocol);
      }
      catch (Exception localException1)
      {
        System.err.println("JRegistry Error: " + localException1.getMessage());
        localException1.printStackTrace();
        System.exit(0);
      }
    }
    for (localJProtocol : JProtocol.values()) {
      try
      {
        JBinding[] arrayOfJBinding = AnnotatedBinding.inspectJHeaderClass(localJProtocol.getHeaderClass(), errors);
        if ((arrayOfJBinding != null) && (arrayOfJBinding.length != 0)) {
          addBindings(arrayOfJBinding);
        }
      }
      catch (Exception localException2)
      {
        System.err.println("JRegistry Error: " + localException2.getMessage());
        localException2.printStackTrace();
        System.exit(0);
      }
    }
    for (localJProtocol : Resolver.ResolverType.values()) {
      if (localJProtocol.getResolver() != null) {
        try
        {
          registerResolver(localJProtocol, localJProtocol.getResolver());
        }
        catch (Exception localException3)
        {
          System.err.println("JRegistry Error: " + localException3.getMessage());
          localException3.printStackTrace();
          System.exit(0);
        }
      }
    }
    setFlags(4, 16);
    setFlags(5, 16);
  }
  
  private static class Entry
  {
    private AnnotatedHeader annotatedHeader;
    private final String className;
    private Class<? extends JHeader> clazz;
    private final int id;
    
    public Entry(int paramInt, Class<? extends JHeader> paramClass)
    {
      this.id = paramInt;
      this.clazz = paramClass;
      this.className = paramClass.getName();
    }
    
    public Entry(int paramInt, String paramString)
    {
      this.id = paramInt;
      this.className = paramString;
    }
    
    public Class<? extends JHeader> getHeaderClass()
    {
      if (this.clazz == null) {
        try
        {
          return Class.forName(this.className);
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          throw new IllegalStateException(localClassNotFoundException);
        }
      }
      return this.clazz;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JRegistry
 * JD-Core Version:    0.7.0.1
 */