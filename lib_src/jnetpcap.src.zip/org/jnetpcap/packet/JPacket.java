package org.jnetpcap.packet;

import java.nio.ByteBuffer;
import org.jnetpcap.JCaptureHeader;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JMemoryPool;
import org.jnetpcap.nio.JMemoryPool.Block;
import org.jnetpcap.nio.JStruct;
import org.jnetpcap.packet.format.FormatUtils;
import org.jnetpcap.packet.format.JFormatter;
import org.jnetpcap.packet.format.TextFormatter;

public abstract class JPacket
  extends JBuffer
  implements JHeaderAccessor
{
  public static final int DEFAULT_STATE_HEADER_COUNT = 20;
  protected static JScanner defaultScanner;
  private static JFormatter out = new TextFormatter(new StringBuilder());
  protected static JMemoryPool pool = new JMemoryPool();
  protected final JBuffer memory = new JBuffer(JMemory.Type.POINTER);
  protected final State state = new State(JMemory.Type.POINTER);
  
  public static JScanner getDefaultScanner()
  {
    if (defaultScanner == null) {
      synchronized (JScanner.class)
      {
        if (defaultScanner == null) {
          defaultScanner = new JScanner();
        }
      }
    }
    return defaultScanner;
  }
  
  public static void shutdown()
  {
    defaultScanner = null;
    pool = null;
  }
  
  public static JFormatter getFormatter()
  {
    return out;
  }
  
  public static JMemoryPool getMemoryPool()
  {
    return pool;
  }
  
  public static void setFormatter(JFormatter paramJFormatter)
  {
    out = paramJFormatter;
  }
  
  public static void setMemoryPool(JMemoryPool paramJMemoryPool)
  {
    pool = paramJMemoryPool;
  }
  
  public JPacket(int paramInt1, int paramInt2)
  {
    super(JMemory.Type.POINTER);
    allocate(paramInt1 + paramInt2);
  }
  
  public JPacket(JMemory.Type paramType)
  {
    super(paramType);
  }
  
  public void allocate(int paramInt)
  {
    pool.allocate(paramInt, this.memory);
  }
  
  public int getAllocatedMemorySize()
  {
    if (!this.memory.isInitialized()) {
      return 0;
    }
    return this.memory.size();
  }
  
  public abstract JCaptureHeader getCaptureHeader();
  
  public long getFrameNumber()
  {
    return this.state.getFrameNumber() + 1L;
  }
  
  public <T extends JHeader> T getHeader(T paramT)
  {
    return getHeader(paramT, 0);
  }
  
  public <T extends JHeader> T getHeader(T paramT, int paramInt)
  {
    check();
    int i = this.state.findHeaderIndex(paramT.getId(), paramInt);
    if (i == -1) {
      return null;
    }
    return getHeaderByIndex(i, paramT);
  }
  
  public <T extends JHeader> T getHeaderByIndex(int paramInt, T paramT)
    throws IndexOutOfBoundsException
  {
    JHeader.State localState = paramT.getState();
    this.state.peerHeaderByIndex(paramInt, localState);
    paramT.peer(this, localState.getOffset(), localState.getLength());
    paramT.setPacket(this);
    paramT.setIndex(paramInt);
    paramT.decode();
    return paramT;
  }
  
  public int getHeaderCount()
  {
    return this.state.getHeaderCount();
  }
  
  public int getHeaderIdByIndex(int paramInt)
  {
    return this.state.getHeaderIdByIndex(paramInt);
  }
  
  public int getHeaderInstanceCount(int paramInt)
  {
    return this.state.getInstanceCount(paramInt);
  }
  
  protected JBuffer getMemoryBuffer(byte[] paramArrayOfByte)
  {
    pool.allocate(paramArrayOfByte.length, this.memory);
    this.memory.transferFrom(paramArrayOfByte);
    return this.memory;
  }
  
  protected JBuffer getMemoryBuffer(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    this.memory.peer(paramByteBuffer);
    return this.memory;
  }
  
  protected JBuffer getMemoryBuffer(int paramInt)
  {
    if ((!this.memory.isInitialized()) || (this.memory.size() < paramInt)) {
      allocate(paramInt);
    }
    return this.memory;
  }
  
  protected JBuffer getMemoryBuffer(JBuffer paramJBuffer)
  {
    this.memory.peer(paramJBuffer);
    return this.memory;
  }
  
  public int getPacketWirelen()
  {
    return getCaptureHeader().wirelen();
  }
  
  @Deprecated
  public JScanner getScanner()
  {
    return defaultScanner;
  }
  
  public State getState()
  {
    return this.state;
  }
  
  public abstract int getTotalSize();
  
  public boolean hasHeader(int paramInt)
  {
    return hasHeader(paramInt, 0);
  }
  
  public boolean hasHeader(int paramInt1, int paramInt2)
  {
    check();
    int i = this.state.findHeaderIndex(paramInt1, paramInt2);
    return i != -1;
  }
  
  public <T extends JHeader> boolean hasHeader(T paramT)
  {
    return ((this.state.get64BitHeaderMap(0) & 1L << paramT.getId()) != 0L) && (hasHeader(paramT, 0));
  }
  
  public <T extends JHeader> boolean hasHeader(T paramT, int paramInt)
  {
    check();
    int i = this.state.findHeaderIndex(paramT.getId(), paramInt);
    if (i == -1) {
      return false;
    }
    getHeaderByIndex(i, paramT);
    return true;
  }
  
  public int remaining(int paramInt)
  {
    return size() - paramInt;
  }
  
  public int remaining(int paramInt1, int paramInt2)
  {
    int i = size() - paramInt1;
    return i >= paramInt2 ? paramInt2 : i;
  }
  
  public void scan(int paramInt)
  {
    getDefaultScanner().scan(this, paramInt, getCaptureHeader().wirelen());
  }
  
  public String toHexdump()
  {
    if (this.state.isInitialized()) {
      return FormatUtils.hexdump(this);
    }
    byte[] arrayOfByte = getByteArray(0, size());
    return FormatUtils.hexdump(arrayOfByte);
  }
  
  public String toString()
  {
    out.reset();
    try
    {
      out.format(this);
      return out.toString();
    }
    catch (Exception localException)
    {
      throw new RuntimeException(out.toString(), localException);
    }
  }
  
  public static class State
    extends JStruct
  {
    public static final int FLAG_TRUNCATED = 1;
    public static final String STRUCT_NAME = "packet_state_t";
    private final JFlowKey flowKey = new JFlowKey();
    
    public static native int sizeof(int paramInt);
    
    public State(int paramInt)
    {
      super(paramInt);
    }
    
    public State(JMemory.Type paramType)
    {
      super(paramType);
    }
    
    public void cleanup()
    {
      super.cleanup();
    }
    
    public int findHeaderIndex(int paramInt)
    {
      return findHeaderIndex(paramInt, 0);
    }
    
    public native int findHeaderIndex(int paramInt1, int paramInt2);
    
    public native long get64BitHeaderMap(int paramInt);
    
    public native int getFlags();
    
    public JFlowKey getFlowKey()
    {
      if (!this.flowKey.isInitialized()) {
        this.flowKey.peer(this);
      }
      return this.flowKey;
    }
    
    public native long getFrameNumber();
    
    public native int getHeaderCount();
    
    public native int getHeaderIdByIndex(int paramInt);
    
    public native int getHeaderLengthByIndex(int paramInt);
    
    public native int getHeaderOffsetByIndex(int paramInt);
    
    public native int getInstanceCount(int paramInt);
    
    public native int getWirelen();
    
    public int peer(ByteBuffer paramByteBuffer)
      throws PeeringException
    {
      int i = super.peer(paramByteBuffer);
      this.flowKey.peer(this);
      return i;
    }
    
    public int peer(JBuffer paramJBuffer)
    {
      int i = super.peer(paramJBuffer, 0, size());
      this.flowKey.peer(this);
      return i;
    }
    
    public int peer(JBuffer paramJBuffer, int paramInt1, int paramInt2)
      throws IndexOutOfBoundsException
    {
      int i = super.peer(paramJBuffer, paramInt1, paramInt2);
      this.flowKey.peer(this);
      return i;
    }
    
    public int peer(JMemory paramJMemory, int paramInt)
    {
      int i = super.peer(paramJMemory, paramInt, size());
      this.flowKey.peer(this);
      return i;
    }
    
    public int peer(JMemoryPool.Block paramBlock, int paramInt1, int paramInt2)
      throws IndexOutOfBoundsException
    {
      int i = super.peer(paramBlock, paramInt1, paramInt2);
      this.flowKey.peer(this);
      return i;
    }
    
    public int peer(State paramState)
    {
      int i = super.peer(paramState, 0, size());
      this.flowKey.peer(this);
      return i;
    }
    
    public native int peerHeaderById(int paramInt1, int paramInt2, JHeader.State paramState);
    
    public native int peerHeaderByIndex(int paramInt, JHeader.State paramState)
      throws IndexOutOfBoundsException;
    
    public int peerTo(JBuffer paramJBuffer, int paramInt)
    {
      int i = super.peer(paramJBuffer, paramInt, size());
      this.flowKey.peer(this);
      return i;
    }
    
    public int peerTo(JBuffer paramJBuffer, int paramInt1, int paramInt2)
    {
      int i = super.peer(paramJBuffer, paramInt1, paramInt2);
      this.flowKey.peer(this);
      return i;
    }
    
    public int peerTo(State paramState, int paramInt)
    {
      int i = super.peer(paramState, paramInt, paramState.size());
      this.flowKey.peer(this);
      return i;
    }
    
    public native void setFlags(int paramInt);
    
    public native void setWirelen(int paramInt);
    
    public String toDebugString()
    {
      return super.toDebugString() + "\n" + toDebugStringJPacketState();
    }
    
    private native String toDebugStringJPacketState();
    
    public int transferTo(byte[] paramArrayOfByte, int paramInt)
    {
      return super.transferTo(paramArrayOfByte, 0, size(), paramInt);
    }
    
    public int transferTo(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
    {
      return super.transferTo(paramArrayOfByte, paramInt1, size(), paramInt3);
    }
    
    public int transferTo(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3)
    {
      return super.transferTo(paramJBuffer, paramInt1, size(), paramInt3);
    }
    
    public int transferTo(State paramState)
    {
      return super.transferTo(paramState, 0, size(), 0);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JPacket
 * JD-Core Version:    0.7.0.1
 */