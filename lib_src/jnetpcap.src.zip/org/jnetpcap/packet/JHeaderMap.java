package org.jnetpcap.packet;

import java.util.ArrayList;
import java.util.List;
import org.jnetpcap.packet.structure.AnnotatedHeader;
import org.jnetpcap.packet.structure.JField;

public abstract class JHeaderMap<B extends JHeader>
  extends JHeader
  implements JCompoundHeader<B>
{
  public static final int MAX_HEADERS = 64;
  protected long optionsBitmap = -1L;
  protected int[] optionsOffsets = new int[64];
  protected int[] optionsLength = new int[64];
  protected final JHeader[] X_HEADERS = new JHeader[64];
  
  public JHeaderMap()
  {
    reorderAndSave(createHeaderInstances(this.annotatedHeader.getHeaders()));
  }
  
  private static JHeader[] createHeaderInstances(AnnotatedHeader... paramVarArgs)
  {
    JHeader[] arrayOfJHeader = new JHeader[paramVarArgs.length];
    for (int i = 0; i < arrayOfJHeader.length; i++) {
      arrayOfJHeader[i] = createHeaderInstance(paramVarArgs[i]);
    }
    return arrayOfJHeader;
  }
  
  private static JHeader createHeaderInstance(AnnotatedHeader paramAnnotatedHeader)
  {
    try
    {
      return (JHeader)paramAnnotatedHeader.getHeaderClass().newInstance();
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new IllegalStateException(localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalStateException(localIllegalAccessException);
    }
  }
  
  public JHeaderMap(int paramInt, JField[] paramArrayOfJField, String paramString1, String paramString2, JHeader[] paramArrayOfJHeader)
  {
    super(paramInt, paramArrayOfJField, paramString1, paramString2);
    reorderAndSave(paramArrayOfJHeader);
  }
  
  public JHeaderMap(int paramInt, String paramString, JHeader[] paramArrayOfJHeader)
  {
    super(paramInt, paramString);
    reorderAndSave(paramArrayOfJHeader);
  }
  
  public JHeaderMap(int paramInt, String paramString1, String paramString2, JHeader[] paramArrayOfJHeader)
  {
    super(paramInt, paramString1, paramString2);
    reorderAndSave(paramArrayOfJHeader);
  }
  
  public void setSubHeaders(JHeader[] paramArrayOfJHeader)
  {
    reorderAndSave(paramArrayOfJHeader);
  }
  
  public <T extends JSubHeader<B>> T getSubHeader(T paramT)
  {
    int i = this.optionsOffsets[paramT.getId()];
    int j = this.optionsLength[paramT.getId()];
    paramT.peer(this, i, j);
    paramT.setOffset(i);
    paramT.setLength(j);
    paramT.setParent(this);
    paramT.packet = this.packet;
    return paramT;
  }
  
  private JHeader getSubHeader(JHeader paramJHeader)
  {
    JSubHeader localJSubHeader = (JSubHeader)paramJHeader;
    int i = localJSubHeader.getId();
    int j = this.optionsOffsets[i];
    int k = this.optionsLength[i];
    localJSubHeader.peer(this, j, k);
    localJSubHeader.setOffset(j);
    localJSubHeader.setLength(k);
    localJSubHeader.setParent(this);
    return paramJHeader;
  }
  
  public JHeader[] getSubHeaders()
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < 64; i++) {
      if ((hasSubHeader(i)) && (this.X_HEADERS[i] != null))
      {
        JHeader localJHeader = this.X_HEADERS[i];
        getSubHeader(localJHeader);
        localArrayList.add(this.X_HEADERS[i]);
      }
    }
    return (JHeader[])localArrayList.toArray(new JHeader[localArrayList.size()]);
  }
  
  public boolean hasSubHeader(int paramInt)
  {
    return (this.optionsBitmap & 1 << paramInt) > 0L;
  }
  
  public <T extends JSubHeader<B>> boolean hasSubHeader(T paramT)
  {
    if (hasSubHeader(paramT.getId()))
    {
      getSubHeader(paramT);
      return true;
    }
    return false;
  }
  
  private void reorderAndSave(JHeader[] paramArrayOfJHeader)
  {
    for (JHeader localJHeader : paramArrayOfJHeader) {
      this.X_HEADERS[localJHeader.getId()] = localJHeader;
    }
  }
  
  public boolean hasSubHeaders()
  {
    return this.optionsBitmap != 0L;
  }
  
  protected void setSubHeader(int paramInt1, int paramInt2, int paramInt3)
  {
    this.optionsBitmap |= 1L << paramInt1;
    this.optionsLength[paramInt1] = paramInt3;
    this.optionsOffsets[paramInt1] = paramInt2;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JHeaderMap
 * JD-Core Version:    0.7.0.1
 */