package org.jnetpcap.packet;

import java.util.Formatter;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JStruct;

public class JFlowKey
  extends JStruct
{
  public static final int FLAG_REVERSABLE = 1;
  private static final int FLOW_KEY_PAIR_COUNT = 3;
  public static final String STRUCT_NAME = "flow_key_t";
  
  public static native int sizeof();
  
  public JFlowKey()
  {
    super("flow_key_t", JMemory.Type.POINTER);
  }
  
  public JFlowKey(JMemory.Type paramType)
  {
    super("flow_key_t", paramType);
  }
  
  public native boolean equal(JFlowKey paramJFlowKey);
  
  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof JFlowKey))
    {
      JFlowKey localJFlowKey = (JFlowKey)paramObject;
      return equal(localJFlowKey);
    }
    return false;
  }
  
  public native int getFlags();
  
  public native long getHeaderMap();
  
  public native int getId(int paramInt);
  
  public int[] getIds()
  {
    int[] arrayOfInt = new int[getPairCount()];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = getId(i);
    }
    return arrayOfInt;
  }
  
  public native long getPair(int paramInt, boolean paramBoolean);
  
  public long[] getPairs()
  {
    long[] arrayOfLong = new long[getPairCount()];
    for (int i = 0; i < arrayOfLong.length; i++) {
      arrayOfLong[i] = getPair(i, false);
    }
    return arrayOfLong;
  }
  
  public native int getPairCount();
  
  public native int getPairP1(int paramInt, boolean paramBoolean);
  
  public native int getPairP2(int paramInt, boolean paramBoolean);
  
  public native int hashCode();
  
  public native int match(JFlowKey paramJFlowKey);
  
  protected int peer(JPacket.State paramState)
  {
    return super.peer(paramState);
  }
  
  public String toDebugString()
  {
    Formatter localFormatter = new Formatter();
    localFormatter.format("[count=%d, map=0x%x, hash=0x%x]", new Object[] { Integer.valueOf(getPairCount()), Long.valueOf(getHeaderMap()), Integer.valueOf(hashCode()) });
    return localFormatter.toString();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JFlowKey
 * JD-Core Version:    0.7.0.1
 */