package org.jnetpcap.packet;

import org.jnetpcap.packet.structure.AnnotatedHeaderLengthMethod;
import org.jnetpcap.packet.structure.HeaderDefinitionError;

public abstract class AbstractBinding<H extends JHeader>
  implements JBinding
{
  private final int targetId;
  private final int sourceId;
  private final H header;
  private AnnotatedHeaderLengthMethod[] lengthMethods;
  
  public AbstractBinding(Class<? extends JHeader> paramClass, Class<H> paramClass1)
  {
    this.sourceId = JRegistry.lookupId(paramClass);
    this.targetId = JRegistry.lookupId(paramClass1);
    try
    {
      this.header = ((JHeader)paramClass1.newInstance());
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new IllegalStateException(localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalStateException(localIllegalAccessException);
    }
    try
    {
      this.lengthMethods = AnnotatedHeaderLengthMethod.inspectClass(paramClass1);
    }
    catch (HeaderDefinitionError localHeaderDefinitionError)
    {
      this.lengthMethods = null;
    }
  }
  
  public int getSourceId()
  {
    return this.sourceId;
  }
  
  public int getTargetId()
  {
    return this.targetId;
  }
  
  public boolean isBound(JPacket paramJPacket, int paramInt)
  {
    if (this.lengthMethods != null)
    {
      int i = this.lengthMethods[org.jnetpcap.packet.annotate.HeaderLength.Type.PREFIX.ordinal()].getHeaderLength(paramJPacket, paramInt);
      paramJPacket.peer(this.header, paramInt + i, this.lengthMethods[org.jnetpcap.packet.annotate.HeaderLength.Type.HEADER.ordinal()].getHeaderLength(paramJPacket, paramInt));
    }
    else
    {
      paramJPacket.peer(this.header, paramInt, paramJPacket.remaining(paramInt));
    }
    return isBound(paramJPacket, this.header);
  }
  
  public abstract boolean isBound(JPacket paramJPacket, H paramH);
  
  public int[] listDependencies()
  {
    return new int[] { this.targetId };
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.AbstractBinding
 * JD-Core Version:    0.7.0.1
 */