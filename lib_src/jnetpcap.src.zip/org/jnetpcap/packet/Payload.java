package org.jnetpcap.packet;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.protocol.JProtocol;

@Header(nicname="Data")
public class Payload
  extends JHeader
{
  public static final int ID = JProtocol.PAYLOAD.getId();
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    return paramJBuffer.size() - paramInt;
  }
  
  @Dynamic(Field.Property.LENGTH)
  public int dataLength()
  {
    return size() * 8;
  }
  
  @Field(offset=0, format="#hexdump#")
  public byte[] data()
  {
    return super.getByteArray(0, size());
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.Payload
 * JD-Core Version:    0.7.0.1
 */