package org.jnetpcap.packet;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import org.jnetpcap.packet.format.FormatUtils;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;

public class JFlow
{
  private final JFlowKey key;
  private final boolean reversable;
  private final List<JPacket> all;
  private final List<JPacket> forward;
  private final List<JPacket> reverse;
  private final Tcp tcp = new Tcp();
  private final Ip4 ip = new Ip4();
  private final Ethernet eth = new Ethernet();
  
  public JFlow(JFlowKey paramJFlowKey)
  {
    this.key = paramJFlowKey;
    this.reversable = ((paramJFlowKey.getFlags() & 0x1) > 0);
    if (this.reversable)
    {
      this.all = new LinkedList();
      this.forward = new LinkedList();
      this.reverse = new LinkedList();
    }
    else
    {
      this.all = new LinkedList();
      this.forward = Collections.emptyList();
      this.reverse = Collections.emptyList();
    }
  }
  
  public final JFlowKey getKey()
  {
    return this.key;
  }
  
  public boolean add(JPacket paramJPacket)
  {
    int i = this.key.match(paramJPacket.getState().getFlowKey());
    if (i == 0) {
      return false;
    }
    if (!isReversable()) {
      return this.all.add(paramJPacket);
    }
    return (i == 1 ? this.forward.add(paramJPacket) : this.reverse.add(paramJPacket)) && (this.all.add(paramJPacket));
  }
  
  public final boolean isReversable()
  {
    return this.reversable;
  }
  
  public final List<JPacket> getAll()
  {
    return this.all;
  }
  
  public int size()
  {
    return this.all.size();
  }
  
  public final List<JPacket> getForward()
  {
    return this.reversable ? this.forward : this.all;
  }
  
  public final List<JPacket> getReverse()
  {
    return this.reversable ? this.reverse : null;
  }
  
  public String toString()
  {
    if (this.all.isEmpty()) {
      return this.key.toDebugString() + " size=" + this.all.size();
    }
    JPacket localJPacket = (JPacket)this.all.get(0);
    String str1;
    String str2;
    String str3;
    if ((localJPacket.hasHeader(this.tcp)) && (localJPacket.hasHeader(this.ip)))
    {
      str1 = FormatUtils.ip(this.ip.destination());
      str2 = FormatUtils.ip(this.ip.source());
      str3 = "" + this.tcp.source();
      String str4 = "" + this.tcp.destination();
      return str2 + ":" + str3 + " -> " + str1 + ":" + str4 + " Tcp fw/rev/tot pkts=[" + this.forward.size() + "/" + this.reverse.size() + "/" + this.all.size() + "]";
    }
    if (localJPacket.hasHeader(this.ip))
    {
      str1 = FormatUtils.ip(this.ip.destination());
      str2 = FormatUtils.ip(this.ip.source());
      str3 = "" + this.ip.type();
      return str2 + " -> " + str1 + ":" + str3 + " Ip4 tot pkts=[" + this.all.size() + "]";
    }
    if (localJPacket.hasHeader(this.eth))
    {
      str1 = FormatUtils.mac(this.eth.destination());
      str2 = FormatUtils.mac(this.eth.source());
      str3 = Integer.toHexString(this.eth.type());
      return str2 + " -> " + str1 + ":" + str3 + " Eth tot pkts=[" + this.all.size() + "]";
    }
    return this.key.toDebugString() + " packets=" + this.all.size();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JFlow
 * JD-Core Version:    0.7.0.1
 */