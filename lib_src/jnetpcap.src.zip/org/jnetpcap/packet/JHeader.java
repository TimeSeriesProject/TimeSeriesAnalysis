package org.jnetpcap.packet;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JStruct;
import org.jnetpcap.packet.format.JFormatter;
import org.jnetpcap.packet.structure.AnnotatedHeader;
import org.jnetpcap.packet.structure.DefaultField;
import org.jnetpcap.packet.structure.JField;
import org.jnetpcap.protocol.JProtocol;

public abstract class JHeader
  extends JBuffer
  implements JPayloadAccessor
{
  public static final int BYTE = 8;
  private static final JField[] DEFAULT_FIELDS = new JField[0];
  protected static final JHeader[] EMPTY_HEADER_ARRAY = new JHeader[0];
  protected AnnotatedHeader annotatedHeader;
  private JField[] fields;
  private int id;
  protected boolean isSubHeader = false;
  private String name;
  private String nicname;
  protected JPacket packet;
  protected final State state;
  private int index = -1;
  
  public static native int sizeof();
  
  public JHeader()
  {
    super(JMemory.Type.POINTER);
    order(ByteOrder.BIG_ENDIAN);
    this.state = new State(JMemory.Type.POINTER);
    JProtocol localJProtocol = JProtocol.valueOf(getClass());
    AnnotatedHeader localAnnotatedHeader;
    if (localJProtocol != null)
    {
      this.id = localJProtocol.getId();
      localAnnotatedHeader = JRegistry.lookupAnnotatedHeader(localJProtocol);
    }
    else
    {
      this.id = JRegistry.lookupId(getClass());
      localAnnotatedHeader = JRegistry.lookupAnnotatedHeader(getClass());
    }
    initFromAnnotatedHeader(localAnnotatedHeader);
  }
  
  public JHeader(int paramInt, JField[] paramArrayOfJField, String paramString)
  {
    this(paramInt, paramArrayOfJField, paramString, paramString);
  }
  
  public JHeader(int paramInt, JField[] paramArrayOfJField, String paramString1, String paramString2)
  {
    super(JMemory.Type.POINTER);
    this.fields = paramArrayOfJField;
    this.id = paramInt;
    this.name = paramString1;
    this.nicname = paramString2;
    this.state = new State(JMemory.Type.POINTER);
    super.order(ByteOrder.nativeOrder());
  }
  
  public JHeader(int paramInt, String paramString)
  {
    this(paramInt, paramString, paramString);
  }
  
  public JHeader(int paramInt, String paramString1, String paramString2)
  {
    this(paramInt, DEFAULT_FIELDS, paramString1, paramString2);
  }
  
  public JHeader(JProtocol paramJProtocol)
  {
    super(JMemory.Type.POINTER);
    order(ByteOrder.BIG_ENDIAN);
    this.state = new State(JMemory.Type.POINTER);
    this.id = paramJProtocol.getId();
    AnnotatedHeader localAnnotatedHeader = JRegistry.lookupAnnotatedHeader(paramJProtocol);
    initFromAnnotatedHeader(localAnnotatedHeader);
  }
  
  public JHeader(State paramState, JField[] paramArrayOfJField, String paramString1, String paramString2)
  {
    super(JMemory.Type.POINTER);
    this.state = paramState;
    this.fields = paramArrayOfJField;
    this.name = paramString1;
    this.nicname = paramString2;
    this.id = paramState.getId();
    super.order(ByteOrder.nativeOrder());
  }
  
  public final void decode()
  {
    decodeHeader();
    validateHeader();
  }
  
  protected void decodeHeader() {}
  
  public AnnotatedHeader getAnnotatedHeader()
  {
    return this.annotatedHeader;
  }
  
  public String getDescription()
  {
    return this.annotatedHeader.getDescription();
  }
  
  public JField[] getFields()
  {
    JField.sortFieldByOffset(this.fields, this, true);
    return this.fields;
  }
  
  public byte[] getGap()
  {
    return this.packet.getByteArray(getGapOffset(), getGapLength());
  }
  
  public int getGapLength()
  {
    return this.state.getGap();
  }
  
  public int getGapOffset()
  {
    return getOffset() + getHeaderLength();
  }
  
  public byte[] getHeader()
  {
    return this.packet.getByteArray(getHeaderOffset(), getHeaderLength());
  }
  
  public int getHeaderLength()
  {
    return this.state.getLength();
  }
  
  public int getHeaderOffset()
  {
    return this.state.getOffset();
  }
  
  public final int getId()
  {
    return this.id;
  }
  
  public int getLength()
  {
    return this.state.getLength();
  }
  
  public final String getName()
  {
    return this.name;
  }
  
  public final String getNicname()
  {
    return this.nicname;
  }
  
  public int getOffset()
  {
    return this.state.getOffset();
  }
  
  public final JPacket getPacket()
  {
    return this.packet;
  }
  
  public JHeader getParent()
  {
    return this;
  }
  
  public byte[] getPayload()
  {
    return this.packet.getByteArray(getPayloadOffset(), getPayloadLength());
  }
  
  public int getPayloadLength()
  {
    return this.state.getPayload();
  }
  
  public int getPayloadOffset()
  {
    return getGapOffset() + getGapLength();
  }
  
  public byte[] getPostfix()
  {
    return this.packet.getByteArray(getPostfixOffset(), getPostfixLength());
  }
  
  public int getPostfixLength()
  {
    return this.state.getPostfix();
  }
  
  public int getPostfixOffset()
  {
    return getPayloadOffset() + getPayloadLength();
  }
  
  public byte[] getPrefix()
  {
    return this.packet.getByteArray(getPrefixOffset(), getPrefixLength());
  }
  
  public int getPrefixLength()
  {
    return this.state.getPrefix();
  }
  
  public int getPrefixOffset()
  {
    return getOffset() - getPrefixLength();
  }
  
  public State getState()
  {
    return this.state;
  }
  
  public JHeader[] getSubHeaders()
  {
    return EMPTY_HEADER_ARRAY;
  }
  
  public boolean hasDescription()
  {
    return this.annotatedHeader.getDescription() != null;
  }
  
  public boolean hasGap()
  {
    return getGapLength() != 0;
  }
  
  public boolean hasPayload()
  {
    return getPayloadLength() != 0;
  }
  
  public boolean hasPostfix()
  {
    return getPostfixLength() != 0;
  }
  
  public boolean hasPrefix()
  {
    return getPrefixLength() != 0;
  }
  
  public boolean hasSubHeaders()
  {
    return false;
  }
  
  private void initFromAnnotatedHeader(AnnotatedHeader paramAnnotatedHeader)
  {
    this.annotatedHeader = paramAnnotatedHeader;
    this.name = paramAnnotatedHeader.getName();
    this.nicname = paramAnnotatedHeader.getNicname();
    this.fields = DefaultField.fromAnnotatedFields(paramAnnotatedHeader.getFields());
  }
  
  public boolean isGapTruncated()
  {
    return (this.state.getFlags() & 0x8) != 0;
  }
  
  public boolean isHeaderTruncated()
  {
    return (this.state.getFlags() & 0x2) != 0;
  }
  
  public boolean isPayloadTruncated()
  {
    return (this.state.getFlags() & 0x4) != 0;
  }
  
  public boolean isPostfixTruncated()
  {
    return (this.state.getFlags() & 0x10) != 0;
  }
  
  public boolean isPrefixTruncated()
  {
    return (this.state.getFlags() & 0x1) != 0;
  }
  
  public int peer(JBuffer paramJBuffer, int paramInt)
  {
    return 0;
  }
  
  public int peer(JHeader paramJHeader)
  {
    this.state.peer(paramJHeader.state);
    return super.peer(paramJHeader, paramJHeader.getOffset(), paramJHeader.getLength());
  }
  
  public JBuffer peerPayloadTo(JBuffer paramJBuffer)
  {
    JPacket localJPacket = getPacket();
    int i = getOffset() + size();
    paramJBuffer.peer(localJPacket, i, localJPacket.remaining(i));
    return paramJBuffer;
  }
  
  public final void setPacket(JPacket paramJPacket)
  {
    this.packet = paramJPacket;
  }
  
  public void setSubHeaders(JHeader[] paramArrayOfJHeader) {}
  
  public String toString()
  {
    JFormatter localJFormatter = JPacket.getFormatter();
    localJFormatter.reset();
    try
    {
      localJFormatter.format(this);
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException("Unexpected StringBuilder IO error");
    }
    return localJFormatter.toString();
  }
  
  public byte[] transferPayloadTo(byte[] paramArrayOfByte)
  {
    JPacket localJPacket = getPacket();
    int i = getOffset() + size();
    return localJPacket.getByteArray(i, paramArrayOfByte);
  }
  
  public ByteBuffer transferPayloadTo(ByteBuffer paramByteBuffer)
  {
    JPacket localJPacket = getPacket();
    int i = getOffset() + size();
    localJPacket.transferTo(paramByteBuffer, i, localJPacket.remaining(i));
    return paramByteBuffer;
  }
  
  public JBuffer transferPayloadTo(JBuffer paramJBuffer)
  {
    JPacket localJPacket = getPacket();
    int i = getOffset() + size();
    localJPacket.transferTo(paramJBuffer, i, localJPacket.remaining(i), 0);
    return paramJBuffer;
  }
  
  void setIndex(int paramInt)
  {
    this.index = paramInt;
  }
  
  public int getIndex()
  {
    return this.index;
  }
  
  protected void validateHeader() {}
  
  public boolean hasNextHeader()
  {
    return this.index + 1 < this.packet.getState().getHeaderCount();
  }
  
  public int getNextHeaderId()
  {
    return this.packet.getState().getHeaderIdByIndex(this.index + 1);
  }
  
  public int getNextHeaderOffset()
  {
    return this.packet.getState().getHeaderOffsetByIndex(this.index + 1);
  }
  
  public boolean hasPreviousHeader()
  {
    return this.index > 0;
  }
  
  public int getPreviousHeaderId()
  {
    return this.packet.getState().getHeaderIdByIndex(this.index - 1);
  }
  
  public int getPreviousHeaderOffset()
  {
    return this.packet.getState().getHeaderOffsetByIndex(this.index - 1);
  }
  
  public boolean isFragmented()
  {
    return (getState().getFlags() & 0x100) > 0;
  }
  
  public static class State
    extends JStruct
  {
    public static final int FLAG_CRC_INVALID = 128;
    public static final int FLAG_CRC_PERFORMED = 64;
    public static final int FLAG_GAP_TRUNCATED = 8;
    public static final int FLAG_HEADER_TRUNCATED = 2;
    public static final int FLAG_HEURISTIC_BINDING = 32;
    public static final int FLAG_PAYLOAD_TRUNCATED = 4;
    public static final int FLAG_POSTFIX_TRUNCATED = 16;
    public static final int FLAG_PREFIX_TRUNCATED = 1;
    public static final int FLAG_HEADER_FRAGMENTED = 256;
    public static final int FLAG_FIELDS_DISSECTED = 512;
    public static final int FLAG_SUBHEADERS_DISSECTED = 1024;
    public static final int FLAG_IGNORE_BOUNDS = 2048;
    public static final String STRUCT_NAME = "header_t";
    
    public State(JMemory.Type paramType)
    {
      super(paramType);
    }
    
    public native int getFlags();
    
    public native int getGap();
    
    public native int getId();
    
    public native int getLength();
    
    public native int getOffset();
    
    public native int getPayload();
    
    public native int getPostfix();
    
    public native int getPrefix();
    
    public boolean isDirect()
    {
      return true;
    }
    
    public int peer(State paramState)
    {
      if (!paramState.isDirect()) {
        throw new IllegalStateException("DirectState can only peer with another DirectState");
      }
      return super.peer(paramState);
    }
    
    public native void setFlags(int paramInt);
    
    public String toString()
    {
      return "(id=" + getId() + ", offset=" + getOffset() + ", length=" + getLength() + ")";
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JHeader
 * JD-Core Version:    0.7.0.1
 */