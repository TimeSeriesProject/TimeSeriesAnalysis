package org.jnetpcap.packet.structure;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JRegistry;
import org.jnetpcap.packet.JScan;
import org.jnetpcap.packet.annotate.Scanner;

public class AnnotatedScannerMethod
  extends AnnotatedMethod
{
  private static final Map<Class<?>, AnnotatedScannerMethod[]> cache = new HashMap();
  private final int id;
  
  public static AnnotatedScannerMethod[] inspectJHeaderClass(Class<? extends JHeader> paramClass)
  {
    if (cache.containsKey(paramClass)) {
      return (AnnotatedScannerMethod[])cache.get(paramClass);
    }
    Method[] arrayOfMethod = getMethods(paramClass, Scanner.class);
    if (arrayOfMethod.length > 1) {
      throw new HeaderDefinitionError(paramClass, "too many scanners defined");
    }
    if (arrayOfMethod.length == 1)
    {
      arrayOfAnnotatedScannerMethod = new AnnotatedScannerMethod[] { new AnnotatedScannerMethod(arrayOfMethod[0], paramClass) };
      cache.put(paramClass, arrayOfAnnotatedScannerMethod);
      return arrayOfAnnotatedScannerMethod;
    }
    AnnotatedScannerMethod[] arrayOfAnnotatedScannerMethod = new AnnotatedScannerMethod[0];
    cache.put(paramClass, arrayOfAnnotatedScannerMethod);
    return arrayOfAnnotatedScannerMethod;
  }
  
  public static AnnotatedScannerMethod[] inspectClass(Class<? extends JHeader> paramClass)
  {
    if (cache.containsKey(paramClass)) {
      return (AnnotatedScannerMethod[])cache.get(paramClass);
    }
    ArrayList localArrayList = new ArrayList(20);
    for (Method localMethod : getMethods(paramClass, Scanner.class))
    {
      Scanner localScanner = (Scanner)localMethod.getAnnotation(Scanner.class);
      Class localClass = localScanner.value() == JHeader.class ? paramClass : localScanner.value();
      if (!JHeader.class.isAssignableFrom(paramClass)) {
        throw new HeaderDefinitionError(paramClass, "non JHeader based classes, must declare protocol class in @Scanner annotation");
      }
      localArrayList.add(new AnnotatedScannerMethod(localMethod, localClass));
    }
    ??? = (AnnotatedScannerMethod[])localArrayList.toArray(new AnnotatedScannerMethod[localArrayList.size()]);
    cache.put(paramClass, ???);
    return ???;
  }
  
  public static AnnotatedScannerMethod[] inspectObject(Object paramObject)
  {
    Class localClass = paramObject.getClass();
    if (cache.containsKey(localClass)) {
      return (AnnotatedScannerMethod[])cache.get(localClass);
    }
    ArrayList localArrayList = new ArrayList(20);
    for (Method localMethod : getMethods(localClass, Scanner.class))
    {
      Scanner localScanner = (Scanner)localMethod.getAnnotation(Scanner.class);
      if (localScanner.value() == JHeader.class) {
        throw new HeaderDefinitionError(localClass, "non JHeader based classes, must declare protocol class in @Scanner annotation");
      }
      localArrayList.add(new AnnotatedScannerMethod(localMethod, localScanner.value(), paramObject));
    }
    ??? = (AnnotatedScannerMethod[])localArrayList.toArray(new AnnotatedScannerMethod[localArrayList.size()]);
    cache.put(localClass, ???);
    return ???;
  }
  
  private AnnotatedScannerMethod(Method paramMethod, Class<? extends JHeader> paramClass)
  {
    super(paramMethod);
    this.id = JRegistry.lookupId(paramClass);
  }
  
  public AnnotatedScannerMethod(Method paramMethod, Class<? extends JHeader> paramClass, Object paramObject)
  {
    super(paramMethod, paramObject);
    this.id = JRegistry.lookupId(paramClass);
  }
  
  public void scan(JScan paramJScan)
  {
    try
    {
      this.method.invoke(this.object, new Object[] { paramJScan });
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new IllegalStateException(localIllegalArgumentException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalStateException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException);
    }
  }
  
  protected void validateSignature(Method paramMethod)
  {
    Class localClass = paramMethod.getDeclaringClass();
    if (!paramMethod.isAnnotationPresent(Scanner.class)) {
      throw new AnnotatedMethodException(localClass, "@Scanner annotation missing for " + paramMethod.getName() + "()");
    }
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    if ((arrayOfClass.length != 1) || (arrayOfClass[0] != JScan.class)) {
      throw new AnnotatedMethodException(localClass, "Invalid signature for " + paramMethod.getName() + "()");
    }
    if ((this.object == null) && ((paramMethod.getModifiers() & 0x8) == 0)) {
      throw new AnnotatedMethodException(localClass, paramMethod.getName() + "()" + " must be declared static");
    }
  }
  
  public int getId()
  {
    return this.id;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedScannerMethod
 * JD-Core Version:    0.7.0.1
 */