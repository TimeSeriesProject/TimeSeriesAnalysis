package org.jnetpcap.packet.structure;

public class AnnotatedMethodException
  extends HeaderDefinitionError
{
  private static final long serialVersionUID = 1165114276807013103L;
  private final Class<?> c;
  
  public AnnotatedMethodException(Class<?> paramClass)
  {
    super(paramClass);
    this.c = paramClass;
  }
  
  public AnnotatedMethodException(String paramString)
  {
    super(paramString);
    this.c = null;
  }
  
  public AnnotatedMethodException(Class<?> paramClass, String paramString)
  {
    super(paramClass, paramString);
    this.c = paramClass;
  }
  
  public AnnotatedMethodException(Throwable paramThrowable)
  {
    super(paramThrowable);
    this.c = null;
  }
  
  public AnnotatedMethodException(Class<?> paramClass, Throwable paramThrowable)
  {
    super(paramClass, paramThrowable);
    this.c = paramClass;
  }
  
  public AnnotatedMethodException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
    this.c = null;
  }
  
  public AnnotatedMethodException(Class<?> paramClass, String paramString, Throwable paramThrowable)
  {
    super(paramClass, paramString, paramThrowable);
    this.c = paramClass;
  }
  
  public Class<?> getHeader()
  {
    return this.c;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedMethodException
 * JD-Core Version:    0.7.0.1
 */