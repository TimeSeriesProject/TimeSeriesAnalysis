package org.jnetpcap.packet.structure;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public abstract class AnnotatedMethod
{
  protected final Method method;
  protected boolean isMapped = false;
  protected final Class<?> declaringClass;
  protected final Object object;
  private static HashMap<Integer, Method[]> cache = new HashMap(20);
  
  public void setIsMapped(boolean paramBoolean)
  {
    this.isMapped = paramBoolean;
  }
  
  public AnnotatedMethod()
  {
    this.method = null;
    this.declaringClass = null;
    this.object = null;
    this.isMapped = false;
  }
  
  public AnnotatedMethod(Method paramMethod, Object paramObject)
  {
    this.object = paramObject;
    this.method = paramMethod;
    this.declaringClass = paramMethod.getDeclaringClass();
  }
  
  public AnnotatedMethod(Method paramMethod)
  {
    this.method = paramMethod;
    this.declaringClass = paramMethod.getDeclaringClass();
    this.object = null;
    validateSignature(paramMethod);
  }
  
  public Method getMethod()
  {
    return this.method;
  }
  
  protected abstract void validateSignature(Method paramMethod);
  
  public String toString()
  {
    if (this.method == null) {
      return "";
    }
    return this.declaringClass.getSimpleName() + "." + this.method.getName() + "()";
  }
  
  public static Method[] getMethods(Class<?> paramClass, Class<? extends Annotation> paramClass1)
  {
    int i = paramClass.hashCode() + paramClass1.hashCode();
    if (cache.containsKey(Integer.valueOf(i))) {
      return (Method[])cache.get(Integer.valueOf(i));
    }
    ArrayList localArrayList = new ArrayList(50);
    for (Method localMethod : paramClass.getMethods()) {
      if (localMethod.isAnnotationPresent(paramClass1)) {
        localArrayList.add(localMethod);
      }
    }
    ??? = (Method[])localArrayList.toArray(new Method[localArrayList.size()]);
    cache.put(Integer.valueOf(i), ???);
    return ???;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedMethod
 * JD-Core Version:    0.7.0.1
 */