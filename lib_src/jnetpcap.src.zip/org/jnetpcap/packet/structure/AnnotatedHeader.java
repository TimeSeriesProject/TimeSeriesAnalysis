package org.jnetpcap.packet.structure;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jnetpcap.PcapDLT;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JSubHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.FieldSetter;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.protocol.JProtocol.Suite;

public class AnnotatedHeader
{
  private static final Map<Class<?>, AnnotatedHeader> cache = new HashMap();
  private String description;
  private Class<? extends JHeader> clazz;
  private AnnotatedField[] fields;
  private final Header annotation;
  private AnnotatedHeader[] headers;
  private String name;
  private String nicname;
  private Class<? extends JHeader> parentClass = null;
  private AnnotatedHeader parent;
  
  private static List<Class<?>> getSubHeaderClasses(Class<?> paramClass, String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    for (Class localClass : paramClass.getClasses()) {
      if (localClass != paramClass) {
        if (localClass.isAnnotationPresent(Header.class)) {
          localArrayList.add(localClass);
        } else {
          localArrayList.addAll(getSubHeaderClasses(localClass, paramString + "." + localClass.getSimpleName()));
        }
      }
    }
    return localArrayList;
  }
  
  private static AnnotatedHeader inspectHeaderAnnotation(Class<? extends JHeader> paramClass, List<HeaderDefinitionError> paramList)
  {
    AnnotatedHeader localAnnotatedHeader = new AnnotatedHeader(paramClass);
    if (paramClass.isAnnotationPresent(Header.class))
    {
      Header localHeader = (Header)paramClass.getAnnotation(Header.class);
      if (!JHeader.class.isAssignableFrom(paramClass)) {
        paramList.add(new HeaderDefinitionError(paramClass, "header must subclass 'JHeader'"));
      }
      if (localHeader.name().length() != 0) {
        localAnnotatedHeader.name = localHeader.name();
      } else {
        localAnnotatedHeader.name = paramClass.getSimpleName();
      }
      if (localHeader.nicname().length() != 0) {
        localAnnotatedHeader.nicname = localHeader.nicname();
      } else {
        localAnnotatedHeader.nicname = localAnnotatedHeader.name;
      }
      if (localHeader.description().length() != 0) {
        localAnnotatedHeader.description = localHeader.description();
      } else if (localHeader.dlt().length != 0) {
        localAnnotatedHeader.description = localHeader.dlt()[0].getDescription();
      } else {
        localAnnotatedHeader.description = null;
      }
      if (localHeader.id() != -1) {
        localHeader.id();
      }
      if (localHeader.parent() != JHeader.class) {
        localAnnotatedHeader.parentClass = localHeader.parent();
      }
      if ((localAnnotatedHeader.parentClass == null) && (paramClass.getEnclosingClass() != null)) {
        for (Class localClass = paramClass.getEnclosingClass(); localClass != null; localClass = localClass.getEnclosingClass()) {
          if (localClass.isAnnotationPresent(Header.class))
          {
            if (!JHeader.class.isAssignableFrom(localClass))
            {
              paramList.add(new HeaderDefinitionError(paramClass, "parentClass header '" + localClass.getSimpleName() + "' must subclass 'JHeader'"));
              break;
            }
            localAnnotatedHeader.parentClass = localClass.asSubclass(JHeader.class);
            break;
          }
        }
      }
    }
    else
    {
      paramList.add(new HeaderDefinitionError(paramClass, "header missing @Header annotation"));
    }
    return localAnnotatedHeader;
  }
  
  public static AnnotatedHeader inspectJHeaderClass(Class<? extends JHeader> paramClass, List<HeaderDefinitionError> paramList)
  {
    if (cache.containsKey(paramClass)) {
      return (AnnotatedHeader)cache.get(paramClass);
    }
    AnnotatedHeader localAnnotatedHeader = inspectHeaderAnnotation(paramClass, paramList);
    ArrayList localArrayList1 = new ArrayList(50);
    ArrayList localArrayList2 = new ArrayList(50);
    ArrayList localArrayList3 = new ArrayList(50);
    ArrayList localArrayList4 = new ArrayList(100);
    HashMap localHashMap = new HashMap(localArrayList1.size());
    for (Object localObject1 = paramClass; localObject1 != Object.class; localObject1 = ((Class)localObject1).getSuperclass()) {
      localArrayList4.addAll(Arrays.asList(((Class)localObject1).getDeclaredMethods()));
    }
    Object localObject2 = localArrayList4.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (Method)((Iterator)localObject2).next();
      if (((Method)localObject3).isAnnotationPresent(Field.class)) {
        localArrayList1.add(localObject3);
      }
      if (((Method)localObject3).isAnnotationPresent(Dynamic.class))
      {
        localArrayList3.add(localObject3);
        ((Method)localObject3).setAccessible(true);
      }
      if (((Method)localObject3).isAnnotationPresent(FieldSetter.class)) {
        localArrayList2.add(localObject3);
      }
    }
    localObject2 = localArrayList1.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (Method)((Iterator)localObject2).next();
      try
      {
        AnnotatedField localAnnotatedField1 = AnnotatedField.inspectMethod(paramClass, (Method)localObject3);
        if (localHashMap.containsKey(localAnnotatedField1.getName())) {
          throw new HeaderDefinitionError(paramClass, "duplicate field " + localAnnotatedField1.getName());
        }
        localHashMap.put(localAnnotatedField1.getName(), localAnnotatedField1);
      }
      catch (HeaderDefinitionError localHeaderDefinitionError1)
      {
        paramList.add(localHeaderDefinitionError1);
      }
    }
    localObject2 = new HashMap();
    Object localObject3 = localArrayList3.iterator();
    while (((Iterator)localObject3).hasNext())
    {
      localObject4 = (Method)((Iterator)localObject3).next();
      try
      {
        AnnotatedFieldMethod localAnnotatedFieldMethod = AnnotatedFieldMethod.inspectMethod((Method)localObject4);
        if (localAnnotatedFieldMethod.method.getParameterTypes().length == 1)
        {
          ((Map)localObject2).put(localAnnotatedFieldMethod.getFunction(), localAnnotatedFieldMethod);
          localAnnotatedFieldMethod.setIsMapped(true);
        }
        else
        {
          AnnotatedField localAnnotatedField2 = (AnnotatedField)localHashMap.get(localAnnotatedFieldMethod.getFieldName());
          if (localAnnotatedField2 == null) {
            throw new HeaderDefinitionError(paramClass, "runtime can not find field " + localAnnotatedFieldMethod.getFieldName());
          }
          localAnnotatedField2.getRuntime().setFunction(localAnnotatedFieldMethod);
        }
      }
      catch (HeaderDefinitionError localHeaderDefinitionError2)
      {
        paramList.add(localHeaderDefinitionError2);
      }
    }
    localObject3 = null;
    Class localClass;
    for (localClass : paramClass.getClasses())
    {
      localObject3 = null;
      if ((localClass.isAnnotationPresent(Field.class)) && (localClass.isEnum()))
      {
        localObject3 = (Field)localClass.getAnnotation(Field.class);
        for (Object localObject6 : localClass.getEnumConstants())
        {
          String str = localObject6.toString().replace('_', '-');
          try
          {
            AnnotatedField localAnnotatedField4 = AnnotatedField.inspectEnumConstant(str, (Field)localObject3, (Map)localObject2, paramClass);
            localHashMap.put(str, localAnnotatedField4);
          }
          catch (AnnotatedMethodException localAnnotatedMethodException2)
          {
            paramList.add(localAnnotatedMethodException2);
          }
        }
      }
    }
    Object localObject4 = localHashMap.values().iterator();
    while (((Iterator)localObject4).hasNext())
    {
      localObject5 = (AnnotatedField)((Iterator)localObject4).next();
      try
      {
        if (((AnnotatedField)localObject5).isSubField())
        {
          if (((AnnotatedField)localObject5).getParent().equals(((AnnotatedField)localObject5).getName())) {
            throw new HeaderDefinitionError(paramClass, "invalid parentClass name for sub-field " + ((AnnotatedField)localObject5).getName());
          }
          AnnotatedField localAnnotatedField3 = (AnnotatedField)localHashMap.get(((AnnotatedField)localObject5).getParent());
          if (localAnnotatedField3 == null) {
            throw new HeaderDefinitionError(paramClass, "can not find parentClass '" + ((AnnotatedField)localObject5).getParent() + "' for sub field '" + ((AnnotatedField)localObject5).getName() + "'");
          }
          localAnnotatedField3.addSubField((AnnotatedField)localObject5);
          ((Iterator)localObject4).remove();
        }
      }
      catch (HeaderDefinitionError localHeaderDefinitionError3)
      {
        paramList.add(localHeaderDefinitionError3);
      }
    }
    localObject4 = localHashMap.values().iterator();
    while (((Iterator)localObject4).hasNext())
    {
      localObject5 = (AnnotatedField)((Iterator)localObject4).next();
      ((AnnotatedField)localObject5).finishProcessing(paramList);
    }
    localObject4 = getSubHeaderClasses(paramClass, paramClass.getSimpleName());
    Object localObject5 = new ArrayList(((List)localObject4).size());
    Iterator localIterator = ((List)localObject4).iterator();
    while (localIterator.hasNext())
    {
      localClass = (Class)localIterator.next();
      if (paramClass != localClass) {
        if (!JSubHeader.class.isAssignableFrom(localClass)) {
          paramList.add(new HeaderDefinitionError(paramClass, "skipping sub-header " + localClass.getSimpleName() + ". The sub-header must subclass JSubHeader class"));
        } else {
          ((List)localObject5).add(inspectJHeaderClass(localClass.asSubclass(JSubHeader.class), paramList));
        }
      }
    }
    localAnnotatedHeader.saveSubHeaders((AnnotatedHeader[])((List)localObject5).toArray(new AnnotatedHeader[((List)localObject5).size()]));
    localAnnotatedHeader.saveFields((AnnotatedField[])localHashMap.values().toArray(new AnnotatedField[localHashMap.size()]));
    try
    {
      AnnotatedHeaderLengthMethod.inspectClass(paramClass);
    }
    catch (AnnotatedMethodException localAnnotatedMethodException1)
    {
      paramList.add(new HeaderDefinitionError(paramClass, localAnnotatedMethodException1));
    }
    if (paramList.isEmpty()) {
      cache.put(paramClass, localAnnotatedHeader);
    }
    return localAnnotatedHeader;
  }
  
  private AnnotatedHeader(Class<? extends JHeader> paramClass)
  {
    this.annotation = ((Header)paramClass.getAnnotation(Header.class));
    this.clazz = paramClass;
  }
  
  public AnnotatedField[] getFields()
  {
    return this.fields;
  }
  
  public Class<? extends JHeader> getHeaderClass()
  {
    return this.clazz;
  }
  
  public final AnnotatedHeader[] getHeaders()
  {
    return this.headers;
  }
  
  public int getId()
  {
    return this.annotation.id();
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public PcapDLT[] getDlt()
  {
    return this.annotation.dlt();
  }
  
  public JProtocol.Suite getSuite()
  {
    return this.annotation.suite();
  }
  
  public final String getNicname()
  {
    return this.nicname;
  }
  
  private void saveFields(AnnotatedField[] paramArrayOfAnnotatedField)
  {
    this.fields = paramArrayOfAnnotatedField;
  }
  
  private void saveSubHeaders(AnnotatedHeader[] paramArrayOfAnnotatedHeader)
  {
    this.headers = paramArrayOfAnnotatedHeader;
    for (AnnotatedHeader localAnnotatedHeader : paramArrayOfAnnotatedHeader) {
      localAnnotatedHeader.setParent(this);
    }
  }
  
  public final AnnotatedHeader getParent()
  {
    return this.parent;
  }
  
  public boolean isSubHeader()
  {
    return this.parent != null;
  }
  
  private void setParent(AnnotatedHeader paramAnnotatedHeader)
  {
    this.parent = paramAnnotatedHeader;
  }
  
  public String getDescription()
  {
    return this.description;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedHeader
 * JD-Core Version:    0.7.0.1
 */