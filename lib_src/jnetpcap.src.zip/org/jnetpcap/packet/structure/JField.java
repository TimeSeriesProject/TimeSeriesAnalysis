package org.jnetpcap.packet.structure;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.format.JFormatter.Priority;
import org.jnetpcap.packet.format.JFormatter.Style;

public class JField
{
  private static final JFieldComp SORT_BY_OFFSET = new JFieldComp(null);
  protected JField[] subFields;
  private final String name;
  private final String nicname;
  private JField parent;
  private final JFormatter.Priority priority;
  protected JFormatter.Style style;
  private final AnnotatedFieldMethod value;
  private final AnnotatedFieldMethod offset;
  private final AnnotatedFieldMethod length;
  private final AnnotatedFieldMethod display;
  private final AnnotatedFieldMethod description;
  private final AnnotatedFieldMethod mask;
  private final AnnotatedFieldMethod check;
  private AnnotatedFieldMethod units;
  
  public static void sortFieldByOffset(JField[] paramArrayOfJField, JHeader paramJHeader, boolean paramBoolean)
  {
    SORT_BY_OFFSET.setAscending(paramBoolean);
    SORT_BY_OFFSET.setHeader(paramJHeader);
    Arrays.sort(paramArrayOfJField, SORT_BY_OFFSET);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("name=").append(this.name);
    localStringBuilder.append(", nicname=").append(this.nicname);
    localStringBuilder.append(", parent=").append(this.parent);
    localStringBuilder.append(", priority=").append(this.priority);
    localStringBuilder.append(", style=").append(this.style);
    return localStringBuilder.toString();
  }
  
  public JField(AnnotatedField paramAnnotatedField, JField[] paramArrayOfJField)
  {
    this.subFields = paramArrayOfJField;
    this.priority = paramAnnotatedField.getPriority();
    this.name = paramAnnotatedField.getName();
    this.nicname = paramAnnotatedField.getNicname();
    paramAnnotatedField.getDisplay();
    paramAnnotatedField.getUnits();
    this.style = paramAnnotatedField.getStyle();
    this.value = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.VALUE));
    this.offset = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.OFFSET));
    this.length = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.LENGTH));
    this.display = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.DISPLAY));
    this.description = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.DESCRIPTION));
    this.mask = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.MASK));
    this.check = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.CHECK));
    this.units = ((AnnotatedFieldMethod)paramAnnotatedField.getRuntime().getFunctionMap().get(Field.Property.UNITS));
    for (JField localJField : this.subFields) {
      localJField.setParent(this);
    }
  }
  
  public JField[] getSubFields()
  {
    return this.subFields;
  }
  
  public final String getName()
  {
    return this.name;
  }
  
  public String getNicname()
  {
    return this.nicname;
  }
  
  public final JField getParent()
  {
    return this.parent;
  }
  
  public JFormatter.Priority getPriority()
  {
    return this.priority;
  }
  
  public JFormatter.Style getStyle()
  {
    return this.style;
  }
  
  public boolean hasSubFields()
  {
    return this.subFields.length != 0;
  }
  
  public final void setParent(JField paramJField)
  {
    this.parent = paramJField;
  }
  
  public void setStyle(JFormatter.Style paramStyle)
  {
    this.style = paramStyle;
  }
  
  public String getUnits(JHeader paramJHeader)
  {
    return this.units.stringMethod(paramJHeader, this.name);
  }
  
  public boolean hasField(JHeader paramJHeader)
  {
    return this.check.booleanMethod(paramJHeader, this.name);
  }
  
  public String getDisplay(JHeader paramJHeader)
  {
    return this.display.stringMethod(paramJHeader, this.name);
  }
  
  public int getLength(JHeader paramJHeader)
  {
    return this.length.intMethod(paramJHeader, this.name);
  }
  
  public long getMask(JHeader paramJHeader)
  {
    return this.mask.longMethod(paramJHeader, this.name);
  }
  
  public int getOffset(JHeader paramJHeader)
  {
    return this.offset.intMethod(paramJHeader, this.name);
  }
  
  public String getValueDescription(JHeader paramJHeader)
  {
    return this.description.stringMethod(paramJHeader, this.name);
  }
  
  public <T> T getValue(Class<T> paramClass, JHeader paramJHeader)
  {
    return this.value.objectMethod(paramJHeader, this.name);
  }
  
  public Object getValue(JHeader paramJHeader)
  {
    return this.value.objectMethod(paramJHeader, this.name);
  }
  
  public long longValue(JHeader paramJHeader)
  {
    Object localObject = getValue(paramJHeader);
    if ((localObject instanceof Number)) {
      return ((Number)localObject).longValue();
    }
    if ((localObject instanceof Boolean)) {
      return ((Boolean)localObject).booleanValue() ? 1L : 0L;
    }
    if ((localObject instanceof String)) {
      return Long.parseLong(localObject.toString());
    }
    throw new IllegalStateException("unknown format encountered");
  }
  
  private static class JFieldComp
    implements Comparator<JField>
  {
    private JHeader header;
    private boolean ascending = true;
    
    public int compare(JField paramJField1, JField paramJField2)
    {
      if (this.ascending) {
        return paramJField1.getOffset(this.header) - paramJField2.getOffset(this.header);
      }
      return paramJField2.getOffset(this.header) - paramJField1.getOffset(this.header);
    }
    
    public void setHeader(JHeader paramJHeader)
    {
      this.header = paramJHeader;
    }
    
    public void setAscending(boolean paramBoolean)
    {
      this.ascending = paramBoolean;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.JField
 * JD-Core Version:    0.7.0.1
 */