package org.jnetpcap.packet.structure;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Header;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.packet.annotate.HeaderLength.Type;

public class AnnotatedHeaderLengthMethod
  extends AnnotatedMethod
{
  private static final Map<Class<?>, AnnotatedHeaderLengthMethod[]> cache = new HashMap();
  private int staticLength;
  private final HeaderLength.Type type;
  
  public static AnnotatedHeaderLengthMethod[] inspectClass(Class<? extends JHeader> paramClass)
  {
    if (cache.containsKey(paramClass)) {
      return (AnnotatedHeaderLengthMethod[])cache.get(paramClass);
    }
    AnnotatedHeaderLengthMethod[] arrayOfAnnotatedHeaderLengthMethod = new AnnotatedHeaderLengthMethod[HeaderLength.Type.values().length];
    Header localHeader = (Header)paramClass.getAnnotation(Header.class);
    if ((localHeader != null) && (localHeader.length() != -1)) {
      arrayOfAnnotatedHeaderLengthMethod[HeaderLength.Type.HEADER.ordinal()] = new AnnotatedHeaderLengthMethod(paramClass, localHeader.length(), HeaderLength.Type.HEADER);
    }
    if ((localHeader != null) && (localHeader.prefix() != -1)) {
      arrayOfAnnotatedHeaderLengthMethod[HeaderLength.Type.PREFIX.ordinal()] = new AnnotatedHeaderLengthMethod(paramClass, localHeader.prefix(), HeaderLength.Type.PREFIX);
    }
    if ((localHeader != null) && (localHeader.gap() != -1)) {
      arrayOfAnnotatedHeaderLengthMethod[HeaderLength.Type.GAP.ordinal()] = new AnnotatedHeaderLengthMethod(paramClass, localHeader.gap(), HeaderLength.Type.GAP);
    }
    if ((localHeader != null) && (localHeader.payload() != -1)) {
      arrayOfAnnotatedHeaderLengthMethod[HeaderLength.Type.PAYLOAD.ordinal()] = new AnnotatedHeaderLengthMethod(paramClass, localHeader.payload(), HeaderLength.Type.PAYLOAD);
    }
    if ((localHeader != null) && (localHeader.postfix() != -1)) {
      arrayOfAnnotatedHeaderLengthMethod[HeaderLength.Type.POSTFIX.ordinal()] = new AnnotatedHeaderLengthMethod(paramClass, localHeader.postfix(), HeaderLength.Type.POSTFIX);
    }
    for (Method localMethod : getMethods(paramClass, HeaderLength.class))
    {
      HeaderLength localHeaderLength = (HeaderLength)localMethod.getAnnotation(HeaderLength.class);
      if (arrayOfAnnotatedHeaderLengthMethod[localHeaderLength.value().ordinal()] != null) {
        throw new AnnotatedMethodException(paramClass, "duplicate: " + arrayOfAnnotatedHeaderLengthMethod[localHeaderLength.value().ordinal()] + " property and " + localMethod.getName() + "() method");
      }
      checkSignature(localMethod);
      arrayOfAnnotatedHeaderLengthMethod[localHeaderLength.value().ordinal()] = new AnnotatedHeaderLengthMethod(localMethod, localHeaderLength.value());
    }
    if (arrayOfAnnotatedHeaderLengthMethod[HeaderLength.Type.HEADER.ordinal()] == null) {
      throw new AnnotatedMethodException(paramClass, "@HeaderLength annotated method not found");
    }
    cache.put(paramClass, arrayOfAnnotatedHeaderLengthMethod);
    return arrayOfAnnotatedHeaderLengthMethod;
  }
  
  private AnnotatedHeaderLengthMethod(Method paramMethod, HeaderLength.Type paramType)
  {
    super(paramMethod);
    this.type = paramType;
    this.staticLength = -1;
  }
  
  public AnnotatedHeaderLengthMethod(Class<? extends JHeader> paramClass, int paramInt, HeaderLength.Type paramType)
  {
    this.staticLength = paramInt;
    this.type = paramType;
  }
  
  public int getHeaderLength(JBuffer paramJBuffer, int paramInt)
  {
    if (this.staticLength != -1) {
      return this.staticLength;
    }
    try
    {
      int i = ((Integer)this.method.invoke(null, new Object[] { paramJBuffer, Integer.valueOf(paramInt) })).intValue();
      return i;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new IllegalStateException(localIllegalArgumentException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalStateException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException.getCause());
    }
  }
  
  public final Method getMethod()
  {
    return this.method;
  }
  
  public boolean hasStaticLength()
  {
    return this.staticLength != -1;
  }
  
  protected void validateSignature(Method paramMethod)
  {
    checkSignature(paramMethod);
  }
  
  private static void checkSignature(Method paramMethod)
  {
    Class localClass = paramMethod.getDeclaringClass();
    if (!paramMethod.isAnnotationPresent(HeaderLength.class)) {
      throw new AnnotatedMethodException(localClass, "@HeaderLength annotation missing for " + paramMethod.getName() + "()");
    }
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    if ((arrayOfClass.length != 2) || (arrayOfClass[0] != JBuffer.class) || (arrayOfClass[1] != Integer.TYPE) || (paramMethod.getReturnType() != Integer.TYPE)) {
      throw new AnnotatedMethodException(localClass, "Invalid signature for " + paramMethod.getName() + "()");
    }
    if ((paramMethod.getModifiers() & 0x8) == 0) {
      throw new AnnotatedMethodException(localClass, paramMethod.getName() + "()" + " must be declared static");
    }
  }
  
  public static void clearCache()
  {
    cache.clear();
  }
  
  public String toString()
  {
    if (this.method == null)
    {
      String str = this.type == HeaderLength.Type.HEADER ? "length" : this.type.toString().toLowerCase();
      return "@Header(" + str + "=" + this.staticLength + ")";
    }
    return super.toString();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedHeaderLengthMethod
 * JD-Core Version:    0.7.0.1
 */