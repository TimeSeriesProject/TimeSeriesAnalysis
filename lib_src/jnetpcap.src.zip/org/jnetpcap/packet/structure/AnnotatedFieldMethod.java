package org.jnetpcap.packet.structure;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.annotate.FieldDefinitionException;

public abstract class AnnotatedFieldMethod
  extends AnnotatedMethod
{
  protected final String field;
  protected final Field.Property function;
  
  public static void checkAnnotation(Method paramMethod, List<AnnotatedField> paramList)
  {
    Dynamic localDynamic = (Dynamic)paramMethod.getAnnotation(Dynamic.class);
    if (localDynamic.field().length() != 0)
    {
      int i = 0;
      String str = localDynamic.field();
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        AnnotatedField localAnnotatedField = (AnnotatedField)localIterator.next();
        if (localAnnotatedField.getName().equals(str))
        {
          i = 1;
          break;
        }
      }
      if (i == 0) {
        throw new HeaderDefinitionError("field name defined in annotation ");
      }
    }
  }
  
  private static void checkSignature(Method paramMethod, Class<?> paramClass)
  {
    Class localClass = paramMethod.getDeclaringClass();
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    if (((arrayOfClass.length == 1) && (arrayOfClass[0] != String.class)) || (arrayOfClass.length > 1) || (paramMethod.getReturnType() != paramClass)) {
      throw new AnnotatedMethodException(localClass, "Invalid signature for " + paramMethod.getName() + "()");
    }
    if ((paramMethod.getModifiers() & 0x8) != 0) {
      throw new AnnotatedMethodException(localClass, paramMethod.getName() + "()" + " can not be declared static");
    }
  }
  
  public static AnnotatedFieldMethod generateFunction(Field.Property paramProperty, AnnotatedField paramAnnotatedField)
  {
    switch (1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[paramProperty.ordinal()])
    {
    case 2: 
    case 3: 
      return new IntFunction(paramAnnotatedField, paramProperty);
    case 4: 
      return new LongFunction(paramAnnotatedField, paramProperty);
    case 5: 
      return new ObjectFunction(paramAnnotatedField, paramProperty);
    case 1: 
      return new BooleanFunction(paramAnnotatedField, paramProperty);
    case 6: 
    case 7: 
    case 8: 
      return new StringFunction(paramAnnotatedField, paramProperty);
    }
    throw new HeaderDefinitionError("Unsupported Dynamic function type " + paramProperty.toString());
  }
  
  private static String guessFieldName(String paramString)
  {
    if (paramString.startsWith("has"))
    {
      String str = paramString.replace("has", "");
      char c1 = str.charAt(0);
      char c2 = Character.toLowerCase(c1);
      return str.replace(c1, c2);
    }
    if (paramString.endsWith("Description")) {
      return paramString.replace("Description", "");
    }
    if (paramString.endsWith("Offset")) {
      return paramString.replace("Offset", "");
    }
    if (paramString.endsWith("Length")) {
      return paramString.replace("Length", "");
    }
    if (paramString.endsWith("Mask")) {
      return paramString.replace("Mask", "");
    }
    if (paramString.endsWith("Value")) {
      return paramString.replace("Value", "");
    }
    if (paramString.endsWith("Display")) {
      return paramString.replace("Display", "");
    }
    if (paramString.endsWith("Units")) {
      return paramString.replace("Units", "");
    }
    if (paramString.endsWith("Format")) {
      return paramString.replace("Format", "");
    }
    return paramString;
  }
  
  public static AnnotatedFieldMethod inspectMethod(Method paramMethod)
  {
    Dynamic localDynamic = (Dynamic)paramMethod.getAnnotation(Dynamic.class);
    Field.Property localProperty = localDynamic.value();
    switch (1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[localProperty.ordinal()])
    {
    case 2: 
    case 3: 
      checkSignature(paramMethod, Integer.TYPE);
      return new IntFunction(paramMethod, localProperty);
    case 4: 
      checkSignature(paramMethod, Long.TYPE);
      return new LongFunction(paramMethod, localProperty);
    case 5: 
      checkSignature(paramMethod, Object.class);
      return new ObjectFunction(paramMethod, localProperty);
    case 1: 
      checkSignature(paramMethod, Boolean.TYPE);
      return new BooleanFunction(paramMethod, localProperty);
    case 7: 
    case 8: 
      checkSignature(paramMethod, String.class);
      return new StringFunction(paramMethod, localProperty);
    }
    throw new HeaderDefinitionError("Unsupported Dynamic function type " + localProperty.toString());
  }
  
  public AnnotatedFieldMethod(AnnotatedField paramAnnotatedField, Field.Property paramProperty)
  {
    this.function = paramProperty;
    this.field = paramAnnotatedField.getName();
  }
  
  public AnnotatedFieldMethod(AnnotatedField paramAnnotatedField, Field.Property paramProperty, Method paramMethod)
  {
    super(paramMethod);
    this.function = paramProperty;
    this.field = paramAnnotatedField.getName();
  }
  
  public AnnotatedFieldMethod(Method paramMethod, Field.Property paramProperty)
  {
    super(paramMethod);
    this.function = paramProperty;
    Dynamic localDynamic = (Dynamic)paramMethod.getAnnotation(Dynamic.class);
    if (localDynamic == null) {
      throw new HeaderDefinitionError(paramMethod.getDeclaringClass(), "unable get field's annotated runtime");
    }
    if (localDynamic.field().length() != 0) {
      this.field = localDynamic.field();
    } else {
      this.field = guessFieldName(paramMethod.getName());
    }
  }
  
  public boolean booleanMethod(JHeader paramJHeader, String paramString)
  {
    throw new UnsupportedOperationException("this return type is invalid for this function type");
  }
  
  public abstract void configFromField(AnnotatedField paramAnnotatedField);
  
  public String getFieldName()
  {
    return this.field;
  }
  
  public final Field.Property getFunction()
  {
    return this.function;
  }
  
  public int intMethod(JHeader paramJHeader, String paramString)
  {
    throw new UnsupportedOperationException("this return type is invalid for this function type");
  }
  
  public Object objectMethod(JHeader paramJHeader, String paramString)
  {
    throw new UnsupportedOperationException("this return type is invalid for this function type");
  }
  
  public String stringMethod(JHeader paramJHeader, String paramString)
  {
    throw new UnsupportedOperationException("this return type is invalid for this function type");
  }
  
  protected void validateSignature(Method paramMethod) {}
  
  public long longMethod(JHeader paramJHeader, String paramString)
  {
    throw new UnsupportedOperationException("this return type is invalid for this function type");
  }
  
  private static class StringFunction
    extends AnnotatedFieldMethod
  {
    private boolean hasStaticValue = false;
    private String value;
    
    public StringFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty)
    {
      super(paramProperty);
      configFromField(paramAnnotatedField);
    }
    
    public StringFunction(Method paramMethod, Field.Property paramProperty)
    {
      super(paramProperty);
    }
    
    public final void configFromField(AnnotatedField paramAnnotatedField)
    {
      switch (AnnotatedFieldMethod.1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[this.function.ordinal()])
      {
      case 6: 
        if (paramAnnotatedField.getUnits().length() != 0) {
          setValue(paramAnnotatedField.getUnits());
        } else if (this.method == null) {
          setValue(null);
        }
        break;
      case 7: 
        if (paramAnnotatedField.getDisplay().length() != 0) {
          setValue(paramAnnotatedField.getDisplay());
        } else if (this.method == null) {
          setValue(null);
        }
        break;
      case 8: 
        if (paramAnnotatedField.getDescription().length() != 0) {
          setValue(paramAnnotatedField.getDescription());
        } else if (this.method == null) {
          setValue(null);
        }
        break;
      default: 
        throw new HeaderDefinitionError("Invalid Dynamic function type " + this.function.toString());
      }
      if ((!this.hasStaticValue) && (this.method == null)) {
        throw new FieldDefinitionException(paramAnnotatedField, "Missing '" + this.function.name().toLowerCase() + "' property. [@Field(" + this.function.name().toLowerCase() + "=<string>) or @Dynamic(Property." + this.function.name() + ")]");
      }
    }
    
    public String execute(JHeader paramJHeader, String paramString)
    {
      if (this.hasStaticValue) {
        return this.value;
      }
      try
      {
        if (this.isMapped) {
          return (String)this.method.invoke(paramJHeader, new Object[] { paramString });
        }
        return (String)this.method.invoke(paramJHeader, new Object[0]);
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new IllegalStateException(localIllegalArgumentException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new IllegalStateException(localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException);
      }
    }
    
    private void setValue(String paramString)
    {
      this.hasStaticValue = true;
      this.value = paramString;
    }
    
    public String stringMethod(JHeader paramJHeader, String paramString)
    {
      return execute(paramJHeader, paramString);
    }
  }
  
  private static class ObjectFunction
    extends AnnotatedFieldMethod
  {
    public ObjectFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty)
    {
      super(paramProperty, paramAnnotatedField.getMethod());
    }
    
    public ObjectFunction(Method paramMethod, Field.Property paramProperty)
    {
      super(paramProperty);
    }
    
    public final void configFromField(AnnotatedField paramAnnotatedField)
    {
      switch (AnnotatedFieldMethod.1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[this.function.ordinal()])
      {
      case 5: 
        if (this.method == null) {
          throw new HeaderDefinitionError(paramAnnotatedField.getDeclaringClass(), "no method set for field value getter [" + paramAnnotatedField.getName() + "]");
        }
        break;
      default: 
        throw new HeaderDefinitionError(paramAnnotatedField.getDeclaringClass(), "Invalid Dynamic function type " + this.function.toString());
      }
      if (this.method == null) {
        throw new FieldDefinitionException(paramAnnotatedField, "Missing field accessor '" + this.function.name().toLowerCase() + "' property. [@Dynamic(Property." + this.function.name() + ")]");
      }
    }
    
    public Object execute(JHeader paramJHeader, String paramString)
    {
      try
      {
        if (this.isMapped) {
          return this.method.invoke(paramJHeader, new Object[] { paramString });
        }
        return this.method.invoke(paramJHeader, new Object[0]);
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new IllegalStateException(localIllegalArgumentException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new IllegalStateException(localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException.getMessage(), localInvocationTargetException);
      }
    }
    
    public Object objectMethod(JHeader paramJHeader, String paramString)
    {
      return execute(paramJHeader, paramString);
    }
  }
  
  private static class LongFunction
    extends AnnotatedFieldMethod
  {
    private boolean hasStaticValue = false;
    private long value;
    
    public LongFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty)
    {
      super(paramProperty);
      configFromField(paramAnnotatedField);
    }
    
    public LongFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty, long paramLong)
    {
      super(paramProperty);
      setValue(paramLong);
    }
    
    public LongFunction(Method paramMethod, Field.Property paramProperty)
    {
      super(paramProperty);
    }
    
    public final void configFromField(AnnotatedField paramAnnotatedField)
    {
      switch (AnnotatedFieldMethod.1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[this.function.ordinal()])
      {
      case 4: 
        setValue(paramAnnotatedField.getMask());
        break;
      default: 
        throw new HeaderDefinitionError("Invalid Dynamic function type " + this.function.toString());
      }
      if ((!this.hasStaticValue) && (this.method == null)) {
        throw new FieldDefinitionException(paramAnnotatedField, "Missing '" + this.function.name().toLowerCase() + "' property. [@Field(" + this.function.name().toLowerCase() + "=<int>) or @Dynamic(Property." + this.function.name() + ")]");
      }
    }
    
    public long execute(JHeader paramJHeader, String paramString)
    {
      if (this.hasStaticValue) {
        return this.value;
      }
      try
      {
        if (this.isMapped) {
          return ((Long)this.method.invoke(paramJHeader, new Object[] { paramString })).longValue();
        }
        return ((Long)this.method.invoke(paramJHeader, new Object[0])).longValue();
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new IllegalStateException(localIllegalArgumentException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new IllegalStateException(localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException);
      }
    }
    
    public long longMethod(JHeader paramJHeader, String paramString)
    {
      return execute(paramJHeader, paramString);
    }
    
    private void setValue(long paramLong)
    {
      this.hasStaticValue = true;
      this.value = paramLong;
    }
  }
  
  private static class IntFunction
    extends AnnotatedFieldMethod
  {
    private boolean hasStaticValue = false;
    private int value;
    
    public IntFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty)
    {
      super(paramProperty);
      configFromField(paramAnnotatedField);
    }
    
    public IntFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty, int paramInt)
    {
      super(paramProperty);
      setValue(paramInt);
    }
    
    public IntFunction(Method paramMethod, Field.Property paramProperty)
    {
      super(paramProperty);
    }
    
    public final void configFromField(AnnotatedField paramAnnotatedField)
    {
      switch (AnnotatedFieldMethod.1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[this.function.ordinal()])
      {
      case 2: 
        if (paramAnnotatedField.getLength() != -1) {
          setValue(paramAnnotatedField.getLength());
        }
        break;
      case 3: 
        if (paramAnnotatedField.getOffset() != -1) {
          setValue(paramAnnotatedField.getOffset());
        }
        break;
      default: 
        throw new HeaderDefinitionError("Invalid Dynamic function type " + this.function.toString());
      }
      if ((!this.hasStaticValue) && (this.method == null)) {
        throw new FieldDefinitionException(paramAnnotatedField, "Missing '" + this.function.name().toLowerCase() + "' property. [@Field(" + this.function.name().toLowerCase() + "=<int>) or @Dynamic(Property." + this.function.name() + ")]");
      }
    }
    
    public int execute(JHeader paramJHeader, String paramString)
    {
      if (this.hasStaticValue) {
        return this.value;
      }
      try
      {
        if (this.isMapped) {
          return ((Integer)this.method.invoke(paramJHeader, new Object[] { paramString })).intValue();
        }
        return ((Integer)this.method.invoke(paramJHeader, new Object[0])).intValue();
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new IllegalStateException(localIllegalArgumentException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new IllegalStateException(localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException);
      }
    }
    
    public int intMethod(JHeader paramJHeader, String paramString)
    {
      return execute(paramJHeader, paramString);
    }
    
    private void setValue(int paramInt)
    {
      this.hasStaticValue = true;
      this.value = paramInt;
    }
  }
  
  private static class BooleanFunction
    extends AnnotatedFieldMethod
  {
    private boolean hasStaticValue = false;
    private boolean value;
    
    public BooleanFunction(AnnotatedField paramAnnotatedField, Field.Property paramProperty)
    {
      super(paramProperty);
      setValue(true);
    }
    
    public BooleanFunction(Method paramMethod, Field.Property paramProperty)
    {
      super(paramProperty);
    }
    
    public boolean booleanMethod(JHeader paramJHeader, String paramString)
    {
      return execute(paramJHeader, paramString);
    }
    
    public final void configFromField(AnnotatedField paramAnnotatedField)
    {
      switch (AnnotatedFieldMethod.1.$SwitchMap$org$jnetpcap$packet$annotate$Field$Property[this.function.ordinal()])
      {
      case 1: 
        break;
      default: 
        throw new HeaderDefinitionError("Invalid Dynamic function type " + this.function.toString());
      }
      if ((!this.hasStaticValue) && (this.method == null)) {
        throw new FieldDefinitionException(paramAnnotatedField, "Missing '" + this.function.name().toLowerCase() + "' property. [@Dynamic(Property." + this.function.name() + ")]");
      }
    }
    
    public boolean execute(JHeader paramJHeader, String paramString)
    {
      if (this.hasStaticValue) {
        return this.value;
      }
      try
      {
        if (this.isMapped) {
          return ((Boolean)this.method.invoke(paramJHeader, new Object[] { paramString })).booleanValue();
        }
        return ((Boolean)this.method.invoke(paramJHeader, new Object[0])).booleanValue();
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new IllegalStateException(localIllegalArgumentException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new IllegalStateException(localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException);
      }
    }
    
    private void setValue(boolean paramBoolean)
    {
      this.hasStaticValue = true;
      this.value = paramBoolean;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedFieldMethod
 * JD-Core Version:    0.7.0.1
 */