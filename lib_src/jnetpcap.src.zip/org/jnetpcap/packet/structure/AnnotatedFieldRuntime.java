package org.jnetpcap.packet.structure;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jnetpcap.packet.annotate.Field.Property;

public class AnnotatedFieldRuntime
{
  private final Map<Field.Property, AnnotatedFieldMethod> map = new HashMap();
  private final AnnotatedField parent;
  
  public AnnotatedFieldRuntime(AnnotatedField paramAnnotatedField)
  {
    this.parent = paramAnnotatedField;
  }
  
  public void finishProcessing(List<HeaderDefinitionError> paramList)
  {
    for (Field.Property localProperty : ) {
      try
      {
        if (!this.map.containsKey(localProperty)) {
          this.map.put(localProperty, AnnotatedFieldMethod.generateFunction(localProperty, this.parent));
        }
      }
      catch (HeaderDefinitionError localHeaderDefinitionError)
      {
        paramList.add(localHeaderDefinitionError);
      }
    }
  }
  
  public Map<Field.Property, AnnotatedFieldMethod> getFunctionMap()
  {
    return this.map;
  }
  
  public void setFunction(AnnotatedFieldMethod paramAnnotatedFieldMethod)
  {
    Field.Property localProperty = paramAnnotatedFieldMethod.getFunction();
    if (this.map.containsKey(localProperty)) {
      throw new HeaderDefinitionError(paramAnnotatedFieldMethod.getMethod().getDeclaringClass(), "duplicate " + localProperty + " method declarations for field " + this.parent.getName());
    }
    if (!paramAnnotatedFieldMethod.isMapped) {
      paramAnnotatedFieldMethod.configFromField(this.parent);
    }
    this.map.put(localProperty, paramAnnotatedFieldMethod);
  }
  
  public void setFunction(Map<Field.Property, AnnotatedFieldMethod> paramMap)
  {
    Iterator localIterator = paramMap.values().iterator();
    while (localIterator.hasNext())
    {
      AnnotatedFieldMethod localAnnotatedFieldMethod = (AnnotatedFieldMethod)localIterator.next();
      setFunction(localAnnotatedFieldMethod);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedFieldRuntime
 * JD-Core Version:    0.7.0.1
 */