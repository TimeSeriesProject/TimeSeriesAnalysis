package org.jnetpcap.packet.structure;

import java.util.Iterator;
import java.util.List;

public class DefaultField
  extends JField
{
  private DefaultField(AnnotatedField paramAnnotatedField, DefaultField[] paramArrayOfDefaultField)
  {
    super(paramAnnotatedField, paramArrayOfDefaultField);
  }
  
  public static DefaultField fromAnnotatedField(AnnotatedField paramAnnotatedField)
  {
    DefaultField[] arrayOfDefaultField = new DefaultField[paramAnnotatedField.getSubFields().size()];
    int i = 0;
    Iterator localIterator = paramAnnotatedField.getSubFields().iterator();
    while (localIterator.hasNext())
    {
      AnnotatedField localAnnotatedField = (AnnotatedField)localIterator.next();
      arrayOfDefaultField[(i++)] = fromAnnotatedField(localAnnotatedField);
    }
    JField.sortFieldByOffset(arrayOfDefaultField, null, false);
    return new DefaultField(paramAnnotatedField, arrayOfDefaultField);
  }
  
  public static JField[] fromAnnotatedFields(AnnotatedField[] paramArrayOfAnnotatedField)
  {
    JField[] arrayOfJField = new JField[paramArrayOfAnnotatedField.length];
    for (int i = 0; i < paramArrayOfAnnotatedField.length; i++) {
      arrayOfJField[i] = fromAnnotatedField(paramArrayOfAnnotatedField[i]);
    }
    return arrayOfJField;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.DefaultField
 * JD-Core Version:    0.7.0.1
 */