package org.jnetpcap.packet.structure;

public class HeaderDefinitionError
  extends RuntimeException
{
  private static final long serialVersionUID = -1034165417637411714L;
  private final Class<?> c;
  
  public HeaderDefinitionError(Class<?> paramClass)
  {
    this.c = paramClass;
  }
  
  public HeaderDefinitionError(String paramString)
  {
    super(paramString);
    this.c = null;
  }
  
  public HeaderDefinitionError(Class<?> paramClass, String paramString)
  {
    super(paramString);
    this.c = paramClass;
  }
  
  public HeaderDefinitionError(Throwable paramThrowable)
  {
    super(paramThrowable);
    this.c = null;
  }
  
  public HeaderDefinitionError(Class<?> paramClass, Throwable paramThrowable)
  {
    super(paramThrowable);
    this.c = paramClass;
  }
  
  public HeaderDefinitionError(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
    this.c = null;
  }
  
  public HeaderDefinitionError(Class<?> paramClass, String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
    this.c = paramClass;
  }
  
  public Class<?> getHeader()
  {
    return this.c;
  }
  
  public String getMessage()
  {
    if (this.c != null) {
      return "[" + getPath() + "] " + super.getMessage();
    }
    return super.getMessage();
  }
  
  protected String getPath()
  {
    String str = "";
    for (Class localClass = this.c; localClass != null; localClass = localClass.getEnclosingClass()) {
      str = localClass.getSimpleName() + "." + str;
    }
    return str;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.HeaderDefinitionError
 * JD-Core Version:    0.7.0.1
 */