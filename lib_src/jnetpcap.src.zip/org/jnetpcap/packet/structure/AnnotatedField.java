package org.jnetpcap.packet.structure;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.annotate.Field;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.format.JFormatter.Priority;
import org.jnetpcap.packet.format.JFormatter.Style;

public class AnnotatedField
{
  private final Field annotation;
  private final Class<?> declaringClass;
  private final Method method;
  private final AnnotatedFieldRuntime runtime;
  private final List<AnnotatedField> subFields = new ArrayList();
  private String name;
  
  private static void checkSingature(Class<? extends JHeader> paramClass, Method paramMethod)
  {
    if (!paramMethod.isAnnotationPresent(Field.class)) {
      throw new AnnotatedMethodException(paramClass, "missing @Field annotation on field " + paramMethod.getName());
    }
  }
  
  public static AnnotatedField inspectEnumConstant(String paramString, Field paramField, Map<Field.Property, AnnotatedFieldMethod> paramMap, Class<?> paramClass)
  {
    if (!paramMap.containsKey(Field.Property.VALUE)) {
      throw new AnnotatedMethodException(paramClass, "missing value getter method for field based on enum constant: " + paramString);
    }
    if (!paramMap.containsKey(Field.Property.LENGTH)) {
      throw new AnnotatedMethodException(paramClass, "missing length getter method for field based on enum constant: " + paramString);
    }
    if (!paramMap.containsKey(Field.Property.OFFSET)) {
      throw new AnnotatedMethodException(paramClass, "missing offset getter method for field based on enum constant: " + paramString);
    }
    return new AnnotatedField(paramString, paramField, paramMap, paramClass);
  }
  
  public static AnnotatedField inspectMethod(Class<? extends JHeader> paramClass, Method paramMethod)
  {
    checkSingature(paramClass, paramMethod);
    AnnotatedField localAnnotatedField = new AnnotatedField(paramMethod);
    return localAnnotatedField;
  }
  
  private static JFormatter.Style mapFormatToStyle(String paramString)
  {
    if (paramString.contains("%s[]")) {
      return JFormatter.Style.STRING_ARRAY;
    }
    if (paramString.contains("%s")) {
      return JFormatter.Style.STRING;
    }
    if (paramString.contains("%b")) {
      return JFormatter.Style.BOOLEAN;
    }
    if (paramString.contains("%d")) {
      return JFormatter.Style.INT_DEC;
    }
    if (paramString.contains("%x")) {
      return JFormatter.Style.INT_HEX;
    }
    if (paramString.contains("#ip4#")) {
      return JFormatter.Style.BYTE_ARRAY_IP4_ADDRESS;
    }
    if (paramString.contains("#ip4[]#")) {
      return JFormatter.Style.BYTE_ARRAY_ARRAY_IP4_ADDRESS;
    }
    if (paramString.contains("#ip6#")) {
      return JFormatter.Style.BYTE_ARRAY_IP6_ADDRESS;
    }
    if (paramString.contains("#mac#")) {
      return JFormatter.Style.BYTE_ARRAY_COLON_ADDRESS;
    }
    if (paramString.contains("#hexdump#")) {
      return JFormatter.Style.BYTE_ARRAY_HEX_DUMP;
    }
    if (paramString.contains("#textdump#")) {
      return JFormatter.Style.STRING_TEXT_DUMP;
    }
    if (paramString.contains("#bitfield#")) {
      return JFormatter.Style.INT_BITS;
    }
    return JFormatter.Style.STRING;
  }
  
  private AnnotatedField(Method paramMethod)
  {
    this.method = paramMethod;
    this.annotation = ((Field)paramMethod.getAnnotation(Field.class));
    this.runtime = new AnnotatedFieldRuntime(this);
    this.declaringClass = paramMethod.getDeclaringClass();
  }
  
  public AnnotatedField(String paramString, Field paramField, Map<Field.Property, AnnotatedFieldMethod> paramMap, Class<?> paramClass)
  {
    this.name = paramString;
    this.method = ((AnnotatedFieldMethod)paramMap.get(Field.Property.VALUE)).method;
    this.annotation = paramField;
    this.runtime = new AnnotatedFieldRuntime(this);
    this.declaringClass = this.method.getDeclaringClass();
    this.runtime.setFunction(paramMap);
  }
  
  public void addSubField(AnnotatedField paramAnnotatedField)
  {
    this.subFields.add(paramAnnotatedField);
  }
  
  public void finishProcessing(List<HeaderDefinitionError> paramList)
  {
    this.runtime.finishProcessing(paramList);
    Iterator localIterator = this.subFields.iterator();
    while (localIterator.hasNext())
    {
      AnnotatedField localAnnotatedField = (AnnotatedField)localIterator.next();
      localAnnotatedField.finishProcessing(paramList);
    }
  }
  
  public Class<?> getDeclaringClass()
  {
    return this.declaringClass;
  }
  
  public String getDescription()
  {
    return this.annotation.description();
  }
  
  public final String getDisplay()
  {
    return this.annotation.display().length() == 0 ? getName() : this.annotation.display();
  }
  
  public final String getFormat()
  {
    if ((isSubField()) && (this.annotation.format().length() == 0)) {
      return "#bitfield#";
    }
    return this.annotation.format().length() == 0 ? "%s" : this.annotation.format();
  }
  
  public int getLength()
  {
    return this.annotation.length();
  }
  
  public long getMask()
  {
    return this.annotation.mask();
  }
  
  public Method getMethod()
  {
    return this.method;
  }
  
  public final String getName()
  {
    if (this.name != null) {
      return this.name;
    }
    return this.annotation.name().length() == 0 ? this.method.getName() : this.annotation.name();
  }
  
  public final String getNicname()
  {
    return this.annotation.nicname().length() == 0 ? getName() : this.annotation.nicname();
  }
  
  public int getOffset()
  {
    return this.annotation.offset();
  }
  
  public String getParent()
  {
    return this.annotation.parent();
  }
  
  public JFormatter.Priority getPriority()
  {
    return this.annotation.priority();
  }
  
  public final AnnotatedFieldRuntime getRuntime()
  {
    return this.runtime;
  }
  
  public JFormatter.Style getStyle()
  {
    if (isSubField()) {
      return JFormatter.Style.INT_BITS;
    }
    return mapFormatToStyle(getFormat());
  }
  
  public List<AnnotatedField> getSubFields()
  {
    return this.subFields;
  }
  
  public String getUnits()
  {
    return this.annotation.units();
  }
  
  public boolean isSubField()
  {
    return this.annotation.parent().length() != 0;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedField
 * JD-Core Version:    0.7.0.1
 */