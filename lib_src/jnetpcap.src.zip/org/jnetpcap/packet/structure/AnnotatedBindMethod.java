package org.jnetpcap.packet.structure;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.annotate.Bind;

public class AnnotatedBindMethod
  extends AnnotatedMethod
{
  private static final Map<Class<?>, AnnotatedBindMethod[]> cache = new HashMap();
  
  private static void checkSignature(Method paramMethod)
  {
    Class localClass = paramMethod.getDeclaringClass();
    if (!paramMethod.isAnnotationPresent(Bind.class)) {
      throw new AnnotatedMethodException(localClass, "@Bind annotation missing for " + paramMethod.getName() + "()");
    }
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    if ((arrayOfClass.length != 2) || (arrayOfClass[0] != JPacket.class) || (arrayOfClass[1].isAssignableFrom(JHeader.class))) {
      throw new AnnotatedMethodException(localClass, "Invalid signature for " + paramMethod.getName() + "()");
    }
    if ((paramMethod.getModifiers() & 0x8) == 0) {
      throw new AnnotatedMethodException(localClass, paramMethod.getName() + "()" + " must be declared static");
    }
  }
  
  private static void checkNonStaticSignature(Method paramMethod)
  {
    Class localClass = paramMethod.getDeclaringClass();
    if (!paramMethod.isAnnotationPresent(Bind.class)) {
      throw new AnnotatedMethodException(localClass, "@Bind annotation missing for " + paramMethod.getName() + "()");
    }
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    if ((arrayOfClass.length != 2) || (arrayOfClass[0] != JPacket.class) || (arrayOfClass[1].isAssignableFrom(JHeader.class))) {
      throw new AnnotatedMethodException(localClass, "Invalid signature for " + paramMethod.getName() + "()");
    }
    if ((paramMethod.getModifiers() & 0x8) != 0) {
      throw new AnnotatedMethodException(localClass, paramMethod.getName() + "()" + " can not be declared static");
    }
  }
  
  public static void clearCache()
  {
    cache.clear();
  }
  
  public static AnnotatedBindMethod[] inspectClass(Class<?> paramClass, List<HeaderDefinitionError> paramList)
  {
    if (cache.containsKey(paramClass)) {
      return (AnnotatedBindMethod[])cache.get(paramClass);
    }
    AnnotatedBindMethod[] arrayOfAnnotatedBindMethod = inspectAnyClass(paramClass, paramList);
    LinkedList localLinkedList = new LinkedList(Arrays.asList(arrayOfAnnotatedBindMethod));
    Object localObject = localLinkedList.iterator();
    while (((Iterator)localObject).hasNext())
    {
      AnnotatedBindMethod localAnnotatedBindMethod = (AnnotatedBindMethod)((Iterator)localObject).next();
      Bind localBind = (Bind)localAnnotatedBindMethod.getMethod().getAnnotation(Bind.class);
      Class localClass = localBind.from();
      if (localClass == JHeader.class)
      {
        paramList.add(new HeaderDefinitionError(paramClass, "missing annotated 'from' declaration for method " + localAnnotatedBindMethod.getMethod().getName() + "()"));
        ((Iterator)localObject).remove();
      }
    }
    localObject = (AnnotatedBindMethod[])localLinkedList.toArray(new AnnotatedBindMethod[localLinkedList.size()]);
    cache.put(paramClass, localObject);
    return localObject;
  }
  
  private static <T extends JHeader> AnnotatedBindMethod[] inspectAnyClass(Class<?> paramClass, List<HeaderDefinitionError> paramList)
  {
    if (cache.containsKey(paramClass)) {
      return (AnnotatedBindMethod[])cache.get(paramClass);
    }
    ArrayList localArrayList = new ArrayList();
    Class localClass = null;
    for (Method localMethod : paramClass.getMethods()) {
      try
      {
        if (localMethod.isAnnotationPresent(Bind.class))
        {
          checkSignature(localMethod);
          Bind localBind = (Bind)localMethod.getAnnotation(Bind.class);
          localClass = localBind.to();
          AnnotatedBindMethod localAnnotatedBindMethod = new AnnotatedBindMethod(localClass, localMethod);
          localArrayList.add(localAnnotatedBindMethod);
        }
      }
      catch (AnnotatedMethodException localAnnotatedMethodException)
      {
        paramList.add(localAnnotatedMethodException);
      }
    }
    ??? = (AnnotatedBindMethod[])localArrayList.toArray(new AnnotatedBindMethod[localArrayList.size()]);
    cache.put(paramClass, ???);
    return ???;
  }
  
  public static AnnotatedBindMethod[] inspectObject(Object paramObject, List<HeaderDefinitionError> paramList)
  {
    Class localClass1 = paramObject.getClass();
    if (cache.containsKey(localClass1)) {
      return (AnnotatedBindMethod[])cache.get(localClass1);
    }
    ArrayList localArrayList = new ArrayList();
    Class localClass2 = null;
    if (localClass1.getSuperclass() != Object.class)
    {
      paramList.add(new AnnotatedMethodException("bindings using annonymous classes can only extend Object class"));
      return new AnnotatedBindMethod[0];
    }
    for (Method localMethod : localClass1.getMethods()) {
      try
      {
        if (localMethod.isAnnotationPresent(Bind.class))
        {
          checkNonStaticSignature(localMethod);
          Bind localBind = (Bind)localMethod.getAnnotation(Bind.class);
          localClass2 = localBind.to();
          AnnotatedBindMethod localAnnotatedBindMethod = new AnnotatedBindMethod(localClass2, localMethod, paramObject);
          localArrayList.add(localAnnotatedBindMethod);
        }
      }
      catch (AnnotatedMethodException localAnnotatedMethodException)
      {
        paramList.add(localAnnotatedMethodException);
      }
    }
    ??? = (AnnotatedBindMethod[])localArrayList.toArray(new AnnotatedBindMethod[localArrayList.size()]);
    cache.put(localClass1, ???);
    return ???;
  }
  
  public static <T extends JHeader> AnnotatedBindMethod[] inspectJHeaderClass(Class<? extends JHeader> paramClass, List<HeaderDefinitionError> paramList)
  {
    return inspectAnyClass(paramClass, paramList);
  }
  
  private AnnotatedBindMethod(Class<? extends JHeader> paramClass, Method paramMethod, Object paramObject)
  {
    super(paramMethod, paramObject);
  }
  
  private AnnotatedBindMethod(Class<? extends JHeader> paramClass, Method paramMethod)
  {
    super(paramMethod);
  }
  
  public boolean isBound(JPacket paramJPacket, int paramInt, JHeader paramJHeader)
  {
    try
    {
      return ((Boolean)this.method.invoke(this.object, new Object[] { paramJPacket, paramJHeader })).booleanValue();
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new IllegalStateException(localIllegalArgumentException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalStateException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      throw new AnnotatedMethodException(this.declaringClass, localInvocationTargetException);
    }
  }
  
  protected void validateSignature(Method paramMethod)
  {
    if (this.object == null) {
      checkSignature(paramMethod);
    } else {
      checkNonStaticSignature(paramMethod);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedBindMethod
 * JD-Core Version:    0.7.0.1
 */