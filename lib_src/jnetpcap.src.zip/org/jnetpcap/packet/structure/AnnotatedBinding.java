package org.jnetpcap.packet.structure;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jnetpcap.packet.JBinding;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JRegistry;
import org.jnetpcap.packet.annotate.Bind;

public class AnnotatedBinding
  implements JBinding
{
  private static final Map<Class<?>, JBinding[]> cache = new HashMap();
  private final AnnotatedBindMethod annotatedBound;
  private final Class<?> definitionClass;
  protected final int[] dependencies;
  private final JHeader header;
  private final int sourceId;
  private final Class<? extends JHeader> targetClass;
  private final int targetId;
  
  public static void clearCache()
  {
    cache.clear();
  }
  
  private static JHeader createHeaderFromClass(Class<? extends JHeader> paramClass)
  {
    try
    {
      JHeader localJHeader = (JHeader)paramClass.newInstance();
      return localJHeader;
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new HeaderDefinitionError(paramClass, "problem in the default constructor", localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new HeaderDefinitionError(paramClass, "problem in the default constructor", localIllegalAccessException);
    }
  }
  
  public static JBinding[] inspectClass(Class<?> paramClass, List<HeaderDefinitionError> paramList)
  {
    if (cache.containsKey(paramClass)) {
      return (JBinding[])cache.get(paramClass);
    }
    AnnotatedBindMethod[] arrayOfAnnotatedBindMethod = AnnotatedBindMethod.inspectClass(paramClass, paramList);
    return createBindings(paramClass, arrayOfAnnotatedBindMethod, paramList);
  }
  
  private static JBinding[] createBindings(Class<?> paramClass, AnnotatedBindMethod[] paramArrayOfAnnotatedBindMethod, List<HeaderDefinitionError> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Class localClass1 = null;
    for (AnnotatedBindMethod localAnnotatedBindMethod : paramArrayOfAnnotatedBindMethod) {
      try
      {
        Bind localBind = (Bind)localAnnotatedBindMethod.getMethod().getAnnotation(Bind.class);
        localClass1 = localBind.to();
        Class localClass2 = localBind.from();
        Class[] arrayOfClass = localBind.dependencies();
        localArrayList.add(new AnnotatedBinding(paramClass, localClass2, localClass1, localAnnotatedBindMethod, arrayOfClass));
      }
      catch (AnnotatedMethodException localAnnotatedMethodException)
      {
        paramList.add(localAnnotatedMethodException);
      }
    }
    ??? = (JBinding[])localArrayList.toArray(new JBinding[localArrayList.size()]);
    cache.put(paramClass, ???);
    return ???;
  }
  
  public static <T extends JHeader> JBinding[] inspectJHeaderClass(Class<T> paramClass, List<HeaderDefinitionError> paramList)
  {
    if (cache.containsKey(paramClass)) {
      return (JBinding[])cache.get(paramClass);
    }
    AnnotatedBindMethod[] arrayOfAnnotatedBindMethod = AnnotatedBindMethod.inspectJHeaderClass(paramClass, paramList);
    Class<T> localClass = paramClass;
    ArrayList localArrayList = new ArrayList();
    Class localClass1 = null;
    for (AnnotatedBindMethod localAnnotatedBindMethod : arrayOfAnnotatedBindMethod) {
      try
      {
        Bind localBind = (Bind)localAnnotatedBindMethod.getMethod().getAnnotation(Bind.class);
        localClass1 = localBind.to();
        Class[] arrayOfClass = localBind.dependencies();
        localArrayList.add(new AnnotatedBinding(paramClass, localClass, localClass1, localAnnotatedBindMethod, arrayOfClass));
      }
      catch (AnnotatedMethodException localAnnotatedMethodException)
      {
        paramList.add(localAnnotatedMethodException);
      }
    }
    ??? = (JBinding[])localArrayList.toArray(new JBinding[localArrayList.size()]);
    cache.put(paramClass, ???);
    return ???;
  }
  
  private AnnotatedBinding(Class<?> paramClass, Class<? extends JHeader> paramClass1, Class<? extends JHeader> paramClass2, AnnotatedBindMethod paramAnnotatedBindMethod, Class<? extends JHeader>... paramVarArgs)
  {
    this.definitionClass = paramClass;
    this.targetClass = paramClass2;
    this.annotatedBound = paramAnnotatedBindMethod;
    this.dependencies = new int[paramVarArgs.length];
    this.sourceId = JRegistry.lookupId(paramClass1);
    this.targetId = JRegistry.lookupId(paramClass2);
    int i = 0;
    for (Class<? extends JHeader> localClass : paramVarArgs) {
      this.dependencies[(i++)] = JRegistry.lookupId(localClass);
    }
    this.header = createHeaderFromClass(paramClass2);
  }
  
  public int getSourceId()
  {
    return this.sourceId;
  }
  
  public Class<? extends JHeader> getTargetClass()
  {
    return this.targetClass;
  }
  
  public int getTargetId()
  {
    return this.targetId;
  }
  
  public boolean isBound(JPacket paramJPacket, int paramInt)
  {
    paramJPacket.getHeader(this.header);
    return (!this.header.isHeaderTruncated()) && (this.annotatedBound.isBound(paramJPacket, paramInt, this.header));
  }
  
  public int[] listDependencies()
  {
    return this.dependencies;
  }
  
  public String toString()
  {
    String str1 = this.definitionClass.getSimpleName();
    String str2 = this.annotatedBound.getMethod().getName();
    String str3 = this.targetClass.getSimpleName();
    return str1 + "." + str2 + "(JPacket packet, " + str3 + " header):" + "boolean";
  }
  
  public static JBinding[] inspectClass(Object paramObject, List<HeaderDefinitionError> paramList)
  {
    return inspectClass(paramObject.getClass(), paramList);
  }
  
  public static JBinding[] inspectObject(Object paramObject, List<HeaderDefinitionError> paramList)
  {
    Class localClass = paramObject.getClass();
    if (cache.containsKey(localClass)) {
      return (JBinding[])cache.get(localClass);
    }
    AnnotatedBindMethod[] arrayOfAnnotatedBindMethod = AnnotatedBindMethod.inspectObject(paramObject, paramList);
    return createBindings(localClass, arrayOfAnnotatedBindMethod, paramList);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.structure.AnnotatedBinding
 * JD-Core Version:    0.7.0.1
 */