package org.jnetpcap.packet;

public abstract interface JHeaderChecksum
{
  public abstract int checksum();
  
  public abstract int calculateChecksum();
  
  public abstract boolean isChecksumValid();
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JHeaderChecksum
 * JD-Core Version:    0.7.0.1
 */