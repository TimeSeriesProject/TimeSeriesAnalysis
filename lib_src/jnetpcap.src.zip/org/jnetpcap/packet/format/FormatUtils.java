package org.jnetpcap.packet.format;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JPacket.State;

public class FormatUtils
{
  private static final int DAY_MILLIS = 86400000;
  private static final int HOUR_MILLIS = 3600000;
  private static final int MINUTE_MILLIS = 60000;
  private static final List<String> multiLineStringList = new ArrayList();
  private static final int SECOND_MILLIS = 1000;
  private static String SPACE_CHAR = " ";
  static String[] table = new String[256];
  private static final int WEEK_MILLIS = 604800000;
  
  private static void initTable1char()
  {
    for (int i = 0; i < 31; i++) {
      table[i] = ".";
    }
    for (i = 31; i < 127; i++) {
      table[i] = new String(new byte[] { (byte)i });
    }
    for (i = 127; i < 256; i++) {
      table[i] = ".";
    }
  }
  
  private static void initTable3chars()
  {
    for (int i = 0; i < 31; i++)
    {
      table[i] = ("\\" + Integer.toHexString(i));
      if (table[i].length() == 2)
      {
        int tmp58_57 = i;
        String[] tmp58_54 = table;
        tmp58_54[tmp58_57] = (tmp58_54[tmp58_57] + " ");
      }
    }
    for (i = 31; i < 127; i++) {
      table[i] = new String(new byte[] { (byte)i, 32, 32 });
    }
    for (i = 127; i < 256; i++)
    {
      table[i] = ("\\" + Integer.toHexString(i));
      if (table[i].length() == 2)
      {
        int tmp183_182 = i;
        String[] tmp183_179 = table;
        tmp183_179[tmp183_182] = (tmp183_179[tmp183_182] + " ");
      }
    }
    table[0] = "\\0 ";
    table[7] = "\\a ";
    table[11] = "\\v ";
    table[8] = "\\b ";
    table[9] = "\\t ";
    table[10] = "\\n ";
    table[12] = "\\f ";
    table[13] = "\\r ";
  }
  
  public static String asString(byte[] paramArrayOfByte)
  {
    return asString(paramArrayOfByte, ':');
  }
  
  public static String asString(byte[] paramArrayOfByte, char paramChar)
  {
    return asString(paramArrayOfByte, paramChar, 16);
  }
  
  public static String asString(byte[] paramArrayOfByte, char paramChar, int paramInt)
  {
    return asString(paramArrayOfByte, paramChar, paramInt, 0, paramArrayOfByte.length);
  }
  
  public static String asString(byte[] paramArrayOfByte, char paramChar, int paramInt1, int paramInt2, int paramInt3)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = paramInt2; i < paramInt2 + paramInt3; i++)
    {
      int j = paramArrayOfByte[i];
      if (localStringBuilder.length() != 0) {
        localStringBuilder.append(paramChar);
      }
      localStringBuilder.append(Integer.toString(j < 0 ? j + 256 : j, paramInt1).toUpperCase());
    }
    return localStringBuilder.toString();
  }
  
  public static String asStringZeroPad(byte[] paramArrayOfByte, char paramChar, int paramInt1, int paramInt2, int paramInt3)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = paramInt2; i < paramInt2 + paramInt3; i++)
    {
      int j = paramArrayOfByte[i];
      if (localStringBuilder.length() != 0) {
        localStringBuilder.append(paramChar);
      }
      String str = Integer.toString(j < 0 ? j + 256 : j, paramInt1).toUpperCase();
      if (str.length() == 1) {
        localStringBuilder.append('0');
      }
      localStringBuilder.append(str);
    }
    return localStringBuilder.toString();
  }
  
  public static String ip(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length == 4) {
      return asString(paramArrayOfByte, '.', 10);
    }
    return asStringIp6(paramArrayOfByte, true);
  }
  
  public static String mac(byte[] paramArrayOfByte)
  {
    return asStringZeroPad(paramArrayOfByte, ':', 16, 0, paramArrayOfByte.length);
  }
  
  public static String asStringIp6(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 0;
    int j = -1;
    for (int k = 0; (k < paramArrayOfByte.length) && (paramBoolean); k++)
    {
      if (paramArrayOfByte[k] == 0)
      {
        if (i == 0) {
          j = k;
        }
        i++;
      }
      if ((paramArrayOfByte[k] != 0) && (i != 0)) {
        break;
      }
    }
    if ((j != -1) && (j % 2 == 1))
    {
      j++;
      i--;
    }
    if ((j != -1) && (i % 2 == 1)) {
      i--;
    }
    for (k = 0; k < paramArrayOfByte.length; k++) {
      if (k == j)
      {
        localStringBuilder.append(':');
        k += i - 1;
        if (k == paramArrayOfByte.length - 1) {
          localStringBuilder.append(':');
        }
      }
      else
      {
        int m = paramArrayOfByte[k];
        if ((localStringBuilder.length() != 0) && (k % 2 == 0)) {
          localStringBuilder.append(':');
        }
        if (m < 16) {
          localStringBuilder.append('0');
        }
        localStringBuilder.append(Integer.toHexString(m < 0 ? m + 256 : m).toUpperCase());
      }
    }
    return localStringBuilder.toString();
  }
  
  public static String formatTimeInMillis(long paramLong)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    long l = 0L;
    while (paramLong > 0L)
    {
      if (localStringBuilder.length() != 0) {
        localStringBuilder.append(' ');
      }
      if (paramLong > 604800000L)
      {
        l = paramLong / 604800000L;
        localStringBuilder.append(l).append(' ').append(l > 1L ? "weeks" : "week");
        paramLong -= l * 604800000L;
      }
      else if (paramLong > 86400000L)
      {
        l = paramLong / 86400000L;
        localStringBuilder.append(l).append(' ').append(l > 1L ? "days" : "day");
        paramLong -= l * 86400000L;
      }
      else if (paramLong > 3600000L)
      {
        l = paramLong / 3600000L;
        localStringBuilder.append(l).append(' ').append(l > 1L ? "days" : "day");
        paramLong -= l * 3600000L;
      }
      else if (paramLong > 60000L)
      {
        l = paramLong / 60000L;
        localStringBuilder.append(l).append(' ').append(l > 1L ? "minutes" : "minute");
        paramLong -= l * 60000L;
      }
      else if (paramLong > 1000L)
      {
        l = paramLong / 1000L;
        localStringBuilder.append(l).append(' ').append(l > 1L ? "seconds" : "second");
        paramLong -= l * 1000L;
      }
      else if (paramLong > 0L)
      {
        l = paramLong;
        localStringBuilder.append(l).append(' ').append(l > 1L ? "millis" : "milli");
        paramLong -= l;
      }
    }
    return localStringBuilder.toString();
  }
  
  public static String[] hexdump(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    return hexdump(paramArrayOfByte, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, (int[][])null);
  }
  
  public static int[][] markers(JPacket.State paramState)
  {
    int[][] arrayOfInt = new int[paramState.getHeaderCount() + 1][2];
    arrayOfInt[0][0] = -1;
    arrayOfInt[0][1] = -1;
    for (int i = 0; i < paramState.getHeaderCount(); i++)
    {
      arrayOfInt[(i + 1)][0] = paramState.getHeaderOffsetByIndex(i);
      arrayOfInt[(i + 1)][1] = paramState.getHeaderLengthByIndex(i);
    }
    return arrayOfInt;
  }
  
  public static String[] hexdump(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int[][] paramArrayOfInt)
  {
    multiLineStringList.clear();
    for (int i = 0; i + paramInt2 < paramArrayOfByte.length; i += 16) {
      multiLineStringList.add(hexLine(paramArrayOfByte, i + paramInt1, i + paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, paramArrayOfInt));
    }
    return (String[])multiLineStringList.toArray(new String[multiLineStringList.size()]);
  }
  
  public static String hexdump(byte[] paramArrayOfByte)
  {
    return hexdumpCombined(paramArrayOfByte, 0, 0, true, true, true);
  }
  
  public static String hexdump(JPacket paramJPacket)
  {
    return hexdump(paramJPacket.getByteArray(0, paramJPacket.size()), paramJPacket.getState());
  }
  
  public static String hexdump(byte[] paramArrayOfByte, JPacket.State paramState)
  {
    return hexdumpCombined(paramArrayOfByte, 0, 0, true, true, true, markers(paramState));
  }
  
  public static String hexdumpCombined(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    return hexdumpCombined(paramArrayOfByte, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, (int[][])null);
  }
  
  public static String hexdumpCombined(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int[][] paramArrayOfInt)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (String str : hexdump(paramArrayOfByte, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, paramArrayOfInt)) {
      localStringBuilder.append(str).append('\n');
    }
    return localStringBuilder.toString();
  }
  
  public static String hexLine(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int[][] paramArrayOfInt)
  {
    String str = "";
    if (paramBoolean1)
    {
      str = str + hexLineAddress(paramInt1);
      str = str + ":";
    }
    if (paramBoolean3) {
      str = str + hexLineData(paramArrayOfByte, paramInt2, paramArrayOfInt);
    }
    if (paramBoolean2)
    {
      str = str + SPACE_CHAR;
      str = str + SPACE_CHAR;
      str = str + SPACE_CHAR;
      str = str + hexLineText(paramArrayOfByte, paramInt2);
    }
    return str;
  }
  
  public static String hexLineAddress(int paramInt)
  {
    String str = "";
    str = Integer.toHexString(paramInt);
    for (int i = str.length(); i < 4; i++) {
      str = "0" + str;
    }
    return str;
  }
  
  public static String hexLineData(byte[] paramArrayOfByte, int paramInt)
  {
    String str = "";
    int i = 0;
    for (i = 0; (i + paramInt < paramArrayOfByte.length) && (i < 16); i++)
    {
      int j = i + paramInt;
      if (i == 0) {
        str = str + SPACE_CHAR;
      }
      if ((i % 4 == 0) && (i != 0)) {
        str = str + SPACE_CHAR;
      }
      str = str + toHexString(paramArrayOfByte[j]) + SPACE_CHAR;
    }
    while (i < 16)
    {
      if ((i % 4 == 0) && (i != 0)) {
        str = str + SPACE_CHAR;
      }
      str = str + SPACE_CHAR + SPACE_CHAR + SPACE_CHAR;
      i++;
    }
    return str;
  }
  
  public static String hexLineData(byte[] paramArrayOfByte, int paramInt, int[][] paramArrayOfInt)
  {
    if (paramArrayOfInt == null) {
      return hexLineData(paramArrayOfByte, paramInt);
    }
    StringBuilder localStringBuilder = new StringBuilder();
    String[] arrayOfString = { "*", "*" };
    int i = findMarker(paramArrayOfInt, paramInt);
    int j = paramArrayOfInt[i][0];
    int k = j + paramArrayOfInt[i][1] - 1;
    int m = 0;
    for (m = 0; (m + paramInt < paramArrayOfByte.length) && (m < 16); m++)
    {
      int n = m + paramInt;
      if ((n == 0) && (n == j)) {
        localStringBuilder.append(arrayOfString[(i % 2)]);
      } else if (m == 0) {
        localStringBuilder.append(SPACE_CHAR);
      }
      if ((m % 4 == 0) && (m != 0)) {
        localStringBuilder.append(SPACE_CHAR);
      }
      if (n == k)
      {
        i = findMarker(paramArrayOfInt, n + 1);
        j = paramArrayOfInt[i][0];
        k = j + paramArrayOfInt[i][1] - 1;
        localStringBuilder.append(toHexString(paramArrayOfByte[n])).append(arrayOfString[(i % 2)]);
      }
      else
      {
        localStringBuilder.append(toHexString(paramArrayOfByte[n])).append(SPACE_CHAR);
      }
    }
    while (m < 16)
    {
      if ((m % 4 == 0) && (m != 0)) {
        localStringBuilder.append(SPACE_CHAR);
      }
      localStringBuilder.append(SPACE_CHAR).append(SPACE_CHAR).append(SPACE_CHAR);
      m++;
    }
    return localStringBuilder.toString();
  }
  
  private static int findMarker(int[][] paramArrayOfInt, int paramInt)
  {
    for (int i = 0; i < paramArrayOfInt.length; i++)
    {
      int j = paramArrayOfInt[i][0];
      int k = j + paramArrayOfInt[i][1] - 1;
      if ((paramInt >= j) && (paramInt < k)) {
        return i;
      }
    }
    return 0;
  }
  
  public static String hexLineText(byte[] paramArrayOfByte, int paramInt)
  {
    String str = "";
    for (int i = 0; (i + paramInt < paramArrayOfByte.length) && (i < 16); i++) {
      str = str + table[(paramArrayOfByte[(i + paramInt)] & 0xFF)];
    }
    while (i < 16)
    {
      str = str + SPACE_CHAR;
      i++;
    }
    return str;
  }
  
  public static byte[] toByteArray(String paramString)
  {
    String str1 = paramString.replaceAll(" |\n", "");
    byte[] arrayOfByte = new byte[str1.length() / 2];
    if (str1.length() % 2 != 0)
    {
      System.err.println(str1);
      throw new IllegalArgumentException("need even number of hex double digits [" + str1.length() + "]");
    }
    for (int i = 0; i < str1.length(); i += 2)
    {
      String str2 = str1.substring(i, i + 2);
      arrayOfByte[(i / 2)] = ((byte)Integer.parseInt(str2, 16));
    }
    return arrayOfByte;
  }
  
  public static String toHexString(byte paramByte)
  {
    String str = Integer.toHexString(paramByte & 0xFF);
    if (str.length() == 1) {
      return "0" + str;
    }
    return str;
  }
  
  static
  {
    initTable1char();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.format.FormatUtils
 * JD-Core Version:    0.7.0.1
 */