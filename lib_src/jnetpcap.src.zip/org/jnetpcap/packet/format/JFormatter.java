package org.jnetpcap.packet.format;

import java.io.IOException;
import java.util.Formatter;
import java.util.Iterator;
import java.util.Stack;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JHeaderPool;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JRegistry;
import org.jnetpcap.packet.UnregisteredHeaderException;
import org.jnetpcap.packet.structure.JField;
import org.jnetpcap.util.resolver.Resolver;
import org.jnetpcap.util.resolver.Resolver.ResolverType;

public abstract class JFormatter
{
  private static final Detail DEFAULT_DETAIL = Detail.MULTI_LINE_FULL_DETAIL;
  private static boolean defaultDisplayPayload = true;
  private static boolean defaultResolveAddresses = false;
  private static JFormatter global;
  private Detail[] detailsPerHeader = new Detail[64];
  private boolean displayPayload;
  protected int frameIndex = -1;
  private JHeaderPool headers = new JHeaderPool();
  private Resolver ipResolver;
  private int level;
  private Resolver ouiPrefixResolver;
  protected Formatter out;
  private StringBuilder outputBuffer;
  private Stack<String> padStack = new Stack();
  private boolean resolveAddresses = false;
  
  public static JFormatter getDefault()
  {
    if (global == null) {
      global = new XmlFormatter();
    }
    return global;
  }
  
  public static void setDefault(JFormatter paramJFormatter)
  {
    global = paramJFormatter;
  }
  
  public static void setDefaultDisplayPayload(boolean paramBoolean)
  {
    defaultDisplayPayload = paramBoolean;
  }
  
  public static void setDefaultResolveAddress(boolean paramBoolean)
  {
    defaultResolveAddresses = paramBoolean;
  }
  
  public JFormatter()
  {
    setDetail(DEFAULT_DETAIL);
    setOutput(System.out);
    setResolveAddresses(defaultResolveAddresses);
    setDisplayPayload(defaultDisplayPayload);
  }
  
  public JFormatter(Appendable paramAppendable)
  {
    setDetail(DEFAULT_DETAIL);
    setOutput(paramAppendable);
    setResolveAddresses(defaultResolveAddresses);
    setDisplayPayload(defaultDisplayPayload);
  }
  
  public JFormatter(StringBuilder paramStringBuilder)
  {
    setDetail(DEFAULT_DETAIL);
    setOutput(paramStringBuilder);
    setResolveAddresses(defaultResolveAddresses);
    setDisplayPayload(defaultDisplayPayload);
  }
  
  protected void decLevel()
  {
    if (this.level == 0) {
      return;
    }
    this.level -= 1;
    this.padStack.pop();
  }
  
  protected abstract void fieldAfter(JHeader paramJHeader, JField paramJField, Detail paramDetail)
    throws IOException;
  
  protected abstract void fieldBefore(JHeader paramJHeader, JField paramJField, Detail paramDetail)
    throws IOException;
  
  protected void fieldNull(JHeader paramJHeader, JField paramJField, Detail paramDetail) {}
  
  public void format(JHeader paramJHeader)
    throws IOException
  {
    format(paramJHeader, DEFAULT_DETAIL);
  }
  
  public void format(JHeader paramJHeader, Detail paramDetail)
    throws IOException
  {
    if (paramJHeader == null)
    {
      headerNull(paramJHeader, paramDetail);
      return;
    }
    JField[] arrayOfJField = paramJHeader.getFields();
    headerBefore(paramJHeader, paramDetail);
    JField localJField;
    for (localJField : arrayOfJField) {
      if (localJField.hasField(paramJHeader)) {
        format(paramJHeader, localJField, paramDetail);
      }
    }
    for (localJField : paramJHeader.getSubHeaders()) {
      format(paramJHeader, localJField, paramDetail);
    }
    headerAfter(paramJHeader, paramDetail);
  }
  
  public void format(JHeader paramJHeader, JField paramJField)
    throws IOException
  {
    format(paramJHeader, paramJField, DEFAULT_DETAIL);
  }
  
  public void format(JHeader paramJHeader, JField paramJField, Detail paramDetail)
    throws IOException
  {
    if (paramJHeader == null)
    {
      headerNull(paramJHeader, paramDetail);
      return;
    }
    if (paramJField == null)
    {
      fieldNull(paramJHeader, paramJField, paramDetail);
      return;
    }
    fieldBefore(paramJHeader, paramJField, paramDetail);
    if (paramJField.hasSubFields()) {
      for (JField localJField : paramJField.getSubFields()) {
        format(paramJHeader, localJField, paramDetail);
      }
    }
    fieldAfter(paramJHeader, paramJField, paramDetail);
  }
  
  public void format(JHeader paramJHeader1, JHeader paramJHeader2, Detail paramDetail)
    throws IOException
  {
    JField[] arrayOfJField1 = paramJHeader2.getFields();
    subHeaderBefore(paramJHeader1, paramJHeader2, paramDetail);
    for (JField localJField : arrayOfJField1) {
      if ((localJField != null) && (paramDetail.isDisplayable(localJField.getPriority())) && (localJField.hasField(paramJHeader1))) {
        format(paramJHeader2, localJField, paramDetail);
      }
    }
    subHeaderAfter(paramJHeader1, paramJHeader2, paramDetail);
  }
  
  public void format(JPacket paramJPacket)
    throws IOException
  {
    format(paramJPacket, DEFAULT_DETAIL);
  }
  
  public void format(JPacket paramJPacket, Detail paramDetail)
    throws IOException
  {
    if (paramJPacket == null)
    {
      packetNull(paramJPacket, paramDetail);
      return;
    }
    packetBefore(paramJPacket, paramDetail);
    int i = paramJPacket.getHeaderCount();
    for (int j = 0; j < i; j++)
    {
      int k = paramJPacket.getHeaderIdByIndex(j);
      if ((k != 0) || (this.displayPayload)) {
        try
        {
          JHeader localJHeader = this.headers.getHeader(k);
          Detail localDetail = this.detailsPerHeader[k] == null ? paramDetail : this.detailsPerHeader[k];
          paramJPacket.getHeaderByIndex(j, localJHeader);
          if (localJHeader.getLength() != 0) {
            format(localJHeader, localDetail);
          }
        }
        catch (UnregisteredHeaderException localUnregisteredHeaderException)
        {
          throw new IllegalStateException(localUnregisteredHeaderException);
        }
      }
    }
    packetAfter(paramJPacket, paramDetail);
  }
  
  public void format(StringBuilder paramStringBuilder, JPacket paramJPacket)
  {
    try
    {
      format(paramJPacket, DEFAULT_DETAIL);
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException);
    }
  }
  
  private String formatIpAddress(byte[] paramArrayOfByte)
  {
    if (this.resolveAddresses) {
      return resolveIp(paramArrayOfByte);
    }
    return paramArrayOfByte.length == 16 ? FormatUtils.asStringIp6(paramArrayOfByte, true) : FormatUtils.asString(paramArrayOfByte, '.', 10).toUpperCase();
  }
  
  private String formatMacAddress(byte[] paramArrayOfByte)
  {
    String str1 = FormatUtils.mac(paramArrayOfByte).toLowerCase();
    if ((this.resolveAddresses) && (this.ouiPrefixResolver.canBeResolved(paramArrayOfByte)))
    {
      String str2 = this.ouiPrefixResolver.resolve(paramArrayOfByte);
      String str3 = str2 + "_" + FormatUtils.asStringZeroPad(paramArrayOfByte, ':', 16, 3, 3).toLowerCase();
      return str3 + " (" + str1 + ")";
    }
    return str1;
  }
  
  protected abstract void headerAfter(JHeader paramJHeader, Detail paramDetail)
    throws IOException;
  
  protected abstract void headerBefore(JHeader paramJHeader, Detail paramDetail)
    throws IOException;
  
  protected void headerNull(JHeader paramJHeader, Detail paramDetail) {}
  
  protected void incLevel(int paramInt)
  {
    incLevel(paramInt, ' ');
  }
  
  protected void incLevel(int paramInt, char paramChar)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = 0; i < paramInt; i++) {
      localStringBuilder.append(paramChar);
    }
    incLevel(localStringBuilder.toString());
  }
  
  protected void incLevel(String paramString)
  {
    this.level += 1;
    this.padStack.push(paramString);
  }
  
  public abstract void packetAfter(JPacket paramJPacket, Detail paramDetail)
    throws IOException;
  
  public abstract void packetBefore(JPacket paramJPacket, Detail paramDetail)
    throws IOException;
  
  protected void packetNull(JPacket paramJPacket, Detail paramDetail) {}
  
  protected Formatter pad()
  {
    this.out.format("\n", new Object[0]);
    Iterator localIterator = this.padStack.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      this.out.format(String.valueOf(str), new Object[0]);
    }
    return this.out;
  }
  
  public void reset()
  {
    if (this.outputBuffer != null) {
      this.outputBuffer.setLength(0);
    }
    this.padStack.clear();
  }
  
  private String resolveIp(byte[] paramArrayOfByte)
  {
    String str1 = paramArrayOfByte.length == 16 ? FormatUtils.asStringIp6(paramArrayOfByte, true) : FormatUtils.asString(paramArrayOfByte, '.', 10).toUpperCase();
    String str2 = this.ipResolver.resolve(paramArrayOfByte);
    if (str2 == null) {
      return str1 + " (resolve failed)";
    }
    return str1 + " (" + str2 + ")";
  }
  
  public void setDetail(Detail paramDetail)
  {
    for (int i = 0; i < 64; i++) {
      this.detailsPerHeader[i] = paramDetail;
    }
  }
  
  public void setDetail(Detail paramDetail, int paramInt)
  {
    this.detailsPerHeader[paramInt] = paramDetail;
  }
  
  public void setDisplayPayload(boolean paramBoolean)
  {
    this.displayPayload = paramBoolean;
  }
  
  public void setFrameIndex(int paramInt)
  {
    this.frameIndex = paramInt;
  }
  
  public void setOutput(Appendable paramAppendable)
  {
    this.out = new Formatter(paramAppendable);
    this.outputBuffer = null;
  }
  
  public void setOutput(StringBuilder paramStringBuilder)
  {
    this.outputBuffer = paramStringBuilder;
    this.out = new Formatter(paramStringBuilder);
  }
  
  public void setResolveAddresses(boolean paramBoolean)
  {
    this.resolveAddresses = paramBoolean;
    if ((paramBoolean == true) && (this.ouiPrefixResolver == null))
    {
      this.ouiPrefixResolver = JRegistry.getResolver(Resolver.ResolverType.IEEE_OUI_PREFIX);
      this.ipResolver = JRegistry.getResolver(Resolver.ResolverType.IP);
    }
    else
    {
      this.ouiPrefixResolver = null;
      this.ipResolver = null;
    }
  }
  
  private String stylizeBitField(JHeader paramJHeader, JField paramJField, Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    JField localJField = paramJField.getParent();
    int i = localJField.getLength(paramJHeader);
    long l1 = localJField.getMask(paramJHeader);
    long l2 = paramJField.longValue(paramJHeader);
    int j = paramJField.getOffset(paramJHeader);
    int k = paramJField.getLength(paramJHeader);
    int m = j + k;
    int n = j;
    for (int i1 = i; i1 > m; i1--) {
      if ((l1 & 1L << i1 - 1) != 0L) {
        localStringBuilder.append((i1 - 1) % 4 == 0 ? ". " : Character.valueOf('.'));
      }
    }
    for (i1 = m; i1 > n; i1--) {
      if ((l1 & 1L << i1 - 1) != 0L)
      {
        if ((l2 & 1L << i1 - n - 1) == 0L) {
          localStringBuilder.append('0');
        } else {
          localStringBuilder.append('1');
        }
        if ((i1 - 1) % 4 == 0) {
          localStringBuilder.append(' ');
        }
      }
    }
    for (i1 = n; i1 > 0; i1--) {
      if ((l1 & 1L << i1 - 1) != 0L) {
        localStringBuilder.append((i1 - 1) % 4 == 0 ? ". " : Character.valueOf('.'));
      }
    }
    localStringBuilder.setLength(localStringBuilder.length() - 1);
    return localStringBuilder.toString();
  }
  
  protected String[] stylizeMultiLine(JHeader paramJHeader, JField paramJField, Object paramObject)
  {
    return stylizeMultiLine(paramJHeader, paramJField, paramJField.getStyle(), paramObject);
  }
  
  protected String[] stylizeMultiLine(JHeader paramJHeader, JField paramJField, Style paramStyle, Object paramObject)
  {
    switch (1.$SwitchMap$org$jnetpcap$packet$format$JFormatter$Style[paramStyle.ordinal()])
    {
    case 1: 
      return FormatUtils.hexdump((byte[])paramObject, paramJHeader.getOffset(), 0, true, true, true);
    case 2: 
      return FormatUtils.hexdump((byte[])paramObject, paramJHeader.getOffset(), 0, true, false, true);
    case 3: 
      return FormatUtils.hexdump((byte[])paramObject, paramJHeader.getOffset(), 0, false, false, true);
    case 4: 
      return FormatUtils.hexdump((byte[])paramObject, paramJHeader.getOffset(), 0, false, true, true);
    case 5: 
      return FormatUtils.hexdump((byte[])paramObject, paramJHeader.getOffset(), 0, true, false, false);
    case 6: 
      return FormatUtils.hexdump((byte[])paramObject, paramJHeader.getOffset(), 0, false, true, false);
    case 7: 
      return ((String)paramObject).split("\r\n");
    }
    return new String[] { stylizeSingleLine(paramJHeader, paramJField, paramObject) };
  }
  
  protected String stylizeSingleLine(JHeader paramJHeader, JField paramJField, Object paramObject)
  {
    Style localStyle = paramJField.getStyle();
    switch (1.$SwitchMap$org$jnetpcap$packet$format$JFormatter$Style[localStyle.ordinal()])
    {
    case 8: 
      return FormatUtils.asString((byte[])paramObject, '-').toUpperCase();
    case 9: 
      return formatMacAddress((byte[])paramObject);
    case 10: 
      return FormatUtils.asString((byte[])paramObject, '.').toUpperCase();
    case 11: 
    case 12: 
    case 13: 
      return formatIpAddress((byte[])paramObject);
    case 14: 
      return stylizeBitField(paramJHeader, paramJField, paramObject);
    case 15: 
      return Long.toHexString(((Number)paramObject).longValue()).toUpperCase();
    case 16: 
      return "0x" + Long.toHexString(((Number)paramObject).longValue()).toUpperCase() + " (" + paramObject.toString() + ")";
    case 17: 
      return "0x" + Long.toHexString(((Long)paramObject).longValue()).toUpperCase() + " (" + paramObject.toString() + ")";
    }
    return paramObject.toString();
  }
  
  protected abstract void subHeaderAfter(JHeader paramJHeader1, JHeader paramJHeader2, Detail paramDetail)
    throws IOException;
  
  protected abstract void subHeaderBefore(JHeader paramJHeader1, JHeader paramJHeader2, Detail paramDetail)
    throws IOException;
  
  public String toString()
  {
    return this.out.toString();
  }
  
  public void println(String paramString)
  {
    this.out.format("%s\n", new Object[] { paramString });
  }
  
  public void printf(String paramString, Object... paramVarArgs)
  {
    this.out.format(paramString, paramVarArgs);
  }
  
  public static enum Style
  {
    BYTE_ARRAY_ARRAY_IP4_ADDRESS,  BYTE_ARRAY_COLON_ADDRESS,  BYTE_ARRAY_DASH_ADDRESS,  BYTE_ARRAY_DOT_ADDRESS,  BYTE_ARRAY_HEX_DUMP,  BYTE_ARRAY_HEX_DUMP_ADDRESS,  BYTE_ARRAY_HEX_DUMP_NO_ADDRESS,  BYTE_ARRAY_HEX_DUMP_NO_TEXT,  BYTE_ARRAY_HEX_DUMP_NO_TEXT_ADDRESS,  BYTE_ARRAY_HEX_DUMP_TEXT,  BYTE_ARRAY_IP4_ADDRESS,  BYTE_ARRAY_IP6_ADDRESS,  INT_BIN,  INT_BITS,  INT_DEC,  INT_HEX,  INT_OCT,  INT_RADIX_10,  INT_RADIX_16,  INT_RADIX_2,  INT_RADIX_8,  LONG_DEC,  LONG_HEX,  STRING,  STRING_TEXT_DUMP,  BOOLEAN,  STRING_ARRAY;
    
    private Style() {}
  }
  
  public static enum Priority
  {
    HIGH,  LOW,  MEDIUM;
    
    private Priority() {}
  }
  
  public static abstract enum Detail
  {
    MULTI_LINE_FULL_DETAIL,  MULTI_LINE_SUMMARY,  NONE,  ONE_LINE_SUMMARY;
    
    private Detail() {}
    
    public abstract boolean isDisplayable(JFormatter.Priority paramPriority);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.format.JFormatter
 * JD-Core Version:    0.7.0.1
 */