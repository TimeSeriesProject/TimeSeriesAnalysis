package org.jnetpcap.packet.format;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Formatter;
import org.jnetpcap.JCaptureHeader;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JPacket.State;
import org.jnetpcap.packet.annotate.ProtocolSuite;
import org.jnetpcap.packet.structure.AnnotatedHeader;
import org.jnetpcap.packet.structure.JField;
import org.jnetpcap.protocol.JProtocol.Suite;

public class TextFormatter
  extends JFormatter
{
  private static final String FIELD_ARRAY_FORMAT = "%16s[%d] = ";
  private static final String FIELD_FORMAT = "%16s = ";
  private static final String SEPARATOR = ": ";
  final Formatter uf = new Formatter();
  
  public TextFormatter() {}
  
  public TextFormatter(Appendable paramAppendable)
  {
    super(paramAppendable);
  }
  
  public TextFormatter(StringBuilder paramStringBuilder)
  {
    super(paramStringBuilder);
  }
  
  protected void fieldAfter(JHeader paramJHeader, JField paramJField, JFormatter.Detail paramDetail)
    throws IOException
  {
    if (paramJField.getStyle() != JFormatter.Style.INT_BITS) {
      if (paramJField.hasSubFields()) {
        decLevel();
      } else if ((paramJField.getStyle() != JFormatter.Style.BYTE_ARRAY_HEX_DUMP) && (paramJField.getStyle() != JFormatter.Style.STRING_TEXT_DUMP)) {
        decLevel();
      }
    }
  }
  
  protected void fieldBefore(JHeader paramJHeader, JField paramJField, JFormatter.Detail paramDetail)
    throws IOException
  {
    Object localObject1;
    if (paramJField.hasSubFields())
    {
      localObject1 = stylizeSingleLine(paramJHeader, paramJField, paramJField.getValue(paramJHeader));
      pad().format("%16s = %s", new Object[] { paramJField.getDisplay(paramJHeader), localObject1 });
      incLevel(19);
    }
    else
    {
      Object localObject2;
      if (paramJField.getStyle() == JFormatter.Style.INT_BITS)
      {
        localObject1 = stylizeSingleLine(paramJHeader, paramJField, paramJField.getValue(paramJHeader));
        localObject2 = paramJField.getValueDescription(paramJHeader);
        long l = paramJField.longValue(paramJHeader);
        pad().format("%s = [%d] %s%s", new Object[] { localObject1, Long.valueOf(l), paramJField.getDisplay(paramJHeader), ": " + (String)localObject2 });
      }
      else if ((paramJField.getStyle() == JFormatter.Style.BYTE_ARRAY_HEX_DUMP) || (paramJField.getStyle() == JFormatter.Style.STRING_TEXT_DUMP))
      {
        decLevel();
        decLevel();
        localObject1 = stylizeMultiLine(paramJHeader, paramJField, paramJField.getValue(paramJHeader));
        for (Object localObject4 : localObject1) {
          pad().format("%s", new Object[] { localObject4 });
        }
      }
      else
      {
        int i;
        Object localObject5;
        if (paramJField.getStyle() == JFormatter.Style.BYTE_ARRAY_ARRAY_IP4_ADDRESS)
        {
          localObject1 = (byte[][])paramJField.getValue(paramJHeader);
          i = 0;
          for (localObject5 : localObject1)
          {
            String str2 = stylizeSingleLine(paramJHeader, paramJField, localObject5);
            pad().format("%16s[%d] = %s", new Object[] { paramJField.getDisplay(paramJHeader), Integer.valueOf(i++), str2 });
          }
          incLevel(0);
        }
        else if (paramJField.getStyle() == JFormatter.Style.STRING_ARRAY)
        {
          localObject1 = (String[])paramJField.getValue(paramJHeader);
          i = 0;
          for (localObject5 : localObject1) {
            pad().format("%16s[%d] = %s", new Object[] { paramJField.getDisplay(paramJHeader), Integer.valueOf(i++), localObject5 });
          }
          incLevel(0);
        }
        else
        {
          localObject1 = stylizeSingleLine(paramJHeader, paramJField, paramJField.getValue(paramJHeader));
          String str1 = paramJField.getValueDescription(paramJHeader);
          ??? = paramJField.getUnits(paramJHeader);
          pad().format("%16s = %s", new Object[] { paramJField.getDisplay(paramJHeader), localObject1 });
          if (??? != null) {
            this.out.format(" " + (String)???, new Object[0]);
          }
          if (str1 != null) {
            this.out.format(" [" + str1 + "]", new Object[0]);
          }
          incLevel(19);
        }
      }
    }
  }
  
  protected void headerAfter(JHeader paramJHeader, JFormatter.Detail paramDetail)
    throws IOException
  {
    pad();
    decLevel();
    decLevel();
  }
  
  protected void headerBefore(JHeader paramJHeader, JFormatter.Detail paramDetail)
    throws IOException
  {
    String str1 = paramJHeader.getNicname();
    incLevel(str1);
    incLevel(": ");
    JProtocol.Suite localSuite = paramJHeader.getAnnotatedHeader().getSuite();
    String str2 = "";
    if (localSuite != ProtocolSuite.OTHER) {
      str2 = "protocol suite=" + localSuite.name().replace('_', '/');
    }
    if (paramJHeader.hasDescription()) {
      pad().format(" ******* %s - \"%s\" - offset=%d (0x%X) length=%d %s", new Object[] { paramJHeader.getName(), paramJHeader.getDescription(), Integer.valueOf(paramJHeader.getOffset()), Integer.valueOf(paramJHeader.getOffset()), Integer.valueOf(paramJHeader.getLength()), str2 });
    } else {
      pad().format(" ******* %s offset=%d (0x%X) length=%d %s", new Object[] { paramJHeader.getName(), Integer.valueOf(paramJHeader.getOffset()), Integer.valueOf(paramJHeader.getOffset()), Integer.valueOf(paramJHeader.getLength()), str2 });
    }
    pad();
  }
  
  public void packetAfter(JPacket paramJPacket, JFormatter.Detail paramDetail)
    throws IOException
  {
    if (this.frameIndex != -1) {
      pad().format("END OF PACKET %d", new Object[] { Integer.valueOf(this.frameIndex) });
    }
  }
  
  public void packetBefore(JPacket paramJPacket, JFormatter.Detail paramDetail)
    throws IOException
  {
    incLevel("Frame:");
    pad();
    if (this.frameIndex != -1) {
      pad().format("%16s = %d", new Object[] { "#", Integer.valueOf(this.frameIndex) });
    } else {
      pad().format("%16s = %d", new Object[] { "number", Long.valueOf(paramJPacket.getState().getFrameNumber()) });
    }
    pad().format("%16s = %s", new Object[] { "timestamp", new Timestamp(paramJPacket.getCaptureHeader().timestampInMillis()).toString() });
    pad().format("%16s = %d bytes", new Object[] { "wire length", Integer.valueOf(paramJPacket.getCaptureHeader().wirelen()) });
    pad().format("%16s = %d bytes", new Object[] { "captured length", Integer.valueOf(paramJPacket.getCaptureHeader().caplen()) });
    pad();
    decLevel();
  }
  
  protected void packetNull(JPacket paramJPacket, JFormatter.Detail paramDetail)
  {
    pad().format("packet: NULL", new Object[0]);
  }
  
  protected void subHeaderAfter(JHeader paramJHeader1, JHeader paramJHeader2, JFormatter.Detail paramDetail)
    throws IOException
  {}
  
  protected void subHeaderBefore(JHeader paramJHeader1, JHeader paramJHeader2, JFormatter.Detail paramDetail)
    throws IOException
  {
    pad();
    pad().format("+ %s: offset=%d length=%d", new Object[] { paramJHeader2.getName(), Integer.valueOf(paramJHeader2.getOffset()), Integer.valueOf(paramJHeader2.getLength()) });
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.format.TextFormatter
 * JD-Core Version:    0.7.0.1
 */