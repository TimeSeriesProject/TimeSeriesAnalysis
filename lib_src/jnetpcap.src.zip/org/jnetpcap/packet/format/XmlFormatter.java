package org.jnetpcap.packet.format;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Formatter;
import org.jnetpcap.JCaptureHeader;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.structure.JField;

public class XmlFormatter
  extends JFormatter
{
  private static final String PAD = "  ";
  private static final String LT = "<";
  private static final String GT = ">";
  
  protected void fieldAfter(JHeader paramJHeader, JField paramJField, JFormatter.Detail paramDetail)
    throws IOException
  {
    if (paramJField.getStyle() == JFormatter.Style.BYTE_ARRAY_HEX_DUMP)
    {
      decLevel();
      pad().format("</hexdump>\n", new Object[0]);
    }
    else if (paramJField.getStyle() != JFormatter.Style.INT_BITS) {}
    decLevel();
  }
  
  public XmlFormatter() {}
  
  public XmlFormatter(Appendable paramAppendable)
  {
    super(paramAppendable);
  }
  
  public XmlFormatter(StringBuilder paramStringBuilder)
  {
    super(paramStringBuilder);
  }
  
  protected void fieldBefore(JHeader paramJHeader, JField paramJField, JFormatter.Detail paramDetail)
    throws IOException
  {
    incLevel("  ");
    Object localObject1;
    Object localObject3;
    if (paramJField.getStyle() == JFormatter.Style.BYTE_ARRAY_HEX_DUMP)
    {
      pad().format("<hexdump offset=\"%d\" length=\"%d\">", new Object[] { Integer.valueOf(paramJField.getOffset(paramJHeader)), Integer.valueOf(paramJField.getLength(paramJHeader)) });
      incLevel("  ");
      localObject1 = stylizeMultiLine(paramJHeader, paramJField, JFormatter.Style.BYTE_ARRAY_HEX_DUMP_NO_TEXT, paramJField.getValue(paramJHeader));
      incLevel("  ");
      for (localObject3 : localObject1) {
        pad().format("<hexline data=\"%s\"/>", new Object[] { localObject3.trim() });
      }
      decLevel();
    }
    else if (paramJField.getStyle() != JFormatter.Style.INT_BITS)
    {
      if (paramJField.getStyle() == JFormatter.Style.BYTE_ARRAY_ARRAY_IP4_ADDRESS)
      {
        localObject1 = (byte[][])paramJField.getValue(paramJHeader);
        for (localObject3 : localObject1)
        {
          String str = stylizeSingleLine(paramJHeader, paramJField, localObject3);
          pad().format("<ip4=\"%s\" />", new Object[] { str });
        }
        incLevel(0);
      }
      else
      {
        localObject1 = stylizeSingleLine(paramJHeader, paramJField, paramJField.getValue(paramJHeader));
        pad().format("<field name=\"%s\" value=\"%s\" offset=\"%d\" length=\"%d\"/>", new Object[] { paramJField.getName(), localObject1, Integer.valueOf(paramJField.getOffset(paramJHeader)), Integer.valueOf(paramJField.getLength(paramJHeader)) });
      }
    }
  }
  
  protected void headerAfter(JHeader paramJHeader, JFormatter.Detail paramDetail)
    throws IOException
  {
    pad().format("</header>", new Object[0]);
    pad();
  }
  
  protected void headerBefore(JHeader paramJHeader, JFormatter.Detail paramDetail)
    throws IOException
  {
    pad().format("<header name=\"%s\"", new Object[] { paramJHeader.getName() });
    incLevel("    ");
    pad().format("nicname=\"%s\"", new Object[] { paramJHeader.getNicname() });
    pad().format("classname=\"%s\"", new Object[] { paramJHeader.getClass().getCanonicalName() });
    pad().format("offset=\"%d\"", new Object[] { Integer.valueOf(paramJHeader.getOffset()) });
    pad().format("length=\"%d\">", new Object[] { Integer.valueOf(paramJHeader.getLength()) });
    decLevel();
  }
  
  public void packetAfter(JPacket paramJPacket, JFormatter.Detail paramDetail)
    throws IOException
  {
    decLevel();
    pad().format("</packet>", new Object[0]);
  }
  
  public void packetBefore(JPacket paramJPacket, JFormatter.Detail paramDetail)
    throws IOException
  {
    pad().format("<packet", new Object[0]);
    incLevel("    ");
    pad().format("wirelen=\"%d\"", new Object[] { Integer.valueOf(paramJPacket.getCaptureHeader().wirelen()) });
    pad().format("caplen=\"%d\"", new Object[] { Integer.valueOf(paramJPacket.getCaptureHeader().caplen()) });
    if (this.frameIndex != -1) {
      pad().format("index=\"%d\"", new Object[] { Integer.valueOf(this.frameIndex) });
    }
    pad().format("timestamp=\"%s\"", new Object[] { new Timestamp(paramJPacket.getCaptureHeader().timestampInMillis()) });
    pad().format("captureSeconds=\"%s\"", new Object[] { Long.valueOf(paramJPacket.getCaptureHeader().seconds()) });
    pad().format("captureNanoSeconds=\"%s\">", new Object[] { Long.valueOf(paramJPacket.getCaptureHeader().nanos()) });
    pad();
    decLevel();
    incLevel("  ");
  }
  
  protected void subHeaderAfter(JHeader paramJHeader1, JHeader paramJHeader2, JFormatter.Detail paramDetail)
    throws IOException
  {
    headerAfter(paramJHeader2, paramDetail);
    decLevel();
  }
  
  protected void subHeaderBefore(JHeader paramJHeader1, JHeader paramJHeader2, JFormatter.Detail paramDetail)
    throws IOException
  {
    incLevel("  ");
    pad();
    headerBefore(paramJHeader2, paramDetail);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.format.XmlFormatter
 * JD-Core Version:    0.7.0.1
 */