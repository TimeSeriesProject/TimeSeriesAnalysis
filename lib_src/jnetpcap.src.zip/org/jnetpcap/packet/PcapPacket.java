package org.jnetpcap.packet;

import java.nio.ByteBuffer;
import org.jnetpcap.PcapHeader;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JMemoryPool;

public class PcapPacket
  extends JPacket
{
  private static final int STATE_SIZE = PcapHeader.sizeof() + JPacket.State.sizeof(20);
  private final PcapHeader header = new PcapHeader(JMemory.Type.POINTER);
  
  private static native void initIds();
  
  public PcapPacket(byte[] paramArrayOfByte)
  {
    super(JMemory.Type.POINTER);
    transferStateAndDataFrom(paramArrayOfByte);
  }
  
  public PcapPacket(ByteBuffer paramByteBuffer)
  {
    super(JMemory.Type.POINTER);
    transferStateAndDataFrom(paramByteBuffer);
  }
  
  public PcapPacket(int paramInt)
  {
    super(paramInt, STATE_SIZE);
  }
  
  public PcapPacket(int paramInt1, int paramInt2)
  {
    super(paramInt1, PcapHeader.sizeof() + JPacket.State.sizeof(paramInt2));
  }
  
  public PcapPacket(JBuffer paramJBuffer)
  {
    super(JMemory.Type.POINTER);
    transferStateAndDataFrom(paramJBuffer);
  }
  
  public PcapPacket(JPacket paramJPacket)
  {
    super(JMemory.Type.POINTER);
    if ((paramJPacket instanceof PcapPacket)) {
      ((PcapPacket)paramJPacket).transferStateAndDataTo(this);
    } else {
      throw new UnsupportedOperationException("Unsupported packet type for this constructor");
    }
  }
  
  public PcapPacket(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer)
  {
    super(JMemory.Type.POINTER);
    transferHeaderAndDataFrom0(paramPcapHeader, paramByteBuffer);
  }
  
  public PcapPacket(PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    super(JMemory.Type.POINTER);
    transferHeaderAndDataFrom0(paramPcapHeader, paramJBuffer);
  }
  
  public PcapPacket(PcapPacket paramPcapPacket)
  {
    super(JMemory.Type.POINTER);
    paramPcapPacket.transferStateAndDataTo(this);
  }
  
  public PcapPacket(JMemory.Type paramType)
  {
    super(paramType);
  }
  
  public PcapHeader getCaptureHeader()
  {
    return this.header;
  }
  
  public int getTotalSize()
  {
    return super.size() + this.state.size() + this.header.size();
  }
  
  public int peerHeaderAndData(JBuffer paramJBuffer)
  {
    int i = this.header.peer(paramJBuffer, 0);
    i += super.peer(paramJBuffer, i, paramJBuffer.size() - this.header.size());
    return i;
  }
  
  public int peer(PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    int i = this.header.peerTo(paramPcapHeader, 0);
    i += peer(paramJBuffer);
    return i;
  }
  
  public int peerAndScan(int paramInt, PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    int i = this.header.peerTo(paramPcapHeader, 0);
    i += peer(paramJBuffer);
    scan(paramInt);
    return i;
  }
  
  public int peerHeaderAndData(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    int i = this.header.peerTo(paramPcapHeader, 0);
    i += super.peer(paramByteBuffer);
    return i;
  }
  
  public int peerHeaderAndData(PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    int i = this.header.peerTo(paramPcapHeader, 0);
    i += super.peer(paramJBuffer);
    return i;
  }
  
  public int peerStateAndData(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    if (!paramByteBuffer.isDirect()) {
      throw new PeeringException("unable to peer a non-direct ByteBuffer");
    }
    return peerStateAndData(getMemoryBuffer(paramByteBuffer), 0);
  }
  
  public int peerStateAndData(JBuffer paramJBuffer)
  {
    return peerStateAndData(getMemoryBuffer(paramJBuffer), 0);
  }
  
  private int peerStateAndData(JBuffer paramJBuffer, int paramInt)
  {
    int i = this.header.peer(paramJBuffer, paramInt);
    this.state.peerTo(paramJBuffer, paramInt + i, JPacket.State.sizeof(0));
    i += this.state.peerTo(paramJBuffer, paramInt + i, JPacket.State.sizeof(this.state.getHeaderCount()));
    i += super.peer(paramJBuffer, paramInt + i, this.header.caplen());
    return i;
  }
  
  public int transferHeaderAndDataFrom(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer)
  {
    return transferHeaderAndDataFrom0(paramPcapHeader, paramByteBuffer);
  }
  
  private int transferHeaderAndDataFrom0(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer)
  {
    return getMemoryPool().duplicate2(paramPcapHeader, paramByteBuffer, this.header, this);
  }
  
  public int transferHeaderAndDataFrom(PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    return transferHeaderAndDataFrom0(paramPcapHeader, paramJBuffer);
  }
  
  private int transferHeaderAndDataFrom0(PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    return getMemoryPool().duplicate2(paramPcapHeader, paramJBuffer, this.header, this);
  }
  
  public int transferStateAndDataFrom(byte[] paramArrayOfByte)
  {
    JBuffer localJBuffer = getMemoryBuffer(paramArrayOfByte);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public int transferStateAndDataFrom(ByteBuffer paramByteBuffer)
  {
    int i = paramByteBuffer.limit() - paramByteBuffer.position();
    JBuffer localJBuffer = getMemoryBuffer(i);
    localJBuffer.transferFrom(paramByteBuffer, 0);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public int transferStateAndDataFrom(JBuffer paramJBuffer)
  {
    int i = paramJBuffer.size();
    JBuffer localJBuffer = getMemoryBuffer(i);
    paramJBuffer.transferTo(localJBuffer);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public int transferStateAndDataFrom(PcapPacket paramPcapPacket)
  {
    return paramPcapPacket.transferStateAndDataTo(this);
  }
  
  public int transferStateAndDataTo(byte[] paramArrayOfByte)
  {
    int i = this.header.transferTo(paramArrayOfByte, 0);
    i += this.state.transferTo(paramArrayOfByte, i);
    i += super.transferTo(paramArrayOfByte, 0, size(), i);
    return i;
  }
  
  public int transferStateAndDataTo(ByteBuffer paramByteBuffer)
  {
    int i = this.header.transferTo(paramByteBuffer);
    i += this.state.transferTo(paramByteBuffer);
    i += super.transferTo(paramByteBuffer);
    return i;
  }
  
  public int transferStateAndDataTo(JBuffer paramJBuffer)
  {
    return transferStateAndDataTo(paramJBuffer, 0);
  }
  
  public int transferStateAndDataTo(JBuffer paramJBuffer, int paramInt)
  {
    int i = this.header.transferTo(paramJBuffer, paramInt);
    i += this.state.transferTo(paramJBuffer, 0, this.state.size(), paramInt + i);
    i += super.transferTo(paramJBuffer, 0, size(), paramInt + i);
    return i;
  }
  
  public int transferStateAndDataTo(PcapPacket paramPcapPacket)
  {
    JBuffer localJBuffer = paramPcapPacket.getMemoryBuffer(getTotalSize());
    int i = this.header.transferTo(localJBuffer, 0);
    paramPcapPacket.header.peerTo(localJBuffer, 0);
    paramPcapPacket.state.peerTo(localJBuffer, i, this.state.size());
    i += this.state.transferTo(paramPcapPacket.state);
    paramPcapPacket.peer(localJBuffer, i, size());
    i += transferTo(localJBuffer, 0, size(), i);
    return i;
  }
  
  static
  {
    try
    {
      initIds();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.PcapPacket
 * JD-Core Version:    0.7.0.1
 */