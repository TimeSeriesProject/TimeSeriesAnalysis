package org.jnetpcap.packet;

import java.nio.ByteBuffer;
import org.jnetpcap.JCaptureHeader;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.packet.format.FormatUtils;

public class JMemoryPacket
  extends JPacket
{
  private final JMemoryHeader header = new JMemoryHeader();
  
  public JMemoryPacket(byte[] paramArrayOfByte)
  {
    super(JMemory.Type.POINTER);
    JBuffer localJBuffer = getMemoryBuffer(paramArrayOfByte);
    super.peer(localJBuffer);
    this.header.setWirelen(paramArrayOfByte.length);
  }
  
  public JMemoryPacket(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    super(JMemory.Type.POINTER);
    int i = paramByteBuffer.limit() - paramByteBuffer.position();
    JBuffer localJBuffer = getMemoryBuffer(i);
    super.peer(localJBuffer);
    transferFrom(paramByteBuffer);
    this.header.setWirelen(i);
  }
  
  public JMemoryPacket(int paramInt)
  {
    super(paramInt, 0);
    this.header.setWirelen(paramInt);
    super.peer(this.memory);
  }
  
  public JMemoryPacket(int paramInt, byte[] paramArrayOfByte)
  {
    this(paramArrayOfByte);
    scan(paramInt);
  }
  
  public JMemoryPacket(int paramInt, ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    this(paramByteBuffer);
    scan(paramInt);
  }
  
  public JMemoryPacket(int paramInt, JBuffer paramJBuffer)
  {
    this(paramJBuffer);
    scan(paramInt);
  }
  
  public JMemoryPacket(int paramInt, String paramString)
  {
    this(paramInt, FormatUtils.toByteArray(paramString));
  }
  
  public JMemoryPacket(JBuffer paramJBuffer)
  {
    super(POINTER);
    this.header.setWirelen(paramJBuffer.size());
    int i = paramJBuffer.size();
    JBuffer localJBuffer = getMemoryBuffer(i);
    localJBuffer.transferFrom(paramJBuffer);
    peer(localJBuffer, 0, i);
    this.header.setWirelen(i);
  }
  
  public JMemoryPacket(JMemoryPacket paramJMemoryPacket)
  {
    super(JMemory.Type.POINTER);
    transferFrom(paramJMemoryPacket);
  }
  
  public JMemoryPacket(JPacket paramJPacket)
  {
    super(JMemory.Type.POINTER);
    transferFrom(paramJPacket);
  }
  
  public JMemoryPacket(JMemory.Type paramType)
  {
    super(paramType);
  }
  
  public JMemoryHeader getCaptureHeader()
  {
    return this.header;
  }
  
  public int getTotalSize()
  {
    return super.size() + this.state.size();
  }
  
  public int peerStateAndData(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    if (!paramByteBuffer.isDirect()) {
      throw new PeeringException("unable to peer a non-direct ByteBuffer");
    }
    return peerStateAndData(getMemoryBuffer(paramByteBuffer), 0);
  }
  
  public int peerStateAndData(JBuffer paramJBuffer)
  {
    return peerStateAndData(getMemoryBuffer(paramJBuffer), 0);
  }
  
  public int peerStateAndData(JBuffer paramJBuffer, int paramInt)
  {
    this.state.peerTo(paramJBuffer, paramInt, JPacket.State.sizeof(0));
    int i = this.state.peerTo(paramJBuffer, paramInt, JPacket.State.sizeof(this.state.getHeaderCount()));
    i += super.peer(paramJBuffer, paramInt + i, this.header.caplen());
    return i;
  }
  
  public void setWirelen(int paramInt)
  {
    this.header.setWirelen(paramInt);
  }
  
  public int transferStateAndDataFrom(byte[] paramArrayOfByte)
  {
    JBuffer localJBuffer = getMemoryBuffer(paramArrayOfByte);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public int transferStateAndDataFrom(ByteBuffer paramByteBuffer)
  {
    int i = paramByteBuffer.limit() - paramByteBuffer.position();
    JBuffer localJBuffer = getMemoryBuffer(i);
    localJBuffer.transferFrom(paramByteBuffer, 0);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public int transferStateAndDataFrom(JBuffer paramJBuffer)
  {
    int i = paramJBuffer.size();
    JBuffer localJBuffer = getMemoryBuffer(i);
    localJBuffer.transferFrom(paramJBuffer);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public int transferStateAndDataFrom(JMemoryPacket paramJMemoryPacket)
  {
    return paramJMemoryPacket.transferTo(this);
  }
  
  public int transferStateAndDataFrom(JPacket paramJPacket)
  {
    int i = paramJPacket.state.size() + paramJPacket.size();
    JBuffer localJBuffer = getMemoryBuffer(i);
    int j = paramJPacket.state.transferTo(localJBuffer, 0, paramJPacket.state.size(), 0);
    j += paramJPacket.transferTo(localJBuffer, 0, paramJPacket.size(), j);
    return j;
  }
  
  public int transferStateAndDataTo(JBuffer paramJBuffer, int paramInt)
  {
    int i = this.state.transferTo(paramJBuffer, 0, this.state.size(), paramInt);
    i += super.transferTo(paramJBuffer, 0, size(), paramInt + i);
    return i;
  }
  
  public int transferStateAndDataTo(JMemoryPacket paramJMemoryPacket)
  {
    JBuffer localJBuffer = paramJMemoryPacket.getMemoryBuffer(getTotalSize());
    paramJMemoryPacket.transferStateAndDataTo(localJBuffer, 0);
    return peerStateAndData(localJBuffer, 0);
  }
  
  public static class JMemoryHeader
    implements JCaptureHeader
  {
    private int caplen;
    private long inMicros;
    private long inMillis;
    private long inNanos;
    private long nanos;
    private long seconds;
    private int wirelen;
    
    public JMemoryHeader()
    {
      this(0, 0, System.currentTimeMillis() / 1000L, System.nanoTime());
    }
    
    public JMemoryHeader(int paramInt1, int paramInt2, long paramLong1, long paramLong2)
    {
      init(paramInt1, paramInt2, paramLong2, paramLong1);
    }
    
    public int caplen()
    {
      return this.caplen;
    }
    
    public void caplen(int paramInt)
    {
      this.caplen = paramInt;
      if (this.wirelen == 0) {
        setWirelen(paramInt);
      }
    }
    
    public final int getWirelen()
    {
      return this.wirelen;
    }
    
    public void init(int paramInt1, int paramInt2, long paramLong1, long paramLong2)
    {
      this.caplen = paramInt1;
      this.wirelen = paramInt2;
      this.nanos = paramLong1;
      this.seconds = paramLong2;
      initCompound();
    }
    
    private void initCompound()
    {
      this.inMillis = (this.seconds * 1000L + this.nanos / 1000000L);
      this.inMicros = (this.seconds * 1000000L + this.nanos / 1000L);
      this.inNanos = (this.seconds * 1000000000L + this.nanos);
    }
    
    public void initFrom(JCaptureHeader paramJCaptureHeader)
    {
      init(paramJCaptureHeader.caplen(), paramJCaptureHeader.wirelen(), paramJCaptureHeader.nanos(), paramJCaptureHeader.seconds());
    }
    
    public long nanos()
    {
      return this.nanos;
    }
    
    public void nanos(long paramLong)
    {
      this.nanos = paramLong;
      initCompound();
    }
    
    public long seconds()
    {
      return this.seconds;
    }
    
    public void seconds(long paramLong)
    {
      this.seconds = paramLong;
      initCompound();
    }
    
    public final void setWirelen(int paramInt)
    {
      this.wirelen = paramInt;
      if (this.caplen == 0) {
        this.caplen = paramInt;
      }
    }
    
    public long timestampInMicros()
    {
      return this.inMicros;
    }
    
    public long timestampInMillis()
    {
      return this.inMillis;
    }
    
    public long timestampInNanos()
    {
      return this.inNanos;
    }
    
    public int wirelen()
    {
      return this.wirelen;
    }
    
    public void wirelen(int paramInt)
    {
      this.wirelen = paramInt;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JMemoryPacket
 * JD-Core Version:    0.7.0.1
 */