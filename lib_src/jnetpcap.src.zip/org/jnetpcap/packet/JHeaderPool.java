package org.jnetpcap.packet;

import org.jnetpcap.protocol.JProtocol;

public class JHeaderPool
{
  private static JHeaderPool local = new JHeaderPool();
  private ThreadLocal<? extends JHeader>[] locals = new ThreadLocal[64];
  
  public JHeader getHeader(int paramInt)
    throws UnregisteredHeaderException
  {
    return getHeader(JRegistry.lookupClass(paramInt), paramInt);
  }
  
  public <T extends JHeader> T getHeader(JProtocol paramJProtocol)
  {
    return getHeader(paramJProtocol.getHeaderClass(), paramJProtocol.getId());
  }
  
  public <T extends JHeader> T getHeader(final Class<T> paramClass, int paramInt)
  {
    Object localObject = this.locals[paramInt];
    if (localObject == null)
    {
      localObject = new ThreadLocal()
      {
        protected T initialValue()
        {
          try
          {
            return (JHeader)paramClass.newInstance();
          }
          catch (Exception localException)
          {
            throw new IllegalStateException(localException);
          }
        }
      };
      this.locals[paramInt] = localObject;
    }
    return (JHeader)((ThreadLocal)localObject).get();
  }
  
  public static JHeaderPool getDefault()
  {
    return local;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JHeaderPool
 * JD-Core Version:    0.7.0.1
 */