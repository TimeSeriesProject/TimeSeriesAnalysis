package org.jnetpcap.packet;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.jnetpcap.packet.annotate.Dynamic;
import org.jnetpcap.packet.annotate.Field.Property;
import org.jnetpcap.packet.structure.JField;
import org.jnetpcap.protocol.JProtocol;

public class JMappedHeader
  extends JHeader
{
  private final Map<String, Entry> fieldMap = new HashMap(50);
  
  public JMappedHeader() {}
  
  public JMappedHeader(JProtocol paramJProtocol)
  {
    super(paramJProtocol);
  }
  
  public JMappedHeader(int paramInt, JField[] paramArrayOfJField, String paramString)
  {
    super(paramInt, paramArrayOfJField, paramString);
  }
  
  public JMappedHeader(int paramInt, JField[] paramArrayOfJField, String paramString1, String paramString2)
  {
    super(paramInt, paramArrayOfJField, paramString1, paramString2);
  }
  
  public JMappedHeader(int paramInt, String paramString)
  {
    super(paramInt, paramString);
  }
  
  public JMappedHeader(int paramInt, String paramString1, String paramString2)
  {
    super(paramInt, paramString1, paramString2);
  }
  
  public JMappedHeader(JHeader.State paramState, JField[] paramArrayOfJField, String paramString1, String paramString2)
  {
    super(paramState, paramArrayOfJField, paramString1, paramString2);
  }
  
  protected boolean hasField(Enum<? extends Enum<?>> paramEnum)
  {
    return this.fieldMap.containsKey(map(paramEnum));
  }
  
  @Dynamic(Field.Property.CHECK)
  protected boolean hasField(String paramString)
  {
    return this.fieldMap.containsKey(map(paramString));
  }
  
  protected String fieldDescription(Enum<? extends Enum<?>> paramEnum)
  {
    return ((Entry)this.fieldMap.get(map(paramEnum))).getValueDescription(this);
  }
  
  @Dynamic(Field.Property.DESCRIPTION)
  protected String fieldDescription(String paramString)
  {
    return ((Entry)this.fieldMap.get(map(paramString))).getValueDescription(this);
  }
  
  protected String fieldDisplay(Enum<? extends Enum<?>> paramEnum)
  {
    return ((Entry)this.fieldMap.get(map(paramEnum))).getDisplay(this);
  }
  
  @Dynamic(Field.Property.DISPLAY)
  protected String fieldDisplay(String paramString)
  {
    return ((Entry)this.fieldMap.get(map(paramString))).getDisplay(this);
  }
  
  protected int fieldLength(Enum<? extends Enum<?>> paramEnum)
  {
    return ((Entry)this.fieldMap.get(map(paramEnum))).getLength(this);
  }
  
  @Dynamic(Field.Property.LENGTH)
  protected int fieldLength(String paramString)
  {
    return ((Entry)this.fieldMap.get(map(paramString))).getLength(this);
  }
  
  protected int fieldOffset(Enum<? extends Enum<?>> paramEnum)
  {
    return ((Entry)this.fieldMap.get(map(paramEnum))).getOffset(this);
  }
  
  protected String map(Enum<? extends Enum<?>> paramEnum)
  {
    String str = paramEnum.name().replace('_', '-').toUpperCase();
    return str;
  }
  
  protected String map(String paramString)
  {
    String str = paramString.toUpperCase();
    return str;
  }
  
  @Dynamic(Field.Property.OFFSET)
  protected int fieldOffset(String paramString)
  {
    if (this.fieldMap.get(map(paramString)) == null) {
      return -1;
    }
    return ((Entry)this.fieldMap.get(map(paramString))).getOffset(this);
  }
  
  protected Object fieldValue(Enum<? extends Enum<?>> paramEnum)
  {
    return ((Entry)this.fieldMap.get(map(paramEnum))).getValue(this);
  }
  
  @Dynamic(Field.Property.VALUE)
  protected Object fieldValue(String paramString)
  {
    return ((Entry)this.fieldMap.get(map(paramString))).getValue(this);
  }
  
  protected <V> V fieldValue(Class<V> paramClass, Enum<? extends Enum<?>> paramEnum)
  {
    Entry localEntry = (Entry)this.fieldMap.get(map(paramEnum));
    if (localEntry == null) {
      return null;
    }
    return localEntry.getValue(paramClass, this);
  }
  
  protected <V> V fieldValue(Class<V> paramClass, String paramString)
  {
    return ((Entry)this.fieldMap.get(map(paramString))).getValue(paramClass, this);
  }
  
  public String[] fieldArray()
  {
    String[] arrayOfString = (String[])this.fieldMap.keySet().toArray(new String[this.fieldMap.size()]);
    Arrays.sort(arrayOfString, new Comparator()
    {
      public int compare(String paramAnonymousString1, String paramAnonymousString2)
      {
        return ((JMappedHeader.Entry)JMappedHeader.this.fieldMap.get(paramAnonymousString1)).getOffset(JMappedHeader.this) - ((JMappedHeader.Entry)JMappedHeader.this.fieldMap.get(paramAnonymousString2)).getOffset(JMappedHeader.this);
      }
    });
    return arrayOfString;
  }
  
  public void addField(Enum<? extends Enum<?>> paramEnum, String paramString, int paramInt)
  {
    addField(paramEnum, paramString, paramInt, paramString.length());
  }
  
  public void addField(Enum<? extends Enum<?>> paramEnum, String paramString, int paramInt1, int paramInt2)
  {
    this.fieldMap.put(map(paramEnum), new Entry(paramString, paramInt1, paramInt2, paramEnum.name(), null));
  }
  
  public void addField(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    this.fieldMap.put(paramString1, new Entry(paramString2, paramInt1, paramInt2, paramString1, null));
  }
  
  public void clearFields()
  {
    this.fieldMap.clear();
  }
  
  private static class Entry
  {
    private final String description;
    private final String display;
    private final int length;
    private final int offset;
    private final Object value;
    
    public Entry(Object paramObject, int paramInt1, int paramInt2, String paramString1, String paramString2)
    {
      this.value = paramObject;
      this.offset = paramInt1;
      this.length = paramInt2;
      this.display = paramString1;
      this.description = paramString2;
    }
    
    public String getValueDescription(JHeader paramJHeader)
    {
      return this.description;
    }
    
    public int getLength(JMappedHeader paramJMappedHeader)
    {
      return this.length;
    }
    
    public String getDisplay(JMappedHeader paramJMappedHeader)
    {
      return this.display;
    }
    
    public int getOffset(JMappedHeader paramJMappedHeader)
    {
      return this.offset;
    }
    
    public Object getValue(JMappedHeader paramJMappedHeader)
    {
      return this.value;
    }
    
    public <V> V getValue(Class<V> paramClass, JMappedHeader paramJMappedHeader)
    {
      return this.value;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JMappedHeader
 * JD-Core Version:    0.7.0.1
 */