package org.jnetpcap.packet;

import org.jnetpcap.nio.JMemoryReference;

public class JScannerReference
  extends JMemoryReference
{
  public JScannerReference(Object paramObject, long paramLong1, long paramLong2)
  {
    super(paramObject, paramLong1, paramLong2);
  }
  
  protected native void disposeNative(long paramLong);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JScannerReference
 * JD-Core Version:    0.7.0.1
 */