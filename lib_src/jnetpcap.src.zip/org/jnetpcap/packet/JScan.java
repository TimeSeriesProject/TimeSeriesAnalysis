package org.jnetpcap.packet;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JStruct;

public class JScan
  extends JStruct
{
  private static final String STRUCT_NAME = "scan_t";
  public static final int END_OF_HEADERS_ID = -1;
  
  public JScan()
  {
    super("scan_t", sizeof());
  }
  
  public JScan(JMemory.Type paramType)
  {
    super("scan_t", paramType);
  }
  
  public native int scan_id();
  
  public native int scan_next_id();
  
  public native int scan_length();
  
  public native void scan_id(int paramInt);
  
  public native void scan_next_id(int paramInt);
  
  public native void scan_length(int paramInt);
  
  public native int scan_prefix();
  
  public native int scan_gap();
  
  public native int scan_payload();
  
  public native int scan_postix();
  
  public native int record_header();
  
  public native void scan_prefix(int paramInt);
  
  public native void scan_gap(int paramInt);
  
  public native void scan_payload(int paramInt);
  
  public native void scan_postix(int paramInt);
  
  public native void record_header(int paramInt);
  
  public native void scan_set_lengths(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static native int sizeof();
  
  public native void scan_buf(JBuffer paramJBuffer);
  
  public native void scan_buf_len(int paramInt);
  
  public native void scan_offset(int paramInt);
  
  public native JPacket scan_packet();
  
  public native int scan_offset();
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JScan
 * JD-Core Version:    0.7.0.1
 */