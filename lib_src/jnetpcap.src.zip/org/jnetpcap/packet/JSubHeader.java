package org.jnetpcap.packet;

import org.jnetpcap.packet.structure.JField;

public class JSubHeader<T extends JHeader>
  extends JHeader
{
  private int length;
  private int offset;
  private JHeader parent;
  
  public JSubHeader() {}
  
  public JSubHeader(int paramInt, JField[] paramArrayOfJField, String paramString1, String paramString2)
  {
    super(paramInt, paramArrayOfJField, paramString1, paramString2);
  }
  
  public JSubHeader(int paramInt, JField[] paramArrayOfJField, String paramString)
  {
    super(paramInt, paramArrayOfJField, paramString);
  }
  
  public JSubHeader(int paramInt, String paramString1, String paramString2)
  {
    super(paramInt, paramString1, paramString2);
  }
  
  public JSubHeader(int paramInt, String paramString)
  {
    super(paramInt, paramString);
  }
  
  public JSubHeader(JHeader.State paramState, JField[] paramArrayOfJField, String paramString1, String paramString2)
  {
    super(paramState, paramArrayOfJField, paramString1, paramString2);
  }
  
  public int getLength()
  {
    return this.length;
  }
  
  public int getOffset()
  {
    return this.offset;
  }
  
  public void setOffset(int paramInt)
  {
    this.offset = paramInt;
  }
  
  public void setLength(int paramInt)
  {
    this.length = paramInt;
  }
  
  public void setParent(JHeader paramJHeader)
  {
    this.parent = paramJHeader;
  }
  
  public JHeader getParent()
  {
    return this.parent;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JSubHeader
 * JD-Core Version:    0.7.0.1
 */