package org.jnetpcap.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import org.jnetpcap.nio.JFunction;
import org.jnetpcap.packet.annotate.HeaderLength.Type;
import org.jnetpcap.packet.structure.AnnotatedHeaderLengthMethod;
import org.jnetpcap.packet.structure.AnnotatedScannerMethod;
import org.jnetpcap.protocol.JProtocol;

public class JHeaderScanner
  extends JFunction
{
  private static final String FUNCT_NAME = "scan_";
  private JBinding[] bindings = null;
  private final List<JBinding> bindingsList = new ArrayList();
  private final int id;
  private AnnotatedHeaderLengthMethod[] lengthMethods;
  private AnnotatedScannerMethod scannerMethod;
  private final JProtocol protocol;
  private boolean needJProtocolInitialization;
  
  public JHeaderScanner(Class<? extends JHeader> paramClass)
  {
    super("java header scanner");
    this.protocol = null;
    this.needJProtocolInitialization = false;
    this.id = JRegistry.lookupId(paramClass);
    this.lengthMethods = AnnotatedHeaderLengthMethod.inspectClass(paramClass);
    if (AnnotatedScannerMethod.inspectClass(paramClass).length != 0) {
      this.scannerMethod = AnnotatedScannerMethod.inspectClass(paramClass)[0];
    } else {
      this.scannerMethod = null;
    }
  }
  
  public JHeaderScanner(JProtocol paramJProtocol)
  {
    super("scan_" + paramJProtocol.toString().toLowerCase());
    this.protocol = paramJProtocol;
    this.id = paramJProtocol.getId();
    this.needJProtocolInitialization = true;
    bindNativeScanner(this.id);
  }
  
  private void initFromJProtocol(JProtocol paramJProtocol)
  {
    Class localClass = paramJProtocol.getHeaderClass();
    this.lengthMethods = AnnotatedHeaderLengthMethod.inspectClass(localClass);
    if (AnnotatedScannerMethod.inspectClass(localClass).length != 0) {
      this.scannerMethod = AnnotatedScannerMethod.inspectClass(localClass)[0];
    } else {
      this.scannerMethod = null;
    }
    this.needJProtocolInitialization = false;
  }
  
  private AnnotatedHeaderLengthMethod getLengthMethod(HeaderLength.Type paramType)
  {
    if (this.needJProtocolInitialization) {
      initFromJProtocol(this.protocol);
    }
    return this.lengthMethods[paramType.ordinal()];
  }
  
  private AnnotatedScannerMethod getScannerMethod()
  {
    if (this.needJProtocolInitialization) {
      initFromJProtocol(this.protocol);
    }
    return this.scannerMethod;
  }
  
  public boolean addBindings(JBinding... paramVarArgs)
  {
    this.bindings = null;
    return this.bindingsList.addAll(Arrays.asList(paramVarArgs));
  }
  
  private native void bindNativeScanner(int paramInt);
  
  public void clearBindings()
  {
    this.bindings = null;
    this.bindingsList.clear();
  }
  
  public boolean hasBindings()
  {
    return !this.bindingsList.isEmpty();
  }
  
  public JBinding[] getBindings()
  {
    if (this.bindings == null) {
      this.bindings = ((JBinding[])this.bindingsList.toArray(new JBinding[this.bindingsList.size()]));
    }
    return this.bindings;
  }
  
  public int getHeaderLength(JPacket paramJPacket, int paramInt)
  {
    return getLengthMethod(HeaderLength.Type.HEADER).getHeaderLength(paramJPacket, paramInt);
  }
  
  public int getPrefixLength(JPacket paramJPacket, int paramInt)
  {
    return getLengthMethod(HeaderLength.Type.PREFIX) == null ? 0 : getLengthMethod(HeaderLength.Type.PREFIX).getHeaderLength(paramJPacket, paramInt);
  }
  
  public int getGapLength(JPacket paramJPacket, int paramInt)
  {
    return getLengthMethod(HeaderLength.Type.GAP) == null ? 0 : getLengthMethod(HeaderLength.Type.GAP).getHeaderLength(paramJPacket, paramInt);
  }
  
  public int getPayloadLength(JPacket paramJPacket, int paramInt)
  {
    return getLengthMethod(HeaderLength.Type.PAYLOAD) == null ? 0 : getLengthMethod(HeaderLength.Type.PAYLOAD).getHeaderLength(paramJPacket, paramInt);
  }
  
  public int getPostfixLength(JPacket paramJPacket, int paramInt)
  {
    return getLengthMethod(HeaderLength.Type.POSTFIX) == null ? 0 : getLengthMethod(HeaderLength.Type.POSTFIX).getHeaderLength(paramJPacket, paramInt);
  }
  
  public final int getId()
  {
    return this.id;
  }
  
  public boolean isDirect()
  {
    return (super.isInitialized()) && (getScannerMethod() == null);
  }
  
  private native void nativeScan(JScan paramJScan);
  
  public boolean removeBindings(JBinding... paramVarArgs)
  {
    this.bindings = null;
    return this.bindingsList.removeAll(Arrays.asList(paramVarArgs));
  }
  
  public int scanAllBindings(JPacket paramJPacket, int paramInt)
  {
    for (JBinding localJBinding : getBindings()) {
      if ((localJBinding != null) && (localJBinding.isBound(paramJPacket, paramInt))) {
        return localJBinding.getSourceId();
      }
    }
    return 0;
  }
  
  protected void scanHeader(JScan paramJScan)
  {
    JPacket localJPacket;
    int i;
    if (getScannerMethod() != null)
    {
      getScannerMethod().scan(paramJScan);
    }
    else if (isDirect())
    {
      nativeScan(paramJScan);
    }
    else
    {
      localJPacket = paramJScan.scan_packet();
      i = paramJScan.scan_offset();
      setAllLengths(paramJScan, localJPacket, i);
    }
    if (paramJScan.scan_length() == 0) {
      return;
    }
    if (paramJScan.scan_next_id() == 0)
    {
      paramJScan.record_header();
      localJPacket = paramJScan.scan_packet();
      i = paramJScan.scan_offset();
      paramJScan.scan_offset(i);
      int j = scanAllBindings(localJPacket, i + paramJScan.scan_length() + paramJScan.scan_gap());
      paramJScan.scan_next_id(j);
    }
  }
  
  private void setAllLengths(JScan paramJScan, JPacket paramJPacket, int paramInt)
  {
    if (this.needJProtocolInitialization) {
      initFromJProtocol(this.protocol);
    }
    int i = this.lengthMethods[HeaderLength.Type.PREFIX.ordinal()] == null ? 0 : this.lengthMethods[HeaderLength.Type.PREFIX.ordinal()].getHeaderLength(paramJPacket, paramInt);
    paramInt += i;
    int j = this.lengthMethods[HeaderLength.Type.HEADER.ordinal()].getHeaderLength(paramJPacket, paramInt);
    int k = this.lengthMethods[HeaderLength.Type.GAP.ordinal()] == null ? 0 : this.lengthMethods[HeaderLength.Type.GAP.ordinal()].getHeaderLength(paramJPacket, paramInt);
    int m = this.lengthMethods[HeaderLength.Type.PAYLOAD.ordinal()] == null ? 0 : this.lengthMethods[HeaderLength.Type.PAYLOAD.ordinal()].getHeaderLength(paramJPacket, paramInt);
    int n = this.lengthMethods[HeaderLength.Type.POSTFIX.ordinal()] == null ? 0 : this.lengthMethods[HeaderLength.Type.POSTFIX.ordinal()].getHeaderLength(paramJPacket, paramInt);
    paramJScan.scan_set_lengths(i, j, k, m, n);
  }
  
  public void setScannerMethod(AnnotatedScannerMethod paramAnnotatedScannerMethod)
  {
    this.scannerMethod = paramAnnotatedScannerMethod;
  }
  
  public String toString()
  {
    Formatter localFormatter = new Formatter();
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = this.bindingsList.iterator();
    while (localIterator.hasNext())
    {
      JBinding localJBinding = (JBinding)localIterator.next();
      if (localStringBuilder.length() != 0) {
        localStringBuilder.append(',');
      }
      localStringBuilder.append(JRegistry.lookupClass(localJBinding.getSourceId()).getSimpleName());
    }
    localFormatter.format("id=%2d, loaded=%-5s direct=%-5s, scan=%-5s bindings=%-2d [%s]", new Object[] { Integer.valueOf(this.id), Boolean.valueOf(this.lengthMethods != null ? 1 : false), Boolean.valueOf(isDirect()), Boolean.valueOf(hasScanMethod()), Integer.valueOf(this.bindingsList.size()), localStringBuilder });
    return localFormatter.toString();
  }
  
  public boolean hasScanMethod()
  {
    return getScannerMethod() != null;
  }
  
  static
  {
    JScanner.sizeof();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JHeaderScanner
 * JD-Core Version:    0.7.0.1
 */