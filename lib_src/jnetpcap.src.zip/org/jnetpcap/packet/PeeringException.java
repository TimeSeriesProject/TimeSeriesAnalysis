package org.jnetpcap.packet;

public class PeeringException
  extends Exception
{
  private static final long serialVersionUID = 7136151191443182266L;
  
  public PeeringException() {}
  
  public PeeringException(String paramString)
  {
    super(paramString);
  }
  
  public PeeringException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
  
  public PeeringException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.PeeringException
 * JD-Core Version:    0.7.0.1
 */