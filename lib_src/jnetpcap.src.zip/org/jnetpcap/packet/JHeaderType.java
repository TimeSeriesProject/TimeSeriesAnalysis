package org.jnetpcap.packet;

public abstract interface JHeaderType
{
  public abstract int[] getTypeValues();
  
  public abstract int ordinal();
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JHeaderType
 * JD-Core Version:    0.7.0.1
 */