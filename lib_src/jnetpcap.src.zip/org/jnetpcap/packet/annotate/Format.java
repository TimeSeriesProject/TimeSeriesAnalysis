package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;

public @interface Format {}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.Format
 * JD-Core Version:    0.7.0.1
 */