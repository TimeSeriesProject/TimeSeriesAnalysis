package org.jnetpcap.packet.annotate;

import org.jnetpcap.packet.structure.AnnotatedField;
import org.jnetpcap.packet.structure.HeaderDefinitionError;

public class FieldDefinitionException
  extends HeaderDefinitionError
{
  private static final long serialVersionUID = 2116907712440514743L;
  private final AnnotatedField field;
  
  public FieldDefinitionException(AnnotatedField paramAnnotatedField)
  {
    super(paramAnnotatedField.getDeclaringClass());
    this.field = paramAnnotatedField;
  }
  
  public FieldDefinitionException(String paramString)
  {
    super(paramString);
    this.field = null;
  }
  
  public FieldDefinitionException(AnnotatedField paramAnnotatedField, String paramString)
  {
    super(paramAnnotatedField.getDeclaringClass(), paramString);
    this.field = paramAnnotatedField;
  }
  
  public FieldDefinitionException(Throwable paramThrowable)
  {
    super(paramThrowable);
    this.field = null;
  }
  
  public FieldDefinitionException(AnnotatedField paramAnnotatedField, Throwable paramThrowable)
  {
    super(paramAnnotatedField.getDeclaringClass(), paramThrowable);
    this.field = paramAnnotatedField;
  }
  
  public FieldDefinitionException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
    this.field = null;
  }
  
  public FieldDefinitionException(AnnotatedField paramAnnotatedField, String paramString, Throwable paramThrowable)
  {
    super(paramAnnotatedField.getDeclaringClass(), paramString, paramThrowable);
    this.field = paramAnnotatedField;
  }
  
  public final AnnotatedField getField()
  {
    return this.field;
  }
  
  protected String getPath()
  {
    return super.getPath() + this.field.getName();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.FieldDefinitionException
 * JD-Core Version:    0.7.0.1
 */