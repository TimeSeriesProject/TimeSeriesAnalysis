package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jnetpcap.PcapDLT;
import org.jnetpcap.packet.JHeader;

@Target({java.lang.annotation.ElementType.TYPE})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Header
{
  Characteristic[] characteristics() default {};
  
  String description() default "";
  
  PcapDLT[] dlt() default {};
  
  String format() default "";
  
  int id() default -1;
  
  int length() default -1;
  
  int prefix() default -1;
  
  int gap() default -1;
  
  int payload() default -1;
  
  int postfix() default -1;
  
  String name() default "";
  
  String nicname() default "";
  
  ProtocolSuite suite() default ProtocolSuite.OTHER;
  
  Layer osi() default Layer.NULL;
  
  Class<? extends JHeader> parent() default JHeader.class;
  
  String[] spec() default {};
  
  String url() default "";
  
  public static enum Characteristic
  {
    NULL,  POINT_TO_POINT,  POINT_TO_MULTIPOINT,  CSMA_CD;
    
    private Characteristic() {}
  }
  
  public static enum Layer
  {
    NULL,  PHYSICAL,  DATALINK,  NETWORK,  TRANSPORT,  SESSION,  PRESENTATION,  APPLICATION;
    
    private Layer() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.Header
 * JD-Core Version:    0.7.0.1
 */