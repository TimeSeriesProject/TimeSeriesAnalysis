package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface FieldSetter {}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.FieldSetter
 * JD-Core Version:    0.7.0.1
 */