package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;

public @interface Analyzer
{
  public static final int DEFAULT_PRIORITY = 100;
  
  int priority() default 100;
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.Analyzer
 * JD-Core Version:    0.7.0.1
 */