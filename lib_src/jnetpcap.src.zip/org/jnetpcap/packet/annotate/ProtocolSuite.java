package org.jnetpcap.packet.annotate;

import org.jnetpcap.protocol.JProtocol.Suite;

public enum ProtocolSuite
  implements JProtocol.Suite
{
  APPLICATION,  TCP_IP,  SECURITY,  VPN,  MOBILE,  NETWORK,  WIRELESS,  VOIP,  LAN,  MAN,  WAN,  SAN,  ISO,  SS7,  CISCO,  IBM,  MICROSOFT,  NOVELL,  APPLE,  HP,  SUN,  OTHER;
  
  private ProtocolSuite() {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.ProtocolSuite
 * JD-Core Version:    0.7.0.1
 */