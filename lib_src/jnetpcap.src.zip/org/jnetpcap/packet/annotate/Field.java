package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jnetpcap.packet.format.JFormatter.Priority;

@Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.FIELD})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Field
{
  public static final String EMPTY = "";
  public static final String DEFAULT_FORMAT = "%s";
  
  int offset() default -1;
  
  int length() default -1;
  
  String name() default "";
  
  String display() default "";
  
  String nicname() default "";
  
  String format() default "%s";
  
  String units() default "";
  
  String description() default "";
  
  String parent() default "";
  
  long mask() default -1L;
  
  JFormatter.Priority priority() default JFormatter.Priority.MEDIUM;
  
  public static enum Property
  {
    CHECK,  OFFSET,  LENGTH,  VALUE,  DESCRIPTION,  DISPLAY,  MASK,  UNITS;
    
    private Property() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.Field
 * JD-Core Version:    0.7.0.1
 */