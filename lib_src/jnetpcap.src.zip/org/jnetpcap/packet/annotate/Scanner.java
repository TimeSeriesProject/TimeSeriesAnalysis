package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jnetpcap.packet.JHeader;

@Target({java.lang.annotation.ElementType.METHOD})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Scanner
{
  Class<? extends JHeader> value() default JHeader.class;
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.Scanner
 * JD-Core Version:    0.7.0.1
 */