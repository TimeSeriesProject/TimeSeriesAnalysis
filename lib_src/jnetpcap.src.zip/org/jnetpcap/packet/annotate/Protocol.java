package org.jnetpcap.packet.annotate;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jnetpcap.packet.JHeader;

@Target({java.lang.annotation.ElementType.TYPE})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Protocol
{
  Suite suite() default Suite.OTHER;
  
  Class<? extends JHeader>[] headers() default {JHeader.class};
  
  String[] description() default {""};
  
  String[] license() default {""};
  
  String company() default "";
  
  String[] rfcs() default {""};
  
  public static enum Suite
  {
    APPLICATION,  TCP_IP,  SECURITY,  VPN,  MOBILE,  NETWORK,  WIRELESS,  VOIP,  LAN,  MAN,  WAN,  SAN,  ISO,  SS7,  CISCO,  IBM,  MICROSOFT,  NOVELL,  APPLE,  HP,  SUN,  OTHER;
    
    private Suite() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.annotate.Protocol
 * JD-Core Version:    0.7.0.1
 */