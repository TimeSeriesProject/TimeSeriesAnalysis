package org.jnetpcap.packet;

public abstract interface JBinding
  extends JDependency
{
  public static final int NULL_ID = -2;
  
  public abstract int getTargetId();
  
  public abstract boolean isBound(JPacket paramJPacket, int paramInt);
  
  public abstract int[] listDependencies();
  
  public abstract int getSourceId();
  
  public static abstract class DefaultJBinding
    implements JBinding
  {
    private final int[] dependencyIds;
    private final int myId;
    private final int targetId;
    
    public DefaultJBinding(int paramInt1, int paramInt2, int... paramVarArgs)
    {
      this.myId = paramInt1;
      this.targetId = paramInt2;
      this.dependencyIds = new int[paramVarArgs.length + 1];
      System.arraycopy(paramVarArgs, 0, this.dependencyIds, 1, paramVarArgs.length);
      this.dependencyIds[0] = paramInt2;
    }
    
    public int getId()
    {
      return this.myId;
    }
    
    public int getTargetId()
    {
      return this.targetId;
    }
    
    public int[] listDependencies()
    {
      return this.dependencyIds;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JBinding
 * JD-Core Version:    0.7.0.1
 */