package org.jnetpcap.packet;

public class RegistryRuntimeException
  extends RuntimeException
{
  private static final long serialVersionUID = 2093913023976126160L;
  
  public RegistryRuntimeException() {}
  
  public RegistryRuntimeException(String paramString)
  {
    super(paramString);
  }
  
  public RegistryRuntimeException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
  
  public RegistryRuntimeException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.RegistryRuntimeException
 * JD-Core Version:    0.7.0.1
 */