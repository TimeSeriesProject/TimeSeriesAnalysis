package org.jnetpcap.packet;

import java.nio.ByteBuffer;
import org.jnetpcap.nio.JBuffer;

public abstract interface JPayloadAccessor
{
  public abstract byte[] getPayload();
  
  public abstract byte[] transferPayloadTo(byte[] paramArrayOfByte);
  
  public abstract JBuffer peerPayloadTo(JBuffer paramJBuffer);
  
  public abstract JBuffer transferPayloadTo(JBuffer paramJBuffer);
  
  public abstract ByteBuffer transferPayloadTo(ByteBuffer paramByteBuffer);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JPayloadAccessor
 * JD-Core Version:    0.7.0.1
 */