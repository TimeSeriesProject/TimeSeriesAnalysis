package org.jnetpcap.packet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jnetpcap.packet.structure.HeaderDefinitionError;

public class RegistryHeaderErrors
  extends RegistryException
{
  private final List<HeaderDefinitionError> errors;
  private final Class<? extends JHeader> headerClass;
  private static final long serialVersionUID = -6414263503074702593L;
  
  public final HeaderDefinitionError[] getErrors()
  {
    return (HeaderDefinitionError[])this.errors.toArray(new HeaderDefinitionError[this.errors.size()]);
  }
  
  public final Class<? extends JHeader> getHeaderClass()
  {
    return this.headerClass;
  }
  
  public RegistryHeaderErrors(Class<? extends JHeader> paramClass, List<HeaderDefinitionError> paramList, String paramString)
  {
    super(paramString);
    this.headerClass = paramClass;
    this.errors = new ArrayList(paramList);
  }
  
  public String getMessage()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = this.errors.iterator();
    while (localIterator.hasNext())
    {
      HeaderDefinitionError localHeaderDefinitionError = (HeaderDefinitionError)localIterator.next();
      localStringBuilder.append(localHeaderDefinitionError.getMessage()).append('\n');
    }
    localStringBuilder.append('\n');
    localStringBuilder.append(super.getMessage());
    return localStringBuilder.toString();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.RegistryHeaderErrors
 * JD-Core Version:    0.7.0.1
 */