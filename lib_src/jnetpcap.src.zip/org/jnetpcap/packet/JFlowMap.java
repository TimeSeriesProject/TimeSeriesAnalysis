package org.jnetpcap.packet;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class JFlowMap
  extends HashMap<JFlowKey, JFlow>
  implements PcapPacketHandler<Object>
{
  private static final long serialVersionUID = -5590314946675005059L;
  private int count = 0;
  
  public JFlowMap() {}
  
  public JFlowMap(int paramInt)
  {
    super(paramInt);
  }
  
  public JFlowMap(Map<? extends JFlowKey, ? extends JFlow> paramMap)
  {
    super(paramMap);
  }
  
  public JFlowMap(int paramInt, float paramFloat)
  {
    super(paramInt, paramFloat);
  }
  
  public void nextPacket(PcapPacket paramPcapPacket, Object paramObject)
  {
    paramPcapPacket = new PcapPacket(paramPcapPacket);
    JFlowKey localJFlowKey = paramPcapPacket.getState().getFlowKey();
    JFlow localJFlow = (JFlow)super.get(localJFlowKey);
    if (localJFlow == null)
    {
      localJFlow = new JFlow(new PcapPacket(paramPcapPacket).getState().getFlowKey());
      super.put(localJFlowKey, localJFlow);
    }
    localJFlow.add(paramPcapPacket);
    this.count += 1;
  }
  
  public int getTotalPacketCount()
  {
    return this.count;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(51200);
    localStringBuilder.append("total packet count=").append(this.count).append("\n");
    localStringBuilder.append("total flow count=").append(size()).append("\n");
    int i = 0;
    Iterator localIterator = values().iterator();
    while (localIterator.hasNext())
    {
      JFlow localJFlow = (JFlow)localIterator.next();
      localStringBuilder.append("flow[").append(i++).append(']').append(' ');
      localStringBuilder.append(localJFlow.toString());
      localStringBuilder.append(",\n");
    }
    return localStringBuilder.toString();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JFlowMap
 * JD-Core Version:    0.7.0.1
 */