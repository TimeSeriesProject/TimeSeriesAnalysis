package org.jnetpcap.packet;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.annotate.HeaderLength;
import org.jnetpcap.util.JThreadLocal;

public abstract class AbstractMessageHeader
  extends JMappedHeader
{
  private static final char[] HEADER_DELIMITER = { '\r', '\n', '\r', '\n' };
  private static final String[] VALID_CHARS = { "GET", "PUT", "POS", "CON", "CAN", "HEA", "HTT", "OPT", "DEL", "TRA", "SIP", "INV", "REG", "ACK", "BYE", "REF", "NOT", "INF", "PRA" };
  private MessageType messageType;
  private final JThreadLocal<StringBuilder> stringLocal = new JThreadLocal(StringBuilder.class);
  protected String rawHeader;
  
  private static boolean checkValidFirstChars(JBuffer paramJBuffer, int paramInt)
  {
    String str1 = paramJBuffer.getUTF8String(paramInt, 3);
    for (String str2 : VALID_CHARS) {
      if (str1.equals(str2)) {
        return true;
      }
    }
    return false;
  }
  
  @HeaderLength
  public static int headerLength(JBuffer paramJBuffer, int paramInt)
  {
    if (!checkValidFirstChars(paramJBuffer, paramInt)) {
      return 0;
    }
    int i = paramJBuffer.findUTF8String(paramInt, HEADER_DELIMITER);
    return i;
  }
  
  protected abstract void decodeFirstLine(String paramString);
  
  protected void decodeHeader()
  {
    super.clearFields();
    StringBuilder localStringBuilder = (StringBuilder)this.stringLocal.get();
    localStringBuilder.setLength(0);
    int i = super.getLength();
    super.getUTF8String(0, localStringBuilder, i);
    this.rawHeader = localStringBuilder.toString();
    String[] arrayOfString1 = this.rawHeader.split("\r\n|\n");
    localStringBuilder.setLength(0);
    for (int j = 0; j < arrayOfString1.length; j++)
    {
      String str1 = arrayOfString1[j];
      if (str1.length() != 0)
      {
        int k = str1.charAt(0);
        if ((k == 32) || (k == 9))
        {
          str1 = str1.trim();
          if (localStringBuilder.length() != 0) {
            localStringBuilder.append(' ');
          }
          localStringBuilder.append(str1);
        }
        else
        {
          if (localStringBuilder.length() != 0)
          {
            str1 = localStringBuilder.toString();
            localStringBuilder.setLength(0);
            j--;
          }
          String[] arrayOfString2 = str1.split(":", 2);
          if (arrayOfString2.length == 1)
          {
            if (arrayOfString2[0].length() > 0) {
              decodeFirstLine(arrayOfString2[0]);
            }
          }
          else if (arrayOfString2.length >= 2)
          {
            String str2 = arrayOfString2[0];
            String str3 = arrayOfString2[1];
            int m = this.rawHeader.indexOf(str2 + ":");
            int n = str2.length() + str3.length() + 1;
            super.addField(map(str2.trim()), str3.trim(), m, n);
          }
        }
      }
    }
  }
  
  public MessageType getMessageType()
  {
    return this.messageType;
  }
  
  public void setMessageType(MessageType paramMessageType)
  {
    this.messageType = paramMessageType;
  }
  
  public static enum MessageType
  {
    REQUEST,  RESPONSE;
    
    private MessageType() {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.AbstractMessageHeader
 * JD-Core Version:    0.7.0.1
 */