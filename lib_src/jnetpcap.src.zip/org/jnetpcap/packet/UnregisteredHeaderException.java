package org.jnetpcap.packet;

public class UnregisteredHeaderException
  extends RegistryRuntimeException
{
  private static final long serialVersionUID = 8734105996858455745L;
  
  public UnregisteredHeaderException() {}
  
  public UnregisteredHeaderException(String paramString)
  {
    super(paramString);
  }
  
  public UnregisteredHeaderException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
  
  public UnregisteredHeaderException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.UnregisteredHeaderException
 * JD-Core Version:    0.7.0.1
 */