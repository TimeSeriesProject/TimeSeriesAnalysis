package org.jnetpcap.packet;

import java.io.PrintStream;
import org.jnetpcap.nio.JMemoryReference;
import org.jnetpcap.nio.JStruct;

public class JScanner
  extends JStruct
{
  private static int count = 0;
  public static final int DEFAULT_BLOCKSIZE = 102400;
  private static ThreadLocal<JScanner> localScanners = new ThreadLocal()
  {
    protected JScanner initialValue()
    {
      return new JScanner();
    }
  };
  public static final int MAX_ENTRY_COUNT = 64;
  public static final int MAX_ID_COUNT = 64;
  public static final String STRUCT_NAME = "scanner_t";
  
  public static void bindingOverride(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean) {
      JRegistry.setFlags(paramInt, 2);
    } else {
      JRegistry.clearFlags(paramInt, 2);
    }
    JPacket.getDefaultScanner().reloadAll();
  }
  
  public static JScanner getThreadLocal()
  {
    JScanner localJScanner = JPacket.getDefaultScanner();
    return localJScanner;
  }
  
  public static void shutdown()
  {
    localScanners.remove();
    localScanners = null;
  }
  
  public static void heuristicCheck(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean) {
      JRegistry.setFlags(paramInt, 16);
    } else {
      JRegistry.clearFlags(paramInt, 16);
    }
    JPacket.getDefaultScanner().reloadAll();
  }
  
  public static void heuristicPostCheck(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      JRegistry.setFlags(paramInt, 16);
      JRegistry.clearFlags(paramInt, 32);
    }
    else
    {
      JRegistry.clearFlags(paramInt, 16);
      JRegistry.clearFlags(paramInt, 32);
    }
    JPacket.getDefaultScanner().reloadAll();
  }
  
  public static void heuristicPreCheck(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      JRegistry.setFlags(paramInt, 16);
      JRegistry.setFlags(paramInt, 32);
    }
    else
    {
      JRegistry.clearFlags(paramInt, 16);
      JRegistry.clearFlags(paramInt, 32);
    }
    JPacket.getDefaultScanner().reloadAll();
  }
  
  private static native void initIds();
  
  public static void resetToDefaults()
  {
    for (int i = 0; i < 64; i++) {
      JRegistry.clearFlags(i, -1);
    }
  }
  
  static native int sizeof();
  
  private static long toBitMask(int... paramVarArgs)
  {
    long l = 0L;
    for (int i = 0; i < paramVarArgs.length; i++) {
      l |= 1L << i;
    }
    return l;
  }
  
  public JScanner()
  {
    this(102400);
  }
  
  public JScanner(int paramInt)
  {
    super("scanner_t#" + count++, paramInt + sizeof());
    init(new JScan());
    reloadAll();
  }
  
  public native long getFrameNumber();
  
  private native void init(JScan paramJScan);
  
  private native void loadFlags(int[] paramArrayOfInt);
  
  private native void loadScanners(JHeaderScanner[] paramArrayOfJHeaderScanner);
  
  public void reloadAll()
  {
    JHeaderScanner[] arrayOfJHeaderScanner = JRegistry.getHeaderScanners();
    for (int i = 0; i < arrayOfJHeaderScanner.length; i++) {
      if ((arrayOfJHeaderScanner[i] != null) && (!arrayOfJHeaderScanner[i].hasBindings()) && (!arrayOfJHeaderScanner[i].hasScanMethod()) && (arrayOfJHeaderScanner[i].isDirect())) {
        arrayOfJHeaderScanner[i] = null;
      }
    }
    loadScanners(arrayOfJHeaderScanner);
    int[] arrayOfInt = JRegistry.getAllFlags();
    loadFlags(arrayOfInt);
  }
  
  public int scan(JPacket paramJPacket, int paramInt)
  {
    return scan(paramJPacket, paramInt, paramJPacket.getPacketWirelen());
  }
  
  public int scan(JPacket paramJPacket, int paramInt1, int paramInt2)
  {
    JPacket.State localState = paramJPacket.getState();
    return scan(paramJPacket, localState, paramInt1, paramInt2);
  }
  
  private native int scan(JPacket paramJPacket, JPacket.State paramState, int paramInt1, int paramInt2);
  
  public native void setFrameNumber(long paramLong);
  
  protected JMemoryReference createReference(long paramLong1, long paramLong2)
  {
    return new JScannerReference(this, paramLong1, paramLong2);
  }
  
  static
  {
    try
    {
      initIds();
    }
    catch (Exception localException)
    {
      System.err.println("JScanner.static: error=" + localException.toString());
      throw new ExceptionInInitializerError(localException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.JScanner
 * JD-Core Version:    0.7.0.1
 */