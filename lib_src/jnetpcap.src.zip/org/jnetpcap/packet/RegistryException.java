package org.jnetpcap.packet;

public class RegistryException
  extends Exception
{
  private static final long serialVersionUID = 2093913023976126160L;
  
  public RegistryException() {}
  
  public RegistryException(String paramString)
  {
    super(paramString);
  }
  
  public RegistryException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
  
  public RegistryException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.packet.RegistryException
 * JD-Core Version:    0.7.0.1
 */