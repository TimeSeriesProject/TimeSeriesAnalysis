package org.jnetpcap;

import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JStruct;

public class PcapHeader
  extends JStruct
  implements JCaptureHeader
{
  public static final String STRUCT_NAME = "pcap_pkthdr";
  public static final int LENGTH = 16;
  
  public static native int sizeof();
  
  public PcapHeader()
  {
    super("pcap_pkthdr", 16);
  }
  
  public PcapHeader(int paramInt1, int paramInt2)
  {
    super("pcap_pkthdr", 16);
    hdr_len(paramInt1);
    hdr_wirelen(paramInt2);
    long l1 = System.currentTimeMillis();
    long l2 = l1 / 1000L;
    long l3 = (l1 - l2 * 1000L) * 1000L;
    hdr_sec(l2);
    hdr_usec((int)l3);
  }
  
  public PcapHeader(JMemory.Type paramType)
  {
    super("pcap_pkthdr", paramType);
  }
  
  public int caplen()
  {
    return hdr_len();
  }
  
  public native int hdr_len();
  
  public native void hdr_len(int paramInt);
  
  public native long hdr_sec();
  
  public native void hdr_sec(long paramLong);
  
  public native int hdr_usec();
  
  public native void hdr_usec(int paramInt);
  
  public native int hdr_wirelen();
  
  public native void hdr_wirelen(int paramInt);
  
  public long nanos()
  {
    return hdr_usec() * 1000;
  }
  
  public int peer(JBuffer paramJBuffer, int paramInt)
  {
    return super.peer(paramJBuffer, paramInt, sizeof());
  }
  
  public int peerTo(JBuffer paramJBuffer, int paramInt)
  {
    return super.peer(paramJBuffer, paramInt, sizeof());
  }
  
  public int peerTo(PcapHeader paramPcapHeader, int paramInt)
  {
    return super.peer(paramPcapHeader, paramInt, paramPcapHeader.size());
  }
  
  public long seconds()
  {
    return hdr_sec();
  }
  
  public long timestampInMillis()
  {
    long l = hdr_sec() * 1000L + hdr_usec() / 1000;
    return l;
  }
  
  public int transferTo(JBuffer paramJBuffer, int paramInt)
  {
    return super.transferTo(paramJBuffer, 0, size(), paramInt);
  }
  
  public int transferTo(byte[] paramArrayOfByte, int paramInt)
  {
    return super.transferTo(paramArrayOfByte, 0, size(), paramInt);
  }
  
  public int wirelen()
  {
    return hdr_wirelen();
  }
  
  public void caplen(int paramInt)
  {
    throw new UnsupportedOperationException("Not allowed on PcapHeader");
  }
  
  public void nanos(long paramLong)
  {
    throw new UnsupportedOperationException("Not allowed on PcapHeader");
  }
  
  public void seconds(long paramLong)
  {
    throw new UnsupportedOperationException("Not allowed on PcapHeader");
  }
  
  public void wirelen(int paramInt)
  {
    throw new UnsupportedOperationException("Not allowed on PcapHeader");
  }
  
  public void initFrom(JCaptureHeader paramJCaptureHeader)
  {
    throw new UnsupportedOperationException("Not allowed on PcapHeader");
  }
  
  public long timestampInNanos()
  {
    return hdr_sec() * 1000000000L + hdr_usec() * 1000;
  }
  
  public long timestampInMicros()
  {
    return hdr_sec() * 1000000L + hdr_usec();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapHeader
 * JD-Core Version:    0.7.0.1
 */