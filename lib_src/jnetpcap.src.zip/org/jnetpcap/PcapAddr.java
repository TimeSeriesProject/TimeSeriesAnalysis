package org.jnetpcap;

import java.util.ArrayList;
import java.util.List;

public final class PcapAddr
{
  private volatile PcapAddr next;
  private volatile PcapSockAddr addr;
  private volatile PcapSockAddr netmask;
  private volatile PcapSockAddr broadaddr;
  private volatile PcapSockAddr dstaddr;
  
  private static native void initIDs();
  
  private final PcapAddr getNext()
  {
    return this.next;
  }
  
  public final PcapSockAddr getAddr()
  {
    return this.addr;
  }
  
  public final PcapSockAddr getNetmask()
  {
    return this.netmask;
  }
  
  public final PcapSockAddr getBroadaddr()
  {
    return this.broadaddr;
  }
  
  public final PcapSockAddr getDstaddr()
  {
    return this.dstaddr;
  }
  
  private List<PcapAddr> toList()
  {
    ArrayList localArrayList = new ArrayList();
    for (PcapAddr localPcapAddr = this; localPcapAddr != null; localPcapAddr = localPcapAddr.next) {
      localArrayList.add(localPcapAddr);
    }
    return localArrayList;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[");
    localStringBuilder.append("addr=").append(String.valueOf(this.addr));
    localStringBuilder.append(", mask=").append(String.valueOf(this.netmask));
    localStringBuilder.append(", broadcast=").append(String.valueOf(this.broadaddr));
    localStringBuilder.append(", dstaddr=").append(String.valueOf(this.dstaddr));
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }
  
  static
  {
    
    try
    {
      Class.forName("org.jnetpcap.PcapSockAddr");
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new IllegalStateException(localClassNotFoundException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapAddr
 * JD-Core Version:    0.7.0.1
 */