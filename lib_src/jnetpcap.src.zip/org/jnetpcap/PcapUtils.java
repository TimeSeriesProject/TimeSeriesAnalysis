package org.jnetpcap;

import java.io.IOException;
import org.jnetpcap.packet.JPacket.State;
import org.jnetpcap.packet.JScanner;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;

public final class PcapUtils
{
  public static <T> PcapTask<T> dispatchInBackground(Pcap paramPcap, int paramInt, final ByteBufferHandler<T> paramByteBufferHandler, final T paramT)
  {
    new PcapTask(paramPcap, paramInt, paramT)
    {
      public void run()
      {
        int i = this.count;
        while (i > 0)
        {
          if (i != 0) {
            Thread.yield();
          }
          this.result = this.pcap.dispatch(this.count, paramByteBufferHandler, paramT);
          if (this.result < 0) {
            break;
          }
          i -= this.result;
        }
      }
    };
  }
  
  public static <T> PcapTask<T> dispatchInBackground(Pcap paramPcap, int paramInt, final JBufferHandler<T> paramJBufferHandler, final T paramT)
  {
    new PcapTask(paramPcap, paramInt, paramT)
    {
      public void run()
      {
        int i = this.count;
        while (i > 0)
        {
          if (i != 0) {
            Thread.yield();
          }
          this.result = this.pcap.dispatch(this.count, paramJBufferHandler, paramT);
          if (this.result < 0) {
            break;
          }
          i -= this.result;
        }
      }
    };
  }
  
  public static byte[] getHardwareAddress(PcapIf paramPcapIf)
    throws IOException
  {
    return getHardwareAddress(paramPcapIf.getName());
  }
  
  public static native byte[] getHardwareAddress(String paramString)
    throws IOException;
  
  public static <T> PcapTask<T> loopInBackground(Pcap paramPcap, int paramInt, final ByteBufferHandler<T> paramByteBufferHandler, final T paramT)
  {
    new PcapTask(paramPcap, paramInt, paramT)
    {
      public void run()
      {
        this.result = this.pcap.loop(this.count, paramByteBufferHandler, paramT);
      }
    };
  }
  
  public static <T> PcapTask<T> loopInBackground(Pcap paramPcap, int paramInt, final JBufferHandler<T> paramJBufferHandler, final T paramT)
  {
    new PcapTask(paramPcap, paramInt, paramT)
    {
      public void run()
      {
        this.result = this.pcap.loop(this.count, paramJBufferHandler, paramT);
      }
    };
  }
  
  public static <T> int injectLoop(int paramInt1, int paramInt2, PcapPacketHandler<T> paramPcapPacketHandler, T paramT, PcapPacket paramPcapPacket)
  {
    return injectLoop(paramInt1, paramInt2, paramPcapPacketHandler, paramT, paramPcapPacket, paramPcapPacket.getState(), paramPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  private static native <T> int injectLoop(int paramInt1, int paramInt2, PcapPacketHandler<T> paramPcapPacketHandler, T paramT, PcapPacket paramPcapPacket, JPacket.State paramState, PcapHeader paramPcapHeader, JScanner paramJScanner);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapUtils
 * JD-Core Version:    0.7.0.1
 */