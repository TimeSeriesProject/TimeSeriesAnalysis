package org.jnetpcap;

import java.nio.ByteBuffer;

public class PcapBpfProgram
{
  private volatile long physical = 0L;
  private ByteBuffer buffer;
  
  private static native void initIDs();
  
  public PcapBpfProgram()
  {
    initPeer();
    this.buffer = null;
  }
  
  private native void initPeer();
  
  public PcapBpfProgram(byte[] paramArrayOfByte)
  {
    this.buffer = null;
    if (paramArrayOfByte == null) {
      throw new NullPointerException("BPF instruction array is null");
    }
    if (paramArrayOfByte.length % 8 != 0) {
      throw new IllegalArgumentException("Invalid BPF instruction buffer length. Must be a multiple of 8");
    }
    if (paramArrayOfByte.length == 0) {
      throw new IllegalArgumentException("BPF instruction array is empty");
    }
    initPeer();
    initFromArray(paramArrayOfByte);
  }
  
  public PcapBpfProgram(ByteBuffer paramByteBuffer)
  {
    if (paramByteBuffer == null) {
      throw new NullPointerException("BPF instruction buffer is null");
    }
    int i = paramByteBuffer.limit() - paramByteBuffer.position();
    if (i % 8 != 0) {
      throw new IllegalArgumentException("Invalid BPF instruction buffer length. Must be a multiple of 8");
    }
    if (i == 0) {
      throw new IllegalArgumentException("BPF instruction array is empty");
    }
    initPeer();
    if (!paramByteBuffer.isDirect())
    {
      initFromArray(paramByteBuffer.array());
    }
    else
    {
      initFromBuffer(paramByteBuffer);
      this.buffer = paramByteBuffer;
    }
  }
  
  protected void finalize()
  {
    if (this.physical != 0L) {
      cleanup();
    }
  }
  
  private native void cleanup();
  
  private void initFromArray(byte[] paramArrayOfByte)
  {
    this.buffer = ByteBuffer.allocateDirect(paramArrayOfByte.length);
    this.buffer.put(paramArrayOfByte);
    initFromBuffer(this.buffer);
  }
  
  private native void initFromBuffer(ByteBuffer paramByteBuffer);
  
  public native int getInstructionCount();
  
  public native long getInstruction(int paramInt);
  
  public long[] toLongArray()
  {
    int i = getInstructionCount();
    long[] arrayOfLong = new long[i];
    for (int j = 0; j < i; j++) {
      arrayOfLong[j] = getInstruction(j);
    }
    return arrayOfLong;
  }
  
  static
  {
    try
    {
      Class.forName("org.jnetpcap.Pcap");
      initIDs();
    }
    catch (ClassNotFoundException localClassNotFoundException) {}
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapBpfProgram
 * JD-Core Version:    0.7.0.1
 */