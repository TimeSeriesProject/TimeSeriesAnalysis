package org.jnetpcap;

public class PcapClosedException
  extends IllegalStateException
{
  private static final long serialVersionUID = 4803545074835523202L;
  
  public PcapClosedException() {}
  
  public PcapClosedException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public PcapClosedException(String paramString)
  {
    super(paramString);
  }
  
  public PcapClosedException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapClosedException
 * JD-Core Version:    0.7.0.1
 */