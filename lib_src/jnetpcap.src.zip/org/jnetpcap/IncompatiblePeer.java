package org.jnetpcap;

public class IncompatiblePeer
  extends Exception
{
  private static final long serialVersionUID = 9081938128324891646L;
  
  public IncompatiblePeer(String paramString)
  {
    super(paramString);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.IncompatiblePeer
 * JD-Core Version:    0.7.0.1
 */