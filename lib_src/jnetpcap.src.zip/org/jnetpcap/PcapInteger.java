package org.jnetpcap;

/**
 * @deprecated
 */
public final class PcapInteger
{
  private volatile int value;
  
  public PcapInteger(int paramInt)
  {
    this.value = paramInt;
  }
  
  public PcapInteger()
  {
    this.value = 0;
  }
  
  public final int getValue()
  {
    return this.value;
  }
  
  public final void setValue(int paramInt)
  {
    this.value = paramInt;
  }
  
  public String toString()
  {
    return Integer.toString(this.value);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapInteger
 * JD-Core Version:    0.7.0.1
 */