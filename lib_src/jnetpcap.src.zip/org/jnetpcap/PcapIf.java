package org.jnetpcap;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PcapIf
{
  private volatile PcapIf next;
  private volatile String name;
  private volatile String description;
  private List<PcapAddr> addresses = new ArrayList(2);
  private volatile int flags;
  
  private static native void initIDs();
  
  private final PcapIf getNext()
  {
    return this.next;
  }
  
  public final String getName()
  {
    return this.name;
  }
  
  public final String getDescription()
  {
    return this.description;
  }
  
  public final List<PcapAddr> getAddresses()
  {
    return this.addresses;
  }
  
  public final int getFlags()
  {
    return this.flags;
  }
  
  public byte[] getHardwareAddress()
    throws IOException
  {
    return PcapUtils.getHardwareAddress(this);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<");
    if ((this.addresses != null) && (!this.addresses.isEmpty()))
    {
      localStringBuilder.append("flags=").append(this.flags);
      localStringBuilder.append(", addresses=").append(this.addresses);
      localStringBuilder.append(", ");
    }
    localStringBuilder.append("name=").append(this.name);
    localStringBuilder.append(", desc=").append(this.description);
    localStringBuilder.append(">");
    return localStringBuilder.toString();
  }
  
  static
  {
    
    try
    {
      Class.forName("org.jnetpcap.PcapAddr");
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new IllegalStateException(localClassNotFoundException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapIf
 * JD-Core Version:    0.7.0.1
 */