package org.jnetpcap;

import org.jnetpcap.nio.JBuffer;

public abstract interface JBufferHandler<T>
{
  public abstract void nextPacket(PcapHeader paramPcapHeader, JBuffer paramJBuffer, T paramT);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.JBufferHandler
 * JD-Core Version:    0.7.0.1
 */