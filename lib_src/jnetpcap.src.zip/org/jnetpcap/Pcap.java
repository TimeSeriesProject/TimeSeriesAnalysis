package org.jnetpcap;

import java.nio.ByteBuffer;
import java.util.List;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JNumber;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JPacket.State;
import org.jnetpcap.packet.JPacketHandler;
import org.jnetpcap.packet.JRegistry;
import org.jnetpcap.packet.JScanner;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;

public class Pcap
{
  public static final int DEFAULT_PROMISC = 1;
  public static final int DEFAULT_SNAPLEN = 65536;
  public static final int DEFAULT_TIMEOUT = 0;
  public static final int DISPATCH_BUFFER_FULL = -1;
  public static final String JNETPCAP_LIBRARY_NAME = "jnetpcap";
  @Deprecated
  public static final int LOOP_INFINATE = -1;
  public static final int LOOP_INFINITE = -1;
  public static final int LOOP_INTERRUPTED = -2;
  public static final int MODE_BLOCKING = 0;
  public static final int MODE_NON_BLOCKING = 1;
  public static final int MODE_NON_PROMISCUOUS = 0;
  public static final int MODE_PROMISCUOUS = 1;
  public static final int NEXT_EX_EOF = -2;
  public static final int NEXT_EX_NOT_OK = -1;
  public static final int NEXT_EX_OK = 1;
  public static final int NEXT_EX_TIMEDOUT = 0;
  public static final int NOT_OK = -1;
  public static final int OK = 0;
  private volatile long physical;
  
  public static native int compileNoPcap(int paramInt1, int paramInt2, PcapBpfProgram paramPcapBpfProgram, String paramString, int paramInt3, int paramInt4);
  
  public static native int datalinkNameToVal(String paramString);
  
  public static native String datalinkValToDescription(int paramInt);
  
  public static native String datalinkValToName(int paramInt);
  
  public static native int findAllDevs(List<PcapIf> paramList, StringBuilder paramStringBuilder);
  
  @Deprecated
  public static void freeAllDevs(List<PcapIf> paramList, byte[] paramArrayOfByte)
  {
    if ((paramList == null) || (paramArrayOfByte == null)) {
      throw new NullPointerException();
    }
    paramList.clear();
  }
  
  public static void freeAllDevs(List<PcapIf> paramList, StringBuilder paramStringBuilder)
  {
    if ((paramList == null) || (paramStringBuilder == null)) {
      throw new NullPointerException();
    }
    paramStringBuilder.setLength(0);
    paramList.clear();
  }
  
  public static native void freecode(PcapBpfProgram paramPcapBpfProgram);
  
  private static native void initIDs();
  
  public static native boolean isInjectSupported();
  
  public static native boolean isSendPacketSupported();
  
  public static native String libVersion();
  
  public static native String lookupDev(StringBuilder paramStringBuilder);
  
  public static native int lookupNet(String paramString, JNumber paramJNumber1, JNumber paramJNumber2, StringBuilder paramStringBuilder);
  
  @Deprecated
  public static native int lookupNet(String paramString, PcapInteger paramPcapInteger1, PcapInteger paramPcapInteger2, StringBuilder paramStringBuilder);
  
  public static native Pcap openDead(int paramInt1, int paramInt2);
  
  public static native Pcap openLive(String paramString, int paramInt1, int paramInt2, int paramInt3, StringBuilder paramStringBuilder);
  
  public static native Pcap openOffline(String paramString, StringBuilder paramStringBuilder);
  
  public native void breakloop();
  
  protected native void checkIsActive()
    throws PcapClosedException;
  
  public native void close();
  
  public native int compile(PcapBpfProgram paramPcapBpfProgram, String paramString, int paramInt1, int paramInt2);
  
  public native int datalink();
  
  private int datalinkToId()
  {
    int i = JRegistry.mapDLTToId(datalink());
    return i == -1 ? 1 : i;
  }
  
  public <T> int dispatch(int paramInt, ByteBufferHandler<T> paramByteBufferHandler, T paramT)
  {
    return dispatch(paramInt, paramByteBufferHandler, paramT, new PcapHeader(JMemory.Type.POINTER));
  }
  
  private native <T> int dispatch(int paramInt, ByteBufferHandler<T> paramByteBufferHandler, T paramT, PcapHeader paramPcapHeader);
  
  public <T> int dispatch(int paramInt1, int paramInt2, JPacketHandler<T> paramJPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return dispatch(paramInt1, paramInt2, paramJPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  private native <T> int dispatch(int paramInt1, int paramInt2, JPacketHandler<T> paramJPacketHandler, T paramT, JPacket paramJPacket, JPacket.State paramState, PcapHeader paramPcapHeader, JScanner paramJScanner);
  
  public <T> int dispatch(int paramInt1, int paramInt2, PcapPacketHandler<T> paramPcapPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return dispatch(paramInt1, paramInt2, paramPcapPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  private native <T> int dispatch(int paramInt1, int paramInt2, PcapPacketHandler<T> paramPcapPacketHandler, T paramT, JPacket paramJPacket, JPacket.State paramState, PcapHeader paramPcapHeader, JScanner paramJScanner);
  
  public <T> int dispatch(int paramInt, JBufferHandler<T> paramJBufferHandler, T paramT)
  {
    return dispatch(paramInt, paramJBufferHandler, paramT, new PcapHeader(JMemory.Type.POINTER), new JBuffer(JMemory.Type.POINTER));
  }
  
  private native <T> int dispatch(int paramInt, JBufferHandler<T> paramJBufferHandler, T paramT, PcapHeader paramPcapHeader, JBuffer paramJBuffer);
  
  public <T> int dispatch(int paramInt, JPacketHandler<T> paramJPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return dispatch(paramInt, datalinkToId(), paramJPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  public <T> int dispatch(int paramInt, JPacketHandler<T> paramJPacketHandler, T paramT, JScanner paramJScanner)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return dispatch(paramInt, datalinkToId(), paramJPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), paramJScanner);
  }
  
  public native int dispatch(int paramInt, PcapDumper paramPcapDumper);
  
  @Deprecated
  public native <T> int dispatch(int paramInt, PcapHandler<T> paramPcapHandler, T paramT);
  
  @Deprecated
  public <T> int dispatch(int paramInt, PcapPacketHandler<T> paramPcapPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return dispatch(paramInt, datalinkToId(), paramPcapPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  @Deprecated
  public <T> int dispatch(int paramInt, PcapPacketHandler<T> paramPcapPacketHandler, T paramT, JScanner paramJScanner)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return dispatch(paramInt, datalinkToId(), paramPcapPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), paramJScanner);
  }
  
  public native PcapDumper dumpOpen(String paramString);
  
  protected void finalize()
  {
    if (this.physical != 0L) {
      close();
    }
  }
  
  public native String getErr();
  
  public native int getNonBlock(StringBuilder paramStringBuilder);
  
  public int inject(byte[] paramArrayOfByte)
  {
    checkIsActive();
    int i = paramArrayOfByte.length;
    ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(i);
    localByteBuffer.put(paramArrayOfByte);
    return injectPrivate(localByteBuffer, 0, i);
  }
  
  public int inject(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    checkIsActive();
    ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(paramInt2);
    localByteBuffer.put(paramArrayOfByte, paramInt1, paramInt2);
    return injectPrivate(localByteBuffer, 0, paramInt2);
  }
  
  public int inject(ByteBuffer paramByteBuffer)
  {
    checkIsActive();
    if (!paramByteBuffer.isDirect())
    {
      int i = paramByteBuffer.limit() - paramByteBuffer.position();
      ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(i);
      localByteBuffer.put(paramByteBuffer);
      return injectPrivate(localByteBuffer, 0, i);
    }
    return injectPrivate(paramByteBuffer, paramByteBuffer.position(), paramByteBuffer.limit() - paramByteBuffer.position());
  }
  
  public native int inject(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  private native int injectPrivate(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
  
  public native int isSwapped();
  
  public <T> int loop(int paramInt, ByteBufferHandler<T> paramByteBufferHandler, T paramT)
  {
    return loop(paramInt, paramByteBufferHandler, paramT, new PcapHeader(JMemory.Type.POINTER));
  }
  
  private native <T> int loop(int paramInt, ByteBufferHandler<T> paramByteBufferHandler, T paramT, PcapHeader paramPcapHeader);
  
  public <T> int loop(int paramInt1, int paramInt2, JPacketHandler<T> paramJPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return loop(paramInt1, paramInt2, paramJPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  private native <T> int loop(int paramInt1, int paramInt2, JPacketHandler<T> paramJPacketHandler, T paramT, JPacket paramJPacket, JPacket.State paramState, PcapHeader paramPcapHeader, JScanner paramJScanner);
  
  public <T> int loop(int paramInt1, int paramInt2, PcapPacketHandler<T> paramPcapPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return loop(paramInt1, paramInt2, paramPcapPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  private native <T> int loop(int paramInt1, int paramInt2, PcapPacketHandler<T> paramPcapPacketHandler, T paramT, JPacket paramJPacket, JPacket.State paramState, PcapHeader paramPcapHeader, JScanner paramJScanner);
  
  public <T> int loop(int paramInt, JBufferHandler<T> paramJBufferHandler, T paramT)
  {
    return loop(paramInt, paramJBufferHandler, paramT, new PcapHeader(JMemory.Type.POINTER), new JBuffer(JMemory.Type.POINTER));
  }
  
  private native <T> int loop(int paramInt, JBufferHandler<T> paramJBufferHandler, T paramT, PcapHeader paramPcapHeader, JBuffer paramJBuffer);
  
  public <T> int loop(int paramInt, JPacketHandler<T> paramJPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return loop(paramInt, datalinkToId(), paramJPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  public <T> int loop(int paramInt, JPacketHandler<T> paramJPacketHandler, T paramT, JScanner paramJScanner)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return loop(paramInt, datalinkToId(), paramJPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), paramJScanner);
  }
  
  public native int loop(int paramInt, PcapDumper paramPcapDumper);
  
  @Deprecated
  public native <T> int loop(int paramInt, PcapHandler<T> paramPcapHandler, T paramT);
  
  public <T> int loop(int paramInt, PcapPacketHandler<T> paramPcapPacketHandler, T paramT)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return loop(paramInt, datalinkToId(), paramPcapPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), JScanner.getThreadLocal());
  }
  
  public <T> int loop(int paramInt, PcapPacketHandler<T> paramPcapPacketHandler, T paramT, JScanner paramJScanner)
  {
    PcapPacket localPcapPacket = new PcapPacket(JMemory.Type.POINTER);
    return loop(paramInt, datalinkToId(), paramPcapPacketHandler, paramT, localPcapPacket, localPcapPacket.getState(), localPcapPacket.getCaptureHeader(), paramJScanner);
  }
  
  public native int majorVersion();
  
  public native int minorVersion();
  
  public native JBuffer next(PcapHeader paramPcapHeader, JBuffer paramJBuffer);
  
  @Deprecated
  public native ByteBuffer next(PcapPktHdr paramPcapPktHdr);
  
  public native int nextEx(PcapHeader paramPcapHeader, JBuffer paramJBuffer);
  
  public int nextEx(PcapPacket paramPcapPacket)
  {
    int i = nextEx(paramPcapPacket.getCaptureHeader(), paramPcapPacket);
    paramPcapPacket.scan(JRegistry.mapDLTToId(datalink()));
    return i;
  }
  
  @Deprecated
  public native int nextEx(PcapPktHdr paramPcapPktHdr, PcapPktBuffer paramPcapPktBuffer);
  
  public int sendPacket(byte[] paramArrayOfByte)
  {
    checkIsActive();
    int i = paramArrayOfByte.length;
    ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(i);
    localByteBuffer.put(paramArrayOfByte);
    return sendPacketPrivate(localByteBuffer, 0, i);
  }
  
  public int sendPacket(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    checkIsActive();
    ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(paramInt2);
    localByteBuffer.put(paramArrayOfByte, paramInt1, paramInt2);
    return sendPacketPrivate(localByteBuffer, 0, paramInt2);
  }
  
  public int sendPacket(ByteBuffer paramByteBuffer)
  {
    checkIsActive();
    if (!paramByteBuffer.isDirect())
    {
      int i = paramByteBuffer.limit() - paramByteBuffer.position();
      ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(i);
      localByteBuffer.put(paramByteBuffer);
      return sendPacketPrivate(localByteBuffer, 0, i);
    }
    return sendPacketPrivate(paramByteBuffer, paramByteBuffer.position(), paramByteBuffer.limit() - paramByteBuffer.position());
  }
  
  public native int sendPacket(JBuffer paramJBuffer);
  
  private native int sendPacketPrivate(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
  
  public native int setDatalink(int paramInt);
  
  public native int setFilter(PcapBpfProgram paramPcapBpfProgram);
  
  public native int setNonBlock(int paramInt, StringBuilder paramStringBuilder);
  
  public native int snapshot();
  
  public native int stats(PcapStat paramPcapStat);
  
  public String toString()
  {
    checkIsActive();
    return libVersion();
  }
  
  static
  {
    System.loadLibrary("jnetpcap");
    initIDs();
    try
    {
      Class.forName("org.jnetpcap.PcapDumper");
      Class.forName("org.jnetpcap.PcapIf");
    }
    catch (Exception localException)
    {
      throw new IllegalStateException(localException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.Pcap
 * JD-Core Version:    0.7.0.1
 */