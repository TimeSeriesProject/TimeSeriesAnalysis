package org.jnetpcap.winpcap;

public final class WinPcapRmtAuth
{
  public static final int RMT_AUTH_NULL = 0;
  public static final int RMT_AUTH_PWD = 1;
  private int type;
  private String username;
  private String password;
  
  private static native void initIDs();
  
  public WinPcapRmtAuth() {}
  
  public WinPcapRmtAuth(int paramInt, String paramString1, String paramString2)
  {
    this.type = paramInt;
    this.username = paramString1;
    this.password = paramString2;
  }
  
  public final int getType()
  {
    return this.type;
  }
  
  public final void setType(int paramInt)
  {
    this.type = paramInt;
  }
  
  public final String getUsername()
  {
    return this.username;
  }
  
  public final void setUsername(String paramString)
  {
    this.username = paramString;
  }
  
  public final String getPassword()
  {
    return this.password;
  }
  
  public final void setPassword(String paramString)
  {
    this.password = paramString;
  }
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.winpcap.WinPcapRmtAuth
 * JD-Core Version:    0.7.0.1
 */