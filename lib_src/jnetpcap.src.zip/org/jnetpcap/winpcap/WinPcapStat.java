package org.jnetpcap.winpcap;

import org.jnetpcap.PcapStat;

public class WinPcapStat
  extends PcapStat
{
  private static native void initIDs();
  
  public long getCapt()
  {
    return this.capt;
  }
  
  public long getNetdrop()
  {
    return this.netdrop;
  }
  
  public long getSent()
  {
    return this.sent;
  }
  
  public String toString()
  {
    out.setLength(0);
    out.append("recv=").append(getRecv());
    out.append(", drop=").append(getDrop());
    out.append(", ifdrop=").append(getIfDrop());
    out.append(", capt=").append(getCapt());
    out.append(", netdrop=").append(getNetdrop());
    out.append(", sent=").append(getSent());
    return out.toString();
  }
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.winpcap.WinPcapStat
 * JD-Core Version:    0.7.0.1
 */