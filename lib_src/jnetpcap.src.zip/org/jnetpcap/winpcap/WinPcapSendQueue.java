package org.jnetpcap.winpcap;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.jnetpcap.PcapHeader;
import org.jnetpcap.PcapPktHdr;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory.Type;
import org.jnetpcap.nio.JStruct;
import org.jnetpcap.packet.PeeringException;

public class WinPcapSendQueue
  extends JStruct
{
  public static final int DEFAULT_QUEUE_SIZE = 65536;
  public static final String STRUCT_NAME = "pcap_send_queue";
  private final JBuffer buffer;
  
  public static native int sizeof();
  
  public WinPcapSendQueue()
  {
    this(65536);
  }
  
  public WinPcapSendQueue(byte[] paramArrayOfByte)
  {
    super("pcap_send_queue", sizeof());
    this.buffer = new JBuffer(paramArrayOfByte.length);
    this.buffer.order(ByteOrder.nativeOrder());
    this.buffer.setByteArray(0, paramArrayOfByte);
    setMaxLen(paramArrayOfByte.length);
    setLen(paramArrayOfByte.length);
  }
  
  public WinPcapSendQueue(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    super("pcap_send_queue", sizeof());
    this.buffer = new JBuffer(JMemory.Type.POINTER);
    this.buffer.order(ByteOrder.nativeOrder());
    if (!paramByteBuffer.isDirect()) {
      throw new IllegalArgumentException("Only direct buffers are accepted. See ByteBuffer.allocateDirect method.");
    }
    this.buffer.peer(paramByteBuffer);
    setMaxLen(this.buffer.size());
    setLen(this.buffer.size());
  }
  
  public WinPcapSendQueue(int paramInt)
  {
    super("pcap_send_queue", sizeof());
    this.buffer = new JBuffer(paramInt);
    this.buffer.order(ByteOrder.nativeOrder());
    setMaxLen(paramInt);
    setLen(0);
    setBuffer(this.buffer);
  }
  
  public JBuffer getBuffer()
  {
    return this.buffer;
  }
  
  public native int getLen();
  
  public native int getMaxLen();
  
  public native int incLen(int paramInt);
  
  public int queue(PcapHeader paramPcapHeader, byte[] paramArrayOfByte)
  {
    return queue(paramPcapHeader, new JBuffer(paramArrayOfByte));
  }
  
  public int queue(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer)
  {
    return queue(paramPcapHeader, new JBuffer(paramByteBuffer));
  }
  
  public int queue(PcapHeader paramPcapHeader, JBuffer paramJBuffer)
  {
    paramPcapHeader.transferTo(this.buffer, 0, paramPcapHeader.size(), getLen());
    setLen(getLen() + paramPcapHeader.size());
    paramJBuffer.transferTo(this.buffer, 0, paramJBuffer.size(), getLen());
    setLen(getLen() + paramJBuffer.size());
    return 0;
  }
  
  @Deprecated
  public int queue(PcapPktHdr paramPcapPktHdr, byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length != paramPcapPktHdr.getCaplen()) {
      throw new IllegalArgumentException("Buffer length does not equal length in packet header");
    }
    int i = getLen();
    this.buffer.setInt(i, (int)paramPcapPktHdr.getSeconds());
    this.buffer.setInt(i + 4, paramPcapPktHdr.getUseconds());
    this.buffer.setInt(i + 8, paramPcapPktHdr.getCaplen());
    this.buffer.setInt(i + 12, paramPcapPktHdr.getLen());
    this.buffer.setByteArray(i + 16, paramArrayOfByte);
    incLen(16 + paramArrayOfByte.length);
    return 0;
  }
  
  @Deprecated
  public int queue(PcapPktHdr paramPcapPktHdr, ByteBuffer paramByteBuffer)
  {
    int i = paramByteBuffer.limit() - paramByteBuffer.position();
    if (i != paramPcapPktHdr.getCaplen()) {
      throw new IllegalArgumentException("Buffer length (limit - position) does not equal length in packet header");
    }
    int j = getLen();
    this.buffer.setInt(j, (int)paramPcapPktHdr.getSeconds());
    this.buffer.setInt(j + 4, paramPcapPktHdr.getUseconds());
    this.buffer.setInt(j + 8, paramPcapPktHdr.getCaplen());
    this.buffer.setInt(j + 12, paramPcapPktHdr.getLen());
    this.buffer.setByteBuffer(j + 16, paramByteBuffer);
    incLen(16 + i);
    return 0;
  }
  
  private native void setBuffer(JBuffer paramJBuffer);
  
  public native void setLen(int paramInt);
  
  public native void setMaxLen(int paramInt);
  
  public native String toDebugString();
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.winpcap.WinPcapSendQueue
 * JD-Core Version:    0.7.0.1
 */