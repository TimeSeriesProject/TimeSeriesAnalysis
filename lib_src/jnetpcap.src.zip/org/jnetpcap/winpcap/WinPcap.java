package org.jnetpcap.winpcap;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import org.jnetpcap.Pcap;
import org.jnetpcap.PcapBpfProgram;
import org.jnetpcap.PcapExtensionNotAvailableException;
import org.jnetpcap.PcapHeader;
import org.jnetpcap.PcapIf;
import org.jnetpcap.PcapPktHdr;
import org.jnetpcap.nio.JBuffer;

public class WinPcap
  extends Pcap
{
  private static final ThreadLocal<StringBuffer> buf = new ThreadLocal()
  {
    protected StringBuffer initialValue()
    {
      return new StringBuffer();
    }
  };
  public static final int MODE_CAPT = 0;
  public static final int MODE_MONITOR = 2;
  public static final int MODE_STAT = 1;
  public static final int OPENFLAG_DATATX_UDP = 2;
  public static final int OPENFLAG_MAX_RESPONSIVENESS = 16;
  public static final int OPENFLAG_NOCAPTURE_LOCAL = 8;
  public static final int OPENFLAG_NOCAPTURE_RPCAP = 4;
  public static final int SRC_FILE = 2;
  public static final int SRC_IFLOCAL = 3;
  public static final int SRC_IFREMOTE = 4;
  public static final int TRANSMIT_SYNCH_ASAP = 0;
  public static final int TRANSMIT_SYNCH_USE_TIMESTAMP = 1;
  
  private static String asString(byte[] paramArrayOfByte)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int k : paramArrayOfByte)
    {
      if (localStringBuilder.length() != 0) {
        localStringBuilder.append(':');
      }
      localStringBuilder.append(Integer.toHexString(k < 0 ? k + 256 : k).toUpperCase());
    }
    return localStringBuilder.toString();
  }
  
  public static int createSrcStr(Appendable paramAppendable1, int paramInt, String paramString1, String paramString2, String paramString3, Appendable paramAppendable2)
    throws IOException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = createSrcStr(localStringBuffer, paramInt, paramString1, paramString2, paramString3, getBuf());
    toAppendable(getBuf(), paramAppendable2);
    toAppendable(localStringBuffer, paramAppendable1);
    return i;
  }
  
  public static native int createSrcStr(StringBuffer paramStringBuffer1, int paramInt, String paramString1, String paramString2, String paramString3, StringBuffer paramStringBuffer2);
  
  public static int createSrcStr(StringBuilder paramStringBuilder1, int paramInt, String paramString1, String paramString2, String paramString3, StringBuilder paramStringBuilder2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = createSrcStr(localStringBuffer, paramInt, paramString1, paramString2, paramString3, getBuf());
    toStringBuilder(getBuf(), paramStringBuilder2);
    toStringBuilder(localStringBuffer, paramStringBuilder1);
    return i;
  }
  
  public static int findAllDevsEx(String paramString, WinPcapRmtAuth paramWinPcapRmtAuth, List<PcapIf> paramList, Appendable paramAppendable)
    throws IOException
  {
    int i = findAllDevsEx(paramString, paramWinPcapRmtAuth, paramList, getBuf());
    toAppendable(getBuf(), paramAppendable);
    return i;
  }
  
  public static native int findAllDevsEx(String paramString, WinPcapRmtAuth paramWinPcapRmtAuth, List<PcapIf> paramList, StringBuffer paramStringBuffer);
  
  public static int findAllDevsEx(String paramString, WinPcapRmtAuth paramWinPcapRmtAuth, List<PcapIf> paramList, StringBuilder paramStringBuilder)
  {
    int i = findAllDevsEx(paramString, paramWinPcapRmtAuth, paramList, getBuf());
    toStringBuilder(getBuf(), paramStringBuilder);
    return i;
  }
  
  private static StringBuffer getBuf()
  {
    return (StringBuffer)buf.get();
  }
  
  private static native void initIDs();
  
  public static native boolean isSupported();
  
  public static native int offlineFilter(PcapBpfProgram paramPcapBpfProgram, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer);
  
  public static native int offlineFilter(PcapBpfProgram paramPcapBpfProgram, PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer);
  
  public static native int offlineFilter(PcapBpfProgram paramPcapBpfProgram, PcapHeader paramPcapHeader, JBuffer paramJBuffer);
  
  @Deprecated
  public static native int offlineFilter(PcapBpfProgram paramPcapBpfProgram, PcapPktHdr paramPcapPktHdr, ByteBuffer paramByteBuffer);
  
  public static WinPcap open(String paramString, int paramInt1, int paramInt2, int paramInt3, WinPcapRmtAuth paramWinPcapRmtAuth, Appendable paramAppendable)
    throws IOException
  {
    WinPcap localWinPcap = open(paramString, paramInt1, paramInt2, paramInt3, paramWinPcapRmtAuth, getBuf());
    toAppendable(getBuf(), paramAppendable);
    return localWinPcap;
  }
  
  public static native WinPcap open(String paramString, int paramInt1, int paramInt2, int paramInt3, WinPcapRmtAuth paramWinPcapRmtAuth, StringBuffer paramStringBuffer);
  
  public static WinPcap open(String paramString, int paramInt1, int paramInt2, int paramInt3, WinPcapRmtAuth paramWinPcapRmtAuth, StringBuilder paramStringBuilder)
  {
    WinPcap localWinPcap = open(paramString, paramInt1, paramInt2, paramInt3, paramWinPcapRmtAuth, getBuf());
    toStringBuilder(getBuf(), paramStringBuilder);
    return localWinPcap;
  }
  
  public static native WinPcap openDead(int paramInt1, int paramInt2);
  
  public static WinPcap openLive(String paramString, int paramInt1, int paramInt2, int paramInt3, Appendable paramAppendable)
    throws IOException
  {
    WinPcap localWinPcap = openLive(paramString, paramInt1, paramInt2, paramInt3, getBuf());
    toAppendable(getBuf(), paramAppendable);
    return localWinPcap;
  }
  
  public static native WinPcap openLive(String paramString, int paramInt1, int paramInt2, int paramInt3, StringBuffer paramStringBuffer);
  
  public static WinPcap openLive(String paramString, int paramInt1, int paramInt2, int paramInt3, StringBuilder paramStringBuilder)
  {
    WinPcap localWinPcap = openLive(paramString, paramInt1, paramInt2, paramInt3, getBuf());
    toStringBuilder(getBuf(), paramStringBuilder);
    return localWinPcap;
  }
  
  public static WinPcap openOffline(String paramString, Appendable paramAppendable)
    throws IOException
  {
    WinPcap localWinPcap = openOffline(paramString, getBuf());
    toAppendable(getBuf(), paramAppendable);
    return localWinPcap;
  }
  
  public static native WinPcap openOffline(String paramString, StringBuffer paramStringBuffer);
  
  public static WinPcap openOffline(String paramString, StringBuilder paramStringBuilder)
  {
    WinPcap localWinPcap = openOffline(paramString, getBuf());
    toStringBuilder(getBuf(), paramStringBuilder);
    return localWinPcap;
  }
  
  public static WinPcapSendQueue sendQueueAlloc(int paramInt)
  {
    if (!isSupported()) {
      throw new PcapExtensionNotAvailableException();
    }
    return new WinPcapSendQueue(paramInt);
  }
  
  public static void sendQueueDestroy(WinPcapSendQueue paramWinPcapSendQueue)
  {
    if (!isSupported()) {
      throw new PcapExtensionNotAvailableException();
    }
  }
  
  private static void toAppendable(StringBuffer paramStringBuffer, Appendable paramAppendable)
    throws IOException
  {
    if (paramStringBuffer.length() != 0) {
      paramAppendable.append(paramStringBuffer);
    }
  }
  
  private static void toStringBuilder(StringBuffer paramStringBuffer, StringBuilder paramStringBuilder)
  {
    paramStringBuilder.setLength(0);
    if (paramStringBuffer.length() != 0) {
      paramStringBuilder.append(paramStringBuffer);
    }
  }
  
  public native int liveDump(String paramString, int paramInt1, int paramInt2);
  
  public native int liveDumpEnded(int paramInt);
  
  public native int sendQueueTransmit(WinPcapSendQueue paramWinPcapSendQueue, int paramInt);
  
  public native int setBuff(int paramInt);
  
  public native int setMinToCopy(int paramInt);
  
  public native int setMode(int paramInt);
  
  public native WinPcapSamp setSampling();
  
  public native WinPcapStat statsEx();
  
  static
  {
    initIDs();
    try
    {
      Class.forName("org.jnetpcap.winpcap.WinPcapStat");
      Class.forName("org.jnetpcap.winpcap.WinPcapSamp");
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new IllegalStateException("Unable to find class: ", localClassNotFoundException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.winpcap.WinPcap
 * JD-Core Version:    0.7.0.1
 */