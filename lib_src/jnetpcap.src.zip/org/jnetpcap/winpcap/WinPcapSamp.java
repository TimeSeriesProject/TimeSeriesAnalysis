package org.jnetpcap.winpcap;

public final class WinPcapSamp
{
  private volatile long physical;
  public static final int NO_SAMP = 0;
  public static final int ONE_EVERY_N = 1;
  public static final int FIRST_AFTER_N_MS = 2;
  
  private static native void initIDs();
  
  private WinPcapSamp(long paramLong)
  {
    this.physical = paramLong;
  }
  
  public native int getMethod();
  
  public native void setMethod(int paramInt);
  
  public native int getValue();
  
  public native void setValue(int paramInt);
  
  public String toString()
  {
    return "method:" + getMethod() + ", value:" + getValue();
  }
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.winpcap.WinPcapSamp
 * JD-Core Version:    0.7.0.1
 */