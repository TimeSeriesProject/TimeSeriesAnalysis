package org.jnetpcap;

public class PcapSockAddr
{
  public static final int AF_INET = 2;
  public static final int AF_INET6 = 23;
  private volatile short family;
  private volatile byte[] data;
  
  private static native void initIDs();
  
  public final short getFamily()
  {
    return this.family;
  }
  
  public final byte[] getData()
  {
    return this.data;
  }
  
  private int u(byte paramByte)
  {
    return paramByte >= 0 ? paramByte : paramByte + 256;
  }
  
  public String toString()
  {
    switch (this.family)
    {
    case 2: 
      return "[INET4:" + u(this.data[0]) + "." + u(this.data[1]) + "." + u(this.data[2]) + "." + u(this.data[3]) + "]";
    case 23: 
      return "[INET6:" + this.data[0] + "." + this.data[1] + "." + this.data[2] + "." + this.data[3] + "]";
    }
    return "[" + this.family + "]";
  }
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapSockAddr
 * JD-Core Version:    0.7.0.1
 */