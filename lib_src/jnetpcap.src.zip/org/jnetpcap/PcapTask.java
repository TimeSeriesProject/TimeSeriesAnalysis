package org.jnetpcap;

public abstract class PcapTask<T>
  implements Runnable
{
  protected int result = 0;
  protected Thread thread;
  protected final Pcap pcap;
  protected final int count;
  protected final T user;
  
  public PcapTask(Pcap paramPcap, int paramInt, T paramT)
  {
    this.pcap = paramPcap;
    this.count = paramInt;
    this.user = paramT;
  }
  
  public final int getResult()
  {
    return this.result;
  }
  
  public final Thread getThread()
  {
    return this.thread;
  }
  
  public void start()
    throws InterruptedException
  {
    if (this.thread != null) {
      stop();
    }
    this.thread = new Thread(new Runnable()
    {
      public void run()
      {
        PcapTask.this.run();
        PcapTask.this.thread = null;
      }
    }, this.user != null ? this.user.toString() : this.pcap.toString());
    this.thread.setDaemon(true);
    this.thread.start();
  }
  
  public void stop()
    throws InterruptedException
  {
    if ((this.thread == null) || (!this.thread.isAlive())) {
      return;
    }
    breakLoop();
    this.thread.join();
  }
  
  protected void breakLoop()
  {
    this.pcap.breakloop();
  }
  
  public boolean isAlive()
  {
    return (this.thread != null) && (this.thread.isAlive());
  }
  
  public final Pcap getPcap()
  {
    return this.pcap;
  }
  
  public final int getCount()
  {
    return this.count;
  }
  
  public final T getUser()
  {
    return this.user;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapTask
 * JD-Core Version:    0.7.0.1
 */