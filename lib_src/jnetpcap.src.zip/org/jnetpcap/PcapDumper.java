package org.jnetpcap;

import java.nio.ByteBuffer;
import org.jnetpcap.nio.JBuffer;

public class PcapDumper
{
  private volatile long physical;
  
  private static native void initIDs();
  
  /**
   * @deprecated
   */
  public void dump(PcapPktHdr paramPcapPktHdr, ByteBuffer paramByteBuffer)
  {
    dump(paramPcapPktHdr.getSeconds(), paramPcapPktHdr.getUseconds(), paramPcapPktHdr.getCaplen(), paramPcapPktHdr.getLen(), paramByteBuffer);
  }
  
  public native void dump(PcapHeader paramPcapHeader, ByteBuffer paramByteBuffer);
  
  public native void dump(PcapHeader paramPcapHeader, JBuffer paramJBuffer);
  
  public native void dump(long paramLong, int paramInt1, int paramInt2, int paramInt3, ByteBuffer paramByteBuffer);
  
  public native long ftell();
  
  public native int flush();
  
  public native void close();
  
  static {}
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapDumper
 * JD-Core Version:    0.7.0.1
 */