package org.jnetpcap;

public enum PcapDLT
  implements DataLinkType
{
  NULL(0),  EN10MB(1),  EN3MB(2),  AX25(3),  PRONET(4),  CHAOS(5),  IEEE802(6),  ARCNET(7),  SLIP(8),  PPP(9),  FDDI(10),  ATM_RFC1483(11),  RAW(12),  SLIP_BSDOS(15),  PPP_BSDOS(16),  ATM_CLIP(19),  PPP_SERIAL(50),  PPP_ETHER(51),  SYMANTEC_FIREWALL(99),  C_HDLC(104),  IEEE802_11(105),  FRELAY(107),  LOOP(108),  ENC(109),  LINUX_SLL(113),  LTALK(114),  ECONET(115),  IPFILTER(116),  PFLOG(117),  CISCO_IOS(118),  PRISM_HEADER(119),  AIRONET_HEADER(120),  PFSYNC(121),  IP_OVER_FC(122),  SUNATM(123),  RIO(124),  PCI_EXP(125),  AURORA(126),  IEEE802_11_RADIO(127),  TZSP(128),  ARCNET_LINUX(129),  JUNIPER_MLPPP(130),  JUNIPER_MLFR(131),  JUNIPER_ES(132),  JUNIPER_GGSN(133),  JUNIPER_MFR(134),  JUNIPER_ATM2(135),  JUNIPER_SERVICES(136),  JUNIPER_ATM1(137),  APPLE_IP_OVER_IEEE1394(138),  MTP2_WITH_PHDR(139),  MTP2(140),  MTP3(141),  SCCP(142),  DOCSIS(143),  LINUX_IRDA(144),  IBM_SP(145),  IBM_SN(146),  USER0(147),  USER1(148),  USER2(149),  USER3(150),  USER4(151),  USER5(152),  USER6(153),  USER7(154),  USER8(155),  USER9(156),  USER10(157),  USER11(158),  USER12(159),  USER13(160),  USER14(161),  USER15(162),  IEEE802_11_RADIO_AVS(163),  JUNIPER_MONITOR(164),  BACNET_MS_TP(165),  PPP_PPPD(166),  JUNIPER_PPPOE(167),  JUNIPER_PPPOE_ATM(168),  GPRS_LLC(169),  GPF_T(170),  GPF_F(171),  GCOM_T1E1(172),  GCOM_SERIAL(173),  JUNIPER_PIC_PEER(174),  ERF_ETH(175),  ERF_POS(176),  LINUX_LAPD(177);
  
  public final int value;
  public final String description;
  public static final int CONST_NULL = 0;
  public static final int CONST_EN10MB = 1;
  public static final int CONST_EN3MB = 2;
  public static final int CONST_AX25 = 3;
  public static final int CONST_PRONET = 4;
  public static final int CONST_CHAOS = 5;
  public static final int CONST_IEEE802 = 6;
  public static final int CONST_ARCNET = 7;
  public static final int CONST_SLIP = 8;
  public static final int CONST_PPP = 9;
  public static final int CONST_FDDI = 10;
  public static final int CONST_ATM_RFC1483 = 11;
  public static final int CONST_RAW = 12;
  public static final int CONST_SLIP_BSDOS = 15;
  public static final int CONST_PPP_BSDOS = 16;
  public static final int CONST_ATM_CLIP = 19;
  public static final int CONST_PPP_SERIAL = 50;
  public static final int CONST_PPP_ETHER = 51;
  public static final int CONST_SYMANTEC_FIREWALL = 99;
  public static final int CONST_C_HDLC = 104;
  public static final int CONST_IEEE802_11 = 105;
  public static final int CONST_FRELAY = 107;
  public static final int CONST_LOOP = 108;
  public static final int CONST_ENC = 109;
  public static final int CONST_LINUX_SLL = 113;
  public static final int CONST_LTALK = 114;
  public static final int CONST_ECONET = 115;
  public static final int CONST_IPFILTER = 116;
  public static final int CONST_PFLOG = 117;
  public static final int CONST_CISCO_IOS = 118;
  public static final int CONST_PRISM_HEADER = 119;
  public static final int CONST_AIRONET_HEADER = 120;
  public static final int CONST_PFSYNC = 121;
  public static final int CONST_IP_OVER_FC = 122;
  public static final int CONST_SUNATM = 123;
  public static final int CONST_RIO = 124;
  public static final int CONST_PCI_EXP = 125;
  public static final int CONST_AURORA = 126;
  public static final int CONST_IEEE802_11_RADIO = 127;
  public static final int CONST_TZSP = 128;
  public static final int CONST_ARCNET_LINUX = 129;
  public static final int CONST_JUNIPER_MLPPP = 130;
  public static final int CONST_APPLE_IP_OVER_IEEE1394 = 138;
  public static final int CONST_JUNIPER_MLFR = 131;
  public static final int CONST_JUNIPER_ES = 132;
  public static final int CONST_JUNIPER_GGSN = 133;
  public static final int CONST_JUNIPER_MFR = 134;
  public static final int CONST_JUNIPER_ATM2 = 135;
  public static final int CONST_JUNIPER_SERVICES = 136;
  public static final int CONST_JUNIPER_ATM1 = 137;
  public static final int CONST_MTP2_WITH_PHDR = 139;
  public static final int CONST_MTP2 = 140;
  public static final int CONST_MTP3 = 141;
  public static final int CONST_SCCP = 142;
  public static final int CONST_DOCSIS = 143;
  public static final int CONST_LINUX_IRDA = 144;
  public static final int CONST_IBM_SP = 145;
  public static final int CONST_IBM_SN = 146;
  public static final int CONST_USER0 = 147;
  public static final int CONST_USER1 = 148;
  public static final int CONST_USER2 = 149;
  public static final int CONST_USER3 = 150;
  public static final int CONST_USER4 = 151;
  public static final int CONST_USER5 = 152;
  public static final int CONST_USER6 = 153;
  public static final int CONST_USER7 = 154;
  public static final int CONST_USER8 = 155;
  public static final int CONST_USER9 = 156;
  public static final int CONST_USER10 = 157;
  public static final int CONST_USER11 = 158;
  public static final int CONST_USER12 = 159;
  public static final int CONST_USER13 = 160;
  public static final int CONST_USER14 = 161;
  public static final int CONST_USER15 = 162;
  public static final int CONST_IEEE802_11_RADIO_AVS = 163;
  public static final int CONST_JUNIPER_MONITOR = 164;
  public static final int CONST_BACNET_MS_TP = 165;
  public static final int CONST_PPP_PPPD = 166;
  public static final int CONST_JUNIPER_PPPOE = 167;
  public static final int CONST_JUNIPER_PPPOE_ATM = 168;
  public static final int CONST_GPRS_LLC = 169;
  public static final int CONST_GPF_T = 170;
  public static final int CONST_GPF_F = 171;
  public static final int CONST_GCOM_T1E1 = 172;
  public static final int CONST_GCOM_SERIAL = 173;
  public static final int CONST_JUNIPER_PIC_PEER = 174;
  public static final int CONST_ERF_ETH = 175;
  public static final int CONST_ERF_POS = 176;
  public static final int CONST_LINUX_LAPD = 177;
  
  private PcapDLT(int paramInt)
  {
    this.value = paramInt;
    String str = Pcap.datalinkValToDescription(paramInt);
    if (str == null) {
      str = name();
    }
    this.description = str;
  }
  
  public boolean equals(int paramInt)
  {
    return this.value == paramInt;
  }
  
  public static PcapDLT valueOf(int paramInt)
  {
    PcapDLT[] arrayOfPcapDLT = values();
    int i = arrayOfPcapDLT.length;
    for (int j = 0; j < i; j++) {
      if (arrayOfPcapDLT[j].value == paramInt) {
        return arrayOfPcapDLT[j];
      }
    }
    return null;
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public int getValue()
  {
    return this.value;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapDLT
 * JD-Core Version:    0.7.0.1
 */