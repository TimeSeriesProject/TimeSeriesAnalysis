package org.jnetpcap;

public class PcapExtensionNotAvailableException
  extends IllegalStateException
{
  private static final long serialVersionUID = 4206020497547882412L;
  
  public PcapExtensionNotAvailableException() {}
  
  public PcapExtensionNotAvailableException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public PcapExtensionNotAvailableException(String paramString)
  {
    super(paramString);
  }
  
  public PcapExtensionNotAvailableException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapExtensionNotAvailableException
 * JD-Core Version:    0.7.0.1
 */