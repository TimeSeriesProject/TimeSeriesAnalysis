package org.jnetpcap.util;

import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

public class JNetPcapFormatter
  extends Formatter
{
  public String format(LogRecord paramLogRecord)
  {
    String str1 = String.format(paramLogRecord.getMessage(), paramLogRecord.getParameters());
    paramLogRecord.getLoggerName().split("\\.");
    String str2 = prefix(paramLogRecord);
    Throwable localThrowable = paramLogRecord.getThrown();
    String str3 = "";
    if (localThrowable != null)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      String str4 = localThrowable.getClass().getCanonicalName() + ":";
      localStringBuilder.append(str4).append(" ");
      localStringBuilder.append(localThrowable.getMessage()).append("\n");
      for (StackTraceElement localStackTraceElement : localThrowable.getStackTrace())
      {
        localStringBuilder.append(str4).append(" ");
        localStringBuilder.append(localStackTraceElement.toString()).append("\n");
      }
      str3 = localStringBuilder.toString();
    }
    return String.format(str2 + " %s\n%s", new Object[] { str1, str3 });
  }
  
  private String prefix(LogRecord paramLogRecord)
  {
    String[] arrayOfString = paramLogRecord.getLoggerName().split("\\.");
    return String.format("%s:%s:", new Object[] { paramLogRecord.getLevel().toString(), arrayOfString[(arrayOfString.length - 1)], paramLogRecord.getSourceMethodName() });
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.JNetPcapFormatter
 * JD-Core Version:    0.7.0.1
 */