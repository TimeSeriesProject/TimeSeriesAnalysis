package org.jnetpcap.util;

import java.lang.reflect.Constructor;

public class JThreadLocal<T>
  extends ThreadLocal<T>
{
  private final Constructor<T> constructor;
  
  public JThreadLocal()
  {
    this.constructor = null;
  }
  
  public JThreadLocal(Class<T> paramClass)
  {
    try
    {
      this.constructor = paramClass.getConstructor(new Class[0]);
    }
    catch (Exception localException)
    {
      throw new IllegalArgumentException(localException);
    }
  }
  
  protected T initialValue()
  {
    if (this.constructor == null) {
      return super.initialValue();
    }
    try
    {
      return this.constructor.newInstance(new Object[0]);
    }
    catch (Exception localException)
    {
      throw new IllegalStateException(localException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.JThreadLocal
 * JD-Core Version:    0.7.0.1
 */