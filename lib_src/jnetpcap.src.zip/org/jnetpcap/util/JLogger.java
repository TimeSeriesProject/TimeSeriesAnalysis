package org.jnetpcap.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import org.jnetpcap.util.config.JConfig;

public class JLogger
  extends Logger
{
  public static final String PROPERTIES_CONFIG = "resources/builtin-logger.properties";
  private static boolean triggerConfigInit = true;
  
  public JLogger(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }
  
  public static Logger getLogger(Class<?> paramClass)
  {
    if ((triggerConfigInit) && (paramClass != JConfig.class))
    {
      triggerConfigInit = false;
      JConfig.init();
    }
    return getLogger(paramClass.getName());
  }
  
  public static Logger getLogger(Package paramPackage)
  {
    if (triggerConfigInit)
    {
      triggerConfigInit = false;
      JConfig.init();
    }
    return getLogger(paramPackage.getName());
  }
  
  public static LogManager readConfiguration(Properties paramProperties)
    throws SecurityException, IOException
  {
    LogManager localLogManager = LogManager.getLogManager();
    return localLogManager;
  }
  
  public void setLevel(Level paramLevel)
    throws SecurityException
  {
    super.setLevel(paramLevel);
    if (triggerConfigInit)
    {
      triggerConfigInit = false;
      JConfig.init();
    }
  }
  
  static
  {
    try
    {
      InputStream localInputStream = JLogger.class.getClassLoader().getResourceAsStream("resources/builtin-logger.properties");
      if (localInputStream == null) {
        Logger.getLogger("").severe("JLogger.static<>: Unable to find builtin-logger.properties. Is resources directory missing in JAR File?");
      } else {
        localInputStream.close();
      }
    }
    catch (Exception localException)
    {
      Logger.getLogger("").log(Level.SEVERE, "Unable to find jNetPcap logger.properties", localException);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.JLogger
 * JD-Core Version:    0.7.0.1
 */