package org.jnetpcap.util;

import java.util.LinkedList;
import java.util.List;

public class ExpandableString
  extends JStringBuilder
{
  protected int count = 0;
  protected int end;
  private final List<String> quoted = new LinkedList();
  protected int start;
  private String template;
  
  public ExpandableString(String paramString)
  {
    this.template = paramString;
    super.append(paramString);
  }
  
  public final String getTemplate()
  {
    return this.template;
  }
  
  public boolean remove(String paramString)
  {
    return replaceSequence(paramString, "", "");
  }
  
  public boolean replaceSequence(String paramString1, String paramString2, String paramString3)
  {
    while ((scanNext(paramString1, paramString2)) && (this.start != -1)) {
      super.replace(this.start, this.end + 1, paramString3);
    }
    return this.start == -1;
  }
  
  public ExpandableString reset()
  {
    super.setLength(0);
    super.append(this.template);
    this.start = 0;
    this.end = 0;
    return this;
  }
  
  protected boolean restoreQuotes()
  {
    while ((scanNext("\\\\'", "\\\\'")) && (this.start != -1)) {
      super.replace(this.start, this.end + 3, (String)this.quoted.remove(0));
    }
    return this.start == -1;
  }
  
  protected boolean saveQuotes()
  {
    this.quoted.clear();
    while ((scanNext("'", "'")) && (this.start != -1))
    {
      this.quoted.add(super.substring(this.start, this.end + 1));
      super.replace(this.start, this.end + 1, "\\\\'\\\\'");
    }
    return this.start == -1;
  }
  
  protected boolean scanNext(String paramString1, String paramString2)
  {
    return scanNext(paramString1, paramString2, 0);
  }
  
  protected boolean scanNext(String paramString1, String paramString2, int paramInt)
  {
    this.start = super.indexOf(paramString1, paramInt);
    if (this.start == -1) {
      return true;
    }
    if ((this.start != 0) && (super.charAt(this.start - 1) == '\\')) {
      return scanNext(paramString1, paramString2, this.start + 1);
    }
    if (!scanNextEnd(paramString2, this.start + 1)) {
      return false;
    }
    this.count += 1;
    return true;
  }
  
  private boolean scanNextEnd(String paramString, int paramInt)
  {
    this.end = super.indexOf(paramString, paramInt);
    if (this.end == -1) {
      return false;
    }
    if ((this.end != 0) && (super.charAt(this.end - 1) == '\\')) {
      return scanNextEnd(paramString, this.end + 1);
    }
    return true;
  }
  
  public final void setTemplate(String paramString)
  {
    this.template = paramString;
    reset();
  }
  
  public String template()
  {
    return this.template;
  }
  
  public String toString()
  {
    return super.toString();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.ExpandableString
 * JD-Core Version:    0.7.0.1
 */