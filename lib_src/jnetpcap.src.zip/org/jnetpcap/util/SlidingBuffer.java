package org.jnetpcap.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.nio.JMemory;
import org.jnetpcap.nio.JMemoryPool;
import org.jnetpcap.nio.JNumber.Type;
import org.jnetpcap.packet.PeeringException;

public class SlidingBuffer
{
  private long leftSequence = 0L;
  private long rightSequence = 0L;
  private final JBuffer storage;
  private final int size;
  
  public SlidingBuffer(int paramInt)
  {
    this.size = paramInt;
    this.storage = JMemoryPool.buffer(paramInt + JNumber.Type.getBiggestSize());
  }
  
  public int findUTF8String(long paramLong, char... paramVarArgs)
  {
    return this.storage.findUTF8String(map(paramLong), paramVarArgs);
  }
  
  public byte getByte(long paramLong)
  {
    return this.storage.getByte(map(paramLong));
  }
  
  public byte[] getByteArray(long paramLong, byte[] paramArrayOfByte)
  {
    return this.storage.getByteArray(map(paramLong), paramArrayOfByte);
  }
  
  public byte[] getByteArray(long paramLong, int paramInt)
  {
    return this.storage.getByteArray(map(paramLong), paramInt);
  }
  
  public double getDouble(long paramLong)
  {
    return this.storage.getDouble(map(paramLong));
  }
  
  public float getFloat(long paramLong)
  {
    return this.storage.getFloat(map(paramLong));
  }
  
  public int getInt(long paramLong)
  {
    return this.storage.getInt(map(paramLong));
  }
  
  public long getLong(long paramLong)
  {
    return this.storage.getLong(map(paramLong));
  }
  
  public short getShort(long paramLong)
  {
    return this.storage.getShort(map(paramLong));
  }
  
  public int getUByte(long paramLong)
  {
    return this.storage.getUByte(map(paramLong));
  }
  
  public long getUInt(long paramLong)
  {
    return this.storage.getUInt(map(paramLong));
  }
  
  public int getUShort(long paramLong)
  {
    return this.storage.getUShort(map(paramLong));
  }
  
  public char getUTF8Char(long paramLong)
  {
    return this.storage.getUTF8Char(map(paramLong));
  }
  
  public String getUTF8String(long paramLong, char... paramVarArgs)
  {
    return this.storage.getUTF8String(map(paramLong), paramVarArgs);
  }
  
  public String getUTF8String(long paramLong, int paramInt)
  {
    return this.storage.getUTF8String(map(paramLong), paramInt);
  }
  
  public StringBuilder getUTF8String(int paramInt, StringBuilder paramStringBuilder, char... paramVarArgs)
  {
    return this.storage.getUTF8String(map(paramInt), paramStringBuilder, paramVarArgs);
  }
  
  public StringBuilder getUTF8String(long paramLong, StringBuilder paramStringBuilder, int paramInt)
  {
    return this.storage.getUTF8String(map(paramLong), paramStringBuilder, paramInt);
  }
  
  public int hashCode()
  {
    return this.storage.hashCode();
  }
  
  public boolean isInitialized()
  {
    return this.storage.isInitialized();
  }
  
  public boolean isJMemoryBasedOwner()
  {
    return this.storage.isJMemoryBasedOwner();
  }
  
  public final boolean isOwner()
  {
    return this.storage.isOwner();
  }
  
  public boolean isReadonly()
  {
    return this.storage.isReadonly();
  }
  
  public ByteOrder order()
  {
    return this.storage.order();
  }
  
  public void order(ByteOrder paramByteOrder)
  {
    this.storage.order(paramByteOrder);
  }
  
  public int peer(ByteBuffer paramByteBuffer)
    throws PeeringException
  {
    return this.storage.peer(paramByteBuffer);
  }
  
  public int peer(JBuffer paramJBuffer, int paramInt1, int paramInt2)
    throws IndexOutOfBoundsException
  {
    return this.storage.peer(paramJBuffer, paramInt1, paramInt2);
  }
  
  public int peer(JBuffer paramJBuffer)
  {
    return this.storage.peer(paramJBuffer);
  }
  
  public int peer(JMemory paramJMemory)
  {
    return this.storage.peer(paramJMemory);
  }
  
  public void setByte(long paramLong, byte paramByte)
  {
    this.storage.setByte(map(paramLong), paramByte);
  }
  
  public void setByteArray(long paramLong, byte[] paramArrayOfByte)
  {
    this.storage.setByteArray(map(paramLong), paramArrayOfByte);
  }
  
  public void setByteBuffer(int paramInt, ByteBuffer paramByteBuffer)
  {
    this.storage.setByteBuffer(paramInt, paramByteBuffer);
  }
  
  public void setDouble(long paramLong, double paramDouble)
  {
    this.storage.setDouble(map(paramLong), paramDouble);
  }
  
  public void setFloat(long paramLong, float paramFloat)
  {
    this.storage.setFloat(map(paramLong), paramFloat);
  }
  
  public void setInt(long paramLong, int paramInt)
  {
    this.storage.setInt(map(paramLong), paramInt);
  }
  
  public void setLong(long paramLong1, long paramLong2)
  {
    this.storage.setLong(map(paramLong1), paramLong2);
  }
  
  public void setShort(long paramLong, short paramShort)
  {
    this.storage.setShort(map(paramLong), paramShort);
  }
  
  public void setUByte(long paramLong, int paramInt)
  {
    this.storage.setUByte(map(paramLong), paramInt);
  }
  
  public void setUInt(long paramLong1, long paramLong2)
  {
    this.storage.setUInt(map(paramLong1), paramLong2);
  }
  
  private int map(long paramLong)
  {
    return (int)(paramLong - this.leftSequence);
  }
  
  public void setUShort(long paramLong, int paramInt)
  {
    this.storage.setUShort(map(paramLong), paramInt);
  }
  
  public int length()
  {
    return (int)(this.rightSequence - this.leftSequence);
  }
  
  public String toDebugString()
  {
    return this.storage.toDebugString();
  }
  
  public String toHexdump()
  {
    return this.storage.toHexdump();
  }
  
  public String toHexdump(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    return this.storage.toHexdump(paramInt, paramBoolean1, paramBoolean2, paramBoolean3);
  }
  
  public String toString()
  {
    return this.storage.toString();
  }
  
  public int transferFrom(byte[] paramArrayOfByte)
  {
    return this.storage.transferFrom(paramArrayOfByte);
  }
  
  public int transferFrom(ByteBuffer paramByteBuffer, int paramInt)
  {
    return this.storage.transferFrom(paramByteBuffer, (int)(paramInt - this.leftSequence));
  }
  
  public int transferFrom(JBuffer paramJBuffer)
  {
    advance(paramJBuffer.size());
    return this.storage.transferFrom(paramJBuffer);
  }
  
  private void advance(int paramInt)
  {
    if (this.rightSequence + paramInt > this.size) {}
  }
  
  public int transferTo(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
  {
    return this.storage.transferTo(paramByteBuffer, (int)(paramInt1 - this.leftSequence), paramInt2);
  }
  
  public int transferTo(ByteBuffer paramByteBuffer)
  {
    return this.storage.transferTo(paramByteBuffer);
  }
  
  public int transferTo(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3)
  {
    return this.storage.transferTo(paramJBuffer, (int)(paramInt1 - this.leftSequence), paramInt2, paramInt3);
  }
  
  public int transferTo(JBuffer paramJBuffer)
  {
    return this.storage.transferTo(paramJBuffer);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.SlidingBuffer
 * JD-Core Version:    0.7.0.1
 */