package org.jnetpcap.util.config;

import java.util.Map;
import java.util.Properties;
import org.jnetpcap.util.ExpandableString;

public class ConfigString
  extends ExpandableString
{
  private static final String VO = "${";
  private static final String VC = "}";
  private static final String PO = "@{";
  private static final String PC = "}";
  private final Map<String, String> variables;
  private final Properties properties;
  
  public ConfigString(String paramString, Map<String, String> paramMap, Properties paramProperties)
  {
    super(paramString);
    this.variables = paramMap;
    this.properties = paramProperties;
  }
  
  public boolean expand(String paramString)
  {
    return expand(paramString, this.variables, this.properties);
  }
  
  public boolean expand(String paramString, Map<String, String> paramMap)
  {
    return expand(paramString, paramMap, this.properties);
  }
  
  public boolean expand(String paramString, Map<String, String> paramMap, Properties paramProperties)
  {
    if (!saveQuotes()) {
      return false;
    }
    for (this.count = 0; (expandVariables(paramString, paramMap, paramProperties)) && (expandProperties(paramString, paramMap, paramProperties)); this.count = 0) {
      if (this.count == 0)
      {
        restoreQuotes();
        return true;
      }
    }
    restoreQuotes();
    return false;
  }
  
  public boolean expand(String paramString, Properties paramProperties)
  {
    return expand(paramString, null, paramProperties);
  }
  
  public boolean expandProperties(String paramString, Map<String, String> paramMap, Properties paramProperties)
  {
    while ((scanNext("@{", "}")) && (this.start != -1))
    {
      if (paramProperties == null) {
        return false;
      }
      String str1 = super.substring(this.start + "@{".length(), this.end);
      String str2 = paramProperties.getProperty(str1);
      if (str2 != null) {
        super.replace(this.start, this.end + "}".length(), str2);
      } else {
        return false;
      }
      if (!saveQuotes()) {
        return false;
      }
      if (!expandVariables(paramString, paramMap, paramProperties)) {
        return false;
      }
    }
    return this.start == -1;
  }
  
  public boolean expandVariables(String paramString, Map<String, String> paramMap, Properties paramProperties)
  {
    while ((scanNext("${", "}")) && (this.start != -1))
    {
      String str = super.substring(this.start + "${".length(), this.end);
      if (str.equals("name")) {
        super.replace(this.start, this.end + "}".length(), paramString);
      } else if ((paramMap != null) && (paramMap.containsKey(str))) {
        super.replace(this.start, this.end + 1, (String)paramMap.get(str));
      } else {
        return false;
      }
    }
    return this.start == -1;
  }
  
  public ConfigString reset()
  {
    super.reset();
    return this;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.config.ConfigString
 * JD-Core Version:    0.7.0.1
 */