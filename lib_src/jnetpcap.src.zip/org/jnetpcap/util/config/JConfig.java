package org.jnetpcap.util.config;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.InvalidPropertiesFormatException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jnetpcap.util.JLogger;

public class JConfig
{
  private static final String BOOTSTRAP_SEARCH_PATH = "config.bootstrap.search.path";
  private static final Properties builtinDefaults;
  public static final String CACHE_DIR_PROPERTY = "jnetpcap.resolver.dir";
  public static final String CACHE_FILE_SUFFIX = ".resolver";
  public static final String CACHE_FILE_SUFFIX_PROPERTY = "jnetpcap.resolver.suffix";
  public static final String CACHE_SUB_DIR = ".jnp";
  public static final String CACHE_SUB_DIR_PROPERTY = "jnetpcap.resolver.subdir";
  private static final String CONFIG_PROPERTY = "config.name";
  private static Map<String, String> globalVariables = new HashMap();
  private static final PropertyChangeSupport listeners = new PropertyChangeSupport(topReadOnlyProperties);
  private static Logger logger = JLogger.getLogger(JConfig.class);
  private static final String LOGGER_NAME = "logger.name";
  private static final String LOGGER_SEARCH_PATH = "logger.search.path";
  private static final CompositeProperties loggingProperties;
  public static final String RESOURCE_SEARCH_PATH_PROPERTY = "search.path";
  private static final CompositeProperties topReadOnlyProperties;
  public static final String USER_HOME_PROPERTY = "user.home";
  private static final Properties userProperties;
  
  public static void addListener(PropertyChangeListener paramPropertyChangeListener, String paramString)
  {
    listeners.addPropertyChangeListener(paramPropertyChangeListener);
  }
  
  public static void addListener(PropertyChangeListener paramPropertyChangeListener, String paramString, boolean paramBoolean)
  {
    addListener(paramPropertyChangeListener, paramString, Boolean.toString(paramBoolean));
  }
  
  public static void addListener(PropertyChangeListener paramPropertyChangeListener, String paramString, int paramInt)
  {
    addListener(paramPropertyChangeListener, paramString, Integer.toString(paramInt));
  }
  
  public static void addListener(PropertyChangeListener paramPropertyChangeListener, String paramString, long paramLong)
  {
    addListener(paramPropertyChangeListener, paramString, Long.toString(paramLong));
  }
  
  public static void addListener(PropertyChangeListener paramPropertyChangeListener, String paramString1, String paramString2)
  {
    listeners.addPropertyChangeListener(paramString1, paramPropertyChangeListener);
    String str = getProperty(paramString1);
    if (str == null)
    {
      if (paramString2 != null) {
        setProperty(paramString1, paramString2);
      }
    }
    else {
      paramPropertyChangeListener.propertyChange(new PropertyChangeEvent(topReadOnlyProperties, paramString1, null, str));
    }
  }
  
  public static SearchPath[] createSearchPath(String paramString)
  {
    String str = topReadOnlyProperties.getProperty(paramString);
    if (str == null) {
      return null;
    }
    SearchpathString localSearchpathString = new SearchpathString(str, globalVariables, topReadOnlyProperties);
    SearchPath[] arrayOfSearchPath = localSearchpathString.toArray();
    return arrayOfSearchPath;
  }
  
  private static void exportPropertiesToVariables(Properties paramProperties)
  {
    Iterator localIterator = topReadOnlyProperties.keySet().iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      String str1 = (String)localObject;
      if (str1.startsWith("var."))
      {
        String str2 = topReadOnlyProperties.getProperty(str1);
        globalVariables.put(str1.substring(4), str2);
      }
    }
  }
  
  public static File getFile(String paramString, SearchPath[] paramArrayOfSearchPath)
    throws IOException
  {
    if (paramArrayOfSearchPath == null) {
      return null;
    }
    File localFile = null;
    logger.log(Level.FINEST, "searching file for " + paramString);
    for (SearchPath localSearchPath : paramArrayOfSearchPath) {
      if ((localFile = localSearchPath.getFile(paramString)) != null) {
        break;
      }
    }
    return localFile;
  }
  
  public static File getFile(String paramString1, String paramString2)
    throws IOException
  {
    if (!topReadOnlyProperties.containsKey(paramString2)) {
      return null;
    }
    return getFile(paramString1, createSearchPath(paramString2));
  }
  
  public static InputStream getInputStream(String paramString, SearchPath[] paramArrayOfSearchPath)
    throws IOException
  {
    if (paramArrayOfSearchPath == null) {
      return null;
    }
    InputStream localInputStream = null;
    logger.log(Level.FINEST, "searching InputStream for " + paramString);
    for (SearchPath localSearchPath : paramArrayOfSearchPath) {
      if ((localInputStream = localSearchPath.getInputStream(paramString)) != null) {
        break;
      }
    }
    return localInputStream;
  }
  
  public static InputStream getInputStream(String paramString1, String paramString2)
    throws IOException
  {
    if (!topReadOnlyProperties.containsKey(paramString2)) {
      return null;
    }
    SearchPath[] arrayOfSearchPath = createSearchPath(paramString2);
    return getInputStream(paramString1, arrayOfSearchPath);
  }
  
  public static String getProperty(String paramString)
  {
    return topReadOnlyProperties.getProperty(paramString);
  }
  
  public static String getExpandedProperty(String paramString)
  {
    ConfigString localConfigString = new ConfigString(getProperty(paramString), globalVariables, topReadOnlyProperties);
    if (localConfigString.expand("")) {
      return localConfigString.toString();
    }
    return null;
  }
  
  public static String getExpandedProperty(String paramString1, String paramString2)
  {
    if (!topReadOnlyProperties.containsKey(paramString1)) {
      return paramString2;
    }
    ConfigString localConfigString = new ConfigString(getProperty(paramString1), globalVariables, topReadOnlyProperties);
    if (localConfigString.expand("")) {
      return localConfigString.toString();
    }
    return paramString2;
  }
  
  public static String getProperty(String paramString1, String paramString2)
  {
    return topReadOnlyProperties.getProperty(paramString1, paramString2);
  }
  
  public static InputStream getResourceInputStream(String paramString)
    throws IOException
  {
    return getInputStream(paramString, "search.path");
  }
  
  public static URL getResourceURL(String paramString)
    throws IOException
  {
    return getURL(paramString, "search.path");
  }
  
  private static URL getURL(String paramString, SearchPath[] paramArrayOfSearchPath)
    throws IOException
  {
    URL localURL = null;
    if (paramArrayOfSearchPath == null) {
      return null;
    }
    logger.log(Level.FINEST, "searching URL for " + paramString);
    for (SearchPath localSearchPath : paramArrayOfSearchPath) {
      if ((localURL = localSearchPath.getURL(paramString)) != null) {
        break;
      }
    }
    return localURL;
  }
  
  public static URL getURL(String paramString1, String paramString2)
    throws IOException
  {
    if (!topReadOnlyProperties.containsKey(paramString2)) {
      return null;
    }
    return getURL(paramString1, createSearchPath(paramString2));
  }
  
  public static void init() {}
  
  public static void removeListener(PropertyChangeListener paramPropertyChangeListener)
  {
    listeners.removePropertyChangeListener(paramPropertyChangeListener);
  }
  
  public static void removeListener(PropertyChangeListener paramPropertyChangeListener, String paramString)
  {
    listeners.removePropertyChangeListener(paramString, paramPropertyChangeListener);
  }
  
  public static String setProperty(String paramString1, String paramString2)
  {
    String str = (String)userProperties.setProperty(paramString1, paramString2);
    listeners.firePropertyChange(paramString1, str, paramString2);
    return str;
  }
  
  public static File getDir(SearchPath[] paramArrayOfSearchPath)
  {
    File localFile = null;
    if (paramArrayOfSearchPath == null)
    {
      logger.warning("null search path for directory ");
      return null;
    }
    logger.log(Level.FINEST, "searching file for directory");
    for (SearchPath localSearchPath : paramArrayOfSearchPath) {
      if ((localFile = localSearchPath.getDir("")) != null) {
        break;
      }
    }
    return localFile;
  }
  
  public static File getDir(String paramString)
  {
    SearchPath[] arrayOfSearchPath = createSearchPath(paramString);
    return getDir(arrayOfSearchPath);
  }
  
  public static File createDir(String paramString1, String paramString2)
  {
    String str = topReadOnlyProperties.getProperty(paramString1);
    if (str == null)
    {
      logger.finer("create directory property not found " + paramString1);
      logger.finer("create directory using defaults " + paramString2);
      str = paramString2;
    }
    ConfigString localConfigString = new ConfigString(str, globalVariables, topReadOnlyProperties);
    if (!localConfigString.expand(""))
    {
      logger.finer("create directory property expansion failed " + localConfigString.toString());
      localConfigString.setTemplate(paramString2);
      if (!localConfigString.expand(""))
      {
        logger.finer("create directory defaults expansion failed " + localConfigString.toString());
        return null;
      }
    }
    File localFile = new File(localConfigString.toString());
    if (!localFile.mkdir())
    {
      logger.fine("failed to created dir " + localFile.toString());
      return null;
    }
    logger.fine("created dir " + localFile.toString());
    return localFile;
  }
  
  public static ConfigString createConfigString(String paramString)
  {
    return new ConfigString(paramString, globalVariables, topReadOnlyProperties);
  }
  
  public static SearchpathString createSearchString(String paramString)
  {
    return new SearchpathString(paramString, globalVariables, topReadOnlyProperties);
  }
  
  public static Properties getTopProperties()
  {
    return topReadOnlyProperties;
  }
  
  public static Properties getUserProperties()
  {
    return userProperties;
  }
  
  public static Map<String, String> getGlobalVariables()
  {
    return globalVariables;
  }
  
  static
  {
    logger = JLogger.getLogger(JConfig.class);
    globalVariables.put("jnp", "org.jnetpcap");
    builtinDefaults = new Properties();
    URL localURL;
    try
    {
      localURL = JConfig.class.getClassLoader().getResource("resources/builtin-config.properties");
      if (localURL == null)
      {
        logger.severe("JConfig.static<>: unable to find builtin-config.properites. Is resources directory in JAR file?");
      }
      else
      {
        builtinDefaults.load(new PreprocessStream(localURL.openStream()));
        logger.fine("loaded " + localURL.toString());
      }
    }
    catch (Exception localException1)
    {
      logger.log(Level.SEVERE, "builtin config intialization", localException1);
    }
    userProperties = new Properties();
    topReadOnlyProperties = new CompositeProperties(new Properties[] { System.getProperties(), userProperties, builtinDefaults });
    topReadOnlyProperties.setSaveProperties(userProperties);
    exportPropertiesToVariables(topReadOnlyProperties);
    String str = getProperty("config.name");
    try
    {
      localURL = getURL(str, "config.bootstrap.search.path");
      if (localURL != null)
      {
        userProperties.load(localURL.openStream());
        exportPropertiesToVariables(userProperties);
        logger.fine("loaded " + localURL.toString());
      }
    }
    catch (IOException localIOException)
    {
      logger.log(Level.SEVERE, "user config intialization", localIOException);
    }
    loggingProperties = new CompositeProperties(new Properties[0]);
    Properties localProperties1 = new Properties();
    try
    {
      localURL = getURL("builtin-logger.properties", "logger.search.path");
      if (localURL == null)
      {
        logger.severe("JConfig.static<>3: unable to find builtin-logger.properties. Is resources directory in JAR file?");
      }
      else
      {
        localProperties1.load(localURL.openStream());
        logger.fine("loaded " + localURL.toString());
        Properties localProperties2 = new Properties();
        localURL = getURL(getProperty("logger.name"), "logger.search.path");
        if (localURL != null)
        {
          localProperties2.load(localURL.openStream());
          loggingProperties.addProperties(new Properties[] { userProperties, localProperties1 });
          Level localLevel = logger.getLevel();
          JLogger.readConfiguration(loggingProperties);
          logger.setLevel(localLevel);
          logger.fine("loaded " + localURL.toString());
          logger.fine("logger config reinitialized from user settings");
          logger.fine("restoring logging to Level." + localLevel);
        }
        else
        {
          loggingProperties.addProperties(new Properties[] { localProperties1 });
        }
      }
    }
    catch (Exception localException2)
    {
      logger.log(Level.WARNING, "logger config intialization error", localException2);
    }
  }
  
  protected static class URLSearch
    implements JConfig.SearchPath
  {
    private final ConfigString url;
    
    public URLSearch(ConfigString paramConfigString)
    {
      this.url = paramConfigString;
    }
    
    public File getFile(String paramString)
      throws IOException
    {
      return null;
    }
    
    public InputStream getInputStream(String paramString)
      throws IOException
    {
      this.url.reset();
      if (this.url.expand(paramString, JConfig.globalVariables, JConfig.topReadOnlyProperties))
      {
        String str = this.url.toString();
        URL localURL = null;
        try
        {
          localURL = new URL(str);
        }
        catch (IOException localIOException)
        {
          this.url.reset().expand(paramString, JConfig.globalVariables);
          JConfig.logger.log(Level.WARNING, "URL: invalid URL format after expansion '" + str + "' property='" + this.url.toString() + "'");
          return null;
        }
        InputStream localInputStream = localURL.openStream();
        if (localInputStream != null)
        {
          JConfig.logger.log(Level.FINER, "URL: opened " + str);
          return localInputStream;
        }
        JConfig.logger.log(Level.FINEST, "URL: not found " + str);
      }
      else
      {
        JConfig.logger.log(Level.FINEST, "URL: failed to expand " + this.url.toString());
      }
      return null;
    }
    
    public URL getURL(String paramString)
      throws IOException
    {
      this.url.reset();
      if (this.url.expand(paramString, JConfig.globalVariables, JConfig.topReadOnlyProperties))
      {
        String str = this.url.toString();
        URL localURL = null;
        try
        {
          localURL = new URL(str);
        }
        catch (IOException localIOException)
        {
          this.url.reset().expand(paramString, JConfig.globalVariables);
          JConfig.logger.log(Level.WARNING, "URL: invalid URL format after expansion '" + str + "' property='" + this.url.toString() + "'");
          return null;
        }
        InputStream localInputStream = localURL.openStream();
        if (localInputStream != null)
        {
          localInputStream.close();
          JConfig.logger.log(Level.FINER, "URL: opened " + str);
          return localURL;
        }
        JConfig.logger.log(Level.FINEST, "URL: not found " + str);
      }
      else
      {
        JConfig.logger.log(Level.FINEST, "URL: failed to expand " + this.url.toString());
      }
      return null;
    }
    
    public String toString()
    {
      return "URL(" + this.url.getTemplate() + ")";
    }
    
    public File getDir(String paramString)
    {
      return null;
    }
  }
  
  public static abstract interface SearchPath
  {
    public abstract File getFile(String paramString)
      throws IOException;
    
    public abstract InputStream getInputStream(String paramString)
      throws IOException;
    
    public abstract URL getURL(String paramString)
      throws IOException;
    
    public abstract File getDir(String paramString);
  }
  
  private static class PreprocessStream
    extends InputStream
  {
    private static final byte[] str = { 92, 13, 10 };
    private final BufferedInputStream in;
    
    public PreprocessStream(InputStream paramInputStream)
    {
      this.in = new BufferedInputStream(paramInputStream, 3);
    }
    
    private boolean matchReaminingChars()
      throws IOException
    {
      this.in.mark(2);
      if (this.in.read() != str[1])
      {
        this.in.reset();
        return false;
      }
      if (this.in.read() != str[2])
      {
        this.in.reset();
        return false;
      }
      return true;
    }
    
    public synchronized int read()
      throws IOException
    {
      int i = this.in.read();
      if ((i == str[0]) && (matchReaminingChars())) {
        i = this.in.read();
      }
      return i;
    }
  }
  
  protected static class FilesystemSearch
    implements JConfig.SearchPath
  {
    private final ConfigString filename;
    
    public FilesystemSearch(ConfigString paramConfigString)
    {
      this.filename = paramConfigString;
    }
    
    public File getFile(String paramString)
      throws IOException
    {
      this.filename.reset();
      if (this.filename.expand(paramString, JConfig.globalVariables, JConfig.topReadOnlyProperties))
      {
        String str = this.filename.toString();
        File localFile = new File(str);
        if (localFile.isFile())
        {
          JConfig.logger.log(Level.FINER, "FILE: found " + str);
          return localFile;
        }
        JConfig.logger.log(Level.FINEST, "FILE: not found " + str);
      }
      else
      {
        JConfig.logger.log(Level.FINEST, "FILE: failed to expand " + this.filename.toString());
      }
      return null;
    }
    
    public InputStream getInputStream(String paramString)
      throws IOException
    {
      File localFile = getFile(paramString);
      if (localFile != null) {
        return new FileInputStream(localFile);
      }
      return null;
    }
    
    public URL getURL(String paramString)
      throws IOException
    {
      File localFile = getFile(paramString);
      if (localFile != null) {
        return localFile.toURI().toURL();
      }
      return null;
    }
    
    public String toString()
    {
      return "File(" + this.filename.getTemplate() + ")";
    }
    
    public File getDir(String paramString)
    {
      this.filename.reset();
      if (this.filename.expand(paramString, JConfig.globalVariables, JConfig.topReadOnlyProperties))
      {
        String str = this.filename.toString();
        File localFile = new File(str);
        if (localFile.isDirectory())
        {
          JConfig.logger.log(Level.FINER, "FILE: found " + str);
          return localFile;
        }
        JConfig.logger.log(Level.FINEST, "FILE: not found " + str);
      }
      else
      {
        JConfig.logger.log(Level.FINEST, "FILE: failed to expand " + this.filename.toString());
      }
      return null;
    }
  }
  
  private static class CompositeProperties
    extends Properties
  {
    private static final long serialVersionUID = 98826036967593082L;
    private Properties[] properties;
    private Properties save = null;
    
    public CompositeProperties(Properties... paramVarArgs)
    {
      this.properties = paramVarArgs;
    }
    
    public void addProperties(Properties... paramVarArgs)
    {
      this.properties = paramVarArgs;
    }
    
    public synchronized boolean contains(Object paramObject)
    {
      for (Properties localProperties : this.properties) {
        if (localProperties.contains(paramObject)) {
          return true;
        }
      }
      return false;
    }
    
    public synchronized boolean containsKey(Object paramObject)
    {
      for (Properties localProperties : this.properties) {
        if (localProperties.containsKey(paramObject)) {
          return true;
        }
      }
      return false;
    }
    
    private Properties flatten()
    {
      Properties localProperties1 = new Properties();
      for (int i = this.properties.length - 1; i >= 0; i--)
      {
        Properties localProperties2 = this.properties[i];
        localProperties1.putAll(localProperties2);
      }
      return localProperties1;
    }
    
    public String getProperty(String paramString)
    {
      return getProperty(paramString, null);
    }
    
    public String getProperty(String paramString1, String paramString2)
    {
      for (Properties localProperties : this.properties) {
        if (localProperties.containsKey(paramString1)) {
          return localProperties.getProperty(paramString1);
        }
      }
      if (paramString2 == null) {
        return null;
      }
      return paramString2;
    }
    
    public Set<Object> keySet()
    {
      return flatten().keySet();
    }
    
    public void list(PrintStream paramPrintStream)
    {
      flatten().list(paramPrintStream);
    }
    
    public void list(PrintWriter paramPrintWriter)
    {
      flatten().list(paramPrintWriter);
    }
    
    public synchronized void load(InputStream paramInputStream)
      throws IOException
    {
      throw new UnsupportedOperationException("invalid operation in composite");
    }
    
    public synchronized void loadFromXML(InputStream paramInputStream)
      throws IOException, InvalidPropertiesFormatException
    {
      throw new UnsupportedOperationException("invalid operation in composite");
    }
    
    public Enumeration<?> propertyNames()
    {
      return flatten().propertyNames();
    }
    
    public synchronized Object setProperty(String paramString1, String paramString2)
    {
      if (this.save != null) {
        return this.save.setProperty(paramString1, paramString2);
      }
      return null;
    }
    
    public void setSaveProperties(Properties paramProperties)
    {
      this.save = paramProperties;
    }
    
    public synchronized void store(OutputStream paramOutputStream, String paramString)
      throws IOException
    {
      for (Properties localProperties : this.properties)
      {
        localProperties.store(paramOutputStream, paramString);
        paramOutputStream.flush();
      }
    }
    
    public synchronized void storeToXML(OutputStream paramOutputStream, String paramString)
      throws IOException
    {
      flatten().storeToXML(paramOutputStream, paramString);
      paramOutputStream.flush();
    }
    
    public synchronized void storeToXML(OutputStream paramOutputStream, String paramString1, String paramString2)
      throws IOException
    {
      flatten().storeToXML(paramOutputStream, paramString1, paramString2);
      paramOutputStream.flush();
    }
  }
  
  protected static class ClasspathSearch
    implements JConfig.SearchPath
  {
    private final ConfigString resource;
    
    public ClasspathSearch(ConfigString paramConfigString)
    {
      this.resource = paramConfigString;
    }
    
    public File getFile(String paramString)
      throws IOException
    {
      return null;
    }
    
    public InputStream getInputStream(String paramString)
      throws IOException
    {
      URL localURL = getURL(paramString);
      return localURL == null ? null : localURL.openStream();
    }
    
    public URL getURL(String paramString)
      throws IOException
    {
      this.resource.reset();
      if (this.resource.expand(paramString, JConfig.globalVariables, JConfig.topReadOnlyProperties))
      {
        String str = this.resource.toString();
        URL localURL = JConfig.class.getClassLoader().getResource(str);
        if (localURL != null) {
          JConfig.logger.log(Level.FINER, "CLASSPATH: found " + str);
        } else {
          JConfig.logger.log(Level.FINEST, "CLASSPATH: not found " + str);
        }
        return localURL;
      }
      JConfig.logger.log(Level.FINEST, "CLASSPATH: failed to expand " + this.resource.toString());
      return null;
    }
    
    public String toString()
    {
      return "Classpath(" + this.resource.getTemplate() + ")";
    }
    
    public File getDir(String paramString)
    {
      return null;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.config.JConfig
 * JD-Core Version:    0.7.0.1
 */