package org.jnetpcap.util.config;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;
import org.jnetpcap.util.JLogger;

public class SearchpathString
  extends ConfigString
{
  private static final Logger logger = JLogger.getLogger(JConfig.class);
  private final List<String> pathContents = new ArrayList();
  private final Properties properties;
  private final Map<String, String> variables;
  
  public SearchpathString(String paramString, Map<String, String> paramMap, Properties paramProperties)
  {
    super(paramString, paramMap, paramProperties);
    this.variables = paramMap;
    this.properties = paramProperties;
  }
  
  private void cleanupString()
  {
    super.expand("", this.variables, this.properties);
    remove("\\\r\n");
    trimToSize();
    this.start = 0;
    this.end = -1;
  }
  
  public SearchpathString reset()
  {
    super.reset();
    this.pathContents.clear();
    return this;
  }
  
  private boolean splitToComponents()
  {
    while ((scanNext("'", "'", this.end + 1)) && (this.start != -1))
    {
      if (this.properties == null) {
        return false;
      }
      String str = substring(this.start + 1, this.end).trim();
      if (str.length() != 0) {
        this.pathContents.add(str);
      }
    }
    return this.start == -1;
  }
  
  public JConfig.SearchPath[] toArray()
  {
    reset();
    cleanupString();
    splitToComponents();
    ArrayList localArrayList = new ArrayList(this.pathContents.size());
    Iterator localIterator = this.pathContents.iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      String str2;
      if (str1.startsWith("File("))
      {
        str2 = str1.substring("File(".length(), str1.length() - 1);
        localArrayList.add(new JConfig.FilesystemSearch(new ConfigString(str2, this.variables, this.properties)));
      }
      else if (str1.startsWith("Classpath("))
      {
        str2 = str1.substring("Classpath(".length(), str1.length() - 1);
        localArrayList.add(new JConfig.ClasspathSearch(new ConfigString(str2, this.variables, this.properties)));
      }
      else if (str1.startsWith("URL("))
      {
        str2 = str1.substring("URL(".length(), str1.length() - 1);
        localArrayList.add(new JConfig.URLSearch(new ConfigString(str2, this.variables, this.properties)));
      }
      else
      {
        logger.warning("unexpected search component type " + str1);
      }
    }
    return (JConfig.SearchPath[])localArrayList.toArray(new JConfig.SearchPath[localArrayList.size()]);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.config.SearchpathString
 * JD-Core Version:    0.7.0.1
 */