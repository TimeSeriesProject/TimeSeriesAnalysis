package org.jnetpcap.util;

import org.jnetpcap.nio.JStruct;

public class Debug
  extends JStruct
{
  public static native int sizeof();
  
  public Debug()
  {
    super("class Debug", sizeof());
  }
  
  public void setLevel(LevelId paramLevelId)
  {
    setLevel(paramLevelId.intValue());
  }
  
  public native void setLevel(int paramInt);
  
  public native int getLevel();
  
  public Level getLevelEnum()
  {
    return Level.valueOf(getLevel());
  }
  
  public static enum Level
    implements Debug.LevelId
  {
    ERROR(4),  WARN(6),  INFO(8),  TRACE(10);
    
    private final int level;
    
    private Level(int paramInt)
    {
      this.level = paramInt;
    }
    
    public int intValue()
    {
      return this.level;
    }
    
    public static Level valueOf(int paramInt)
    {
      for (Level localLevel : ) {
        if (localLevel.level == paramInt) {
          return localLevel;
        }
      }
      return null;
    }
  }
  
  public static abstract interface LevelId
  {
    public abstract int intValue();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.Debug
 * JD-Core Version:    0.7.0.1
 */