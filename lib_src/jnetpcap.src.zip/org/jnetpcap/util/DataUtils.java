package org.jnetpcap.util;

import org.jnetpcap.nio.JBuffer;

public class DataUtils
{
  public static byte[] diff(JBuffer paramJBuffer1, JBuffer paramJBuffer2)
  {
    return diff(paramJBuffer1.getByteArray(0, paramJBuffer1.size()), paramJBuffer2.getByteArray(0, paramJBuffer2.size()));
  }
  
  public static byte[] diff(byte[] paramArrayOfByte, JBuffer paramJBuffer)
  {
    return diff(paramArrayOfByte, paramJBuffer.getByteArray(0, paramJBuffer.size()));
  }
  
  public static byte[] diff(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    int i = paramArrayOfByte1.length > paramArrayOfByte2.length ? paramArrayOfByte1.length : paramArrayOfByte2.length;
    byte[] arrayOfByte = new byte[i];
    for (int j = 0; j < i; j++)
    {
      int k = j < paramArrayOfByte1.length ? paramArrayOfByte1[j] : 0;
      int m = j < paramArrayOfByte2.length ? paramArrayOfByte2[j] : 0;
      arrayOfByte[j] = ((byte)(m - k));
    }
    return arrayOfByte;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.DataUtils
 * JD-Core Version:    0.7.0.1
 */