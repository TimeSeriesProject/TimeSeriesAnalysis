package org.jnetpcap.util;

public abstract interface Offset
{
  public abstract int offset();
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.Offset
 * JD-Core Version:    0.7.0.1
 */