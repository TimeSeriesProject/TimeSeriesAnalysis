package org.jnetpcap.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public abstract class BlockingQueuePump<T>
  implements BlockingQueue<T>
{
  private final String name;
  private final BlockingQueue<T> queue;
  private final AtomicReference<Thread> thread = new AtomicReference();
  public Runnable dispatchQueue = new Runnable()
  {
    public void run()
    {
      try
      {
        while (BlockingQueuePump.this.thread.get() != null) {
          BlockingQueuePump.this.dispatch(BlockingQueuePump.this.take());
        }
        if (BlockingQueuePump.this.thread.get() != null) {
          throw new IllegalStateException(BlockingQueuePump.this.name + " thread unexpected termination");
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        localInterruptedException.printStackTrace();
      }
      finally
      {
        BlockingQueuePump.this.thread.set(null);
      }
    }
  };
  
  public BlockingQueuePump(String paramString)
  {
    this.queue = new LinkedBlockingQueue();
    this.name = paramString;
    start();
  }
  
  public BlockingQueuePump(String paramString, int paramInt)
  {
    this.queue = new ArrayBlockingQueue(paramInt);
    this.name = paramString;
    start();
  }
  
  public boolean add(T paramT)
  {
    return this.queue.add(paramT);
  }
  
  public boolean addAll(Collection<? extends T> paramCollection)
  {
    return this.queue.addAll(paramCollection);
  }
  
  public void clear()
  {
    this.queue.clear();
  }
  
  public boolean contains(Object paramObject)
  {
    return this.queue.contains(paramObject);
  }
  
  public boolean containsAll(Collection<?> paramCollection)
  {
    return this.queue.containsAll(paramCollection);
  }
  
  protected abstract void dispatch(T paramT);
  
  public int drainTo(Collection<? super T> paramCollection)
  {
    return this.queue.drainTo(paramCollection);
  }
  
  public int drainTo(Collection<? super T> paramCollection, int paramInt)
  {
    return this.queue.drainTo(paramCollection, paramInt);
  }
  
  public T element()
  {
    return this.queue.element();
  }
  
  public boolean equals(Object paramObject)
  {
    return this.queue.equals(paramObject);
  }
  
  public int hashCode()
  {
    return this.queue.hashCode();
  }
  
  public boolean isAlive()
  {
    return (this.thread.get() != null) && (((Thread)this.thread.get()).isAlive());
  }
  
  public boolean isEmpty()
  {
    return this.queue.isEmpty();
  }
  
  public Iterator<T> iterator()
  {
    return this.queue.iterator();
  }
  
  public boolean offer(T paramT)
  {
    return this.queue.offer(paramT);
  }
  
  public boolean offer(T paramT, long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException
  {
    return this.queue.offer(paramT, paramLong, paramTimeUnit);
  }
  
  public T peek()
  {
    return this.queue.peek();
  }
  
  public T poll()
  {
    return this.queue.poll();
  }
  
  public T poll(long paramLong, TimeUnit paramTimeUnit)
    throws InterruptedException
  {
    return this.queue.poll(paramLong, paramTimeUnit);
  }
  
  public void put(T paramT)
    throws InterruptedException
  {
    this.queue.put(paramT);
  }
  
  public int remainingCapacity()
  {
    return this.queue.remainingCapacity();
  }
  
  public T remove()
  {
    return this.queue.remove();
  }
  
  public boolean remove(Object paramObject)
  {
    return this.queue.remove(paramObject);
  }
  
  public boolean removeAll(Collection<?> paramCollection)
  {
    return this.queue.removeAll(paramCollection);
  }
  
  public boolean retainAll(Collection<?> paramCollection)
  {
    return this.queue.retainAll(paramCollection);
  }
  
  public int size()
  {
    return this.queue.size();
  }
  
  public void start()
  {
    if (this.thread.get() != null) {
      throw new IllegalStateException(this.name + " thread unexpected termination");
    }
    this.thread.set(new Thread(this.dispatchQueue, this.name));
    ((Thread)this.thread.get()).setDaemon(true);
    ((Thread)this.thread.get()).start();
  }
  
  public void stop()
  {
    if ((this.thread.get() == null) || (!((Thread)this.thread.get()).isAlive()))
    {
      this.thread.set(null);
      return;
    }
    synchronized ((Thread)this.thread.get())
    {
      try
      {
        this.thread.wait();
      }
      catch (InterruptedException localInterruptedException) {}finally
      {
        this.thread.set(null);
      }
    }
  }
  
  public T take()
    throws InterruptedException
  {
    return this.queue.take();
  }
  
  public Object[] toArray()
  {
    return this.queue.toArray();
  }
  
  public <Q> Q[] toArray(Q[] paramArrayOfQ)
  {
    return this.queue.toArray(paramArrayOfQ);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.BlockingQueuePump
 * JD-Core Version:    0.7.0.1
 */