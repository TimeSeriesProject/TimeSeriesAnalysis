package org.jnetpcap.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JPacketHandler;

public class JPacketSupport
  implements JPacketHandler<Object>
{
  private List<Entry> listeners = new ArrayList();
  private Entry[] listenersArray = null;
  
  public <T> boolean add(JPacketHandler<T> paramJPacketHandler, T paramT)
  {
    this.listenersArray = null;
    return this.listeners.add(new Entry(paramJPacketHandler, paramT));
  }
  
  public boolean remove(JPacketHandler<?> paramJPacketHandler)
  {
    this.listenersArray = null;
    Iterator localIterator = this.listeners.iterator();
    while (localIterator.hasNext())
    {
      Entry localEntry = (Entry)localIterator.next();
      if (paramJPacketHandler == localEntry.handler)
      {
        localIterator.remove();
        this.listenersArray = null;
        return true;
      }
    }
    return false;
  }
  
  public void fireNextPacket(JPacket paramJPacket)
  {
    if (this.listenersArray == null) {
      this.listenersArray = ((Entry[])this.listeners.toArray(new Entry[this.listeners.size()]));
    }
    for (Entry localEntry : this.listenersArray) {
      localEntry.handler.nextPacket(paramJPacket, localEntry.user);
    }
  }
  
  public void nextPacket(JPacket paramJPacket, Object paramObject)
  {
    fireNextPacket(paramJPacket);
  }
  
  private static class Entry
  {
    public JPacketHandler<Object> handler;
    public Object user;
    
    public Entry(JPacketHandler<?> paramJPacketHandler, Object paramObject)
    {
      this.handler = paramJPacketHandler;
      this.user = paramObject;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.JPacketSupport
 * JD-Core Version:    0.7.0.1
 */