package org.jnetpcap.util.checksum;

import org.jnetpcap.nio.JBuffer;

public class Checksum
{
  public static native int crc16CCITT(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static int crc16CCITTContinue(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3)
  {
    return crc16CCITTSeed(paramJBuffer, paramInt1, paramInt2, paramInt3 ^ 0xFFFFFFFF);
  }
  
  public static native int crc16CCITTSeed(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3);
  
  public static native int crc16X25CCITT(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static native int crc32c(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3);
  
  public static native long crc32CCITT(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static int crc32CCITTContinue(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3)
  {
    return crc32CCITTSeed(paramJBuffer, paramInt1, paramInt2, paramInt3 ^ 0xFFFFFFFF);
  }
  
  public static native int crc32CCITTSeed(JBuffer paramJBuffer, int paramInt1, int paramInt2, int paramInt3);
  
  public static native long crc32IEEE802(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static long flip(long paramLong)
  {
    return (paramLong >> 0 & 0xFF) << 24 | (paramLong >> 8 & 0xFF) << 16 | (paramLong >> 16 & 0xFF) << 8 | (paramLong >> 24 & 0xFF) << 0;
  }
  
  public static native int icmp(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static native int inChecksum(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static native int inChecksumShouldBe(int paramInt1, int paramInt2);
  
  public static native int pseudoTcp(JBuffer paramJBuffer, int paramInt1, int paramInt2);
  
  public static native int pseudoUdp(JBuffer paramJBuffer, int paramInt1, int paramInt2);
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.checksum.Checksum
 * JD-Core Version:    0.7.0.1
 */