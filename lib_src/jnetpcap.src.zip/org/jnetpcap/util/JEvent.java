package org.jnetpcap.util;

import java.beans.PropertyChangeEvent;

public class JEvent
{
  public static int intValue(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return Integer.parseInt((String)paramPropertyChangeEvent.getNewValue());
  }
  
  public static long longValue(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return Long.parseLong((String)paramPropertyChangeEvent.getNewValue());
  }
  
  public static boolean booleanValue(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return Boolean.parseBoolean((String)paramPropertyChangeEvent.getNewValue());
  }
  
  public static String stringValue(PropertyChangeEvent paramPropertyChangeEvent)
  {
    return (String)paramPropertyChangeEvent.getNewValue();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.JEvent
 * JD-Core Version:    0.7.0.1
 */