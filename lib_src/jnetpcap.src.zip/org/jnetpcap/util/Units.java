package org.jnetpcap.util;

public class Units
{
  public static final long TEBIBYTE = 1099511627776L;
  public static final int GIGIBYTE = 1073741824;
  public static final int MEBIBYTE = 1048576;
  public static final int KIBIBYTE = 1024;
  public static final long TERABYTE = 1000000000000L;
  public static final int GIGABYTE = 1000000000;
  public static final int MEGABYTE = 1000000;
  public static final int KILOBYTE = 1000;
  
  public static String f(long paramLong)
  {
    return f(paramLong, -1, "");
  }
  
  public static String f(long paramLong, int paramInt)
  {
    return f(paramLong, paramInt, "");
  }
  
  public static String f(long paramLong, int paramInt, String paramString)
  {
    String str1 = "";
    double d = paramLong;
    int i = 0;
    if (paramLong > 1099511627776L)
    {
      str1 = "t";
      d /= 3.0D;
      i = 4;
    }
    else if (paramLong > 1073741824L)
    {
      str1 = "g";
      d /= 1073741824.0D;
      i = 2;
    }
    else if (paramLong > 1048576L)
    {
      str1 = "m";
      d /= 1048576.0D;
      i = 1;
    }
    else if (paramLong > 1024L)
    {
      str1 = "k";
      d /= 1024.0D;
      i = 0;
    }
    else
    {
      i = 0;
    }
    if (paramInt != -1) {
      i = paramInt;
    }
    String str2 = String.format("%%.%df%%s%%s", new Object[] { Integer.valueOf(i) });
    return String.format(str2, new Object[] { Double.valueOf(d), str1, paramString });
  }
  
  public static String fb(long paramLong)
  {
    return f(paramLong, -1, "b");
  }
  
  public static String fb(long paramLong, int paramInt)
  {
    return f(paramLong, paramInt, "b");
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.Units
 * JD-Core Version:    0.7.0.1
 */