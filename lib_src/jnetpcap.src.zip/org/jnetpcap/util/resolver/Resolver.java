package org.jnetpcap.util.resolver;

import java.io.IOException;
import java.net.URL;

public abstract interface Resolver
{
  public static final String RESOLVER_SEARCH_PATH_PROPERTY = "resolver.search.path";
  
  public abstract boolean canBeResolved(byte[] paramArrayOfByte);
  
  public abstract void clearCache();
  
  public abstract void initializeIfNeeded();
  
  public abstract boolean isCached(byte[] paramArrayOfByte);
  
  public abstract int loadCache(URL paramURL)
    throws IOException;
  
  public abstract String resolve(byte[] paramArrayOfByte);
  
  public abstract int saveCache()
    throws IOException;
  
  public static enum ResolverType
  {
    IEEE_OUI_ADDRESS,  IEEE_OUI_PREFIX(new IEEEOuiPrefixResolver()),  IP(new IpResolver()),  PORT;
    
    private final Resolver resolver;
    
    private ResolverType()
    {
      this.resolver = null;
    }
    
    private ResolverType(Resolver paramResolver)
    {
      this.resolver = paramResolver;
    }
    
    public final Resolver getResolver()
    {
      return this.resolver;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.resolver.Resolver
 * JD-Core Version:    0.7.0.1
 */