package org.jnetpcap.util.resolver;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URL;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jnetpcap.util.JEvent;
import org.jnetpcap.util.config.JConfig;

public abstract class AbstractResolver
  implements Resolver, PropertyChangeListener
{
  private static final int DEFAULT_BACKOFF = 10;
  private static final String DEFAULT_CACHE_SUFFIX = ".resolver";
  private static final String DEFAULT_HOME = "@{user.home}/@{${subdir}}";
  private static final int DEFAULT_MAX_ENTRIES = 1000;
  private static final boolean DEFAULT_MKDIR_HOME = false;
  private static final long DEFAULT_NEGATIVE_TIMEOUT_IN_MILLIS = 1800000L;
  protected static final long INFINITE_TIMEOUT = 157680000000L;
  private static final long DEFAULT_POSITIVE_TIMEOUT_IN_MILLIS = 86400000L;
  private static final boolean DEFAULT_SAVE_CACHE = false;
  private static final String NEWLINE_SEPARATOR = System.getProperty("line.separator");
  private static final String PROPERTY_BACKOFF = "resolver.%sbackoff";
  private static final String PROPERTY_CACHE_SUFFIX = "resolver.suffix";
  private static final String PROPERTY_MAX_ENTRIES = "resolver.%smaxentries";
  private static final String PROPERTY_MKDIR_HOME = "resolver.home.mkdir";
  private static final String PROPERTY_NEGATIVE_TIMEOUT = "resolver.%stimeout.negative";
  private static final String PROPERTY_POSITIVE_TIMEOUT = "resolver.%stimeout.positive";
  private static final String PROPERTY_RESOLVER_HOME = "resolver.home";
  private static final String PROPERTY_RESOLVER_HOME_SEARCH_PATH = "resolver.home.search.path";
  private static final String PROPERTY_RESOLVER_FILE_SEARCH_PATH = "resolver.search.path";
  private static final String PROPERTY_SAVE_CACHE = "resolver.%ssave";
  private int backoff = 10;
  private Map<Long, String> cache;
  private int cacheCapacity = 100;
  private float cacheLoadFactor = 0.75F;
  private boolean isModified = false;
  protected final Logger logger;
  private int maxentries = 1000;
  private boolean mkdirHome = false;
  private final String name;
  private long negativeTimeout = 1800000L;
  private long positiveTimeout = 86400000L;
  private boolean saveCache = false;
  private Queue<TimeoutEntry> timeoutQueue;
  
  public AbstractResolver(Logger paramLogger, Resolver.ResolverType paramResolverType)
  {
    this(paramLogger, paramResolverType.name());
  }
  
  public AbstractResolver(Logger paramLogger, String paramString)
  {
    this.logger = paramLogger;
    this.name = paramString;
    if ((paramString == null) || (paramString.length() == 0)) {
      throw new IllegalArgumentException("resolver's name must be set");
    }
  }
  
  public void addToCache(long paramLong, String paramString)
  {
    if ((paramString != null) && (this.positiveTimeout != 0L)) {
      addToCache(paramLong, paramString, this.positiveTimeout);
    }
    if ((paramString == null) && (this.negativeTimeout != 0L)) {
      addToCache(paramLong, paramString, this.negativeTimeout);
    }
  }
  
  public void addToCache(long paramLong1, String paramString, long paramLong2)
  {
    if (this.cache.containsKey(Long.valueOf(paramLong1)))
    {
      this.logger.finest(String.format("[%d] replacing %X", new Object[] { Integer.valueOf(this.cache.size()), Long.valueOf(paramLong1) }));
      this.cache.remove(Long.valueOf(paramLong1));
    }
    else if (this.logger.isLoggable(Level.FINEST))
    {
      this.logger.finest(String.format("[%d] adding %X %s", new Object[] { Integer.valueOf(this.cache.size()), Long.valueOf(paramLong1), String.valueOf(paramString) }));
    }
    this.isModified = true;
    this.cache.put(Long.valueOf(paramLong1), paramString);
    TimeoutEntry localTimeoutEntry;
    this.timeoutQueue.add(localTimeoutEntry = new TimeoutEntry(paramLong1, paramLong2));
    if (this.cache.size() >= this.maxentries) {
      timeoutCacheOldest(this.maxentries * 100 / this.backoff);
    }
    long l = localTimeoutEntry.timeout - System.currentTimeMillis();
    if (l != paramLong2) {
      this.logger.finest(String.format("invalid timeout %d != %d", new Object[] { Long.valueOf(l), Long.valueOf(paramLong2) }));
    }
  }
  
  public boolean canBeResolved(byte[] paramArrayOfByte)
  {
    return resolve(paramArrayOfByte) != null;
  }
  
  public void clearCache()
  {
    if (this.cache != null)
    {
      this.cache.clear();
      this.isModified = true;
    }
    if (this.timeoutQueue != null)
    {
      this.timeoutQueue.clear();
      this.isModified = true;
    }
  }
  
  private void createCache()
  {
    this.cache = Collections.synchronizedMap(new HashMap(this.cacheCapacity, this.cacheLoadFactor));
    this.timeoutQueue = new PriorityQueue(this.cacheCapacity, new Comparator()
    {
      public int compare(AbstractResolver.TimeoutEntry paramAnonymousTimeoutEntry1, AbstractResolver.TimeoutEntry paramAnonymousTimeoutEntry2)
      {
        return (int)(paramAnonymousTimeoutEntry1.timeout - paramAnonymousTimeoutEntry2.timeout);
      }
    });
  }
  
  private String filename()
  {
    String str = this.name + JConfig.getProperty("resolver.suffix", ".resolver");
    return str;
  }
  
  protected void finalize()
    throws Throwable
  {
    saveCache();
    super.finalize();
  }
  
  public final int getCacheCapacity()
  {
    return this.cacheCapacity;
  }
  
  public final float getCacheLoadFactor()
  {
    return this.cacheLoadFactor;
  }
  
  public final long getNegativeTimeout()
  {
    return this.negativeTimeout;
  }
  
  public final long getPositiveTimeout()
  {
    return this.positiveTimeout;
  }
  
  protected boolean hasCacheFile()
  {
    File localFile;
    try
    {
      localFile = JConfig.getFile(this.name, "resolver.search.path");
    }
    catch (IOException localIOException)
    {
      return false;
    }
    return (localFile != null) && (localFile.canRead()) && (localFile.length() > 0L);
  }
  
  public void initializeIfNeeded()
  {
    if (this.cache == null)
    {
      createCache();
      initProperties();
      try
      {
        loadCache();
      }
      catch (IOException localIOException)
      {
        localIOException.printStackTrace();
      }
    }
  }
  
  private void initProperties()
  {
    JConfig.addListener(this, String.format("resolver.%stimeout.positive", new Object[] { "" }), 86400000L);
    JConfig.addListener(this, String.format("resolver.%stimeout.negative", new Object[] { "" }), 1800000L);
    JConfig.addListener(this, String.format("resolver.%ssave", new Object[] { "" }), false);
    JConfig.addListener(this, String.format("resolver.%smaxentries", new Object[] { "" }), 1000);
    JConfig.addListener(this, String.format("resolver.%sbackoff", new Object[] { "" }), 10);
    JConfig.addListener(this, String.format("resolver.home.mkdir", new Object[] { "" }), false);
    String str = this.name + ".";
    JConfig.addListener(this, String.format("resolver.%stimeout.positive", new Object[] { str }), null);
    JConfig.addListener(this, String.format("resolver.%stimeout.negative", new Object[] { str }), null);
    JConfig.addListener(this, String.format("resolver.%ssave", new Object[] { str }), null);
    JConfig.addListener(this, String.format("resolver.%smaxentries", new Object[] { str }), null);
    JConfig.addListener(this, String.format("resolver.%sbackoff", new Object[] { this.name + "." }), null);
  }
  
  public boolean isCached(byte[] paramArrayOfByte)
  {
    return this.cache.containsKey(Long.valueOf(toHashCode(paramArrayOfByte)));
  }
  
  public int loadCache()
    throws IOException
  {
    URL localURL = JConfig.getURL(this.name, "resolver.search.path");
    if (localURL == null)
    {
      this.logger.fine("cache file " + this.name + " not found");
      return 0;
    }
    this.logger.finer("loading cache file " + localURL.toString());
    return loadCache(new BufferedReader(new InputStreamReader(localURL.openStream())));
  }
  
  private int loadCache(BufferedReader paramBufferedReader)
    throws IOException
  {
    long l1 = System.currentTimeMillis();
    int i = 0;
    if (this.cache == null) {
      createCache();
    } else {
      this.cache.clear();
    }
    synchronized (this.cache)
    {
      try
      {
        boolean bool = this.isModified;
        String str1;
        while ((str1 = paramBufferedReader.readLine()) != null)
        {
          String[] arrayOfString = str1.split(":", 3);
          if (arrayOfString.length != 3)
          {
            this.isModified = true;
            this.logger.fine("corrupt entry in cache file");
          }
          else
          {
            long l2 = Long.parseLong(arrayOfString[0], 16);
            long l3 = 0L;
            try
            {
              l3 = Long.parseLong(arrayOfString[1], 16);
            }
            catch (NumberFormatException localNumberFormatException)
            {
              bool = true;
            }
            continue;
            String str2 = arrayOfString[2].length() == 0 ? null : arrayOfString[2];
            if (l3 <= l1)
            {
              this.logger.fine(String.format("on load timeout, skipping %x %d\n", new Object[] { Long.valueOf(l2), Long.valueOf((l3 - l1) / 1000L) }));
              this.isModified = true;
            }
            else
            {
              addToCache(l2, str2, l3 - l1);
              i++;
            }
          }
        }
        this.isModified = bool;
      }
      finally
      {
        paramBufferedReader.close();
      }
    }
    return i;
  }
  
  public int loadCache(String paramString)
    throws IOException
  {
    File localFile = new File(paramString);
    if (!localFile.canRead()) {
      return 0;
    }
    BufferedReader localBufferedReader = new BufferedReader(new FileReader(localFile));
    return loadCache(localBufferedReader);
  }
  
  public int loadCache(URL paramURL)
    throws IOException
  {
    return loadCache(new BufferedReader(new InputStreamReader(paramURL.openStream())));
  }
  
  public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
  {
    if (String.format("resolver.%stimeout.negative", new Object[] { "" }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.negativeTimeout = JEvent.longValue(paramPropertyChangeEvent);
      if (this.negativeTimeout == -1L) {
        this.negativeTimeout = 157680000000L;
      }
    }
    else if (String.format("resolver.%stimeout.positive", new Object[] { "" }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.positiveTimeout = JEvent.longValue(paramPropertyChangeEvent);
      if (this.positiveTimeout == -1L) {
        this.positiveTimeout = 157680000000L;
      }
    }
    else if (String.format("resolver.%ssave", new Object[] { "" }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.saveCache = JEvent.booleanValue(paramPropertyChangeEvent);
    }
    else if (String.format("resolver.%smaxentries", new Object[] { "" }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.maxentries = JEvent.intValue(paramPropertyChangeEvent);
      if (this.cache.size() > this.maxentries) {
        timeoutCacheOldest(this.maxentries * 100 / this.backoff);
      }
    }
    else if (String.format("resolver.%sbackoff", new Object[] { "" }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.backoff = JEvent.intValue(paramPropertyChangeEvent);
    }
    else if (String.format("resolver.home.mkdir", new Object[] { "" }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.mkdirHome = JEvent.booleanValue(paramPropertyChangeEvent);
    }
    else if (String.format("resolver.%stimeout.negative", new Object[] { this.name + "." }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.negativeTimeout = JEvent.longValue(paramPropertyChangeEvent);
      if (this.negativeTimeout == -1L) {
        this.negativeTimeout = 157680000000L;
      }
    }
    else if (String.format("resolver.%stimeout.positive", new Object[] { this.name + "." }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.positiveTimeout = JEvent.longValue(paramPropertyChangeEvent);
      if (this.positiveTimeout == -1L) {
        this.positiveTimeout = 157680000000L;
      }
    }
    else if (String.format("resolver.%ssave", new Object[] { this.name + "." }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.saveCache = JEvent.booleanValue(paramPropertyChangeEvent);
    }
    else if (String.format("resolver.%smaxentries", new Object[] { this.name + "." }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.maxentries = JEvent.intValue(paramPropertyChangeEvent);
      if (this.cache.size() > this.maxentries) {
        timeoutCacheOldest(this.maxentries * 100 / this.backoff);
      }
    }
    else if (String.format("resolver.%sbackoff", new Object[] { this.name + "." }).equals(paramPropertyChangeEvent.getPropertyName()))
    {
      this.backoff = JEvent.intValue(paramPropertyChangeEvent);
    }
  }
  
  public final String resolve(byte[] paramArrayOfByte)
  {
    timeoutCache();
    long l = toHashCode(paramArrayOfByte);
    if (this.cache.containsKey(Long.valueOf(l))) {
      return (String)this.cache.get(Long.valueOf(l));
    }
    String str = resolveToName(paramArrayOfByte, l);
    addToCache(l, str);
    return str;
  }
  
  protected abstract String resolveToName(byte[] paramArrayOfByte, long paramLong);
  
  protected abstract String resolveToName(long paramLong1, long paramLong2);
  
  public int saveCache()
    throws IOException
  {
    timeoutCache();
    if ((!this.saveCache) || (!this.isModified) || (this.timeoutQueue.isEmpty())) {
      return 0;
    }
    URL localURL = JConfig.getURL(this.name, "resolver.search.path");
    if (localURL == null)
    {
      this.logger.fine("cache file " + this.name + " not found");
      File localFile = JConfig.getDir("resolver.home.search.path");
      if (localFile == null)
      {
        this.logger.fine("cache directory not found");
        if (this.mkdirHome == true)
        {
          this.logger.fine("attempting to create cache directory using property resolver.home");
          localFile = JConfig.createDir("resolver.home", "@{user.home}/@{${subdir}}");
          if (localFile == null) {
            return 0;
          }
        }
        else
        {
          this.logger.finer("property resolver.home.mkdir set to false, giving up");
          return 0;
        }
      }
      localURL = new File(localFile, filename()).toURI().toURL();
    }
    this.logger.finer("saving cache " + localURL.toString());
    int i = saveCache(new PrintWriter(new OutputStreamWriter(new FileOutputStream(localURL.getFile()))));
    if (i == 0) {
      throw new IllegalStateException("Saved empty cache");
    }
    return i;
  }
  
  private int saveCache(PrintWriter paramPrintWriter)
  {
    int i = 0;
    this.logger.finer(String.format("saving %d entries", new Object[] { Integer.valueOf(this.cache.size()) }));
    synchronized (this.cache)
    {
      try
      {
        Iterator localIterator = this.timeoutQueue.iterator();
        while (localIterator.hasNext())
        {
          TimeoutEntry localTimeoutEntry = (TimeoutEntry)localIterator.next();
          String str = (String)this.cache.get(Long.valueOf(localTimeoutEntry.hash));
          if (this.logger.isLoggable(Level.FINEST)) {
            this.logger.finest(String.format("saving %X %X\n", new Object[] { Long.valueOf(localTimeoutEntry.hash), Long.valueOf(localTimeoutEntry.timeout - System.currentTimeMillis()) }));
          }
          paramPrintWriter.format("%X:%d:%s" + NEWLINE_SEPARATOR, new Object[] { Long.valueOf(localTimeoutEntry.hash), Long.valueOf(localTimeoutEntry.timeout), str == null ? "" : str });
          i++;
        }
      }
      finally
      {
        paramPrintWriter.close();
      }
    }
    return i;
  }
  
  public int saveCache(String paramString)
    throws IOException
  {
    File localFile = new File(paramString);
    if (localFile.exists()) {
      localFile.delete();
    }
    if (!localFile.createNewFile()) {
      return 0;
    }
    PrintWriter localPrintWriter = new PrintWriter(new FileWriter(localFile));
    return saveCache(localPrintWriter);
  }
  
  public final void setCacheCapacity(int paramInt)
  {
    this.cacheCapacity = paramInt;
  }
  
  public final void setCacheLoadFactor(float paramFloat)
  {
    this.cacheLoadFactor = paramFloat;
  }
  
  public final void setNegativeTimeout(long paramLong)
  {
    JConfig.setProperty(String.format("resolver.%stimeout.negative", new Object[] { this.name + "." }), Long.toString(paramLong));
  }
  
  public final void setPositiveTimeout(long paramLong)
  {
    JConfig.setProperty(String.format("resolver.%stimeout.positive", new Object[] { this.name + "." }), Long.toString(paramLong));
  }
  
  private void timeoutCache()
  {
    long l = System.currentTimeMillis();
    synchronized (this.cache)
    {
      Iterator localIterator = this.timeoutQueue.iterator();
      while (localIterator.hasNext())
      {
        TimeoutEntry localTimeoutEntry = (TimeoutEntry)localIterator.next();
        if (localTimeoutEntry.timeout >= l) {
          break;
        }
        System.out.printf("%s: %s %s\n", new Object[] { "timeout()", this.logger, this.logger.getLevel() });
        this.logger.finest(String.format("timedout %s\n", new Object[] { this.cache.get(Long.valueOf(localTimeoutEntry.hash)) }));
        this.cache.remove(Long.valueOf(localTimeoutEntry.hash));
        localIterator.remove();
      }
    }
  }
  
  private void timeoutCacheOldest(int paramInt)
  {
    synchronized (this.cache)
    {
      Iterator localIterator = this.timeoutQueue.iterator();
      while (localIterator.hasNext())
      {
        TimeoutEntry localTimeoutEntry = (TimeoutEntry)localIterator.next();
        if (paramInt-- <= 0) {
          break;
        }
        this.logger.finest(String.format("removed due to backoff %s \n", new Object[] { this.cache.get(Long.valueOf(localTimeoutEntry.hash)) }));
        this.cache.remove(Long.valueOf(localTimeoutEntry.hash));
        localIterator.remove();
      }
    }
  }
  
  protected abstract long toHashCode(byte[] paramArrayOfByte);
  
  protected long toHashCode(long paramLong)
  {
    return paramLong;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(String.format("cache[count=%d], timeout[count=%d, positive=%d, negative=%d], ", new Object[] { Integer.valueOf(this.cache.size()), Integer.valueOf(this.timeoutQueue.size()), Long.valueOf(this.positiveTimeout), Long.valueOf(this.negativeTimeout) }));
    return localStringBuilder.toString();
  }
  
  private static class TimeoutEntry
  {
    public final long hash;
    public final long timeout;
    
    public TimeoutEntry(long paramLong1, long paramLong2)
    {
      this.hash = paramLong1;
      this.timeout = (System.currentTimeMillis() + paramLong2);
      if ((this.timeout < 0L) || (this.timeout - System.currentTimeMillis() < 0L)) {
        throw new IllegalStateException("timeout overflow " + paramLong2);
      }
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.resolver.AbstractResolver
 * JD-Core Version:    0.7.0.1
 */