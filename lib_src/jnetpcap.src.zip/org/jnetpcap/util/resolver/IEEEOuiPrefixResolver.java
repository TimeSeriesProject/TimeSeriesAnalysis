package org.jnetpcap.util.resolver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jnetpcap.packet.format.JFormatter;
import org.jnetpcap.util.JLogger;
import org.jnetpcap.util.config.JConfig;

public class IEEEOuiPrefixResolver
  extends AbstractResolver
{
  public static final String IEEE_OUI_DATABASE_PATH = "http://standards.ieee.org/regauth/oui/oui.txt";
  private static final String RESOURCE_COMPRESSED_OUI_DATABASE = "oui.txt";
  private static final String PROPERTY_OUI_DB_URL = "resolver.OUI_PREFIX.db.url";
  private static final String PROPERTY_OUI_DB_DOWNLOAD = "resolver.OUI_PREFIX.db.download";
  private static final String DEFAULT_OUI_DB_DOWNLOAD = "false";
  private boolean initialized = false;
  
  public IEEEOuiPrefixResolver()
  {
    super(JLogger.getLogger(IEEEOuiPrefixResolver.class), "OUI_PREFIX");
  }
  
  public void initializeIfNeeded()
  {
    if ((!this.initialized) && (!hasCacheFile()))
    {
      this.initialized = true;
      setCacheCapacity(13000);
      super.initializeIfNeeded();
      setPositiveTimeout(157680000000L);
      setNegativeTimeout(0L);
      try
      {
        URL localURL = JConfig.getResourceURL("oui.txt");
        if (localURL != null)
        {
          this.logger.fine("loading compressed database file from " + localURL.toString());
          readOuisFromCompressedIEEEDb("oui.txt");
          return;
        }
        boolean bool = Boolean.parseBoolean(JConfig.getProperty("resolver.OUI_PREFIX.db.download", "false"));
        String str = JConfig.getProperty("resolver.OUI_PREFIX.db.url");
        if ((str != null) && (bool))
        {
          localURL = new URL(str);
          this.logger.fine("loading remote database " + localURL.toString());
          loadCache(localURL);
          return;
        }
      }
      catch (IOException localIOException)
      {
        this.logger.log(Level.WARNING, "error while reading database", localIOException);
      }
    }
    else
    {
      super.initializeIfNeeded();
    }
  }
  
  public int loadCache(URL paramURL)
    throws IOException
  {
    if (paramURL == null) {
      paramURL = new URL("http://standards.ieee.org/regauth/oui/oui.txt");
    }
    return readOuisFromRawIEEEDb(new BufferedReader(new InputStreamReader(paramURL.openStream())));
  }
  
  private int readOuisFromCompressedIEEEDb(BufferedReader paramBufferedReader)
    throws IOException
  {
    int i = 0;
    try
    {
      String str;
      while ((str = paramBufferedReader.readLine()) != null)
      {
        String[] arrayOfString = str.split(":", 2);
        if (arrayOfString.length >= 2)
        {
          Long localLong = Long.valueOf(Long.parseLong(arrayOfString[0], 16));
          super.addToCache(localLong.longValue(), arrayOfString[1]);
          i++;
        }
      }
    }
    finally
    {
      paramBufferedReader.close();
    }
    return i;
  }
  
  private boolean readOuisFromCompressedIEEEDb(String paramString)
    throws FileNotFoundException, IOException
  {
    File localFile = new File(paramString);
    if (localFile.canRead())
    {
      readOuisFromCompressedIEEEDb(new BufferedReader(new FileReader(localFile)));
      return true;
    }
    InputStream localInputStream = JFormatter.class.getClassLoader().getResourceAsStream("resources/" + paramString);
    if (localInputStream == null) {
      return false;
    }
    readOuisFromCompressedIEEEDb(new BufferedReader(new InputStreamReader(localInputStream)));
    return true;
  }
  
  private int readOuisFromRawIEEEDb(BufferedReader paramBufferedReader)
    throws IOException
  {
    int i = 0;
    try
    {
      String str1;
      while ((str1 = paramBufferedReader.readLine()) != null) {
        if (str1.contains("(base 16)"))
        {
          String[] arrayOfString1 = str1.split("\t\t");
          if (arrayOfString1.length >= 2)
          {
            String str2 = arrayOfString1[0].split(" ")[0];
            long l = Long.parseLong(str2, 16);
            String[] arrayOfString2 = arrayOfString1[1].split(" ");
            if (arrayOfString2.length > 1)
            {
              String str3 = arrayOfString2[0];
              if ((str3.length() <= 3) || ((str3.length() == 2) && (str3.charAt(1) == '.'))) {
                str3 = str3 + arrayOfString2[1];
              }
              str3 = str3.replace('.', '_');
              str3 = str3.replace('-', '_');
              str3 = str3.replace('\t', ' ').trim();
              str3 = str3.replace(',', ' ').trim();
              if ((str3.endsWith("_")) || (str3.endsWith("-"))) {
                str3 = str3.substring(0, str3.length() - 1);
              }
              str3 = transform(str3, arrayOfString2);
              super.addToCache(l, str3);
              i++;
            }
          }
        }
      }
    }
    finally
    {
      paramBufferedReader.close();
    }
    return i;
  }
  
  private String transform(String paramString, String[] paramArrayOfString)
  {
    int i = 1;
    for (;;)
    {
      String str1 = paramArrayOfString.length > 1 ? paramArrayOfString[i] : null;
      String str2 = transform(paramString, str1);
      if (str2 == paramString) {
        break;
      }
      paramString = str2;
    }
    return paramString;
  }
  
  private String transform(String paramString1, String paramString2)
  {
    paramString1 = transform(paramString1, paramString2, "Graphic", "Graph");
    paramString1 = transform(paramString1, paramString2, "Electronic", "Elect");
    paramString1 = transform(paramString1, paramString2, "Application", "App");
    paramString1 = transform(paramString1, paramString2, "Incorporated", "Inc");
    paramString1 = transform(paramString1, paramString2, "Corporation", "Corp");
    paramString1 = transform(paramString1, paramString2, "Company", "Co");
    paramString1 = transform(paramString1, paramString2, "Technologies", "Tech");
    paramString1 = transform(paramString1, paramString2, "Technology", "Tech");
    paramString1 = transform(paramString1, paramString2, "Communication", "Com");
    paramString1 = transform(paramString1, paramString2, "Network", "Net");
    paramString1 = transform(paramString1, paramString2, "System", "Sys");
    paramString1 = transform(paramString1, paramString2, "Information", "Info");
    paramString1 = transform(paramString1, paramString2, "Industries", "Ind");
    paramString1 = transform(paramString1, paramString2, "Industrial", "Ind");
    paramString1 = transform(paramString1, paramString2, "Industry", "Ind");
    paramString1 = transform(paramString1, paramString2, "Laboratories", "Lab");
    paramString1 = transform(paramString1, paramString2, "Laboratory", "Ind");
    paramString1 = transform(paramString1, paramString2, "Enterprises", "Ent");
    paramString1 = transform(paramString1, paramString2, "Computer", "Cp");
    paramString1 = transform(paramString1, paramString2, "Manufacturing", "Mfg");
    paramString1 = transform(paramString1, paramString2, "Resources", "Res");
    paramString1 = transform(paramString1, paramString2, "Resource", "Res");
    paramString1 = transform(paramString1, paramString2, "Limited", "Ltd");
    paramString1 = transform(paramString1, paramString2, "International", "Int");
    paramString1 = transform(paramString1, paramString2, "Presentation", "Pres");
    paramString1 = transform(paramString1, paramString2, "Equipment", "Eq");
    paramString1 = transform(paramString1, paramString2, "Peripheral", "Pr");
    paramString1 = transform(paramString1, paramString2, "Interactive", "Int");
    return paramString1;
  }
  
  private String transform(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    String str = paramString3 + "s";
    paramString1 = paramString1.replace(str.toUpperCase(), paramString4);
    paramString1 = paramString1.replace(str.toLowerCase(), paramString4);
    paramString1 = paramString1.replace(str, paramString4);
    paramString1 = paramString1.replace(paramString3.toUpperCase(), paramString4);
    paramString1 = paramString1.replace(paramString3.toLowerCase(), paramString4);
    paramString1 = paramString1.replace(paramString3, paramString4);
    if ((paramString1.equals(paramString4)) && (paramString2 != null)) {
      paramString1 = paramString1 + paramString2;
    }
    return paramString1;
  }
  
  public String resolveToName(byte[] paramArrayOfByte, long paramLong)
  {
    return null;
  }
  
  public long toHashCode(byte[] paramArrayOfByte)
  {
    return (paramArrayOfByte[2] < 0 ? paramArrayOfByte[2] + 256 : paramArrayOfByte[2]) | (paramArrayOfByte[1] < 0 ? paramArrayOfByte[1] + 256 : paramArrayOfByte[1]) << 8 | (paramArrayOfByte[0] < 0 ? paramArrayOfByte[0] + 256 : paramArrayOfByte[0]) << 16;
  }
  
  protected String resolveToName(long paramLong1, long paramLong2)
  {
    throw new UnsupportedOperationException("this resolver only resolves addresses in byte[] form");
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.resolver.IEEEOuiPrefixResolver
 * JD-Core Version:    0.7.0.1
 */