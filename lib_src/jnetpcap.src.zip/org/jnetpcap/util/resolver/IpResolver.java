package org.jnetpcap.util.resolver;

import java.net.InetAddress;
import java.net.UnknownHostException;
import org.jnetpcap.util.JLogger;

public class IpResolver
  extends AbstractResolver
{
  public IpResolver()
  {
    super(JLogger.getLogger(IpResolver.class), "IP");
  }
  
  public String resolveToName(byte[] paramArrayOfByte, long paramLong)
  {
    try
    {
      InetAddress localInetAddress = InetAddress.getByAddress(paramArrayOfByte);
      String str = localInetAddress.getHostName();
      if (!Character.isDigit(str.charAt(0))) {
        return str;
      }
    }
    catch (UnknownHostException localUnknownHostException)
    {
      localUnknownHostException.printStackTrace();
    }
    return null;
  }
  
  public long toHashCode(byte[] paramArrayOfByte)
  {
    long l = (paramArrayOfByte[3] < 0 ? paramArrayOfByte[3] + 256 : paramArrayOfByte[3]) | (paramArrayOfByte[2] < 0 ? paramArrayOfByte[2] + 256 : paramArrayOfByte[2]) << 8 | (paramArrayOfByte[1] < 0 ? paramArrayOfByte[1] + 256 : paramArrayOfByte[1]) << 16 | (paramArrayOfByte[0] < 0 ? paramArrayOfByte[0] + 256 : paramArrayOfByte[0]) << 24;
    return l;
  }
  
  protected String resolveToName(long paramLong1, long paramLong2)
  {
    throw new UnsupportedOperationException("this resolver only resolves addresses in byte[] form");
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.resolver.IpResolver
 * JD-Core Version:    0.7.0.1
 */