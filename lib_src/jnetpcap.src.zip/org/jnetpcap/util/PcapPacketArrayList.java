package org.jnetpcap.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;

public class PcapPacketArrayList
  implements List<PcapPacket>, RandomAccess, Serializable, PcapPacketHandler<Object>
{
  private static final long serialVersionUID = -6379668946303974430L;
  private final ArrayList<PcapPacket> list;
  
  public PcapPacketArrayList()
  {
    this.list = new ArrayList();
  }
  
  public PcapPacketArrayList(int paramInt)
  {
    this.list = new ArrayList(paramInt);
  }
  
  public PcapPacketArrayList(Collection<? extends PcapPacket> paramCollection)
  {
    this.list = new ArrayList(paramCollection);
  }
  
  public void add(int paramInt, PcapPacket paramPcapPacket)
  {
    this.list.add(paramInt, paramPcapPacket);
  }
  
  public boolean add(PcapPacket paramPcapPacket)
  {
    return this.list.add(paramPcapPacket);
  }
  
  public boolean addAll(Collection<? extends PcapPacket> paramCollection)
  {
    return this.list.addAll(paramCollection);
  }
  
  public boolean addAll(int paramInt, Collection<? extends PcapPacket> paramCollection)
  {
    return this.list.addAll(paramInt, paramCollection);
  }
  
  public void clear()
  {
    this.list.clear();
  }
  
  public Object clone()
  {
    return this.list.clone();
  }
  
  public boolean contains(Object paramObject)
  {
    return this.list.contains(paramObject);
  }
  
  public boolean containsAll(Collection<?> paramCollection)
  {
    return this.list.containsAll(paramCollection);
  }
  
  public void ensureCapacity(int paramInt)
  {
    this.list.ensureCapacity(paramInt);
  }
  
  public boolean equals(Object paramObject)
  {
    return this.list.equals(paramObject);
  }
  
  public PcapPacket get(int paramInt)
  {
    return (PcapPacket)this.list.get(paramInt);
  }
  
  public int hashCode()
  {
    return this.list.hashCode();
  }
  
  public int indexOf(Object paramObject)
  {
    return this.list.indexOf(paramObject);
  }
  
  public boolean isEmpty()
  {
    return this.list.isEmpty();
  }
  
  public Iterator<PcapPacket> iterator()
  {
    return this.list.iterator();
  }
  
  public int lastIndexOf(Object paramObject)
  {
    return this.list.lastIndexOf(paramObject);
  }
  
  public ListIterator<PcapPacket> listIterator()
  {
    return this.list.listIterator();
  }
  
  public ListIterator<PcapPacket> listIterator(int paramInt)
  {
    return this.list.listIterator(paramInt);
  }
  
  public PcapPacket remove(int paramInt)
  {
    return (PcapPacket)this.list.remove(paramInt);
  }
  
  public boolean remove(Object paramObject)
  {
    return this.list.remove(paramObject);
  }
  
  public boolean removeAll(Collection<?> paramCollection)
  {
    return this.list.removeAll(paramCollection);
  }
  
  public boolean retainAll(Collection<?> paramCollection)
  {
    return this.list.retainAll(paramCollection);
  }
  
  public PcapPacket set(int paramInt, PcapPacket paramPcapPacket)
  {
    return (PcapPacket)this.list.set(paramInt, paramPcapPacket);
  }
  
  public int size()
  {
    return this.list.size();
  }
  
  public List<PcapPacket> subList(int paramInt1, int paramInt2)
  {
    return this.list.subList(paramInt1, paramInt2);
  }
  
  public Object[] toArray()
  {
    return this.list.toArray();
  }
  
  public <T> T[] toArray(T[] paramArrayOfT)
  {
    return this.list.toArray(paramArrayOfT);
  }
  
  public String toString()
  {
    return this.list.toString();
  }
  
  public void trimToSize()
  {
    this.list.trimToSize();
  }
  
  public void nextPacket(PcapPacket paramPcapPacket, Object paramObject)
  {
    this.list.add(paramPcapPacket);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.PcapPacketArrayList
 * JD-Core Version:    0.7.0.1
 */