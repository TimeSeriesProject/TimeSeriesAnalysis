package org.jnetpcap.util;

import java.util.AbstractQueue;
import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicInteger;

public class HoldQueue<T, C>
  extends AbstractQueue<T>
  implements Queue<T>
{
  private final PriorityQueue<HoldHandle<C>> handles = new PriorityQueue();
  private final Queue<T> exposed;
  private HoldHandle<C> hold;
  
  protected HoldQueue(Queue<T> paramQueue1, Queue<T> paramQueue2, Comparator<T> paramComparator)
  {
    this.exposed = paramQueue2;
  }
  
  public Iterator<T> iterator()
  {
    return this.exposed.iterator();
  }
  
  private void release(HoldHandle<C> paramHoldHandle)
  {
    this.handles.remove(paramHoldHandle);
    this.hold = (this.handles.isEmpty() ? null : (HoldHandle)this.handles.peek());
  }
  
  public int size()
  {
    return this.exposed.size();
  }
  
  public boolean offer(T paramT)
  {
    if (this.hold == null) {
      this.exposed.offer(paramT);
    }
    throw new UnsupportedOperationException("Not implemented yet");
  }
  
  public T peek()
  {
    return this.exposed.peek();
  }
  
  public T poll()
  {
    return this.exposed.poll();
  }
  
  public static class HoldHandle<C>
    implements Comparable<C>
  {
    private final AtomicInteger ref = new AtomicInteger();
    private final Comparable<C> hold;
    private final HoldQueue<?, C> parent;
    
    public HoldHandle(HoldQueue<?, C> paramHoldQueue, Comparable<C> paramComparable)
    {
      this.hold = paramComparable;
      this.parent = paramHoldQueue;
    }
    
    public int release()
    {
      int i = this.ref.decrementAndGet();
      if (i < 0) {
        throw new IllegalStateException("invalid hold-handle");
      }
      if (i == 0) {
        this.parent.release(this);
      }
      return i;
    }
    
    public int compareTo(C paramC)
    {
      return this.hold.compareTo(paramC);
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.HoldQueue
 * JD-Core Version:    0.7.0.1
 */