package org.jnetpcap.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;

public class PcapPacketSupport
  implements PcapPacketHandler<Object>
{
  private List<Entry> listeners = new ArrayList();
  private Entry[] listenersArray = null;
  
  public <T> boolean add(PcapPacketHandler<T> paramPcapPacketHandler, T paramT)
  {
    this.listenersArray = null;
    return this.listeners.add(new Entry(paramPcapPacketHandler, paramT));
  }
  
  public boolean remove(PcapPacketHandler<?> paramPcapPacketHandler)
  {
    this.listenersArray = null;
    Iterator localIterator = this.listeners.iterator();
    while (localIterator.hasNext())
    {
      Entry localEntry = (Entry)localIterator.next();
      if (paramPcapPacketHandler == localEntry.handler)
      {
        localIterator.remove();
        this.listenersArray = null;
        return true;
      }
    }
    return false;
  }
  
  public void fireNextPacket(PcapPacket paramPcapPacket)
  {
    if (this.listenersArray == null) {
      this.listenersArray = ((Entry[])this.listeners.toArray(new Entry[this.listeners.size()]));
    }
    for (Entry localEntry : this.listenersArray) {
      localEntry.handler.nextPacket(paramPcapPacket, localEntry.user);
    }
  }
  
  public void nextPacket(PcapPacket paramPcapPacket, Object paramObject)
  {
    fireNextPacket(paramPcapPacket);
  }
  
  private static class Entry
  {
    public PcapPacketHandler<Object> handler;
    public Object user;
    
    public Entry(PcapPacketHandler<?> paramPcapPacketHandler, Object paramObject)
    {
      this.handler = paramPcapPacketHandler;
      this.user = paramObject;
    }
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.PcapPacketSupport
 * JD-Core Version:    0.7.0.1
 */