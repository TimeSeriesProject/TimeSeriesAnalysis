package org.jnetpcap.util;

public class JStringBuilder
  implements Appendable
{
  private final StringBuilder buffer;
  
  public JStringBuilder()
  {
    this.buffer = new StringBuilder();
  }
  
  public JStringBuilder(CharSequence paramCharSequence)
  {
    this.buffer = new StringBuilder(paramCharSequence);
  }
  
  public JStringBuilder(int paramInt)
  {
    this.buffer = new StringBuilder(paramInt);
  }
  
  public JStringBuilder(String paramString)
  {
    this.buffer = new StringBuilder(paramString);
  }
  
  public StringBuilder append(boolean paramBoolean)
  {
    return this.buffer.append(paramBoolean);
  }
  
  public StringBuilder append(char paramChar)
  {
    return this.buffer.append(paramChar);
  }
  
  public StringBuilder append(char[] paramArrayOfChar)
  {
    return this.buffer.append(paramArrayOfChar);
  }
  
  public StringBuilder append(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    return this.buffer.append(paramArrayOfChar, paramInt1, paramInt2);
  }
  
  public StringBuilder append(CharSequence paramCharSequence)
  {
    return this.buffer.append(paramCharSequence);
  }
  
  public StringBuilder append(CharSequence paramCharSequence, int paramInt1, int paramInt2)
  {
    return this.buffer.append(paramCharSequence, paramInt1, paramInt2);
  }
  
  public StringBuilder append(double paramDouble)
  {
    return this.buffer.append(paramDouble);
  }
  
  public StringBuilder append(float paramFloat)
  {
    return this.buffer.append(paramFloat);
  }
  
  public StringBuilder append(int paramInt)
  {
    return this.buffer.append(paramInt);
  }
  
  public StringBuilder append(long paramLong)
  {
    return this.buffer.append(paramLong);
  }
  
  public StringBuilder append(Object paramObject)
  {
    return this.buffer.append(paramObject);
  }
  
  public StringBuilder append(String paramString)
  {
    return this.buffer.append(paramString);
  }
  
  public StringBuilder append(StringBuffer paramStringBuffer)
  {
    return this.buffer.append(paramStringBuffer);
  }
  
  public StringBuilder appendCodePoint(int paramInt)
  {
    return this.buffer.appendCodePoint(paramInt);
  }
  
  public int capacity()
  {
    return this.buffer.capacity();
  }
  
  public char charAt(int paramInt)
  {
    return this.buffer.charAt(paramInt);
  }
  
  public int codePointAt(int paramInt)
  {
    return this.buffer.codePointAt(paramInt);
  }
  
  public int codePointBefore(int paramInt)
  {
    return this.buffer.codePointBefore(paramInt);
  }
  
  public int codePointCount(int paramInt1, int paramInt2)
  {
    return this.buffer.codePointCount(paramInt1, paramInt2);
  }
  
  public StringBuilder delete(int paramInt1, int paramInt2)
  {
    return this.buffer.delete(paramInt1, paramInt2);
  }
  
  public StringBuilder deleteCharAt(int paramInt)
  {
    return this.buffer.deleteCharAt(paramInt);
  }
  
  public void ensureCapacity(int paramInt)
  {
    this.buffer.ensureCapacity(paramInt);
  }
  
  public boolean equals(Object paramObject)
  {
    return this.buffer.equals(paramObject);
  }
  
  public void getChars(int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3)
  {
    this.buffer.getChars(paramInt1, paramInt2, paramArrayOfChar, paramInt3);
  }
  
  public int hashCode()
  {
    return this.buffer.hashCode();
  }
  
  public int indexOf(String paramString)
  {
    return this.buffer.indexOf(paramString);
  }
  
  public int indexOf(String paramString, int paramInt)
  {
    return this.buffer.indexOf(paramString, paramInt);
  }
  
  public StringBuilder insert(int paramInt, boolean paramBoolean)
  {
    return this.buffer.insert(paramInt, paramBoolean);
  }
  
  public StringBuilder insert(int paramInt, char paramChar)
  {
    return this.buffer.insert(paramInt, paramChar);
  }
  
  public StringBuilder insert(int paramInt, char[] paramArrayOfChar)
  {
    return this.buffer.insert(paramInt, paramArrayOfChar);
  }
  
  public StringBuilder insert(int paramInt1, char[] paramArrayOfChar, int paramInt2, int paramInt3)
  {
    return this.buffer.insert(paramInt1, paramArrayOfChar, paramInt2, paramInt3);
  }
  
  public StringBuilder insert(int paramInt, CharSequence paramCharSequence)
  {
    return this.buffer.insert(paramInt, paramCharSequence);
  }
  
  public StringBuilder insert(int paramInt1, CharSequence paramCharSequence, int paramInt2, int paramInt3)
  {
    return this.buffer.insert(paramInt1, paramCharSequence, paramInt2, paramInt3);
  }
  
  public StringBuilder insert(int paramInt, double paramDouble)
  {
    return this.buffer.insert(paramInt, paramDouble);
  }
  
  public StringBuilder insert(int paramInt, float paramFloat)
  {
    return this.buffer.insert(paramInt, paramFloat);
  }
  
  public StringBuilder insert(int paramInt1, int paramInt2)
  {
    return this.buffer.insert(paramInt1, paramInt2);
  }
  
  public StringBuilder insert(int paramInt, long paramLong)
  {
    return this.buffer.insert(paramInt, paramLong);
  }
  
  public StringBuilder insert(int paramInt, Object paramObject)
  {
    return this.buffer.insert(paramInt, paramObject);
  }
  
  public StringBuilder insert(int paramInt, String paramString)
  {
    return this.buffer.insert(paramInt, paramString);
  }
  
  public int lastIndexOf(String paramString)
  {
    return this.buffer.lastIndexOf(paramString);
  }
  
  public int lastIndexOf(String paramString, int paramInt)
  {
    return this.buffer.lastIndexOf(paramString, paramInt);
  }
  
  public int length()
  {
    return this.buffer.length();
  }
  
  public int offsetByCodePoints(int paramInt1, int paramInt2)
  {
    return this.buffer.offsetByCodePoints(paramInt1, paramInt2);
  }
  
  public StringBuilder replace(int paramInt1, int paramInt2, String paramString)
  {
    return this.buffer.replace(paramInt1, paramInt2, paramString);
  }
  
  public StringBuilder reverse()
  {
    return this.buffer.reverse();
  }
  
  public void setCharAt(int paramInt, char paramChar)
  {
    this.buffer.setCharAt(paramInt, paramChar);
  }
  
  public void setLength(int paramInt)
  {
    this.buffer.setLength(paramInt);
  }
  
  public CharSequence subSequence(int paramInt1, int paramInt2)
  {
    return this.buffer.subSequence(paramInt1, paramInt2);
  }
  
  public String substring(int paramInt)
  {
    return this.buffer.substring(paramInt);
  }
  
  public String substring(int paramInt1, int paramInt2)
  {
    return this.buffer.substring(paramInt1, paramInt2);
  }
  
  public String toString()
  {
    return this.buffer.toString();
  }
  
  public void trimToSize()
  {
    this.buffer.trimToSize();
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.JStringBuilder
 * JD-Core Version:    0.7.0.1
 */