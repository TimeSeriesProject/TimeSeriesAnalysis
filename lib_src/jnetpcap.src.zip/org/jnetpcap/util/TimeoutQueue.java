package org.jnetpcap.util;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class TimeoutQueue
{
  private Queue<Timeout> timeoutQueue = new PriorityQueue();
  
  public void timeout(long paramLong)
  {
    if ((this.timeoutQueue.isEmpty()) || (!((Timeout)this.timeoutQueue.peek()).isTimedout(paramLong))) {
      return;
    }
    Iterator localIterator = this.timeoutQueue.iterator();
    while (localIterator.hasNext())
    {
      Timeout localTimeout = (Timeout)localIterator.next();
      if (!localTimeout.isTimedout(paramLong)) {
        break;
      }
      localIterator.remove();
      localTimeout.timeout();
    }
  }
  
  public boolean timeout(Timeout paramTimeout)
  {
    paramTimeout.timeout();
    return remove(paramTimeout);
  }
  
  public boolean isEmpty()
  {
    return this.timeoutQueue.isEmpty();
  }
  
  public boolean add(Timeout paramTimeout)
  {
    return this.timeoutQueue.add(paramTimeout);
  }
  
  public boolean remove(Timeout paramTimeout)
  {
    return this.timeoutQueue.remove(paramTimeout);
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.util.TimeoutQueue
 * JD-Core Version:    0.7.0.1
 */