package org.jnetpcap;

import java.nio.ByteBuffer;

/**
 * @deprecated
 */
public class PcapPktBuffer
{
  private volatile ByteBuffer buffer;
  
  public final ByteBuffer getBuffer()
  {
    return this.buffer;
  }
}


/* Location:           E:\z资料\编程\java pcap\jnetpcap-1.3.0\jnetpcap.jar
 * Qualified Name:     org.jnetpcap.PcapPktBuffer
 * JD-Core Version:    0.7.0.1
 */