/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.sa;

import ec.nbdemetra.ui.DemetraUI;
import ec.nbdemetra.ws.WorkspaceFactory;
import ec.nbdemetra.ws.WorkspaceItem;
import ec.tss.sa.RegArimaReport;
import ec.tss.sa.SaItem;
import ec.tstoolkit.algorithm.AlgorithmDescriptor;
import ec.tstoolkit.algorithm.CompositeResults;
import ec.tstoolkit.information.InformationSet;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.SwingUtilities;
import org.netbeans.core.spi.multiview.CloseOperationHandler;
import org.netbeans.core.spi.multiview.CloseOperationState;
import org.netbeans.core.spi.multiview.MultiViewDescription;
import org.netbeans.core.spi.multiview.MultiViewElement;
import org.netbeans.core.spi.multiview.MultiViewFactory;
import org.openide.awt.ActionID;
import org.openide.awt.ActionReference;
import org.openide.awt.ActionReferences;
import org.openide.awt.ActionRegistration;
import org.openide.util.HelpCtx;
import org.openide.util.Lookup;
import org.openide.util.LookupEvent;
import org.openide.util.LookupListener;
import org.openide.util.NbBundle.Messages;
import org.openide.windows.TopComponent;

@ActionID(category = "Seasonal Adjustment", id = "ec.nbdemetra.sa.MultiAnalysisAction")
@ActionRegistration(displayName = "#CTL_MultiAnalysisAction")
@ActionReferences({
    @ActionReference(path = "Menu/Statistical methods/Seasonal Adjustment/Multi Processing", position = 10000)
})
@Messages("CTL_MultiAnalysisAction=New")
public final class MultiAnalysisAction implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        MultiProcessingManager mgr = WorkspaceFactory.getInstance().getManager(MultiProcessingManager.class);
        WorkspaceItem<MultiProcessingDocument> doc = mgr.create(WorkspaceFactory.getInstance().getActiveWorkspace());
        TopComponent c = createView(doc);
        c.open();
        c.requestActive();
    }

    public static TopComponent createView(final WorkspaceItem<MultiProcessingDocument> doc) {
        if (doc.isOpen()) {
            return doc.getView();
        }
        // data
        final Map<Integer, Map<AlgorithmDescriptor, RegArimaReport>> reports_ = new HashMap<>();
        final Map<Integer, InformationSet> details_ = new HashMap<>();
        // views
        final SaBatchUI processingView = new SaBatchUI(doc);
        final SummaryView summaryView = new SummaryView();
        final MatrixView matrixView = new MatrixView();

 
        MultiViewDescription[] descriptions = {
            new QuickAndDirtyDescription("Processing", processingView),
            new QuickAndDirtyDescription("Summary", summaryView),
            new QuickAndDirtyDescription("Matrix", matrixView),};

        final TopComponent result = MultiViewFactory.createMultiView(descriptions, descriptions[0]);
        result.setName(doc.getDisplayName());
        doc.setView(result);

        DemetraUI demetraUI = DemetraUI.getDefault();

        processingView.setDefaultSpecification(demetraUI.getDefaultSASpec());
        //processingView.setDefaultSpecification(doc.getElement().getDefaultSpecification());
        processingView.addPropertyChangeListener(SaBatchUI.STATE_PROPERTY, new PropertyChangeListener() {

            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                switch (processingView.getState()) {
                    case DONE:
                        if (processingView.getProcessing().isProcessed()) {
                            if (reports_.isEmpty()) {
                                for (SaItem item : processingView.getProcessing().items()) {
                                    CompositeResults rslt = item.process();
                                    if (rslt != null) {
                                        int freq = item.getTs().getTsData().getFrequency().intValue();
                                        Map<AlgorithmDescriptor, RegArimaReport> reports = reports_.get(freq);
                                        if (reports == null) {
                                            reports = new LinkedHashMap<>();
                                            reports_.put(freq, reports);
                                        }
                                        RegArimaReport report = reports.get(item.getEstimationMethod());
                                        if (report == null) {
                                            report = new RegArimaReport(freq);
                                            reports.put(item.getEstimationMethod(), report);
                                        }
                                        report.add(rslt);
                                    }
                                }
                                summaryView.setData(reports_);
                            }
                            if (details_.isEmpty()) {
                                for (SaItem item : processingView.getProcessing().items()) {
                                    details_.put(item.getKey(), item.getDiagnostics());
                                }
                                matrixView.setData(reports_, processingView.getProcessing().items());
                            }
                        }
                        result.makeBusy(false);
                        result.setAttentionHighlight(true);
                        break;
                    case PENDING:
                        result.makeBusy(false);
                        break;
                    case STARTED:
                        reports_.clear();
                        details_.clear();
                        matrixView.setData(reports_, processingView.getProcessing().items());
                        summaryView.setData(reports_);
                        result.makeBusy(true);
                        break;
                }
            }
        });
        return result;
    }

    static class QuickAndDirtyDescription implements MultiViewDescription, Serializable {

        final String name;
        final MultiViewElement multiViewElement;

        public QuickAndDirtyDescription(String name, MultiViewElement multiViewElement) {
            this.name = name;
            this.multiViewElement = multiViewElement;
        }

        @Override
        public int getPersistenceType() {
            return TopComponent.PERSISTENCE_NEVER;
        }

        @Override
        public String getDisplayName() {
            return name;
        }

        @Override
        public Image getIcon() {
            return null;
        }

        @Override
        public HelpCtx getHelpCtx() {
            return null;
        }

        @Override
        public String preferredID() {
            return name;
        }

        @Override
        public MultiViewElement createElement() {
            return multiViewElement;
        }
    }
}
