/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.nbdemetra.tramoseats.actions;

/**
 *
 * @author Jean Palate
 */
public class CopyResultSpecification {
    
}
